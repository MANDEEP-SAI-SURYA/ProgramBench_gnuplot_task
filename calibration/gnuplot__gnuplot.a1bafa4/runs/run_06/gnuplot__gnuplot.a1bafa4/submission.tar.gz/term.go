package main

import (
	"os"
)

type Multiplot struct {
	rows, cols int
	layout     bool
	rowsFirst  bool
	upwards    bool
	title      string
	idx        int
	canvas     *Canvas
}

var mp *Multiplot

var outFile *os.File

func openOutput() {
	if outFile != nil {
		outFile.Close()
		outFile = nil
	}
	if S.output != "" {
		f, err := os.Create(S.output)
		if err != nil {
			throwNC("cannot open file; output not changed")
		}
		outFile = f
	}
	setVar("GPVAL_OUTPUT", StrV(S.output))
}

func writeOutput(s string) {
	if outFile != nil {
		outFile.WriteString(s)
		return
	}
	stdout.WriteString(s)
}

func setTerminal(p *Parser) {
	if p.endOfCmd() {
		stderr.WriteString("\nAvailable terminal types:\n")
		return
	}
	w := p.tokStr()
	p.c++
	switch {
	case optMatch(w, "dum$b"):
		S.termName = "dumb"
		if S.termW == 0 || S.termName != "dumb" {
			S.termW, S.termH = 79, 24
		}
		sizeGiven, feedGiven := false, false
		nofeed := false
		defer func() { dumbFeed = !nofeed; _ = sizeGiven; _ = feedGiven }()
		for !p.endOfCmd() {
			x := p.tokStr()
			p.c++
			switch {
			case optMatch(x, "si$ze"):
				sizeGiven = true
				S.termW = int(p.evalNum())
				if p.isOp(",") {
					p.c++
					S.termH = int(p.evalNum())
				}
			case x == "feed":
				feedGiven = true
			case x == "nofeed":
				nofeed = true
			case x == "nofeed", x == "enhanced", x == "noenhanced", x == "mono", x == "ansi", x == "ansi256", x == "ansirgb", x == "aspect":
				if x == "aspect" {
					p.evalNum()
					if p.isOp(",") {
						p.c++
						p.evalNum()
					}
				}
			default:
				p.c--
				if t := p.cur(); t.K == TNUM {
					S.termW = int(p.evalNum())
					if p.isOp(",") {
						p.c++
						S.termH = int(p.evalNum())
					}
				} else {
					p.c++
				}
			}
		}
	case optMatch(w, "sv$g"):
		S.termName = "svg"
		S.termW, S.termH = 600, 480
		for !p.endOfCmd() {
			x := p.tokStr()
			p.c++
			if optMatch(x, "si$ze") {
				S.termW = int(p.evalNum())
				if p.isOp(",") {
					p.c++
					S.termH = int(p.evalNum())
				}
			} else if x == "font" || x == "fname" || x == "fsize" || x == "background" || x == "name" || x == "linewidth" || x == "lw" || x == "fontscale" || x == "dashlength" {
				if !p.endOfCmd() {
					p.c++
				}
			}
		}
	case optMatch(w, "canv$as"):
		S.termName = "canvas"
		S.termW, S.termH = 600, 400
		for !p.endOfCmd() {
			x := p.tokStr()
			p.c++
			if optMatch(x, "si$ze") {
				S.termW = int(p.evalNum())
				if p.isOp(",") {
					p.c++
					S.termH = int(p.evalNum())
				}
			}
		}
	case w == "unknown":
		S.termName = "unknown"
	case w == "push" || w == "pop":
	default:
		S.termName = w
		skipToEnd(p)
	}
	setVar("GPVAL_TERM", StrV(S.termName))
}

func showTerminal() string {
	switch S.termName {
	case "dumb":
		f := "feed"
		if !dumbFeed {
			f = "nofeed"
		}
		return "   terminal type is dumb " + f + "  size " + itoa(S.termW) + ", " + itoa(S.termH) + " aspect 2, 1 mono\n"
	case "unknown":
		return "   terminal type is unknown \n"
	}
	return "   terminal type is " + S.termName + " \n"
}

func cmdClear() {}

func cmdUpdate(p *Parser) { skipToEnd(p) }

func mpBegin() {}
func mpEnd() {
	if mp != nil && mp.canvas != nil {
		flushCanvas(mp.canvas)
	}
	mp = nil
	S.multiplot = false
	setVar("GPVAL_MULTIPLOT", IntV(0))
}
