package main

import (
	"math"
	"math/cmplx"
	"os/exec"
	"strings"
	"time"
	"unicode/utf8"
)

type Builtin struct {
	n int
	f func([]Value) Value
}

var builtins map[string]Builtin

var angleDeg = false

func cpow(a, b complex128) complex128 { return cmplx.Pow(a, b) }

func realFn(name string, f func(float64) float64) Builtin {
	return Builtin{1, func(a []Value) Value {
		v := numify(a[0])
		if v.T == CMPLX && v.Im != 0 {
			throwNC("undefined value")
		}
		r := f(v.Real())
		return FltV(r)
	}}
}

func cfn(rf func(float64) (float64, bool), cf func(complex128) complex128) Builtin {
	return Builtin{1, func(a []Value) Value {
		v := numify(a[0])
		if v.Im == 0 {
			if r, ok := rf(v.Real()); ok {
				return FltV(r)
			}
		}
		return fromC(cf(cx(v)))
	}}
}

func angIn(x float64) float64 {
	if angleDeg {
		return x * math.Pi / 180
	}
	return x
}
func angOut(x float64) float64 {
	if angleDeg {
		return x * 180 / math.Pi
	}
	return x
}

func strArg(v Value, fn string) string {
	if v.T != STR {
		throwNC("internal error : " + fn + " of non-STRING argument")
	}
	return v.S
}

func init() {
	builtins = map[string]Builtin{
		"sin":  cfn(func(x float64) (float64, bool) { return math.Sin(angIn(x)), true }, cmplx.Sin),
		"cos":  cfn(func(x float64) (float64, bool) { return math.Cos(angIn(x)), true }, cmplx.Cos),
		"tan":  cfn(func(x float64) (float64, bool) { return math.Tan(angIn(x)), true }, cmplx.Tan),
		"sinh": cfn(func(x float64) (float64, bool) { return math.Sinh(x), true }, cmplx.Sinh),
		"cosh": cfn(func(x float64) (float64, bool) { return math.Cosh(x), true }, cmplx.Cosh),
		"tanh": cfn(func(x float64) (float64, bool) { return math.Tanh(x), true }, cmplx.Tanh),
		"asin": cfn(func(x float64) (float64, bool) { return angOut(math.Asin(x)), x >= -1 && x <= 1 }, cmplx.Asin),
		"acos": cfn(func(x float64) (float64, bool) { return angOut(math.Acos(x)), x >= -1 && x <= 1 }, cmplx.Acos),
		"atan": cfn(func(x float64) (float64, bool) { return angOut(math.Atan(x)), true }, cmplx.Atan),
		"asinh": cfn(func(x float64) (float64, bool) { return math.Asinh(x), true }, cmplx.Asinh),
		"acosh": cfn(func(x float64) (float64, bool) { return math.Acosh(x), x >= 1 }, cmplx.Acosh),
		"atanh": cfn(func(x float64) (float64, bool) { return math.Atanh(x), x > -1 && x < 1 }, cmplx.Atanh),
		"exp":  cfn(func(x float64) (float64, bool) { return math.Exp(x), true }, cmplx.Exp),
		"log": cfn(func(x float64) (float64, bool) {
			if x == 0 {
				undef()
			}
			return math.Log(x), x > 0
		}, cmplx.Log),
		"log10": cfn(func(x float64) (float64, bool) {
			if x == 0 {
				undef()
			}
			return math.Log10(x), x > 0
		}, cmplx.Log10),
		"sqrt": cfn(func(x float64) (float64, bool) { return math.Sqrt(x), x >= 0 }, cmplx.Sqrt),
		"atan2": {2, func(a []Value) Value {
			return FltV(angOut(math.Atan2(numify(a[0]).Real(), numify(a[1]).Real())))
		}},
		"abs": {1, func(a []Value) Value {
			v := numify(a[0])
			if v.T == INT {
				if v.I < 0 {
					return IntV(-v.I)
				}
				return v
			}
			if v.Im == 0 {
				return FltV(math.Abs(v.R))
			}
			return FltV(cmplx.Abs(cx(v)))
		}},
		"sgn": {1, func(a []Value) Value {
			v := numify(a[0])
			x := v.Real()
			if x > 0 {
				return IntV(1)
			} else if x < 0 {
				return IntV(-1)
			}
			return IntV(0)
		}},
		"real": {1, func(a []Value) Value { v := numify(a[0]); return FltV(v.Real()) }},
		"imag": {1, func(a []Value) Value { v := numify(a[0]); return FltV(v.Im) }},
		"arg": {1, func(a []Value) Value {
			v := numify(a[0])
			return FltV(angOut(math.Atan2(v.Im, v.Real())))
		}},
		"conj": {1, func(a []Value) Value { v := numify(a[0]); return CpxV(v.Real(), -v.Im) }},
		"int": {1, func(a []Value) Value {
			v := numify(a[0])
			if v.T == INT {
				return v
			}
			if math.IsNaN(v.R) || math.IsInf(v.R, 0) || math.Abs(v.R) >= 9.2233720368547758e18 {
				undef()
			}
			return IntV(int64(v.R))
		}},
		"floor": {1, func(a []Value) Value {
			v := numify(a[0])
			if v.T == INT {
				return v
			}
			f := math.Floor(v.R)
			if math.Abs(f) >= 9.2233720368547758e18 || math.IsNaN(f) {
				return FltV(f)
			}
			return IntV(int64(f))
		}},
		"ceil": {1, func(a []Value) Value {
			v := numify(a[0])
			if v.T == INT {
				return v
			}
			f := math.Ceil(v.R)
			if math.Abs(f) >= 9.2233720368547758e18 || math.IsNaN(f) {
				return FltV(f)
			}
			return IntV(int64(f))
		}},
		"gamma":  realFn("gamma", math.Gamma),
		"lgamma": realFn("lgamma", func(x float64) float64 { r, _ := math.Lgamma(x); return r }),
		"erf":    realFn("erf", math.Erf),
		"erfc":   realFn("erfc", math.Erfc),
		"inverf": realFn("inverf", math.Erfinv),
		"norm":   realFn("norm", func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": realFn("invnorm", func(p float64) float64 {
			if p <= 0 || p >= 1 {
				undef()
			}
			return -math.Sqrt2 * math.Erfcinv(2*p)
		}),
		"besj0": realFn("besj0", math.J0),
		"besj1": realFn("besj1", math.J1),
		"besy0": realFn("besy0", math.Y0),
		"besy1": realFn("besy1", math.Y1),
		"besjn": {2, func(a []Value) Value { return FltV(math.Jn(int(toInt(a[0])), numify(a[1]).Real())) }},
		"besyn": {2, func(a []Value) Value { return FltV(math.Yn(int(toInt(a[0])), numify(a[1]).Real())) }},
		"besi0": realFn("besi0", func(x float64) float64 { return besselI(0, x) }),
		"besi1": realFn("besi1", func(x float64) float64 { return besselI(1, x) }),
		"besin": {2, func(a []Value) Value { return FltV(besselI(int(toInt(a[0])), numify(a[1]).Real())) }},
		"igamma": {2, func(a []Value) Value { return FltV(igamma(numify(a[0]).Real(), numify(a[1]).Real())) }},
		"ibeta": {3, func(a []Value) Value {
			return FltV(ibeta(numify(a[0]).Real(), numify(a[1]).Real(), numify(a[2]).Real()))
		}},
		"lambertw": realFn("lambertw", lambertw),
		"expint":   {2, func(a []Value) Value { return FltV(expint(int(toInt(a[0])), numify(a[1]).Real())) }},
		"EllipticK": realFn("EllipticK", ellipK),
		"EllipticE": realFn("EllipticE", ellipE),
		"rand": {1, func(a []Value) Value { return FltV(gpRand(toInt(numify(a[0])))) }},
		"strlen": {1, func(a []Value) Value {
			return IntV(int64(utf8.RuneCountInString(strArg(a[0], "strlen"))))
		}},
		"substr": {3, func(a []Value) Value {
			s := []rune(strArg(a[0], "substr"))
			b := int(toInt(a[1]))
			e := int(toInt(a[2]))
			if b < 1 {
				b = 1
			}
			if e > len(s) {
				e = len(s)
			}
			if b > e {
				return StrV("")
			}
			return StrV(string(s[b-1 : e]))
		}},
		"strstrt": {2, func(a []Value) Value {
			s := strArg(a[0], "strstrt")
			t := strArg(a[1], "strstrt")
			i := strings.Index(s, t)
			if i < 0 {
				return IntV(0)
			}
			return IntV(int64(utf8.RuneCountInString(s[:i]) + 1))
		}},
		"words": {1, func(a []Value) Value { return IntV(int64(len(strings.Fields(strArg(a[0], "words"))))) }},
		"word": {2, func(a []Value) Value {
			f := strings.Fields(strArg(a[0], "word"))
			i := int(toInt(a[1]))
			if i < 1 || i > len(f) {
				return StrV("")
			}
			return StrV(f[i-1])
		}},
		"trim": {1, func(a []Value) Value { return StrV(strings.Trim(strArg(a[0], "trim"), " \t\n\r")) }},
		"sprintf": {-1, gpSprintf},
		"gprintf": {2, func(a []Value) Value {
			if a[0].T != STR {
				throwNC("First parameter to gprintf must be a format string")
			}
			return StrV(gprintfBase(a[0].S, numify(a[1]).Real(), 0))
		}},
		"strftime": {2, func(a []Value) Value {
			if a[0].T != STR {
				throwNC("First parameter to strftime must be a format string")
			}
			return StrV(gpStrftime(a[0].S, numify(a[1]).Real()))
		}},
		"strptime": {2, func(a []Value) Value {
			t, ok := gpStrptime(strArg(a[0], "strptime"), strArg(a[1], "strptime"))
			if !ok {
				undef()
			}
			return FltV(t)
		}},
		"time": {1, func(a []Value) Value {
			now := time.Now()
			if a[0].T == STR {
				return StrV(gpStrftime(a[0].S, float64(now.Unix())))
			}
			if a[0].T == INT {
				return IntV(now.Unix())
			}
			return FltV(float64(now.UnixNano()) / 1e9)
		}},
		"system": {1, func(a []Value) Value {
			out, _ := exec.Command("/bin/sh", "-c", strArg(a[0], "system")).Output()
			s := string(out)
			s = strings.TrimSuffix(s, "\n")
			return StrV(s)
		}},
		"exists": {1, func(a []Value) Value {
			n := strArg(a[0], "exists")
			v, ok := gvars[n]
			return BoolV(ok && v.T != UNDEF)
		}},
		"value": {1, func(a []Value) Value {
			n := strArg(a[0], "value")
			v, ok := gvars[n]
			if !ok {
				return Value{}
			}
			return *v
		}},
		"column":       {1, func(a []Value) Value { return columnFunc(a[0]) }},
		"stringcolumn": {1, func(a []Value) Value { return stringColumn(a[0]) }},
		"strcol":       {1, func(a []Value) Value { return stringColumn(a[0]) }},
		"columnhead":   {1, func(a []Value) Value { return columnHead(a[0]) }},
		"timecolumn": {-1, func(a []Value) Value { return timeColumn(a) }},
		"valid":        {1, func(a []Value) Value { return validColumn(a[0]) }},
		"tm_sec":  tmFn(func(t time.Time) int64 { return int64(t.Second()) }),
		"tm_min":  tmFn(func(t time.Time) int64 { return int64(t.Minute()) }),
		"tm_hour": tmFn(func(t time.Time) int64 { return int64(t.Hour()) }),
		"tm_mday": tmFn(func(t time.Time) int64 { return int64(t.Day()) }),
		"tm_mon":  tmFn(func(t time.Time) int64 { return int64(t.Month()) - 1 }),
		"tm_year": tmFn(func(t time.Time) int64 { return int64(t.Year()) }),
		"tm_wday": tmFn(func(t time.Time) int64 { return int64(t.Weekday()) }),
		"tm_yday": tmFn(func(t time.Time) int64 { return int64(t.YearDay()) - 1 }),
		"hsv2rgb": {3, func(a []Value) Value {
			return IntV(hsv2rgb(numify(a[0]).Real(), numify(a[1]).Real(), numify(a[2]).Real()))
		}},
		"voigt": {2, func(a []Value) Value { return FltV(voigt(numify(a[0]).Real(), numify(a[1]).Real())) }},
	}
}

func tmFn(f func(time.Time) int64) Builtin {
	return Builtin{1, func(a []Value) Value {
		x := numify(a[0]).Real()
		sec := math.Floor(x)
		t := time.Unix(int64(sec), 0).UTC()
		return IntV(f(t))
	}}
}

func hsv2rgb(h, s, v float64) int64 {
	if h < 0 {
		h = 0
	}
	if h > 1 {
		h = 1
	}
	var r, g, b float64
	if s == 0 {
		r, g, b = v, v, v
	} else {
		hh := h * 6
		if hh >= 6 {
			hh = 0
		}
		i := math.Floor(hh)
		f := hh - i
		p := v * (1 - s)
		q := v * (1 - s*f)
		t := v * (1 - s*(1-f))
		switch int(i) {
		case 0:
			r, g, b = v, t, p
		case 1:
			r, g, b = q, v, p
		case 2:
			r, g, b = p, v, t
		case 3:
			r, g, b = p, q, v
		case 4:
			r, g, b = t, p, v
		default:
			r, g, b = v, p, q
		}
	}
	return int64(r*255+0.5)<<16 | int64(g*255+0.5)<<8 | int64(b*255+0.5)
}

// random generator: L'Ecuyer combined
var rs1, rs2 int64 = 12345, 67890

func gpRand(seed int64) float64 {
	if seed < 0 {
		rs1, rs2 = 12345, 67890
		return 0
	}
	if seed > 0 {
		rs1 = seed
		rs2 = seed
		return 0
	}
	k := rs1 / 53668
	rs1 = 40014*(rs1-k*53668) - k*12211
	if rs1 < 0 {
		rs1 += 2147483563
	}
	k = rs2 / 52774
	rs2 = 40692*(rs2-k*52774) - k*3791
	if rs2 < 0 {
		rs2 += 2147483399
	}
	z := rs1 - rs2
	if z < 1 {
		z += 2147483562
	}
	return float64(z) * 4.656613057391769e-10
}

func besselI(n int, x float64) float64 {
	if n < 0 {
		n = -n
	}
	sum := 0.0
	term := math.Pow(x/2, float64(n)) / math.Gamma(float64(n)+1)
	for k := 0; k < 500; k++ {
		sum += term
		term *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		if x == 0 {
			return 0
		}
		undef()
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		sum := 1.0 / a
		del := sum
		ap := a
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x < 0 || x > 1 || a <= 0 || b <= 0 {
		undef()
	}
	if x == 0 || x == 1 {
		return x
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		undef()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1e-300)
		if w < 0 {
			w = 0.5
		}
	} else if x > -0.3 {
		w = x
	} else {
		w = -1 + math.Sqrt(2*(1+math.E*x))
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func expint(n int, x float64) float64 {
	if n < 0 || x < 0 || (x == 0 && (n == 0 || n == 1)) {
		undef()
	}
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x == 0 {
		return 1 / float64(n-1)
	}
	nm1 := n - 1
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 1000; i++ {
			an := -float64(i) * float64(nm1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 1000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

func ellipK(k float64) float64 {
	if k <= -1 || k >= 1 {
		undef()
	}
	a, b := 1.0, math.Sqrt(1-k*k)
	for i := 0; i < 100 && math.Abs(a-b) > 1e-16*a; i++ {
		a, b = (a+b)/2, math.Sqrt(a*b)
	}
	return math.Pi / (2 * a)
}

func ellipE(k float64) float64 {
	if k < -1 || k > 1 {
		undef()
	}
	if k == 1 || k == -1 {
		return 1
	}
	a, b := 1.0, math.Sqrt(1-k*k)
	sum := k * k / 2
	pw := 0.5
	for i := 0; i < 100 && math.Abs(a-b) > 1e-16*a; i++ {
		c := (a - b) / 2
		a, b = (a+b)/2, math.Sqrt(a*b)
		pw *= 2
		sum += pw * c * c
	}
	return math.Pi / (2 * a) * (1 - sum)
}

func voigt(x, y float64) float64 {
	// numerical integration fallback
	if y <= 0 {
		return math.Exp(-x*x) / math.Sqrt(math.Pi)
	}
	n := 4000
	sum := 0.0
	L := 40.0
	h := 2 * L / float64(n)
	for i := 0; i <= n; i++ {
		t := -L + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		sum += w * math.Exp(-t*t) / (y*y + (x-t)*(x-t))
	}
	return y / (math.Pi * math.Sqrt(math.Pi)) * sum * h
}
