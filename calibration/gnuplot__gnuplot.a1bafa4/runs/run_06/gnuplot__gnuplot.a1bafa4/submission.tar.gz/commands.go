package main

import (
	"bufio"
	"os"
	"os/exec"
	"strings"
)

var datablocks = map[string][]string{}

type breakSig struct{}
type continueSig struct{}

var skipEndCheck bool

// print destination
var printFile *os.File
var printW *bufio.Writer
var printToStdout bool
var printDB string
var printDBAppendBuf strings.Builder
var printFileName string

func printOut(s string) {
	if printDB != "" {
		printDBAppendBuf.WriteString(s)
		// lines are committed on newline
		buf := printDBAppendBuf.String()
		for {
			i := strings.IndexByte(buf, '\n')
			if i < 0 {
				break
			}
			datablocks[printDB] = append(datablocks[printDB], buf[:i])
			buf = buf[i+1:]
		}
		printDBAppendBuf.Reset()
		printDBAppendBuf.WriteString(buf)
		return
	}
	if printW != nil {
		printW.WriteString(s)
		return
	}
	if printToStdout {
		stdout.WriteString(s)
		return
	}
	stderr.WriteString(s)
}

func flushPrint() {
	if printW != nil {
		printW.Flush()
	}
}

func closePrintFile() {
	if printW != nil {
		printW.Flush()
		printFile.Close()
		printW = nil
		printFile = nil
	}
	printToStdout = false
	printDB = ""
}

func initState() {
	setVar("pi", FltV(3.14159265358979323846))
	setVar("I", CpxV(0, 1))
	setVar("NaN", FltV(nan()))
	setVar("GPVAL_TERM", StrV("unknown"))
	setVar("GPVAL_TERMOPTIONS", StrV(""))
	setVar("GPVAL_OUTPUT", StrV(""))
	setVar("GPVAL_ENCODING", StrV("utf8"))
	setVar("GPVAL_MINUS_SIGN", StrV("\u2212"))
	setVar("GPVAL_MICRO", StrV("\u00b5"))
	setVar("GPVAL_DEGREE_SIGN", StrV("\u00b0"))
	setVar("GPVAL_VERSION", FltV(5.4))
	setVar("GPVAL_PATCHLEVEL", StrV("9"))
	setVar("GPVAL_COMPILE_OPTIONS", StrV("    +READLINE  -LIBREADLINE  +HISTORY  \n    +OBJECTS  +STATS \n    -LIBGD  \n    -USE_CWDRC  +HIDDEN3D_QUADTREE  \n"))
	setVar("GPVAL_MULTIPLOT", IntV(0))
	setVar("GPVAL_PLOT", IntV(0))
	setVar("GPVAL_SPLOT", IntV(0))
	setVar("GPVAL_TERMINALS", StrV(" canvas cgm context domterm dumb dxf emf epslatex fig hpgl mf mp pcl5 pict2e postscript pslatex pstex pstricks svg texdraw tkcanvas unknown "))
	setVar("GPVAL_pi", FltV(3.14159265358979323846))
	setVar("GPVAL_NaN", FltV(nan()))
	setVar("GPVAL_SYSNAME", StrV("Linux"))
	setVar("GPVAL_MACHINE", StrV("x86_64"))
	setVar("GPVAL_BITS", IntV(64))
	setVar("GPVAL_ERRNO", IntV(0))
	setVar("GPVAL_ERRMSG", StrV(""))
	setVar("GPVAL_SYSTEM_ERRNO", IntV(0))
	setVar("GPVAL_SYSTEM_ERRMSG", StrV(""))
	setVar("GPVAL_PWD", StrV(getwd()))
	setVar("VoxelDistance", FltV(0))
	initSettings()
}

func getwd() string {
	d, _ := os.Getwd()
	return d
}

func execCommand(p *Parser) {
	t := p.cur()
	if t.K == TOP && t.S == "!" {
		// shell command
		cmd := strings.TrimSpace(p.line[t.End:])
		if i := strings.IndexByte(cmd, '\n'); i >= 0 {
			cmd = cmd[:i]
		}
		flushAll()
		c := exec.Command("/bin/sh", "-c", cmd)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
		p.c = len(p.toks)
		return
	}
	if t.K == TDOLLAR {
		n1 := p.at(1)
		if n1 != nil && n1.K == TOP && n1.S == "<<" {
			// inline datablock in -e: just skip
			p.c = len(p.toks)
			return
		}
		throwAt(t.Pos, "invalid command")
	}
	if t.K != TNAME {
		throwAt(t.Pos, "invalid command")
	}
	n1 := p.at(1)
	if n1 != nil && n1.K == TOP {
		switch n1.S {
		case "=":
			name := t.S
			p.c += 2
			st := p.pos()
			v := evalNode(p.parseExpr(), st)
			if v.T == ARR {
				// array assignment copies
				arr := append([]Value(nil), (*v.A)...)
				v = Value{T: ARR, A: &arr}
			}
			setVar(name, v)
			return
		case "+=", "-=", "*=", "/=", "%=":
			throwAt(n1.Pos, "invalid command")
		case "(":
			if isFuncDef(p) {
				defineFunc(p)
				return
			}
		case "[":
			if isArrayAssign(p) {
				arrayAssign(p)
				return
			}
		}
	}
	name := t.S
	cmd := matchCommand(name)
	switch cmd {
	case "print":
		p.c++
		cmdPrint(p, false)
	case "printerr":
		p.c++
		cmdPrint(p, true)
	case "echo":
		p.c++
	case "if":
		p.c++
		cmdIf(p)
	case "else":
		throwAt(t.Pos, "invalid command")
	case "do":
		p.c++
		cmdDo(p)
	case "while":
		p.c++
		cmdWhile(p)
	case "break":
		p.c++
		panic(breakSig{})
	case "continue":
		p.c++
		panic(continueSig{})
	case "load":
		p.c++
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if v.T != STR {
			throwAt(st, "expecting filename")
		}
		loadFile(v.S, nil, false)
	case "call":
		p.c++
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if v.T != STR {
			throwAt(st, "expecting filename")
		}
		var args []string
		for !p.endOfCmd() {
			t := p.cur()
			if t.K == TSTR {
				args = append(args, t.S)
				p.c++
			} else {
				st := p.pos()
				// numbers/expressions: use token text
				if t.K == TNUM || t.K == TNAME {
					if t.K == TNAME {
						if gv, ok := gvars[t.S]; ok && p.at(1) == nil || ok && p.at(1).K != TOP {
							args = append(args, gv.String())
							p.c++
							continue
						}
					}
					args = append(args, tokText(p, t))
					p.c++
				} else {
					v := evalNode(p.parsePrimary(), st)
					args = append(args, v.String())
				}
			}
		}
		loadFile(v.S, args, true)
	case "eval":
		p.c++
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if v.T != STR {
			throwAt(st, "expected string")
		}
		evalString(v.S)
	case "exit", "quit":
		p.c++
		code := 0
		if p.isName("status") {
			p.c++
			st := p.pos()
			code = int(toInt(evalNode(p.parseExpr(), st)))
		} else if p.isName("gnuplot") {
			p.c++
		} else if p.isName("error") {
			p.c++
			st := p.pos()
			v := evalNode(p.parseExpr(), st)
			throwNC(v.String())
		}
		panic(exitReq{code})
	case "undefine":
		p.c++
		for !p.endOfCmd() {
			t := p.cur()
			if t.K == TNAME {
				if strings.HasSuffix(t.S, "") {
					n := t.S
					if p.at(1) != nil && p.at(1).K == TOP && p.at(1).S == "*" {
						for k := range gvars {
							if strings.HasPrefix(k, n) && !strings.HasPrefix(k, "GPVAL_") {
								delVar(k)
							}
						}
						p.c += 2
						continue
					}
					delVar(n)
				}
			} else if t.K == TDOLLAR {
				delete(datablocks, t.S)
			}
			p.c++
		}
	case "array":
		p.c++
		cmdArray(p)
	case "pause":
		p.c++
		for !p.endOfCmd() {
			p.c++
		}
	case "reset":
		p.c++
		if p.isName("session") {
			p.c++
			for k := range gvars {
				if !strings.HasPrefix(k, "GPVAL_") {
					delVar(k)
				}
			}
			ufuncs = map[string]*UserFunc{}
			setVar("pi", FltV(3.14159265358979323846))
			setVar("NaN", FltV(nan()))
		} else if p.isName("errors") {
			p.c++
			setVar("GPVAL_ERRNO", IntV(0))
			setVar("GPVAL_ERRMSG", StrV(""))
			return
		}
		resetSettings()
	case "clear", "refresh", "replot", "test", "history", "bind", "raise", "lower", "cd", "pwd", "help", "update", "system", "vclear", "vfill", "shell":
		p.c++
		handleMisc(p, cmd)
	case "set":
		p.c++
		cmdSet(p)
	case "unset":
		p.c++
		cmdUnset(p)
	case "show":
		p.c++
		cmdShow(p)
	case "plot":
		p.c++
		cmdPlot(p, false)
	case "splot":
		p.c++
		cmdPlot(p, true)
	case "fit":
		p.c++
		cmdFit(p)
	case "stats":
		p.c++
		cmdStats(p)
	default:
		throwAt(t.Pos, "invalid command")
	}
}

var cmdNames = []struct{ full, min string }{
	{"print", "pr"}, {"printerr", "printerr"}, {"plot", "p"}, {"splot", "sp"}, {"set", "se"}, {"show", "sh"}, {"unset", "uns"},
	{"if", "if"}, {"else", "else"}, {"do", "do"}, {"while", "while"}, {"load", "l"}, {"call", "ca"}, {"eval", "eval"},
	{"exit", "ex"}, {"quit", "q"}, {"undefine", "undef"}, {"array", "array"}, {"pause", "pa"}, {"reset", "re"},
	{"clear", "cle"}, {"refresh", "refresh"}, {"replot", "rep"}, {"test", "test"}, {"history", "hi"}, {"bind", "bind"},
	{"raise", "raise"}, {"lower", "lower"}, {"cd", "cd"}, {"pwd", "pwd"}, {"help", "h"}, {"update", "up"}, {"system", "sy"},
	{"fit", "fit"}, {"stats", "stats"}, {"break", "break"}, {"continue", "continue"}, {"echo", "echo"}, {"vclear", "vclear"}, {"vfill", "vfill"}, {"shell", "she"},
}

func matchCommand(s string) string {
	for _, c := range cmdNames {
		if s == c.full {
			return c.full
		}
	}
	for _, c := range cmdNames {
		if len(s) >= len(c.min) && strings.HasPrefix(c.full, s) {
			return c.full
		}
	}
	return ""
}

func evalString(s string) {
	saved := *ctx
	l := expandMacros(s)
	toks := lexLine(l)
	// errors inside eval refer to eval'd text
	ctx.line = l
	ctx.echoText = ""
	ctx.echoOff = 0
	execTokens(toks)
	*ctx = saved
}

func cmdPrint(p *Parser, toErr bool) {
	if p.endOfCmd() {
		throwAt(p.pos(), "constant expression required")
	}
	var out func(string)
	if toErr {
		out = func(s string) { stderr.WriteString(s) }
	} else {
		out = printOut
	}
	first := true
	for {
		st := p.pos()
		var v Value
		if t := p.cur(); t != nil && t.K == TDOLLAR && !(len(t.S) > 1 && isDigit(t.S[1])) && !isOpAt(p, 1, "[") {
			// datablock print
			if db, ok := datablocks[t.S]; ok {
				p.c++
				if !first {
					out(" ")
				}
				for _, l := range db {
					out(l + "\n")
				}
				first = false
				if p.isOp(",") {
					p.c++
					continue
				}
				break
			}
		}
		if !first {
			out(" ")
		}
		n := p.parseExpr()
		v = evalNode(n, st)
		first = false
		if v.T == ARR {
			out(v.String() + "\n")
		} else {
			out(v.String())
		}
		if p.isOp(",") {
			p.c++
			continue
		}
		break
	}
	out("\n")
}

func isOpAt(p *Parser, i int, s string) bool {
	t := p.at(i)
	return t != nil && t.K == TOP && t.S == s
}

func isFuncDef(p *Parser) bool {
	// name ( name [, name]* ) =
	i := 2
	for {
		t := p.at(i)
		if t == nil || t.K != TNAME {
			return false
		}
		i++
		t = p.at(i)
		if t == nil || t.K != TOP {
			return false
		}
		if t.S == ")" {
			t2 := p.at(i + 1)
			return t2 != nil && t2.K == TOP && t2.S == "="
		}
		if t.S != "," {
			return false
		}
		i++
	}
}

func defineFunc(p *Parser) {
	name := p.cur().S
	p.c += 2
	var params []string
	for {
		params = append(params, p.cur().S)
		p.c++
		if p.isOp(")") {
			p.c++
			break
		}
		p.c++
	}
	p.c++ // '='
	st := p.pos()
	old, had := ufuncs[name]
	uf := &UserFunc{name: name, params: params}
	ufuncs[name] = uf
	if !had {
		funcOrder = append(funcOrder, name)
	}
	sub := &Parser{toks: p.toks, c: p.c, params: params, line: p.line}
	func() {
		defer func() {
			if r := recover(); r != nil {
				if had {
					ufuncs[name] = old
				} else {
					delete(ufuncs, name)
				}
				panic(r)
			}
		}()
		uf.body = sub.parseExpr()
	}()
	end := sub.c
	endPos := len(p.line)
	if end < len(p.toks) {
		endPos = p.toks[end].Pos
	}
	uf.text = name + "(" + strings.Join(params, ",") + ")=" + strings.TrimSpace(p.line[st:endPos])
	p.c = end
	_ = st
}

func isArrayAssign(p *Parser) bool {
	// name [ ... ] =
	depth := 0
	for i := 1; ; i++ {
		t := p.at(i)
		if t == nil || t.K == TNL || (t.K == TOP && t.S == ";") {
			return false
		}
		if t.K == TOP && t.S == "[" {
			depth++
		}
		if t.K == TOP && t.S == "]" {
			depth--
			if depth == 0 {
				t2 := p.at(i + 1)
				return t2 != nil && t2.K == TOP && t2.S == "="
			}
		}
	}
}

func arrayAssign(p *Parser) {
	name := p.cur().S
	p.c += 2
	st := p.pos()
	idx := evalNode(p.parseExpr(), st)
	p.expectOp("]", "missing ']'")
	p.c++ // =
	st2 := p.pos()
	v := evalNode(p.parseExpr(), st2)
	av, ok := gvars[name]
	if !ok || av.T != ARR {
		throwNC("undefined array " + name)
		_ = av
	}
	i := toInt(idx)
	arr := *av.A
	if i < 1 || int(i) > len(arr) {
		throwNC("array index out of range")
	}
	arr[i-1] = v
}

func cmdArray(p *Parser) {
	t := p.cur()
	if t == nil || t.K != TNAME {
		throwAt(p.pos(), "illegal array name")
	}
	name := t.S
	p.c++
	size := -1
	if p.isOp("[") {
		p.c++
		st := p.pos()
		size = int(toInt(evalNode(p.parseExpr(), st)))
		p.expectOp("]", "missing ']'")
	}
	var init []Value
	if p.isOp("=") {
		p.c++
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if v.T != ARR {
			throwAt(st, "invalid array initializer")
		}
		init = *v.A
		if size < 0 {
			size = len(init)
		}
	}
	if size < 0 {
		throwAt(p.pos(), "expecting array[size]")
	}
	arr := make([]Value, size)
	for i := range arr {
		if i < len(init) {
			arr[i] = init[i]
		}
	}
	setVar(name, Value{T: ARR, A: &arr})
}

// findBlock: p at '{'; returns index range of body and positions
func findBlock(p *Parser) (int, int) {
	if !p.isOp("{") {
		throwAt(p.pos(), "expecting '{'")
	}
	st := p.c + 1
	depth := 0
	for i := p.c; i < len(p.toks); i++ {
		t := p.toks[i]
		if t.K == TOP && t.S == "{" {
			depth++
		} else if t.K == TOP && t.S == "}" {
			depth--
			if depth == 0 {
				p.c = i + 1
				return st, i
			}
		}
	}
	throwAt(p.pos(), "unmatched '{'")
	return 0, 0
}

func execBlock(p *Parser, a, b int) {
	savedEchoT, savedEchoO := ctx.echoText, ctx.echoOff
	if !ctx.multi {
		// echo text is the body
		startPos := p.toks[a-1].End
		endPos := p.toks[b].Pos
		body := p.line[startPos:endPos]
		trimmed := strings.TrimLeft(body, " \t")
		ctx.echoOff = startPos + (len(body) - len(trimmed))
		ctx.echoText = trimmed
	}
	sub := &Parser{toks: p.toks[a:b], line: p.line}
	execSub(sub)
	ctx.echoText, ctx.echoOff = savedEchoT, savedEchoO
}

func execSub(p *Parser) {
	for {
		for p.c < len(p.toks) && (p.toks[p.c].K == TNL || (p.toks[p.c].K == TOP && p.toks[p.c].S == ";")) {
			p.c++
		}
		if p.c >= len(p.toks) {
			return
		}
		ctx.curTokLine = lineOfPos(p.toks[p.c].Pos)
		execCommand(p)
		if skipEndCheck {
			skipEndCheck = false
			continue
		}
		if !p.endOfCmd() {
			t := p.cur()
			throwAt(t.Pos, "unexpected or unrecognized token: "+tokText(p, t))
		}
	}
}

func parseCond(p *Parser) bool {
	if !p.isOp("(") {
		throwAt(p.pos(), "expecting '('")
	}
	st := p.pos()
	p.c++
	n := p.parseCommaExpr()
	p.expectOp(")", "expecting ')'")
	v := evalNode(n, st)
	return truth(v)
}

func cmdIf(p *Parser) {
	cond := parseCond(p)
	if !p.isOp("{") {
		// old style
		if !cond {
			for p.c < len(p.toks) && p.toks[p.c].K != TNL {
				p.c++
			}
		} else {
			skipEndCheck = true
			execRestAsCommands(p)
		}
		return
	}
	done := false
	for {
		a, b := findBlock(p)
		if cond && !done {
			execBlock(p, a, b)
			done = true
		}
		// skip newlines? else must be on same chunk
		if p.isName("else") {
			p.c++
			if !p.isOp("{") {
				throwAt(p.pos(), "expected {else-clause}")
			}
			if p.isName("if") {
				p.c++
				if done {
					// skip condition parse without evaluation
					skipParen(p)
					cond = false
				} else {
					cond = parseCond(p)
				}
				continue
			}
			a, b := findBlock(p)
			if !done {
				execBlock(p, a, b)
			}
		}
		return
	}
}

func execRestAsCommands(p *Parser) {
	// continue executing in same parser
}

func skipParen(p *Parser) {
	depth := 0
	for p.c < len(p.toks) {
		t := p.toks[p.c]
		p.c++
		if t.K == TOP && t.S == "(" {
			depth++
		} else if t.K == TOP && t.S == ")" {
			depth--
			if depth == 0 {
				return
			}
		}
	}
}

type iterSpec struct {
	varName string
	isIn    bool
	words   []string
	start   int64
	end     int64
	step    int64
	endless bool
}

// parseIter parses [var = a:b:c] or [var in "string"]
func parseIter(p *Parser) iterSpec {
	p.expectOp("[", "expecting '['")
	t := p.cur()
	if t == nil || t.K != TNAME {
		throwAt(p.pos(), "expecting iteration variable")
	}
	var it iterSpec
	it.varName = t.S
	p.c++
	if p.isName("in") {
		p.c++
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if v.T == ARR {
			for _, e := range *v.A {
				it.words = append(it.words, e.String())
			}
		} else {
			it.words = strings.Fields(v.S)
		}
		it.isIn = true
		p.expectOp("]", "expecting ']'")
		return it
	}
	p.expectOp("=", "expecting '='")
	st := p.pos()
	it.start = toInt(evalNode(p.parseExpr(), st))
	p.expectOp(":", "expecting ':'")
	if p.isOp("*") {
		p.c++
		it.endless = true
	} else {
		st = p.pos()
		it.end = toInt(evalNode(p.parseExpr(), st))
	}
	it.step = 1
	if p.isOp(":") {
		p.c++
		st = p.pos()
		it.step = toInt(evalNode(p.parseExpr(), st))
	}
	p.expectOp("]", "expecting ']'")
	return it
}

func (it iterSpec) each(f func()) {
	saved, had := gvars[it.varName]
	defer func() {
		if had {
			gvars[it.varName] = saved
		} else {
			delVar(it.varName)
		}
	}()
	if it.isIn {
		for _, w := range it.words {
			setVar(it.varName, StrV(w))
			if !runBody(f) {
				break
			}
		}
		return
	}
	if it.step == 0 {
		throwNC("iteration step cannot be 0")
	}
	for i := it.start; it.endless || (it.step > 0 && i <= it.end) || (it.step < 0 && i >= it.end); i += it.step {
		setVar(it.varName, IntV(i))
		if !runBody(f) {
			break
		}
	}
}

// runBody returns false on break
func runBody(f func()) (cont bool) {
	cont = true
	defer func() {
		if r := recover(); r != nil {
			switch r.(type) {
			case breakSig:
				cont = false
			case continueSig:
				cont = true
			default:
				panic(r)
			}
		}
	}()
	f()
	return
}

func cmdDo(p *Parser) {
	if !p.isName("for") {
		throwAt(p.pos(), "expecting 'for'")
	}
	p.c++
	var iters []iterSpec
	for p.isOp("[") {
		iters = append(iters, parseIter(p))
		if p.isName("for") {
			p.c++
		}
	}
	a, b := findBlock(p)
	var run func(k int)
	run = func(k int) {
		if k == len(iters) {
			execBlock(p, a, b)
			return
		}
		iters[k].each(func() { run(k + 1) })
	}
	run(0)
}

func cmdWhile(p *Parser) {
	condStart := p.c
	for {
		p.c = condStart
		cond := parseCond(p)
		a, b := findBlock(p)
		if !cond {
			return
		}
		if !runBody(func() { execBlock(p, a, b) }) {
			p.c = condStart
			parseCondSkip(p)
			findBlock(p)
			return
		}
	}
}

func parseCondSkip(p *Parser) {
	skipParen(p)
}

func handleMisc(p *Parser, cmd string) {
	switch cmd {
	case "cd":
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		if os.Chdir(v.S) != nil {
			throwAt(st, "Can't change to this directory")
		}
		setVar("GPVAL_PWD", StrV(getwd()))
		return
	case "pwd":
		printOut("")
		stderr.WriteString(getwd() + "\n")
		return
	case "system":
		st := p.pos()
		v := evalNode(p.parseExpr(), st)
		flushAll()
		c := exec.Command("/bin/sh", "-c", v.S)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
		return
	case "replot":
		cmdReplot(p)
		return
	case "clear":
		cmdClear()
		return
	case "update":
		cmdUpdate(p)
		return
	}
	for !p.endOfCmd() {
		p.c++
	}
}
