module gp

go 1.21
