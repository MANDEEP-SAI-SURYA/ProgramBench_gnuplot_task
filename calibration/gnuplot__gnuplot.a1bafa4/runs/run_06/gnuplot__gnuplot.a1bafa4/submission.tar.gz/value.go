package main

import (
	"math"
	"strconv"
	"strings"
)

const (
	UNDEF = iota
	INT
	CMPLX
	STR
	ARR
)

type Value struct {
	T  int
	I  int64
	R  float64
	Im float64
	S  string
	A  *[]Value
}

func IntV(i int64) Value       { return Value{T: INT, I: i} }
func FltV(f float64) Value     { return Value{T: CMPLX, R: f} }
func CpxV(r, i float64) Value  { return Value{T: CMPLX, R: r, Im: i} }
func StrV(s string) Value      { return Value{T: STR, S: s} }
func BoolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

// fmtNum formats a float like gnuplot's print: %.15g, append .0 if integral-looking
func fmtG(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	if math.IsInf(f, 1) {
		return "inf.0"
	}
	if math.IsInf(f, -1) {
		return "-inf.0"
	}
	s := cfmt("%.15g", f)
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

func (v Value) String() string {
	switch v.T {
	case INT:
		return strconv.FormatInt(v.I, 10)
	case CMPLX:
		if v.Im == 0 {
			return fmtG(v.R)
		}
		return "{" + fmtG(v.R) + ", " + fmtG(v.Im) + "}"
	case STR:
		return v.S
	case ARR:
		var b strings.Builder
		b.WriteString("[")
		arr := *v.A
		for i, e := range arr {
			if i > 0 {
				b.WriteString(",")
			}
			switch e.T {
			case STR:
				b.WriteString("\"" + e.S + "\"")
			case UNDEF:
			default:
				b.WriteString(e.String())
			}
		}
		b.WriteString("]")
		return b.String()
	}
	return ""
}

func (v Value) Real() float64 {
	switch v.T {
	case INT:
		return float64(v.I)
	case CMPLX:
		return v.R
	case STR:
		return strToNum(v.S).Real()
	}
	return 0
}

func (v Value) isNum() bool { return v.T == INT || v.T == CMPLX }

// convert string to numeric value like gnuplot does when string used in numeric context
func strToNum(s string) Value {
	t := strings.TrimLeft(s, " \t")
	n := numPrefix(t)
	if n == 0 {
		throwNC("Non-numeric string found where a numeric expression was expected")
	}
	rest := strings.TrimSpace(t[n:])
	if rest != "" {
		warn("Trailing characters after numeric expression")
	}
	if iv, err := strconv.ParseInt(t[:n], 10, 64); err == nil {
		return IntV(iv)
	}
	f, _ := strconv.ParseFloat(t[:n], 64)
	return FltV(f)
}

// length of numeric prefix (strtod-like)
func numPrefix(t string) int {
	i := 0
	if i < len(t) && (t[i] == '+' || t[i] == '-') {
		i++
	}
	st := i
	low := strings.ToLower(t[i:])
	if strings.HasPrefix(low, "inf") {
		return i + 3
	}
	if strings.HasPrefix(low, "nan") {
		return i + 3
	}
	dig := false
	for i < len(t) && t[i] >= '0' && t[i] <= '9' {
		i++
		dig = true
	}
	if i < len(t) && t[i] == '.' {
		i++
		for i < len(t) && t[i] >= '0' && t[i] <= '9' {
			i++
			dig = true
		}
	}
	if !dig {
		_ = st
		return 0
	}
	if i < len(t) && (t[i] == 'e' || t[i] == 'E') {
		j := i + 1
		if j < len(t) && (t[j] == '+' || t[j] == '-') {
			j++
		}
		if j < len(t) && t[j] >= '0' && t[j] <= '9' {
			for j < len(t) && t[j] >= '0' && t[j] <= '9' {
				j++
			}
			i = j
		}
	}
	return i
}
