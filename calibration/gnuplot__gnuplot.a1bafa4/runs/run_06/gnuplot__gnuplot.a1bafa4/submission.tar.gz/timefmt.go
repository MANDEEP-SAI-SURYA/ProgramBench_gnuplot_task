package main

import (
	"math"
	"strconv"
	"strings"
	"time"
)

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, t float64) string {
	sec := math.Floor(t)
	frac := t - sec
	tm := time.Unix(int64(sec), 0).UTC()
	var b strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			b.WriteByte(c)
			continue
		}
		i++
		// optional width/precision for %S etc.
		prec := -1
		pad := ""
		for i < len(f) && (f[i] == '0' || f[i] == '-' ) {
			pad += string(f[i])
			i++
		}
		width := ""
		for i < len(f) && isDigit(f[i]) {
			width += string(f[i])
			i++
		}
		if i < len(f) && f[i] == '.' {
			i++
			ps := ""
			for i < len(f) && isDigit(f[i]) {
				ps += string(f[i])
				i++
			}
			prec, _ = strconv.Atoi(ps)
		}
		if i >= len(f) {
			break
		}
		two := func(n int) string {
			s := strconv.Itoa(n)
			if len(s) < 2 {
				s = "0" + s
			}
			return s
		}
		switch f[i] {
		case 'Y':
			b.WriteString(strconv.Itoa(tm.Year()))
		case 'y':
			b.WriteString(two(tm.Year() % 100))
		case 'm':
			b.WriteString(two(int(tm.Month())))
		case 'd':
			b.WriteString(two(tm.Day()))
		case 'e':
			s := strconv.Itoa(tm.Day())
			if len(s) < 2 {
				s = " " + s
			}
			b.WriteString(s)
		case 'H':
			b.WriteString(two(tm.Hour()))
		case 'k':
			s := strconv.Itoa(tm.Hour())
			if len(s) < 2 {
				s = " " + s
			}
			b.WriteString(s)
		case 'I':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			b.WriteString(two(h))
		case 'l':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			s := strconv.Itoa(h)
			if len(s) < 2 {
				s = " " + s
			}
			b.WriteString(s)
		case 'M':
			b.WriteString(two(tm.Minute()))
		case 'S':
			b.WriteString(two(tm.Second()))
			if prec > 0 {
				fs := strconv.FormatFloat(frac, 'f', prec, 64)
				b.WriteString(fs[1:])
			}
		case 's':
			b.WriteString(strconv.FormatInt(int64(sec), 10))
		case 'j':
			s := strconv.Itoa(tm.YearDay())
			for len(s) < 3 {
				s = "0" + s
			}
			b.WriteString(s)
		case 'b', 'h':
			b.WriteString(monNames[tm.Month()-1][:3])
		case 'B':
			b.WriteString(monNames[tm.Month()-1])
		case 'a':
			b.WriteString(dayNames[tm.Weekday()][:3])
		case 'A':
			b.WriteString(dayNames[tm.Weekday()])
		case 'p':
			if tm.Hour() < 12 {
				b.WriteString("AM")
			} else {
				b.WriteString("PM")
			}
		case 'P':
			if tm.Hour() < 12 {
				b.WriteString("am")
			} else {
				b.WriteString("pm")
			}
		case 'D':
			b.WriteString(two(int(tm.Month())) + "/" + two(tm.Day()) + "/" + two(tm.Year()%100))
		case 'F':
			b.WriteString(strconv.Itoa(tm.Year()) + "-" + two(int(tm.Month())) + "-" + two(tm.Day()))
		case 'T':
			b.WriteString(two(tm.Hour()) + ":" + two(tm.Minute()) + ":" + two(tm.Second()))
		case 'R':
			b.WriteString(two(tm.Hour()) + ":" + two(tm.Minute()))
		case 'r':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			ap := "AM"
			if tm.Hour() >= 12 {
				ap = "PM"
			}
			b.WriteString(two(h) + ":" + two(tm.Minute()) + ":" + two(tm.Second()) + " " + ap)
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case '%':
			b.WriteByte('%')
		case 'U':
			b.WriteString(two((tm.YearDay() + 6 - int(tm.Weekday())) / 7))
		case 'w':
			b.WriteString(strconv.Itoa(int(tm.Weekday())))
		default:
			b.WriteByte('%')
			b.WriteByte(f[i])
		}
	}
	return b.String()
}

// gpStrptime parses s according to f, returning seconds since epoch
func gpStrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	secf := 0.0
	yday := -1
	pm := -1
	j := 0
	epoch := false
	var epochv float64
	readInt := func(maxd int) (int, bool) {
		for j < len(s) && s[j] == ' ' {
			j++
		}
		st := j
		neg := false
		if j < len(s) && (s[j] == '-' || s[j] == '+') {
			neg = s[j] == '-'
			j++
		}
		ds := j
		for j < len(s) && isDigit(s[j]) && j-ds < maxd {
			j++
		}
		if j == ds {
			j = st
			return 0, false
		}
		v, _ := strconv.Atoi(s[ds:j])
		if neg {
			v = -v
		}
		return v, true
	}
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c == ' ' {
			for j < len(s) && s[j] == ' ' {
				j++
			}
			continue
		}
		if c != '%' || i+1 >= len(f) {
			if j < len(s) && s[j] == c {
				j++
			} else {
				return 0, false
			}
			continue
		}
		i++
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			year, ok = readInt(2)
			if year < 69 {
				year += 2000
			} else {
				year += 1900
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			for j < len(s) && s[j] == ' ' {
				j++
			}
			n := numPrefix(s[j:])
			if n == 0 {
				return 0, false
			}
			secf, _ = strconv.ParseFloat(s[j:j+n], 64)
			j += n
			ok = true
		case 's':
			n := numPrefix(s[j:])
			if n == 0 {
				return 0, false
			}
			epochv, _ = strconv.ParseFloat(s[j:j+n], 64)
			j += n
			epoch = true
			ok = true
		case 'b', 'h', 'B':
			ok = false
			for mi, mn := range monNames {
				if len(s)-j >= 3 && strings.EqualFold(s[j:j+3], mn[:3]) {
					mon = mi + 1
					j += 3
					if f[i] == 'B' && len(s)-j >= len(mn)-3 && strings.EqualFold(s[j:j+len(mn)-3], mn[3:]) {
						j += len(mn) - 3
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			for _, dn := range dayNames {
				if len(s)-j >= 3 && strings.EqualFold(s[j:j+3], dn[:3]) {
					j += 3
					if f[i] == 'A' && len(s)-j >= len(dn)-3 && strings.EqualFold(s[j:j+len(dn)-3], dn[3:]) {
						j += len(dn) - 3
					}
					ok = true
					break
				}
			}
		case 'p':
			if len(s)-j >= 2 {
				u := strings.ToUpper(s[j : j+2])
				if u == "AM" {
					pm = 0
				} else if u == "PM" {
					pm = 1
				}
				j += 2
			}
			ok = true
		case '%':
			ok = j < len(s) && s[j] == '%'
			j++
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if epoch {
		return epochv, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + secf, true
}

func nan() float64 { return math.NaN() }
