package main

import (
	"bufio"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

const (
	PT_IN = 'i'
	PT_OUT = 'o'
	PT_UNDEF = 'u'
	PT_BREAK = 'b'
)

type Pt struct {
	x, y, z float64
	ex      []float64 // extra columns (ylow,yhigh etc)
	label   string
	typ     byte
}

type Curve struct {
	title     string
	hasTitle  bool
	style     string
	pts       []Pt
	isFunc    bool
	is3d      bool
	smooth    string
	lt        int
	pt        int
	ptChar    string
	axes      string
	blocks    [][]Pt // for splot surfaces / isocurves
	isoCurves [][][]Pt
	fillTo    string
	ncols     int
}

type PlotElem struct {
	isFunc    bool
	fn        Node
	fnText    string
	src       string // file name or $db
	srcKind   int    // 0 file, 1 datablock, 2 '+', 3 '++', 4 '-'
	using     []UsingCol
	usingSet  bool
	index     [3]int
	indexSet  bool
	every     [6]int
	everySet  bool
	smooth    string
	title     string
	titleSet  bool
	notitle   bool
	titleCol  bool
	style     string
	defText   string
	lt        int
	pt        int
	ltSet     bool
	sampRange *[2]float64
	sampVar   string
	axes      string
	fillTo    string
	pointsChar string
	labelCol   int
}

type UsingCol struct {
	col  int
	expr Node
	str  string
	isStr bool
	isExpr bool
}

// data reading context
var curFields []string
var curRecIdx, curSegIdx, curBlockIdx int
var curHeader []string
var colInvalid bool

func columnValue(col int) Value {
	if col == 0 {
		return FltV(float64(curRecIdx))
	}
	if col == -1 {
		return FltV(float64(curSegIdx))
	}
	if col == -2 {
		return FltV(float64(curBlockIdx))
	}
	if col < 0 || col > len(curFields) {
		colInvalid = true
		return FltV(math.NaN())
	}
	f := curFields[col-1]
	v, ok := parseNumField(f)
	if !ok {
		return FltV(math.NaN())
	}
	return FltV(v)
}

func parseNumField(f string) (float64, bool) {
	if S.dfMissing != "" && f == S.dfMissing {
		return math.NaN(), false
	}
	t := f
	n := numPrefix(t)
	if n == 0 || n != len(t) {
		if n > 0 && n < len(t) && (t[n] == 'd' || t[n] == 'D' || t[n] == 'q' || t[n] == 'Q') {
			// fortran exponent
			x := t[:n] + "e" + t[n+1:]
			if v, err := strconv.ParseFloat(x, 64); err == nil {
				return v, true
			}
		}
		return 0, false
	}
	v, err := strconv.ParseFloat(t, 64)
	if err != nil {
		if strings.EqualFold(strings.TrimLeft(t, "+-"), "inf") {
			if t[0] == '-' {
				return math.Inf(-1), true
			}
			return math.Inf(1), true
		}
		if strings.EqualFold(strings.TrimLeft(t, "+-"), "nan") {
			return math.NaN(), true
		}
		return 0, false
	}
	return v, true
}

func columnFunc(a Value) Value {
	if a.T == STR {
		for i, h := range curHeader {
			if h == a.S {
				return columnValue(i + 1)
			}
		}
		colInvalid = true
		return FltV(math.NaN())
	}
	return columnValue(int(toInt(a)))
}

func stringColumn(a Value) Value {
	c := 0
	if a.T == STR {
		for i, h := range curHeader {
			if h == a.S {
				c = i + 1
			}
		}
	} else {
		c = int(toInt(a))
	}
	if c >= 1 && c <= len(curFields) {
		return StrV(curFields[c-1])
	}
	if c == 0 {
		return StrV(itoa(curRecIdx))
	}
	return StrV("")
}

func columnHead(a Value) Value {
	c := int(toInt(a))
	if c >= 1 && c <= len(curHeader) {
		return StrV(curHeader[c-1])
	}
	return StrV("")
}

func timeColumn(a []Value) Value {
	if len(a) == 0 {
		throwNC("not enough arguments")
	}
	c := int(toInt(a[0]))
	f := S.timefmt
	if len(a) > 1 {
		f = a[1].S
	}
	if c >= 1 && c <= len(curFields) {
		t, ok := gpStrptime(f, curFields[c-1])
		if ok {
			return FltV(t)
		}
	}
	return FltV(math.NaN())
}

func validColumn(a Value) Value {
	c := int(toInt(a))
	if c >= 1 && c <= len(curFields) {
		_, ok := parseNumField(curFields[c-1])
		return BoolV(ok)
	}
	return IntV(0)
}

// split a data line into fields
func splitFields(line string) []string {
	var out []string
	if S.dfSep != "" && S.dfSep != " " {
		// separator chars
		cur := strings.Builder{}
		inQ := false
		for i := 0; i < len(line); i++ {
			c := line[i]
			if c == '"' {
				inQ = !inQ
				continue
			}
			if !inQ && strings.IndexByte(S.dfSep, c) >= 0 {
				out = append(out, strings.TrimSpace(cur.String()))
				cur.Reset()
				continue
			}
			cur.WriteByte(c)
		}
		out = append(out, strings.TrimSpace(cur.String()))
		return out
	}
	i := 0
	n := len(line)
	for i < n {
		for i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
			i++
		}
		if i >= n {
			break
		}
		if line[i] == '"' {
			j := i + 1
			for j < n && line[j] != '"' {
				j++
			}
			out = append(out, line[i+1:j])
			i = j + 1
			continue
		}
		j := i
		for j < n && line[j] != ' ' && line[j] != '\t' && line[j] != '\r' {
			j++
		}
		out = append(out, line[i:j])
		i = j
	}
	return out
}

func isCommentLine(l string) bool {
	t := strings.TrimLeft(l, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(S.dfComments, t[0]) >= 0
}

func loadDataLines(e *PlotElem) []string {
	switch e.srcKind {
	case 1:
		d, ok := datablocks[e.src]
		if !ok {
			throwNC("undefined datablock " + e.src)
		}
		return d
	}
	f, err := os.Open(e.src)
	if err != nil {
		throwNC("Cannot find or open file \"" + e.src + "\"")
	}
	defer f.Close()
	return readLines(bufio.NewReader(f))
}

// Record represents one parsed data record
type Record struct {
	vals   []float64
	strs   []string
	ok     bool // all needed columns valid
	undef  bool // some expression undefined
	brk    bool // segment break marker
	label  string
}

// readData iterates over records applying index/every/using
func readData(e *PlotElem, ncols int, fn func(r Record)) {
	lines := loadDataLines(e)
	block := 0
	seg := 0
	rec := 0
	blank := 0
	pointInSeg := 0
	headerDone := false
	curHeader = nil
	prevWasData := false
	idxStart, idxEnd, idxStep := 0, math.MaxInt32, 1
	if e.indexSet {
		idxStart, idxEnd, idxStep = e.index[0], e.index[1], e.index[2]
	}
	inIndex := func(b int) bool {
		return b >= idxStart && b <= idxEnd && (b-idxStart)%idxStep == 0
	}
	evStep, blStep := 1, 1
	evStart, blStart := 0, 0
	evEnd, blEnd := math.MaxInt32, math.MaxInt32
	if e.everySet {
		evStep, blStep, evStart, blStart, evEnd, blEnd = e.every[0], e.every[1], e.every[2], e.every[3], e.every[4], e.every[5]
	}
	needHeader := S.dfHeader || e.titleCol
	for _, l := range lines {
		if isCommentLine(l) {
			continue
		}
		if strings.TrimSpace(l) == "" {
			blank++
			if blank == 1 && prevWasData {
				if inIndex(block) && seg >= blStart && seg <= blEnd && (seg-blStart)%blStep == 0 {
					fn(Record{brk: true})
				}
				seg++
				pointInSeg = 0
			}
			if blank == 2 && prevWasData {
				block++
				seg = 0
				rec = 0
				pointInSeg = 0
			}
			prevWasData = blank == 1 && prevWasData
			if blank >= 2 {
				prevWasData = false
			}
			continue
		}
		if blank >= 2 || (blank == 1 && !prevWasData) {
			// already handled
		}
		blank = 0
		prevWasData = true
		fields := splitFields(l)
		if needHeader && !headerDone {
			headerDone = true
			curHeader = fields
			continue
		}
		headerDone = true
		if !inIndex(block) {
			rec++
			continue
		}
		if block > idxEnd {
			break
		}
		curFields = fields
		curRecIdx = rec
		curSegIdx = seg
		curBlockIdx = block
		rec++
		pis := pointInSeg
		pointInSeg++
		if e.everySet {
			if seg < blStart || seg > blEnd || (seg-blStart)%blStep != 0 {
				continue
			}
			if pis < evStart || pis > evEnd || (pis-evStart)%evStep != 0 {
				continue
			}
		}
		r := evalRecord(e, ncols, fields)
		fn(r)
	}
	curFields = nil
}

func evalRecord(e *PlotElem, ncols int, fields []string) Record {
	r := Record{ok: true}
	if !e.usingSet {
		// all fields must be numeric
		var vals []float64
		for _, f := range fields {
			v, ok := parseNumField(f)
			if !ok {
				r.ok = false
				return r
			}
			vals = append(vals, v)
		}
		if len(vals) == 0 {
			r.ok = false
			return r
		}
		if len(vals) == 1 {
			r.vals = []float64{float64(curRecIdx), vals[0]}
		} else {
			r.vals = vals
		}
		if len(r.vals) < ncols {
			r.ok = false
		}
		return r
	}
	for ui, u := range e.using {
		if e.labelCol == ui+1 && !u.isExpr && u.col > 0 {
			if u.col <= len(fields) {
				r.strs = append(r.strs, fields[u.col-1])
				r.vals = append(r.vals, 0)
				continue
			}
		}
		if u.isStr {
			r.strs = append(r.strs, u.str)
			continue
		}
		if u.isExpr {
			colInvalid = false
			v, ok := tryEval(u.expr)
			if !ok {
				r.undef = true
				r.vals = append(r.vals, math.NaN())
				continue
			}
			if v.T == STR {
				r.strs = append(r.strs, v.S)
				r.label = v.S
				r.vals = append(r.vals, math.NaN())
				continue
			}
			f := v.Real()
			if math.IsNaN(f) {
				r.undef = true
			}
			r.vals = append(r.vals, f)
			continue
		}
		c := u.col
		if c <= 0 {
			r.vals = append(r.vals, columnValue(c).Real())
			continue
		}
		if c > len(fields) {
			r.ok = false
			return r
		}
		v, ok := parseNumField(fields[c-1])
		if !ok {
			r.ok = false
			r.label = fields[c-1]
			r.strs = append(r.strs, fields[c-1])
			r.vals = append(r.vals, math.NaN())
			continue
		}
		r.vals = append(r.vals, v)
	}
	return r
}

// ---------------- plot command parsing ----------------

var lastPlotCmd string
var lastPlotIs3d bool

func cmdReplot(p *Parser) {
	if lastPlotCmd == "" {
		throwNC("no previous plot")
	}
	skipToEnd(p)
	savedLine := ctx.line
	toks := lexLine(lastPlotCmd)
	ctx.line = lastPlotCmd
	sub := &Parser{toks: toks, line: lastPlotCmd}
	sub.c = 1
	doPlot(sub, lastPlotIs3d)
	ctx.line = savedLine
}

func cmdPlot(p *Parser, is3d bool) {
	startTok := p.c - 1
	st := p.toks[startTok].Pos
	doPlot(p, is3d)
	end := len(p.line)
	if p.c < len(p.toks) {
		end = p.toks[p.c].Pos
	}
	lastPlotCmd = p.line[st:end]
	lastPlotIs3d = is3d
}

func parseRangeSpec(p *Parser, a *Axis, dummy *string) (lo, hi float64, loSet, hiSet bool) {
	p.c++ // [
	// dummy variable assignment  [t=0:1]
	if t := p.cur(); t != nil && t.K == TNAME && isOpAt(p, 1, "=") {
		if dummy != nil {
			*dummy = t.S
		}
		p.c += 2
	}
	if !p.isOp(":") && !p.isOp("]") {
		if p.isOp("*") {
			p.c++
		} else {
			lo = axisValueFromExpr(p, a)
			loSet = true
		}
	}
	if p.isOp(":") {
		p.c++
		if !p.isOp("]") {
			if p.isOp("*") {
				p.c++
			} else {
				hi = axisValueFromExpr(p, a)
				hiSet = true
			}
		}
	}
	p.expectOp("]", "']' expected")
	return
}

type PlotRanges struct {
	set   map[string][4]float64 // lo,hi,loSet,hiSet
	order []string
}

func doPlot(p *Parser, is3d bool) {
	// ranges
	rangeAxes := []string{"x", "y"}
	if is3d {
		rangeAxes = []string{"x", "y", "z"}
	}
	if S.parametric {
		if is3d {
			rangeAxes = []string{"u", "v", "x", "y", "z"}
		} else {
			rangeAxes = []string{"t", "x", "y"}
		}
	}
	saved := map[string]Axis{}
	for _, n := range axisNames {
		saved[n] = *S.axes[n]
	}
	dummy := S.dummy1
	dummy2 := S.dummy2
	ri := 0
	firstRangePos := p.pos()
	for p.isOp("[") {
		if ri >= len(rangeAxes) {
			break
		}
		an := rangeAxes[ri]
		a := S.axes[an]
		var dv string
		lo, hi, ls, hs := parseRangeSpec(p, a, &dv)
		if dv != "" {
			if ri == 0 {
				dummy = dv
			} else if ri == 1 && is3d {
				dummy2 = dv
			}
		}
		if ls {
			a.min = lo
			a.autoMin = false
		}
		if hs {
			a.max = hi
			a.autoMax = false
		}
		ri++
	}
	_ = firstRangePos
	var elems []*PlotElem
	elemPos := []int{}
	type iterCtx struct{}
	// parse elements, with iteration support (evaluated immediately)
	var curves []*Curve
	defer func() {
		// restore temporary ranges
		for _, n := range axisNames {
			a := S.axes[n]
			sv := saved[n]
			a.min, a.max, a.autoMin, a.autoMax = sv.min, sv.max, sv.autoMin, sv.autoMax
		}
	}()
	for {
		if p.endOfCmd() {
			throwAt(p.pos(), "function to plot expected")
		}
		if p.isName("for") {
			p.c++
			it := parseIter(p)
			startC := p.c
			endC := startC
			it.each(func() {
				p.c = startC
				e := parsePlotElem(p, is3d, dummy, dummy2)
				elems = append(elems, e)
				elemPos = append(elemPos, startC)
				curves = append(curves, buildCurve(e, is3d, dummy, dummy2, len(curves)))
				endC = p.c
			})
			if endC == startC {
				// zero iterations: skip element tokens
				p.c = startC
				skipPlotElem(p)
			} else {
				p.c = endC
			}
		} else {
			e := parsePlotElem(p, is3d, dummy, dummy2)
			elems = append(elems, e)
			curves = append(curves, buildCurve(e, is3d, dummy, dummy2, len(curves)))
		}
		if p.isOp(",") {
			p.c++
			continue
		}
		break
	}
	_ = elems
	// assign line types
	lt := 0
	for _, c := range curves {
		if c == nil {
			continue
		}
		if c.lt == 0 {
			lt++
			c.lt = lt
		} else {
			lt++
		}
	}
	var cs []*Curve
	for _, c := range curves {
		if c != nil {
			cs = append(cs, c)
		}
	}
	if is3d {
		setVar("GPVAL_SPLOT", IntV(1))
		setVar("GPVAL_PLOT", IntV(0))
	} else {
		setVar("GPVAL_PLOT", IntV(1))
		setVar("GPVAL_SPLOT", IntV(0))
	}
	if S.tableOn {
		writeTable(cs, is3d)
		return
	}
	renderPlot(cs, is3d)
}

func skipPlotElem(p *Parser) {
	depth := 0
	for p.c < len(p.toks) {
		t := p.toks[p.c]
		if t.K == TNL || (t.K == TOP && t.S == ";" && depth == 0) {
			return
		}
		if t.K == TOP && (t.S == "(" || t.S == "[" || t.S == "{") {
			depth++
		}
		if t.K == TOP && (t.S == ")" || t.S == "]" || t.S == "}") {
			depth--
		}
		if depth == 0 && t.K == TOP && t.S == "," {
			return
		}
		p.c++
	}
}

var lastDataFile string

func parsePlotElem(p *Parser, is3d bool, dummy, dummy2 string) *PlotElem {
	e := &PlotElem{axes: "x1y1"}
	t := p.cur()
	startPos := t.Pos
	// sampling range for this element
	if p.isOp("[") {
		var dv string
		a := S.axes["x"]
		lo, hi, ls, hs := parseRangeSpec(p, a, &dv)
		_ = ls
		_ = hs
		e.sampRange = &[2]float64{lo, hi}
		e.sampVar = dv
		t = p.cur()
		startPos = t.Pos
	}
	isData := false
	if t.K == TSTR {
		isData = true
		// check it's not a string expression (e.g. "a"."b")
	}
	if t.K == TDOLLAR && !(len(t.S) > 1 && isDigit(t.S[1])) {
		isData = true
	}
	if isData {
		if t.K == TSTR {
			e.src = t.S
			if e.src == "" {
				e.src = lastDataFile
			}
			switch t.S {
			case "+":
				e.srcKind = 2
			case "++":
				e.srcKind = 3
			case "-":
				e.srcKind = 4
			default:
				e.srcKind = 0
				lastDataFile = e.src
			}
		} else {
			e.src = t.S
			e.srcKind = 1
		}
		p.c++
		// modifiers
		titleEnd := p.toks[p.c-1].End
		for !p.endOfCmd() && !p.isOp(",") {
			w := p.tokStr()
			switch {
			case optMatch(w, "i$ndex"):
				p.c++
				e.indexSet = true
				a := int(p.evalNum())
				e.index = [3]int{a, a, 1}
				if p.isOp(":") {
					p.c++
					e.index[1] = int(p.evalNum())
					if p.isOp(":") {
						p.c++
						e.index[2] = int(p.evalNum())
					}
				}
				titleEnd = p.toks[p.c-1].End
			case optMatch(w, "ev$ery"):
				p.c++
				e.everySet = true
				e.every = [6]int{1, 1, 0, 0, math.MaxInt32, math.MaxInt32}
				for k := 0; k < 6; k++ {
					if p.isOp(":") {
						p.c++
						continue
					}
					if p.endOfCmd() || p.isOp(",") || (p.cur().K == TNAME) {
						break
					}
					e.every[k] = int(p.evalNum())
					if p.isOp(":") {
						p.c++
					} else {
						break
					}
				}
				titleEnd = p.toks[p.c-1].End
			case optMatch(w, "u$sing"):
				p.c++
				e.usingSet = true
				for {
					var u UsingCol
					if p.isOp("(") {
						st := p.c
						p.c++
						n := p.parseCommaExpr()
						p.expectOp(")", "')' expected")
						_ = st
						u.expr = n
						u.isExpr = true
					} else if t := p.cur(); t.K == TNUM {
						u.col = int(t.IV)
						p.c++
					} else if t.K == TOP && t.S == "-" {
						p.c++
						u.col = -int(p.cur().IV)
						p.c++
					} else if t.K == TDOLLAR {
						n := p.parsePrimary()
						u.expr = n
						u.isExpr = true
					} else if t.K == TSTR {
						name := t.S
						p.c++
						u.isExpr = true
						u.expr = func() Value { return columnFunc(StrV(name)) }
					} else {
						n := p.parsePrimary()
						u.expr = n
						u.isExpr = true
					}
					e.using = append(e.using, u)
					if p.isOp(":") {
						p.c++
						continue
					}
					break
				}
				titleEnd = p.toks[p.c-1].End
			default:
				goto common
			}
		}
	common:
		e.defText = p.line[startPos:titleEnd]
	} else {
		// function: may be preceded by assignments  a=1, ...
		st := p.pos()
		params := []string{dummy}
		if is3d {
			params = []string{dummy, dummy2}
		}
		if S.parametric && !is3d {
			params = []string{"t"}
			if dummy != "x" {
				params = []string{dummy}
			}
		}
		if e.sampVar != "" {
			params[0] = e.sampVar
		}
		sub := &Parser{toks: p.toks, c: p.c, params: params, line: p.line}
		n := sub.parseExpr()
		p.c = sub.c
		end := len(p.line)
		if p.c < len(p.toks) {
			end = p.toks[p.c].Pos
		}
		e.isFunc = true
		e.fn = n
		e.fnText = strings.TrimSpace(p.line[st:end])
		e.defText = e.fnText
		if S.parametric && !is3d && p.isOp(",") {
			// second function of parametric pair
			p.c++
			st2 := p.pos()
			sub2 := &Parser{toks: p.toks, c: p.c, params: params, line: p.line}
			n2 := sub2.parseExpr()
			p.c = sub2.c
			end2 := len(p.line)
			if p.c < len(p.toks) {
				end2 = p.toks[p.c].Pos
			}
			fx := n
			fy := n2
			e.fn = func() Value {
				x := fx()
				y := fy()
				return CpxV(x.Real(), y.Real())
			}
			e.defText = e.fnText + ", " + strings.TrimSpace(p.line[st2:end2])
			e.srcKind = -2
		}
	}
	// options
	for !p.endOfCmd() && !p.isOp(",") {
		w := p.tokStr()
		wp := p.pos()
		p.c++
		switch {
		case optMatch(w, "t$itle"):
			if p.isName("columnheader") || p.isName("columnhead") || p.isName("col") {
				p.c++
				e.titleCol = true
				if p.isOp("(") {
					p.c++
					p.evalNum()
					p.expectOp(")", "')' expected")
				}
				continue
			}
			e.title = p.evalStr()
			e.titleSet = true
		case optMatch(w, "not$itle"):
			e.notitle = true
			if p.isStrStart() {
				p.evalStr()
			}
		case optMatch(w, "w$ith"):
			e.style = parseStyleName(p)
			if e.style == "filledcurves" {
				for _, k := range []string{"x1", "x2", "y1", "y2", "closed", "above", "below"} {
					if p.isName(k) {
						e.fillTo = k
						p.c++
					}
				}
			}
		case optMatch(w, "s$mooth"):
			sm := p.tokStr()
			p.c++
			for _, s := range []string{"u$nique", "f$requency", "fnormal", "cum$ulative", "cn$ormal", "cs$plines", "acs$plines", "mcs$plines", "b$ezier", "sb$ezier", "k$density", "unwrap", "path", "zsort"} {
				if optMatch(sm, s) {
					e.smooth = strings.Replace(s, "$", "", 1)
				}
			}
			if e.smooth == "kdensity" {
				for p.isName("bandwidth") || p.isName("period") {
					p.c++
					p.evalNum()
				}
			}
			if e.smooth == "acsplines" || e.smooth == "" {
			}
		case optMatch(w, "lt") || optMatch(w, "linet$ype") || optMatch(w, "ls") || optMatch(w, "lines$tyle"):
			v := int(p.evalNum())
			e.lt = v
			e.ltSet = true
		case optMatch(w, "lc") || optMatch(w, "linec$olor"):
			if p.isName("rgb") || p.isName("rgbcolor") {
				p.c++
				p.parseExpr()
			} else if p.isName("variable") || p.isName("palette") || p.isName("bgnd") || p.isName("black") {
				p.c++
			} else {
				p.evalNum()
			}
		case optMatch(w, "lw") || optMatch(w, "linew$idth") || optMatch(w, "ps") || optMatch(w, "points$ize") || optMatch(w, "dt") || optMatch(w, "dasht$ype"):
			if p.isName("variable") {
				p.c++
			} else if p.isStrStart() {
				p.evalStr()
			} else {
				p.evalNum()
			}
		case optMatch(w, "pt") || optMatch(w, "pointt$ype"):
			if p.isStrStart() {
				e.pointsChar = p.evalStr()
			} else {
				e.pt = int(p.evalNum())
			}
		case optMatch(w, "fs") || optMatch(w, "fill$style"):
			for p.isName("solid") || p.isName("empty") || p.isName("pattern") || p.isName("border") || p.isName("noborder") || p.isName("transparent") {
				p.c++
				if t := p.cur(); t != nil && t.K == TNUM {
					p.c++
				}
			}
		case w == "axes" || w == "axis":
			e.axes = p.tokStr()
			p.c++
		case w == "nohidden3d", w == "nocontours", w == "nosurface", w == "palette", w == "pointinterval", w == "pi", w == "pn", w == "pointnumber", w == "heads", w == "nohead", w == "head", w == "noborder", w == "fc", w == "fillcolor", w == "notitle", w == "binary", w == "matrix", w == "nonuniform", w == "sparse":
			if (w == "pi" || w == "pointinterval" || w == "pn" || w == "pointnumber") && !p.endOfCmd() {
				p.evalNum()
			}
			if (w == "fc" || w == "fillcolor") && !p.endOfCmd() {
				if p.isName("rgb") {
					p.c++
				}
				p.parseExpr()
			}
		case w == "bins":
			if p.isOp("=") {
				p.c++
				p.evalNum()
			}
			e.smooth = "bins"
		default:
			throwAt(wp, "unexpected or unrecognized token: "+w)
		}
	}
	return e
}

func styleCols(style string, is3d bool) int {
	if is3d {
		return 3
	}
	switch style {
	case "errorbars", "yerrorbars", "xerrorbars", "errorlines", "yerrorlines", "xerrorlines", "labels", "boxerrorbars":
		return 3
	case "xyerrorbars", "xyerrorlines", "vectors", "boxxyerrorbars":
		return 4
	case "financebars", "candlesticks":
		return 5
	}
	return 2
}

// buildCurve evaluates an element into a curve
func buildCurve(e *PlotElem, is3d bool, dummy, dummy2 string, idx int) *Curve {
	c := &Curve{is3d: is3d, isFunc: e.isFunc, smooth: e.smooth, axes: e.axes, fillTo: e.fillTo}
	c.style = e.style
	if c.style == "" {
		if e.isFunc || e.srcKind == 2 || e.srcKind == 3 {
			c.style = S.styleFunc
			if !e.isFunc {
				c.style = S.styleData
			}
		} else {
			c.style = S.styleData
		}
	}
	if e.ltSet {
		c.lt = e.lt
	}
	c.pt = e.pt
	c.ptChar = e.pointsChar
	if e.notitle {
		c.hasTitle = false
	} else if e.titleSet {
		c.title = e.title
		c.hasTitle = e.title != ""
	} else {
		c.title = e.defText
		c.hasTitle = true
	}
	if is3d {
		build3d(c, e, dummy, dummy2)
		return c
	}
	xa := S.axes["x"]
	ya := S.axes["y"]
	if e.isFunc {
		var lo, hi float64
		if S.parametric {
			ta := S.axes["t"]
			lo, hi = ta.min, ta.max
		} else {
			lo, hi = funcXRange()
		}
		if e.sampRange != nil {
			lo, hi = e.sampRange[0], e.sampRange[1]
		}
		n := S.samples1
		frames = append(frames, []Value{IntV(0)})
		defer func() { frames = frames[:len(frames)-1] }()
		for i := 0; i < n; i++ {
			var x float64
			if xa.log && !S.parametric {
				l0, l1 := math.Log(lo)/math.Log(xa.base), math.Log(hi)/math.Log(xa.base)
				x = math.Pow(xa.base, l0+float64(i)*(l1-l0)/float64(n-1))
			} else {
				x = lo + float64(i)*(hi-lo)/float64(n-1)
			}
			frames[len(frames)-1][0] = FltV(x)
			v, ok := tryEval(e.fn)
			pt := Pt{x: x, typ: PT_IN}
			if !ok || v.T == STR {
				pt.typ = PT_UNDEF
				pt.y = 0
			} else if S.parametric {
				pt.x = v.R
				pt.y = v.Im
			} else {
				if v.T == CMPLX && math.Abs(v.Im) > S.zero {
					pt.typ = PT_UNDEF
					pt.y = 0
				} else {
					pt.y = v.Real()
				}
			}
			if pt.typ != PT_UNDEF && (math.IsNaN(pt.y) || math.IsInf(pt.y, 0)) {
				pt.typ = PT_UNDEF
			}
			if c.style == "filledcurves" {
				pt.ex = []float64{0}
			}
			c.pts = append(c.pts, pt)
		}
		applyRangeTypes(c)
		return c
	}
	ncols := styleCols(c.style, false)
	if c.style == "labels" {
		e.labelCol = 3
	}
	if e.srcKind == 2 || e.srcKind == 3 {
		lo, hi := funcXRange()
		if e.sampRange != nil {
			lo, hi = e.sampRange[0], e.sampRange[1]
		}
		n := S.samples1
		for i := 0; i < n; i++ {
			x := lo + float64(i)*(hi-lo)/float64(n-1)
			curFields = []string{strconv.FormatFloat(x, 'g', -1, 64)}
			curRecIdx = i
			var r Record
			if e.usingSet {
				r = evalRecord(e, ncols, curFields)
			} else {
				r = Record{ok: true, vals: []float64{x, x}}
			}
			addRecord(c, r, ncols, e)
		}
		curFields = nil
	} else {
		readData(e, ncols, func(r Record) {
			if e.titleCol && !e.titleSet && curHeader != nil {
			}
			addRecord(c, r, ncols, e)
		})
		if e.titleCol && curHeader != nil {
			col := 2
			if e.usingSet && len(e.using) >= 2 && !e.using[1].isExpr {
				col = e.using[1].col
			}
			if col >= 1 && col <= len(curHeader) {
				c.title = curHeader[col-1]
				c.hasTitle = true
			}
		}
	}
	// trailing break removal
	for len(c.pts) > 0 && c.pts[len(c.pts)-1].typ == PT_BREAK {
		c.pts = c.pts[:len(c.pts)-1]
	}
	if c.smooth != "" {
		applySmooth(c)
	}
	_ = xa
	_ = ya
	applyRangeTypes(c)
	return c
}

func funcXRange() (float64, float64) {
	xa := S.axes["x"]
	lo, hi := xa.min, xa.max
	if xa.autoMin && xa.autoMax {
		lo, hi = -10, 10
		if dataXRangeSet {
			lo, hi = dataXMin, dataXMax
		}
	} else if xa.autoMin {
		lo = -10
		if dataXRangeSet {
			lo = dataXMin
		}
	} else if xa.autoMax {
		hi = 10
		if dataXRangeSet {
			hi = dataXMax
		}
	}
	return lo, hi
}

var dataXRangeSet bool
var dataXMin, dataXMax float64

func addRecord(c *Curve, r Record, ncols int, e *PlotElem) {
	if r.brk {
		if len(c.pts) > 0 && c.pts[len(c.pts)-1].typ != PT_BREAK {
			c.pts = append(c.pts, Pt{typ: PT_BREAK})
		}
		return
	}
	if !r.ok {
		return
	}
	v := r.vals
	if e.usingSet && len(e.using) == 1 {
		v = []float64{float64(curRecIdx), v[0]}
	}
	if len(v) < 2 {
		return
	}
	pt := Pt{x: v[0], y: v[1], typ: PT_IN}
	style := c.style
	switch style {
	case "labels":
		if len(r.strs) > 0 {
			pt.label = r.strs[len(r.strs)-1]
		} else if len(v) > 2 {
			pt.label = gnum(v[2])
		}
	case "errorbars", "yerrorbars", "errorlines", "yerrorlines":
		if len(v) >= 4 {
			pt.ex = []float64{v[2], v[3]}
		} else if len(v) >= 3 {
			pt.ex = []float64{v[1] - v[2], v[1] + v[2]}
		} else {
			pt.ex = []float64{v[1], v[1]}
		}
	case "xerrorbars", "xerrorlines":
		if len(v) >= 4 {
			pt.ex = []float64{v[2], v[3]}
		} else if len(v) >= 3 {
			pt.ex = []float64{v[0] - v[2], v[0] + v[2]}
		}
	case "xyerrorbars", "xyerrorlines":
		if len(v) >= 6 {
			pt.ex = []float64{v[2], v[3], v[4], v[5]}
		} else if len(v) >= 4 {
			pt.ex = []float64{v[0] - v[2], v[0] + v[2], v[1] - v[3], v[1] + v[3]}
		}
	case "boxes":
		w := 0.0
		if len(v) >= 3 {
			w = v[2]
			pt.ex = []float64{v[0] - w/2, v[0] + w/2}
		} else {
			pt.ex = []float64{v[0], v[0]}
		}
	case "filledcurves":
		if len(v) >= 3 {
			pt.ex = []float64{v[2]}
		} else {
			pt.ex = []float64{0}
		}
	case "vectors":
		if len(v) >= 4 {
			pt.ex = []float64{v[2], v[3]}
		}
	case "financebars", "candlesticks":
		if len(v) >= 5 {
			pt.ex = v[2:5]
		}
	case "boxerrorbars":
		if len(v) >= 3 {
			pt.ex = v[2:]
		}
	}
	if r.undef || math.IsNaN(pt.y) || math.IsNaN(pt.x) {
		pt.typ = PT_UNDEF
	}
	c.pts = append(c.pts, pt)
}

func applyRangeTypes(c *Curve) {
	xa := S.axes["x"]
	ya := S.axes["y"]
	if c.axes == "x1y2" {
		ya = S.axes["y2"]
	}
	for i := range c.pts {
		pt := &c.pts[i]
		if pt.typ != PT_IN {
			continue
		}
		if outOfRange(xa, pt.x) || outOfRange(ya, pt.y) {
			pt.typ = PT_OUT
		}
	}
}

func outOfRange(a *Axis, v float64) bool {
	lo, hi := a.min, a.max
	if lo > hi {
		lo, hi = hi, lo
	}
	if !a.autoMin && v < lo {
		return true
	}
	if !a.autoMax && v > hi {
		return true
	}
	if a.log && v <= 0 {
		return true
	}
	return false
}

// ---------------- table output ----------------

func tnum(v float64) string {
	if math.IsNaN(v) {
		return " NaN"
	}
	if math.IsInf(v, 1) {
		return " inf"
	}
	if math.IsInf(v, -1) {
		return "-inf"
	}
	return cfmt("% g", v)
}

var tableBuf strings.Builder

func writeTable(cs []*Curve, is3d bool) {
	var b strings.Builder
	if is3d {
		writeTable3d(&b, cs)
	} else {
		for i, c := range cs {
			b.WriteString("\n# Curve " + itoa(i) + " of " + itoa(len(cs)) + ", " + itoa(len(c.pts)) + " points\n")
			if c.hasTitle {
				b.WriteString("# Curve title: \"" + c.title + "\"\n")
			}
			hdr := "# x y type\n"
			switch c.style {
			case "errorbars", "yerrorbars", "errorlines", "yerrorlines":
				hdr = "# x y ylow yhigh type\n"
			case "xerrorbars", "xerrorlines":
				hdr = "# x y xlow xhigh type\n"
			case "xyerrorbars", "xyerrorlines":
				hdr = "# x y xlow xhigh ylow yhigh type\n"
			case "boxes":
				hdr = "# x y xlow xhigh type\n"
			case "filledcurves":
				hdr = "# x y1 y2 type\n"
			case "labels":
				hdr = "# x y label type\n"
			case "vectors":
				hdr = "# x y xdelta ydelta type\n"
			case "financebars", "candlesticks":
				hdr = "# x open low high close type\n"
			case "boxerrorbars":
				hdr = "# x y ylow yhigh type\n"
			}
			b.WriteString(hdr)
			for _, pt := range c.pts {
				if pt.typ == PT_BREAK {
					if c.style != "labels" {
						b.WriteString("\n")
					}
					continue
				}
				if c.style == "labels" {
					b.WriteString(tnum(pt.x) + " " + tnum(pt.y) + " \"" + pt.label + "\"\n")
					continue
				}
				line := tnum(pt.x) + " " + tnum(pt.y)
				for _, ex := range pt.ex {
					line += " " + tnum(ex)
				}
				line += "  " + string(pt.typ) + "\n"
				b.WriteString(line)
			}
			b.WriteString("\n")
		}
	}
	out := b.String()
	if S.tableDB != "" {
		lines := strings.Split(strings.TrimSuffix(out, "\n"), "\n")
		datablocks[S.tableDB] = append(datablocks[S.tableDB], lines...)
		return
	}
	if S.tableFile != "" {
		f, err := os.OpenFile(S.tableFile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
		if err == nil {
			f.WriteString(out)
			f.Close()
		}
		return
	}
	writeOutput(out)
}

func writeTable3d(b *strings.Builder, cs []*Curve) {
	for i, c := range cs {
		b.WriteString("\n# Surface " + itoa(i) + " of " + itoa(len(cs)) + " surfaces\n")
		for si, surf := range c.isoCurves {
			if si > 0 {
				b.WriteString("\n\n# Surface " + itoa(i+si) + " of " + itoa(len(cs)+len(c.isoCurves)-1) + " surfaces\n")
			}
			if si == 0 && c.hasTitle {
				b.WriteString("\n# Curve title: \"" + c.title + "\"\n")
			}
			for k, iso := range surf {
				b.WriteString("\n# IsoCurve " + itoa(k) + ", " + itoa(len(iso)) + " points\n# x y z type\n")
				for _, pt := range iso {
					b.WriteString(tnum(pt.x) + " " + tnum(pt.y) + " " + tnum(pt.z) + " " + string(pt.typ) + "\n")
				}
			}
		}
		b.WriteString("\n")
	}
}

func build3d(c *Curve, e *PlotElem, dummy, dummy2 string) {
	if e.isFunc {
		xa, ya := S.axes["x"], S.axes["y"]
		xlo, xhi := xa.min, xa.max
		ylo, yhi := ya.min, ya.max
		if xa.autoMin {
			xlo = -10
		}
		if xa.autoMax {
			xhi = 10
		}
		if ya.autoMin {
			ylo = -10
		}
		if ya.autoMax {
			yhi = 10
		}
		nx := S.samples1
		ny := S.iso2
		frames = append(frames, []Value{IntV(0), IntV(0)})
		defer func() { frames = frames[:len(frames)-1] }()
		var surf [][]Pt
		// iso curves along x for each y (iso2 count), samples along x
		for j := 0; j < ny; j++ {
			y := ylo + float64(j)*(yhi-ylo)/float64(ny-1)
			var iso []Pt
			for i := 0; i < nx; i++ {
				x := xlo + float64(i)*(xhi-xlo)/float64(nx-1)
				iso = append(iso, eval3(e, x, y))
			}
			surf = append(surf, iso)
		}
		nx2 := S.iso1
		ny2 := S.samples2
		for i := 0; i < nx2; i++ {
			x := xlo + float64(i)*(xhi-xlo)/float64(nx2-1)
			var iso []Pt
			for j := 0; j < ny2; j++ {
				y := ylo + float64(j)*(yhi-ylo)/float64(ny2-1)
				iso = append(iso, eval3(e, x, y))
			}
			surf = append(surf, iso)
		}
		c.isoCurves = [][][]Pt{surf}
		return
	}
	// data: group by blocks and segments
	var surfs [][][]Pt
	var cur [][]Pt
	var seg []Pt
	lastBlock := -1
	readData(e, 3, func(r Record) {
		if lastBlock >= 0 && curBlockIdx != lastBlock {
		}
		if r.brk {
			if len(seg) > 0 {
				cur = append(cur, seg)
				seg = nil
			}
			return
		}
		if curBlockIdx != lastBlock && lastBlock >= 0 {
			if len(seg) > 0 {
				cur = append(cur, seg)
				seg = nil
			}
			if len(cur) > 0 {
				surfs = append(surfs, cur)
				cur = nil
			}
		}
		lastBlock = curBlockIdx
		if !r.ok {
			return
		}
		v := r.vals
		var pt Pt
		if len(v) >= 3 {
			pt = Pt{x: v[0], y: v[1], z: v[2], typ: PT_IN}
		} else if len(v) >= 1 {
			pt = Pt{x: float64(curRecIdx), y: float64(curSegIdx), z: v[len(v)-1], typ: PT_IN}
		}
		seg = append(seg, pt)
	})
	if len(seg) > 0 {
		cur = append(cur, seg)
	}
	if len(cur) > 0 {
		surfs = append(surfs, cur)
	}
	c.isoCurves = surfs
}

func eval3(e *PlotElem, x, y float64) Pt {
	frames[len(frames)-1][0] = FltV(x)
	frames[len(frames)-1][1] = FltV(y)
	v, ok := tryEval(e.fn)
	pt := Pt{x: x, y: y, typ: PT_IN}
	if !ok {
		pt.typ = PT_UNDEF
		return pt
	}
	pt.z = v.Real()
	za := S.axes["z"]
	if outOfRange(za, pt.z) {
		pt.typ = PT_OUT
	}
	return pt
}

// ---------------- smoothing ----------------

func applySmooth(c *Curve) {
	switch c.smooth {
	case "unique", "frequency", "cumulative", "cnormal", "fnormal":
		// operate on each segment? gnuplot: whole curve, sorted
		var segs [][]Pt
		var seg []Pt
		for _, p := range c.pts {
			if p.typ == PT_BREAK || p.typ == PT_UNDEF {
				if len(seg) > 0 {
					segs = append(segs, seg)
				}
				seg = nil
				continue
			}
			seg = append(seg, p)
		}
		if len(seg) > 0 {
			segs = append(segs, seg)
		}
		var out []Pt
		for si, s := range segs {
			if si > 0 {
				out = append(out, Pt{typ: PT_BREAK})
			}
			out = append(out, smoothSeg(c.smooth, s)...)
		}
		c.pts = out
	case "csplines", "acsplines", "mcsplines", "bezier", "sbezier", "kdensity":
		var all []Pt
		for _, p := range c.pts {
			if p.typ == PT_IN || p.typ == PT_OUT {
				all = append(all, p)
			}
		}
		c.pts = smoothInterp(c.smooth, all)
	}
}

func smoothSeg(kind string, s []Pt) []Pt {
	sort.SliceStable(s, func(i, j int) bool { return s[i].x < s[j].x })
	var out []Pt
	switch kind {
	case "unique", "frequency":
		for i := 0; i < len(s); {
			j := i
			sum := 0.0
			for j < len(s) && s[j].x == s[i].x {
				sum += s[j].y
				j++
			}
			y := sum
			if kind == "unique" {
				y = sum / float64(j-i)
			}
			out = append(out, Pt{x: s[i].x, y: y, typ: PT_IN})
			i = j
		}
	case "cumulative", "cnormal":
		sum := 0.0
		for _, p := range s {
			sum += p.y
			out = append(out, Pt{x: p.x, y: sum, typ: PT_IN})
		}
		if kind == "cnormal" && sum != 0 {
			for i := range out {
				out[i].y /= sum
			}
		}
	case "fnormal":
		sum := 0.0
		for _, p := range s {
			sum += p.y
		}
		for i := 0; i < len(s); {
			j := i
			t := 0.0
			for j < len(s) && s[j].x == s[i].x {
				t += s[j].y
				j++
			}
			out = append(out, Pt{x: s[i].x, y: t / sum, typ: PT_IN})
			i = j
		}
	}
	return out
}

func smoothInterp(kind string, s []Pt) []Pt {
	sort.SliceStable(s, func(i, j int) bool { return s[i].x < s[j].x })
	// merge equal x (average)
	var u []Pt
	for i := 0; i < len(s); {
		j := i
		sum := 0.0
		for j < len(s) && s[j].x == s[i].x {
			sum += s[j].y
			j++
		}
		u = append(u, Pt{x: s[i].x, y: sum / float64(j-i)})
		i = j
	}
	n := S.samples1
	if len(u) == 0 {
		return nil
	}
	xlo, xhi := u[0].x, u[len(u)-1].x
	xa := S.axes["x"]
	if !xa.autoMin {
		xlo = xa.min
	}
	if !xa.autoMax {
		xhi = xa.max
	}
	var out []Pt
	switch kind {
	case "csplines", "acsplines":
		if len(u) < 3 {
			throwNC("Can't calculate splines, need at least 3 points")
		}
		m := naturalSpline(u)
		for i := 0; i < n; i++ {
			x := xlo + float64(i)*(xhi-xlo)/float64(n-1)
			out = append(out, Pt{x: x, y: evalSpline(u, m, x), typ: PT_IN})
		}
	case "mcsplines":
		for i := 0; i < n; i++ {
			x := xlo + float64(i)*(xhi-xlo)/float64(n-1)
			out = append(out, Pt{x: x, y: monoSpline(u, x), typ: PT_IN})
		}
	case "bezier", "sbezier":
		pts := u
		for i := 0; i < n; i++ {
			t := float64(i) / float64(n-1)
			x, y := bezier(pts, t)
			out = append(out, Pt{x: x, y: y, typ: PT_IN})
		}
	case "kdensity":
		// gaussian kernel, default bandwidth
		N := float64(len(s))
		mean, sd := 0.0, 0.0
		for _, p := range s {
			mean += p.x
		}
		mean /= N
		for _, p := range s {
			sd += (p.x - mean) * (p.x - mean)
		}
		sd = math.Sqrt(sd / N)
		bw := sd * math.Pow(4.0/(3.0*N), 0.2)
		if bw == 0 {
			bw = 1
		}
		lo, hi := s[0].x, s[len(s)-1].x
		lo -= 3 * bw
		hi += 3 * bw
		for i := 0; i < n; i++ {
			x := lo + float64(i)*(hi-lo)/float64(n-1)
			y := 0.0
			for _, p := range s {
				z := (x - p.x) / bw
				y += p.y * math.Exp(-z*z/2) / (bw * math.Sqrt(2*math.Pi))
			}
			out = append(out, Pt{x: x, y: y, typ: PT_IN})
		}
	}
	return out
}

func naturalSpline(u []Pt) []float64 {
	n := len(u)
	m := make([]float64, n)
	a := make([]float64, n)
	b := make([]float64, n)
	c := make([]float64, n)
	d := make([]float64, n)
	for i := 1; i < n-1; i++ {
		h0 := u[i].x - u[i-1].x
		h1 := u[i+1].x - u[i].x
		a[i] = h0
		b[i] = 2 * (h0 + h1)
		c[i] = h1
		d[i] = 6 * ((u[i+1].y-u[i].y)/h1 - (u[i].y-u[i-1].y)/h0)
	}
	// solve tridiagonal for m[1..n-2]
	for i := 2; i < n-1; i++ {
		w := a[i] / b[i-1]
		b[i] -= w * c[i-1]
		d[i] -= w * d[i-1]
	}
	for i := n - 2; i >= 1; i-- {
		m[i] = d[i]
		if i+1 <= n-2 {
			m[i] -= c[i] * m[i+1]
		}
		m[i] /= b[i]
	}
	return m
}

func evalSpline(u []Pt, m []float64, x float64) float64 {
	n := len(u)
	k := 0
	for k < n-2 && x > u[k+1].x {
		k++
	}
	h := u[k+1].x - u[k].x
	A := (u[k+1].x - x) / h
	B := (x - u[k].x) / h
	return A*u[k].y + B*u[k+1].y + ((A*A*A-A)*m[k]+(B*B*B-B)*m[k+1])*h*h/6
}

func monoSpline(u []Pt, x float64) float64 {
	n := len(u)
	if n == 1 {
		return u[0].y
	}
	dk := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		dk[i] = (u[i+1].y - u[i].y) / (u[i+1].x - u[i].x)
	}
	mk := make([]float64, n)
	mk[0] = dk[0]
	mk[n-1] = dk[n-2]
	for i := 1; i < n-1; i++ {
		if dk[i-1]*dk[i] <= 0 {
			mk[i] = 0
		} else {
			mk[i] = (dk[i-1] + dk[i]) / 2
		}
	}
	for i := 0; i < n-1; i++ {
		if dk[i] == 0 {
			mk[i], mk[i+1] = 0, 0
			continue
		}
		a := mk[i] / dk[i]
		b := mk[i+1] / dk[i]
		s := a*a + b*b
		if s > 9 {
			t := 3 / math.Sqrt(s)
			mk[i] = t * a * dk[i]
			mk[i+1] = t * b * dk[i]
		}
	}
	k := 0
	for k < n-2 && x > u[k+1].x {
		k++
	}
	h := u[k+1].x - u[k].x
	t := (x - u[k].x) / h
	h00 := 2*t*t*t - 3*t*t + 1
	h10 := t*t*t - 2*t*t + t
	h01 := -2*t*t*t + 3*t*t
	h11 := t*t*t - t*t
	return h00*u[k].y + h10*h*mk[k] + h01*u[k+1].y + h11*h*mk[k+1]
}

func bezier(p []Pt, t float64) (float64, float64) {
	n := len(p) - 1
	x, y := 0.0, 0.0
	for i := 0; i <= n; i++ {
		b := binom(n, i) * math.Pow(t, float64(i)) * math.Pow(1-t, float64(n-i))
		x += b * p[i].x
		y += b * p[i].y
	}
	return x, y
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}
