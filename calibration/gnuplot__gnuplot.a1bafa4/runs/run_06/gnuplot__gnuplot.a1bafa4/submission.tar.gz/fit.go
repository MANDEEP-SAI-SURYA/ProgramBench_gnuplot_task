package main

import (
	"fmt"
	"os"
	"math"
	"strings"
)

func cmdFit(p *Parser) {
	// optional ranges
	var rlo, rhi float64
	rset := false
	for p.isOp("[") {
		a := S.axes["x"]
		lo, hi, ls, hs := parseRangeSpec(p, a, nil)
		if ls && hs {
			rlo, rhi, rset = lo, hi, true
		}
	}
	_ = rset
	// function expression with dummy x (and y)
	st := p.pos()
	sub := &Parser{toks: p.toks, c: p.c, params: []string{S.dummy1, S.dummy2}, line: p.line}
	fn := sub.parseExpr()
	p.c = sub.c
	_ = st
	e := &PlotElem{}
	t := p.cur()
	if t == nil {
		throwAt(p.pos(), "missing data file")
	}
	if t.K == TDOLLAR {
		e.src = t.S
		e.srcKind = 1
		p.c++
	} else {
		v := evalNode(p.parseExpr(), p.pos())
		e.src = v.S
		if e.src == "" {
			e.src = lastDataFile
		}
	}
	parseDataMods(p, e)
	errMode := ""
	for p.isName("yerror") || p.isName("xyerror") || p.isName("errors") || p.isName("zerror") || p.isName("unitweights") {
		errMode = p.tokStr()
		p.c++
		if errMode == "errors" {
			for !p.isName("via") && !p.endOfCmd() {
				p.c++
			}
		}
	}
	if !p.isName("via") {
		throwAt(p.pos(), "Need via and either parameter list or file")
	}
	p.c++
	var params []string
	for {
		t := p.cur()
		if t == nil || t.K != TNAME {
			throwAt(p.pos(), "no parameter specified")
		}
		params = append(params, t.S)
		p.c++
		if p.isOp(",") {
			p.c++
			continue
		}
		break
	}
	// read data
	var xs, ys, ws []float64
	readData(e, 2, func(r Record) {
		if r.brk || !r.ok || r.undef {
			return
		}
		v := r.vals
		if !e.usingSet && len(v) > 2 && errMode == "" {
			v = v[:2]
		}
		if len(v) < 2 {
			return
		}
		x, y := v[0], v[1]
		if rset && (x < math.Min(rlo, rhi) || x > math.Max(rlo, rhi)) {
			return
		}
		w := 1.0
		if len(v) >= 3 && (errMode == "yerror" || (e.usingSet && len(e.using) >= 3 && errMode == "")) {
			w = v[2]
		}
		xs = append(xs, x)
		ys = append(ys, y)
		ws = append(ws, w)
	})
	N := len(xs)
	M := len(params)
	if N == 0 {
		throwNC("No data to fit")
	}
	// initial values
	a := make([]float64, M)
	for i, n := range params {
		v, ok := gvars[n]
		if !ok {
			a[i] = 1
			setVar(n, FltV(1))
		} else {
			a[i] = numify(*v).Real()
		}
	}
	scale := make([]float64, M)
	for i := range a {
		scale[i] = 1
		if S.fitPrescale && a[i] != 0 {
			scale[i] = math.Abs(a[i])
		}
	}
	frames = append(frames, []Value{IntV(0), IntV(0)})
	defer func() { frames = frames[:len(frames)-1] }()
	evalModel := func(par []float64) ([]float64, bool) {
		for i, n := range params {
			setVar(n, FltV(par[i]))
		}
		out := make([]float64, N)
		for k := 0; k < N; k++ {
			frames[len(frames)-1][0] = FltV(xs[k])
			v, ok := tryEval(fn)
			if !ok {
				return nil, false
			}
			out[k] = v.Real()
		}
		return out, true
	}
	chi2 := func(f []float64) float64 {
		s := 0.0
		for k := 0; k < N; k++ {
			d := (ys[k] - f[k]) / ws[k]
			s += d * d
		}
		return s
	}
	jac := func(par []float64, f0 []float64) [][]float64 {
		J := make([][]float64, N)
		for k := range J {
			J[k] = make([]float64, M)
		}
		for j := 0; j < M; j++ {
			h := math.Abs(par[j]) * fitDelta
			if h == 0 {
				h = 1e-30
			}
			pp := append([]float64(nil), par...)
			pp[j] += h
			f1, _ := evalModel(pp)
			for k := 0; k < N; k++ {
				J[k][j] = (f1[k] - f0[k]) / h / ws[k] * scale[j]
			}
		}
		return J
	}
	f0, ok := evalModel(a)
	if !ok {
		throwNC("Undefined value during function evaluation")
	}
	chisq := chi2(f0)
	J := jac(a, f0)
	lambda := 0.0
	for k := 0; k < N; k++ {
		for j := 0; j < M; j++ {
			lambda += J[k][j] * J[k][j]
		}
	}
	lambda = math.Sqrt(lambda / float64(N*M))
	o := func(s string) { stderr.WriteString(s) }
	hdr := "iter      chisq       delta/lim  lambda  "
	for _, n := range params {
		hdr += " " + cfmt("%-13s", n)
	}
	hdr += "\n"
	quiet := S.fitQuiet
	printIter := func(it int, chisq, delta, lambda float64, a []float64) {
		if quiet {
			return
		}
		s := cfmt("%4d %-17.10e %- 10.2e %-9.2e", it, chisq, delta, lambda)
		for _, v := range a {
			s += cfmt(" % 14.6e", v)
		}
		o(s + "\n")
	}
	if !quiet {
		o(hdr)
	}
	printIter(0, chisq, 0, lambda, a)
	iter := 0
	limit := S.fitLimit
	if limit <= 0 {
		limit = 1e-5
	}
	maxIter := S.fitMaxIter
	lastRel := 0.0
	converged := false
	for {
		// solve (J^T J + lambda^2 I) da = J^T r  in scaled space
		r := make([]float64, N)
		for k := 0; k < N; k++ {
			r[k] = (ys[k] - f0[k]) / ws[k]
		}
		A := make([][]float64, M)
		g := make([]float64, M)
		for i := 0; i < M; i++ {
			A[i] = make([]float64, M)
			for j := 0; j < M; j++ {
				s := 0.0
				for k := 0; k < N; k++ {
					s += J[k][i] * J[k][j]
				}
				A[i][j] = s
			}
			A[i][i] += lambda * lambda
			s := 0.0
			for k := 0; k < N; k++ {
				s += J[k][i] * r[k]
			}
			g[i] = s
		}
		da := solveLin(A, g)
		na := make([]float64, M)
		for i := range a {
			na[i] = a[i] + da[i]*scale[i]
		}
		f1, ok := evalModel(na)
		var nchi float64
		if ok {
			nchi = chi2(f1)
		}
		if ok && nchi < chisq {
			rel := (nchi - chisq) / nchi
			iter++
			lambda /= S.fitLambdaFactor
			a = na
			f0 = f1
			oldchi := chisq
			chisq = nchi
			lastRel = rel
			printIter(iter, chisq, rel/limit, lambda, a)
			_ = oldchi
			J = jac(a, f0)
			if -rel < limit {
				converged = true
				break
			}
			if maxIter > 0 && iter >= maxIter {
				break
			}
		} else {
			lambda *= S.fitLambdaFactor
			if lambda > 1e20 {
				break
			}
		}
	}
	for i, n := range params {
		setVar(n, FltV(a[i]))
	}
	// final statistics
	ndf := N - M
	// covariance: inverse of J^T J (unscaled)
	Ju := make([][]float64, N)
	for k := 0; k < N; k++ {
		Ju[k] = make([]float64, M)
		for j := 0; j < M; j++ {
			Ju[k][j] = J[k][j] / scale[j]
		}
	}
	JTJ := make([][]float64, M)
	for i := 0; i < M; i++ {
		JTJ[i] = make([]float64, M)
		for j := 0; j < M; j++ {
			s := 0.0
			for k := 0; k < N; k++ {
				s += Ju[k][i] * Ju[k][j]
			}
			JTJ[i][j] = s
		}
	}
	cov := invert(JTJ)
	stdfit := 0.0
	if ndf > 0 {
		stdfit = math.Sqrt(chisq / float64(ndf))
	}
	errs := make([]float64, M)
	for i := 0; i < M; i++ {
		errs[i] = math.Sqrt(cov[i][i])
		if S.fitErrScaling {
			errs[i] *= stdfit
		}
	}
	if !quiet {
		o(hdr)
		if converged {
			o("\nAfter " + itoa(iter) + " iterations the fit converged.\n")
		} else if maxIter > 0 && iter >= maxIter {
			o("\nIteration limit reached.\n")
		} else {
			o("\nAfter " + itoa(iter) + " iterations the fit failed to converge.\n")
		}
		o("final sum of squares of residuals : " + cfmt("%g", chisq) + "\n")
		o("rel. change during last iteration : " + cfmt("%g", lastRel) + "\n\n")
		o(cfmt("degrees of freedom    (FIT_NDF)                        : %d\n", ndf))
		o("rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : " + cfmt("%g", stdfit) + "\n")
		o("variance of residuals (reduced chisquare) = WSSR/ndf   : " + cfmt("%g", stdfit*stdfit) + "\n\n")
		o("Final set of parameters            Asymptotic Standard Error\n")
		o("=======================            ==========================\n")
		for i, n := range params {
			pct := 0.0
			if a[i] != 0 {
				pct = math.Abs(errs[i]/a[i]) * 100
			}
			o(cfmt("%-15.15s = %-15g  +/- %-12.4g (%.4g%%)\n", n, a[i], errs[i], pct))
		}
		o("\ncorrelation matrix of the fit parameters:\n")
		line := strings.Repeat(" ", 16)
		for _, n := range params {
			line += cfmt("%-7.6s", n)
		}
		o(line + "\n")
		for i, n := range params {
			l := cfmt("%-15.15s", n)
			for j := 0; j <= i; j++ {
				c := cov[i][j] / math.Sqrt(cov[i][i]*cov[j][j])
				l += cfmt("%6.3f ", c)
			}
			o(l + "\n")
		}
	}
	setVar("FIT_NDF", IntV(int64(ndf)))
	setVar("FIT_STDFIT", FltV(stdfit))
	setVar("FIT_WSSR", FltV(chisq))
	setVar("FIT_CONVERGED", BoolV(converged))
	setVar("FIT_ITER", IntV(int64(iter)))
	if S.fitErrVars {
		for i, n := range params {
			setVar(n+"_err", FltV(errs[i]))
		}
	}
}

func solveLin(A [][]float64, b []float64) []float64 {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64(nil), A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		M[c], M[piv] = M[piv], M[c]
		if M[c][c] == 0 {
			continue
		}
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := 0; i < n; i++ {
		if M[i][i] != 0 {
			x[i] = M[i][n] / M[i][i]
		}
	}
	return x
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for i := 0; i < n; i++ {
		e := make([]float64, n)
		e[i] = 1
		col := solveLin(A, e)
		inv[i] = col
	}
	// inv[i] is column i; transpose (symmetric anyway)
	out := make([][]float64, n)
	for i := 0; i < n; i++ {
		out[i] = make([]float64, n)
		for j := 0; j < n; j++ {
			out[i][j] = inv[j][i]
		}
	}
	return out
}

var fitDelta = 1e-3

func init() {
	if s := os.Getenv("FITD"); s != "" {
		fmt.Sscanf(s, "%g", &fitDelta)
	}
}
