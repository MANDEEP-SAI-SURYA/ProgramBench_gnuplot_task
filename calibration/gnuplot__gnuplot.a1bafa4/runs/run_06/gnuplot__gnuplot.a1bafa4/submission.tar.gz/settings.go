package main

import (
	"bufio"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type TicSpec struct {
	on       bool
	auto     bool
	step     float64
	start    float64
	end      float64
	hasStart bool
	hasEnd   bool
	list     []TicItem
	addList  bool
	mirror   bool
	out      bool
	rotate   bool
	format   string
}

type TicItem struct {
	x     float64
	label string
	has   bool
	level int
}

type Axis struct {
	name               string
	min, max           float64
	autoMin, autoMax   bool
	reverse, writeback bool
	log                bool
	base               float64
	format             string
	label              string
	labelOffX, labelOffY float64
	labelRot           float64
	labelRotSet        bool
	tics               TicSpec
	mtics              int // 0 auto(off for linear), -1 off, n
	mticsSet           bool
	isTime             bool
	grid, mgrid        bool
	// current (data) range after plot
	curMin, curMax float64
	zeroAxis       bool
}

type Label struct {
	tag   int
	text  string
	x, y  float64
	coord string
	just  string
	point bool
}

type Arrow struct {
	tag            int
	x1, y1, x2, y2 float64
	nohead         bool
	heads          bool
}

type Settings struct {
	axes                 map[string]*Axis
	samples1, samples2   int
	iso1, iso2           int
	title                string
	titleOffX, titleOffY float64
	styleData            string
	styleFunc            string
	angleDeg             bool
	dummy1, dummy2       string
	parametric           bool
	polar                bool
	zero                 float64
	boxwidth             float64
	boxwidthAbs          bool
	boxwidthSet          bool
	pointsize            float64
	timefmt              string
	offsets              [4]float64
	sizeX, sizeY         float64
	sizeSquare           bool
	sizeRatio            float64
	originX, originY     float64
	viewRotX, viewRotZ   float64
	viewScale, viewScaleZ float64
	viewMap              bool
	dfSep                string
	dfMissing            string
	dfComments           string
	dfHeader             bool
	tableOn              bool
	tableFile            string
	tableDB              string
	tableAppend          bool
	fillStyle            string
	fillDensity          float64
	fillBorder           bool
	fillPattern          int
	border               int
	ticsFront            bool
	key                  KeySet
	termName             string
	termW, termH         int
	termOpts             string
	output               string
	grid                 bool
	labels               []*Label
	arrows               []*Arrow
	hidden3d             bool
	surface              bool
	contour              bool
	xyplane              float64
	xyplaneSet           bool
	clipTwo              bool
	histGap              int
	histStyle            string
	logbase              map[string]float64
	fitLog               string
	fitQuiet             bool
	fitErrVars           bool
	fitCovVars           bool
	fitLimit             float64
	fitMaxIter           int
	fitPrescale          bool
	fitErrScaling        bool
	fitLambdaFactor      float64
	fitStartLambda       float64
	fitVerbose           bool
	fitLogSet            bool
	fitLogFile           string
	decimalsign          string
	bars                 float64
	barsFront            bool
	encoding             string
	lmargin, rmargin, tmargin, bmargin float64
	multiplot            bool
	minusSign            bool
	jitter               bool
	ticscale             float64
	mticscale            float64
	mapping              string
}

type KeySet struct {
	on       bool
	vpos     string // top bottom center
	hpos     string // left right center
	inside   bool
	outside  bool
	vertical bool
	just     string // Right Left
	reverse  bool
	invert   bool
	box      bool
	title    string
	samplen  float64
	spacing  float64
	width    float64
	height   float64
	enhanced bool
	opaque   bool
	autotitle bool
	columnhead bool
	maxcols  int
	maxrows  int
	fixed    bool
	atSet    bool
	atX, atY float64
}

var S *Settings

var axisNames = []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"}

func newAxis(n string) *Axis {
	a := &Axis{name: n, min: -10, max: 10, autoMin: true, autoMax: true, base: 10, format: "% h"}
	if n == "t" || n == "u" || n == "v" {
		a.autoMin, a.autoMax = false, false
		a.min, a.max = -5, 5
		if n == "t" {
			a.min, a.max = 0, 2*math.Pi
		}
	}
	if n == "r" {
		a.min, a.max = 0, 10
		a.autoMin = false
	}
	a.tics = TicSpec{on: n == "x" || n == "y" || n == "z" || n == "cb", auto: true, mirror: n != "z" && n != "x2" && n != "y2", step: 0}
	a.mtics = 0
	a.curMin, a.curMax = -10, 10
	return a
}

func initSettings() {
	S = &Settings{}
	S.axes = map[string]*Axis{}
	for _, n := range axisNames {
		S.axes[n] = newAxis(n)
	}
	S.samples1, S.samples2 = 100, 100
	S.iso1, S.iso2 = 10, 10
	S.styleData = "points"
	S.styleFunc = "lines"
	S.dummy1, S.dummy2 = "x", "y"
	S.zero = 1e-8
	S.boxwidth = -1
	S.pointsize = 1
	S.timefmt = "%d/%m/%y,%H:%M"
	S.sizeX, S.sizeY = 1, 1
	S.viewRotX, S.viewRotZ, S.viewScale, S.viewScaleZ = 60, 30, 1, 1
	S.dfComments = "#"
	S.fillStyle = "empty"
	S.fillBorder = true
	S.fillDensity = 1
	S.border = 31
	S.key = KeySet{on: true, vpos: "top", hpos: "right", inside: true, vertical: true, just: "Right", samplen: 4, spacing: 1, enhanced: true, autotitle: true}
	if S.termName == "" {
		S.termName = "unknown"
	}
	S.surface = true
	S.histGap = 2
	S.histStyle = "clustered"
	S.fitErrVars = true
	S.fitLimit = 1e-5
	S.fitPrescale = true
	S.fitErrScaling = true
	S.fitLambdaFactor = 10
	S.decimalsign = ""
	S.bars = 1
	S.barsFront = true
	S.lmargin, S.rmargin, S.tmargin, S.bmargin = -1, -1, -1, -1
	S.ticscale, S.mticscale = 1, 0.5
	S.mapping = "cartesian"
	S.xyplane = 0.5
	angleDeg = false
}

func resetSettings() {
	tn, tw, th, out, to := S.termName, S.termW, S.termH, S.output, S.termOpts
	initSettings()
	S.termName, S.termW, S.termH, S.output, S.termOpts = tn, tw, th, out, to
}

// option matching: name with min abbreviation e.g. "xr$ange"
func optMatch(tok string, pat string) bool {
	i := strings.IndexByte(pat, '$')
	full := strings.Replace(pat, "$", "", 1)
	if i < 0 {
		return tok == full
	}
	return len(tok) >= i && strings.HasPrefix(full, tok)
}

func (p *Parser) tokStr() string {
	t := p.cur()
	if t == nil || t.K == TNL {
		return ""
	}
	return t.S
}

func (p *Parser) evalNum() float64 {
	st := p.pos()
	v := evalNode(p.parseExpr(), st)
	return numify(v).Real()
}
func (p *Parser) evalStr() string {
	st := p.pos()
	v := evalNode(p.parseExpr(), st)
	if v.T != STR {
		throwAt(st, "expecting string")
	}
	return v.S
}
func (p *Parser) isStrStart() bool {
	t := p.cur()
	if t == nil {
		return false
	}
	if t.K == TSTR {
		return true
	}
	if t.K == TNAME {
		if v, ok := gvars[t.S]; ok && v.T == STR {
			return true
		}
		if t.S == "sprintf" || t.S == "gprintf" {
			return true
		}
	}
	return false
}

func skipToEnd(p *Parser) {
	for !p.endOfCmd() {
		p.c++
	}
}

func rangeAxisName(tok string) string {
	if strings.HasSuffix(tok, "range") {
		n := strings.TrimSuffix(tok, "range")
		if _, ok := S.axes[n]; ok {
			return n
		}
	}
	for _, n := range axisNames {
		if len(tok) > len(n) && optMatch(tok[len(n):], "r$ange") && strings.HasPrefix(tok, n) {
			return n
		}
	}
	return ""
}

// parse [a:b] range
func parseRange(p *Parser, a *Axis) {
	p.expectOp("[", "expecting '['")
	if !p.isOp(":") && !p.isOp("]") {
		if p.isOp("*") {
			p.c++
			a.autoMin = true
		} else {
			st := p.pos()
			v := axisValueFromExpr(p, a)
			_ = st
			a.min = v
			a.autoMin = false
		}
	}
	if p.isOp(":") {
		p.c++
		if !p.isOp("]") {
			if p.isOp("*") {
				p.c++
				a.autoMax = true
			} else {
				a.max = axisValueFromExpr(p, a)
				a.autoMax = false
			}
		}
	}
	p.expectOp("]", "expecting ']'")
}

func axisValueFromExpr(p *Parser, a *Axis) float64 {
	st := p.pos()
	n := p.parseExpr()
	v := evalNode(n, st)
	if v.T == STR {
		if a.isTime {
			t, ok := gpStrptime(S.timefmt, v.S)
			if ok {
				return t
			}
		}
		return numify(v).Real()
	}
	if v.T == CMPLX && v.Im != 0 {
		throwAt(st, "constant expression required")
	}
	return v.Real()
}

func cmdSet(p *Parser) {
	t := p.cur()
	if t == nil || t.K == TNL || (t.K == TOP && t.S == ";") {
		throwAt(p.pos(), "unrecognized option - see 'help set'.")
	}
	opt := t.S
	optPos := t.Pos
	if t.K != TNAME {
		throwAt(t.Pos, "unrecognized option - see 'help set'.")
	}
	p.c++
	if n := rangeAxisName(opt); n != "" {
		a := S.axes[n]
		if p.isOp("[") {
			parseRange(p, a)
		}
		for !p.endOfCmd() {
			w := p.tokStr()
			p.c++
			switch {
			case optMatch(w, "rev$erse"):
				a.reverse = true
			case optMatch(w, "norev$erse"):
				a.reverse = false
			case optMatch(w, "wri$teback"):
				a.writeback = true
			case optMatch(w, "nowri$teback"):
				a.writeback = false
			case w == "restore":
			default:
				p.c--
				throwAt(p.pos(), "unrecognized option - see 'help set'.")
			}
		}
		return
	}
	// axis-prefixed options
	for _, an := range []string{"x2", "y2", "x", "y", "z", "cb", "r"} {
		if strings.HasPrefix(opt, an) {
			rest := opt[len(an):]
			a := S.axes[an]
			switch {
			case optMatch(rest, "l$abel"):
				setLabel(p, &a.label, &a.labelOffX, &a.labelOffY, a)
				return
			case optMatch(rest, "tic$s"):
				setTics(p, a)
				return
			case optMatch(rest, "mtic$s") || (rest == "mtics"):
				a.mticsSet = true
				if p.endOfCmd() {
					a.mtics = 0
					a.mticsSet = true
				} else {
					a.mtics = int(p.evalNum())
				}
				return
			case optMatch(rest, "da$ta"):
				if p.isName("time") {
					p.c++
					a.isTime = true
				} else {
					a.isTime = false
					skipToEnd(p)
				}
				return
			case optMatch(rest, "zeroa$xis"):
				a.zeroAxis = true
				skipToEnd(p)
				return
			}
		}
	}
	switch {
	case optMatch(opt, "sa$mples"):
		S.samples1 = int(p.evalNum())
		S.samples2 = S.samples1
		if p.isOp(",") {
			p.c++
			S.samples2 = int(p.evalNum())
		}
	case optMatch(opt, "isosa$mples"):
		S.iso1 = int(p.evalNum())
		S.iso2 = S.iso1
		if p.isOp(",") {
			p.c++
			S.iso2 = int(p.evalNum())
		}
	case optMatch(opt, "tit$le"):
		setLabel(p, &S.title, &S.titleOffX, &S.titleOffY, nil)
	case optMatch(opt, "st$yle"):
		setStyle(p)
	case optMatch(opt, "form$at"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		if t := p.cur(); t != nil && t.K == TNAME {
			var sel []string
			s := t.S
			for len(s) > 0 {
				matched := false
				for _, an := range []string{"x2", "y2", "cb", "x", "y", "z", "r"} {
					if strings.HasPrefix(s, an) {
						sel = append(sel, an)
						s = s[len(an):]
						matched = true
						break
					}
				}
				if !matched {
					break
				}
			}
			p.c++
			axes = sel
		}
		f := "% h"
		if !p.endOfCmd() {
			f = p.evalStr()
		}
		for !p.endOfCmd() {
			p.c++
		}
		for _, an := range axes {
			S.axes[an].format = f
		}
	case optMatch(opt, "log$scale"):
		axes, base := parseLogAxes(p)
		for _, an := range axes {
			S.axes[an].log = true
			S.axes[an].base = base
		}
	case optMatch(opt, "nolog$scale"):
		axes, _ := parseLogAxes(p)
		for _, an := range axes {
			S.axes[an].log = false
		}
	case optMatch(opt, "an$gles"):
		w := p.tokStr()
		p.c++
		if optMatch(w, "d$egrees") {
			S.angleDeg = true
		} else {
			S.angleDeg = false
		}
		angleDeg = S.angleDeg
	case optMatch(opt, "du$mmy"):
		if !p.isOp(",") {
			S.dummy1 = p.tokStr()
			p.c++
		}
		if p.isOp(",") {
			p.c++
			S.dummy2 = p.tokStr()
			p.c++
		}
	case optMatch(opt, "pa$rametric"):
		S.parametric = true
	case optMatch(opt, "nopa$rametric"):
		S.parametric = false
	case optMatch(opt, "po$lar"):
		S.polar = true
	case optMatch(opt, "zero"):
		S.zero = p.evalNum()
	case optMatch(opt, "bo$xwidth"):
		S.boxwidthSet = true
		if p.endOfCmd() {
			S.boxwidth = -1
			S.boxwidthAbs = false
			return
		}
		S.boxwidth = p.evalNum()
		S.boxwidthAbs = true
		if p.isName("relative") {
			S.boxwidthAbs = false
			p.c++
		} else if p.isName("absolute") {
			p.c++
		}
	case optMatch(opt, "poi$ntsize") || optMatch(opt, "ps"):
		S.pointsize = p.evalNum()
	case optMatch(opt, "timef$mt"):
		S.timefmt = p.evalStr()
	case optMatch(opt, "offset$s"):
		for i := 0; i < 4 && !p.endOfCmd(); i++ {
			if p.isName("graph") || p.isName("first") {
				p.c++
			}
			S.offsets[i] = p.evalNum()
			if p.isOp(",") {
				p.c++
			}
		}
	case optMatch(opt, "si$ze"):
		for !p.endOfCmd() {
			if p.isName("square") {
				S.sizeSquare = true
				p.c++
				continue
			}
			if p.isName("nosquare") {
				S.sizeSquare = false
				p.c++
				continue
			}
			if p.isName("ratio") {
				p.c++
				S.sizeRatio = p.evalNum()
				continue
			}
			if p.isName("noratio") {
				p.c++
				S.sizeRatio = 0
				continue
			}
			S.sizeX = p.evalNum()
			if p.isOp(",") {
				p.c++
				S.sizeY = p.evalNum()
			}
		}
	case optMatch(opt, "or$igin"):
		S.originX = p.evalNum()
		p.expectOp(",", "',' expected")
		S.originY = p.evalNum()
	case optMatch(opt, "vi$ew"):
		if p.isName("map") {
			p.c++
			S.viewMap = true
			S.viewRotX, S.viewRotZ = 0, 0
			return
		}
		S.viewMap = false
		vals := []*float64{&S.viewRotX, &S.viewRotZ, &S.viewScale, &S.viewScaleZ}
		for i := 0; i < 4 && !p.endOfCmd(); i++ {
			if p.isOp(",") {
				p.c++
				continue
			}
			*vals[i] = p.evalNum()
			if p.isOp(",") {
				p.c++
			}
		}
	case optMatch(opt, "da$tafile"):
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "sep$arator"):
			if p.endOfCmd() || p.isName("whitespace") {
				S.dfSep = ""
				if !p.endOfCmd() {
					p.c++
				}
			} else if p.isName("tab") {
				S.dfSep = "\t"
				p.c++
			} else if p.isName("comma") {
				S.dfSep = ","
				p.c++
			} else {
				S.dfSep = p.evalStr()
			}
		case optMatch(w, "mis$sing"):
			if p.endOfCmd() {
				S.dfMissing = ""
			} else {
				S.dfMissing = p.evalStr()
			}
		case optMatch(w, "com$mentschars"):
			if p.endOfCmd() {
				S.dfComments = "#"
			} else {
				S.dfComments = p.evalStr()
			}
		case optMatch(w, "columnhead$ers"):
			S.dfHeader = true
		case optMatch(w, "nocolumnhead$ers"):
			S.dfHeader = false
		default:
			skipToEnd(p)
		}
	case optMatch(opt, "tab$le"):
		S.tableOn = true
		S.tableFile = ""
		S.tableDB = ""
		S.tableAppend = false
		if t := p.cur(); t != nil && t.K == TDOLLAR {
			S.tableDB = t.S
			p.c++
			if p.isName("append") {
				p.c++
			} else {
				datablocks[S.tableDB] = nil
			}
			datablockOrder(S.tableDB)
		} else if !p.endOfCmd() {
			S.tableFile = p.evalStr()
			if p.isName("append") {
				p.c++
				S.tableAppend = true
			} else {
				os.WriteFile(S.tableFile, nil, 0644)
			}
		}
		skipToEnd(p)
	case optMatch(opt, "pr$int"):
		closePrintFile()
		if p.endOfCmd() {
			return
		}
		if t := p.cur(); t != nil && t.K == TDOLLAR {
			printDB = t.S
			p.c++
			if p.isName("append") {
				p.c++
			} else {
				datablocks[printDB] = nil
			}
			return
		}
		fn := p.evalStr()
		app := false
		if p.isName("append") {
			p.c++
			app = true
		}
		if fn == "-" {
			printToStdout = true
			printFileName = "<stdout>"
			return
		}
		flag := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flag = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(fn, flag, 0644)
		if err != nil {
			throwNC("cannot open print output file")
		}
		printFile = f
		printW = bufio.NewWriter(f)
		printFileName = fn
	case optMatch(opt, "fit"):
		setFit(p)
	case optMatch(opt, "te$rminal"):
		setTerminal(p)
	case optMatch(opt, "o$utput"):
		if p.endOfCmd() {
			S.output = ""
		} else {
			S.output = p.evalStr()
		}
		openOutput()
	case optMatch(opt, "k$ey"):
		setKey(p)
	case optMatch(opt, "nok$ey"):
		S.key.on = false
	case optMatch(opt, "g$rid"):
		S.grid = true
		any := false
		for !p.endOfCmd() {
			w := p.tokStr()
			p.c++
			for _, an := range []string{"x", "y", "z", "x2", "y2", "cb"} {
				if w == an+"tics" {
					S.axes[an].grid = true
					any = true
				}
				if w == "m"+an+"tics" {
					S.axes[an].mgrid = true
					any = true
				}
				if w == "no"+an+"tics" {
					S.axes[an].grid = false
					any = true
				}
			}
		}
		if !any {
			S.axes["x"].grid = true
			S.axes["y"].grid = true
		}
	case optMatch(opt, "bor$der"):
		if p.endOfCmd() {
			S.border = 31
		} else {
			if t := p.cur(); t.K == TNUM || t.K == TOP {
				S.border = int(p.evalNum())
			}
			skipToEnd(p)
		}
	case optMatch(opt, "nobor$der"):
		S.border = 0
	case optMatch(opt, "tic$s"):
		for !p.endOfCmd() {
			w := p.tokStr()
			p.c++
			switch {
			case w == "out" || w == "outwards":
				for _, a := range S.axes {
					a.tics.out = true
				}
			case w == "in" || w == "inwards":
				for _, a := range S.axes {
					a.tics.out = false
				}
			case w == "front":
				S.ticsFront = true
			case w == "back":
				S.ticsFront = false
			case optMatch(w, "sc$ale"):
				S.ticscale = p.evalNum()
				if p.isOp(",") {
					p.c++
					S.mticscale = p.evalNum()
				} else {
					S.mticscale = S.ticscale / 2
				}
			}
		}
	case optMatch(opt, "mxt$ics"):
		S.axes["x"].mtics = int(p.evalNum())
	case optMatch(opt, "la$bel"):
		setLabelObj(p)
	case optMatch(opt, "ar$row"):
		setArrow(p)
	case optMatch(opt, "hid$den3d"):
		S.hidden3d = true
		skipToEnd(p)
	case optMatch(opt, "su$rface"):
		S.surface = true
		skipToEnd(p)
	case optMatch(opt, "cont$ours"):
		S.contour = true
		skipToEnd(p)
	case optMatch(opt, "xyp$lane"):
		if p.isName("at") {
			p.c++
		}
		if p.isName("relative") {
			p.c++
		}
		S.xyplane = p.evalNum()
	case optMatch(opt, "ticsl$evel"):
		S.xyplane = p.evalNum()
	case optMatch(opt, "mar$gins"):
		vals := []*float64{&S.lmargin, &S.rmargin, &S.bmargin, &S.tmargin}
		for i := 0; i < 4 && !p.endOfCmd(); i++ {
			*vals[i] = p.evalNum()
			if p.isOp(",") {
				p.c++
			}
		}
	case optMatch(opt, "lmar$gin"):
		S.lmargin = optNum(p)
	case optMatch(opt, "rmar$gin"):
		S.rmargin = optNum(p)
	case optMatch(opt, "tmar$gin"):
		S.tmargin = optNum(p)
	case optMatch(opt, "bmar$gin"):
		S.bmargin = optNum(p)
	case optMatch(opt, "multi$plot"):
		setMultiplot(p)
	case optMatch(opt, "dec$imalsign"):
		if p.endOfCmd() {
			S.decimalsign = ""
		} else if p.isName("locale") {
			skipToEnd(p)
		} else {
			S.decimalsign = p.evalStr()
		}
	case optMatch(opt, "enc$oding"):
		skipToEnd(p)
	case optMatch(opt, "bar$s"):
		skipToEnd(p)
	case optMatch(opt, "cl$ip"), optMatch(opt, "loadpath"), optMatch(opt, "fontpath"), optMatch(opt, "colors$equence"), optMatch(opt, "pal$ette"), optMatch(opt, "pm3d"), optMatch(opt, "cbr$ange"), optMatch(opt, "colorb$ox"), optMatch(opt, "obj$ect"), optMatch(opt, "lin$etype"), optMatch(opt, "mou$se"), optMatch(opt, "term$options"), optMatch(opt, "cntrp$aram"), optMatch(opt, "cntrl$abel"), optMatch(opt, "dgrid3d"), optMatch(opt, "map$ping"), optMatch(opt, "minus$sign"), optMatch(opt, "micro"), optMatch(opt, "jitter"), optMatch(opt, "theta"), optMatch(opt, "rtics"), optMatch(opt, "raxis"), optMatch(opt, "psdir"), optMatch(opt, "historysize"), optMatch(opt, "his$tory"), optMatch(opt, "auto$scale"), optMatch(opt, "noauto$scale"), optMatch(opt, "for$mat"), optMatch(opt, "overflow"), optMatch(opt, "walls"), optMatch(opt, "pixmap"), optMatch(opt, "rgbmax"), optMatch(opt, "isotropic"), optMatch(opt, "link"), optMatch(opt, "nonlinear"), optMatch(opt, "errorbars"), optMatch(opt, "monochrome"), optMatch(opt, "color"), optMatch(opt, "ve$rsion"), optMatch(opt, "c$olorbox"):
		if optMatch(opt, "auto$scale") {
			setAutoscale(p, true)
			return
		}
		if optMatch(opt, "noauto$scale") {
			setAutoscale(p, false)
			return
		}
		skipToEnd(p)
	default:
		throwAt(optPos, "unrecognized option - see 'help set'.")
	}
}

func setAutoscale(p *Parser, on bool) {
	if p.endOfCmd() {
		for _, a := range S.axes {
			if a.name == "t" || a.name == "u" || a.name == "v" || a.name == "r" {
				continue
			}
			a.autoMin, a.autoMax = on, on
		}
		return
	}
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		for _, an := range []string{"x2", "y2", "cb", "x", "y", "z"} {
			if strings.HasPrefix(w, an) {
				a := S.axes[an]
				r := w[len(an):]
				switch r {
				case "", "fix":
					a.autoMin, a.autoMax = on, on
				case "min", "fixmin":
					a.autoMin = on
				case "max", "fixmax":
					a.autoMax = on
				}
				break
			}
		}
	}
}

func datablockOrder(name string) {}

func optNum(p *Parser) float64 {
	if p.endOfCmd() {
		return -1
	}
	if p.isName("at") {
		p.c++
		if p.isName("screen") {
			p.c++
		}
	}
	return p.evalNum()
}

func parseLogAxes(p *Parser) ([]string, float64) {
	var axes []string
	base := 10.0
	if p.endOfCmd() {
		return []string{"x", "y", "z", "x2", "y2", "cb"}, 10
	}
	t := p.cur()
	if t.K == TNAME {
		s := t.S
		for len(s) > 0 {
			matched := false
			for _, an := range []string{"x2", "y2", "cb", "x", "y", "z", "r"} {
				if strings.HasPrefix(s, an) {
					axes = append(axes, an)
					s = s[len(an):]
					matched = true
					break
				}
			}
			if !matched {
				throwAt(t.Pos, "unknown axis")
			}
		}
		p.c++
	}
	if !p.endOfCmd() {
		base = p.evalNum()
	}
	return axes, base
}

func setLabel(p *Parser, text *string, ox, oy *float64, a *Axis) {
	if p.endOfCmd() {
		*text = ""
		return
	}
	if p.isStrStart() || p.cur().K == TSTR {
		*text = p.evalStr()
	}
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "off$set"):
			if p.isName("character") || p.isName("char") {
				p.c++
			}
			*ox = p.evalNum()
			if p.isOp(",") {
				p.c++
				*oy = p.evalNum()
			}
			if p.isOp(",") {
				p.c++
				p.evalNum()
			}
		case optMatch(w, "rot$ate"):
			if a != nil {
				a.labelRotSet = true
				a.labelRot = 90
				if p.isName("by") {
					p.c++
					a.labelRot = p.evalNum()
				} else if p.isName("parallel") {
					p.c++
				}
			}
		case optMatch(w, "norot$ate"):
			if a != nil {
				a.labelRotSet = true
				a.labelRot = 0
			}
		case w == "font", optMatch(w, "tc"), optMatch(w, "textc$olor"):
			if !p.endOfCmd() {
				if p.isName("rgb") || p.isName("lt") || p.isName("linetype") {
					p.c++
				}
				if !p.endOfCmd() {
					p.c++
				}
			}
		}
	}
}

func setTics(p *Parser, a *Axis) {
	a.tics.on = true
	if p.endOfCmd() {
		a.tics.auto = true
		a.tics.list = nil
		return
	}
	for !p.endOfCmd() {
		t := p.cur()
		if t.K == TOP && t.S == "(" {
			p.c++
			if !a.tics.addList {
				a.tics.list = nil
			}
			for !p.isOp(")") {
				var it TicItem
				if p.isStrStart() {
					it.label = p.evalStr()
					it.has = true
				}
				it.x = axisValueFromExpr(p, a)
				if !p.isOp(",") && !p.isOp(")") {
					it.level = int(p.evalNum())
				}
				a.tics.list = append(a.tics.list, it)
				if p.isOp(",") {
					p.c++
				}
			}
			p.c++
			if !a.tics.addList {
				a.tics.auto = false
			}
			continue
		}
		if t.K == TNAME {
			w := t.S
			p.c++
			switch {
			case w == "add":
				a.tics.addList = true
			case optMatch(w, "mi$rror"):
				a.tics.mirror = true
			case optMatch(w, "nomi$rror"):
				a.tics.mirror = false
			case w == "out":
				a.tics.out = true
			case w == "in":
				a.tics.out = false
			case optMatch(w, "rot$ate"):
				a.tics.rotate = true
				if p.isName("by") {
					p.c++
					p.evalNum()
				}
			case optMatch(w, "norot$ate"):
				a.tics.rotate = false
			case optMatch(w, "autof$req"):
				a.tics.auto = true
				a.tics.step = 0
				a.tics.list = nil
			case w == "format":
				a.format = p.evalStr()
			case w == "border", w == "axis", w == "nooutrange", w == "front", w == "back", w == "left", w == "right", w == "center", w == "autojustify":
			case w == "offset":
				p.evalNum()
				for p.isOp(",") {
					p.c++
					p.evalNum()
				}
			case w == "scale":
				p.evalNum()
				if p.isOp(",") {
					p.c++
					p.evalNum()
				}
			case w == "font", w == "tc", w == "textcolor":
				p.c++
			default:
				p.c--
				st := p.pos()
				_ = st
				v := axisValueFromExpr(p, a)
				ticSeries(p, a, v)
			}
			continue
		}
		v := axisValueFromExpr(p, a)
		ticSeries(p, a, v)
	}
}

func ticSeries(p *Parser, a *Axis, v float64) {
	a.tics.list = nil
	a.tics.auto = false
	if p.isOp(",") {
		p.c++
		v2 := axisValueFromExpr(p, a)
		a.tics.start = v
		a.tics.hasStart = true
		a.tics.step = v2
		a.tics.hasEnd = false
		if p.isOp(",") {
			p.c++
			a.tics.end = axisValueFromExpr(p, a)
			a.tics.hasEnd = true
		}
	} else {
		a.tics.step = v
		a.tics.hasStart = false
		a.tics.hasEnd = false
	}
}

func setStyle(p *Parser) {
	w := p.tokStr()
	p.c++
	switch {
	case optMatch(w, "d$ata"):
		S.styleData = parseStyleName(p)
	case optMatch(w, "f$unction"):
		S.styleFunc = parseStyleName(p)
	case optMatch(w, "fi$ll"):
		for !p.endOfCmd() {
			x := p.tokStr()
			p.c++
			switch {
			case optMatch(x, "s$olid"):
				S.fillStyle = "solid"
				S.fillDensity = 1
				if t := p.cur(); t != nil && (t.K == TNUM) {
					S.fillDensity = p.evalNum()
				}
			case optMatch(x, "e$mpty"):
				S.fillStyle = "empty"
			case optMatch(x, "p$attern"):
				S.fillStyle = "pattern"
				if t := p.cur(); t != nil && (t.K == TNUM) {
					S.fillPattern = int(p.evalNum())
				}
			case optMatch(x, "tr$ansparent"):
			case optMatch(x, "bo$rder"):
				S.fillBorder = true
				if t := p.cur(); t != nil && (t.K == TNUM) {
					p.evalNum()
				}
				if p.isName("lt") || p.isName("lc") || p.isName("linecolor") || p.isName("linetype") {
					p.c++
					if p.isName("rgb") {
						p.c++
					}
					p.c++
				}
			case optMatch(x, "nobo$rder"):
				S.fillBorder = false
			}
		}
	case optMatch(w, "hist$ogram"):
		for !p.endOfCmd() {
			x := p.tokStr()
			p.c++
			switch {
			case optMatch(x, "clu$stered"):
				S.histStyle = "clustered"
				if p.isName("gap") {
					p.c++
					S.histGap = int(p.evalNum())
				}
			case optMatch(x, "rows$tacked"):
				S.histStyle = "rowstacked"
			case optMatch(x, "columns$tacked"):
				S.histStyle = "columnstacked"
			case x == "gap":
				S.histGap = int(p.evalNum())
			}
		}
	default:
		skipToEnd(p)
	}
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xyerrorb$ars", "errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "b$oxes", "boxerrorb$ars", "boxxy$errorbars", "fin$ancebars", "candle$sticks", "vec$tors", "his$tograms", "filledc$urves", "fillst$eps", "lab$els", "boxp$lot", "circ$les", "ell$ipses", "pm3d", "image", "rgbi$mage", "zerror$fill", "table", "arrows", "sur$face", "parallel$axes", "spider$plot", "polygons", "isosurface", "rgba$lpha", "cand$lesticks"}

func parseStyleName(p *Parser) string {
	w := p.tokStr()
	for _, s := range styleNames {
		if optMatch(w, s) {
			p.c++
			full := strings.Replace(s, "$", "", 1)
			if full == "lp" {
				full = "linespoints"
			}
			if full == "cand" {
				full = "candlesticks"
			}
			return full
		}
	}
	throwAt(p.pos(), "unrecognized plot type")
	return ""
}

func setKey(p *Parser) {
	S.key.on = true
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "t$op"):
			S.key.vpos = "top"
		case optMatch(w, "b$ottom"):
			S.key.vpos = "bottom"
		case optMatch(w, "l$eft"):
			S.key.hpos = "left"
		case optMatch(w, "r$ight"):
			S.key.hpos = "right"
		case optMatch(w, "c$enter"):
			S.key.hpos = "center"
			S.key.vpos = "center"
		case optMatch(w, "ins$ide"):
			S.key.inside = true
			S.key.outside = false
		case optMatch(w, "o$utside"):
			S.key.inside = false
			S.key.outside = true
		case optMatch(w, "bm$argin"):
			S.key.inside = false
			S.key.vpos = "bottom"
		case optMatch(w, "tm$argin"):
			S.key.inside = false
			S.key.vpos = "top"
		case optMatch(w, "lm$argin"):
			S.key.inside = false
			S.key.hpos = "left"
		case optMatch(w, "rm$argin"):
			S.key.inside = false
			S.key.hpos = "right"
		case optMatch(w, "vert$ical"):
			S.key.vertical = true
		case optMatch(w, "hor$izontal"):
			S.key.vertical = false
		case optMatch(w, "Left"):
			S.key.just = "Left"
		case optMatch(w, "Right"):
			S.key.just = "Right"
		case optMatch(w, "rev$erse"):
			S.key.reverse = true
		case optMatch(w, "norev$erse"):
			S.key.reverse = false
		case optMatch(w, "inv$ert"):
			S.key.invert = true
		case optMatch(w, "noinv$ert"):
			S.key.invert = false
		case optMatch(w, "box"):
			S.key.box = true
			for p.isName("lt") || p.isName("lw") || p.isName("lc") || p.isName("linewidth") || p.isName("linetype") || p.isName("dt") {
				p.c++
				p.evalNum()
			}
		case optMatch(w, "nobox"):
			S.key.box = false
		case optMatch(w, "samp$len"):
			S.key.samplen = p.evalNum()
		case optMatch(w, "spac$ing"):
			S.key.spacing = p.evalNum()
		case optMatch(w, "wid$th"):
			S.key.width = p.evalNum()
		case optMatch(w, "hei$ght"):
			S.key.height = p.evalNum()
		case optMatch(w, "tit$le"):
			if p.isStrStart() {
				S.key.title = p.evalStr()
			} else {
				S.key.title = ""
			}
		case optMatch(w, "enh$anced"):
			S.key.enhanced = true
		case optMatch(w, "noenh$anced"):
			S.key.enhanced = false
		case optMatch(w, "opaque"):
			S.key.opaque = true
		case optMatch(w, "noopaque"):
			S.key.opaque = false
		case optMatch(w, "autot$itle"):
			S.key.autotitle = true
			if p.isName("columnheader") || p.isName("columnhead") {
				p.c++
				S.key.columnhead = true
			}
		case optMatch(w, "noautot$itle"):
			S.key.autotitle = false
		case optMatch(w, "at"):
			S.key.atSet = true
			S.key.atX = p.evalNum()
			p.expectOp(",", "',' expected")
			S.key.atY = p.evalNum()
		case optMatch(w, "maxc$ols"):
			if p.isName("auto") {
				p.c++
			} else {
				S.key.maxcols = int(p.evalNum())
			}
		case optMatch(w, "maxr$ows"):
			if p.isName("auto") {
				p.c++
			} else {
				S.key.maxrows = int(p.evalNum())
			}
		case w == "on":
			S.key.on = true
		case w == "off":
			S.key.on = false
		case w == "default":
			S.key = KeySet{on: true, vpos: "top", hpos: "right", inside: true, vertical: true, just: "Right", samplen: 4, spacing: 1, enhanced: true, autotitle: true}
		case w == "fixed":
		case w == "font", w == "tc", w == "textcolor":
			p.c++
		}
	}
}

func setLabelObj(p *Parser) {
	l := &Label{tag: 0, just: "left", coord: "first"}
	if t := p.cur(); t != nil && t.K == TNUM {
		l.tag = int(t.IV)
		p.c++
	}
	if l.tag == 0 {
		mx := 0
		for _, o := range S.labels {
			if o.tag > mx {
				mx = o.tag
			}
		}
		l.tag = mx + 1
	}
	// replace existing
	var existing *Label
	for _, o := range S.labels {
		if o.tag == l.tag {
			existing = o
		}
	}
	if existing != nil {
		l = existing
	}
	if p.isStrStart() {
		l.text = p.evalStr()
	}
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch {
		case w == "at":
			for _, c := range []string{"first", "graph", "screen", "character"} {
				if p.isName(c) {
					l.coord = c
					p.c++
				}
			}
			l.x = p.evalNum()
			p.expectOp(",", "',' expected")
			if p.isName("first") || p.isName("graph") || p.isName("screen") {
				p.c++
			}
			l.y = p.evalNum()
			if p.isOp(",") {
				p.c++
				p.evalNum()
			}
		case optMatch(w, "l$eft"):
			l.just = "left"
		case optMatch(w, "r$ight"):
			l.just = "right"
		case optMatch(w, "c$entre") || optMatch(w, "c$enter"):
			l.just = "center"
		case optMatch(w, "p$oint"):
			l.point = true
		case w == "font", w == "tc", w == "textcolor", w == "offset":
			if !p.endOfCmd() {
				p.c++
			}
		}
	}
	if existing == nil {
		S.labels = append(S.labels, l)
		sort.Slice(S.labels, func(i, j int) bool { return S.labels[i].tag < S.labels[j].tag })
	}
}

func setArrow(p *Parser) {
	a := &Arrow{}
	if t := p.cur(); t != nil && t.K == TNUM {
		a.tag = int(t.IV)
		p.c++
	}
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch w {
		case "from":
			for p.isName("first") || p.isName("graph") || p.isName("screen") {
				p.c++
			}
			a.x1 = p.evalNum()
			p.expectOp(",", "',' expected")
			a.y1 = p.evalNum()
		case "to":
			for p.isName("first") || p.isName("graph") || p.isName("screen") {
				p.c++
			}
			a.x2 = p.evalNum()
			p.expectOp(",", "',' expected")
			a.y2 = p.evalNum()
		case "nohead":
			a.nohead = true
		case "heads":
			a.heads = true
		}
	}
	S.arrows = append(S.arrows, a)
}

func setFit(p *Parser) {
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "log$file"):
			S.fitLogSet = true
			if p.endOfCmd() || !p.isStrStart() {
				S.fitLogFile = ""
			} else {
				S.fitLogFile = p.evalStr()
			}
		case optMatch(w, "nolog$file"):
			S.fitLog = "none"
		case optMatch(w, "q$uiet"):
			S.fitQuiet = true
			S.fitVerbose = false
		case optMatch(w, "noq$uiet"):
			S.fitQuiet = false
		case optMatch(w, "v$erbose"):
			S.fitVerbose = true
			S.fitQuiet = false
		case optMatch(w, "results"):
			S.fitQuiet = false
			S.fitVerbose = false
		case optMatch(w, "brief"):
			S.fitQuiet = false
			S.fitVerbose = false
		case optMatch(w, "errorv$ariables"):
			S.fitErrVars = true
		case optMatch(w, "noerrorv$ariables"):
			S.fitErrVars = false
		case optMatch(w, "covariancev$ariables"):
			S.fitCovVars = true
		case optMatch(w, "nocovariancev$ariables"):
			S.fitCovVars = false
		case optMatch(w, "errors$caling"):
			S.fitErrScaling = true
		case optMatch(w, "noerrors$caling"):
			S.fitErrScaling = false
		case optMatch(w, "pre$scale"):
			S.fitPrescale = true
		case optMatch(w, "nopre$scale"):
			S.fitPrescale = false
		case w == "limit":
			if p.endOfCmd() {
				S.fitLimit = 1e-5
			} else {
				S.fitLimit = p.evalNum()
			}
		case w == "maxiter":
			if p.endOfCmd() {
				S.fitMaxIter = 0
			} else {
				S.fitMaxIter = int(p.evalNum())
			}
		case w == "start-lambda":
			S.fitStartLambda = p.evalNum()
		case w == "lambda-factor":
			S.fitLambdaFactor = p.evalNum()
		case w == "script":
			if !p.endOfCmd() {
				p.evalStr()
			}
		case w == "v4" || w == "v5":
		}
	}
}

func setMultiplot(p *Parser) {
	S.multiplot = true
	setVar("GPVAL_MULTIPLOT", IntV(1))
	mp = &Multiplot{}
	for !p.endOfCmd() {
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "lay$out"):
			mp.rows = int(p.evalNum())
			p.expectOp(",", "',' expected")
			mp.cols = int(p.evalNum())
			mp.layout = true
		case optMatch(w, "rowsf$irst"):
			mp.rowsFirst = true
		case optMatch(w, "columnsf$irst"):
			mp.rowsFirst = false
		case optMatch(w, "down$wards"):
		case optMatch(w, "up$wards"):
			mp.upwards = true
		case optMatch(w, "tit$le"):
			mp.title = p.evalStr()
		case optMatch(w, "sc$ale"):
			p.evalNum()
			if p.isOp(",") {
				p.c++
				p.evalNum()
			}
		case optMatch(w, "off$set"):
			p.evalNum()
			if p.isOp(",") {
				p.c++
				p.evalNum()
			}
		case optMatch(w, "marg$ins"), optMatch(w, "spac$ing"):
			for !p.endOfCmd() {
				t := p.cur()
				if t.K == TNAME && t.S != "screen" && t.S != "character" {
					break
				}
				p.c++
			}
		}
	}
	mpBegin()
}

func cmdUnset(p *Parser) {
	t := p.cur()
	if t == nil || t.K != TNAME {
		throwAt(p.pos(), "unrecognized option - see 'help unset'.")
	}
	opt := t.S
	p.c++
	for _, an := range []string{"x2", "y2", "x", "y", "z", "cb", "r"} {
		if strings.HasPrefix(opt, an) {
			rest := opt[len(an):]
			a := S.axes[an]
			switch {
			case optMatch(rest, "l$abel"):
				a.label = ""
				return
			case optMatch(rest, "tic$s"):
				a.tics.on = false
				return
			case optMatch(rest, "mtic$s"):
				a.mtics = -1
				return
			case optMatch(rest, "da$ta"):
				a.isTime = false
				return
			case optMatch(rest, "zeroa$xis"):
				a.zeroAxis = false
				return
			case optMatch(rest, "r$ange"):
				na := newAxis(an)
				a.min, a.max, a.autoMin, a.autoMax = na.min, na.max, na.autoMin, na.autoMax
				return
			}
		}
	}
	switch {
	case optMatch(opt, "k$ey"):
		S.key.on = false
	case optMatch(opt, "tit$le"):
		S.title = ""
	case optMatch(opt, "log$scale"):
		axes, _ := parseLogAxes(p)
		for _, an := range axes {
			S.axes[an].log = false
		}
	case optMatch(opt, "g$rid"):
		S.grid = false
		for _, a := range S.axes {
			a.grid = false
			a.mgrid = false
		}
	case optMatch(opt, "bor$der"):
		S.border = 0
	case optMatch(opt, "tab$le"):
		S.tableOn = false
		S.tableFile = ""
		S.tableDB = ""
	case optMatch(opt, "pr$int"):
		closePrintFile()
	case optMatch(opt, "pa$rametric"):
		S.parametric = false
	case optMatch(opt, "po$lar"):
		S.polar = false
	case optMatch(opt, "la$bel"):
		if !p.endOfCmd() {
			tag := int(p.evalNum())
			var nl []*Label
			for _, l := range S.labels {
				if l.tag != tag {
					nl = append(nl, l)
				}
			}
			S.labels = nl
		} else {
			S.labels = nil
		}
	case optMatch(opt, "ar$row"):
		S.arrows = nil
		skipToEnd(p)
	case optMatch(opt, "tic$s"):
		for _, a := range S.axes {
			a.tics.on = false
		}
	case optMatch(opt, "multi$plot"):
		mpEnd()
	case optMatch(opt, "hid$den3d"):
		S.hidden3d = false
	case optMatch(opt, "su$rface"):
		S.surface = false
	case optMatch(opt, "cont$ours"):
		S.contour = false
	case optMatch(opt, "o$utput"):
		S.output = ""
		openOutput()
	case optMatch(opt, "te$rminal"):
		S.termName = "unknown"
	case optMatch(opt, "st$yle"):
		skipToEnd(p)
	case optMatch(opt, "bo$xwidth"):
		S.boxwidth = -1
	case optMatch(opt, "auto$scale"):
		setAutoscale(p, false)
	case optMatch(opt, "offset$s"):
		S.offsets = [4]float64{}
	case optMatch(opt, "dec$imalsign"):
		S.decimalsign = ""
	default:
		skipToEnd(p)
	}
}

func fmtRangeVal(v float64, isTime bool) string {
	if isTime {
		return "\"" + gpStrftime(S.timefmt, v) + "\""
	}
	return cfmt("%#g", v)
}

func cmdShow(p *Parser) {
	t := p.cur()
	if t == nil || t.K != TNAME {
		throwAt(p.pos(), "Unrecognized option. See 'help show'.")
	}
	opt := t.S
	optPos := t.Pos
	p.c++
	o := func(s string) { stderr.WriteString(s) }
	if n := rangeAxisName(opt); n != "" {
		a := S.axes[n]
		o("\n")
		o(showRange(a))
		o("\n")
		return
	}
	switch {
	case optMatch(opt, "v$ariables"):
		all := false
		prefix := ""
		if p.isName("all") {
			all = true
			p.c++
		} else if !p.endOfCmd() {
			prefix = p.tokStr()
			p.c++
		}
		showVariables(all, prefix)
	case optMatch(opt, "f$unctions"):
		o("\n\tUser-Defined Functions:\n")
		for _, n := range funcOrder {
			if f, ok := ufuncs[n]; ok {
				o("\t" + f.text + "\n")
			}
		}
		o("\n")
	case optMatch(opt, "sa$mples"):
		o("\n\tsampling rate is " + itoa(S.samples1) + ", " + itoa(S.samples2) + "\n\n")
	case optMatch(opt, "isosa$mples"):
		o("\n\tiso sampling rate is " + itoa(S.iso1) + ", " + itoa(S.iso2) + "\n\n")
	case optMatch(opt, "tit$le"):
		o("\n\ttitle is \"" + S.title + "\", offset at (character " + gnum(S.titleOffX) + ", " + gnum(S.titleOffY) + ", 0)center justified  textcolor lt -1\n\n")
	case optMatch(opt, "st$yle"):
		w := p.tokStr()
		p.c++
		switch {
		case optMatch(w, "d$ata"):
			o("\n\tData are plotted with " + S.styleData + "\n\n")
		case optMatch(w, "f$unction"):
			o("\n\tFunctions are plotted with " + S.styleFunc + "\n\n")
		case optMatch(w, "fi$ll"):
			o("\n" + showFill() + "\n")
		default:
			skipToEnd(p)
		}
	case optMatch(opt, "form$at"):
		o("\n\ttic format is:\n")
		for _, an := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			o("\t  " + an + "-axis: \"" + S.axes[an].format + "\"\n")
		}
		o("\n")
	case optMatch(opt, "log$scale"):
		s := ""
		for _, an := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			a := S.axes[an]
			if a.log {
				s += " " + an
				if a.base != 10 {
					s += " (base " + gnum(a.base) + ")"
				}
			}
		}
		if s == "" {
			o("\n\tlogscaling on none\n\n")
		} else {
			o("\n\tlogscaling on " + s + "\n\n")
		}
	case optMatch(opt, "an$gles"):
		if S.angleDeg {
			o("\n\tAngles are in degrees\n\n")
		} else {
			o("\n\tAngles are in radians\n\n")
		}
	case optMatch(opt, "du$mmy"):
		o("\n\tdummy variables are " + S.dummy1 + " " + S.dummy2 + " \n\n")
	case optMatch(opt, "pa$rametric"):
		if S.parametric {
			o("\n\tparametric is ON\n\n")
		} else {
			o("\n\tparametric is OFF\n\n")
		}
	case optMatch(opt, "po$lar"):
		if S.polar {
			o("\n\tpolar is ON\n\n")
		} else {
			o("\n\tpolar is OFF\n\n")
		}
	case optMatch(opt, "zero"):
		o("\n\tzero is " + gnum(S.zero) + "\n\n")
	case optMatch(opt, "bo$xwidth"):
		if S.boxwidth < 0 {
			o("\n\tboxwidth is auto\n")
		} else if S.boxwidthAbs {
			o("\n\tboxwidth is " + gnum(S.boxwidth) + " absolute\n")
		} else {
			o("\n\tboxwidth is " + gnum(S.boxwidth) + " relative\n")
		}
		o("\tboxdepth is 0\n\n")
	case optMatch(opt, "poi$ntsize"):
		o("\n\tpointsize is " + gnum(S.pointsize) + "\n\n")
	case optMatch(opt, "timef$mt"):
		o("\n\tDefault format for reading time data is \"" + S.timefmt + "\"\n\n")
	case optMatch(opt, "offset$s"):
		o("\n\toffsets are " + gnum(S.offsets[0]) + ", " + gnum(S.offsets[1]) + ", " + gnum(S.offsets[2]) + ", " + gnum(S.offsets[3]) + "\n\n")
	case optMatch(opt, "si$ze"):
		o("\n\tsize is scaled by " + gnum(S.sizeX) + "," + gnum(S.sizeY) + "\n")
		if S.sizeSquare {
			o("\tTry to set aspect ratio to 1:1.0\n\n")
		} else if S.sizeRatio != 0 {
			o("\tTry to set aspect ratio to 1:" + gnum(S.sizeRatio) + "\n\n")
		} else {
			o("\tNo attempt to control aspect ratio\n\n")
		}
	case optMatch(opt, "or$igin"):
		o("\n\torigin is set to " + gnum(S.originX) + "," + gnum(S.originY) + "\n\n")
	case optMatch(opt, "vi$ew"):
		if S.viewMap {
			o("\n\tview is map\n")
		} else {
			o("\n\tview is " + gnum(S.viewRotX) + " rot_x, " + gnum(S.viewRotZ) + " rot_z, " + gnum(S.viewScale) + " scale, " + gnum(S.viewScaleZ) + " scale_z\n")
		}
		o("\t\t axes are independently scaled\n\t\t azimuth 0\n\n")
	case optMatch(opt, "da$tafile"):
		o("\n")
		w := ""
		if !p.endOfCmd() {
			w = p.tokStr()
			p.c++
		}
		if w == "" || optMatch(w, "mis$sing") {
			if S.dfMissing == "" {
				o("\tNo missing data string set for datafile\n")
			} else {
				o("\t\"" + S.dfMissing + "\" in datafile is interpreted as missing value\n")
			}
		}
		if w == "" || optMatch(w, "sep$arator") {
			if S.dfSep == "" {
				o("\tdatafile fields separated by whitespace\n")
			} else {
				o("\tdatafile fields separated by any of " + itoa(len(S.dfSep)) + " characters \"" + S.dfSep + "\"\n")
			}
		}
		if w == "" || optMatch(w, "com$mentschars") {
			o("\tComments chars are \"" + S.dfComments + "\"\n")
		}
		if w == "" {
			if S.dfHeader {
				o("\tFirst line is treated as headers\n")
			} else {
				o("\tFirst line is treated as headers only if accessed explicitly\n")
			}
		}
		o("\n")
	case optMatch(opt, "pr$int"):
		dest := "<stderr>"
		if printToStdout {
			dest = "<stdout>"
		} else if printW != nil {
			dest = printFileName
		} else if printDB != "" {
			dest = printDB
		}
		o("\n\tprint output is sent to '" + dest + "'\n\n")
	case optMatch(opt, "tab$le"):
		if S.tableOn {
			o("\n\ttable mode is on, field separator tab\n\n")
		} else {
			o("\n\ttable mode is off\n\n")
		}
	case optMatch(opt, "bor$der"):
		if S.border == 0 {
			o("\n\tborder is not drawn\n\n")
		} else {
			o("\n\tborder " + itoa(S.border) + " (0x" + strings.ToUpper(strconv.FormatInt(int64(S.border), 16)) + ") is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n")
		}
	case optMatch(opt, "k$ey"):
		o("\n" + showKey() + "\n")
	case optMatch(opt, "g$rid"):
		if !S.grid {
			o("\n\tgrid is OFF\n\n")
		} else {
			s := ""
			for _, an := range []string{"x", "y", "z", "x2", "y2", "r", "cb"} {
				if S.axes[an].grid {
					s += an + " "
				}
			}
			ms := ""
			for _, an := range []string{"x", "y", "z", "x2", "y2", "r", "cb"} {
				if S.axes[an].mgrid {
					ms += "m" + an + " "
				}
			}
			o("\n\tRectangular grid drawn at " + s + ms + "tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case optMatch(opt, "te$rminal"):
		o("\n" + showTerminal() + "\n")
	case optMatch(opt, "o$utput"):
		if S.output == "" {
			o("\n\toutput is sent to STDOUT\n\n")
		} else {
			o("\n\toutput is sent to '" + S.output + "'\n\n")
		}
	case optMatch(opt, "ve$rsion"):
		o(versionText())
		skipToEnd(p)
	case optMatch(opt, "fit"):
		o("\n" + showFit() + "\n")
	case optMatch(opt, "mar$gin"):
		o("\n")
		for i, n := range []string{"lmargin", "rmargin", "bmargin", "tmargin"} {
			v := []float64{S.lmargin, S.rmargin, S.bmargin, S.tmargin}[i]
			if v < 0 {
				o("\t" + n + " is computed automatically\n")
			} else {
				o("\t" + n + " is set to " + gnum(v) + "\n")
			}
		}
		o("\n")
	case optMatch(opt, "mxt$ics"), optMatch(opt, "myt$ics"), optMatch(opt, "mzt$ics"):
		an := opt[1:2]
		a := S.axes[an]
		if a.mtics > 0 {
			o("\tminor " + an + "tics are drawn with " + itoa(a.mtics) + " subintervals between major tic marks\n\n")
		} else if a.mtics < 0 {
			o("\tminor " + an + "tics are off\n\n")
		} else {
			o("\tminor " + an + "tics are off for linear scales\n\tminor " + an + "tics are computed automatically for log scales\n\n")
		}
	case optMatch(opt, "xl$abel"), optMatch(opt, "yl$abel"), optMatch(opt, "zl$abel"), optMatch(opt, "x2l$abel"), optMatch(opt, "y2l$abel"), optMatch(opt, "cbl$abel"):
		an := strings.SplitN(opt, "l", 2)[0]
		a := S.axes[an]
		rot := ""
		if a.labelRotSet && a.labelRot != 0 {
			rot = ", rotated by " + gnum(a.labelRot) + " degrees in 2D plots"
		}
		o("\n\t" + an + "label is \"" + a.label + "\", offset at (character " + gnum(a.labelOffX) + ", " + gnum(a.labelOffY) + ", 0)center justified " + rot + " textcolor lt -1\n\n")
	case optMatch(opt, "xd$ata"), optMatch(opt, "yd$ata"), optMatch(opt, "zd$ata"), optMatch(opt, "x2d$ata"), optMatch(opt, "y2d$ata"), optMatch(opt, "cbd$ata"):
		an := strings.SplitN(opt, "d", 2)[0]
		if S.axes[an].isTime {
			o("\n\t" + an + " is set to time\n\n")
		} else {
			o("\n\t" + an + " is set to numerical\n\n")
		}
	case optMatch(opt, "lab$el"):
		o("\n")
		for _, l := range S.labels {
			just := l.just
			if just == "center" {
				just = "centre"
			}
			pos := "(" + cfmt("%#g", l.x) + ", " + cfmt("%#g", l.y) + ", 0.00000)"
			if l.coord != "first" {
				pos = "(" + l.coord + " " + gnum(l.x) + ", " + gnum(l.y) + ", 0)"
			}
			pt := " nopoint"
			if l.point {
				pt = " point with color of linewidth 1.000 dashtype solid pointtype 1 pointsize default offset (character 0, 0, 0)"
			}
			o("\tlabel " + itoa(l.tag) + " \"" + l.text + "\" at " + pos + " " + just + " not rotated back " + pt + "\n")
		}
		o("\n")
	case optMatch(opt, "auto$scale"):
		ao := func(n string) string {
			a := S.axes[n]
			if a.autoMin && a.autoMax {
				return "ON"
			}
			if a.autoMin {
				return "MIN"
			}
			if a.autoMax {
				return "MAX"
			}
			return "OFF"
		}
		o("\n\tautoscaling is \tx: " + ao("x") + ", \ty: " + ao("y") + ", \n\t               \tx2: " + ao("x2") + ", \ty2: " + ao("y2") + ", \n\t               \tz: " + ao("z") + ", \tcb: " + ao("cb") + ", \n")
	case optMatch(opt, "dec$imalsign"):
		if S.decimalsign == "" {
			o("\n\tdecimalsign for input is  . \n\tdecimalsign for output has default value (normally '.')\n\tdegree sign for output is ° \n\n")
		} else {
			o("\n\tdecimalsign for input is  . \n\tdecimalsign for output is " + S.decimalsign + " \n\tdegree sign for output is ° \n\n")
		}
	case optMatch(opt, "enc$oding"):
		o("\n\tnominal character encoding is utf8\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case optMatch(opt, "cl$ip"):
		o("\n\tpoint clip is OFF\n\tclipping lines with one end out of range (clip one)\n\tnot drawing lines with both ends out of range (clip two)\n\tnot clipping lines on polar plot at maximum radius\n\n")
	case optMatch(opt, "xyp$lane"), optMatch(opt, "ticsl$evel"):
		o("\txyplane " + gnum(S.xyplane) + "\n\n")
	case optMatch(opt, "map$ping"):
		o("\n\tmapping for 3-d data is " + S.mapping + "\n\n")
	case optMatch(opt, "su$rface"):
		if S.surface {
			o("\n\tsurface is drawn \n\n")
		} else {
			o("\n\tsurface is not drawn\n\n")
		}
	case optMatch(opt, "cont$ours"), optMatch(opt, "cntrp$aram"):
		if !S.contour {
			o("\n\tcontour for surfaces are not drawn\n\n")
		} else {
			o("\n\tcontour for surfaces are drawn in 2 levels on grid base\n\n")
		}
	case optMatch(opt, "bar$s"):
		o("\terrors are plotted with bars of size 1.000000\n\n")
	case optMatch(opt, "multi$plot"):
		if S.multiplot {
			o("\n\tmultiplot mode is on\n\n")
		} else {
			o("\n\tmultiplot mode is off\n\n")
		}
	case optMatch(opt, "xtic$s"), optMatch(opt, "ytic$s"), optMatch(opt, "ztic$s"), optMatch(opt, "x2tic$s"), optMatch(opt, "y2tic$s"), optMatch(opt, "cbtic$s"), optMatch(opt, "tic$s"):
		an := strings.TrimSuffix(strings.SplitN(opt, "tic", 2)[0], "")
		o("\n" + showTics(an) + "\n")
	default:
		throwAt(optPos, "Unrecognized option. See 'help show'.")
	}
}

func showCoord(c string) string {
	if c == "first" {
		return ""
	}
	return c + " "
}

func showRange(a *Axis) string {
	lo, hi := "*", "*"
	if !a.autoMin {
		lo = fmtRangeVal(a.min, a.isTime)
	}
	if !a.autoMax {
		hi = fmtRangeVal(a.max, a.isTime)
	}
	rev := "noreverse"
	if a.reverse {
		rev = "reverse"
	}
	wb := "nowriteback"
	if a.writeback {
		wb = "writeback"
	}
	s := "\tset " + a.name + "range [ " + lo + " : " + hi + " ] " + rev + " " + wb
	if a.autoMin || a.autoMax {
		if a.isTime {
			s += "  # (currently [" + "\"" + gpStrftime(S.timefmt, a.curMin) + "\"" + ":" + "\"" + gpStrftime(S.timefmt, a.curMax) + "\"" + "] )"
		} else {
			s += "  # (currently [" + cfmt("%#g", a.curMin) + ":" + cfmt("%#g", a.curMax) + "] )"
		}
	}
	return s + "\n"
}

// gnum formats like %g
func gnum(v float64) string { return cfmt("%g", v) }

var funcOrder []string

func showVariables(all bool, prefix string) {
	o := func(s string) { stderr.WriteString(s) }
	if all {
		o("\n\tAll available variables:\n")
	} else if prefix != "" {
		o("\n\tVariables beginning with " + prefix + ":\n")
	} else {
		o("\n\tUser and default variables:\n")
	}
	for _, n := range varOrder {
		v, ok := gvars[n]
		if !ok {
			continue
		}
		if !all && strings.HasPrefix(n, "GPVAL_") && prefix == "" {
			continue
		}
		if prefix != "" && !strings.HasPrefix(n, prefix) {
			continue
		}
		if v.T == UNDEF {
			continue
		}
		o("\t" + n + " = " + showValue(*v) + "\n")
	}
	o("\n")
}

func showValue(v Value) string {
	switch v.T {
	case STR:
		return "\"" + v.S + "\""
	case ARR:
		return "<" + itoa(len(*v.A)) + " element array>"
	case CMPLX:
		if v.Im == 0 {
			return fmtG(v.R)
		}
		return "{" + fmtG(v.R) + ", " + fmtG(v.Im) + "}"
	}
	return v.String()
}

func showFill() string {
	switch S.fillStyle {
	case "solid":
		s := "\tFill style uses  solid colour with density " + cfmt("%.3f", S.fillDensity)
		if S.fillBorder {
			return s + " with border \n"
		}
		return s + " with no border\n"
	case "pattern":
		s := "\tFill style uses  patterns starting at " + itoa(S.fillPattern)
		if S.fillBorder {
			return s + " with border \n"
		}
		return s + " with no border\n"
	}
	if S.fillBorder {
		return "\tFill style is empty with border \n"
	}
	return "\tFill style is empty with no border\n"
}

func showKey() string {
	k := S.key
	if !k.on {
		return "\tkey is OFF\n"
	}
	var b strings.Builder
	pos := k.vpos + " " + k.hpos
	if k.hpos == "center" && k.vpos == "center" {
		pos = "center"
	}
	if k.atSet {
		b.WriteString("\tkey is ON, position: at " + gnum(k.atX) + ", " + gnum(k.atY) + ", 0 ")
	} else {
		place := ""
		if !k.inside {
			place = " outside"
		}
		_ = place
		b.WriteString("\tkey is ON, position: " + pos)
	}
	if k.vertical {
		b.WriteString(" vertical")
	} else {
		b.WriteString(" horizontal")
	}
	b.WriteString(" fixed  offset: (character 0, 0)\n")
	just := "right"
	if k.just == "Left" {
		just = "left"
	}
	rev := "not reversed"
	if k.reverse {
		rev = "reversed"
	}
	inv := "not inverted"
	if k.invert {
		inv = "inverted"
	}
	enh := "enhanced"
	if !k.enhanced {
		enh = "noenhanced"
	}
	box := "not boxed"
	if k.box {
		box = "boxed"
	}
	b.WriteString("\tkey is " + just + " justified, " + rev + ", " + inv + ", " + enh + " and " + box + "\n")
	if k.box {
		b.WriteString("\twith  lt black linewidth 1.000 dashtype solid\n")
	}
	b.WriteString("\tsample length is " + gnum(k.samplen) + " characters\n")
	b.WriteString("\tvertical spacing is " + gnum(k.spacing) + " characters\n")
	b.WriteString("\twidth adjustment is " + gnum(k.width) + " characters\n")
	b.WriteString("\theight adjustment is " + gnum(k.height) + " characters\n")
	if k.autotitle {
		if k.columnhead {
			b.WriteString("\tcurves are automatically titled with column header\n")
		} else {
			b.WriteString("\tcurves are automatically titled with filename\n")
		}
	} else {
		b.WriteString("\tcurves are not automatically titled\n")
	}
	if k.maxcols > 0 {
		b.WriteString("\tmaximum number of columns is " + itoa(k.maxcols) + "\n")
	} else {
		b.WriteString("\tmaximum number of columns is calculated automatically\n")
	}
	if k.maxrows > 0 {
		b.WriteString("\tmaximum number of rows is " + itoa(k.maxrows) + "\n")
	} else {
		b.WriteString("\tmaximum number of rows is calculated automatically\n")
	}
	b.WriteString("\n\tkey title is \"" + k.title + "\" center justified \n")
	return b.String()
}

func showFit() string {
	var b strings.Builder
	if S.fitQuiet {
		b.WriteString("\tfit will not output results to console.\n")
	} else if S.fitVerbose {
		b.WriteString("\tfit will output verbose results to console and log-file.\n")
	} else {
		b.WriteString("\tfit will output brief results to console and log-file.\n")
	}
	b.WriteString("\tfit can handle up to 12 independent variables\n")
	if S.fitPrescale {
		b.WriteString("\tfit will prescale parameters by their initial values\n")
	} else {
		b.WriteString("\tfit will not prescale parameters by their initial values\n")
	}
	if S.fitErrVars {
		b.WriteString("\tfit will place parameter errors in variables\n")
	} else {
		b.WriteString("\tfit will not place parameter errors in variables\n")
	}
	if S.fitCovVars {
		b.WriteString("\tfit will place covariances in variables\n")
	} else {
		b.WriteString("\tfit will not place covariances in variables\n")
	}
	if S.fitErrScaling {
		b.WriteString("\tfit will scale parameter errors with the reduced chi square\n")
	} else {
		b.WriteString("\tfit will not scale parameter errors with the reduced chi square\n")
	}
	if S.fitLog == "none" {
		b.WriteString("\tfit will not write a log file\n")
	} else if S.fitLogSet && S.fitLogFile != "" {
		b.WriteString("\tlog-file for fits was set by the user to \n\t'" + S.fitLogFile + "'\n")
	} else {
		b.WriteString("\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
	}
	b.WriteString("\tfits will be considered to have converged if  delta chisq < chisq * " + gnum(S.fitLimit) + "\n")
	if S.fitMaxIter > 0 {
		b.WriteString("\tfit will stop after a maximum of " + itoa(S.fitMaxIter) + " iterations\n")
	} else {
		b.WriteString("\tfit has no limit in the number of iterations\n")
	}
	b.WriteString("\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n")
	b.WriteString("\tfit can run the following command when interrupted:\n\t\t'replot'\n")
	return b.String()
}

func showTics(an string) string {
	var b strings.Builder
	if S.ticsFront {
		b.WriteString("\ttics are in front of plot\n")
	} else {
		b.WriteString("\ttics are in back of plot\n")
	}
	list := []string{"x", "x2"}
	if an == "" {
		list = []string{"x", "x2", "y", "y2", "z", "cb"}
	} else if an == "y" {
		list = []string{"y", "y2"}
	} else if an == "z" {
		list = []string{"z"}
	} else if an == "cb" {
		list = []string{"cb"}
	} else if an == "x2" {
		list = []string{"x2"}
	} else if an == "y2" {
		list = []string{"y2"}
	}
	for _, n := range list {
		a := S.axes[n]
		io := "IN"
		if a.tics.out {
			io = "OUT"
		}
		b.WriteString("\t" + n + "-axis tics are " + io + ", \tmajor ticscale is " + gnum(S.ticscale) + " and minor ticscale is " + gnum(S.mticscale) + "\n")
		if !a.tics.on {
			b.WriteString("\t" + n + "-axis tics:\tOFF\n")
			continue
		}
		mir := " and mirrored on opposite border"
		if !a.tics.mirror {
			mir = ""
		}
		b.WriteString("\t" + n + "-axis tics:\ton border" + mir + "\n")
		td := ""
		if a.isTime {
			td = " timedate"
		}
		rot := "are not rotated"
		if a.tics.rotate {
			rot = "are rotated"
		}
		b.WriteString("\t  labels are justified automatically, format \"" + a.format + "\"" + td + " and " + rot + ",\n")
		b.WriteString("\t    offset (character 0, 0, 0)\n")
		if a.tics.auto {
			b.WriteString("\t  intervals computed automatically\n")
		} else if a.tics.list == nil {
			if a.tics.hasStart {
				s := "\t  series from " + gnum(a.tics.start) + " by " + gnum(a.tics.step)
				if a.tics.hasEnd {
					s += " until " + gnum(a.tics.end)
				}
				b.WriteString(s + "\n")
			} else {
				b.WriteString("\t  series by " + gnum(a.tics.step) + "\n")
			}
		} else {
			b.WriteString("\t  no auto-generated tics\n")
		}
		if len(a.tics.list) > 0 {
			var items []string
			for _, it := range a.tics.list {
				vs := cfmt("%#g", it.x)
				if a.isTime {
					vs = "\"" + gpStrftime(S.timefmt, it.x) + "\""
				}
				if it.has {
					items = append(items, "\""+it.label+"\" "+vs)
				} else {
					items = append(items, vs)
				}
			}
			b.WriteString("\t  explicit list (" + strings.Join(items, ", ") + ")\n")
		}
	}
	b.WriteString("\tScales for user tic levels 2-4 are:  1, 1, 1\n")
	return b.String()
}

func versionText() string {
	return "\n\t" + `G N U P L O T
	Version 5.4 patchlevel 9    last modified 2023-09-01

	Copyright (C) 1986-1993, 1998, 2004, 2007-2023
	Thomas Williams, Colin Kelley and many others

	gnuplot home:     http://www.gnuplot.info
	faq, bugs, etc:   type "help FAQ"
	immediate help:   type "help"  (plot window: hit 'h')

`
}
