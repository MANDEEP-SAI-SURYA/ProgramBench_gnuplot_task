package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
)

// cfmt is a C-like printf for a single numeric/string argument list
func cfmt(format string, args ...interface{}) string {
	var b strings.Builder
	ai := 0
	i := 0
	for i < len(format) {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i += 2
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.') {
			j++
		}
		for j < len(format) && (format[j] == 'l' || format[j] == 'h') {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		spec := format[i:j]
		spec = strings.ReplaceAll(strings.ReplaceAll(spec, "l", ""), "h", "")
		conv := format[j]
		var a interface{}
		if ai < len(args) {
			a = args[ai]
			ai++
		}
		b.WriteString(fmtOne(spec, conv, a))
		i = j + 1
	}
	return b.String()
}

func fmtOne(spec string, conv byte, a interface{}) string {
	switch conv {
	case 'd', 'i':
		var v int64
		switch x := a.(type) {
		case int:
			v = int64(x)
		case int64:
			v = x
		case float64:
			v = int64(x)
		}
		return fmt.Sprintf(spec+"d", v)
	case 'u':
		var v int64
		switch x := a.(type) {
		case int:
			v = int64(x)
		case int64:
			v = x
		case float64:
			v = int64(x)
		}
		return fmt.Sprintf(spec+"d", uint64(v))
	case 'x', 'X', 'o':
		var v int64
		switch x := a.(type) {
		case int:
			v = int64(x)
		case int64:
			v = x
		case float64:
			v = int64(x)
		}
		s := fmt.Sprintf(spec+string(conv), uint64(v))
		if conv == 'o' && strings.Contains(spec, "#") {
			// Go uses 0 prefix like C
		}
		return s
	case 'c':
		var v int64
		switch x := a.(type) {
		case int:
			v = int64(x)
		case int64:
			v = x
		case float64:
			v = int64(x)
		}
		return fmt.Sprintf(spec+"c", rune(byte(v)))
	case 's':
		s, _ := a.(string)
		return fmt.Sprintf(spec+"s", s)
	case 'f', 'F', 'e', 'E', 'g', 'G':
		var v float64
		switch x := a.(type) {
		case int:
			v = float64(x)
		case int64:
			v = float64(x)
		case float64:
			v = x
		}
		return cfloat(spec, conv, v)
	}
	return spec + string(conv)
}

// cfloat formats a float like C printf
func cfloat(spec string, conv byte, v float64) string {
	// parse flags/width/prec
	flags := ""
	k := 1
	for k < len(spec) && strings.IndexByte("-+ #0", spec[k]) >= 0 {
		flags += string(spec[k])
		k++
	}
	ws := ""
	for k < len(spec) && isDigit(spec[k]) {
		ws += string(spec[k])
		k++
	}
	prec := -1
	if k < len(spec) && spec[k] == '.' {
		k++
		ps := ""
		for k < len(spec) && isDigit(spec[k]) {
			ps += string(spec[k])
			k++
		}
		prec, _ = strconv.Atoi(ps)
	}
	if prec < 0 {
		prec = 6
	}
	width, _ := strconv.Atoi(ws)
	var body string
	neg := math.Signbit(v)
	av := math.Abs(v)
	if math.IsInf(v, 0) || math.IsNaN(v) {
		if math.IsNaN(v) {
			body = "nan"
		} else {
			body = "inf"
		}
		if conv == 'E' || conv == 'G' || conv == 'F' {
			body = strings.ToUpper(body)
		}
		flags = strings.ReplaceAll(flags, "0", "")
	} else {
		switch conv {
		case 'f', 'F':
			body = strconv.FormatFloat(av, 'f', prec, 64)
			if prec == 0 && strings.Contains(flags, "#") {
				body += "."
			}
		case 'e', 'E':
			body = cexp(av, prec, conv == 'E', strings.Contains(flags, "#"))
		case 'g', 'G':
			body = cgen(av, prec, conv == 'G', strings.Contains(flags, "#"))
		}
	}
	sign := ""
	if neg {
		sign = "-"
	} else if strings.Contains(flags, "+") {
		sign = "+"
	} else if strings.Contains(flags, " ") {
		sign = " "
	}
	total := len(sign) + len(body)
	if total < width {
		pad := width - total
		if strings.Contains(flags, "-") {
			return sign + body + strings.Repeat(" ", pad)
		}
		if strings.Contains(flags, "0") {
			return sign + strings.Repeat("0", pad) + body
		}
		return strings.Repeat(" ", pad) + sign + body
	}
	return sign + body
}

func cexp(av float64, prec int, upper bool, alt bool) string {
	s := strconv.FormatFloat(av, 'e', prec, 64)
	// Go gives e+00 style with at least 2 digits: matches C
	if alt && prec == 0 {
		idx := strings.IndexByte(s, 'e')
		s = s[:idx] + "." + s[idx:]
	}
	if upper {
		s = strings.ToUpper(s)
	}
	return s
}

func cgen(av float64, prec int, upper bool, alt bool) string {
	if prec == 0 {
		prec = 1
	}
	if av == 0 {
		if alt {
			return "0." + strings.Repeat("0", prec-1)
		}
		return "0"
	}
	es := strconv.FormatFloat(av, 'e', prec-1, 64)
	ei := strings.IndexByte(es, 'e')
	exp, _ := strconv.Atoi(es[ei+1:])
	var s string
	if exp < -4 || exp >= prec {
		mant := es[:ei]
		if !alt && strings.Contains(mant, ".") {
			mant = strings.TrimRight(mant, "0")
			mant = strings.TrimSuffix(mant, ".")
		}
		s = mant + es[ei:]
	} else {
		s = strconv.FormatFloat(av, 'f', prec-1-exp, 64)
		if !alt && strings.Contains(s, ".") {
			s = strings.TrimRight(s, "0")
			s = strings.TrimSuffix(s, ".")
		}
	}
	if upper {
		s = strings.ToUpper(s)
	}
	return s
}

// gnuplot sprintf()
func gpSprintf(args []Value) Value {
	if len(args) == 0 || args[0].T != STR {
		throwNC("First parameter to sprintf must be a format string")
	}
	format := args[0].S
	rest := args[1:]
	var b strings.Builder
	ai := 0
	i := 0
	for i < len(format) {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i += 2
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0'", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.' || format[j] == '*') {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		conv := format[j]
		spec := format[i:j]
		if ai >= len(rest) {
			b.WriteString(format[i:])
			break
		}
		a := rest[ai]
		ai++
		switch conv {
		case 'd', 'i', 'x', 'X', 'o', 'c', 'u':
			if a.T == STR {
				throwNC("f_sprintf: attempt to print string value with numeric format")
			}
			a = numify(a)
			var iv int64
			if a.T == INT {
				iv = a.I
			} else {
				iv = int64(a.R)
			}
			b.WriteString(fmtOne(spec, conv, iv))
		case 'f', 'F', 'e', 'E', 'g', 'G':
			if a.T == STR {
				throwNC("f_sprintf: attempt to print string value with numeric format")
			}
			b.WriteString(fmtOne(spec, conv, numify(a).Real()))
		case 's':
			if a.T != STR {
				throwNC("f_sprintf: attempt to print numeric value with string format")
			}
			b.WriteString(fmtOne(spec, conv, a.S))
		default:
			throwNC("f_sprintf: unsupported or invalid format specifier")
		}
		i = j + 1
	}
	return StrV(b.String())
}

// gprintf: gnuplot axis-style format
func gprintf(format string, x float64) string {
	return gprintfBase(format, x, 10)
}

func gprintfBase(format string, x float64, logbase float64) string {
	var b strings.Builder
	i := 0
	// precompute mantissa/power for log base 10 (t/T)
	for i < len(format) {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i += 2
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.') {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		spec := format[i:j]
		conv := format[j]
		i = j + 1
		switch conv {
		case 'f', 'F', 'e', 'E', 'g', 'G':
			b.WriteString(cfloat(spec, conv, x))
		case 'x', 'X', 'o', 'd', 'i':
			b.WriteString(fmtOne(spec, conv, int64(x)))
		case 't':
			m, _ := mantExp10(x, spec)
			b.WriteString(cfloat(spec, 'f', m))
		case 'T':
			_, e := mantExp10(x, spec)
			b.WriteString(fmtOne(spec, 'd', int64(e)))
		case 'l':
			m, _ := mantExpBase(x, logbase)
			b.WriteString(cfloat(spec, 'f', m))
		case 'L':
			_, e := mantExpBase(x, logbase)
			b.WriteString(fmtOne(spec, 'd', int64(e)))
		case 's':
			m, _ := mantExp1000(x, spec)
			b.WriteString(cfloat(spec, 'f', m))
		case 'S':
			_, e := mantExp1000(x, spec)
			b.WriteString(fmtOne(spec, 'd', int64(3*e)))
		case 'c':
			_, e := mantExp1000(x, spec)
			b.WriteString(siPrefix(e))
		case 'P':
			b.WriteString(cfloat(spec, 'f', x/math.Pi))
		case 'h', 'H':
			s := cfloat(spec, 'g', x)
			if strings.Contains(s, "e") {
				// convert to x10^{...}
				idx := strings.Index(s, "e")
				mant := s[:idx]
				ex, _ := strconv.Atoi(s[idx+1:])
				s = mant + "x10^{" + strconv.Itoa(ex) + "}"
				if conv == 'H' {
					s = mant + "x10^{" + strconv.Itoa(ex) + "}"
				}
			}
			b.WriteString(s)
		default:
			b.WriteString(spec + string(conv))
		}
	}
	return b.String()
}

func precOf(spec string) int {
	k := strings.IndexByte(spec, '.')
	if k < 0 {
		return 6
	}
	p, _ := strconv.Atoi(spec[k+1:])
	return p
}

func mantExp10(x float64, spec string) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	e := int(math.Floor(math.Log10(ax)))
	m := x / math.Pow(10, float64(e))
	// rounding check
	p := precOf(spec)
	r := math.Pow(10, float64(p))
	if math.Abs(math.Round(m*r)/r) >= 10 {
		m /= 10
		e++
	}
	return m, e
}

func mantExpBase(x float64, base float64) (float64, int) {
	if x == 0 || base <= 1 {
		return x, 0
	}
	ax := math.Abs(x)
	e := int(math.Floor(math.Log(ax)/math.Log(base) + 1e-12))
	return x / math.Pow(base, float64(e)), e
}

func mantExp1000(x float64, spec string) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	e := int(math.Floor(math.Log10(ax)))
	e3 := int(math.Floor(float64(e) / 3))
	m := x / math.Pow(10, float64(3*e3))
	p := precOf(spec)
	r := math.Pow(10, float64(p))
	if math.Abs(math.Round(m*r)/r) >= 1000 {
		m /= 1000
		e3++
	}
	return m, e3
}

func siPrefix(e int) string {
	pre := []string{"y", "z", "a", "f", "p", "n", "u", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"}
	i := e + 8
	if i >= 0 && i < len(pre) {
		return pre[i]
	}
	return "e" + strconv.Itoa(3*e)
}
