package main

import (
	"strconv"
	"strings"
)

const (
	TNUM = iota
	TSTR
	TNAME
	TOP
	TDOLLAR // $name or $1
	TNL     // newline separator inside blocks
)

type Token struct {
	K     int
	S     string // text (for TSTR: processed content)
	Pos   int    // start offset in line
	End   int
	IsInt bool
	IV    int64
	FV    float64
	Quote byte
}

var ops3 = []string{"<<", ">>", "**", "==", "!=", "<=", ">=", "&&", "||"}

func isAlpha(c byte) bool {
	return c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }

func lexLine(line string) []Token {
	var toks []Token
	i := 0
	n := len(line)
	for i < n {
		c := line[i]
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '\n' {
			toks = append(toks, Token{K: TNL, S: "\n", Pos: i, End: i + 1})
			i++
			continue
		}
		if c == '#' {
			// comment to end of line
			for i < n && line[i] != '\n' {
				i++
			}
			continue
		}
		st := i
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])) {
			t := lexNumber(line, i)
			toks = append(toks, t)
			i = t.End
			continue
		}
		if isAlpha(c) {
			for i < n && (isAlpha(line[i]) || isDigit(line[i])) {
				i++
			}
			toks = append(toks, Token{K: TNAME, S: line[st:i], Pos: st, End: i})
			continue
		}
		if c == '$' {
			i++
			if i < n && (isAlpha(line[i]) || isDigit(line[i])) {
				for i < n && (isAlpha(line[i]) || isDigit(line[i])) {
					i++
				}
			}
			toks = append(toks, Token{K: TDOLLAR, S: line[st:i], Pos: st, End: i})
			continue
		}
		if c == '"' || c == '\'' {
			s, e := lexString(line, i)
			toks = append(toks, Token{K: TSTR, S: s, Pos: st, End: e, Quote: c})
			i = e
			continue
		}
		matched := false
		for _, op := range ops3 {
			if strings.HasPrefix(line[i:], op) {
				toks = append(toks, Token{K: TOP, S: op, Pos: st, End: i + len(op)})
				i += len(op)
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		toks = append(toks, Token{K: TOP, S: string(c), Pos: st, End: i + 1})
		i++
	}
	return toks
}

func lexNumber(line string, i int) Token {
	st := i
	n := len(line)
	if line[i] == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
		j := i + 2
		for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
			j++
		}
		v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
		return Token{K: TNUM, S: line[st:j], Pos: st, End: j, IsInt: true, IV: int64(v)}
	}
	j := i
	for j < n && isDigit(line[j]) {
		j++
	}
	isInt := true
	if j < n && line[j] == '.' {
		isInt = false
		j++
		for j < n && isDigit(line[j]) {
			j++
		}
	}
	if j < n && (line[j] == 'e' || line[j] == 'E') {
		k := j + 1
		if k < n && (line[k] == '+' || line[k] == '-') {
			k++
		}
		if k < n && isDigit(line[k]) {
			for k < n && isDigit(line[k]) {
				k++
			}
			isInt = false
			j = k
		} else {
			throwAt(k, "expecting exponent")
		}
	}
	txt := line[st:j]
	if isInt {
		if len(txt) > 1 && txt[0] == '0' {
			v, err := strconv.ParseInt(txt, 8, 64)
			if err == nil {
				return Token{K: TNUM, S: txt, Pos: st, End: j, IsInt: true, IV: v}
			}
		}
		v, err := strconv.ParseInt(txt, 10, 64)
		if err == nil {
			return Token{K: TNUM, S: txt, Pos: st, End: j, IsInt: true, IV: v}
		}
		f, _ := strconv.ParseFloat(txt, 64)
		return Token{K: TNUM, S: txt, Pos: st, End: j, FV: f}
	}
	f, _ := strconv.ParseFloat(txt, 64)
	return Token{K: TNUM, S: txt, Pos: st, End: j, FV: f}
}

func lexString(line string, i int) (string, int) {
	q := line[i]
	n := len(line)
	j := i + 1
	var b strings.Builder
	if q == '\'' {
		for j < n {
			if line[j] == '\'' {
				if j+1 < n && line[j+1] == '\'' {
					b.WriteByte('\'')
					j += 2
					continue
				}
				return b.String(), j + 1
			}
			b.WriteByte(line[j])
			j++
		}
		return b.String(), j
	}
	for j < n {
		c := line[j]
		if c == '"' {
			return b.String(), j + 1
		}
		if c == '\\' && j+1 < n {
			d := line[j+1]
			switch d {
			case 'n':
				b.WriteByte('\n')
			case 't':
				b.WriteByte('\t')
			case 'r':
				b.WriteByte('\r')
			case 'a':
				b.WriteByte(7)
			case 'b':
				b.WriteByte(8)
			case 'f':
				b.WriteByte(12)
			case 'v':
				b.WriteByte(11)
			case '\\':
				b.WriteByte('\\')
			case '"':
				b.WriteByte('"')
			case '\n':
			default:
				if d >= '0' && d <= '7' {
					k := j + 1
					v := 0
					for k < n && k < j+4 && line[k] >= '0' && line[k] <= '7' {
						v = v*8 + int(line[k]-'0')
						k++
					}
					b.WriteByte(byte(v))
					j = k
					continue
				}
				b.WriteByte(d)
			}
			j += 2
			continue
		}
		b.WriteByte(c)
		j++
	}
	return b.String(), j
}
