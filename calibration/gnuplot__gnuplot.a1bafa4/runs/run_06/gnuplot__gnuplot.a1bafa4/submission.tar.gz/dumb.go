package main

import (
	"math"
	"strings"
)

type Canvas struct {
	w, h  int
	cells [][]rune
}

func newCanvas(w, h int) *Canvas {
	c := &Canvas{w: w, h: h}
	c.cells = make([][]rune, h)
	for i := range c.cells {
		c.cells[i] = []rune(strings.Repeat(" ", w))
	}
	return c
}

func (c *Canvas) set(col, row int, ch rune) {
	if row >= 0 && row < c.h && col >= 0 && col < c.w {
		c.cells[row][col] = ch
	}
}

func (c *Canvas) text(col, row int, s string) {
	for i, r := range []rune(s) {
		c.set(col+i, row, r)
	}
}

func flushCanvas(c *Canvas) {
	var b strings.Builder
	if dumbFeed {
		b.WriteString("\f")
	}
	for i, row := range c.cells {
		b.WriteString(string(row))
		if i < c.h-1 || true {
			b.WriteString("\n")
		}
	}
	writeOutput(b.String())
}

var dumbFeed = false

func quantizeTics(arg, guide float64) float64 {
	power := math.Pow(10, math.Floor(math.Log10(arg)))
	xnorm := arg / power
	posns := guide / xnorm
	var tics float64
	switch {
	case posns > 40:
		tics = 0.05
	case posns > 20:
		tics = 0.1
	case posns > 10:
		tics = 0.2
	case posns > 4:
		tics = 0.5
	case posns > 2:
		tics = 1
	case posns > 0.5:
		tics = 2
	default:
		tics = math.Ceil(xnorm)
	}
	return tics * power
}

type axisLayout struct {
	min, max float64
	step     float64
	tics     []float64
	labels   []string
}

func computeAxis(a *Axis, dmin, dmax float64, have bool) axisLayout {
	var L axisLayout
	lo, hi := a.min, a.max
	if a.autoMin {
		if have {
			lo = dmin
		} else {
			lo = -10
		}
	}
	if a.autoMax {
		if have {
			hi = dmax
		} else {
			hi = 10
		}
	}
	if lo == hi {
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			d := math.Abs(lo) * 0.01
			lo -= d
			hi += d
		}
	}
	rev := false
	if lo > hi {
		lo, hi = hi, lo
		rev = true
	}
	_ = rev
	step := quantizeTics(hi-lo, 20)
	if !a.tics.auto && a.tics.step > 0 {
		step = a.tics.step
	}
	if a.autoMin {
		lo = math.Floor(lo/step+1e-9) * step
	}
	if a.autoMax {
		hi = math.Ceil(hi/step-1e-9) * step
	}
	L.min, L.max, L.step = lo, hi, step
	a.curMin, a.curMax = lo, hi
	if a.tics.on {
		if len(a.tics.list) > 0 {
			for _, it := range a.tics.list {
				if it.x >= lo-1e-9*(hi-lo) && it.x <= hi+1e-9*(hi-lo) {
					L.tics = append(L.tics, it.x)
					if it.has {
						L.labels = append(L.labels, it.label)
					} else {
						L.labels = append(L.labels, gprintfBase(a.format, it.x, 0))
					}
				}
			}
		} else {
			start := math.Ceil(lo/step-1e-9) * step
			if a.tics.hasStart {
				start = a.tics.start
				for start < lo-1e-9*step {
					start += step
				}
			}
			for v := start; v <= hi+1e-9*step; v += step {
				t := v
				if math.Abs(t) < step*1e-9 {
					t = 0
				}
				if a.tics.hasEnd && t > a.tics.end+1e-9*step {
					break
				}
				L.tics = append(L.tics, t)
				L.labels = append(L.labels, gprintfBase(a.format, t, 0))
			}
		}
	}
	return L
}

var dumbLineChars = []rune("*#$%@&=*")

func renderPlot(cs []*Curve, is3d bool) {
	if S.termName == "unknown" {
		stderr.WriteString("WARNING: Plotting with an 'unknown' terminal.\nNo output will be generated. Please select a terminal with 'set terminal'.\n")
		return
	}
	if S.termName != "dumb" {
		return
	}
	if is3d {
		return
	}
	W, H := S.termW, S.termH
	if W == 0 {
		W, H = 79, 24
	}
	var cv *Canvas
	if mp != nil && mp.canvas != nil {
		cv = mp.canvas
	} else {
		cv = newCanvas(W, H)
		if mp != nil {
			mp.canvas = cv
		}
	}
	// data ranges
	xa, ya := S.axes["x"], S.axes["y"]
	dxmin, dxmax := math.Inf(1), math.Inf(-1)
	dymin, dymax := math.Inf(1), math.Inf(-1)
	haveX, haveY := false, false
	for _, c := range cs {
		for _, p := range c.pts {
			if p.typ == PT_UNDEF || p.typ == PT_BREAK {
				continue
			}
			inX := !outOfRange(xa, p.x)
			if inX || true {
				if p.x < dxmin {
					dxmin = p.x
				}
				if p.x > dxmax {
					dxmax = p.x
				}
				haveX = true
			}
			if !inX {
				continue
			}
			ys := []float64{p.y}
			if c.style == "boxes" || c.style == "impulses" {
				ys = append(ys, 0)
			}
			for _, y := range ys {
				if outOfRange(ya, y) {
					continue
				}
				if y < dymin {
					dymin = y
				}
				if y > dymax {
					dymax = y
				}
				haveY = true
			}
		}
	}
	XL := computeAxis(xa, dxmin, dxmax, haveX)
	YL := computeAxis(ya, dymin, dymax, haveY)
	// layout
	top := 1
	if S.title != "" {
		top = 3
	}
	bottom := H - 3
	if xa.label != "" {
		bottom = H - 4
	}
	ylw := 0
	for _, l := range YL.labels {
		if n := len([]rune(l)); n > ylw {
			ylw = n
		}
	}
	left := ylw + 2
	if ya.label != "" {
		left += len([]rune(ya.label)) + 1
	}
	right := W - 4
	mapX := func(x float64) float64 {
		return float64(left) + (x-XL.min)/(XL.max-XL.min)*float64(right-left)
	}
	ybot := H - 1 - bottom
	ytop := H - 1 - top
	mapY := func(y float64) float64 {
		return float64(ybot) + (y-YL.min)/(YL.max-YL.min)*float64(ytop-ybot)
	}
	rnd := func(v float64) int { return int(math.Floor(v + 0.5)) }
	rowOf := func(yv int) int { return H - 1 - yv }
	// grid
	if S.grid && ya.grid {
		for _, t := range YL.tics {
			r := rowOf(rnd(mapY(t)))
			if r <= top || r >= bottom {
				continue
			}
			for x := left + 1; x < right; x++ {
				cv.set(x, r, '.')
			}
		}
	}
	if S.grid && xa.grid {
		for _, t := range XL.tics {
			col := rnd(mapX(t))
			if col <= left || col >= right {
				continue
			}
			for r := top + 1; r < bottom; r++ {
				cv.set(col, r, ':')
			}
		}
	}
	// tics
	if ya.tics.on {
		for i, t := range YL.tics {
			r := rowOf(rnd(mapY(t)))
			cv.set(left, r, '+')
			cv.set(left+1, r, '-')
			cv.set(left+2, r, '+')
			if ya.tics.mirror {
				cv.set(right, r, '+')
				cv.set(right-1, r, '-')
				cv.set(right-2, r, '+')
			}
			lab := YL.labels[i]
			cv.text(left-1-len([]rune(lab)), r, lab)
		}
	}
	if xa.tics.on {
		for i, t := range XL.tics {
			col := rnd(mapX(t))
			cv.set(col, bottom, '+')
			cv.set(col, bottom-1, '+')
			if xa.tics.mirror {
				cv.set(col, top, '+')
				cv.set(col, top+1, '+')
			}
			lab := XL.labels[i]
			n := len([]rune(lab))
			cv.text(col-n/2, bottom+1, lab)
		}
	}
	// curves and key
	keyRow := top + 2
	tw := 0
	for _, c := range cs {
		if c.hasTitle {
			if n := len([]rune(c.title)); n > tw {
				tw = n
			}
		}
	}
	keyText := right - 10
	keyS0 := right - 8
	if S.key.hpos == "left" {
		keyText = left + tw
		keyS0 = left + tw + 2
	}
	inside := func(col, row int) bool {
		return col >= left && col <= right && row >= top && row <= bottom
	}
	plotPix := func(col, row int, ch rune) {
		if inside(col, row) {
			cv.set(col, row, ch)
		}
	}
	for ci, c := range cs {
		lt := c.lt
		if lt <= 0 {
			lt = ci + 1
		}
		lch := dumbLineChars[(lt-1)%len(dumbLineChars)]
		pt := c.pt
		if pt == 0 {
			pt = lt
		}
		pch := rune('A' + (pt-1)%26)
		if c.ptChar != "" {
			pch = []rune(c.ptChar)[0]
		}
		if c.style == "dots" {
			pch = '.'
		}
		drawLine := c.style == "lines" || c.style == "linespoints" || c.style == "impulses" || c.style == "steps" || c.style == "fsteps" || c.style == "histeps" || c.style == "boxes" || c.style == "filledcurves" || strings.HasSuffix(c.style, "lines")
		drawPts := c.style == "points" || c.style == "linespoints" || c.style == "dots" || strings.HasSuffix(c.style, "errorbars")
		// key entry
		if S.key.on && c.hasTitle && c.title != "" {
			sx0 := keyS0
			sx1 := sx0 + 6
			tx := keyText
			lab := c.title
			cv.text(tx-len([]rune(lab))+1, keyRow, lab)
			if drawLine {
				for x := sx0; x <= sx1; x++ {
					cv.set(x, keyRow, lch)
				}
			}
			if drawPts {
				cv.set((sx0+sx1)/2, keyRow, pch)
			}
			keyRow++
		}
		var prev *Pt
		for i := range c.pts {
			p := &c.pts[i]
			if p.typ == PT_UNDEF || p.typ == PT_BREAK {
				prev = nil
				continue
			}
			fx, fy := mapX(p.x), mapY(p.y)
			switch c.style {
			case "impulses":
				y0 := mapY(0)
				if YL.min > 0 {
					y0 = mapY(YL.min)
				}
				dumbLine(fx, y0, fx, fy, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
			case "boxes":
				y0 := mapY(math.Max(0, YL.min))
				x0 := fx
				x1 := fx
				if len(p.ex) == 2 && p.ex[0] != p.ex[1] {
					x0, x1 = mapX(p.ex[0]), mapX(p.ex[1])
				}
				for _, seg := range [][4]float64{{x0, y0, x0, fy}, {x0, fy, x1, fy}, {x1, fy, x1, y0}} {
					dumbLine(seg[0], seg[1], seg[2], seg[3], func(col, yv int) { plotPix(col, rowOf(yv), lch) })
				}
			default:
				if drawLine && prev != nil {
					px, py := mapX(prev.x), mapY(prev.y)
					if c.style == "steps" {
						dumbLine(px, py, fx, py, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
						dumbLine(fx, py, fx, fy, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
					} else if c.style == "fsteps" {
						dumbLine(px, py, px, fy, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
						dumbLine(px, fy, fx, fy, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
					} else {
						dumbLine(px, py, fx, fy, func(col, yv int) { plotPix(col, rowOf(yv), lch) })
					}
				}

			}
			if c.style == "labels" && p.typ == PT_IN {
				col := rnd(fx) - len([]rune(p.label))/2
				cv.text(col, rowOf(rnd(fy)), p.label)
			}
			prev = p
		}
		if drawPts {
			for _, p := range c.pts {
				if p.typ == PT_IN {
					plotPix(rnd(mapX(p.x)), rowOf(rnd(mapY(p.y))), pch)
				}
			}
		}
	}
	// labels
	for _, l := range S.labels {
		var col, row int
		switch l.coord {
		case "graph":
			col = rnd(float64(left) + l.x*float64(right-left))
			row = rowOf(rnd(float64(ybot) + l.y*float64(ytop-ybot)))
		case "screen":
			col = rnd(l.x * float64(W-1))
			row = rowOf(rnd(l.y * float64(H-1)))
		default:
			col = rnd(mapX(l.x))
			row = rowOf(rnd(mapY(l.y)))
		}
		n := len([]rune(l.text))
		switch l.just {
		case "center":
			col -= n / 2
		case "right":
			col -= n - 1
		}
		cv.text(col, row, l.text)
	}
	// border
	if S.border&1 != 0 {
		for x := left; x <= right; x++ {
			cv.set(x, bottom, '-')
		}
	}
	if S.border&4 != 0 {
		for x := left; x <= right; x++ {
			cv.set(x, top, '-')
		}
	}
	if S.border&2 != 0 {
		for r := top; r <= bottom; r++ {
			cv.set(left, r, '|')
		}
	}
	if S.border&8 != 0 {
		for r := top; r <= bottom; r++ {
			cv.set(right, r, '|')
		}
	}
	if S.border&3 != 0 {
		cv.set(left, bottom, '+')
	}
	if S.border&9 != 0 {
		cv.set(right, bottom, '+')
	}
	if S.border&6 != 0 {
		cv.set(left, top, '+')
	}
	if S.border&12 != 0 {
		cv.set(right, top, '+')
	}
	// title and axis labels
	if S.title != "" {
		center := (left + right) / 2
		cv.text(center-len([]rune(S.title))/2, top-1, S.title)
	}
	if xa.label != "" {
		center := (left + right) / 2
		cv.text(center-len([]rune(xa.label))/2, H-2, xa.label)
	}
	if ya.label != "" {
		cv.text(1, (top+bottom+1)/2, ya.label)
	}
	if mp == nil {
		flushCanvas(cv)
	}
}

// dumbLine draws from (x0,y0) to (x1,y1) in cell units
func dumbLine(x0, y0, x1, y1 float64, f func(int, int)) {
	ix0, iy0 := int(math.Floor(x0+0.5)), int(math.Floor(y0+0.5))
	ix1, iy1 := int(math.Floor(x1+0.5)), int(math.Floor(y1+0.5))
	dx := ix1 - ix0
	dy := iy1 - iy0
	if abs(dx) >= abs(dy) {
		n := abs(dx)
		if n == 0 {
			f(ix0, iy0)
			return
		}
		for i := 0; i <= n; i++ {
			x := ix0 + i*sgnI(dx)
			y := float64(iy0) + float64(dy)*float64(i)/float64(n)
			f(x, int(math.Floor(y+0.5)))
		}
	} else {
		n := abs(dy)
		for i := 0; i <= n; i++ {
			y := iy0 + i*sgnI(dy)
			x := float64(ix0) + float64(dx)*float64(i)/float64(n)
			f(int(math.Floor(x+0.5)), y)
		}
	}
}

func abs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}
func sgnI(a int) int {
	if a < 0 {
		return -1
	}
	return 1
}
