package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

var stdout = bufio.NewWriterSize(os.Stdout, 65536)
var stderr = bufio.NewWriterSize(os.Stderr, 65536)

type gpError struct {
	msg  string
	pos  int // -1 no caret
	tok  *Token
	line int
}

type exitReq struct{ code int }

// execution context
type Ctx struct {
	name     string // file name ("" for -e / stdin)
	mode     int    // 0 -e, 1 file, 2 stdin
	line     string // full text of the chunk being executed
	lineno   int    // line number of start of chunk
	multi    bool   // chunk spans multiple lines
	echoOff  int    // for single-line blocks: offset of echo text start
	echoText string
	curTokLine int
}

var ctx = &Ctx{}
var stdinErrors = false

func emit(s string) { stderr.WriteString(s) }

func throwAt(pos int, msg string) { panic(&gpError{msg: msg, pos: pos}) }
func throwNC(msg string)          { panic(&gpError{msg: msg, pos: -1}) }

func locPrefix() string {
	ln := ctx.curTokLine
	if ctx.mode == 2 {
		return "         line 0: "
	}
	if ctx.name == "" {
		return "line " + itoa(ln) + ": "
	}
	return "\"" + ctx.name + "\" line " + itoa(ln) + ": "
}

func warn(msg string) {
	flushPrint()
	emit(locPrefix() + "warning: " + msg + "\n")
}

func lineOfPos(pos int) int {
	if ctx.mode != 1 {
		return ctx.lineno
	}
	n := ctx.lineno
	for i := 0; i < pos && i < len(ctx.line); i++ {
		if ctx.line[i] == '\n' {
			n++
		}
	}
	return n
}

func reportError(e *gpError) {
	flushPrint()
	if e.pos >= 0 {
		ctx.curTokLine = lineOfPos(e.pos)
	}
	if e.pos >= 0 && !ctx.multi {
		text := ctx.line
		pos := e.pos
		if ctx.echoText != "" || ctx.echoOff > 0 {
			text = ctx.echoText
			pos -= ctx.echoOff
			if pos < 0 {
				pos = 0
			}
		}
		if ctx.mode == 2 {
			emit("\ngnuplot> " + text + "\n" + strings.Repeat(" ", pos+9) + "^\n")
		} else {
			emit("\n" + text + "\n" + strings.Repeat(" ", pos) + "^\n")
		}
	}
	emit(locPrefix() + e.msg + "\n\n")
}

func flushAll() {
	flushPrint()
	stdout.Flush()
	stderr.Flush()
	closePrintFile()
}

func exitProg(code int) {
	flushAll()
	os.Exit(code)
}

func main() {
	args := os.Args[1:]
	type action struct {
		kind int // 0 -e, 1 file, 2 stdin, 3 -c
		s    string
		args []string
	}
	var acts []action
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			stdout.WriteString("gnuplot 5.4 patchlevel 9\n")
			exitProg(0)
		case a == "-h" || a == "--help":
			stdout.WriteString("Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\ngnuplot 5.4 patchlevel 9\n")
			exitProg(0)
		case a == "-e":
			if i+1 < len(args) {
				acts = append(acts, action{kind: 0, s: args[i+1]})
				i++
			}
		case a == "-c":
			if i+1 < len(args) {
				acts = append(acts, action{kind: 3, s: args[i+1], args: args[i+2:]})
			}
			i = len(args)
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings" || a == "-persist":
		case a == "-":
			acts = append(acts, action{kind: 2})
		case strings.HasPrefix(a, "-") && len(a) > 1:
			stdout.WriteString("unrecognized option " + a + "\n")
			stdout.WriteString("Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\ngnuplot 5.4 patchlevel 9\n")
			exitProg(0)
		default:
			acts = append(acts, action{kind: 1, s: a})
		}
	}
	initState()
	if len(acts) == 0 {
		acts = append(acts, action{kind: 2})
	}
	defer func() {
		if r := recover(); r != nil {
			if ex, ok := r.(exitReq); ok {
				exitProg(ex.code)
			}
			panic(r)
		}
	}()
	for _, a := range acts {
		switch a.kind {
		case 0:
			runTop(func() { runString(a.s) })
		case 1:
			runTop(func() { loadFile(a.s, nil, false) })
		case 3:
			runTop(func() { loadFile(a.s, a.args, true) })
		case 2:
			runStdin()
		}
	}
	if stdinErrors {
		exitProg(1)
	}
	exitProg(0)
}

func runTop(f func()) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*gpError); ok {
				reportError(e)
				exitProg(1)
			}
			panic(r)
		}
	}()
	f()
}

func runString(s string) {
	saved := *ctx
	ctx.name = ""
	ctx.mode = 0
	ctx.lineno = 0
	ctx.curTokLine = 0
	execChunk(s, 0, false)
	*ctx = saved
}

func readLines(r *bufio.Reader) []string {
	var lines []string
	for {
		l, err := r.ReadString('\n')
		if len(l) > 0 {
			l = strings.TrimSuffix(l, "\n")
			l = strings.TrimSuffix(l, "\r")
			lines = append(lines, l)
		}
		if err != nil {
			break
		}
	}
	return lines
}

type LineSrc struct {
	lines []string
	i     int
}

func (s *LineSrc) next() (string, bool) {
	if s.i >= len(s.lines) {
		return "", false
	}
	l := s.lines[s.i]
	s.i++
	return l, true
}

var callArgsStack [][]string

func loadFile(name string, args []string, isCall bool) {
	var f *os.File
	var err error
	if name == "-" {
		f = os.Stdin
	} else {
		f, err = os.Open(name)
	}
	if err != nil {
		throwNC("Cannot load input from '" + name + "'")
	}
	lines := readLines(bufio.NewReader(f))
	if f != os.Stdin {
		f.Close()
	}
	var savedArgs map[string]*Value
	if isCall {
		savedArgs = map[string]*Value{}
		for _, k := range []string{"ARGC", "ARG0", "ARGV", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"} {
			savedArgs[k] = gvars[k]
		}
		setVar("ARGC", IntV(int64(len(args))))
		setVar("ARG0", StrV(name))
		arr := make([]Value, len(args))
		for i := 1; i <= 9; i++ {
			if i <= len(args) {
				setVar("ARG"+itoa(i), StrV(args[i-1]))
			} else {
				setVar("ARG"+itoa(i), StrV(""))
			}
		}
		for i, a := range args {
			arr[i] = StrV(a)
			if n := numPrefix(a); n > 0 && n == len(a) {
				arr[i] = strToNumQuiet(a)
			}
		}
		setVar("ARGV", Value{T: ARR, A: &arr})
		callArgsStack = append(callArgsStack, args)
	}
	saved := *ctx
	ctx.name = name
	ctx.mode = 1
	src := &LineSrc{lines: lines}
	runLines(src, 1)
	*ctx = saved
	if isCall {
		callArgsStack = callArgsStack[:len(callArgsStack)-1]
		for k, v := range savedArgs {
			if v == nil {
				delVar(k)
			} else {
				gvars[k] = v
			}
		}
	}
}

func strToNumQuiet(s string) Value {
	n := numPrefix(s)
	var f float64
	fmt.Sscanf(s[:n], "%g", &f)
	return FltV(f)
}

// runLines reads statements from src and executes them
func runLines(src *LineSrc, mode int) {
	lineno := 0
	for {
		l, ok := src.next()
		if !ok {
			return
		}
		lineno = src.i
		start := lineno
		// continuation
		for strings.HasSuffix(l, "\\") {
			nl, ok := src.next()
			if !ok {
				l = strings.TrimSuffix(l, "\\")
				break
			}
			l = strings.TrimSuffix(l, "\\") + nl
		}
		lineno = src.i
		start = lineno
		multi := false
		// datablock
		if db, term := isDatablockStart(l); db != "" {
			var data []string
			for {
				dl, ok := src.next()
				if !ok {
					break
				}
				if strings.TrimRight(dl, " \t") == term {
					break
				}
				data = append(data, dl)
			}
			datablocks[db] = data
			continue
		}
		for braceDepth(l) > 0 {
			nl, ok := src.next()
			if !ok {
				break
			}
			for strings.HasSuffix(nl, "\\") {
				nl2, ok := src.next()
				if !ok {
					break
				}
				nl = strings.TrimSuffix(nl, "\\") + nl2
			}
			l += "\n" + nl
			multi = true
		}
		ctx.mode = mode
		if mode == 2 {
			func() {
				defer func() {
					if r := recover(); r != nil {
						if e, ok := r.(*gpError); ok {
							reportError(e)
							stdinErrors = true
							return
						}
						panic(r)
					}
				}()
				execChunk(l, start, multi)
			}()
		} else {
			execChunk(l, start, multi)
		}
	}
}

func runStdin() {
	lines := readLines(bufio.NewReader(os.Stdin))
	saved := *ctx
	ctx.name = ""
	ctx.mode = 2
	defer func() {
		if r := recover(); r != nil {
			if _, ok := r.(exitReq); ok {
				*ctx = saved
			}
			panic(r)
		}
	}()
	runLines(&LineSrc{lines: lines}, 2)
	*ctx = saved
}

func isDatablockStart(l string) (string, string) {
	t := strings.TrimLeft(l, " \t")
	if !strings.HasPrefix(t, "$") {
		return "", ""
	}
	i := 1
	for i < len(t) && (isAlpha(t[i]) || isDigit(t[i])) {
		i++
	}
	name := t[:i]
	rest := strings.TrimLeft(t[i:], " \t")
	if !strings.HasPrefix(rest, "<<") {
		return "", ""
	}
	term := strings.TrimSpace(rest[2:])
	if term == "" {
		return "", ""
	}
	return name, term
}

// braceDepth counts unbalanced { outside of strings and comments
func braceDepth(l string) int {
	d := 0
	inS := byte(0)
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inS != 0 {
			if c == '\\' && inS == '"' {
				i++
				continue
			}
			if c == inS {
				inS = 0
			}
			continue
		}
		switch c {
		case '"', '\'':
			inS = c
		case '#':
			for i < len(l) && l[i] != '\n' {
				i++
			}
		case '{':
			d++
		case '}':
			d--
		}
	}
	return d
}

func execChunk(l string, lineno int, multi bool) {
	l = expandMacros(l)
	ctx.line = l
	ctx.lineno = lineno
	ctx.multi = multi
	ctx.curTokLine = lineno
	ctx.echoText = ""
	ctx.echoOff = 0
	toks := lexLine(l)
	execTokens(toks)
}

func expandMacros(l string) string {
	if !strings.Contains(l, "@") {
		return l
	}
	var b strings.Builder
	inS := byte(0)
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inS != 0 {
			b.WriteByte(c)
			if c == '\\' && inS == '"' && i+1 < len(l) {
				i++
				b.WriteByte(l[i])
				continue
			}
			if c == inS {
				inS = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			inS = c
			b.WriteByte(c)
			continue
		}
		if c == '#' {
			b.WriteString(l[i:])
			break
		}
		if c == '@' && i+1 < len(l) && isAlpha(l[i+1]) {
			j := i + 1
			for j < len(l) && (isAlpha(l[j]) || isDigit(l[j])) {
				j++
			}
			name := l[i+1 : j]
			v, ok := gvars[name]
			if !ok || v.T != STR {
				warn(name + " is not a string variable")
				i = j - 1
				continue
			}
			b.WriteString(v.S)
			i = j - 1
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

func execTokens(toks []Token) {
	execSub(&Parser{toks: toks, line: ctx.line})
}

func tokText(p *Parser, t *Token) string {
	return p.line[t.Pos:t.End]
}
