package main

import (
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                   int
	mean, sd, ssd, skew, kurt, adev     float64
	sum, sumsq, min, max                float64
	imin, imax                          int
	median, loq, upq                    float64
	merr, sderr, skerr, kuerr           float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x > s.max {
			s.max = x
			s.imax = i
		}
	}
	N := float64(n)
	s.mean = s.sum / N
	var m2, m3, m4 float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		s.adev += math.Abs(d)
	}
	s.adev /= N
	s.sd = math.Sqrt(m2 / N)
	if n > 1 {
		s.ssd = math.Sqrt(m2 / (N - 1))
	}
	if s.sd > 0 {
		s.skew = (m3 / N) / (s.sd * s.sd * s.sd)
		s.kurt = (m4 / N) / (s.sd * s.sd * s.sd * s.sd)
	}
	s.merr = s.sd / math.Sqrt(N)
	s.sderr = s.sd / math.Sqrt(2*N)
	s.skerr = math.Sqrt(6 / N)
	s.kuerr = math.Sqrt(24 / N)
	sv := append([]float64(nil), v...)
	sort.Float64s(sv)
	s.median = medianOf(sv)
	if n >= 2 {
		s.loq = medianOf(sv[:n/2])
		s.upq = medianOf(sv[(n+1)/2:])
	} else {
		s.loq, s.upq = sv[0], sv[0]
	}
	return s
}

func medianOf(sv []float64) float64 {
	n := len(sv)
	if n == 0 {
		return 0
	}
	if n%2 == 1 {
		return sv[n/2]
	}
	return (sv[n/2-1] + sv[n/2]) / 2
}

func cmdStats(p *Parser) {
	st := p.pos()
	t := p.cur()
	e := &PlotElem{}
	if t.K == TDOLLAR {
		e.src = t.S
		e.srcKind = 1
		p.c++
	} else {
		v := evalNode(p.parseExpr(), st)
		if v.T != STR {
			throwAt(st, "expecting filename")
		}
		e.src = v.S
		if e.src == "" {
			e.src = lastDataFile
		}
	}
	prefix := "STATS"
	output := true
	for !p.endOfCmd() {
		w := p.tokStr()
		switch {
		case optMatch(w, "u$sing"):
			sub := &Parser{toks: p.toks, c: p.c, line: p.line}
			// reuse plot element parser for using/index/every
			pe := parseDataMods(sub, e)
			_ = pe
			p.c = sub.c
		case optMatch(w, "i$ndex"), optMatch(w, "ev$ery"):
			sub := &Parser{toks: p.toks, c: p.c, line: p.line}
			parseDataMods(sub, e)
			p.c = sub.c
		case w == "name":
			p.c++
			prefix = p.evalStr()
		case optMatch(w, "nooutput"):
			p.c++
			output = false
		case optMatch(w, "output"):
			p.c++
			output = true
		case w == "prefix":
			p.c++
			prefix = p.evalStr()
		case w == "matrix":
			p.c++
		default:
			throwAt(p.pos(), "Unrecognized option. See 'help stats'.")
		}
	}
	var xs, ys []float64
	records, blank, blocks := 0, 0, 0
	invalid := 0
	ncols := 0
	if e.usingSet {
		ncols = len(e.using)
	}
	lines := loadDataLines(e)
	// count blanks and blocks
	prevBlank := 0
	sawData := false
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
			prevBlank++
			continue
		}
		if isCommentLine(l) {
			continue
		}
		if !sawData || prevBlank >= 2 {
			blocks++
		}
		sawData = true
		prevBlank = 0
	}
	readData(e, 1, func(r Record) {
		if r.brk {
			return
		}
		if !r.ok {
			return
		}
		if r.undef {
			invalid++
			return
		}
		vals := r.vals
		if !e.usingSet {
			if ncols == 0 {
				ncols = len(vals)
				if len(r.vals) > 2 && ncols > 2 {
					ncols = 2
				}
			}
		}
		if ncols >= 2 && !(e.usingSet) {
			if len(vals) < 2 {
				return
			}
			xs = append(xs, vals[0])
			ys = append(ys, vals[1])
		} else if ncols >= 2 {
			xs = append(xs, vals[0])
			ys = append(ys, vals[1])
		} else {
			if !e.usingSet && len(r.vals) == 2 {
				xs = append(xs, r.vals[1])
			} else {
				xs = append(xs, vals[0])
			}
		}
		records++
	})
	if records == 0 {
		throwNC("All points out of range")
	}
	two := ncols >= 2
	o := func(s string) {
		if output {
			printOut(s)
		}
	}
	_ = st
	o("\n* FILE: \n")
	o(cfmt("  %-15s%5d\n", "Records:", records))
	o(cfmt("  %-15s%5d\n", "Out of range:", 0))
	o(cfmt("  %-15s%5d\n", "Invalid:", invalid))
	o(cfmt("  %-15s%5d\n", "Header records:", 0))
	o(cfmt("  %-15s%5d\n", "Blank:", blank))
	o(cfmt("  %-15s%5d\n", "Data Blocks:", blocks))
	sx := computeStats(xs)
	setVar(prefix+"_records", IntV(int64(records)))
	setVar(prefix+"_invalid", IntV(int64(invalid)))
	setVar(prefix+"_headers", IntV(0))
	setVar(prefix+"_blank", IntV(int64(blank)))
	setVar(prefix+"_blocks", IntV(int64(blocks)))
	setVar(prefix+"_outofrange", IntV(0))
	setVar(prefix+"_columns", IntV(int64(maxCols(lines))))
	if !two {
		o("\n* COLUMN: \n")
		o(cfmt("  %-14s%12.4f\n", "Mean:", sx.mean))
		o(cfmt("  %-14s%12.4f\n", "Std Dev:", sx.sd))
		o(cfmt("  %-14s%12.4f\n", "Sample StdDev:", sx.ssd))
		o(cfmt("  %-14s%12.4f\n", "Skewness:", sx.skew))
		o(cfmt("  %-14s%12.4f\n", "Kurtosis:", sx.kurt))
		o(cfmt("  %-14s%12.4f\n", "Avg Dev:", sx.adev))
		o(cfmt("  %-14s%12.4f\n", "Sum:", sx.sum))
		o(cfmt("  %-14s%12.4f\n", "Sum Sq.:", sx.sumsq))
		o("\n")
		o(cfmt("  %-14s%12.4f\n", "Mean Err.:", sx.merr))
		o(cfmt("  %-14s%12.4f\n", "Std Dev Err.:", sx.sderr))
		o(cfmt("  %-14s%12.4f\n", "Skewness Err.:", sx.skerr))
		o(cfmt("  %-14s%12.4f\n", "Kurtosis Err.:", sx.kuerr))
		o("\n")
		o(cfmt("  %-14s%12.4f [%d]\n", "Minimum:", sx.min, sx.imin))
		o(cfmt("  %-14s%12.4f [%d]\n", "Maximum:", sx.max, sx.imax))
		o(cfmt("  %-14s%12.4f \n", "Quartile:", sx.loq))
		o(cfmt("  %-14s%12.4f \n", "Median:", sx.median))
		o(cfmt("  %-14s%12.4f \n", "Quartile:", sx.upq))
		o("\n")
		setStatVars(prefix, "", sx)
		return
	}
	sy := computeStats(ys)
	o("\n* COLUMNS:\n")
	row := func(l string, a, b float64) { o(cfmt("  %-14s%12.4f %17.4f\n", l, a, b)) }
	row("Mean:", sx.mean, sy.mean)
	row("Std Dev:", sx.sd, sy.sd)
	row("Sample StdDev:", sx.ssd, sy.ssd)
	row("Skewness:", sx.skew, sy.skew)
	row("Kurtosis:", sx.kurt, sy.kurt)
	row("Avg Dev:", sx.adev, sy.adev)
	row("Sum:", sx.sum, sy.sum)
	row("Sum Sq.:", sx.sumsq, sy.sumsq)
	o("\n")
	row("Mean Err.:", sx.merr, sy.merr)
	row("Std Dev Err.:", sx.sderr, sy.sderr)
	row("Skewness Err.:", sx.skerr, sy.skerr)
	row("Kurtosis Err.:", sx.kuerr, sy.kuerr)
	o("\n")
	o(cfmt("  %-14s%12.4f [%d] %13.4f [%d]\n", "Minimum:", sx.min, sx.imin, sy.min, sy.imin))
	o(cfmt("  %-14s%12.4f [%d] %13.4f [%d]\n", "Maximum:", sx.max, sx.imax, sy.max, sy.imax))
	row("Quartile:", sx.loq, sy.loq)
	row("Median:", sx.median, sy.median)
	row("Quartile:", sx.upq, sy.upq)
	o("\n")
	// linear model
	N := float64(len(xs))
	sxy := 0.0
	for i := range xs {
		sxy += xs[i] * ys[i]
	}
	sxx := sx.sumsq - sx.sum*sx.sum/N
	syy := sy.sumsq - sy.sum*sy.sum/N
	cxy := sxy - sx.sum*sy.sum/N
	slope := cxy / sxx
	icpt := sy.mean - slope*sx.mean
	corr := cxy / math.Sqrt(sxx*syy)
	resid := 0.0
	for i := range xs {
		d := ys[i] - (slope*xs[i] + icpt)
		resid += d * d
	}
	s2 := resid / (N - 2)
	slopeErr := math.Sqrt(s2 / sxx)
	icptErr := math.Sqrt(s2 * (1/N + sx.mean*sx.mean/sxx))
	sign := "+"
	ia := icpt
	if icpt < 0 {
		sign = "-"
		ia = -icpt
	}
	o(cfmt("  %-20sy = %.4g x %s %.4g\n", "Linear Model:", slope, sign, ia))
	o(cfmt("  %-20s%.4g +- %.4g\n", "Slope:", slope, slopeErr))
	o(cfmt("  %-20s%.4g +- %.4g\n", "Intercept:", icpt, icptErr))
	o(cfmt("  %-20sr = %.4g\n", "Correlation:", corr))
	o(cfmt("  %-20s%.4g\n", "Sum xy:", sxy))
	o("\n")
	setStatVars(prefix, "_x", sx)
	setStatVars(prefix, "_y", sy)
	setVar(prefix+"_slope", FltV(slope))
	setVar(prefix+"_intercept", FltV(icpt))
	setVar(prefix+"_slope_err", FltV(slopeErr))
	setVar(prefix+"_intercept_err", FltV(icptErr))
	setVar(prefix+"_correlation", FltV(corr))
	setVar(prefix+"_sumxy", FltV(sxy))
	setVar(prefix+"_pos_min_y", FltV(xs[sy.imin]))
	setVar(prefix+"_pos_max_y", FltV(xs[sy.imax]))
}

func maxCols(lines []string) int {
	m := 0
	for _, l := range lines {
		if isCommentLine(l) {
			continue
		}
		n := len(splitFields(l))
		if n > m {
			m = n
		}
	}
	return m
}

func setStatVars(prefix, suf string, s colStats) {
	setVar(prefix+"_mean"+suf, FltV(s.mean))
	setVar(prefix+"_stddev"+suf, FltV(s.sd))
	setVar(prefix+"_ssd"+suf, FltV(s.ssd))
	setVar(prefix+"_skewness"+suf, FltV(s.skew))
	setVar(prefix+"_kurtosis"+suf, FltV(s.kurt))
	setVar(prefix+"_adev"+suf, FltV(s.adev))
	setVar(prefix+"_mean_err"+suf, FltV(s.merr))
	setVar(prefix+"_stddev_err"+suf, FltV(s.sderr))
	setVar(prefix+"_skewness_err"+suf, FltV(s.skerr))
	setVar(prefix+"_kurtosis_err"+suf, FltV(s.kuerr))
	setVar(prefix+"_sum"+suf, FltV(s.sum))
	setVar(prefix+"_sumsq"+suf, FltV(s.sumsq))
	setVar(prefix+"_min"+suf, FltV(s.min))
	setVar(prefix+"_max"+suf, FltV(s.max))
	setVar(prefix+"_median"+suf, FltV(s.median))
	setVar(prefix+"_lo_quartile"+suf, FltV(s.loq))
	setVar(prefix+"_up_quartile"+suf, FltV(s.upq))
	setVar(prefix+"_index_min"+suf, IntV(int64(s.imin)))
	setVar(prefix+"_index_max"+suf, IntV(int64(s.imax)))
}

// parseDataMods parses index/every/using clauses for e
func parseDataMods(p *Parser, e *PlotElem) *PlotElem {
	for !p.endOfCmd() {
		w := p.tokStr()
		switch {
		case optMatch(w, "i$ndex"):
			p.c++
			e.indexSet = true
			a := int(p.evalNum())
			e.index = [3]int{a, a, 1}
			if p.isOp(":") {
				p.c++
				e.index[1] = int(p.evalNum())
			}
		case optMatch(w, "ev$ery"):
			p.c++
			e.everySet = true
			e.every = [6]int{1, 1, 0, 0, math.MaxInt32, math.MaxInt32}
			for k := 0; k < 6; k++ {
				if p.isOp(":") {
					p.c++
					continue
				}
				if p.endOfCmd() || p.cur().K == TNAME {
					break
				}
				e.every[k] = int(p.evalNum())
				if p.isOp(":") {
					p.c++
				} else {
					break
				}
			}
		case optMatch(w, "u$sing"):
			p.c++
			e.usingSet = true
			for {
				var u UsingCol
				if p.isOp("(") {
					p.c++
					u.expr = p.parseCommaExpr()
					p.expectOp(")", "')' expected")
					u.isExpr = true
				} else if t := p.cur(); t.K == TNUM {
					u.col = int(t.IV)
					p.c++
				} else {
					u.expr = p.parsePrimary()
					u.isExpr = true
				}
				e.using = append(e.using, u)
				if p.isOp(":") {
					p.c++
					continue
				}
				break
			}
		default:
			return e
		}
	}
	return e
}
