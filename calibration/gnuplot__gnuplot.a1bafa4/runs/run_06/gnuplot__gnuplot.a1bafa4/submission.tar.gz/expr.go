package main

import (
	"math"
	"strings"
)

type Node func() Value

type Parser struct {
	toks   []Token
	c      int
	params []string // dummy variable names when parsing a function body
	line   string
	depth  int
}

type UserFunc struct {
	name   string
	params []string
	body   Node
	text   string
}

var gvars = map[string]*Value{}
var ufuncs = map[string]*UserFunc{}
var frames [][]Value

type undefErr struct{}

func (p *Parser) at(i int) *Token {
	if p.c+i < len(p.toks) {
		return &p.toks[p.c+i]
	}
	return nil
}
func (p *Parser) cur() *Token { return p.at(0) }
func (p *Parser) isOp(s string) bool {
	t := p.cur()
	return t != nil && t.K == TOP && t.S == s
}
func (p *Parser) isName(s string) bool {
	t := p.cur()
	return t != nil && t.K == TNAME && t.S == s
}
func (p *Parser) endOfCmd() bool {
	t := p.cur()
	return t == nil || t.K == TNL || (t.K == TOP && t.S == ";")
}
func (p *Parser) pos() int {
	t := p.cur()
	if t == nil {
		if len(p.toks) == 0 {
			return len(p.line)
		}
		return len(p.line)
	}
	return t.Pos
}
func (p *Parser) expectOp(s string, msg string) {
	if !p.isOp(s) {
		throwAt(p.pos(), msg)
	}
	p.c++
}

// evalTop parses and evaluates an expression, converting undefined errors
func (p *Parser) constExpr() Value {
	st := p.pos()
	n := p.parseExpr()
	return evalNode(n, st)
}

func evalNode(n Node, st int) (v Value) {
	defer func() {
		if r := recover(); r != nil {
			if _, ok := r.(undefErr); ok {
				throwAt(st, "undefined value")
			}
			panic(r)
		}
	}()
	return n()
}

// tryEval returns ok=false if the evaluation is undefined
func tryEval(n Node) (v Value, ok bool) {
	defer func() {
		if r := recover(); r != nil {
			if _, isU := r.(undefErr); isU {
				ok = false
				return
			}
			panic(r)
		}
	}()
	v = n()
	if v.T == CMPLX && (math.IsNaN(v.R)) {
		return v, true
	}
	return v, true
}

func undef() { panic(undefErr{}) }

func (p *Parser) parseExpr() Node {
	if p.depth == 0 && p.endOfCmd() {
		throwAt(p.pos(), "constant expression required")
	}
	p.depth++
	defer func() { p.depth-- }()
	t := p.cur()
	if t != nil && t.K == TNAME {
		n1 := p.at(1)
		if n1 != nil && n1.K == TOP && n1.S == "=" {
			name := t.S
			p.c += 2
			rhs := p.parseExpr()
			return func() Value {
				v := rhs()
				setVar(name, v)
				return v
			}
		}
	}
	return p.parseTernary()
}

var varOrder []string

func setVar(name string, v Value) {
	if _, ok := gvars[name]; !ok {
		varOrder = append(varOrder, name)
	}
	nv := v
	gvars[name] = &nv
}

func delVar(name string) {
	if _, ok := gvars[name]; !ok {
		return
	}
	delete(gvars, name)
	for i, n := range varOrder {
		if n == name {
			varOrder = append(varOrder[:i:i], varOrder[i+1:]...)
			break
		}
	}
}

func (p *Parser) parseCommaExpr() Node {
	n := p.parseExpr()
	for p.isOp(",") {
		p.c++
		a := n
		b := p.parseExpr()
		n = func() Value { a(); return b() }
	}
	return n
}

func (p *Parser) parseTernary() Node {
	cond := p.parseBinary(0)
	if p.isOp("?") {
		p.c++
		a := p.parseTernary()
		p.expectOp(":", "expecting ':'")
		b := p.parseTernary()
		return func() Value {
			if truth(cond()) {
				return a()
			}
			return b()
		}
	}
	return cond
}

var binLevels = [][]string{
	{"||"}, {"&&"}, {"|"}, {"^"}, {"&"}, {"==", "!=", "eq", "ne"}, {"<", "<=", ">", ">="}, {"<<", ">>"}, {"+", "-", "."}, {"*", "/", "%"},
}

func (p *Parser) matchLevel(lv int) string {
	t := p.cur()
	if t == nil {
		return ""
	}
	for _, o := range binLevels[lv] {
		if (t.K == TOP || (t.K == TNAME && (o == "eq" || o == "ne"))) && t.S == o {
			return o
		}
	}
	return ""
}

func (p *Parser) parseBinary(lv int) Node {
	if lv >= len(binLevels) {
		return p.parseUnary()
	}
	left := p.parseBinary(lv + 1)
	for {
		op := p.matchLevel(lv)
		if op == "" {
			return left
		}
		p.c++
		right := p.parseBinary(lv + 1)
		l := left
		switch op {
		case "&&":
			left = func() Value {
				if !truth(l()) {
					return IntV(0)
				}
				return BoolV(truth(right()))
			}
		case "||":
			left = func() Value {
				if truth(l()) {
					return IntV(1)
				}
				return BoolV(truth(right()))
			}
		default:
			o := op
			left = func() Value { return binop(o, l(), right()) }
		}
	}
}

func truth(v Value) bool {
	switch v.T {
	case INT:
		return v.I != 0
	case CMPLX:
		return v.R != 0 || v.Im != 0
	case STR:
		return strToNum(v.S).Real() != 0
	}
	throwNC("non-numeric value")
	return false
}

func (p *Parser) parseUnary() Node {
	t := p.cur()
	if t != nil && t.K == TOP {
		switch t.S {
		case "-":
			p.c++
			a := p.parseUnary()
			return func() Value { return neg(a()) }
		case "+":
			p.c++
			a := p.parseUnary()
			return func() Value { return numify(a()) }
		case "!":
			p.c++
			a := p.parseUnary()
			return func() Value { return BoolV(!truth(a())) }
		case "~":
			p.c++
			a := p.parseUnary()
			return func() Value {
				v := numify(a())
				if v.T != INT {
					throwNC("~ operator requires integer operand")
				}
				return IntV(^v.I)
			}
		}
	}
	return p.parsePower()
}

func (p *Parser) parsePower() Node {
	base := p.parsePostfix()
	if p.isOp("**") {
		p.c++
		e := p.parseUnary()
		return func() Value { return power(base(), e()) }
	}
	return base
}

func (p *Parser) parsePostfix() Node {
	n := p.parsePrimary()
	for {
		if p.isOp("!") {
			nx := p.at(1)
			if nx != nil && nx.K == TOP && nx.S == "=" {
				return n
			}
			p.c++
			a := n
			n = func() Value { return factorial(a()) }
			continue
		}
		if p.isOp("[") {
			p.c++
			a := n
			var lo, hi Node
			if !p.isOp(":") {
				lo = p.parseExpr()
			}
			if p.isOp(":") {
				p.c++
				if !p.isOp("]") {
					hi = p.parseExpr()
				}
				p.expectOp("]", "missing ']'")
				l, h := lo, hi
				n = func() Value { return substrOp(a(), l, h) }
				continue
			}
			p.expectOp("]", "missing ']'")
			idx := lo
			n = func() Value { return indexOp(a(), idx()) }
			continue
		}
		return n
	}
}

func substrOp(v Value, lo, hi Node) Value {
	if v.T != STR {
		throwNC("internal error : substring range operator applied to non-STRING type")
	}
	s := []rune(v.S)
	L := len(s)
	b := 1
	e := L
	if lo != nil {
		b = int(toInt(lo()))
	}
	if hi != nil {
		e = int(toInt(hi()))
	}
	if b < 1 {
		b = 1
	}
	if e > L {
		e = L
	}
	if b > e {
		return StrV("")
	}
	return StrV(string(s[b-1 : e]))
}

func indexOp(a Value, iv Value) Value {
	if a.T == ARR {
		i := toInt(iv)
		arr := *a.A
		if i < 1 || int(i) > len(arr) {
			throwNC("array index out of range")
		}
		v := arr[i-1]
		return v
	}
	if a.T == STR {
		// single char
		i := int(toInt(iv))
		s := []rune(a.S)
		if i < 1 || i > len(s) {
			return StrV("")
		}
		return StrV(string(s[i-1]))
	}
	throwNC("internal error: index applied to non-array")
	return Value{}
}

func toInt(v Value) int64 {
	switch v.T {
	case INT:
		return v.I
	case CMPLX:
		return int64(v.R)
	case STR:
		return int64(strToNum(v.S).Real())
	}
	return 0
}

func (p *Parser) parsePrimary() Node {
	t := p.cur()
	if t == nil {
		throwAt(p.pos(), "invalid expression ")
	}
	switch t.K {
	case TNUM:
		p.c++
		var v Value
		if t.IsInt {
			v = IntV(t.IV)
		} else {
			v = FltV(t.FV)
		}
		return func() Value { return v }
	case TSTR:
		p.c++
		v := StrV(t.S)
		return func() Value { return v }
	case TDOLLAR:
		p.c++
		name := t.S
		if len(name) > 1 && isDigit(name[1]) {
			col := 0
			for _, ch := range name[1:] {
				col = col*10 + int(ch-'0')
			}
			return func() Value { return columnValue(col) }
		}
		if name == "$" && p.isOp("#") {
			p.c++
			return func() Value { return columnValue(-100) }
		}
		return func() Value {
			if db, ok := datablocks[name]; ok {
				_ = db
				return StrV(name)
			}
			throwNC("undefined variable: " + name)
			return Value{}
		}
	case TNAME:
		name := t.S
		nx := p.at(1)
		if nx != nil && nx.K == TOP && nx.S == "(" {
			return p.parseCall()
		}
		p.c++
		for i, pn := range p.params {
			if pn == name {
				idx := i
				return func() Value { return frames[len(frames)-1][idx] }
			}
		}
		return func() Value {
			v, ok := gvars[name]
			if !ok || v.T == UNDEF {
				throwNC("undefined variable: " + name)
			}
			return *v
		}
	case TOP:
		switch t.S {
		case "(":
			p.c++
			n := p.parseCommaExpr()
			p.expectOp(")", "')' expected")
			return n
		case "{":
			p.c++
			re := p.parseExpr()
			p.expectOp(",", "',' expected")
			im := p.parseExpr()
			p.expectOp("}", "'}' expected")
			return func() Value { return CpxV(re().Real(), im().Real()) }
		case "|":
			p.c++
			a := p.parseExpr()
			p.expectOp("|", "'|' expected")
			return func() Value {
				v := a()
				if v.T != ARR {
					throwNC("cardinality of non-array")
				}
				return IntV(int64(len(*v.A)))
			}
		case "[":
			// array literal
			p.c++
			var els []Node
			for !p.isOp("]") {
				els = append(els, p.parseExpr())
				if p.isOp(",") {
					p.c++
					continue
				}
				if !p.isOp("]") {
					throwAt(p.pos(), "invalid expression ")
				}
			}
			p.c++
			return func() Value {
				arr := make([]Value, len(els))
				for i, e := range els {
					arr[i] = e()
				}
				return Value{T: ARR, A: &arr}
			}
		}
	}
	throwAt(p.pos(), "invalid expression ")
	return nil
}

func (p *Parser) parseCall() Node {
	t := p.cur()
	name := t.S
	namePos := t.Pos
	p.c += 2
	var args []Node
	if !p.isOp(")") {
		for {
			args = append(args, p.parseExpr())
			if p.isOp(",") {
				p.c++
				continue
			}
			break
		}
	}
	p.expectOp(")", "')' expected")
	_ = namePos
	if bf, ok := builtins[name]; ok {
		if bf.n >= 0 && len(args) != bf.n {
			if len(args) < bf.n {
				if len(args) == 0 {
					throwAt(p.toks[p.c-1].Pos, "invalid expression ")
				}
				throwNC("stack underflow (function call with missing parameters?)")
			}
			// too many: gnuplot warns
			extra := args
			f := bf.f
			nn := bf.n
			return func() Value {
				vals := make([]Value, len(extra))
				for i, a := range extra {
					vals[i] = a()
				}
				emit("\nwarning:  internal error--stack not empty!\n          (function called with too many parameters?)\n")
				return f(vals[len(vals)-nn:])
			}
		}
		f := bf.f
		return func() Value {
			vals := make([]Value, len(args))
			for i, a := range args {
				vals[i] = a()
			}
			return f(vals)
		}
	}
	return func() Value {
		uf, ok := ufuncs[name]
		if !ok {
			throwNC("undefined function: " + name)
		}
		if len(uf.params) != len(args) {
			throwNC("function " + name + " requires " + itoa(len(uf.params)) + " variable" + plural(len(uf.params)))
		}
		vals := make([]Value, len(args))
		for i, a := range args {
			vals[i] = a()
		}
		frames = append(frames, vals)
		defer func() { frames = frames[:len(frames)-1] }()
		return uf.body()
	}
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

func numify(v Value) Value {
	switch v.T {
	case INT, CMPLX:
		return v
	case STR:
		return strToNum(v.S)
	case ARR:
		throwNC("non-numeric value")
	}
	throwNC("undefined value")
	return v
}

func neg(v Value) Value {
	v = numify(v)
	if v.T == INT {
		if v.I == math.MinInt64 {
			return FltV(-float64(v.I))
		}
		return IntV(-v.I)
	}
	return CpxV(-v.R, -v.Im)
}

func cx(v Value) complex128 {
	if v.T == INT {
		return complex(float64(v.I), 0)
	}
	return complex(v.R, v.Im)
}
func fromC(c complex128) Value { return CpxV(real(c), imag(c)) }

func binop(op string, a, b Value) Value {
	switch op {
	case ".":
		if a.T != STR || b.T != STR {
			throwNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		return StrV(a.S + b.S)
	case "eq", "ne":
		if a.T != STR || b.T != STR {
			throwNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		if op == "eq" {
			return BoolV(a.S == b.S)
		}
		return BoolV(a.S != b.S)
	case "==", "!=":
		if a.T == STR && b.T == STR {
			r := a.S == b.S
			if op == "!=" {
				r = !r
			}
			return BoolV(r)
		}
	}
	a = numify(a)
	b = numify(b)
	if a.T == INT && b.T == INT {
		x, y := a.I, b.I
		switch op {
		case "+":
			r := x + y
			if (x >= 0) == (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) + float64(y))
			}
			return IntV(r)
		case "-":
			r := x - y
			if (x >= 0) != (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) - float64(y))
			}
			return IntV(r)
		case "*":
			if x != 0 && y != 0 {
				r := x * y
				if r/y != x || (x == -1 && y == math.MinInt64) || (y == -1 && x == math.MinInt64) {
					return FltV(float64(x) * float64(y))
				}
				return IntV(r)
			}
			return IntV(0)
		case "/":
			if y == 0 {
				undef()
			}
			return IntV(x / y)
		case "%":
			if y == 0 {
				undef()
			}
			return IntV(x % y)
		case "&":
			return IntV(x & y)
		case "|":
			return IntV(x | y)
		case "^":
			return IntV(x ^ y)
		case "<<":
			return IntV(x << uint(y))
		case ">>":
			return IntV(x >> uint(y))
		case "==":
			return BoolV(x == y)
		case "!=":
			return BoolV(x != y)
		case "<":
			return BoolV(x < y)
		case "<=":
			return BoolV(x <= y)
		case ">":
			return BoolV(x > y)
		case ">=":
			return BoolV(x >= y)
		}
	}
	switch op {
	case "%":
		throwNC("non-integer operand for %")
	case "&", "|", "^", "<<", ">>":
		throwNC("non-integer operand for " + op)
	}
	if a.Im == 0 && b.Im == 0 {
		x, y := a.Real(), b.Real()
		switch op {
		case "+":
			return FltV(x + y)
		case "-":
			return FltV(x - y)
		case "*":
			return FltV(x * y)
		case "/":
			if y == 0 {
				undef()
			}
			return FltV(x / y)
		case "==":
			return BoolV(x == y)
		case "!=":
			return BoolV(x != y)
		case "<":
			return BoolV(x < y)
		case "<=":
			return BoolV(x <= y)
		case ">":
			return BoolV(x > y)
		case ">=":
			return BoolV(x >= y)
		}
	}
	ca, cb := cx(a), cx(b)
	switch op {
	case "+":
		return fromC(ca + cb)
	case "-":
		return fromC(ca - cb)
	case "*":
		return fromC(ca * cb)
	case "/":
		if cb == 0 {
			undef()
		}
		return fromC(ca / cb)
	case "==":
		return BoolV(ca == cb)
	case "!=":
		return BoolV(ca != cb)
	case "<":
		return BoolV(real(ca) < real(cb))
	case "<=":
		return BoolV(real(ca) <= real(cb))
	case ">":
		return BoolV(real(ca) > real(cb))
	case ">=":
		return BoolV(real(ca) >= real(cb))
	}
	return Value{}
}

func power(a, b Value) Value {
	a = numify(a)
	b = numify(b)
	if a.T == INT && b.T == INT {
		x, y := a.I, b.I
		if y >= 0 {
			r := int64(1)
			ok := true
			bb := x
			e := y
			for e > 0 {
				if e&1 == 1 {
					nr := r * bb
					if bb != 0 && nr/bb != r {
						ok = false
						break
					}
					r = nr
				}
				e >>= 1
				if e > 0 {
					nb := bb * bb
					if bb != 0 && nb/bb != bb {
						ok = false
						break
					}
					bb = nb
				}
			}
			if ok {
				return IntV(r)
			}
			return FltV(math.Pow(float64(x), float64(y)))
		}
		if x == 0 {
			undef()
		}
		return FltV(math.Pow(float64(x), float64(y)))
	}
	if a.Im == 0 && b.Im == 0 {
		x, y := a.Real(), b.Real()
		if x == 0 && y < 0 {
			undef()
		}
		if x >= 0 || y == math.Trunc(y) {
			return FltV(math.Pow(x, y))
		}
	}
	ca, cb := cx(a), cx(b)
	if ca == 0 {
		if real(cb) == 0 && imag(cb) == 0 {
			return FltV(1)
		}
		return FltV(0)
	}
	return fromC(cpow(ca, cb))
}

func factorial(v Value) Value {
	v = numify(v)
	if v.T != INT {
		throwNC("factorial (!) argument must be an integer")
	}
	n := v.I
	r := int64(1)
	for i := int64(2); i <= n; i++ {
		nr := r * i
		if nr/i != r {
			return FltV(math.Gamma(float64(n) + 1))
		}
		r = nr
	}
	return IntV(r)
}

func itoa(n int) string {
	return strings.TrimSpace(cfmt("%d", n))
}
