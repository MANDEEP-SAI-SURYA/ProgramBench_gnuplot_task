package main

import (
	"math"
	"sort"
)

func uniquePts(pts []Point, mode string) []Point {
	var v []Point
	for _, p := range pts {
		if p.typ == 'u' || p.typ == 'm' {
			continue
		}
		v = append(v, p)
	}
	sort.SliceStable(v, func(i, j int) bool { return v[i].x < v[j].x })
	var out []Point
	for i := 0; i < len(v); {
		j := i
		sum := 0.0
		for j < len(v) && v[j].x == v[i].x {
			sum += v[j].y
			j++
		}
		y := sum
		if mode == "unique" {
			y = sum / float64(j-i)
		}
		out = append(out, Point{x: v[i].x, y: y, typ: 'i'})
		i = j
	}
	return out
}

func applySmooth(c *Curve) {
	pts := c.points
	switch c.spec.smooth {
	case "unique", "frequency", "cumulative", "cnormal", "fnormal":
		mode := c.spec.smooth
		u := uniquePts(pts, map[bool]string{true: "unique", false: "sum"}[mode == "unique"])
		total := 0.0
		for _, p := range u {
			total += p.y
		}
		run := 0.0
		for i := range u {
			switch mode {
			case "cumulative":
				run += u[i].y
				u[i].y = run
			case "cnormal":
				run += u[i].y
				u[i].y = run / total
			case "fnormal":
				u[i].y /= total
			}
		}
		n := len(pts)
		for len(u) < n {
			u = append(u, Point{typ: 'u', gap: len(u) == len(u)})
		}
		c.points = u
		_ = 0
	case "csplines", "acsplines", "mcsplines", "sbezier":
		u := uniquePts(pts, "unique")
		if len(u) < 2 {
			return
		}
		c.points = sampleSpline(u)
	case "bezier":
		var v []Point
		for _, p := range pts {
			if p.typ != 'u' && p.typ != 'm' {
				v = append(v, p)
			}
		}
		c.points = sampleBezier(v)
	}
}

func sampleSpline(u []Point) []Point {
	n := len(u)
	x := make([]float64, n)
	y := make([]float64, n)
	for i := range u {
		x[i], y[i] = u[i].x, u[i].y
	}
	// natural cubic spline second derivatives
	m := make([]float64, n)
	if n > 2 {
		a := make([]float64, n)
		b := make([]float64, n)
		cc := make([]float64, n)
		d := make([]float64, n)
		for i := 1; i < n-1; i++ {
			h0 := x[i] - x[i-1]
			h1 := x[i+1] - x[i]
			a[i] = h0
			b[i] = 2 * (h0 + h1)
			cc[i] = h1
			d[i] = 6 * ((y[i+1]-y[i])/h1 - (y[i]-y[i-1])/h0)
		}
		for i := 2; i < n-1; i++ {
			w := a[i] / b[i-1]
			b[i] -= w * cc[i-1]
			d[i] -= w * d[i-1]
		}
		for i := n - 2; i >= 1; i-- {
			m[i] = (d[i] - cc[i]*m[i+1]) / b[i]
		}
	}
	ns := S.samples
	var out []Point
	for k := 0; k < ns; k++ {
		xv := x[0] + float64(k)*(x[n-1]-x[0])/float64(ns-1)
		i := 0
		for i < n-2 && xv > x[i+1] {
			i++
		}
		h := x[i+1] - x[i]
		A := (x[i+1] - xv) / h
		B := (xv - x[i]) / h
		yv := A*y[i] + B*y[i+1] + ((A*A*A-A)*m[i]+(B*B*B-B)*m[i+1])*h*h/6
		out = append(out, Point{x: xv, y: yv, typ: 'i'})
	}
	return out
}

func sampleBezier(v []Point) []Point {
	n := len(v)
	if n == 0 {
		return nil
	}
	ns := S.samples
	var out []Point
	for k := 0; k < ns; k++ {
		t := float64(k) / float64(ns-1)
		var bx, by float64
		for i := 0; i < n; i++ {
			c := binom(n-1, i) * math.Pow(t, float64(i)) * math.Pow(1-t, float64(n-1-i))
			bx += c * v[i].x
			by += c * v[i].y
		}
		out = append(out, Point{x: bx, y: by, typ: 'i'})
	}
	return out
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}
