package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                   int
	mean, sd, ssd, skew, kurt, adev     float64
	sum, sumsq                          float64
	meanErr, sdErr, skewErr, kurtErr    float64
	min, max                            float64
	imin, imax                          int
	q1, med, q3                         float64
}

func computeCol(v []float64) colStats {
	var c colStats
	n := len(v)
	c.n = n
	if n == 0 {
		return c
	}
	c.min, c.max = math.Inf(1), math.Inf(-1)
	for i, x := range v {
		c.sum += x
		c.sumsq += x * x
		if x < c.min {
			c.min = x
			c.imin = i
		}
		if x > c.max {
			c.max = x
			c.imax = i
		}
	}
	fn := float64(n)
	c.mean = c.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - c.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	c.sd = math.Sqrt(m2 / fn)
	if n > 1 {
		c.ssd = math.Sqrt(m2 / (fn - 1))
	}
	if c.sd != 0 {
		c.skew = (m3 / fn) / (c.sd * c.sd * c.sd)
		c.kurt = (m4 / fn) / (c.sd * c.sd * c.sd * c.sd)
	} else {
		c.skew = math.NaN()
		c.kurt = math.NaN()
	}
	c.adev = ad / fn
	c.meanErr = c.sd / math.Sqrt(fn)
	c.sdErr = c.sd / math.Sqrt(2*fn)
	c.skewErr = math.Sqrt(6 / fn)
	c.kurtErr = math.Sqrt(24 / fn)
	s := append([]float64{}, v...)
	sort.Float64s(s)
	if n%2 == 1 {
		c.med = s[n/2]
	} else {
		c.med = (s[n/2-1] + s[n/2]) / 2
	}
	if n%4 == 0 {
		k := n / 4
		c.q1 = (s[k-1] + s[k]) / 2
		c.q3 = (s[3*k-1] + s[3*k]) / 2
	} else {
		c.q1 = s[n/4]
		c.q3 = s[n-1-n/4]
	}
	return c
}

func cmdStats(p *Parser) {
	// ranges
	xa := axes["x"]
	ya := axes["y"]
	savedX, savedY := *xa, *ya
	defer func() { *xa = savedX; *ya = savedY }()
	if p.isOp("[") {
		parseRange(p, xa)
		if p.isOp("[") {
			parseRange(p, ya)
		}
	}
	sp := &PlotSpec{indexStep: 1, style: "points"}
	sp.every = [6]int{1, 1, 0, 0, -1, -1}
	t := p.cur()
	if t.Kind == TIdent && t.Text[0] == '$' {
		sp.fname = t.Text
		sp.isBlock = true
		p.next()
	} else {
		v := p.parseExpr()()
		if v.T != VStr {
			gpErr(-1, "stats: expecting data file")
		}
		sp.fname = v.S
	}
	parseDataMods(p, sp)
	prefix := "STATS"
	output := true
	for !p.endOfCmd() {
		if p.almost("name") || p.almost("prefix") {
			p.next()
			prefix = p.parseStringArg()
			continue
		}
		if p.almost("noout$put") {
			output = false
		} else if p.almost("out$put") {
			output = true
		}
		p.next()
	}
	lines := readDataLines(sp.fname, sp.isBlock)
	// count blanks
	blank := 0
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
		}
	}
	rows := parseRows(lines)
	ncolsFile := 0
	if len(rows) > 0 {
		ncolsFile = len(rows[0].fields)
	}
	twoCol := false
	if sp.hasUsing {
		twoCol = len(sp.using) >= 2
	} else {
		twoCol = ncolsFile >= 2
	}
	nc := 1
	if twoCol {
		nc = 2
	}
	var xs, ys []float64
	invalid, outr := 0, 0
	blocks := 0
	if len(rows) > 0 {
		blocks = rows[len(rows)-1].index + 1
	}
	curRowNum = 0
	for ri := range rows {
		r := &rows[ri]
		var vals []float64
		var st int
		if !sp.hasUsing {
			cols := []UsingCol{{col: 1}}
			if twoCol {
				cols = append(cols, UsingCol{col: 2})
			}
			sp2 := *sp
			sp2.using = cols
			sp2.hasUsing = true
			vals, _, st, _ = evalUsing(&sp2, r, nc)
		} else {
			vals, _, st, _ = evalUsing(sp, r, nc)
		}
		curRowNum++
		if st != 0 {
			invalid++
			continue
		}
		x := vals[0]
		if twoCol {
			y := vals[1]
			if (!xa.autoMin && x < xa.min) || (!xa.autoMax && x > xa.max) || (!ya.autoMin && y < ya.min) || (!ya.autoMax && y > ya.max) {
				outr++
				continue
			}
			xs = append(xs, x)
			ys = append(ys, y)
		} else {
			if (!xa.autoMin && x < xa.min) || (!xa.autoMax && x > xa.max) {
				outr++
				continue
			}
			xs = append(xs, x)
		}
	}
	curRow = nil
	n := len(xs)
	if n == 0 {
		gpErr(-1, "All points out of range")
	}
	sx := computeCol(xs)
	var sy colStats
	if twoCol {
		sy = computeCol(ys)
	}
	setv := func(k string, v Value) { globals[prefix+"_"+k] = v; updateVarSeq() }
	setv("records", IntVal(int64(n)))
	setv("invalid", IntVal(int64(invalid)))
	setv("headers", IntVal(0))
	setv("blank", IntVal(int64(blank)))
	setv("blocks", IntVal(int64(blocks)))
	setv("outofrange", IntVal(int64(outr)))
	setv("columns", IntVal(int64(ncolsFile)))
	setCol := func(c colStats, suf string) {
		setv("mean"+suf, FloatVal(c.mean))
		setv("stddev"+suf, FloatVal(c.sd))
		setv("ssd"+suf, FloatVal(c.ssd))
		setv("skewness"+suf, FloatVal(c.skew))
		setv("kurtosis"+suf, FloatVal(c.kurt))
		setv("adev"+suf, FloatVal(c.adev))
		setv("mean_err"+suf, FloatVal(c.meanErr))
		setv("stddev_err"+suf, FloatVal(c.sdErr))
		setv("skewness_err"+suf, FloatVal(c.skewErr))
		setv("kurtosis_err"+suf, FloatVal(c.kurtErr))
		setv("sum"+suf, FloatVal(c.sum))
		setv("sumsq"+suf, FloatVal(c.sumsq))
		setv("min"+suf, FloatVal(c.min))
		setv("max"+suf, FloatVal(c.max))
		setv("median"+suf, FloatVal(c.med))
		setv("lo_quartile"+suf, FloatVal(c.q1))
		setv("up_quartile"+suf, FloatVal(c.q3))
		setv("index_min"+suf, IntVal(int64(c.imin)))
		setv("index_max"+suf, IntVal(int64(c.imax)))
	}
	var slope, icpt, slopeErr, icptErr, corr, sumxy float64
	if !twoCol {
		setCol(sx, "")
	} else {
		setCol(sx, "_x")
		setCol(sy, "_y")
		fn := float64(n)
		for i := range xs {
			sumxy += xs[i] * ys[i]
		}
		sxx := sx.sumsq - sx.sum*sx.sum/fn
		sxy := sumxy - sx.sum*sy.sum/fn
		syy := sy.sumsq - sy.sum*sy.sum/fn
		slope = sxy / sxx
		icpt = sy.mean - slope*sx.mean
		corr = sxy / math.Sqrt(sxx*syy)
		ssr := 0.0
		for i := range xs {
			d := ys[i] - (slope*xs[i] + icpt)
			ssr += d * d
		}
		s2 := ssr / (fn - 2)
		slopeErr = math.Sqrt(s2 / sxx)
		icptErr = math.Sqrt(s2 * (1/fn + sx.mean*sx.mean/sxx))
		if n <= 2 {
			slopeErr, icptErr = 0, 0
		}
		setv("slope", FloatVal(slope))
		setv("intercept", FloatVal(icpt))
		setv("slope_err", FloatVal(slopeErr))
		setv("intercept_err", FloatVal(icptErr))
		setv("correlation", FloatVal(corr))
		setv("sumxy", FloatVal(sumxy))
		setv("pos_min_y", FloatVal(xs[sy.imin]))
		setv("pos_max_y", FloatVal(xs[sy.imax]))
	}
	if !output {
		return
	}
	w := func(f string, a ...interface{}) { fmt.Fprintf(stderrW, f, a...) }
	if twoCol && n <= 2 {
		w("Warning:  Errors of slope and intercept are zero. There are as many data points as there are parameters.\n")
	}
	w("\n* FILE: \n")
	rw := len(fmt.Sprintf("%d", n))
	w("  Records:           %*d\n", rw, n)
	w("  Out of range:      %*d\n", rw, outr)
	w("  Invalid:           %*d\n", rw, invalid)
	w("  Header records:    %*d\n", rw, 0)
	w("  Blank:             %*d\n", rw, blank)
	w("  Data Blocks:       %*d\n", rw, blocks)
	cs := []colStats{sx}
	if twoCol {
		cs = append(cs, sy)
		w("\n* COLUMNS:\n")
	} else {
		w("\n* COLUMN: \n")
	}
	line := func(label string, get func(c colStats) float64) {
		w("  %-16s", label)
		for i, c := range cs {
			if i == 0 {
				w("%10s", sfmt(get(c)))
			} else {
				w("%18s", sfmt(get(c)))
			}
		}
		w("\n")
	}
	line("Mean:", func(c colStats) float64 { return c.mean })
	line("Std Dev:", func(c colStats) float64 { return c.sd })
	line("Sample StdDev:", func(c colStats) float64 { return c.ssd })
	line("Skewness:", func(c colStats) float64 { return c.skew })
	line("Kurtosis:", func(c colStats) float64 { return c.kurt })
	line("Avg Dev:", func(c colStats) float64 { return c.adev })
	line("Sum:", func(c colStats) float64 { return c.sum })
	line("Sum Sq.:", func(c colStats) float64 { return c.sumsq })
	w("\n")
	line("Mean Err.:", func(c colStats) float64 { return c.meanErr })
	line("Std Dev Err.:", func(c colStats) float64 { return c.sdErr })
	line("Skewness Err.:", func(c colStats) float64 { return c.skewErr })
	line("Kurtosis Err.:", func(c colStats) float64 { return c.kurtErr })
	w("\n")
	dw := len(fmt.Sprintf("%d", n-1))
	mm := func(label string, isMin bool) {
		w("  %-16s", label)
		for i, c := range cs {
			v, idx := c.max, c.imax
			if isMin {
				v, idx = c.min, c.imin
			}
			if i == 0 {
				w("%10s [%*d]", sfmt(v), dw, idx)
			} else {
				w("%14s [%*d]", sfmt(v), dw, idx)
			}
		}
		w("\n")
	}
	mm("Minimum:", true)
	mm("Maximum:", false)
	q := func(label string, get func(c colStats) float64) {
		w("  %-16s", label)
		for i, c := range cs {
			if i == 0 {
				w("%10s", sfmt(get(c)))
			} else {
				w("%18s", sfmt(get(c)))
			}
		}
		if !twoCol {
			w(" ")
		}
		w("\n")
	}
	q("Quartile:", func(c colStats) float64 { return c.q1 })
	q("Median:", func(c colStats) float64 { return c.med })
	q("Quartile:", func(c colStats) float64 { return c.q3 })
	w("\n")
	if twoCol {
		sign := '+'
		if icpt < 0 {
			sign = '-'
		}
		w("  Linear Model:       y = %s x %c %s\n", cfmt("%.4g", slope), sign, cfmt("%.4g", math.Abs(icpt)))
		w("  Slope:              %s +- %s\n", cfmt("%.4g", slope), cfmt("%.4g", slopeErr))
		w("  Intercept:          %s +- %s\n", cfmt("%.4g", icpt), cfmt("%.4g", icptErr))
		w("  Correlation:        r = %s\n", cfmt("%.4g", corr))
		w("  Sum xy:             %s\n", cfmt("%.4g", sumxy))
		w("\n")
	}
}

func sfmt(v float64) string {
	s := cfmt("%.4f", v)
	if len(s) > 10 {
		s = cfmt("%.5e", v)
	}
	return s
}
