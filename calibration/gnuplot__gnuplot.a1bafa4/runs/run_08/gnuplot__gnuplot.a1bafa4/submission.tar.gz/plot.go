package main

import (
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type UsingCol struct {
	col     int
	expr    Expr
	isStr   bool // string constant column like "name"
	colName string
	isFunc  string // xtic, ytic, ...
}

type PlotSpec struct {
	isFunc    bool
	fexpr     Expr
	ftext     string
	fname     string
	isBlock   bool
	using     []UsingCol
	hasUsing  bool
	usingText string
	srcText   string
	indexS    int
	indexE    int
	indexStep int
	hasIndex  bool
	every     [6]int // pointInc, blockInc, pointStart, blockStart, pointEnd, blockEnd
	hasEvery  bool
	smooth    string
	title     string
	titleSet  bool
	notitle   bool
	style     string
	styleSet  bool
	lt        int
	lc        string
	pt        int
	ps        float64
	lw        float64
	ticLabels []UsingCol
	binsN     int
	binsSet   bool
	binWidth  float64
	binRange  [2]float64
	binRangeSet bool
	hasBinW   bool
	paramY    Expr // parametric second function
	ftext2    string
	ticFunc   Expr
	ticAxis   string
	axes      string
	is3d      bool
	fexpr3    Expr
	ftext3    string
	fill      string
	kdBand    float64
	acsWeights bool
	pmText    string
	iterVal   *Value
	iterName  string
}

type Point struct {
	x, y, z float64
	ex      []float64
	typ     byte // 'i','o','u'
	label   string
	gap     bool // a blank line preceded this point (new block)
	xtic    string
	hasXtic bool
}

type Curve struct {
	spec   *PlotSpec
	title  string
	style  string
	points []Point
	isFunc bool
	index  int
	extraBlank bool
}

var lastPlotLine string
var lastPlotIs3d bool

func cmdReplot(p *Parser) {
	if lastPlotLine == "" {
		gpErr(-1, "no previous plot")
	}
	skipRest(p)
	toks := lexLine(lastPlotLine)
	pp := &Parser{toks: toks, line: lastPlotLine}
	pp.next()
	cmdPlot(pp, lastPlotIs3d)
}

func cmdPlot(p *Parser, is3d bool) {
	startTok := p.i
	_ = startTok
	lineStart := p.toks[p.i-1].Pos
	if p.endOfCmd() {
		p.err("function to plot expected")
	}
	// ranges
	rangeAxes := []string{"x", "y"}
	if is3d {
		rangeAxes = []string{"x", "y", "z"}
	}
	if S.parametric && !is3d {
		rangeAxes = []string{"t", "x", "y"}
	}
	saved := map[string]Axis{}
	for _, n := range axisNames {
		saved[n] = *axes[n]
	}
	ri := 0
	for p.isOp("[") {
		if ri >= len(rangeAxes) {
			break
		}
		an := rangeAxes[ri]
		// named dummy: [t=a:b]
		if p.peek(1).Kind == TIdent && p.peek(2).Kind == TOp && p.peek(2).Text == "=" {
			name := p.peek(1).Text
			p.next()
			p.next()
			p.next()
			p.toks[p.i-1] = Token{Kind: TOp, Text: "[", Pos: p.toks[p.i-1].Pos}
			p.i--
			plotDummy = name
		}
		parseRange(p, axes[an])
		ri++
	}
	specs := parsePlotSpecs(p, is3d)
	endPos := p.cur().Pos
	lastPlotLine = "plot " + strings.TrimSpace(p.line[lineStart:endPos])
	if is3d {
		lastPlotLine = "splot " + strings.TrimSpace(p.line[lineStart:endPos])
	}
	lastPlotIs3d = is3d
	// restore ranges set only inline? gnuplot keeps inline ranges for this plot only
	defer func() {
		plotDummy = ""
		for _, n := range axisNames {
			a := axes[n]
			s := saved[n]
			cmin, cmax := a.curMin, a.curMax
			*a = s
			a.curMin, a.curMax = cmin, cmax
		}
	}()
	if is3d {
		doSplot(specs)
		return
	}
	curves := evalPlot(specs)
	if S.tableOn {
		writeTable(curves)
		return
	}
	renderPlot(curves)
}

var plotDummy string

func parsePlotSpecs(p *Parser, is3d bool) []*PlotSpec {
	var specs []*PlotSpec
	for {
		if p.endOfCmd() {
			p.err("function to plot expected")
		}
		var iter *iterSpec
		if p.is("for") {
			p.next()
			iter = parseIter(p)
		}
		if iter != nil {
			save := p.i
			vals := iter.values()
			endI := p.i
			for k, v := range vals {
				globals[iter.varName] = v
				p.i = save
				sp := parseOneSpec(p, is3d)
				vv := v
				sp.iterVal = &vv
				sp.iterName = iter.varName
				specs = append(specs, sp)
				endI = p.i
				_ = k
			}
			if len(vals) == 0 {
				// skip the spec
				parseOneSpec(p, is3d)
				endI = p.i
			}
			p.i = endI
		} else {
			specs = append(specs, parseOneSpec(p, is3d))
		}
		if p.isOp(",") {
			p.next()
			continue
		}
		break
	}
	return specs
}

func parseOneSpec(p *Parser, is3d bool) *PlotSpec {
	sp := &PlotSpec{indexStep: 1, lt: -1, is3d: is3d}
	sp.every = [6]int{1, 1, 0, 0, -1, -1}
	startPos := p.cur().Pos
	t := p.cur()
	if p.almost("newhist$ogram") || p.almost("keyent$ry") {
		p.next()
		sp.isFunc = true
		sp.style = "skip"
		skipToComma(p)
		return sp
	}
	isData := false
	if t.Kind == TStr {
		isData = true
		sp.fname = t.Val.S
		p.next()
	} else if t.Kind == TIdent && t.Text[0] == '$' && !(p.peek(1).Kind == TOp && p.peek(1).Text == "[") {
		isData = true
		sp.fname = t.Text
		sp.isBlock = true
		p.next()
	} else if t.Kind == TIdent && p.isStringStart() && !(p.peek(1).Kind == TOp && p.peek(1).Text != "(") {
		e := p.parseExpr()
		v := e()
		isData = true
		sp.fname = v.S
	} else if t.Kind == TIdent && (p.peek(1).Kind == TOp && p.peek(1).Text == "(") && (t.Text == "sprintf" || t.Text == "strftime") {
		e := p.parseExpr()
		v := e()
		isData = true
		sp.fname = v.S
	}
	if isData {
		if sp.fname == "" && !sp.isBlock {
			sp.fname = lastDataFile
		}
		lastDataFile = sp.fname
		srcEnd := p.toks[p.i-1].Pos + len(p.toks[p.i-1].Text)
		sp.srcText = p.line[startPos:srcEnd]
		parseDataMods(p, sp)
	} else {
		sp.isFunc = true
		fs := p.cur().Pos
		sp.fexpr = p.parseExpr()
		sp.ftext = strings.TrimSpace(p.line[fs:p.cur().Pos])
		if S.parametric && !is3d {
			if !p.isOp(",") {
				p.err("parametric function not fully specified")
			}
			p.next()
			fs2 := p.cur().Pos
			sp.paramY = p.parseExpr()
			sp.ftext2 = strings.TrimSpace(p.line[fs2:p.cur().Pos])
		}
	}
	parseStyleMods(p, sp)
	return sp
}

var lastDataFile string

func skipToComma(p *Parser) {
	for !p.endOfCmd() && !p.isOp(",") {
		p.next()
	}
}

func parseDataMods(p *Parser, sp *PlotSpec) {
	for {
		switch {
		case p.almost("i$ndex"):
			p.next()
			sp.hasIndex = true
			if p.cur().Kind == TStr {
				// named index not supported
				p.next()
				continue
			}
			sp.indexS = int(p.parseNum())
			sp.indexE = sp.indexS
			if p.isOp(":") {
				p.next()
				sp.indexE = int(p.parseNum())
				if p.isOp(":") {
					p.next()
					sp.indexStep = int(p.parseNum())
				}
			}
		case p.almost("ev$ery"):
			p.next()
			sp.hasEvery = true
			k := 0
			for k < 6 {
				if p.isOp(":") {
					p.next()
					k++
					continue
				}
				if p.endOfCmd() || p.isOp(",") || (p.cur().Kind == TIdent) {
					break
				}
				sp.every[k] = int(p.parseNum())
			}
		case p.almost("u$sing"):
			p.next()
			us := p.cur().Pos
			parseUsing(p, sp)
			sp.hasUsing = true
			sp.usingText = p.line[us:p.toks[p.i-1].Pos+len(p.toks[p.i-1].Text)]
			sp.srcText = strings.TrimSpace(p.line[strings.Index(p.line, sp.srcText):p.toks[p.i-1].Pos+len(p.toks[p.i-1].Text)])
		case p.almost("s$mooth"):
			p.next()
			if p.cur().Kind == TIdent && !isStyleKeyword(p) {
				sp.smooth = p.next().Text
				sp.smooth = smoothFull(sp.smooth)
				if sp.smooth == "kdensity" {
					if p.almost("band$width") {
						p.next()
						sp.kdBand = p.parseNum()
					}
				}
			}
		case p.almost("bins"):
			p.next()
			sp.binsSet = true
			sp.smooth = "bins"
			for {
				if p.isOp("=") {
					p.next()
					sp.binsN = int(p.parseNum())
					continue
				}
				if p.almost("binw$idth") {
					p.next()
					if p.isOp("=") {
						p.next()
					}
					sp.binWidth = p.parseNum()
					sp.hasBinW = true
					continue
				}
				if p.almost("binr$ange") {
					p.next()
					tmp := &Axis{autoMin: true, autoMax: true}
					parseRange(p, tmp)
					sp.binRange = [2]float64{tmp.min, tmp.max}
					sp.binRangeSet = true
					continue
				}
				break
			}
		default:
			return
		}
	}
}

func isStyleKeyword(p *Parser) bool {
	return p.almost("t$itle") || p.almost("not$itle") || p.almost("w$ith") || p.almost("l$inetype") || p.almost("ax$es")
}

var smoothNames = []string{"u$nique", "f$requency", "fnormal", "c$umulative", "cn$ormal", "cs$plines", "acs$plines", "mcs$plines", "b$ezier", "sb$ezier", "k$density", "unwrap", "path", "zsort", "uniq"}

func smoothFull(w string) string {
	for _, s := range smoothNames {
		if almostEq(w, s) {
			return strings.Replace(s, "$", "", 1)
		}
	}
	gpErr(-1, "unrecognized 'smooth' option")
	return ""
}

func parseUsing(p *Parser, sp *PlotSpec) {
	for {
		var uc UsingCol
		t := p.cur()
		switch {
		case p.isOp("("):
			uc.expr = p.parsePrimary()
		case t.Kind == TNum:
			p.next()
			uc.col = int(t.Val.Real())
		case p.isOp("-") && p.peek(1).Kind == TNum:
			p.next()
			uc.col = -int(p.next().Val.Real())
		case t.Kind == TStr:
			p.next()
			uc.isStr = true
			uc.colName = t.Val.S
		case t.Kind == TIdent && (t.Text == "xtic" || t.Text == "ytic" || t.Text == "xticlabels" || t.Text == "yticlabels" || t.Text == "x2tic" || t.Text == "key"):
			p.next()
			fn := t.Text
			arg := p.parsePrimary()
			sp.ticFunc = arg
			sp.ticAxis = fn[:1]
			uc.isFunc = fn
			sp.ticLabels = append(sp.ticLabels, UsingCol{expr: arg, isFunc: fn})
			goto next
		case t.Kind == TIdent:
			uc.expr = p.parsePrimary()
		default:
			p.err("invalid expression ")
		}
		sp.using = append(sp.using, uc)
	next:
		if p.isOp(":") {
			p.next()
			continue
		}
		break
	}
}

func parseStyleMods(p *Parser, sp *PlotSpec) {
	for !p.endOfCmd() && !p.isOp(",") {
		switch {
		case p.almost("t$itle"):
			p.next()
			sp.titleSet = true
			if p.almost("col$umnheader") || p.almost("columnhead") {
				p.next()
				sp.title = "\x01col"
				if p.isOp("(") {
					p.next()
					n := int(p.parseNum())
					p.next()
					sp.title = "\x01col" + strconv.Itoa(n)
				}
				continue
			}
			v := p.parseExpr()()
			if v.T == VStr {
				sp.title = v.S
			} else {
				sp.title = v.PrintStr()
			}
		case p.almost("not$itle"):
			p.next()
			sp.notitle = true
			if p.cur().Kind == TStr {
				p.next()
			}
		case p.almost("w$ith"):
			p.next()
			w := p.next().Text
			st := styleFull(w)
			if st == "" {
				gpErr(p.toks[p.i-1].Pos, "unrecognized plot type")
			}
			sp.style = st
			sp.styleSet = true
		case p.almost("li$netype") || p.almost("lt"):
			p.next()
			sp.lt = int(p.parseNum())
		case p.almost("ls") || p.almost("lines$tyle"):
			p.next()
			sp.lt = int(p.parseNum())
		case p.almost("lc") || p.almost("linec$olor"):
			p.next()
			if p.almost("rgb$color") {
				p.next()
				v := p.parseExpr()()
				sp.lc = v.S
			} else if p.almost("pal$ette") {
				p.next()
				if p.almost("z") {
					p.next()
				}
			} else if p.almost("var$iable") {
				p.next()
			} else {
				sp.lt = int(p.parseNum())
			}
		case p.almost("pt") || p.almost("pointt$ype"):
			p.next()
			if p.cur().Kind == TStr {
				p.next()
			} else {
				sp.pt = int(p.parseNum())
			}
		case p.almost("ps") || p.almost("points$ize"):
			p.next()
			if p.almost("var$iable") {
				p.next()
			} else {
				sp.ps = p.parseNum()
			}
		case p.almost("lw") || p.almost("linew$idth"):
			p.next()
			sp.lw = p.parseNum()
		case p.almost("dt") || p.almost("dasht$ype"):
			p.next()
			if p.isOp("(") {
				for !p.isOp(")") {
					p.next()
				}
				p.next()
			} else {
				p.parseExpr()()
			}
		case p.almost("ax$es"):
			p.next()
			sp.axes = p.next().Text
		case p.almost("fs") || p.almost("fill$style"):
			p.next()
			for p.almost("solid") || p.almost("empty") || p.almost("pattern") || p.almost("transparent") || p.almost("border") || p.almost("noborder") || p.cur().Kind == TNum {
				if p.almost("border") {
					p.next()
					if p.almost("lc") || p.almost("linecolor") {
						p.next()
						if p.almost("rgb") {
							p.next()
						}
						p.next()
					} else if p.cur().Kind == TNum {
						p.next()
					}
					continue
				}
				p.next()
			}
		case p.almost("nohidden3d"), p.almost("nocontours"), p.almost("nosurface"), p.almost("pal$ette"):
			p.next()
		case p.almost("smooth") || p.almost("using") || p.almost("index") || p.almost("every"):
			parseDataMods(p, sp)
		case p.almost("whiskerbars") || p.almost("noborder") || p.almost("above") || p.almost("below") || p.almost("closed") || p.almost("x1") || p.almost("x2") || p.almost("y1") || p.almost("y2"):
			p.next()
		case p.almost("heads") || p.almost("head") || p.almost("nohead") || p.almost("filled") || p.almost("empty") || p.almost("nofilled") || p.almost("front") || p.almost("back"):
			p.next()
		case p.almost("tc") || p.almost("textcolor"):
			p.next()
			if p.almost("rgb") {
				p.next()
			}
			p.next()
		case p.almost("offset"):
			p.next()
			p.parseNum()
			for p.isOp(",") && !(p.peek(1).Kind == TStr) {
				p.next()
				p.parseNum()
			}
		case p.almost("left") || p.almost("right") || p.almost("center") || p.almost("point") || p.almost("nopoint") || p.almost("boxed") || p.almost("hypertext") || p.almost("rotate") || p.almost("norotate"):
			p.next()
			if p.isOp("by") {
				p.next()
				p.parseNum()
			}
		case p.almost("font"):
			p.next()
			p.next()
		default:
			p.err("unexpected or unrecognized token: " + p.cur().Text)
		}
	}
}

// ---------- data reading ----------

type DataRow struct {
	fields []string
	quoted []bool
	block  int // block within dataset
	index  int // dataset index
	gap    bool
	line   int
}

func splitFields(line string) ([]string, []bool) {
	var out []string
	var q []bool
	if S.dfSep != "" && S.dfSep != " " {
		parts := strings.FieldsFunc(line, func(r rune) bool { return false })
		_ = parts
		cur := ""
		for i := 0; i < len(line); i++ {
			c := line[i]
			if strings.IndexByte(S.dfSep, c) >= 0 {
				out = append(out, strings.TrimSpace(cur))
				q = append(q, false)
				cur = ""
				continue
			}
			cur += string(c)
		}
		out = append(out, strings.TrimSpace(cur))
		q = append(q, false)
		for i, f := range out {
			if len(f) >= 2 && f[0] == '"' && f[len(f)-1] == '"' {
				out[i] = f[1 : len(f)-1]
				q[i] = true
			}
		}
		return out, q
	}
	i := 0
	for i < len(line) {
		for i < len(line) && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
			i++
		}
		if i >= len(line) {
			break
		}
		if line[i] == '"' {
			j := i + 1
			for j < len(line) && line[j] != '"' {
				j++
			}
			out = append(out, line[i+1:min(j, len(line))])
			q = append(q, true)
			i = j + 1
			continue
		}
		j := i
		for j < len(line) && line[j] != ' ' && line[j] != '\t' && line[j] != '\r' {
			j++
		}
		out = append(out, line[i:j])
		q = append(q, false)
		i = j
	}
	return out, q
}

func readDataLines(fname string, isBlock bool) []string {
	if isBlock {
		db, ok := datablocks[fname]
		if !ok {
			gpErr(-1, "undefined datablock "+fname)
		}
		return db
	}
	if fname == "-" {
		var lines []string
		for {
			l, ok := curSrc.nextLine()
			if !ok || l == "e" {
				break
			}
			lines = append(lines, l)
		}
		return lines
	}
	data, err := os.ReadFile(fname)
	if err != nil {
		gpErr(-1, "Cannot find or open file \""+fname+"\"")
	}
	return readLines(string(data))
}

func isCommentLine(l string) bool {
	t := strings.TrimLeft(l, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(S.dfComments, t[0]) >= 0
}

// parse rows into datasets
func parseRows(lines []string) []DataRow {
	var rows []DataRow
	blanks := 0
	index := 0
	block := 0
	started := false
	for ln, l := range lines {
		t := strings.TrimRight(l, "\r")
		if strings.TrimSpace(t) == "" {
			blanks++
			continue
		}
		if isCommentLine(t) {
			continue
		}
		gap := false
		if started && blanks > 0 {
			if blanks >= 2 {
				index++
				block = 0
			} else {
				block++
			}
			gap = true
		}
		blanks = 0
		started = true
		// strip trailing comment
		f, q := splitFields(t)
		rows = append(rows, DataRow{fields: f, quoted: q, block: block, index: index, gap: gap, line: ln})
	}
	return rows
}

// current row context for column()
var curRow *DataRow
var curRowNum int
var curHeader []string

func fieldValue(r *DataRow, c int) (Value, int) {
	// returns value and status: 0 ok, 1 missing, 2 invalid
	if c == 0 {
		return FloatVal(float64(curRowNum)), 0
	}
	if c == -2 {
		return FloatVal(float64(r.index)), 0
	}
	if c == -1 {
		return FloatVal(float64(r.block)), 0
	}
	if c < 1 || c > len(r.fields) {
		return Value{}, 2
	}
	s := r.fields[c-1]
	if S.dfMissing != "" && s == S.dfMissing {
		return Value{}, 1
	}
	if s == "NaN" || s == "nan" {
		return FloatVal(math.NaN()), 0
	}
	v, ok := parseNumField(s)
	if !ok {
		return Value{}, 2
	}
	return FloatVal(v), 0
}

func parseNumField(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	// accept fortran d exponents
	f, err := strconv.ParseFloat(s, 64)
	if err == nil {
		return f, true
	}
	t := strings.Map(func(r rune) rune {
		if r == 'd' || r == 'D' {
			return 'e'
		}
		return r
	}, s)
	f, err = strconv.ParseFloat(t, 64)
	if err == nil {
		return f, true
	}
	// leading numeric prefix
	v, ok := strToNum(s)
	if ok {
		// require the full token numeric? gnuplot accepts prefix like "1.5abc"
		j := numPrefixLen(s)
		if j > 0 && j == len(s) {
			return v.Real(), true
		}
		if j > 0 {
			return v.Real(), true
		}
	}
	return 0, false
}

func numPrefixLen(s string) int {
	j := 0
	n := len(s)
	if j < n && (s[j] == '+' || s[j] == '-') {
		j++
	}
	st := j
	for j < n && isDigit(s[j]) {
		j++
	}
	if j < n && s[j] == '.' {
		j++
		for j < n && isDigit(s[j]) {
			j++
		}
	}
	if j == st {
		return 0
	}
	return j
}

var missingFlag bool
var invalidFlag bool

func columnFunc(a Value) Value {
	if curRow == nil {
		gpErr(-1, "column() called from invalid context")
	}
	if a.T == VStr {
		for i, h := range curHeader {
			if h == a.S {
				v, st := fieldValue(curRow, i+1)
				if st == 1 {
					missingFlag = true
				} else if st == 2 {
					invalidFlag = true
				}
				return v
			}
		}
		invalidFlag = true
		return Value{}
	}
	c := int(intOf(a))
	v, st := fieldValue(curRow, c)
	if st == 1 {
		missingFlag = true
		return FloatVal(math.NaN())
	} else if st == 2 {
		invalidFlag = true
		return Value{}
	}
	return v
}

func strcolFunc(a Value) Value {
	if curRow == nil {
		gpErr(-1, "column() called from invalid context")
	}
	c := 0
	if a.T == VStr {
		for i, h := range curHeader {
			if h == a.S {
				c = i + 1
			}
		}
	} else {
		c = int(intOf(a))
	}
	if c == 0 {
		return StrVal(strconv.Itoa(curRowNum))
	}
	if c < 1 || c > len(curRow.fields) {
		invalidFlag = true
		return StrVal("")
	}
	return StrVal(curRow.fields[c-1])
}

func colheadFunc(a Value) Value {
	c := int(intOf(a))
	if c >= 1 && c <= len(curHeader) {
		return StrVal(curHeader[c-1])
	}
	return StrVal("")
}

func validHook(a Value) Value {
	if curRow == nil {
		return IntVal(0)
	}
	c := int(intOf(a))
	_, st := fieldValue(curRow, c)
	return boolVal(st == 0)
}

func timecolFunc(a []Value) Value {
	if curRow == nil {
		gpErr(-1, "timecolumn() called from invalid context")
	}
	c := int(intOf(a[0]))
	f := S.timefmt
	if len(a) > 1 {
		f = a[1].S
	}
	if c < 1 || c > len(curRow.fields) {
		invalidFlag = true
		return Value{}
	}
	t, ok := gpStrptime(f, curRow.fields[c-1])
	if !ok {
		invalidFlag = true
		return Value{}
	}
	return FloatVal(t)
}

func init() {
	columnHook = func(v Value) Value { return columnFunc(v) }
}

// evaluate using columns for a row; returns values, label string, status (0 ok,1 missing,2 invalid)
func evalUsing(sp *PlotSpec, r *DataRow, ncolsDefault int) ([]float64, string, int, string) {
	var vals []float64
	label := ""
	xtic := ""
	cols := sp.using
	if !sp.hasUsing {
		cols = nil
		n := ncolsDefault
		if len(r.fields) == 1 && n >= 2 {
			cols = []UsingCol{{col: 0}, {col: 1}}
		} else {
			for i := 1; i <= n; i++ {
				cols = append(cols, UsingCol{col: i})
			}
		}
	}
	status := 0
	curRow = r
	columnContext = true
	defer func() { columnContext = false }()
	for ci, uc := range cols {
		if uc.expr != nil {
			missingFlag = false
			invalidFlag = false
			v := uc.expr()
			if invalidFlag {
				if status < 2 {
					status = 2
				}
				vals = append(vals, math.NaN())
				continue
			}
			if missingFlag {
				status = max(status, 1)
			}
			if v.T == VStr {
				if ci == len(cols)-1 && sp.style == "labels" {
					label = v.S
					continue
				}
				f, ok := parseNumField(v.S)
				if !ok {
					status = 2
				}
				vals = append(vals, f)
				continue
			}
			if v.T == VUndef {
				status = max(status, 2)
				vals = append(vals, math.NaN())
				continue
			}
			if v.Imag() != 0 {
				status = max(status, 2)
			}
			vals = append(vals, v.Real())
			continue
		}
		if uc.isStr {
			c := 0
			for i, h := range curHeader {
				if h == uc.colName {
					c = i + 1
				}
			}
			v, st := fieldValue(r, c)
			if st != 0 {
				status = max(status, st)
			}
			vals = append(vals, v.Real())
			continue
		}
		if sp.style == "labels" && ci == len(cols)-1 {
			if uc.col >= 1 && uc.col <= len(r.fields) {
				label = r.fields[uc.col-1]
			}
			continue
		}
		v, st := fieldValue(r, uc.col)
		if st != 0 {
			status = max(status, st)
		}
		if st == 0 {
			vals = append(vals, v.Real())
		} else {
			vals = append(vals, math.NaN())
		}
	}
	for _, tl := range sp.ticLabels {
		v := tl.expr()
		if v.T == VStr {
			xtic = v.S
		} else if v.T == VInt || v.T == VCmplx {
			// column number
			c := int(intOf(v))
			if c >= 1 && c <= len(r.fields) {
				xtic = r.fields[c-1]
			}
		}
	}
	return vals, label, status, xtic
}

func defaultStyle(sp *PlotSpec) string {
	if sp.styleSet {
		return sp.style
	}
	if sp.isFunc {
		return S.styleFunc
	}
	return S.styleData
}

func evalPlot(specs []*PlotSpec) []*Curve {
	var curves []*Curve
	xa := axes["x"]
	ya := axes["y"]
	// first pass: data
	dataXmin, dataXmax := math.Inf(1), math.Inf(-1)
	haveData := false
	for _, sp := range specs {
		if sp.style == "skip" {
			continue
		}
		sp.style = defaultStyle(sp)
		if sp.isFunc {
			continue
		}
		c := readDataCurve(sp)
		for _, pt := range c.points {
			if pt.typ == 'u' {
				continue
			}
			haveData = true
			dataXmin = math.Min(dataXmin, pt.x)
			dataXmax = math.Max(dataXmax, pt.x)
			for _, e := range xExtents(c.style, pt) {
				dataXmin = math.Min(dataXmin, e)
				dataXmax = math.Max(dataXmax, e)
			}
		}
		curves = append(curves, c)
	}
	// x range
	xmin, xmax := -10.0, 10.0
	if haveData {
		xmin, xmax = dataXmin, dataXmax
	}
	if !xa.autoMin {
		xmin = xa.min
	}
	if !xa.autoMax {
		xmax = xa.max
	}
	if xa.autoMin && xa.autoMax && !haveData && xmin > xmax {
		xmin, xmax = xmax, xmin
	}
	sampleMin, sampleMax := xmin, xmax
	if !S.tableOn && haveData {
		// extend to tics for terminal output
		smin, smax := sampleMin, sampleMax
		if xa.autoMin || xa.autoMax {
			emin, emax := extendRange(smin, smax, xa)
			if xa.autoMin {
				smin = emin
			}
			if xa.autoMax {
				smax = emax
			}
		}
		sampleMin, sampleMax = smin, smax
	}
	// functions
	res := []*Curve{}
	di := 0
	for _, sp := range specs {
		if sp.style == "skip" {
			continue
		}
		if sp.isFunc {
			res = append(res, sampleFunc(sp, sampleMin, sampleMax))
		} else {
			res = append(res, curves[di])
			di++
		}
	}
	// apply smoothing
	for _, c := range res {
		if c.spec.smooth != "" && !c.isFunc {
			applySmooth(c)
		}
	}
	// determine in/out of range types
	for _, c := range res {
		for i := range c.points {
			pt := &c.points[i]
			if pt.typ == 'u' {
				continue
			}
			pt.typ = 'i'
			if !xa.autoMin && pt.x < math.Min(xa.min, xa.max) || !xa.autoMax && pt.x > math.Max(xa.min, xa.max) {
				pt.typ = 'o'
			}
			if !ya.autoMin && pt.y < math.Min(ya.min, ya.max) || !ya.autoMax && pt.y > math.Max(ya.min, ya.max) {
				pt.typ = 'o'
			}
		}
	}
	return res
}

func xExtents(style string, pt Point) []float64 {
	switch style {
	case "xerrorbars", "xyerrorbars", "xerrorlines", "xyerrorlines":
		if len(pt.ex) >= 2 {
			return pt.ex[:2]
		}
	case "boxes":
	}
	return nil
}

func sampleFunc(sp *PlotSpec, xmin, xmax float64) *Curve {
	c := &Curve{spec: sp, isFunc: true, style: sp.style}
	c.title = sp.ftext
	if S.parametric {
		c.title = sp.ftext + ", " + sp.ftext2
	}
	if sp.titleSet {
		c.title = sp.title
	}
	n := S.samples
	dummy := S.dummy1
	if plotDummy != "" {
		dummy = plotDummy
	}
	if S.parametric {
		ta := axes["t"]
		xmin, xmax = -5, 5
		if !ta.autoMin {
			xmin = ta.min
		}
		if !ta.autoMax {
			xmax = ta.max
		}
	}
	xa := axes["x"]
	logx := xa.log && !S.parametric
	for i := 0; i < n; i++ {
		var x float64
		if logx {
			lmin, lmax := math.Log(xmin)/math.Log(xa.base), math.Log(xmax)/math.Log(xa.base)
			x = math.Pow(xa.base, lmin+float64(i)*(lmax-lmin)/float64(n-1))
		} else {
			x = xmin + float64(i)*(xmax-xmin)/float64(n-1)
		}
		pt := Point{x: x}
		y, ok := evalFuncAt(sp.fexpr, dummy, x)
		if S.parametric {
			y2, ok2 := evalFuncAt(sp.paramY, dummy, x)
			pt.x = y
			y = y2
			ok = ok && ok2
		}
		pt.y = y
		pt.typ = 'i'
		if !ok {
			pt.typ = 'u'
			pt.x = 0
			pt.y = 0
		}
		c.points = append(c.points, pt)
	}
	return c
}

func evalFuncAt(e Expr, dummy string, x float64) (y float64, ok bool) {
	frames = append(frames, map[string]Value{dummy: FloatVal(x)})
	defer func() {
		frames = frames[:len(frames)-1]
		if r := recover(); r != nil {
			if ge, isG := r.(*GPError); isG {
				if strings.HasPrefix(ge.Msg, "undefined variable") || strings.HasPrefix(ge.Msg, "undefined function") || strings.HasPrefix(ge.Msg, "Non-numeric") {
					panic(r)
				}
				ok = false
				return
			}
			panic(r)
		}
	}()
	v := e()
	if v.T == VUndef || v.T == VStr {
		return 0, false
	}
	if v.Imag() != 0 {
		return 0, false
	}
	f := v.Real()
	if math.IsNaN(f) || math.IsInf(f, 0) {
		return 0, false
	}
	return f, true
}

func readDataCurve(sp *PlotSpec) *Curve {
	c := &Curve{spec: sp, style: sp.style}
	lines := readDataLines(sp.fname, sp.isBlock)
	rows := parseRows(lines)
	curHeader = nil
	// header handling for columnheader
	needHeader := S.dfHeader || strings.HasPrefix(sp.title, "\x01col")
	for _, u := range sp.using {
		if u.isStr {
			needHeader = true
		}
	}
	if sp.usingText != "" && (strings.Contains(sp.usingText, "column(\"") || strings.Contains(sp.usingText, "columnhead")) {
		needHeader = true
	}
	if needHeader && len(rows) > 0 {
		curHeader = rows[0].fields
		rows = rows[1:]
		if len(rows) > 0 {
			rows[0].gap = false
		}
	}
	if sp.titleSet && strings.HasPrefix(sp.title, "\x01col") {
		n := 0
		if len(sp.title) > 4 {
			n, _ = strconv.Atoi(sp.title[4:])
		} else if len(sp.using) > 1 {
			n = sp.using[1].col
		} else {
			n = 2
		}
		if n >= 1 && n <= len(curHeader) {
			c.title = curHeader[n-1]
		}
	} else if sp.titleSet {
		c.title = sp.title
	} else {
		c.title = sp.srcText
	}
	ncols := 2
	switch sp.style {
	case "yerrorbars", "xerrorbars", "boxes", "yerrorlines", "xerrorlines", "boxerrorbars", "labels", "filledcurves", "circles":
		ncols = 3
	case "xyerrorbars", "xyerrorlines", "vectors", "boxxyerrorbars":
		ncols = 4
	case "candlesticks", "financebars":
		ncols = 5
	}
	// compute min columns among rows for default
	idx := -1
	curRowNum = 0
	lastIndex := -1
	lastBlock := -1
	blockCount := 0
	pointInBlock := 0
	for ri := range rows {
		r := &rows[ri]
		if sp.hasIndex {
			if r.index < sp.indexS || r.index > sp.indexE || (r.index-sp.indexS)%sp.indexStep != 0 {
				continue
			}
		}
		if r.index != lastIndex {
			if lastIndex >= 0 && !sp.hasIndex {
				// new dataset
			}
			lastIndex = r.index
			lastBlock = -1
			blockCount = -1
			curRowNum = 0
		}
		if r.block != lastBlock {
			lastBlock = r.block
			blockCount++
			pointInBlock = 0
		}
		_ = idx
		if sp.hasEvery {
			ev := sp.every
			if blockCount < ev[3] || (ev[5] >= 0 && blockCount > ev[5]) || (blockCount-ev[3])%max(ev[1], 1) != 0 {
				pointInBlock++
				continue
			}
			if pointInBlock < ev[2] || (ev[4] >= 0 && pointInBlock > ev[4]) || (pointInBlock-ev[2])%max(ev[0], 1) != 0 {
				pointInBlock++
				curRowNum++
				continue
			}
		}
		pointInBlock++
		nc := ncols
		if !sp.hasUsing {
			nc = min(len(r.fields), ncols)
			if len(r.fields) > ncols {
				nc = ncols
			}
		}
		vals, label, st, xtic := evalUsing(sp, r, nc)
		if !sp.hasUsing && st == 0 && len(r.fields) > nc {
			// check remaining columns for non-numeric
			for k := nc; k < len(r.fields); k++ {
				if _, ok := parseNumField(r.fields[k]); !ok {
					if S.dfMissing == "" || r.fields[k] != S.dfMissing {
						st = 2
					}
				}
			}
		}
		pt := Point{gap: r.gap, label: label, xtic: xtic, hasXtic: len(sp.ticLabels) > 0}
		if r.index != 0 && sp.hasIndex == false && ri > 0 && rows[ri-1].index != r.index {
			pt.gap = true
		}
		curRowNum++
		if st == 1 {
			pt.typ = 'm'
			c.points = append(c.points, pt)
			continue
		}
		if st == 2 || len(vals) == 0 {
			pt.typ = 'u'
			c.points = append(c.points, pt)
			continue
		}
		if len(vals) == 1 {
			vals = []float64{float64(curRowNum - 1), vals[0]}
		}
		pt.x = vals[0]
		pt.y = vals[1]
		pt.ex = vals[2:]
		pt.typ = 'i'
		fillExtras(c.style, &pt)
		c.points = append(c.points, pt)
	}
	curRow = nil
	return c
}

// convert raw extra columns into style-specific extras
func fillExtras(style string, pt *Point) {
	e := pt.ex
	switch style {
	case "yerrorbars", "yerrorlines", "boxerrorbars":
		if len(e) == 1 {
			pt.ex = []float64{pt.y - e[0], pt.y + e[0]}
		} else if len(e) >= 2 {
			pt.ex = []float64{e[0], e[1]}
		} else {
			pt.ex = []float64{pt.y, pt.y}
		}
	case "xerrorbars", "xerrorlines":
		if len(e) == 1 {
			pt.ex = []float64{pt.x - e[0], pt.x + e[0]}
		} else if len(e) >= 2 {
			pt.ex = []float64{e[0], e[1]}
		}
	case "xyerrorbars", "xyerrorlines":
		if len(e) == 2 {
			pt.ex = []float64{pt.x - e[0], pt.x + e[0], pt.y - e[1], pt.y + e[1]}
		} else if len(e) >= 4 {
			pt.ex = e[:4]
		}
	}
}

func tableHeader(style string) string {
	switch style {
	case "yerrorbars", "yerrorlines", "boxerrorbars":
		return "x y ylow yhigh type"
	case "xerrorbars", "xerrorlines", "boxes":
		return "x y xlow xhigh type"
	case "xyerrorbars", "xyerrorlines", "boxxyerrorbars":
		return "x y xlow xhigh ylow yhigh type"
	case "vectors":
		return "x y delta_x delta_y type"
	case "labels":
		return "x y label type"
	case "filledcurves":
		return "x y1 y2 type"
	case "candlesticks", "financebars":
		return "x open low high close type"
	}
	return "x y type"
}

func tfmt(f float64) string {
	return cfmt("% g", f)
}

func writeTable(curves []*Curve) {
	var sb strings.Builder
	for ci, c := range curves {
		sb.WriteString("\n")
		sb.WriteString("# Curve " + strconv.Itoa(ci) + " of " + strconv.Itoa(len(curves)) + ", " + strconv.Itoa(len(c.points)) + " points\n")
		sb.WriteString("# Curve title: \"" + c.title + "\"\n")
		sb.WriteString("# " + tableHeader(c.style) + "\n")
		for i, pt := range c.points {
			if pt.gap && i > 0 {
				sb.WriteString("\n")
			}
			if pt.typ == 'm' {
				continue
			}
			if pt.typ == 'u' && !c.isFunc {
				continue
			}
			_ = 0
			if c.style == "labels" {
				sb.WriteString(tfmt(pt.x) + " " + tfmt(pt.y) + " \"" + pt.label + "\"\n")
				continue
			}
			sb.WriteString(tfmt(pt.x) + " " + tfmt(pt.y) + " ")
			nex := 0
			switch c.style {
			case "yerrorbars", "yerrorlines", "boxerrorbars", "xerrorbars", "xerrorlines", "boxes", "vectors", "filledcurves":
				nex = 2
				if c.style == "filledcurves" {
					nex = 1
				}
			case "xyerrorbars", "xyerrorlines", "boxxyerrorbars":
				nex = 4
			case "candlesticks", "financebars":
				nex = 3
			}
			for k := 0; k < nex; k++ {
				v := 0.0
				if k < len(pt.ex) {
					v = pt.ex[k]
				}
				sb.WriteString(tfmt(v) + " ")
			}
			if pt.hasXtic {
				sb.WriteString(pt.xtic + " ")
			}
			sb.WriteString(" " + string(pt.typ) + "\n")
		}
		sb.WriteString("\n")
		if c.extraBlank {
			sb.WriteString("\n")
		}
	}
	out := sb.String()
	writeTableOut(out)
}

func writeTableOut(out string) {
	if S.tableBlock != "" {
		lines := strings.Split(strings.TrimSuffix(out, "\n"), "\n")
		datablocks[S.tableBlock] = append(datablocks[S.tableBlock], lines...)
		return
	}
	if S.tableFile != "" {
		f, err := os.OpenFile(S.tableFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err == nil {
			f.WriteString(out)
			f.Close()
		}
		return
	}
	termWrite(out)
}

func closeTable() {
	S.tableOn = false
	S.tableFile = ""
	S.tableBlock = ""
}

func sortPoints(pts []Point) {
	sort.SliceStable(pts, func(i, j int) bool { return pts[i].x < pts[j].x })
}
