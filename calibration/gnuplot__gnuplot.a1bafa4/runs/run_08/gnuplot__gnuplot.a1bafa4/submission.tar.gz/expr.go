package main

import (
	"math"
	"strings"
)

type Expr func() Value

type GPError struct {
	Msg    string
	Pos    int
	src    *Source
	line   string
	lineNo int
	lineZero bool
}

func gpErr(pos int, msg string) {
	panic(&GPError{Msg: msg, Pos: pos})
}

type Parser struct {
	toks []Token
	i    int
	line string
}

func (p *Parser) cur() Token      { return p.toks[p.i] }
func (p *Parser) peek(k int) Token {
	if p.i+k < len(p.toks) {
		return p.toks[p.i+k]
	}
	return p.toks[len(p.toks)-1]
}
func (p *Parser) is(s string) bool {
	t := p.toks[p.i]
	return (t.Kind == TOp || t.Kind == TIdent) && t.Text == s
}
func (p *Parser) isOp(s string) bool {
	t := p.toks[p.i]
	return t.Kind == TOp && t.Text == s
}
func (p *Parser) endOfCmd() bool {
	t := p.toks[p.i]
	return t.Kind == TEnd || (t.Kind == TOp && t.Text == ";")
}
func (p *Parser) err(msg string) {
	gpErr(p.cur().Pos, msg)
}
func (p *Parser) next() Token {
	t := p.toks[p.i]
	if t.Kind != TEnd {
		p.i++
	}
	return t
}

// almost_equals style matching: "rep$lot" means prefix "rep" required
func almostEq(word, pat string) bool {
	k := strings.IndexByte(pat, '$')
	if k < 0 {
		return word == pat
	}
	full := pat[:k] + pat[k+1:]
	if len(word) < k || len(word) > len(full) {
		return false
	}
	return strings.HasPrefix(full, word)
}
func (p *Parser) almost(pat string) bool {
	t := p.cur()
	if t.Kind != TIdent {
		return false
	}
	return almostEq(t.Text, pat)
}

// ---- interpreter state for evaluation ----

type UDF struct {
	Name   string
	Params []string
	Body   Expr
	Text   string
}

var globals = map[string]Value{}
var udfs = map[string]*UDF{}
var frames []map[string]Value

func lookupVar(name string) (Value, bool) {
	for k := len(frames) - 1; k >= 0; k-- {
		if v, ok := frames[k][name]; ok {
			return v, true
		}
		break
	}
	v, ok := globals[name]
	return v, ok
}

// parse full expression (const_express semantics)
func (p *Parser) parseConstExpr() Expr {
	if p.endOfCmd() {
		p.err("constant expression required")
	}
	return p.parseExpr()
}

func (p *Parser) parseExpr() Expr {
	// assignment at top: ident = expr
	t := p.cur()
	if t.Kind == TIdent && p.peek(1).Kind == TOp && p.peek(1).Text == "=" && t.Text[0] != '$' {
		name := t.Text
		p.i += 2
		rhs := p.parseExpr()
		return func() Value {
			v := rhs()
			globals[name] = v
			return v
		}
	}
	return p.parseTernary()
}

func (p *Parser) parseTernary() Expr {
	c := p.parseBin(0)
	if p.isOp("?") {
		p.next()
		a := p.parseExpr()
		if !p.isOp(":") {
			p.err("expecting ':'")
		}
		p.next()
		b := p.parseExpr()
		return func() Value {
			cv := c()
			if truthy(cv) {
				return a()
			}
			return b()
		}
	}
	return c
}

func truthy(v Value) bool {
	v = numeric(v)
	if v.T == VInt {
		return v.I != 0
	}
	return v.R != 0 || v.Im != 0
}

var binLevels = [][]string{
	{"||"},
	{"&&"},
	{"|"},
	{"^"},
	{"&"},
	{"==", "!=", "eq", "ne"},
	{"<", ">", "<=", ">="},
	{"<<", ">>"},
	{"+", "-", "."},
	{"*", "/", "%"},
}

func (p *Parser) parseBin(level int) Expr {
	if level >= len(binLevels) {
		return p.parseUnary()
	}
	l := p.parseBin(level + 1)
	for {
		t := p.cur()
		op := ""
		for _, o := range binLevels[level] {
			if (t.Kind == TOp || (t.Kind == TIdent && (o == "eq" || o == "ne"))) && t.Text == o {
				op = o
			}
		}
		if op == "" {
			return l
		}
		p.next()
		r := p.parseBin(level + 1)
		l = makeBin(op, l, r)
	}
}

func (p *Parser) parseUnary() Expr {
	t := p.cur()
	if t.Kind == TOp {
		switch t.Text {
		case "-":
			p.next()
			e := p.parseUnary()
			return func() Value { return negate(e()) }
		case "+":
			p.next()
			e := p.parseUnary()
			return func() Value { v := e(); return numeric(v) }
		case "!":
			p.next()
			e := p.parseUnary()
			return func() Value {
				v := numeric(e())
				if v.T != VInt {
					gpErr(-1, "non-integer passed to boolean operator")
				}
				return boolVal(v.I == 0)
			}
		case "~":
			p.next()
			e := p.parseUnary()
			return func() Value {
				v := numeric(e())
				if v.T != VInt {
					gpErr(-1, "~ only works on integers")
				}
				return IntVal(^v.I)
			}
		}
	}
	return p.parsePow()
}

func (p *Parser) parsePow() Expr {
	b := p.parsePostfix()
	if p.isOp("**") {
		p.next()
		e := p.parseUnary()
		return func() Value { return power(b(), e()) }
	}
	return b
}

func (p *Parser) parsePostfix() Expr {
	e := p.parsePrimary()
	for {
		if p.isOp("!") && !(p.peek(1).Kind == TOp && p.peek(1).Text == "=") {
			p.next()
			x := e
			e = func() Value { return factorial(x()) }
			continue
		}
		if p.isOp("[") {
			p.next()
			var lo, hi Expr
			if !p.isOp(":") {
				lo = p.parseExpr()
			}
			if p.isOp("]") && lo != nil {
				p.next()
				x := e
				idx := lo
				e = func() Value { return indexValue(x(), idx()) }
				continue
			}
			if !p.isOp(":") {
				p.err("':' expected")
			}
			p.next()
			if !p.isOp("]") {
				hi = p.parseExpr()
			}
			if !p.isOp("]") {
				p.err("']' expected")
			}
			p.next()
			x := e
			e = func() Value {
				s := x()
				if s.T != VStr {
					gpErr(-1, "internal error : substring range operator applied to non-STRING type")
				}
				var a, b int64 = 1, int64(len(s.S))
				if lo != nil {
					a = intOf(lo())
				}
				if hi != nil {
					b = intOf(hi())
				}
				return StrVal(substr(s.S, a, b))
			}
			continue
		}
		return e
	}
}

func intOf(v Value) int64 {
	v = numeric(v)
	if v.T == VInt {
		return v.I
	}
	return int64(v.R)
}

func substr(s string, a, b int64) string {
	n := int64(len(s))
	if a < 1 {
		a = 1
	}
	if b > n {
		b = n
	}
	if a > b || a > n {
		return ""
	}
	return s[a-1 : b]
}

func indexValue(v Value, idx Value) Value {
	if v.T == VArr {
		i := intOf(idx)
		arr := *v.Arr
		if i < 1 || i >= int64(len(arr)) {
			gpErr(-1, "array index out of range")
		}
		return arr[i]
	}
	gpErr(-1, "internal error: attempt to index a scalar variable")
	return Value{}
}

var columnHook func(Value) Value
var columnContext bool

func (p *Parser) parsePrimary() Expr {
	t := p.cur()
	switch t.Kind {
	case TNum:
		p.next()
		v := t.Val
		return func() Value { return v }
	case TStr:
		p.next()
		v := t.Val
		return func() Value { return v }
	case TIdent:
		name := t.Text
		if name[0] == '$' {
			p.next()
			rest := name[1:]
			if isDigit(rest[0]) {
				col := int64(0)
				for _, c := range rest {
					if c < '0' || c > '9' {
						break
					}
					col = col*10 + int64(c-'0')
				}
				pos := t.Pos + 1
				return func() Value {
					if !columnContext {
						gpErr(pos, "column() called from invalid context")
					}
					return columnHook(IntVal(col))
				}
			}
			// datablock as value
			if p.isOp("[") {
				p.next()
				idx := p.parseExpr()
				if !p.isOp("]") {
					p.err("']' expected")
				}
				p.next()
				return func() Value {
					db, ok := datablocks[name]
					if !ok {
						gpErr(-1, "no datablock named "+name)
					}
					i := intOf(idx())
					if i < 1 || i > int64(len(db)) {
						gpErr(-1, "index out of range")
					}
					return StrVal(db[i-1])
				}
			}
			return func() Value {
				db, ok := datablocks[name]
				if !ok {
					gpErr(-1, "no datablock named "+name)
				}
				arr := make([]Value, len(db)+1)
				for i, l := range db {
					arr[i+1] = StrVal(l)
				}
				return Value{T: VStr, S: strings.Join(db, "\n") + "\n", Arr: &arr}
			}
		}
		if p.peek(1).Kind == TOp && p.peek(1).Text == "(" {
			p.next()
			p.next()
			var args []Expr
			if !p.isOp(")") {
				for {
					args = append(args, p.parseExpr())
					if p.isOp(",") {
						p.next()
						continue
					}
					break
				}
			}
			if !p.isOp(")") {
				p.err("')' expected")
			}
			p.next()
			return p.makeCall(name, args, t.Pos)
		}
		if p.peek(1).Kind == TOp && p.peek(1).Text == "=" {
			p.next()
			p.next()
			rhs := p.parseExpr()
			return func() Value {
				v := rhs()
				globals[name] = v
				return v
			}
		}
		p.next()
		if name == "pi" {
			// pi is a variable that may be redefined
		}
		return func() Value {
			v, ok := lookupVar(name)
			if !ok {
				gpErr(-1, "undefined variable: "+name)
			}
			return v
		}
	case TOp:
		switch t.Text {
		case "(":
			p.next()
			e := p.parseExpr()
			for p.isOp(",") {
				p.next()
				prev := e
				nx := p.parseExpr()
				e = func() Value { prev(); return nx() }
			}
			if !p.isOp(")") {
				p.err("')' expected")
			}
			p.next()
			return e
		case "{":
			start := t.Pos
			p.next()
			re := p.parseComplexPart(start)
			if !p.isOp(",") {
				gpErr(start, "invalid complex constant")
			}
			p.next()
			im := p.parseComplexPart(start)
			if !p.isOp("}") {
				gpErr(start, "invalid complex constant")
			}
			p.next()
			v := CmplxVal(re, im)
			return func() Value { return v }
		case "|":
			// cardinality |A|
			p.next()
			e := p.parsePostfix()
			if !p.isOp("|") {
				p.err("'|' expected")
			}
			p.next()
			return func() Value {
				v := e()
				if v.T == VArr || (v.T == VStr && v.Arr != nil) {
					return IntVal(int64(len(*v.Arr) - 1))
				}
				gpErr(-1, "cardinality of non-array")
				return Value{}
			}
		case "[":
			// array literal
			p.next()
			var elems []Expr
			if !p.isOp("]") {
				for {
					elems = append(elems, p.parseExpr())
					if p.isOp(",") {
						p.next()
						continue
					}
					break
				}
			}
			if !p.isOp("]") {
				p.err("']' expected")
			}
			p.next()
			return func() Value {
				arr := make([]Value, len(elems)+1)
				for i, e := range elems {
					arr[i+1] = e()
				}
				return Value{T: VArr, Arr: &arr}
			}
		}
	}
	p.err("invalid expression ")
	return nil
}

func (p *Parser) parseComplexPart(start int) float64 {
	sign := 1.0
	if p.isOp("-") {
		sign = -1
		p.next()
	} else if p.isOp("+") {
		p.next()
	}
	t := p.cur()
	if t.Kind != TNum {
		gpErr(start, "invalid complex constant")
	}
	p.next()
	return sign * t.Val.Real()
}

func negate(v Value) Value {
	v = numeric(v)
	if v.T == VInt {
		return IntVal(-v.I)
	}
	return CmplxVal(-v.R, -v.Im)
}

func factorial(v Value) Value {
	v = numeric(v)
	if v.T != VInt {
		gpErr(-1, "factorial (!) argument must be an integer")
	}
	r := int64(1)
	ok := true
	f := 1.0
	for i := int64(2); i <= v.I; i++ {
		if ok {
			if r > math.MaxInt64/i {
				ok = false
				f = float64(r)
				f *= float64(i)
				continue
			}
			r *= i
		} else {
			f *= float64(i)
		}
	}
	if ok {
		return IntVal(r)
	}
	return FloatVal(f)
}

func undefinedValue() Value {
	return Value{T: VUndef}
}

func makeBin(op string, l, r Expr) Expr {
	switch op {
	case "&&":
		return func() Value {
			a := numeric(l())
			if a.T != VInt {
				gpErr(-1, "non-integer passed to boolean operator")
			}
			if a.I == 0 {
				return IntVal(0)
			}
			b := numeric(r())
			if b.T != VInt {
				gpErr(-1, "non-integer passed to boolean operator")
			}
			return boolVal(b.I != 0)
		}
	case "||":
		return func() Value {
			a := numeric(l())
			if a.T != VInt {
				gpErr(-1, "non-integer passed to boolean operator")
			}
			if a.I != 0 {
				return IntVal(1)
			}
			b := numeric(r())
			if b.T != VInt {
				gpErr(-1, "non-integer passed to boolean operator")
			}
			return boolVal(b.I != 0)
		}
	case ".":
		return func() Value {
			a := l()
			b := r()
			if a.T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return StrVal(a.S + toStrConcat(b))
		}
	case "eq", "ne":
		return func() Value {
			a := l()
			b := r()
			if a.T != VStr || b.T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			if op == "eq" {
				return boolVal(a.S == b.S)
			}
			return boolVal(a.S != b.S)
		}
	}
	return func() Value { return binop(op, l(), r()) }
}

func toStrConcat(v Value) string {
	switch v.T {
	case VStr:
		return v.S
	case VInt:
		return v.PrintStr()
	case VCmplx:
		return fmtG15(v.R)
	}
	gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
	return ""
}

func isUndef(v Value) bool { return v.T == VUndef }

func binop(op string, a, b Value) Value {
	if a.T == VUndef || b.T == VUndef {
		return Value{}
	}
	a = numeric(a)
	b = numeric(b)
	if a.T == VInt && b.T == VInt {
		x, y := a.I, b.I
		switch op {
		case "+":
			s := x + y
			if (x >= 0) == (y >= 0) && (s >= 0) != (x >= 0) {
				return FloatVal(float64(x) + float64(y))
			}
			return IntVal(s)
		case "-":
			s := x - y
			if (x >= 0) != (y >= 0) && (s >= 0) != (x >= 0) {
				return FloatVal(float64(x) - float64(y))
			}
			return IntVal(s)
		case "*":
			if x != 0 && y != 0 {
				s := x * y
				if s/y != x || (x == -1 && y == math.MinInt64) || (y == -1 && x == math.MinInt64) {
					return FloatVal(float64(x) * float64(y))
				}
				return IntVal(s)
			}
			return IntVal(0)
		case "/":
			if y == 0 {
				return Value{}
			}
			return IntVal(x / y)
		case "%":
			if y == 0 {
				return Value{}
			}
			return IntVal(x % y)
		case "==":
			return boolVal(x == y)
		case "!=":
			return boolVal(x != y)
		case "<":
			return boolVal(x < y)
		case ">":
			return boolVal(x > y)
		case "<=":
			return boolVal(x <= y)
		case ">=":
			return boolVal(x >= y)
		case "&":
			return IntVal(x & y)
		case "|":
			return IntVal(x | y)
		case "^":
			return IntVal(x ^ y)
		case "<<":
			return IntVal(int64(uint64(x) << uint64(y)))
		case ">>":
			return IntVal(int64(uint64(x) >> uint64(y)))
		}
	}
	switch op {
	case "&", "|", "^", "<<", ">>":
		gpErr(-1, "non-integer operand for "+op)
	case "%":
		gpErr(-1, "non-integer operand for %")
	}
	ar, ai := a.Real(), a.Imag()
	br, bi := b.Real(), b.Imag()
	switch op {
	case "+":
		return CmplxVal(ar+br, ai+bi)
	case "-":
		return CmplxVal(ar-br, ai-bi)
	case "*":
		return CmplxVal(ar*br-ai*bi, ar*bi+ai*br)
	case "/":
		if bi == 0 && ai == 0 {
			if br == 0 {
				return Value{}
			}
			return FloatVal(ar / br)
		}
		d := br*br + bi*bi
		if d == 0 {
			return Value{}
		}
		return CmplxVal((ar*br+ai*bi)/d, (ai*br-ar*bi)/d)
	case "==":
		return boolVal(ar == br && ai == bi)
	case "!=":
		return boolVal(ar != br || ai != bi)
	case "<":
		return boolVal(ar < br)
	case ">":
		return boolVal(ar > br)
	case "<=":
		return boolVal(ar <= br)
	case ">=":
		return boolVal(ar >= br)
	}
	return Value{}
}

func power(a, b Value) Value {
	if a.T == VUndef || b.T == VUndef {
		return Value{}
	}
	a = numeric(a)
	b = numeric(b)
	if a.T == VInt && b.T == VInt {
		x, y := a.I, b.I
		if y >= 0 {
			r := int64(1)
			ok := true
			for k := int64(0); k < y; k++ {
				nr := r * x
				if x != 0 && nr/x != r {
					ok = false
					break
				}
				r = nr
				if r == 0 || r == 1 && x == 1 {
					break
				}
				if x == -1 {
					if y%2 == 0 {
						r = 1
					} else {
						r = -1
					}
					break
				}
			}
			if ok {
				return IntVal(r)
			}
			return FloatVal(math.Pow(float64(x), float64(y)))
		}
		if x == 0 {
			return Value{}
		}
		return FloatVal(math.Pow(float64(x), float64(y)))
	}
	if a.Imag() == 0 && b.Imag() == 0 {
		ar := a.Real()
		br := b.Real()
		if ar >= 0 || br == math.Trunc(br) {
			if ar == 0 && br < 0 {
				return Value{}
			}
			return FloatVal(math.Pow(ar, br))
		}
	}
	// complex power
	if a.Real() == 0 && a.Imag() == 0 {
		if b.Real() == 0 && b.Imag() == 0 {
			return FloatVal(1)
		}
		return FloatVal(0)
	}
	lr := math.Log(math.Hypot(a.Real(), a.Imag()))
	th := math.Atan2(a.Imag(), a.Real())
	br, bi := b.Real(), b.Imag()
	mr := br*lr - bi*th
	mi := br*th + bi*lr
	m := math.Exp(mr)
	return CmplxVal(m*math.Cos(mi), m*math.Sin(mi))
}
