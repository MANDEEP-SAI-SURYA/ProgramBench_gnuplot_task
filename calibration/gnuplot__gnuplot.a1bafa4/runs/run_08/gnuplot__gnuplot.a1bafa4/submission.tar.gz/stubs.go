package main

import (
	"os/exec"
)

func shellOut(cmd string) (string, error) {
	out, err := exec.Command("/bin/sh", "-c", cmd).Output()
	return string(out), err
}

var multiplotActive bool

func startMultiplot(p *Parser) { skipRest(p); multiplotActive = true }
func endMultiplot()            { multiplotActive = false }
func flushMultiplot()          {}
func doSplot(s []*PlotSpec)    {}
