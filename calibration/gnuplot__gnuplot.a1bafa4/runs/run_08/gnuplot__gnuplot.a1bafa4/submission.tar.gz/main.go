package main

import (
	"sort"
	"bufio"
	"fmt"
	"io"
	"math"
	"os"
	"strings"
)

type Source struct {
	lines  []string
	idx    int
	name   string // file name ("" for -e / stdin)
	lineNo int
	kind   int // 0 file, 1 -e, 2 stdin
}

var srcStack []*Source
var stdout = bufio.NewWriter(os.Stdout)
var stderrW = bufio.NewWriter(os.Stderr)
var hadError bool

// print destination
var printOut io.Writer
var printFile *os.File
var printBlock string
var printBlockActive bool

var datablocks = map[string][]string{}

type breakSignal struct{ cont bool }
type exitSignal struct{ code int }

func flushAll() {
	stdout.Flush()
	stderrW.Flush()
}

func initGlobals() {
	globals = map[string]Value{}
	varSeq = map[string]int{}
	seqCounter = 0
	set := func(k string, v Value) { globals[k] = v; seqCounter++; varSeq[k] = seqCounter }
	set("pi", FloatVal(math.Pi))
	set("I", CmplxVal(0, 1))
	set("NaN", FloatVal(math.NaN()))
	set("GPVAL_TERM", StrVal("unknown"))
	set("GPVAL_TERMOPTIONS", StrVal(""))
	set("GPVAL_OUTPUT", StrVal(""))
	set("GPVAL_ENCODING", StrVal("utf8"))
	set("GPVAL_MINUS_SIGN", StrVal("\u2212"))
	set("GPVAL_MICRO", StrVal("\u00b5"))
	set("GPVAL_DEGREE_SIGN", StrVal("\u00b0"))
	set("GPVAL_VERSION", FloatVal(5.4))
	set("GPVAL_PATCHLEVEL", StrVal("9"))
	set("GPVAL_COMPILE_OPTIONS", StrVal("    +READLINE  -LIBREADLINE  +HISTORY  \n    +OBJECTS  +STATS \n    -LIBGD  \n    -USE_CWDRC  +HIDDEN3D_QUADTREE  \n"))
	set("GPVAL_MULTIPLOT", IntVal(0))
	set("GPVAL_PLOT", IntVal(0))
	set("GPVAL_SPLOT", IntVal(0))
	set("GPVAL_TERMINALS", StrVal(" canvas cgm context domterm dumb dxf emf epslatex fig hpgl mf mp pcl5 pict2e postscript pslatex pstex pstricks svg texdraw tkcanvas unknown "))
	set("GPVAL_pi", FloatVal(math.Pi))
	set("GPVAL_NaN", FloatVal(math.NaN()))
	set("GPVAL_SYSNAME", StrVal("Linux"))
	set("GPVAL_MACHINE", StrVal("x86_64"))
	set("GPVAL_BITS", IntVal(64))
	set("GPVAL_ERRNO", IntVal(0))
	set("GPVAL_ERRMSG", StrVal(""))
	set("GPVAL_SYSTEM_ERRNO", IntVal(0))
	set("GPVAL_SYSTEM_ERRMSG", StrVal(""))
	set("GPVAL_PWD", StrVal(getwd()))
	set("VoxelDistance", FloatVal(0))
}

var varSeq map[string]int
var seqCounter int

func updateVarSeq() {
	var news []string
	for k := range globals {
		if _, ok := varSeq[k]; !ok {
			news = append(news, k)
		}
	}
	sort.Strings(news)
	for _, k := range news {
		seqCounter++
		varSeq[k] = seqCounter
	}
	for k := range varSeq {
		if _, ok := globals[k]; !ok {
			delete(varSeq, k)
		}
	}
}

func orderedVars() []string {
	updateVarSeq()
	var ks []string
	for k := range globals {
		ks = append(ks, k)
	}
	sort.Slice(ks, func(i, j int) bool { return varSeq[ks[i]] < varSeq[ks[j]] })
	return ks
}

var varOrder []string

func getwd() string {
	d, _ := os.Getwd()
	return d
}

func main() {
	defer flushAll()
	initGlobals()
	resetSettings()
	args := os.Args[1:]
	code := 0
	func() {
		defer func() {
			if r := recover(); r != nil {
				if e, ok := r.(*exitSignal); ok {
					code = e.code
					return
				}
				panic(r)
			}
		}()
		code = runArgs(args)
	}()
	closePrint()
	finishOutput()
	flushAll()
	os.Exit(code)
}

func runArgs(args []string) int {
	ranSomething := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			fmt.Fprintln(stdout, "gnuplot 5.4 patchlevel 9")
			return 0
		case a == "-h" || a == "--help":
			fmt.Fprint(stdout, helpText)
			return 0
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings":
			continue
		case a == "-e":
			if i+1 >= len(args) {
				fmt.Fprintln(stderrW, "gnuplot: option requires an argument -- 'e'")
				return 1
			}
			i++
			ranSomething = true
			src := &Source{lines: []string{args[i]}, kind: 1}
			if !runSource(src) {
				return 1
			}
		case a == "-c":
			if i+1 >= len(args) {
				return 1
			}
			fn := args[i+1]
			rest := args[i+2:]
			setCallArgs(fn, rest)
			ranSomething = true
			if !loadFile(fn, -1) {
				return 1
			}
			return 0
		case a == "-":
			ranSomething = true
			if !runStdin() {
				return 1
			}
		case strings.HasPrefix(a, "-") && len(a) > 1:
			fmt.Fprintf(stderrW, "gnuplot: unrecognized option '%s'\n", a)
			fmt.Fprint(stderrW, "Usage: gnuplot [OPTION] ... [FILE]\n")
			return 1
		default:
			ranSomething = true
			setCallArgs(a, nil)
			if !loadFile(a, -1) {
				return 1
			}
		}
	}
	if !ranSomething {
		if !runStdin() {
			return 1
		}
	}
	return 0
}

const helpText = `Usage: gnuplot [OPTION] ... [FILE]
  -V, --version
  -h, --help
  -p  --persist
  -s  --slow
  -d  --default-settings
  -c  scriptfile ARG1 ARG2 ...
  -e  "command1; command2; ..."
gnuplot 5.4 patchlevel 9
`

func setCallArgs(fn string, rest []string) {
	updateVarSeq()
	globals["ARGC"] = IntVal(int64(len(rest)))
	updateVarSeq()
	globals["ARG0"] = StrVal(fn)
	updateVarSeq()
	arr := make([]Value, len(rest)+1)
	globals["ARGV"] = Value{T: VArr, Arr: &arr}
	updateVarSeq()
	for i := 1; i <= 9; i++ {
		updateVarSeq()
		if i <= len(rest) {
			globals["ARG"+itoa(i)] = StrVal(rest[i-1])
		} else {
			globals["ARG"+itoa(i)] = StrVal("")
		}
	}
	for i, r := range rest {
		arr[i+1] = StrVal(r)
	}
	globals["ARGV"] = Value{T: VArr, Arr: &arr}
}

func readLines(data string) []string {
	data = strings.ReplaceAll(data, "\r\n", "\n")
	lines := strings.Split(data, "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	return lines
}

func loadFile(fn string, errPos int) bool {
	data, err := os.ReadFile(fn)
	if err != nil {
		if errPos >= 0 {
			gpErr(errPos, "Cannot load input from '"+fn+"'")
		}
		fmt.Fprintf(stderrW, "line 0: Cannot load input from '%s'\n\n", fn)
		hadError = true
		return false
	}
	src := &Source{lines: readLines(string(data)), name: fn}
	return runSource(src)
}

func runStdin() bool {
	data, _ := io.ReadAll(os.Stdin)
	src := &Source{lines: readLines(string(data)), kind: 2}
	ok := runSource(src)
	if hadError {
		return false
	}
	return ok
}

// nextLine reads a logical line from the source (handling continuation)
func (s *Source) nextLine() (string, bool) {
	if s.idx >= len(s.lines) {
		return "", false
	}
	line := s.lines[s.idx]
	s.idx++
	s.lineNo = s.idx
	for strings.HasSuffix(line, "\\") && s.idx < len(s.lines) {
		line = line[:len(line)-1] + s.lines[s.idx]
		s.idx++
		s.lineNo = s.idx
	}
	return line, true
}

func braceBalance(line string) int {
	bal := 0
	inq := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if inq != 0 {
			if c == '\\' && inq == '"' {
				i++
				continue
			}
			if c == inq {
				inq = 0
			}
			continue
		}
		switch c {
		case '"', '\'':
			inq = c
		case '#':
			// skip to end of physical line
			for i < len(line) && line[i] != '\n' {
				i++
			}
		case '{':
			bal++
		case '}':
			bal--
		}
	}
	return bal
}

var curSrc *Source

// runSource executes all lines; returns false if aborted due to error
func runSource(src *Source) bool {
	srcStack = append(srcStack, src)
	prev := curSrc
	curSrc = src
	defer func() {
		srcStack = srcStack[:len(srcStack)-1]
		curSrc = prev
	}()
	for {
		line, ok := src.nextLine()
		if !ok {
			break
		}
		for braceBalance(line) > 0 {
			more, ok := src.nextLine()
			if !ok {
				break
			}
			line += "\n" + more
		}
		okc := execLineTop(src, line)
		if !okc {
			if src.kind == 2 {
				continue
			}
			return false
		}
	}
	return true
}

// execLineTop runs one line, catching errors
func execLineTop(src *Source, line string) (ok bool) {
	defer func() {
		if r := recover(); r != nil {
			if e, isE := r.(*GPError); isE {
				if e.src == nil {
					e.src = src
					e.line = line
					e.lineNo = src.lineNo
					if e.lineZero {
						e.lineNo = 0
					}
				}
				if len(srcStack) > 1 && src.kind != 2 {
					panic(e)
				}
				reportError(e.src, e.line, e)
				hadError = true
				ok = false
				return
			}
			panic(r)
		}
	}()
	execLine(line)
	return true
}

type nestedAbort struct{}

var nestedLoad int

func reportError(src *Source, line string, e *GPError) {
	stdout.Flush()
	w := stderrW
	loc := ""
	switch src.kind {
	case 0:
		loc = fmt.Sprintf("\"%s\" line %d: ", src.name, e.lineNo)
	default:
		loc = "line 0: "
	}
	if src.kind == 2 {
		if e.Pos >= 0 {
			fmt.Fprintf(w, "\ngnuplot> %s\n%s^\n", line, strings.Repeat(" ", 9+e.Pos))
		}
		fmt.Fprintf(w, "         %s%s\n\n", loc, e.Msg)
	} else {
		if e.Pos >= 0 {
			fmt.Fprintf(w, "\n%s\n%s^\n", line, caretPad(line, e.Pos))
		}
		fmt.Fprintf(w, "%s%s\n\n", loc, e.Msg)
	}
	w.Flush()
}

func caretPad(line string, pos int) string {
	var sb strings.Builder
	for i := 0; i < pos && i < len(line); i++ {
		if line[i] == '\t' {
			sb.WriteByte('\t')
		} else {
			sb.WriteByte(' ')
		}
	}
	for i := len(line); i < pos; i++ {
		sb.WriteByte(' ')
	}
	return sb.String()
}

// macro expansion: @name replaced by string variable value
func expandMacros(line string) string {
	if !strings.Contains(line, "@") {
		return line
	}
	var sb strings.Builder
	inq := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if inq != 0 {
			sb.WriteByte(c)
			if c == '\\' && inq == '"' && i+1 < len(line) {
				i++
				sb.WriteByte(line[i])
				continue
			}
			if c == inq {
				inq = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			inq = c
			sb.WriteByte(c)
			continue
		}
		if c == '@' && i+1 < len(line) && isAlpha(line[i+1]) {
			j := i + 1
			for j < len(line) && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			name := line[i+1 : j]
			v, ok := globals[name]
			if ok && v.T == VStr {
				sb.WriteString(v.S)
				i = j - 1
				continue
			}
			warnMsg(name + " is not a string variable")
			i = j - 1
			continue
		}
		sb.WriteByte(c)
	}
	return sb.String()
}

func warnMsg(msg string) {
	src := curSrc
	if src != nil && src.kind == 0 {
		fmt.Fprintf(stderrW, "\"%s\" line %d: warning: %s\n", src.name, src.lineNo, msg)
	} else if src != nil && src.kind == 2 {
		fmt.Fprintf(stderrW, "         line 0: warning: %s\n", msg)
	} else {
		fmt.Fprintf(stderrW, "line 0: warning: %s\n", msg)
	}
}

func execLine(line string) {
	line = expandMacros(line)
	toks := lexLine(line)
	p := &Parser{toks: toks, line: line}
	execCommands(p)
}

func execCommands(p *Parser) {
	for {
		for p.isOp(";") {
			p.next()
		}
		if p.cur().Kind == TEnd {
			return
		}
		execCommand(p)
		updateVarSeq()
		if !p.endOfCmd() {
			if p.isOp("}") {
				return
			}
			p.err("unexpected or unrecognized token: " + p.cur().Text)
		}
	}
}
