package main

import (
	"fmt"
	"math"
	"strings"
)

func cmdFit(p *Parser) {
	xa := axes["x"]
	savedX := *xa
	defer func() { *xa = savedX }()
	var dummyName = S.dummy1
	if p.isOp("[") {
		if p.peek(1).Kind == TIdent && p.peek(2).Kind == TOp && p.peek(2).Text == "=" {
			dummyName = p.peek(1).Text
			p.next()
			p.next()
			p.toks[p.i] = Token{Kind: TOp, Text: "[", Pos: p.toks[p.i].Pos}
		}
		parseRange(p, xa)
		for p.isOp("[") {
			tmp := &Axis{autoMin: true, autoMax: true}
			parseRange(p, tmp)
		}
	}
	fexpr := p.parseExpr()
	sp := &PlotSpec{indexStep: 1, style: "points"}
	sp.every = [6]int{1, 1, 0, 0, -1, -1}
	t := p.cur()
	if t.Kind == TIdent && t.Text[0] == '$' {
		sp.fname = t.Text
		sp.isBlock = true
		p.next()
	} else {
		v := p.parseExpr()()
		sp.fname = v.S
	}
	parseDataMods(p, sp)
	for !p.endOfCmd() && !p.almost("via") {
		p.next()
	}
	if !p.almost("via") {
		p.err("Need via and either parameter list or file")
	}
	p.next()
	var params []string
	for {
		params = append(params, p.next().Text)
		if p.isOp(",") {
			p.next()
			continue
		}
		break
	}
	// read data
	lines := readDataLines(sp.fname, sp.isBlock)
	rows := parseRows(lines)
	var xs, ys, sig []float64
	nc := 2
	if sp.hasUsing {
		nc = len(sp.using)
	}
	curRowNum = 0
	for ri := range rows {
		r := &rows[ri]
		var vals []float64
		var st int
		if !sp.hasUsing {
			sp2 := *sp
			sp2.using = []UsingCol{{col: 1}, {col: 2}}
			sp2.hasUsing = true
			vals, _, st, _ = evalUsing(&sp2, r, 2)
		} else {
			vals, _, st, _ = evalUsing(sp, r, nc)
		}
		curRowNum++
		if st != 0 || len(vals) < 2 {
			continue
		}
		if (!xa.autoMin && vals[0] < xa.min) || (!xa.autoMax && vals[0] > xa.max) {
			continue
		}
		xs = append(xs, vals[0])
		ys = append(ys, vals[1])
		if len(vals) >= 3 {
			sig = append(sig, vals[2])
		} else {
			sig = append(sig, 1)
		}
	}
	curRow = nil
	N := len(xs)
	M := len(params)
	if N == 0 {
		gpErr(-1, "No data to fit")
	}
	a := make([]float64, M)
	for i, pn := range params {
		v, ok := globals[pn]
		if !ok {
			a[i] = 1
			globals[pn] = FloatVal(1)
		} else {
			a[i] = numeric(v).Real()
		}
	}
	scale := make([]float64, M)
	for i := range a {
		if S.fitPrescale && a[i] != 0 {
			scale[i] = math.Abs(a[i])
		} else {
			scale[i] = 1
		}
	}
	setParams := func(v []float64) {
		for i, pn := range params {
			globals[pn] = FloatVal(v[i])
		}
	}
	evalF := func(v []float64) ([]float64, bool) {
		setParams(v)
		out := make([]float64, N)
		for i := range xs {
			y, ok := evalFuncAt(fexpr, dummyName, xs[i])
			if !ok {
				return nil, false
			}
			out[i] = y
		}
		return out, true
	}
	chi := func(f []float64) float64 {
		s := 0.0
		for i := range f {
			d := (ys[i] - f[i]) / sig[i]
			s += d * d
		}
		return s
	}
	jac := func(v []float64, f0 []float64) [][]float64 {
		J := make([][]float64, N)
		for i := range J {
			J[i] = make([]float64, M)
		}
		for j := 0; j < M; j++ {
			h := math.Abs(v[j])
			if h < 1e-30 {
				h = 1e-30
			}
			h *= 0.001
			vp := append([]float64{}, v...)
			vp[j] += h
			fp, _ := evalF(vp)
			for i := 0; i < N; i++ {
				J[i][j] = (fp[i] - f0[i]) / h / sig[i] * scale[j]
			}
		}
		setParams(v)
		return J
	}
	f0, ok := evalF(a)
	if !ok {
		gpErr(-1, "Undefined value during function evaluation")
	}
	chisq := chi(f0)
	J := jac(a, f0)
	lambda := S.fitStartLambda
	if lambda <= 0 {
		s := 0.0
		for i := range J {
			for j := range J[i] {
				s += J[i][j] * J[i][j]
			}
		}
		lambda = math.Sqrt(s / float64(N) / float64(M))
	}
	factor := S.fitLambdaFactor
	if factor <= 0 {
		factor = 10
	}
	w := func(f string, args ...interface{}) { fmt.Fprintf(stderrW, f, args...) }
	quiet := S.fitQuiet
	header := "iter      chisq       delta/lim  lambda  "
	for _, pn := range params {
		header += fmt.Sprintf(" %-13s", pn)
	}
	printIter := func(it int, c, d, l float64, v []float64) {
		if quiet {
			return
		}
		s := fmt.Sprintf("%4d %s%s%s ", it, cfmt("%.10e", c), cfmt("%11.2e", d), cfmt("%10.2e", l))
		for _, x := range v {
			s += cfmt("%15.6e", x)
		}
		w("%s\n", s)
	}
	if !quiet {
		w("%s\n", header)
	}
	printIter(0, chisq, 0, lambda, a)
	iter := 0
	lastDelta := 0.0
	converged := false
	maxIter := S.fitMaxIter
	for {
		// solve (J^T J + lambda^2 I) d = J^T r
		A := make([][]float64, M)
		g := make([]float64, M)
		for j := 0; j < M; j++ {
			A[j] = make([]float64, M)
			for k := 0; k < M; k++ {
				s := 0.0
				for i := 0; i < N; i++ {
					s += J[i][j] * J[i][k]
				}
				A[j][k] = s
			}
			A[j][j] += lambda * lambda
			s := 0.0
			for i := 0; i < N; i++ {
				s += J[i][j] * (ys[i] - f0[i]) / sig[i]
			}
			g[j] = s
		}
		d, okS := solveLin(A, g)
		if !okS {
			break
		}
		na := make([]float64, M)
		for j := range a {
			na[j] = a[j] + d[j]*scale[j]
		}
		nf, okF := evalF(na)
		nchi := math.Inf(1)
		if okF {
			nchi = chi(nf)
		}
		if nchi < chisq || (nchi == chisq && nchi == 0) {
			iter++
			delta := (nchi - chisq) / nchi
			if nchi == 0 {
				delta = 0
			}
			lambda /= factor
			a = na
			f0 = nf
			chisq = nchi
			lastDelta = delta
			printIter(iter, chisq, delta/S.fitLimit, lambda, a)
			if -delta < S.fitLimit || chisq == 0 {
				converged = true
				break
			}
			if maxIter > 0 && iter >= maxIter {
				break
			}
			J = jac(a, f0)
		} else {
			lambda *= factor
			if lambda > 1e20 {
				break
			}
		}
	}
	setParams(a)
	if !quiet {
		w("%s\n", header)
	}
	ndf := N - M
	// covariance at solution (unscaled)
	Ju := make([][]float64, N)
	for i := range Ju {
		Ju[i] = make([]float64, M)
		for j := 0; j < M; j++ {
			Ju[i][j] = J[i][j] / scale[j]
		}
	}
	if converged {
		J = jac(a, f0)
		for i := range Ju {
			for j := 0; j < M; j++ {
				Ju[i][j] = J[i][j] / scale[j]
			}
		}
	}
	A := make([][]float64, M)
	for j := 0; j < M; j++ {
		A[j] = make([]float64, M)
		for k := 0; k < M; k++ {
			s := 0.0
			for i := 0; i < N; i++ {
				s += Ju[i][j] * Ju[i][k]
			}
			A[j][k] = s
		}
	}
	cov := invertMat(A)
	stdfit := 0.0
	if ndf > 0 {
		stdfit = math.Sqrt(chisq / float64(ndf))
	}
	errs := make([]float64, M)
	for j := 0; j < M; j++ {
		e := math.Sqrt(math.Abs(cov[j][j]))
		if S.fitErrScaling {
			e *= stdfit
		}
		errs[j] = e
	}
	globals["FIT_NDF"] = IntVal(int64(ndf))
	globals["FIT_WSSR"] = FloatVal(chisq)
	globals["FIT_STDFIT"] = FloatVal(stdfit)
	globals["FIT_CONVERGED"] = boolVal(converged)
	globals["FIT_NITER"] = IntVal(int64(iter))
	if ndf > 0 {
		globals["FIT_P"] = FloatVal(1 - igamma(float64(ndf)/2, chisq/2))
	}
	if S.fitErrVars {
		for j, pn := range params {
			globals[pn+"_err"] = FloatVal(errs[j])
		}
	}
	updateVarSeq()
	if quiet {
		return
	}
	if converged {
		w("\nAfter %d iterations the fit converged.\n", iter)
	} else {
		w("\nAfter %d iterations the fit did not converge.\n", iter)
	}
	w("final sum of squares of residuals : %s\n", gnum(chisq))
	w("rel. change during last iteration : %s\n\n", gnum(lastDelta))
	w("degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	w("rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", gnum(stdfit))
	w("variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n", gnum(stdfit*stdfit))
	if ndf > 0 && false {
	}
	w("\nFinal set of parameters            Asymptotic Standard Error\n")
	w("=======================            ==========================\n")
	for j, pn := range params {
		pct := ""
		if a[j] != 0 {
			pct = fmt.Sprintf("(%s%%)", cfmt("%.4g", math.Abs(errs[j]/a[j]*100)))
		}
		w("%-15s = %-16s +/- %-12s %s\n", pn, gnum(a[j]), cfmt("%.4g", errs[j]), pct)
	}
	w("\ncorrelation matrix of the fit parameters:\n")
	s := strings.Repeat(" ", 16)
	for _, pn := range params {
		s += fmt.Sprintf("%-7s", pn)
	}
	w("%s\n", s)
	for j, pn := range params {
		line := fmt.Sprintf("%-15s", pn)
		for k := 0; k <= j; k++ {
			c := cov[j][k] / math.Sqrt(cov[j][j]*cov[k][k])
			line += cfmt("%6.3f", c) + " "
		}
		w("%s\n", line)
	}
}

func solveLin(A [][]float64, b []float64) ([]float64, bool) {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		if M[piv][c] == 0 {
			return nil, false
		}
		M[c], M[piv] = M[piv], M[c]
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := range x {
		x[i] = M[i][n] / M[i][i]
	}
	return x, true
}

func invertMat(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for j := 0; j < n; j++ {
		e := make([]float64, n)
		e[j] = 1
		col, ok := solveLin(A, e)
		if !ok {
			col = make([]float64, n)
		}
		for i := 0; i < n; i++ {
			if inv[i] == nil {
				inv[i] = make([]float64, n)
			}
			inv[i][j] = col[i]
		}
	}
	return inv
}
