package main

import (
	"strconv"
	"strings"
)

const (
	TNum = iota
	TStr
	TIdent
	TOp
	TEnd
)

type Token struct {
	Kind  int
	Text  string
	Pos   int
	Val   Value
	Quote byte
}

func isAlpha(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_' || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }

// lexLine tokenizes a single command line. Comments start with # outside strings.
func lexLine(s string) []Token {
	var toks []Token
	i := 0
	n := len(s)
	for i < n {
		c := s[i]
		if c == ' ' || c == '\t' || c == '\r' || c == '\n' {
			i++
			continue
		}
		if c == '#' {
			for i < n && s[i] != '\n' {
				i++
			}
			continue
		}
		start := i
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(s[i+1])) {
			// number
			if c == '0' && i+1 < n && (s[i+1] == 'x' || s[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", s[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(s[i+2:j], 16, 64)
				toks = append(toks, Token{Kind: TNum, Text: s[i:j], Pos: start, Val: IntVal(int64(v))})
				i = j
				continue
			}
			j := i
			isFloat := false
			for j < n && isDigit(s[j]) {
				j++
			}
			if j < n && s[j] == '.' && !(j+1 < n && s[j+1] == '.') {
				isFloat = true
				j++
				for j < n && isDigit(s[j]) {
					j++
				}
			}
			if j < n && strings.IndexByte("eEdDqQ", s[j]) >= 0 {
				k := j + 1
				if k < n && (s[k] == '+' || s[k] == '-') {
					k++
				}
				if k < n && isDigit(s[k]) {
					for k < n && isDigit(s[k]) {
						k++
					}
					isFloat = true
					j = k
				}
			}
			txt := s[i:j]
			var v Value
			if isFloat {
				t := strings.Map(func(r rune) rune {
					if r == 'd' || r == 'D' || r == 'q' || r == 'Q' {
						return 'e'
					}
					return r
				}, txt)
				f, _ := strconv.ParseFloat(t, 64)
				v = FloatVal(f)
			} else {
				if len(txt) > 1 && txt[0] == '0' {
					iv, err := strconv.ParseInt(txt, 8, 64)
					if err != nil {
						f, _ := strconv.ParseFloat(txt, 64)
						v = FloatVal(f)
					} else {
						v = IntVal(iv)
					}
				} else {
					iv, err := strconv.ParseInt(txt, 10, 64)
					if err != nil {
						f, _ := strconv.ParseFloat(txt, 64)
						v = FloatVal(f)
					} else {
						v = IntVal(iv)
					}
				}
			}
			toks = append(toks, Token{Kind: TNum, Text: txt, Pos: start, Val: v})
			i = j
			continue
		}
		if isAlpha(c) || (c == '$' && i+1 < n && (isAlpha(s[i+1]) || isDigit(s[i+1]))) {
			j := i + 1
			for j < n && (isAlpha(s[j]) || isDigit(s[j])) {
				j++
			}
			toks = append(toks, Token{Kind: TIdent, Text: s[i:j], Pos: start})
			i = j
			continue
		}
		if c == '"' {
			var sb strings.Builder
			j := i + 1
			for j < n && s[j] != '"' {
				if s[j] == '\\' && j+1 < n {
					j++
					switch s[j] {
					case 'n':
						sb.WriteByte('\n')
					case 't':
						sb.WriteByte('\t')
					case 'r':
						sb.WriteByte('\r')
					case 'a':
						sb.WriteByte('\a')
					case 'b':
						sb.WriteByte('\b')
					case 'f':
						sb.WriteByte('\f')
					case 'v':
						sb.WriteByte('\v')
					case '"':
						sb.WriteByte('"')
					case '\\':
						sb.WriteByte('\\')
					case '0', '1', '2', '3', '4', '5', '6', '7':
						k := j
						val := 0
						for k < n && k < j+3 && s[k] >= '0' && s[k] <= '7' {
							val = val*8 + int(s[k]-'0')
							k++
						}
						sb.WriteByte(byte(val))
						j = k - 1
					default:
						sb.WriteByte('\\')
						sb.WriteByte(s[j])
					}
					j++
					continue
				}
				sb.WriteByte(s[j])
				j++
			}
			if j < n {
				j++
			}
			toks = append(toks, Token{Kind: TStr, Text: s[i:j], Pos: start, Val: StrVal(sb.String()), Quote: '"'})
			i = j
			continue
		}
		if c == '\'' {
			var sb strings.Builder
			j := i + 1
			for j < n {
				if s[j] == '\'' {
					if j+1 < n && s[j+1] == '\'' {
						sb.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				sb.WriteByte(s[j])
				j++
			}
			if j < n {
				j++
			}
			toks = append(toks, Token{Kind: TStr, Text: s[i:j], Pos: start, Val: StrVal(sb.String()), Quote: '\''})
			i = j
			continue
		}
		ops3 := []string{"..."}
		ops2 := []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "=~", ".."}
		matched := false
		for _, o := range ops3 {
			if strings.HasPrefix(s[i:], o) {
				toks = append(toks, Token{Kind: TOp, Text: o, Pos: start})
				i += len(o)
				matched = true
				break
			}
		}
		if !matched {
			for _, o := range ops2 {
				if strings.HasPrefix(s[i:], o) {
					toks = append(toks, Token{Kind: TOp, Text: o, Pos: start})
					i += len(o)
					matched = true
					break
				}
			}
		}
		if !matched {
			toks = append(toks, Token{Kind: TOp, Text: s[i : i+1], Pos: start})
			i++
		}
	}
	toks = append(toks, Token{Kind: TEnd, Text: "", Pos: len(s)})
	return toks
}
