package main

import (
	"fmt"
	"os"
	"sort"
	"strings"
)

func matchBrace(p *Parser) int {
	// p.cur() is '{'; returns index of matching '}'
	depth := 0
	for k := p.i; k < len(p.toks); k++ {
		t := p.toks[k]
		if t.Kind == TOp && t.Text == "{" {
			depth++
		} else if t.Kind == TOp && t.Text == "}" {
			depth--
			if depth == 0 {
				return k
			}
		}
	}
	return -1
}

func subParser(p *Parser, from, to int) *Parser {
	toks := make([]Token, 0, to-from+1)
	toks = append(toks, p.toks[from:to]...)
	endPos := len(p.line)
	if to < len(p.toks) {
		endPos = p.toks[to].Pos
	}
	toks = append(toks, Token{Kind: TEnd, Pos: endPos})
	return &Parser{toks: toks, line: p.line}
}

// parse a { block } at current position; returns the sub-parser body
func parseBlock(p *Parser) (int, int) {
	if !p.isOp("{") {
		p.err("expecting '{'")
	}
	end := matchBrace(p)
	if end < 0 {
		panic(&GPError{Msg: "Syntax error: missing block terminator }", Pos: -1, lineZero: true})
	}
	start := p.i + 1
	p.i = end + 1
	return start, end
}

func runBlock(p *Parser, from, to int) {
	sp := subParser(p, from, to)
	execCommands(sp)
}

var lastIfResult bool

func execCommand(p *Parser) {
	t := p.cur()
	if t.Kind == TOp && t.Text == "{" {
		s, e := parseBlock(p)
		runBlock(p, s, e)
		return
	}
	if t.Kind == TOp && t.Text == "!" {
		// shell command: rest of line
		cmd := p.line[t.Pos+1:]
		p.i = len(p.toks) - 1
		out, _ := runShell(cmd)
		stdout.WriteString(out)
		return
	}
	if t.Kind != TIdent {
		p.err("invalid command")
	}
	name := t.Text
	// datablock definition
	if name[0] == '$' {
		if p.peek(1).Kind == TOp && p.peek(1).Text == "<<" {
			p.next()
			p.next()
			term := p.cur().Text
			p.next()
			var lines []string
			for {
				l, ok := curSrc.nextLine()
				if !ok {
					break
				}
				if strings.TrimRight(l, " \t\r") == term {
					break
				}
				lines = append(lines, l)
			}
			datablocks[name] = lines
			return
		}
		if p.peek(1).Kind == TOp && p.peek(1).Text == "=" {
			p.next()
			p.next()
			// $a = $b copies
			src := p.cur().Text
			p.next()
			if db, ok := datablocks[src]; ok {
				cp := append([]string{}, db...)
				datablocks[name] = cp
			}
			return
		}
		p.err("invalid command")
	}
	// function definition f(a,b) = expr
	if p.peek(1).Kind == TOp && p.peek(1).Text == "(" {
		// scan for ") ="
		k := p.i + 2
		var params []string
		okdef := true
		for {
			tk := p.toks[k]
			if tk.Kind != TIdent {
				okdef = false
				break
			}
			params = append(params, tk.Text)
			k++
			if p.toks[k].Kind == TOp && p.toks[k].Text == "," {
				k++
				continue
			}
			break
		}
		if okdef && p.toks[k].Kind == TOp && p.toks[k].Text == ")" && p.toks[k+1].Kind == TOp && p.toks[k+1].Text == "=" {
			p.i = k + 2
			if p.endOfCmd() {
				p.err("function definition expected")
			}
			bstart := p.cur().Pos
			body := p.parseExpr()
			bend := p.cur().Pos
			text := strings.TrimSpace(p.line[t.Pos:bend])
			_ = bstart
			udfs[name] = &UDF{Name: name, Params: params, Body: body, Text: text}
			if !contains(udfOrder, name) {
				udfOrder = append(udfOrder, name)
			}
			return
		}
	}
	// variable assignment
	if p.peek(1).Kind == TOp && p.peek(1).Text == "=" {
		p.next()
		p.next()
		start := p.cur().Pos
		e := p.parseConstExpr()
		v := e()
		if v.T == VUndef {
			gpErr(start, "undefined value")
		}
		setVar(name, v)
		return
	}
	// array element assignment A[i] = expr
	if p.peek(1).Kind == TOp && p.peek(1).Text == "[" {
		if arr, ok := globals[name]; ok && arr.T == VArr {
			save := p.i
			p.next()
			p.next()
			idx := p.parseExpr()
			if p.isOp("]") && p.peek(1).Kind == TOp && p.peek(1).Text == "=" {
				p.next()
				p.next()
				e := p.parseConstExpr()
				i := intOf(idx())
				v := e()
				a := *arr.Arr
				if i < 1 || i >= int64(len(a)) {
					gpErr(-1, "array index out of range")
				}
				a[i] = v
				return
			}
			p.i = save
		}
	}
	p.next()
	switch {
	case name == "print":
		cmdPrint(p, false)
	case name == "printerr":
		cmdPrint(p, true)
	case name == "if":
		cmdIf(p)
	case name == "else":
		// stray else: skip block
		if p.isOp("{") {
			parseBlock(p)
		}
	case name == "do":
		cmdDo(p)
	case name == "while":
		cmdWhile(p)
	case name == "break":
		panic(&breakSignal{cont: false})
	case name == "continue":
		panic(&breakSignal{cont: true})
	case almostEq(name, "ex$it") || almostEq(name, "q$uit"):
		code := 0
		if p.almost("st$atus") {
			p.next()
			e := p.parseConstExpr()
			code = int(intOf(e()))
		} else if !p.endOfCmd() && p.almost("error") {
			p.next()
			e := p.parseConstExpr()
			msg := e()
			gpErr(-1, msg.S)
		}
		panic(&exitSignal{code: code})
	case almostEq(name, "l$oad"):
		e := p.parseConstExpr()
		v := e()
		if v.T != VStr {
			p.err("expecting filename")
		}
		nestedLoadFile(v.S, t.Pos, nil)
	case almostEq(name, "cal$l"):
		pos := p.cur().Pos
		e := p.parseConstExpr()
		v := e()
		var args []string
		for !p.endOfCmd() {
			a := p.parsePrimaryArg()
			args = append(args, a)
		}
		nestedLoadFile(v.S, pos, args)
	case almostEq(name, "ev$aluate"):
		e := p.parseConstExpr()
		v := e()
		if v.T != VStr {
			gpErr(-1, "expected string")
		}
		execLine(v.S)
	case almostEq(name, "und$efine"):
		for !p.endOfCmd() {
			n := p.next().Text
			if strings.HasSuffix(n, "*") {
				n = n[:len(n)-1]
			}
			if p.isOp("*") {
				p.next()
				for k := range globals {
					if strings.HasPrefix(k, n) {
						delete(globals, k)
					}
				}
				continue
			}
			delete(globals, n)
			delete(datablocks, n)
		}
	case name == "array":
		cmdArray(p)
	case almostEq(name, "se$t"):
		cmdSet(p)
	case almostEq(name, "uns$et"):
		cmdUnset(p)
	case almostEq(name, "sh$ow"):
		cmdShow(p)
	case almostEq(name, "res$et"):
		if p.almost("b$ind") || p.almost("e$rrors") || p.almost("s$ession") {
			p.next()
		}
		resetSettings()
	case almostEq(name, "p$lot"):
		cmdPlot(p, false)
	case almostEq(name, "sp$lot"):
		cmdPlot(p, true)
	case almostEq(name, "rep$lot"):
		cmdReplot(p)
	case almostEq(name, "pa$use"):
		e := p.parseConstExpr()
		v := e()
		if !p.endOfCmd() {
			m := p.parseExpr()()
			if m.T == VStr {
				fmt.Fprintln(stderrW, m.S)
			}
		}
		_ = v
	case almostEq(name, "cl$ear"):
		termClear()
	case almostEq(name, "f$it"):
		cmdFit(p)
	case almostEq(name, "stats"):
		cmdStats(p)
	case almostEq(name, "cd"):
		e := p.parseConstExpr()
		v := e()
		if err := os.Chdir(v.S); err != nil {
			gpErr(-1, "Can't change to this directory")
		}
	case almostEq(name, "pwd"):
		fmt.Fprintln(stderrW, getwd())
	case almostEq(name, "sy$stem"):
		e := p.parseConstExpr()
		v := e()
		out, _ := runShell(v.S)
		stdout.WriteString(out)
	case almostEq(name, "up$date"):
		e := p.parseConstExpr()
		e()
		if !p.endOfCmd() {
			p.parseExpr()()
		}
	case almostEq(name, "ref$resh"), almostEq(name, "test"), almostEq(name, "lo$wer"), almostEq(name, "ra$ise"), almostEq(name, "hi$story"):
		for !p.endOfCmd() {
			p.next()
		}
	case almostEq(name, "vclear"):
	default:
		gpErr(t.Pos, "invalid command")
	}
}

var udfOrder []string

func contains(l []string, s string) bool {
	for _, x := range l {
		if x == s {
			return true
		}
	}
	return false
}

func setVar(name string, v Value) {
	if name == "GPVAL_" {
	}
	globals[name] = v
}

func (p *Parser) parsePrimaryArg() string {
	t := p.cur()
	if t.Kind == TStr {
		p.next()
		return t.Val.S
	}
	if t.Kind == TNum {
		p.next()
		return t.Text
	}
	// expression in parentheses or variable
	e := p.parsePrimary()
	v := e()
	if v.T == VStr {
		return v.S
	}
	return v.PrintStr()
}

func nestedLoadFile(fn string, pos int, args []string) {
	data, err := os.ReadFile(fn)
	if err != nil {
		gpErr(-1, "Cannot load input from '"+fn+"'")
	}
	var saved map[string]Value
	if args != nil {
		saved = map[string]Value{}
		for _, k := range []string{"ARG0", "ARGC", "ARGV", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"} {
			if v, ok := globals[k]; ok {
				saved[k] = v
			}
		}
		setCallArgs(fn, args)
	}
	src := &Source{lines: readLines(string(data)), name: fn}
	runSource(src)
	if saved != nil {
		for k, v := range saved {
			globals[k] = v
		}
	}
}

func printDest(toErr bool) func(string) {
	if toErr || (!printBlockActive && printFile == nil && !printToStdout) {
		return func(s string) { stderrW.WriteString(s) }
	}
	if printBlockActive {
		return func(s string) { printBlockBuf.WriteString(s) }
	}
	if printToStdout {
		return func(s string) { stdout.WriteString(s) }
	}
	return func(s string) { printFile.WriteString(s) }
}

var printToStdout bool
var printBlockBuf strings.Builder

func cmdPrint(p *Parser, toErr bool) {
	out := printDest(toErr)
	if p.endOfCmd() {
		p.err("constant expression required")
	}
	first := true
	for {
		pos := p.cur().Pos
		e := p.parseConstExpr()
		v := e()
		if v.T == VUndef && v.I == 0 {
			gpErr(pos, "undefined value")
		}
		_ = first
		first = false
		if v.T == VArr {
			out(v.PrintStr() + "\n")
		} else {
			out(v.PrintStr())
		}
		if p.isOp(",") {
			p.next()
			out(" ")
			continue
		}
		break
	}
	out("\n")
	if printBlockActive {
		flushPrintBlock()
	}
}

func flushPrintBlock() {
	s := printBlockBuf.String()
	if strings.HasSuffix(s, "\n") {
		lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
		datablocks[printBlock] = append(datablocks[printBlock], lines...)
		printBlockBuf.Reset()
	}
}

func closePrint() {
	if printFile != nil {
		printFile.Close()
		printFile = nil
	}
}

func cmdIf(p *Parser) {
	if !p.isOp("(") {
		p.err("expecting '('")
	}
	p.next()
	c := p.parseExpr()
	if !p.isOp(")") {
		p.err("expecting ')'")
	}
	p.next()
	cond := truthy(c())
	if !p.isOp("{") {
		// old-style if: rest of line
		if cond {
			execCommands(p)
		} else {
			p.i = len(p.toks) - 1
		}
		return
	}
	s, e := parseBlock(p)
	done := false
	if cond {
		runBlock(p, s, e)
		done = true
	}
	for p.is("else") {
		p.next()
		if p.is("if") {
			p.err("expected {else-clause}")
			if !p.isOp("(") {
				p.err("expecting '('")
			}
			p.next()
			c2 := p.parseExpr()
			if !p.isOp(")") {
				p.err("expecting ')'")
			}
			p.next()
			s2, e2 := parseBlock(p)
			if !done && truthy(c2()) {
				runBlock(p, s2, e2)
				done = true
			}
			continue
		}
		s2, e2 := parseBlock(p)
		if !done {
			runBlock(p, s2, e2)
			done = true
		}
		break
	}
}

type iterSpec struct {
	varName string
	isStr   bool
	words   []string
	start   int64
	end     int64
	step    int64
	openEnd bool
}

// parse [i=a:b:c] or [s in "..."]
func parseIter(p *Parser) *iterSpec {
	if !p.isOp("[") {
		p.err("expecting '['")
	}
	p.next()
	it := &iterSpec{}
	if p.cur().Kind != TIdent {
		p.err("Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	it.varName = p.next().Text
	if p.is("in") {
		p.next()
		v := p.parseExpr()()
		if v.T == VArr {
			it.isStr = true
			for _, e := range (*v.Arr)[1:] {
				it.words = append(it.words, e.PrintStr())
			}
		} else {
			it.isStr = true
			it.words = splitWords(v.S)
		}
	} else {
		if !p.isOp("=") {
			p.err("Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
		}
		p.next()
		it.start = intOf(p.parseExpr()())
		if !p.isOp(":") {
			p.err("Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
		}
		p.next()
		if p.isOp("*") {
			p.next()
			it.openEnd = true
			it.end = 1 << 62
		} else {
			it.end = intOf(p.parseExpr()())
		}
		it.step = 1
		if p.isOp(":") {
			p.next()
			it.step = intOf(p.parseExpr()())
		}
	}
	if !p.isOp("]") {
		p.err("Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	p.next()
	return it
}

func (it *iterSpec) values() []Value {
	var out []Value
	if it.isStr {
		for _, w := range it.words {
			out = append(out, StrVal(w))
		}
		return out
	}
	if it.step > 0 {
		for i := it.start; i <= it.end && len(out) < 10000000; i += it.step {
			out = append(out, IntVal(i))
		}
	} else if it.step < 0 {
		for i := it.start; i >= it.end; i += it.step {
			out = append(out, IntVal(i))
		}
	}
	return out
}

func cmdDo(p *Parser) {
	if !p.is("for") {
		p.err("expecting 'for'")
	}
	p.next()
	var iters []*iterSpec
	iters = append(iters, parseIter(p))
	for p.is("for") {
		p.next()
		iters = append(iters, parseIter(p))
	}
	s, e := parseBlock(p)
	var savedVals []Value
	var savedOk []bool
	for _, it := range iters {
		v, ok := globals[it.varName]
		savedVals = append(savedVals, v)
		savedOk = append(savedOk, ok)
	}
	defer func() {
		for k, it := range iters {
			if savedOk[k] {
				globals[it.varName] = savedVals[k]
			} else {
				delete(globals, it.varName)
			}
		}
	}()
	runIters(p, iters, 0, s, e)
}

func runIters(p *Parser, iters []*iterSpec, k int, s, e int) bool {
	it := iters[k]
	for _, v := range it.values() {
		globals[it.varName] = v
		if k+1 < len(iters) {
			if !runIters(p, iters, k+1, s, e) {
				return false
			}
			continue
		}
		stop := false
		func() {
			defer func() {
				if r := recover(); r != nil {
					if b, ok := r.(*breakSignal); ok {
						if !b.cont {
							stop = true
						}
						return
					}
					panic(r)
				}
			}()
			runBlock(p, s, e)
		}()
		if stop {
			return false
		}
	}
	return true
}

func cmdWhile(p *Parser) {
	if !p.isOp("(") {
		p.err("expecting '('")
	}
	p.next()
	cs := p.i
	c := p.parseExpr()
	_ = cs
	if !p.isOp(")") {
		p.err("expecting ')'")
	}
	p.next()
	s, e := parseBlock(p)
	for truthy(c()) {
		stop := false
		func() {
			defer func() {
				if r := recover(); r != nil {
					if b, ok := r.(*breakSignal); ok {
						if !b.cont {
							stop = true
						}
						return
					}
					panic(r)
				}
			}()
			runBlock(p, s, e)
		}()
		if stop {
			break
		}
	}
}

func cmdArray(p *Parser) {
	t := p.cur()
	if t.Kind != TIdent {
		p.err("illegal array name")
	}
	name := t.Text
	p.next()
	var n int64 = -1
	if p.isOp("[") {
		p.next()
		n = intOf(p.parseExpr()())
		if !p.isOp("]") {
			p.err("expecting ']'")
		}
		p.next()
	}
	var init []Value
	if p.isOp("=") {
		p.next()
		if !p.isOp("[") {
			v := p.parseExpr()()
			if v.T == VArr {
				init = (*v.Arr)[1:]
			}
		} else {
			p.next()
			if !p.isOp("]") {
				for {
					init = append(init, p.parseExpr()())
					if p.isOp(",") {
						p.next()
						continue
					}
					break
				}
			}
			if !p.isOp("]") {
				p.err("expecting ']'")
			}
			p.next()
		}
		if n < 0 {
			n = int64(len(init))
		}
	}
	if n < 0 {
		p.err("expecting [size]")
	}
	arr := make([]Value, n+1)
	for k := range arr {
		arr[k].I = 1
	}
	for i := 0; i < len(init) && int64(i) < n; i++ {
		arr[i+1] = init[i]
	}
	globals[name] = Value{T: VArr, Arr: &arr}
}

func runShell(cmd string) (string, error) {
	return shellOut(cmd)
}

func sortedKeys(m map[string]Value) []string {
	var k []string
	for x := range m {
		k = append(k, x)
	}
	sort.Strings(k)
	return k
}
