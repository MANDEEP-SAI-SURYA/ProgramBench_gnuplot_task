package main

import (
	"fmt"
	"math"
	"strings"
	"time"
)

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, t float64) string {
	sec := math.Floor(t)
	frac := t - sec
	tm := time.Unix(int64(sec), 0).UTC()
	var sb strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			sb.WriteByte(c)
			continue
		}
		i++
		// optional width/precision for %S etc
		prec := -1
		if f[i] == '.' && i+1 < len(f) && isDigit(f[i+1]) {
			prec = int(f[i+1] - '0')
			i += 2
		}
		switch f[i] {
		case 'Y':
			sb.WriteString(fmt.Sprintf("%04d", tm.Year()))
		case 'y':
			sb.WriteString(fmt.Sprintf("%02d", tm.Year()%100))
		case 'm':
			sb.WriteString(fmt.Sprintf("%02d", int(tm.Month())))
		case 'd':
			sb.WriteString(fmt.Sprintf("%02d", tm.Day()))
		case 'e':
			sb.WriteString(fmt.Sprintf("%2d", tm.Day()))
		case 'H':
			sb.WriteString(fmt.Sprintf("%02d", tm.Hour()))
		case 'I':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(fmt.Sprintf("%02d", h))
		case 'p':
			if tm.Hour() < 12 {
				sb.WriteString("AM")
			} else {
				sb.WriteString("PM")
			}
		case 'M':
			sb.WriteString(fmt.Sprintf("%02d", tm.Minute()))
		case 'S':
			if prec > 0 {
				s := float64(tm.Second()) + frac
				sb.WriteString(fmt.Sprintf("%0*.*f", prec+3, prec, s))
			} else {
				sb.WriteString(fmt.Sprintf("%02d", tm.Second()))
			}
		case 's':
			sb.WriteString(fmt.Sprintf("%d", int64(sec)))
		case 'j':
			sb.WriteString(fmt.Sprintf("%03d", tm.YearDay()))
		case 'b', 'h':
			sb.WriteString(monNames[tm.Month()-1][:3])
		case 'B':
			sb.WriteString(monNames[tm.Month()-1])
		case 'a':
			sb.WriteString(dayNames[tm.Weekday()][:3])
		case 'A':
			sb.WriteString(dayNames[tm.Weekday()])
		case 'w':
			sb.WriteString(fmt.Sprintf("%d", int(tm.Weekday())))
		case 'D':
			sb.WriteString(fmt.Sprintf("%02d/%02d/%02d", int(tm.Month()), tm.Day(), tm.Year()%100))
		case 'F':
			sb.WriteString(fmt.Sprintf("%04d-%02d-%02d", tm.Year(), int(tm.Month()), tm.Day()))
		case 'T':
			sb.WriteString(fmt.Sprintf("%02d:%02d:%02d", tm.Hour(), tm.Minute(), tm.Second()))
		case 'R':
			sb.WriteString(fmt.Sprintf("%02d:%02d", tm.Hour(), tm.Minute()))
		case 'n':
			sb.WriteByte('\n')
		case 't':
			sb.WriteByte('\t')
		case '%':
			sb.WriteByte('%')
		default:
			sb.WriteByte('%')
			sb.WriteByte(f[i])
		}
	}
	return sb.String()
}

func gpStrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min, sec := 1970, 1, 1, 0, 0, 0.0
	yday := -1
	epoch := math.NaN()
	pm := -1
	j := 0
	readInt := func(maxw int) (int, bool) {
		for j < len(s) && s[j] == ' ' {
			j++
		}
		neg := false
		if j < len(s) && (s[j] == '-' || s[j] == '+') {
			neg = s[j] == '-'
			j++
		}
		st := j
		v := 0
		for j < len(s) && isDigit(s[j]) && j-st < maxw {
			v = v*10 + int(s[j]-'0')
			j++
		}
		if j == st {
			return 0, false
		}
		if neg {
			v = -v
		}
		return v, true
	}
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for j < len(s) && s[j] == ' ' {
					j++
				}
				continue
			}
			if j < len(s) && s[j] == c {
				j++
				continue
			}
			return 0, false
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			var y int
			y, ok = readInt(2)
			if y < 69 {
				year = 2000 + y
			} else {
				year = 1900 + y
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H':
			hour, ok = readInt(2)
		case 'I':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			var si int
			si, ok = readInt(2)
			sec = float64(si)
			if ok && j < len(s) && s[j] == '.' {
				st := j
				j++
				for j < len(s) && isDigit(s[j]) {
					j++
				}
				var fr float64
				fmt.Sscanf(s[st:j], "%g", &fr)
				sec += fr
			}
		case 's':
			st := j
			for j < len(s) && (isDigit(s[j]) || s[j] == '.' || s[j] == '-') {
				j++
			}
			var e float64
			_, err := fmt.Sscanf(s[st:j], "%g", &e)
			ok = err == nil
			epoch = e
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-j >= 3 && strings.EqualFold(s[j:j+3], m[:3]) {
					mon = k + 1
					if f[i] == 'B' && strings.HasPrefix(strings.ToLower(s[j:]), strings.ToLower(m)) {
						j += len(m)
					} else {
						j += 3
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			for j < len(s) && ((s[j] >= 'a' && s[j] <= 'z') || (s[j] >= 'A' && s[j] <= 'Z')) {
				j++
			}
			ok = true
		case 'p':
			if len(s)-j >= 2 {
				if strings.EqualFold(s[j:j+2], "pm") {
					pm = 1
				} else {
					pm = 0
				}
				j += 2
			}
			ok = true
		case 'T':
			hour, ok = readInt(2)
			j++
			min, _ = readInt(2)
			j++
			var si int
			si, _ = readInt(2)
			sec = float64(si)
		case '%':
			ok = j < len(s) && s[j] == '%'
			j++
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if !math.IsNaN(epoch) {
		return epoch, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	t := time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	}
	return float64(t.Unix()) + sec, true
}
