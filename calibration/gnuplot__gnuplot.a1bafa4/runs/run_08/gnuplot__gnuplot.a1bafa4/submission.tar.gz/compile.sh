#!/bin/sh
set -e
cd "$(dirname "$0")"
export GOFLAGS=-mod=mod GOPROXY=off GOTOOLCHAIN=local CGO_ENABLED=0
export GOCACHE="${GOCACHE:-$(pwd)/.gocache}"
go build -o executable .
