package main

import (
	"fmt"
	"math"
	"os"
	"strings"
)

type Axis struct {
	name       string
	min, max   float64
	autoMin    bool
	autoMax    bool
	curMin     float64
	curMax     float64
	reverse    bool
	log        bool
	base       float64
	label      string
	format     string
	isTime     bool
	ticsOn     bool
	mirror     bool
	ticStep    float64 // 0 = auto
	ticStart   float64
	ticEnd     float64
	hasTicSE   bool
	ticList    []ticDef
	ticAdd     bool
	minor      int
	timeFormat string
	ticsSet    bool
}

type ticDef struct {
	label string
	pos   float64
	level int
}

type Settings struct {
	samples, samples2       int
	iso1, iso2              int
	title                   string
	titleOffX, titleOffY    float64
	keyOn                   bool
	keyLeft, keyBottom      bool
	keyHPos                 string // left/right/center
	keyVPos                 string // top/bottom/center
	keyBox                  bool
	keyReverse              bool
	keyInside               bool
	keyOutside              bool
	keyJustLeft             bool
	keyTitle                string
	keyAbove, keyBelow      bool
	keyHoriz                bool
	styleData, styleFunc    string
	angleDeg                bool
	dummy1, dummy2          string
	grid                    bool
	termName                string
	termW, termH            int
	termFeed                bool
	output                  string
	dfSep                   string
	dfMissing               string
	dfComments              string
	dfHeader                bool
	tableOn                 bool
	tableFile               string
	tableBlock              string
	tableSep                string
	zero                    float64
	timefmt                 string
	boxwidth                float64
	boxwidthRel             bool
	parametric              bool
	polar                   bool
	border                  int
	pointsize               float64
	decimalsign             string
	fitLogfile              string
	fitQuiet                bool
	fitNolog                bool
	fitErrVars              bool
	fitCovVars              bool
	fitLimit                float64
	fitMaxIter              int
	fitPrescale             bool
	fitErrScaling           bool
	fitStartLambda          float64
	fitLambdaFactor         float64
	fitVerbose              bool
	clip                    bool
	xzeroaxis, yzeroaxis    bool
	labels                  []*Label
	arrows                  []*Arrow
	bars                    float64
	view                    [4]float64
	hidden3d                bool
	surface                 bool
	contour                 bool
	style                   map[string]string
	tics                    bool
	encoding                string
	ticsLevelOrBase         float64
	xyplane                 bool
	multiplot               bool
	offsets                 [4]float64
	lmargin, rmargin        float64
	tmargin, bmargin        float64
	mxtics                  bool
}

type Label struct {
	tag   int
	text  string
	x, y  float64
	coord string
	just  string
}
type Arrow struct {
	tag            int
	x1, y1, x2, y2 float64
	nohead         bool
}

var S Settings
var axes map[string]*Axis
var axisNames = []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"}

func newAxis(n string) *Axis {
	a := &Axis{name: n, autoMin: true, autoMax: true, curMin: -10, curMax: 10, base: 10, format: "% h", ticsOn: true, mirror: true, minor: 0}
	if n == "x2" || n == "y2" {
		a.ticsOn = false
	}
	if n == "t" {
		a.curMin, a.curMax = -5, 5
	}
	if n == "u" || n == "v" {
		a.curMin, a.curMax = -10, 10
	}
	if n == "r" {
		a.curMin, a.curMax = -10, 10
	}
	return a
}

func resetSettings() {
	S = Settings{samples: 100, samples2: 100, iso1: 10, iso2: 10, keyOn: true, keyHPos: "right", keyVPos: "top",
		styleData: "points", styleFunc: "lines", dummy1: "x", dummy2: "y", termName: "unknown", termW: 79, termH: 24,
		zero: 1e-8, timefmt: "%d/%m/%y,%H:%M", boxwidth: -1, border: 31, pointsize: 1, dfComments: "#",
		fitLimit: 1e-5, fitPrescale: true, fitErrVars: true, fitErrScaling: true, fitStartLambda: 0, fitLambdaFactor: 10,
		bars: 1, view: [4]float64{60, 30, 1, 1}, surface: true, tics: true, encoding: "utf8", ticsLevelOrBase: 0.5, keyInside: true,
		lmargin: -1, rmargin: -1, tmargin: -1, bmargin: -1, termFeed: true,
	}
	S.style = map[string]string{}
	axes = map[string]*Axis{}
	for _, n := range axisNames {
		axes[n] = newAxis(n)
	}
	axes["t"].curMin, axes["t"].curMax = -5, 5
	if keepTerm.name != "" {
		S.termName = keepTerm.name
		S.termW, S.termH = keepTerm.w, keepTerm.h
		S.output = keepTerm.output
	}
}

var keepTerm struct {
	name   string
	w, h   int
	output string
}

func show(format string, a ...interface{}) {
	fmt.Fprintf(stderrW, format, a...)
}

func (p *Parser) parseStringArg() string {
	e := p.parseExpr()
	v := e()
	if v.T != VStr {
		gpErr(-1, "expecting string")
	}
	return v.S
}

func (p *Parser) isStringStart() bool {
	t := p.cur()
	if t.Kind == TStr {
		return true
	}
	if t.Kind == TIdent && !p.endOfCmd() {
		if v, ok := globals[t.Text]; ok && v.T == VStr {
			return true
		}
		if t.Text == "sprintf" || t.Text == "gprintf" || t.Text == "strftime" {
			return true
		}
	}
	return false
}

func (p *Parser) parseNum() float64 {
	e := p.parseExpr()
	return numeric(e()).Real()
}

// parse range [a:b]; returns which set
func parseRange(p *Parser, ax *Axis) {
	if !p.isOp("[") {
		return
	}
	p.next()
	if p.isOp("]") {
		p.next()
		return
	}
	if !p.isOp(":") {
		if p.isOp("*") {
			p.next()
			ax.autoMin = true
		} else {
			ax.min = p.parseRangeVal(ax)
			ax.autoMin = false
		}
	}
	if p.isOp(":") {
		p.next()
		if p.isOp("*") {
			p.next()
			ax.autoMax = true
		} else if !p.isOp("]") {
			ax.max = p.parseRangeVal(ax)
			ax.autoMax = false
		}
	}
	if !p.isOp("]") {
		p.err("']' expected")
	}
	p.next()
}

func (p *Parser) parseRangeVal(ax *Axis) float64 {
	if ax.isTime && p.cur().Kind == TStr {
		s := p.next().Val.S
		t, _ := gpStrptime(S.timefmt, s)
		return t
	}
	return p.parseNum()
}

func axisFromPrefix(s string) (string, string) {
	for _, n := range []string{"x2", "y2", "cb", "x", "y", "z", "r", "t", "u", "v"} {
		if strings.HasPrefix(s, n) {
			return n, s[len(n):]
		}
	}
	return "", s
}

func cmdSet(p *Parser) {
	if p.endOfCmd() {
		return
	}
	t := p.cur()
	opt := t.Text
	p.next()
	// axis-prefixed options
	if an, rest := axisFromPrefix(opt); an != "" {
		ax := axes[an]
		switch {
		case rest == "range":
			parseRange(p, ax)
			for !p.endOfCmd() {
				if p.almost("rev$erse") {
					ax.reverse = true
				} else if p.almost("norev$erse") {
					ax.reverse = false
				}
				p.next()
			}
			return
		case rest == "label":
			if p.endOfCmd() {
				ax.label = ""
				return
			}
			ax.label = p.parseStringArg()
			skipRest(p)
			return
		case rest == "tics" || rest == "tic":
			ax.ticsOn = true
			parseTics(p, ax)
			return
		case rest == "data":
			if p.almost("t$ime") {
				ax.isTime = true
				p.next()
			} else {
				ax.isTime = false
			}
			skipRest(p)
			return
		case rest == "zeroaxis":
			skipRest(p)
			return
		case rest == "mtics" && an != "":
			skipRest(p)
			return
		}
		if strings.HasPrefix(an, "m") {
		}
	}
	if strings.HasPrefix(opt, "m") {
		if an, rest := axisFromPrefix(opt[1:]); an != "" && rest == "tics" {
			ax := axes[an]
			ax.minor = 1
			if !p.endOfCmd() {
				ax.minor = int(p.parseNum())
			}
			return
		}
	}
	switch {
	case almostEq(opt, "sa$mples"):
		S.samples = int(p.parseNum())
		S.samples2 = S.samples
		if p.isOp(",") {
			p.next()
			S.samples2 = int(p.parseNum())
		}
	case almostEq(opt, "iso$samples"):
		S.iso1 = int(p.parseNum())
		S.iso2 = S.iso1
		if p.isOp(",") {
			p.next()
			S.iso2 = int(p.parseNum())
		}
	case almostEq(opt, "tit$le"):
		if p.endOfCmd() {
			S.title = ""
			return
		}
		if p.isStringStart() {
			S.title = p.parseStringArg()
		}
		for !p.endOfCmd() {
			if p.almost("off$set") {
				p.next()
				S.titleOffX = p.parseNum()
				if p.isOp(",") {
					p.next()
					S.titleOffY = p.parseNum()
				}
				continue
			}
			p.next()
		}
	case almostEq(opt, "k$ey"):
		parseKey(p)
	case almostEq(opt, "log$scale"):
		names := "x y z x2 y2 cb"
		if !p.endOfCmd() && p.cur().Kind == TIdent {
			names = parseAxisList(p.next().Text)
		}
		base := 10.0
		if !p.endOfCmd() {
			base = p.parseNum()
		}
		for _, n := range strings.Fields(names) {
			axes[n].log = true
			axes[n].base = base
		}
	case almostEq(opt, "form$at"):
		which := []string{"x", "y", "z", "x2", "y2", "cb", "r"}
		if p.cur().Kind == TIdent && !p.isStringStart() {
			which = strings.Fields(parseAxisList(p.next().Text))
		}
		f := "% h"
		if !p.endOfCmd() {
			f = p.parseStringArg()
		}
		for _, w := range which {
			axes[w].format = f
		}
		skipRest(p)
	case almostEq(opt, "st$yle"):
		if p.almost("d$ata") {
			p.next()
			S.styleData = parseStyleName(p)
		} else if p.almost("f$unction") {
			p.next()
			S.styleFunc = parseStyleName(p)
		} else {
			k := p.next().Text
			var parts []string
			for !p.endOfCmd() {
				parts = append(parts, p.next().Text)
			}
			S.style[k] = strings.Join(parts, " ")
		}
	case almostEq(opt, "ang$les"):
		if p.almost("d$egrees") {
			S.angleDeg = true
		} else {
			S.angleDeg = false
		}
		p.next()
	case almostEq(opt, "du$mmy"):
		S.dummy1 = p.next().Text
		if p.isOp(",") {
			p.next()
			S.dummy2 = p.next().Text
		}
	case almostEq(opt, "gr$id"):
		S.grid = true
		skipRest(p)
	case almostEq(opt, "t$erminal"):
		parseTerm(p)
	case almostEq(opt, "o$utput"):
		if p.endOfCmd() {
			setOutput("")
		} else {
			setOutput(p.parseStringArg())
		}
	case almostEq(opt, "print"):
		closePrint()
		printToStdout = false
		printBlockActive = false
		if p.endOfCmd() {
			return
		}
		if p.cur().Kind == TIdent && p.cur().Text[0] == '$' {
			name := p.next().Text
			app := false
			if p.almost("app$end") {
				p.next()
				app = true
			}
			if _, ok := datablocks[name]; !ok || !app {
				datablocks[name] = []string{}
			}
			printBlock = name
			printBlockActive = true
			return
		}
		fn := p.parseStringArg()
		app := false
		if p.almost("app$end") {
			p.next()
			app = true
		}
		if fn == "-" {
			printToStdout = true
			return
		}
		var f *os.File
		var err error
		if app {
			f, err = os.OpenFile(fn, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		} else {
			f, err = os.Create(fn)
		}
		if err != nil {
			gpErr(-1, "cannot open print output file")
		}
		printFile = f
		printFileName = fn
	case almostEq(opt, "dataf$ile") || almostEq(opt, "da$tafile"):
		for !p.endOfCmd() {
			if p.almost("sep$arators") {
				p.next()
				if p.endOfCmd() || p.almost("white$space") {
					S.dfSep = ""
					if !p.endOfCmd() {
						p.next()
					}
				} else if p.almost("tab") {
					p.next()
					S.dfSep = "\t"
				} else if p.almost("comma") {
					p.next()
					S.dfSep = ","
				} else {
					S.dfSep = p.parseStringArg()
				}
			} else if p.almost("miss$ing") {
				p.next()
				if p.endOfCmd() {
					S.dfMissing = ""
				} else {
					S.dfMissing = p.parseStringArg()
				}
			} else if p.almost("com$mentschars") {
				p.next()
				if p.endOfCmd() {
					S.dfComments = "#"
				} else {
					S.dfComments = p.parseStringArg()
				}
			} else if p.almost("columnhead$ers") {
				p.next()
				S.dfHeader = true
			} else if p.almost("nocolumnhead$ers") {
				p.next()
				S.dfHeader = false
			} else {
				p.next()
			}
		}
	case almostEq(opt, "table"):
		S.tableOn = true
		S.tableFile = ""
		S.tableBlock = ""
		if !p.endOfCmd() {
			if p.cur().Kind == TIdent && p.cur().Text[0] == '$' {
				S.tableBlock = p.next().Text
				datablocks[S.tableBlock] = []string{}
			} else {
				S.tableFile = p.parseStringArg()
				os.WriteFile(S.tableFile, nil, 0644)
			}
		}
		skipRest(p)
	case almostEq(opt, "z$ero"):
		S.zero = p.parseNum()
	case almostEq(opt, "timef$mt"):
		S.timefmt = p.parseStringArg()
	case almostEq(opt, "boxw$idth"):
		if p.endOfCmd() {
			S.boxwidth = -1
		} else {
			S.boxwidth = p.parseNum()
			S.boxwidthRel = false
			if p.almost("rel$ative") {
				S.boxwidthRel = true
				p.next()
			} else if p.almost("abs$olute") {
				p.next()
			}
		}
	case almostEq(opt, "par$ametric"):
		S.parametric = true
		S.dummy1 = "t"
	case almostEq(opt, "pol$ar"):
		S.polar = true
		S.dummy1 = "t"
	case almostEq(opt, "bor$der"):
		if !p.endOfCmd() && p.cur().Kind == TNum {
			S.border = int(p.parseNum())
		}
		skipRest(p)
	case almostEq(opt, "poi$ntsize"):
		S.pointsize = p.parseNum()
	case almostEq(opt, "decimals$ign"):
		if !p.endOfCmd() {
			S.decimalsign = p.parseStringArg()
		}
		skipRest(p)
	case almostEq(opt, "fit"):
		parseFitOpts(p)
	case almostEq(opt, "cl$ip"):
		skipRest(p)
	case almostEq(opt, "lab$el"):
		parseLabel(p)
	case almostEq(opt, "ar$row"):
		parseArrow(p)
	case almostEq(opt, "view"):
		if p.almost("map") {
			p.next()
			S.view = [4]float64{0, 0, 1, 1}
			return
		}
		k := 0
		for !p.endOfCmd() && k < 4 {
			if p.isOp(",") {
				p.next()
				k++
				continue
			}
			S.view[k] = p.parseNum()
		}
	case almostEq(opt, "hid$den3d"):
		S.hidden3d = true
		skipRest(p)
	case almostEq(opt, "surf$ace"):
		S.surface = true
		skipRest(p)
	case almostEq(opt, "cont$ours"):
		S.contour = true
		skipRest(p)
	case almostEq(opt, "tics"):
		skipRest(p)
	case almostEq(opt, "mult$iplot"):
		startMultiplot(p)
	case almostEq(opt, "off$sets"):
		k := 0
		for !p.endOfCmd() && k < 4 {
			if p.isOp(",") {
				p.next()
				k++
				continue
			}
			S.offsets[k] = p.parseNum()
		}
	case almostEq(opt, "lmar$gin"):
		S.lmargin = marginArg(p)
	case almostEq(opt, "rmar$gin"):
		S.rmargin = marginArg(p)
	case almostEq(opt, "tmar$gin"):
		S.tmargin = marginArg(p)
	case almostEq(opt, "bmar$gin"):
		S.bmargin = marginArg(p)
	case almostEq(opt, "mar$gins"):
		skipRest(p)
	case almostEq(opt, "auto$scale"):
		if p.endOfCmd() {
			for _, a := range axes {
				a.autoMin, a.autoMax = true, true
			}
			return
		}
		for !p.endOfCmd() {
			w := p.next().Text
			for _, n := range axisNames {
				if w == n || w == n+"min" || w == n+"max" || w == n+"fix" {
					if w != n+"max" {
						axes[n].autoMin = true
					}
					if w != n+"min" {
						axes[n].autoMax = true
					}
				}
			}
			if w == "xy" {
				axes["x"].autoMin, axes["x"].autoMax = true, true
				axes["y"].autoMin, axes["y"].autoMax = true, true
			}
		}
	case almostEq(opt, "enc$oding"), almostEq(opt, "loc$ale"), almostEq(opt, "si$ze"), almostEq(opt, "ori$gin"),
		almostEq(opt, "ma$croS"), almostEq(opt, "colors$equence"), almostEq(opt, "pal$ette"), almostEq(opt, "pm3d"),
		almostEq(opt, "colorb$ox"), almostEq(opt, "obj$ect"), almostEq(opt, "linet$ype"), almostEq(opt, "ticsl$evel"),
		almostEq(opt, "xyp$lane"), almostEq(opt, "cntrp$aram"), almostEq(opt, "cntrl$abel"), almostEq(opt, "mou$se"),
		almostEq(opt, "hist$orysize"), almostEq(opt, "fontp$ath"), almostEq(opt, "loadp$ath"), almostEq(opt, "ter$moption"),
		almostEq(opt, "rt$ics"), almostEq(opt, "ttics"), almostEq(opt, "rtics"), almostEq(opt, "bar$s"), almostEq(opt, "errorbars"),
		almostEq(opt, "jitter"), almostEq(opt, "minus$sign"), almostEq(opt, "micro"), almostEq(opt, "overflow"),
		almostEq(opt, "dg$rid3d"), almostEq(opt, "map$ping"), almostEq(opt, "raxis"), almostEq(opt, "zeroaxis"),
		almostEq(opt, "theta"), almostEq(opt, "vxrange"), almostEq(opt, "isosurface"), almostEq(opt, "walls"),
		almostEq(opt, "pixmap"), almostEq(opt, "nonlinear"), almostEq(opt, "link"), almostEq(opt, "psdir"),
		almostEq(opt, "historysize"), almostEq(opt, "sty$le"), almostEq(opt, "for$mat"):
		skipRest(p)
	default:
		if strings.HasPrefix(opt, "no") {
			unsetOpt(opt[2:], p)
			return
		}
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

var printFileName string

func marginArg(p *Parser) float64 {
	if p.endOfCmd() {
		return -1
	}
	if p.almost("at") {
		p.next()
		p.almost("sc$reen")
		p.next()
	}
	return p.parseNum()
}

func skipRest(p *Parser) {
	for !p.endOfCmd() {
		p.next()
	}
}

func parseAxisList(s string) string {
	var out []string
	for len(s) > 0 {
		switch {
		case strings.HasPrefix(s, "x2"):
			out = append(out, "x2")
			s = s[2:]
		case strings.HasPrefix(s, "y2"):
			out = append(out, "y2")
			s = s[2:]
		case strings.HasPrefix(s, "cb"):
			out = append(out, "cb")
			s = s[2:]
		default:
			out = append(out, s[:1])
			s = s[1:]
		}
	}
	return strings.Join(out, " ")
}

func parseStyleName(p *Parser) string {
	w := p.next().Text
	full := styleFull(w)
	if full == "" {
		gpErr(p.toks[p.i-1].Pos, "unrecognized plot type")
	}
	for !p.endOfCmd() {
		p.next()
	}
	return full
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "imp$ulses", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xyerrorb$ars", "yerrorl$ines", "errorl$ines", "xerrorl$ines", "xyerrorl$ines", "boxes", "boxer$rorbars", "boxxy$errorbars", "st$eps", "fs$teps", "his$teps", "fillst$eps", "vec$tors", "fin$ancebars", "candle$sticks", "histograms", "filledc$urves", "lab$els", "circles", "ellipses", "pm3d", "image", "rgbimage", "surface", "zerrorfill", "arrows", "boxplot", "table", "parallelaxes", "spiderplot", "polygons", "sectors"}

func styleFull(w string) string {
	for _, s := range styleNames {
		if almostEq(w, s) {
			r := strings.Replace(s, "$", "", 1)
			if r == "lp" {
				r = "linespoints"
			}
			if r == "errorbars" {
				r = "yerrorbars"
			}
			if r == "errorlines" {
				r = "yerrorlines"
			}
			return r
		}
	}
	return ""
}

func parseKey(p *Parser) {
	S.keyOn = true
	for !p.endOfCmd() {
		w := p.cur()
		switch {
		case p.almost("of$f"):
			S.keyOn = false
		case p.almost("on"):
			S.keyOn = true
		case p.almost("l$eft"):
			S.keyHPos = "left"
		case p.almost("r$ight"):
			S.keyHPos = "right"
		case p.almost("c$enter"):
			if S.keyHPos == "center" || true {
				S.keyHPos = "center"
			}
		case p.almost("t$op"):
			S.keyVPos = "top"
		case p.almost("b$ottom"):
			S.keyVPos = "bottom"
		case p.almost("bo$x"):
			S.keyBox = true
		case p.almost("nobo$x"):
			S.keyBox = false
		case p.almost("rev$erse"):
			S.keyReverse = true
		case p.almost("norev$erse"):
			S.keyReverse = false
		case p.almost("Left"):
			S.keyJustLeft = true
		case p.almost("Right"):
			S.keyJustLeft = false
		case p.almost("ins$ide"):
			S.keyInside = true
		case p.almost("out$side"):
			S.keyInside = false
		case p.almost("tit$le"):
			p.next()
			if p.isStringStart() {
				S.keyTitle = p.parseStringArg()
			}
			continue
		case p.almost("hor$izontal"):
			S.keyHoriz = true
		case p.almost("ver$tical"):
			S.keyHoriz = false
		case p.almost("above") || p.almost("over"):
			S.keyAbove = true
		case p.almost("below") || p.almost("under"):
			S.keyBelow = true
		default:
			if w.Kind == TNum || w.Kind == TStr {
				p.next()
				continue
			}
		}
		p.next()
	}
}

func parseTics(p *Parser, ax *Axis) {
	for !p.endOfCmd() {
		switch {
		case p.almost("nomi$rror"):
			ax.mirror = false
			p.next()
		case p.almost("mi$rror"):
			ax.mirror = true
			p.next()
		case p.almost("add"):
			ax.ticAdd = true
			p.next()
		case p.almost("autof$req"):
			ax.ticStep = 0
			ax.ticList = nil
			ax.hasTicSE = false
			p.next()
		case p.almost("form$at"):
			p.next()
			ax.format = p.parseStringArg()
		case p.isOp("("):
			p.next()
			if !ax.ticAdd {
				ax.ticList = nil
			}
			for !p.isOp(")") && !p.endOfCmd() {
				lbl := ""
				hasLbl := false
				if p.isStringStart() {
					lbl = p.parseStringArg()
					hasLbl = true
				}
				pos := p.parseNum()
				lev := 0
				if !p.isOp(",") && !p.isOp(")") {
					lev = int(p.parseNum())
				}
				if !hasLbl {
					lbl = "\x00"
				}
				ax.ticList = append(ax.ticList, ticDef{label: lbl, pos: pos, level: lev})
				if p.isOp(",") {
					p.next()
				}
			}
			p.next()
			if !ax.ticAdd {
				ax.ticStep = -1
			}
		case p.cur().Kind == TNum || p.isOp("-") || p.isOp("+"):
			a := p.parseNum()
			if p.isOp(",") {
				p.next()
				b := p.parseNum()
				ax.ticStart = a
				ax.ticStep = b
				ax.hasTicSE = true
				ax.ticEnd = math.Inf(1)
				if p.isOp(",") {
					p.next()
					ax.ticEnd = p.parseNum()
				}
			} else {
				ax.ticStep = a
				ax.hasTicSE = false
			}
			ax.ticList = nil
		default:
			p.next()
		}
	}
}

func parseLabel(p *Parser) {
	l := &Label{tag: len(S.labels) + 1, just: "left"}
	if p.cur().Kind == TNum {
		l.tag = int(p.parseNum())
	}
	if p.isStringStart() {
		l.text = p.parseStringArg()
	}
	for !p.endOfCmd() {
		if p.almost("at") {
			p.next()
			if p.almost("gr$aph") || p.almost("sc$reen") || p.almost("fir$st") || p.almost("char$acter") {
				l.coord = p.next().Text
			}
			l.x = p.parseNum()
			if p.isOp(",") {
				p.next()
				if p.almost("gr$aph") || p.almost("sc$reen") || p.almost("fir$st") || p.almost("char$acter") {
					p.next()
				}
				l.y = p.parseNum()
			}
			continue
		}
		if p.almost("cent$er") {
			l.just = "center"
		} else if p.almost("righ$t") {
			l.just = "right"
		} else if p.almost("lef$t") {
			l.just = "left"
		}
		p.next()
	}
	for i, x := range S.labels {
		if x.tag == l.tag {
			S.labels[i] = l
			return
		}
	}
	S.labels = append(S.labels, l)
}

func parseArrow(p *Parser) {
	a := &Arrow{tag: len(S.arrows) + 1}
	if p.cur().Kind == TNum {
		a.tag = int(p.parseNum())
	}
	for !p.endOfCmd() {
		if p.almost("fr$om") {
			p.next()
			a.x1 = p.parseNum()
			p.next()
			a.y1 = p.parseNum()
			continue
		}
		if p.almost("to") {
			p.next()
			a.x2 = p.parseNum()
			p.next()
			a.y2 = p.parseNum()
			continue
		}
		if p.almost("noh$ead") {
			a.nohead = true
		}
		p.next()
	}
	S.arrows = append(S.arrows, a)
}

func parseFitOpts(p *Parser) {
	for !p.endOfCmd() {
		switch {
		case p.almost("nolog$file"):
			S.fitNolog = true
		case p.almost("log$file"):
			p.next()
			S.fitNolog = false
			if p.isStringStart() {
				S.fitLogfile = p.parseStringArg()
			}
			continue
		case p.almost("q$uiet"):
			S.fitQuiet = true
			S.fitVerbose = false
		case p.almost("noq$uiet"), p.almost("results"):
			S.fitQuiet = false
		case p.almost("brief"):
			S.fitQuiet = false
			S.fitVerbose = false
		case p.almost("verbose"):
			S.fitVerbose = true
		case p.almost("errorv$ariables"):
			S.fitErrVars = true
		case p.almost("noerrorv$ariables"):
			S.fitErrVars = false
		case p.almost("cov$ariancevariables"):
			S.fitCovVars = true
		case p.almost("nocov$ariancevariables"):
			S.fitCovVars = false
		case p.almost("errors$caling"):
			S.fitErrScaling = true
		case p.almost("noerrors$caling"):
			S.fitErrScaling = false
		case p.almost("pre$scale"):
			S.fitPrescale = true
		case p.almost("nopre$scale"):
			S.fitPrescale = false
		case p.almost("lim$it"):
			p.next()
			S.fitLimit = p.parseNum()
			continue
		case p.almost("maxiter"):
			p.next()
			S.fitMaxIter = int(p.parseNum())
			continue
		case p.almost("start$-lambda"):
			p.next()
			S.fitStartLambda = p.parseNum()
			continue
		case p.almost("lambda$-factor"):
			p.next()
			S.fitLambdaFactor = p.parseNum()
			continue
		}
		p.next()
	}
}

func unsetOpt(opt string, p *Parser) {
	if an, rest := axisFromPrefix(opt); an != "" {
		ax := axes[an]
		switch rest {
		case "range":
			ax.autoMin, ax.autoMax = true, true
			return
		case "label":
			ax.label = ""
			return
		case "tics":
			ax.ticsOn = false
			return
		case "data":
			ax.isTime = false
			return
		case "zeroaxis", "mtics":
			return
		}
	}
	if strings.HasPrefix(opt, "m") {
		if an, rest := axisFromPrefix(opt[1:]); an != "" && rest == "tics" {
			axes[an].minor = 0
			return
		}
	}
	switch {
	case almostEq(opt, "k$ey"):
		S.keyOn = false
	case almostEq(opt, "tit$le"):
		S.title = ""
	case almostEq(opt, "log$scale"):
		names := "x y z x2 y2 cb r"
		if !p.endOfCmd() {
			names = parseAxisList(p.next().Text)
		}
		for _, n := range strings.Fields(names) {
			axes[n].log = false
		}
	case almostEq(opt, "gr$id"):
		S.grid = false
	case almostEq(opt, "table"):
		closeTable()
	case almostEq(opt, "par$ametric"):
		S.parametric = false
		S.dummy1 = "x"
	case almostEq(opt, "pol$ar"):
		S.polar = false
		S.dummy1 = "x"
	case almostEq(opt, "o$utput"):
		setOutput("")
	case almostEq(opt, "print"):
		closePrint()
		printToStdout = false
		printBlockActive = false
	case almostEq(opt, "lab$el"):
		S.labels = nil
	case almostEq(opt, "ar$row"):
		S.arrows = nil
	case almostEq(opt, "bor$der"):
		S.border = 0
	case almostEq(opt, "mult$iplot"):
		endMultiplot()
	case almostEq(opt, "tics"):
		for _, a := range axes {
			a.ticsOn = false
		}
	case almostEq(opt, "form$at"):
		for _, a := range axes {
			a.format = "% h"
		}
	case almostEq(opt, "hid$den3d"):
		S.hidden3d = false
	case almostEq(opt, "surf$ace"):
		S.surface = false
	case almostEq(opt, "cont$ours"):
		S.contour = false
	case almostEq(opt, "dataf$ile"):
		S.dfSep = ""
		S.dfMissing = ""
		S.dfComments = "#"
	case almostEq(opt, "auto$scale"):
		for !p.endOfCmd() {
			p.next()
		}
	case almostEq(opt, "t$erminal"):
		S.termName = "unknown"
		keepTerm.name = ""
	case almostEq(opt, "fit"):
	case almostEq(opt, "clip"), almostEq(opt, "colorb$ox"), almostEq(opt, "obj$ect"), almostEq(opt, "zeroaxis"),
		almostEq(opt, "xyp$lane"), almostEq(opt, "mou$se"), almostEq(opt, "st$yle"), almostEq(opt, "pm3d"), almostEq(opt, "mar$gins"),
		almostEq(opt, "lmar$gin"), almostEq(opt, "rmar$gin"), almostEq(opt, "tmar$gin"), almostEq(opt, "bmar$gin"):
	default:
		gpErr(p.toks[p.i-1].Pos, "Unrecognized option.  See 'help unset'.")
	}
	skipRest(p)
}

func cmdUnset(p *Parser) {
	if p.endOfCmd() {
		return
	}
	opt := p.next().Text
	unsetOpt(opt, p)
}
