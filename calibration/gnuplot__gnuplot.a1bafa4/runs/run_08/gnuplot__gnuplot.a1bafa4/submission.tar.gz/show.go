package main

import (
	"fmt"
	"strings"
)

func fmtRangeVal(f float64) string {
	return cfmt("%#g", f)
}

func showRange(n string) {
	a := axes[n]
	lo, hi := "*", "*"
	if !a.autoMin {
		lo = fmtRangeVal(a.min)
	}
	if !a.autoMax {
		hi = fmtRangeVal(a.max)
	}
	rev := "noreverse"
	if a.reverse {
		rev = "reverse"
	}
	s := fmt.Sprintf("\tset %srange [ %s : %s ] %s nowriteback", n, lo, hi, rev)
	if a.autoMin || a.autoMax {
		s += fmt.Sprintf("  # (currently [%s:%s] )", cfmt("%#g", a.curMin), cfmt("%#g", a.curMax))
	}
	show("\n%s\n\n", s)
}

func showVarLine(name string, v Value) {
	switch v.T {
	case VStr:
		show("\t%s = \"%s\"\n", name, v.S)
	case VArr:
		show("\t%s = <%d element array>\n", name, len(*v.Arr)-1)
	case VCmplx:
		if v.Im == 0 && v.R != v.R {
			show("\t%s = NaN\n", name)
		} else {
			show("\t%s = %s\n", name, v.PrintStr())
		}
	default:
		show("\t%s = %s\n", name, v.PrintStr())
	}
}

func showVariables(p *Parser) {
	all := false
	prefix := ""
	if p.almost("all") {
		p.next()
		all = true
	} else if !p.endOfCmd() {
		prefix = p.next().Text
	}
	if all {
		show("\n\tAll available variables:\n")
	} else if prefix != "" {
		show("\n\tVariables beginning with %s:\n", prefix)
	} else {
		show("\n\tUser and default variables:\n")
	}
	for _, k := range orderedVars() {
		if prefix != "" && !strings.HasPrefix(k, prefix) {
			continue
		}
		if !all && prefix == "" && strings.HasPrefix(k, "GPVAL_") {
			continue
		}
		if k == "GPVAL_COMPILE_OPTIONS" || k == "GPVAL_TERMINALS" {
		}
		showVarLine(k, globals[k])
	}
	show("\n")
}

func cmdShow(p *Parser) {
	if p.endOfCmd() {
		return
	}
	t := p.cur()
	opt := t.Text
	p.next()
	if an, rest := axisFromPrefix(opt); an != "" {
		a := axes[an]
		switch rest {
		case "range":
			showRange(an)
			return
		case "label":
			show("\n\t%slabel is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", an, a.label)
			return
		case "data":
			if a.isTime {
				show("\n\t%s is set to time\n\n", an)
			} else {
				show("\n\t%s is set to numerical\n\n", an)
			}
			return
		}
	}
	switch {
	case almostEq(opt, "sa$mples"):
		show("\n\tsampling rate is %d, %d\n\n", S.samples, S.samples2)
	case almostEq(opt, "iso$samples"):
		show("\n\tiso sampling rate is %d, %d\n\n", S.iso1, S.iso2)
	case almostEq(opt, "tit$le"):
		show("\n\ttitle is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", S.title, gnum(S.titleOffX), gnum(S.titleOffY))
	case almostEq(opt, "k$ey"):
		showKey()
	case almostEq(opt, "log$scale"):
		var parts []string
		for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			a := axes[n]
			if a.log {
				if a.base != 10 {
					parts = append(parts, fmt.Sprintf("%s (base %s)", n, gnum(a.base)))
				} else {
					parts = append(parts, n)
				}
			}
		}
		if len(parts) == 0 {
			show("\n\tlogscaling on none\n\n")
		} else {
			show("\n\tlogscaling on  %s\n\n", strings.Join(parts, " "))
		}
	case almostEq(opt, "form$at"):
		show("\n\ttic format is:\n")
		for _, n := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			show("\t  %s-axis: \"%s\"\n", n, axes[n].format)
		}
		show("\n")
	case almostEq(opt, "st$yle"):
		if p.almost("d$ata") {
			p.next()
			show("\n\tData are plotted with %s\n\n", S.styleData)
		} else if p.almost("f$unction") {
			p.next()
			show("\n\tFunctions are plotted with %s\n\n", S.styleFunc)
		} else {
			skipRest(p)
		}
	case almostEq(opt, "ang$les"):
		if S.angleDeg {
			show("\n\tAngles are in degrees\n\n")
		} else {
			show("\n\tAngles are in radians\n\n")
		}
	case almostEq(opt, "du$mmy"):
		show("\n\tdummy variables are %s %s \n\n", S.dummy1, S.dummy2)
	case almostEq(opt, "gr$id"):
		if !S.grid {
			show("\n\tgrid is OFF\n\n")
		} else {
			show("\n\tRectangular grid drawn at x y tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case almostEq(opt, "t$erminal"):
		showTerm()
	case almostEq(opt, "o$utput"):
		if S.output == "" {
			show("\n\toutput is sent to STDOUT\n\n")
		} else {
			show("\n\toutput is sent to '%s'\n\n", S.output)
		}
	case almostEq(opt, "dataf$ile"):
		show("\n")
		if S.dfMissing == "" {
			show("\tNo missing data string set for datafile\n")
		} else {
			show("\t\"%s\" in datafile is interpreted as missing value\n", S.dfMissing)
		}
		if S.dfSep == "" {
			show("\tdatafile fields separated by whitespace\n")
		} else {
			show("\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.dfSep), S.dfSep)
		}
		show("\tComments chars are \"%s\"\n", S.dfComments)
		if S.dfHeader {
			show("\tFirst line is treated as headers\n")
		} else {
			show("\tFirst line is treated as headers only if accessed explicitly\n")
		}
		show("\n")
	case almostEq(opt, "table"):
		if S.tableOn {
			show("\n\ttable mode is on, field separator tab\n\n")
		} else {
			show("\n\ttable mode is off\n\n")
		}
	case almostEq(opt, "z$ero"):
		show("\n\tzero is %s\n\n", gnum(S.zero))
	case almostEq(opt, "timef$mt"):
		show("\n\tDefault format for reading time data is \"%s\"\n\n", S.timefmt)
	case almostEq(opt, "boxw$idth"):
		if S.boxwidth < 0 {
			show("\n\tboxwidth is auto\n\tboxdepth is 0\n\n")
		} else if S.boxwidthRel {
			show("\n\tboxwidth is %s relative\n\tboxdepth is 0\n\n", gnum(S.boxwidth))
		} else {
			show("\n\tboxwidth is %s absolute\n\tboxdepth is 0\n\n", gnum(S.boxwidth))
		}
	case almostEq(opt, "par$ametric"):
		show("\n\tparametric is %s\n\n", onoff(S.parametric))
	case almostEq(opt, "pol$ar"):
		show("\n\tpolar is %s\n\n", onoff(S.polar))
	case almostEq(opt, "poi$ntsize"):
		show("\n\tpointsize is %s\n\n", gnum(S.pointsize))
	case almostEq(opt, "ori$gin"):
		show("\n\torigin is set to 0,0\n\n")
	case almostEq(opt, "off$sets"):
		show("\n\toffsets are %s, %s, %s, %s\n\n", gnum(S.offsets[0]), gnum(S.offsets[1]), gnum(S.offsets[2]), gnum(S.offsets[3]))
	case almostEq(opt, "si$ze"):
		show("\n\tsize is scaled by 1,1\n\tNo attempt to control aspect ratio\n\n")
	case almostEq(opt, "bor$der"):
		if S.border == 0 {
			show("\n\tborder is not drawn\n\n")
		} else {
			show("\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.border, S.border)
		}
	case almostEq(opt, "fu$nctions"):
		show("\n\tUser-Defined Functions:\n")
		for _, n := range udfOrder {
			if u, ok := udfs[n]; ok {
				show("\t%s\n", u.Text)
			}
		}
		show("\n")
	case almostEq(opt, "v$ariables"):
		showVariables(p)
	case almostEq(opt, "decimals$ign"):
		show("\n\tdecimalsign for input is  . \n")
		if S.decimalsign == "" {
			show("\tdecimalsign for output has default value (normally '.')\n")
		} else {
			show("\tdecimalsign for output is %s \n", S.decimalsign)
		}
		show("\tdegree sign for output is \u00b0 \n\n")
	case almostEq(opt, "ver$sion"):
		if p.almost("l$ong") {
			p.next()
		}
		show("\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
	case almostEq(opt, "print"):
		if printToStdout {
			show("\n\tprint output is sent to '<stdout>'\n\n")
		} else if printBlockActive {
			show("\n\tprint output is saved to datablock %s\n\n", printBlock)
		} else if printFile != nil {
			show("\n\tprint output is sent to '%s'\n\n", printFileName)
		} else {
			show("\n\tprint output is sent to '<stderr>'\n\n")
		}
	case almostEq(opt, "fit"):
		showFit()
	case almostEq(opt, "mar$gins"):
		show("\n\tlmargin is computed automatically\n\trmargin is computed automatically\n\tbmargin is computed automatically\n\ttmargin is computed automatically\n\n")
	case almostEq(opt, "cl$ip"):
		show("\n\tpoint clip is OFF\n\tclipping lines with one end out of range (clip one)\n\tnot drawing lines with both ends out of range (clip two)\n\tnot clipping lines on polar plot at maximum radius\n\n")
	case almostEq(opt, "enc$oding"):
		show("\n\tnominal character encoding is utf8\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case almostEq(opt, "view"):
		show("\n\tview is %s rot_x, %s rot_z, %s scale, %s scale_z\n\t\t axes are independently scaled\n\t\t azimuth 0\n\n", gnum(S.view[0]), gnum(S.view[1]), gnum(S.view[2]), gnum(S.view[3]))
	case almostEq(opt, "auto$scale"):
		show("\n\tautoscaling is \tx: %s, \ty: %s, \n\t               \tx2: %s, \ty2: %s, \n\t               \tz: %s, \tcb: %s, \n", asc("x"), asc("y"), asc("x2"), asc("y2"), asc("z"), asc("cb"))
	case almostEq(opt, "bar$s"):
		show("set errorbars front 1.000000 \n")
	case almostEq(opt, "lab$el"):
		show("\n")
		show("\n")
	case almostEq(opt, "ar$row"):
		show("\n")
		show("\n")
	case almostEq(opt, "loadp$ath"):
		show("\n\tloadpath is empty\n\tgnuplotrc is read from /usr/local/share/gnuplot/5.4\n\n")
	case almostEq(opt, "hid$den3d"):
		show("\n\thidden surface is %s\n\n", map[bool]string{true: "removed", false: "drawn"}[S.hidden3d])
	case almostEq(opt, "surf$ace"):
		if S.surface {
			show("\n\tsurface is drawn \n\n")
		} else {
			show("\n\tsurface is not drawn\n\n")
		}
	default:
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
}

func asc(n string) string {
	a := axes[n]
	if a.autoMin && a.autoMax {
		return "ON"
	}
	if a.autoMin {
		return "MIN"
	}
	if a.autoMax {
		return "MAX"
	}
	return "OFF"
}

func onoff(b bool) string {
	if b {
		return "ON"
	}
	return "OFF"
}

func gnum(f float64) string {
	return cfmt("%g", f)
}

func showKey() {
	if !S.keyOn {
		show("\n\tkey is OFF\n\n")
		return
	}
	pos := S.keyVPos + " " + S.keyHPos
	if S.keyVPos == "center" && S.keyHPos == "center" {
		pos = "center"
	}
	show("\n\tkey is ON, position: %s vertical fixed  offset: (character 0, 0)\n", pos)
	just := "right"
	if S.keyJustLeft {
		just = "left"
	}
	rev := "not reversed"
	if S.keyReverse {
		rev = "reversed"
	}
	if S.keyBox {
		show("\tkey is %s justified, %s, not inverted, enhanced and boxed\n\twith  lt black linewidth 1.000 dashtype solid\n", just, rev)
	} else {
		show("\tkey is %s justified, %s, not inverted, enhanced and not boxed\n", just, rev)
	}
	show("\tsample length is 4 characters\n\tvertical spacing is 1 characters\n\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n\n\tkey title is \"%s\" center justified \n\n", S.keyTitle)
}

func showTerm() {
	switch S.termName {
	case "dumb":
		show("\n   terminal type is dumb %s size %d, %d aspect 2, 1 mono\n\n", map[bool]string{true: "feed ", false: "nofeed "}[S.termFeed], S.termW, S.termH)
	case "unknown":
		show("\n   terminal type is unknown \n\n")
	default:
		show("\n   terminal type is %s %s\n\n", S.termName, termOptions())
	}
}

func showFit() {
	if S.fitQuiet {
		show("\n\tfit will not output results to console.\n")
	} else if S.fitVerbose {
		show("\n\tfit will output verbose results to console and log-file.\n")
	} else {
		show("\n\tfit will output brief results to console and log-file.\n")
	}
	show("\tfit can handle up to 12 independent variables\n")
	if S.fitPrescale {
		show("\tfit will prescale parameters by their initial values\n")
	} else {
		show("\tfit will not prescale parameters by their initial values\n")
	}
	if S.fitErrVars {
		show("\tfit will place parameter errors in variables\n")
	} else {
		show("\tfit will not place parameter errors in variables\n")
	}
	if S.fitCovVars {
		show("\tfit will place covariances in variables\n")
	} else {
		show("\tfit will not place covariances in variables\n")
	}
	if S.fitErrScaling {
		show("\tfit will scale parameter errors with the reduced chi square\n")
	} else {
		show("\tfit will not scale parameter errors with the reduced chi square\n")
	}
	if S.fitNolog {
		show("\tno logfile will be written\n")
	} else if S.fitLogfile != "" {
		show("\tlog-file for fits was set by the user to \n\t\t'%s'\n", S.fitLogfile)
	} else {
		show("\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
	}
	show("\tfits will be considered to have converged if  delta chisq < chisq * %s\n", gnum(S.fitLimit))
	if S.fitMaxIter > 0 {
		show("\tfit will stop after a maximum of %d iterations\n", S.fitMaxIter)
	} else {
		show("\tfit has no limit in the number of iterations\n")
	}
	show("\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
}
