package main

import (
	"fmt"
	"math"
	"strings"
)

type Canvas struct {
	w, h int
	c    [][]byte
}

func newCanvas(w, h int) *Canvas {
	cv := &Canvas{w: w, h: h}
	cv.c = make([][]byte, h)
	for i := range cv.c {
		cv.c[i] = []byte(strings.Repeat(" ", w))
	}
	return cv
}

func (cv *Canvas) set(x, y int, ch byte) {
	if x < 0 || y < 0 || x >= cv.w || y >= cv.h {
		return
	}
	cv.c[y][x] = ch
}

func (cv *Canvas) text(x, y int, s string) {
	for i := 0; i < len(s); i++ {
		cv.set(x+i, y, s[i])
	}
}

// vector with dumb terminal semantics; pen 0 = border
func (cv *Canvas) vector(x0, y0, x1, y1 int, pen byte) {
	dx := x1 - x0
	dy := y1 - y0
	adx, ady := iabs(dx), iabs(dy)
	if ady > adx {
		p, p1 := pen, pen
		if pen == 0 {
			p, p1 = '|', '+'
		}
		cv.set(x0, y0, p1)
		for d := 1; d < ady; d++ {
			cv.set(x0+int(math.Floor(float64(dx)*float64(d)/float64(ady)+0.5)), y0+d*isign(dy), p)
		}
		cv.set(x1, y1, p1)
	} else if adx > ady {
		p, p1 := pen, pen
		if pen == 0 {
			p, p1 = '-', '+'
		}
		cv.set(x0, y0, p1)
		for d := 1; d < adx; d++ {
			cv.set(x0+d*isign(dx), y0+int(math.Floor(float64(dy)*float64(d)/float64(adx)+0.5)), p)
		}
		cv.set(x1, y1, p1)
	} else {
		p := pen
		if pen == 0 {
			p = '+'
		}
		for d := 0; d <= adx; d++ {
			cv.set(x0+d*isign(dx), y0+d*isign(dy), p)
		}
	}
}

func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}
func isign(a int) int {
	if a < 0 {
		return -1
	}
	if a > 0 {
		return 1
	}
	return 0
}

func (cv *Canvas) String() string {
	var sb strings.Builder
	for y := cv.h - 1; y >= 0; y-- {
		sb.Write(cv.c[y])
		sb.WriteByte('\n')
	}
	return sb.String()
}

var lineChars = "*#$%@&="

func quantizeTics(arg, guide float64) float64 {
	power := math.Pow(10, math.Floor(math.Log10(arg)))
	xnorm := arg / power
	posns := guide / xnorm
	var t float64
	switch {
	case posns > 40:
		t = 0.05
	case posns > 20:
		t = 0.1
	case posns > 10:
		t = 0.2
	case posns > 4:
		t = 0.5
	case posns > 2:
		t = 1
	case posns > 0.5:
		t = 2
	default:
		t = math.Ceil(xnorm)
	}
	return t * power
}

type AxisRange struct {
	min, max float64
	step     float64
	log      bool
	base     float64
}

// autoscale: extend range to tic multiples
func autoExtend(lo, hi float64, ax *Axis, name string) (float64, float64, float64) {
	if ax.log {
		return lo, hi, 0
	}
	if lo > hi {
		lo, hi = hi, lo
	}
	if lo == hi {
		ymin, ymax := lo, hi
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			lo = lo - math.Abs(lo)*0.01
			hi = hi + math.Abs(hi)*0.01
		}
		fmt.Fprintf(stderrW, "Warning: empty %s range [%s:%s], adjusting to [%s:%s]\n", name, gnum(ymin), gnum(ymax), gnum(lo), gnum(hi))
	}
	step := ax.ticStep
	if step <= 0 {
		step = quantizeTics(hi-lo, 20)
	}
	nlo, nhi := lo, hi
	if ax.autoMin {
		nlo = math.Floor(lo/step+1e-9) * step
	}
	if ax.autoMax {
		nhi = math.Ceil(hi/step-1e-9) * step
	}
	return nlo, nhi, step
}

func extendRange(a, b float64, ax *Axis) (float64, float64) {
	lo, hi, _ := autoExtend(a, b, ax, "x")
	return lo, hi
}

type ticMark struct {
	pos   float64
	label string
}

func genTics(lo, hi, step float64, ax *Axis) []ticMark {
	var out []ticMark
	if ax.ticList != nil && ax.ticStep < 0 {
		for _, t := range ax.ticList {
			l := t.label
			if l == "\x00" {
				l = gprintf(ax.format, t.pos)
			}
			out = append(out, ticMark{t.pos, l})
		}
		return out
	}
	if ax.log {
		base := ax.base
		e0 := math.Floor(math.Log(math.Min(lo, hi))/math.Log(base) - 1e-9)
		e1 := math.Ceil(math.Log(math.Max(lo, hi))/math.Log(base) + 1e-9)
		for e := e0; e <= e1; e++ {
			v := math.Pow(base, e)
			if v >= math.Min(lo, hi)*(1-1e-9) && v <= math.Max(lo, hi)*(1+1e-9) {
				out = append(out, ticMark{v, gprintf(ax.format, v)})
			}
		}
		return out
	}
	a, b := math.Min(lo, hi), math.Max(lo, hi)
	start := math.Ceil(a/step-1e-9) * step
	if ax.hasTicSE {
		start = ax.ticStart
		for start-step >= a-1e-9*step {
			start -= step
		}
		for start < a-1e-9*math.Abs(step) {
			start += step
		}
	}
	for k := 0; k < 1000; k++ {
		v := start + float64(k)*step
		if v > b+1e-9*math.Abs(step) {
			break
		}
		if ax.hasTicSE && v > ax.ticEnd+1e-9 {
			break
		}
		if math.Abs(v) < 1e-12*math.Abs(step) {
			v = 0
		}
		out = append(out, ticMark{v, gprintf(ax.format, v)})
	}
	return out
}

func ticLabelFmt(f string, v float64) string {
	return gprintf(f, v)
}

func pointChar(pt int) byte {
	if pt <= 0 {
		return '.'
	}
	return byte('A' + (pt-1)%26)
}

type Frame struct {
	xleft, xright, ybot, ytop int
	xmin, xmax, ymin, ymax    float64
	xlog, ylog                bool
	xbase, ybase              float64
}

func (f *Frame) mx(x float64) float64 {
	if f.xlog {
		return float64(f.xleft) + (math.Log(x)-math.Log(f.xmin))/(math.Log(f.xmax)-math.Log(f.xmin))*float64(f.xright-f.xleft)
	}
	return float64(f.xleft) + (x-f.xmin)/(f.xmax-f.xmin)*float64(f.xright-f.xleft)
}
func (f *Frame) my(y float64) float64 {
	if f.ylog {
		return float64(f.ybot) + (math.Log(y)-math.Log(f.ymin))/(math.Log(f.ymax)-math.Log(f.ymin))*float64(f.ytop-f.ybot)
	}
	return float64(f.ybot) + (y-f.ymin)/(f.ymax-f.ymin)*float64(f.ytop-f.ybot)
}
func rnd(v float64) int { return int(math.Floor(v + 0.5)) }

// clip segment in terminal float coords to the box
func clipSeg(x0, y0, x1, y1, xl, xr, yb, yt float64) (float64, float64, float64, float64, bool) {
	code := func(x, y float64) int {
		c := 0
		if x < xl {
			c |= 1
		} else if x > xr {
			c |= 2
		}
		if y < yb {
			c |= 4
		} else if y > yt {
			c |= 8
		}
		return c
	}
	c0, c1 := code(x0, y0), code(x1, y1)
	for k := 0; k < 10; k++ {
		if c0|c1 == 0 {
			return x0, y0, x1, y1, true
		}
		if c0&c1 != 0 {
			return 0, 0, 0, 0, false
		}
		c := c0
		if c == 0 {
			c = c1
		}
		var x, y float64
		switch {
		case c&8 != 0:
			x = x0 + (x1-x0)*(yt-y0)/(y1-y0)
			y = yt
		case c&4 != 0:
			x = x0 + (x1-x0)*(yb-y0)/(y1-y0)
			y = yb
		case c&2 != 0:
			y = y0 + (y1-y0)*(xr-x0)/(x1-x0)
			x = xr
		case c&1 != 0:
			y = y0 + (y1-y0)*(xl-x0)/(x1-x0)
			x = xl
		}
		if c == c0 {
			x0, y0 = x, y
			c0 = code(x0, y0)
		} else {
			x1, y1 = x, y
			c1 = code(x1, y1)
		}
	}
	return 0, 0, 0, 0, false
}

func computeRanges(curves []*Curve) (float64, float64, float64, float64, float64, float64) {
	xa, ya := axes["x"], axes["y"]
	xmin, xmax := math.Inf(1), math.Inf(-1)
	ymin, ymax := math.Inf(1), math.Inf(-1)
	for _, c := range curves {
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			if !(xa.autoMin && xa.autoMax) {
				lo, hi := math.Min(xa.min, xa.max), math.Max(xa.min, xa.max)
				if !xa.autoMin && pt.x < lo || !xa.autoMax && pt.x > hi {
					continue
				}
			}
			xmin = math.Min(xmin, pt.x)
			xmax = math.Max(xmax, pt.x)
			ymin = math.Min(ymin, pt.y)
			ymax = math.Max(ymax, pt.y)
			switch c.style {
			case "yerrorbars", "yerrorlines", "boxerrorbars":
				if len(pt.ex) >= 2 {
					ymin = math.Min(ymin, pt.ex[0])
					ymax = math.Max(ymax, pt.ex[1])
				}
			case "xyerrorbars", "xyerrorlines":
				if len(pt.ex) >= 4 {
					ymin = math.Min(ymin, pt.ex[2])
					ymax = math.Max(ymax, pt.ex[3])
					xmin = math.Min(xmin, pt.ex[0])
					xmax = math.Max(xmax, pt.ex[1])
				}
			case "impulses":
				ymin = math.Min(ymin, 0)
				ymax = math.Max(ymax, 0)
			}
		}
	}
	if math.IsInf(xmin, 1) {
		xmin, xmax = -10, 10
	}
	if math.IsInf(ymin, 1) {
		ymin, ymax = -10, 10
	}
	if !xa.autoMin {
		xmin = xa.min
	}
	if !xa.autoMax {
		xmax = xa.max
	}
	if !ya.autoMin {
		ymin = ya.min
	}
	if !ya.autoMax {
		ymax = ya.max
	}
	var xs, ys float64
	// boxes autoscale widen x
	xmin, xmax, xs = autoExtend(xmin, xmax, xa, "x")
	ymin, ymax, ys = autoExtend(ymin, ymax, ya, "y")
	return xmin, xmax, ymin, ymax, xs, ys
}

func renderPlot(curves []*Curve) {
	globals["GPVAL_PLOT"] = IntVal(1)
	xa, ya := axes["x"], axes["y"]
	xmin, xmax, ymin, ymax, xstep, ystep := computeRanges(curves)
	if xa.reverse && xa.autoMin && xa.autoMax {
		xmin, xmax = xmax, xmin
	}
	if ya.reverse && ya.autoMin && ya.autoMax {
		ymin, ymax = ymax, ymin
	}
	xa.curMin, xa.curMax = xmin, xmax
	ya.curMin, ya.curMax = ymin, ymax
	if xstep == 0 {
		xstep = quantizeTics(math.Abs(xmax-xmin), 20)
	}
	if ystep == 0 {
		ystep = quantizeTics(math.Abs(ymax-ymin), 20)
	}
	if xa.ticStep > 0 {
		xstep = xa.ticStep
	}
	if ya.ticStep > 0 {
		ystep = ya.ticStep
	}
	switch S.termName {
	case "dumb":
		renderDumb(curves, xmin, xmax, ymin, ymax, xstep, ystep)
	case "svg", "canvas":
		renderDumb(curves, xmin, xmax, ymin, ymax, xstep, ystep)
	default:
	}
}

func renderDumb(curves []*Curve, xmin, xmax, ymin, ymax, xstep, ystep float64) {
	W, H := S.termW, S.termH
	cv := newCanvas(W, H)
	xa, ya := axes["x"], axes["y"]
	ytics := genTics(ymin, ymax, ystep, ya)
	xtics := genTics(xmin, xmax, xstep, xa)
	if !ya.ticsOn {
		ytics = nil
	}
	if !xa.ticsOn {
		xtics = nil
	}
	// layout
	ylw := 0
	for _, t := range ytics {
		if len(t.label) > ylw {
			ylw = len(t.label)
		}
	}
	xleft := ylw + 2
	if ylw == 0 {
		xleft = 2
	}
	if ya.label != "" {
		xleft += len(ya.label) + 1
	}
	xright := W - 4
	ytop := H - 2
	if S.title != "" {
		ytop -= 2
	}
	ybot := 2
	if xtics == nil {
		ybot = 1
	}
	if xa.label != "" {
		ybot++
	}
	fr := &Frame{xleft: xleft, xright: xright, ybot: ybot, ytop: ytop, xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax, xlog: xa.log, ylog: ya.log}
	// tics
	for _, t := range ytics {
		y := rnd(fr.my(t.pos))
		if y < ybot || y > ytop {
			continue
		}
		cv.vector(xleft, y, xleft+2, y, 0)
		if ya.mirror {
			cv.vector(xright, y, xright-2, y, 0)
		}
		lbl := t.label
		cv.text(xleft-1-len(lbl), y, lbl)
	}
	for _, t := range xtics {
		x := rnd(fr.mx(t.pos))
		if x < xleft || x > xright {
			continue
		}
		cv.vector(x, ybot, x, ybot+1, 0)
		if xa.mirror {
			cv.vector(x, ytop, x, ytop-1, 0)
		}
		lbl := t.label
		cv.text(x-len(lbl)/2, ybot-1, lbl)
	}
	// labels
	if S.title != "" {
		cx := (xleft + xright) / 2
		cv.text(cx-len(S.title)/2, ytop+1, S.title)
	}
	if xa.label != "" {
		cx := (xleft + xright) / 2
		cv.text(cx-len(xa.label)/2, ybot-2, xa.label)
	}
	if ya.label != "" {
		cv.text(1, (ytop+ybot)/2, ya.label)
	}
	// key
	var keyEntries []*Curve
	for _, c := range curves {
		if c.spec.notitle || c.title == "" {
			continue
		}
		keyEntries = append(keyEntries, c)
	}
	tw := 0
	for _, c := range keyEntries {
		if len(c.title) > tw {
			tw = len(c.title)
		}
	}
	n := len(keyEntries)
	keyRow := map[*Curve]int{}
	for i, c := range keyEntries {
		var y int
		if S.keyVPos == "bottom" {
			y = ybot + n - i
		} else if S.keyVPos == "center" {
			y = (ytop+ybot)/2 + n/2 - i
		} else {
			y = ytop - 2 - i
		}
		keyRow[c] = y
	}
	var sampleX0, textX int
	if S.keyHPos == "left" {
		textX = xleft + 1
		sampleX0 = textX + tw + 1
	} else {
		sampleX0 = xright - 8
		textX = sampleX0 - 1 - tw
	}
	for ci, c := range curves {
		lt := ci + 1
		if c.spec.lt > 0 {
			lt = c.spec.lt
		}
		pen := lineChars[(lt-1)%len(lineChars)]
		pt := ci + 1
		if c.spec.pt > 0 {
			pt = c.spec.pt
		}
		if y, ok := keyRow[c]; ok && S.keyOn {
			cv.text(textX+tw-len(c.title), y, c.title)
			switch c.style {
			case "points":
				cv.set(sampleX0+3, y, pointChar(pt))
			case "linespoints":
				cv.vector(sampleX0, y, sampleX0+6, y, pen)
				cv.set(sampleX0+3, y, pointChar(pt))
			case "dots":
				cv.set(sampleX0+3, y, '.')
			default:
				cv.vector(sampleX0, y, sampleX0+6, y, pen)
			}
		}
		drawCurve(cv, fr, c, pen, pointChar(pt))
	}
	// border
	if S.border&15 != 0 {
		cv.vector(xleft, ybot, xright, ybot, 0)
		cv.vector(xright, ybot, xright, ytop, 0)
		cv.vector(xright, ytop, xleft, ytop, 0)
		cv.vector(xleft, ytop, xleft, ybot, 0)
	}
	out := cv.String()
	if S.termFeed {
		out = "\f" + out
	}
	termWrite(out)
}

func drawCurve(cv *Canvas, fr *Frame, c *Curve, pen byte, pch byte) {
	xl, xr, yb, yt := float64(fr.xleft), float64(fr.xright), float64(fr.ybot), float64(fr.ytop)
	inside := func(x, y float64) bool {
		return x >= xl-1e-9 && x <= xr+1e-9 && y >= yb-1e-9 && y <= yt+1e-9
	}
	drawLines := func() {
		havePrev := false
		var px, py float64
		for _, pt := range c.points {
			if pt.typ == 'u' {
				continue
			}
			if pt.typ == 'm' || pt.gap {
				havePrev = false
				if pt.typ == 'm' {
					continue
				}
			}
			x, y := fr.mx(pt.x), fr.my(pt.y)
			if havePrev {
				if c.style == "steps" {
					drawSeg(cv, px, py, x, py, xl, xr, yb, yt, pen)
					drawSeg(cv, x, py, x, y, xl, xr, yb, yt, pen)
				} else {
					drawSeg(cv, px, py, x, y, xl, xr, yb, yt, pen)
				}
			}
			px, py = x, y
			havePrev = true
		}
	}
	drawPoints := func(ch byte) {
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			x, y := fr.mx(pt.x), fr.my(pt.y)
			if inside(x, y) {
				cv.set(rnd(x), rnd(y), ch)
			}
		}
	}
	switch c.style {
	case "lines", "steps", "fsteps", "histeps", "filledcurves":
		drawLines()
	case "points":
		drawPoints(pch)
	case "linespoints":
		drawLines()
		drawPoints(pch)
	case "dots":
		drawPoints('.')
	case "impulses":
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			x := fr.mx(pt.x)
			y0 := fr.my(math.Max(fr.ymin, math.Min(0, fr.ymax)))
			if fr.ylog {
				y0 = yb
			}
			drawSeg(cv, x, y0, x, fr.my(pt.y), xl, xr, yb, yt, pen)
		}
	case "yerrorbars", "xerrorbars", "xyerrorbars":
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			x, y := fr.mx(pt.x), fr.my(pt.y)
			if len(pt.ex) >= 2 && c.style == "yerrorbars" {
				drawSeg(cv, x, fr.my(pt.ex[0]), x, fr.my(pt.ex[1]), xl, xr, yb, yt, pen)
			}
			if inside(x, y) {
				cv.set(rnd(x), rnd(y), pch)
			}
		}
	case "boxes":
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			w := 1.0
			if S.boxwidth > 0 {
				w = S.boxwidth
			}
			x0, x1 := fr.mx(pt.x-w/2), fr.mx(pt.x+w/2)
			y0 := fr.my(math.Max(fr.ymin, math.Min(0, fr.ymax)))
			y1 := fr.my(pt.y)
			drawSeg(cv, x0, y0, x0, y1, xl, xr, yb, yt, pen)
			drawSeg(cv, x0, y1, x1, y1, xl, xr, yb, yt, pen)
			drawSeg(cv, x1, y1, x1, y0, xl, xr, yb, yt, pen)
		}
	case "labels":
		for _, pt := range c.points {
			if pt.typ == 'u' || pt.typ == 'm' {
				continue
			}
			x, y := fr.mx(pt.x), fr.my(pt.y)
			if inside(x, y) {
				cv.text(rnd(x)-len(pt.label)/2, rnd(y), pt.label)
			}
		}
	default:
		drawLines()
	}
}

func drawSeg(cv *Canvas, x0, y0, x1, y1, xl, xr, yb, yt float64, pen byte) {
	a, b, c, d, ok := clipSeg(x0, y0, x1, y1, xl, xr, yb, yt)
	if !ok {
		return
	}
	cv.vector(rnd(a), rnd(b), rnd(c), rnd(d), pen)
}
