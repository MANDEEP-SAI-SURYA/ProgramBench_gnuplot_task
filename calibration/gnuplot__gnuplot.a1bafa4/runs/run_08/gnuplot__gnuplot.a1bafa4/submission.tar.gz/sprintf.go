package main

import (
	"fmt"
	"math"
	"strings"
)

// cfmt formats one value with a C-style format spec (single conversion).
func cfmt(spec string, arg interface{}) string {
	// spec like %[flags][width][.prec]conv
	conv := spec[len(spec)-1]
	switch a := arg.(type) {
	case float64:
		if math.IsInf(a, 0) || math.IsNaN(a) {
			var s string
			if math.IsNaN(a) {
				s = "nan"
				if math.Signbit(a) {
					s = "-nan"
				}
			} else if a > 0 {
				s = "inf"
			} else {
				s = "-inf"
			}
			if conv >= 'A' && conv <= 'Z' {
				s = strings.ToUpper(s)
			}
			flags, width, _, _ := parseSpec(spec)
			if s[0] != '-' {
				if strings.Contains(flags, "+") {
					s = "+" + s
				} else if strings.Contains(flags, " ") {
					s = " " + s
				}
			}
			for len(s) < width {
				if strings.Contains(flags, "-") {
					s += " "
				} else {
					s = " " + s
				}
			}
			return s
		}
		if conv == 'g' || conv == 'G' {
			// Go's %g differs from C for exponent thresholds when precision given? It matches C.
			flags, width, prec, hasPrec := parseSpec(spec)
			if !hasPrec {
				prec = 6
			}
			if prec == 0 {
				prec = 1
			}
			s := cG(a, prec, strings.Contains(flags, "#"), conv == 'G')
			if a >= 0 && !math.Signbit(a) {
				if strings.Contains(flags, "+") {
					s = "+" + s
				} else if strings.Contains(flags, " ") {
					s = " " + s
				}
			}
			return padNum(s, flags, width)
		}
		return fmt.Sprintf(spec, a)
	case int64:
		return fmt.Sprintf(spec, a)
	case uint64:
		return fmt.Sprintf(spec, a)
	case string:
		return fmt.Sprintf(spec, a)
	}
	return fmt.Sprintf(spec, arg)
}

func padNum(s, flags string, width int) string {
	if len(s) >= width {
		return s
	}
	if strings.Contains(flags, "-") {
		return s + strings.Repeat(" ", width-len(s))
	}
	if strings.Contains(flags, "0") {
		sign := ""
		if len(s) > 0 && (s[0] == '-' || s[0] == '+' || s[0] == ' ') {
			sign = s[:1]
			s = s[1:]
		}
		return sign + strings.Repeat("0", width-len(s)-len(sign)) + s
	}
	return strings.Repeat(" ", width-len(s)) + s
}

// cG implements C's %g
func cG(a float64, prec int, alt bool, upper bool) string {
	if a == 0 {
		s := "0"
		if math.Signbit(a) {
			s = "-0"
		}
		if alt && prec > 1 {
			s += "." + strings.Repeat("0", prec-1)
		}
		return s
	}
	es := fmt.Sprintf("%.*e", prec-1, a)
	// get exponent
	ei := strings.LastIndexAny(es, "e")
	var x int
	fmt.Sscanf(es[ei+1:], "%d", &x)
	var s string
	if x < -4 || x >= prec {
		mant := es[:ei]
		if !alt && strings.Contains(mant, ".") {
			mant = strings.TrimRight(mant, "0")
			mant = strings.TrimSuffix(mant, ".")
		}
		exp := es[ei:]
		s = mant + exp
	} else {
		s = fmt.Sprintf("%.*f", prec-1-x, a)
		if !alt && strings.Contains(s, ".") {
			s = strings.TrimRight(s, "0")
			s = strings.TrimSuffix(s, ".")
		}
	}
	if upper {
		s = strings.ToUpper(s)
	}
	return s
}

func parseSpec(spec string) (flags string, width int, prec int, hasPrec bool) {
	i := 1
	for i < len(spec) && strings.IndexByte("-+ #0'", spec[i]) >= 0 {
		flags += spec[i : i+1]
		i++
	}
	for i < len(spec) && isDigit(spec[i]) {
		width = width*10 + int(spec[i]-'0')
		i++
	}
	if i < len(spec) && spec[i] == '.' {
		hasPrec = true
		i++
		for i < len(spec) && isDigit(spec[i]) {
			prec = prec*10 + int(spec[i]-'0')
			i++
		}
	}
	return
}

// scan a conversion spec starting at fmt[i]=='%'; returns spec end index (exclusive) and conv char
func scanSpec(f string, i int) (int, byte) {
	j := i + 1
	for j < len(f) && strings.IndexByte("-+ #0'", f[j]) >= 0 {
		j++
	}
	for j < len(f) && isDigit(f[j]) {
		j++
	}
	if j < len(f) && f[j] == '.' {
		j++
		for j < len(f) && isDigit(f[j]) {
			j++
		}
	}
	if j < len(f) {
		return j + 1, f[j]
	}
	return j, 0
}

func formatIntConv(spec string, conv byte, v Value) string {
	var iv int64
	if v.T == VInt {
		iv = v.I
	} else {
		f := v.Real()
		if math.IsNaN(f) || math.IsInf(f, 0) || f >= 9.3e18 || f <= -9.3e18 {
			iv = math.MinInt64
		} else {
			iv = int64(f)
		}
	}
	switch conv {
	case 'd', 'i':
		return cfmt(spec[:len(spec)-1]+"d", iv)
	case 'x', 'X', 'o':
		var u uint64
		if iv >= math.MinInt32 && iv <= math.MaxInt32 {
			u = uint64(uint32(int32(iv)))
		} else {
			u = uint64(iv)
		}
		flags, _, _, _ := parseSpec(spec)
		if strings.Contains(flags, "#") && conv == 'o' {
			// Go's %#o prints leading 0 like C
		}
		return cfmt(spec, u)
	case 'c':
		return string(rune(byte(iv)))
	}
	return ""
}

func gpSprintf(f string, args []Value) string {
	var sb strings.Builder
	ai := 0
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' {
			sb.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		end, conv := scanSpec(f, i)
		spec := f[i:end]
		if ai >= len(args) {
			// no more args: copy rest verbatim
			sb.WriteString(f[i:])
			break
		}
		a := args[ai]
		ai++
		switch conv {
		case 'd', 'i', 'x', 'X', 'o', 'c':
			if a.T == VStr {
				gpErr(-1, "f_sprintf: attempt to print string value with numeric format")
			}
			sb.WriteString(formatIntConv(spec, conv, a))
		case 'e', 'E', 'f', 'F', 'g', 'G', 'a', 'A':
			if a.T == VStr {
				gpErr(-1, "f_sprintf: attempt to print string value with numeric format")
			}
			sp := spec
			if conv == 'F' {
				sp = spec[:len(spec)-1] + "f"
			}
			sb.WriteString(cfmt(sp, a.Real()))
		case 's':
			if a.T != VStr {
				gpErr(-1, "f_sprintf: attempt to print numeric value with string format")
			}
			sb.WriteString(cfmt(spec, a.S))
		default:
			gpErr(-1, "f_sprintf: unsupported or invalid format specifier")
		}
		i = end
	}
	return sb.String()
}

var siPrefixes = "yzafpnum kMGTPEZY"

// gprintf implements gnuplot's format for axis tics and gprintf()
func gprintf(f string, x float64) string {
	return gprintfBase(f, x, 10)
}

func gprintfBase(f string, x float64, logbase float64) string {
	var sb strings.Builder
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' {
			sb.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		end, conv := scanSpec(f, i)
		spec := f[i:end]
		base := spec[:len(spec)-1]
		switch conv {
		case 'c':
			_, e3 := mantExp3(x)
			k := e3/3 + 8
			if k >= 0 && k < len(siPrefixes) {
				if siPrefixes[k] != ' ' {
					sb.WriteByte(siPrefixes[k])
				}
			}
		case 'd', 'i', 'x', 'X', 'o':
			sb.WriteString(formatIntConv(spec, conv, FloatVal(x)))
		case 'e', 'E', 'f', 'F', 'g', 'G':
			sp := spec
			if conv == 'F' {
				sp = base + "f"
			}
			sb.WriteString(cfmt(sp, x))
		case 'h', 'H':
			sb.WriteString(cfmt(base+string(conv-'h'+'g'), x))
		case 't', 'T', 's', 'S', 'c' + 100:
		case 'l', 'L':
		case 'P':
			sb.WriteString(cfmt(base+"f", x/math.Pi))
		}
		switch conv {
		case 't':
			m, _ := mantExp(x, 10)
			sb.WriteString(cfmt(base+"f", m))
		case 'T':
			_, e := mantExp(x, 10)
			sb.WriteString(cfmt(base+"d", int64(e)))
		case 'l':
			m, _ := mantExp(x, logbase)
			sb.WriteString(cfmt(base+"f", m))
		case 'L':
			_, e := mantExp(x, logbase)
			sb.WriteString(cfmt(base+"d", int64(e)))
		case 's':
			m, _ := mantExp3(x)
			sb.WriteString(cfmt(base+"f", m))
		case 'S':
			_, e := mantExp3(x)
			sb.WriteString(cfmt(base+"d", int64(e)))
		}
		if conv == 'c' && false {
		}
		i = end
		// %c after %s: SI prefix
		_ = siPrefixes
	}
	return sb.String()
}

func mantExp(x float64, base float64) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	e := int(math.Floor(math.Log(ax) / math.Log(base)))
	m := x / math.Pow(base, float64(e))
	if math.Abs(m) >= base*(1-1e-12) {
		m /= base
		e++
	}
	return m, e
}

func mantExp3(x float64) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	e := int(math.Floor(math.Log10(math.Abs(x))))
	e3 := e
	if e3 < 0 {
		e3 = -((-e3 + 2) / 3) * 3
	} else {
		e3 = (e3 / 3) * 3
	}
	return x / math.Pow(10, float64(e3)), e3
}
