package main

import (
	"math"
	"strconv"
	"strings"
)

const (
	VUndef = iota
	VInt
	VCmplx
	VStr
	VArr
)

type Value struct {
	T   int
	I   int64
	R   float64
	Im  float64
	S   string
	Arr *[]Value
}

func IntVal(i int64) Value           { return Value{T: VInt, I: i} }
func FloatVal(f float64) Value       { return Value{T: VCmplx, R: f} }
func CmplxVal(r, i float64) Value    { return Value{T: VCmplx, R: r, Im: i} }
func StrVal(s string) Value          { return Value{T: VStr, S: s} }
func (v Value) IsNum() bool          { return v.T == VInt || v.T == VCmplx }
func boolVal(b bool) Value {
	if b {
		return IntVal(1)
	}
	return IntVal(0)
}

// Real returns the real part (converting strings like gnuplot does).
func (v Value) Real() float64 {
	switch v.T {
	case VInt:
		return float64(v.I)
	case VCmplx:
		return v.R
	case VStr:
		f, ok := strToNum(v.S)
		if !ok {
			gpErr(-1, "Non-numeric string found where a numeric expression was expected")
		}
		return f.Real()
	case VUndef:
		return 0
	}
	gpErr(-1, "Non-numeric string found where a numeric expression was expected")
	return 0
}

func (v Value) Imag() float64 {
	if v.T == VCmplx {
		return v.Im
	}
	return 0
}

// numeric coerces a value to a number (string -> number)
func numeric(v Value) Value {
	switch v.T {
	case VInt, VCmplx:
		return v
	case VStr:
		f, ok := strToNum(v.S)
		if !ok {
			gpErr(-1, "Non-numeric string found where a numeric expression was expected")
		}
		return f
	case VArr:
		gpErr(-1, "Non-numeric string found where a numeric expression was expected")
	}
	return v
}

func strToNum(s string) (Value, bool) {
	t := strings.TrimLeft(s, " \t\n")
	// parse leading number like strtod
	j := 0
	n := len(t)
	if j < n && (t[j] == '+' || t[j] == '-') {
		j++
	}
	st := j
	isf := false
	for j < n && isDigit(t[j]) {
		j++
	}
	if j < n && t[j] == '.' {
		isf = true
		j++
		for j < n && isDigit(t[j]) {
			j++
		}
	}
	if j == st || (j == st+1 && isf) {
		// maybe inf/nan
		low := strings.ToLower(t[st:])
		if strings.HasPrefix(low, "inf") {
			if st > 0 && t[0] == '-' {
				return FloatVal(math.Inf(-1)), true
			}
			return FloatVal(math.Inf(1)), true
		}
		if strings.HasPrefix(low, "nan") {
			return FloatVal(math.NaN()), true
		}
		return Value{}, false
	}
	if j < n && (t[j] == 'e' || t[j] == 'E') {
		k := j + 1
		if k < n && (t[k] == '+' || t[k] == '-') {
			k++
		}
		if k < n && isDigit(t[k]) {
			for k < n && isDigit(t[k]) {
				k++
			}
			isf = true
			j = k
		}
	}
	if !isf {
		if iv, err := strconv.ParseInt(t[:j], 10, 64); err == nil {
			return IntVal(iv), true
		}
	}
	f, _ := strconv.ParseFloat(t[:j], 64)
	return FloatVal(f), true
}

func fmtG15(f float64) string {
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	if math.IsNaN(f) {
		return "nan"
	}
	return cfmt("%.15g", f)
}

func numStr(f float64) string {
	s := fmtG15(f)
	if !strings.ContainsAny(s, ".e") || s == "inf" || s == "-inf" || s == "nan" {
		s += ".0"
	}
	return s
}

// String used by print
func (v Value) PrintStr() string {
	switch v.T {
	case VInt:
		return strconv.FormatInt(v.I, 10)
	case VCmplx:
		if v.Im != 0 {
			return "{" + numStr(v.R) + ", " + numStr(v.Im) + "}"
		}
		return numStr(v.R)
	case VStr:
		return v.S
	case VArr:
		var sb strings.Builder
		sb.WriteByte('[')
		for i, e := range (*v.Arr)[1:] {
			if i > 0 {
				sb.WriteByte(',')
			}
			if e.T == VStr {
				sb.WriteString("\"" + e.S + "\"")
			} else if e.T != VUndef {
				sb.WriteString(e.PrintStr())
			}
		}
		sb.WriteByte(']')
		return sb.String()
	}
	return "<undefined>"
}

func typeName(v Value) string {
	switch v.T {
	case VInt:
		return "integer"
	case VCmplx:
		if v.Im != 0 {
			return "complex"
		}
		return "real"
	case VStr:
		return "string"
	case VArr:
		return "array"
	}
	return "undefined"
}
