package main

import (
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strings"
	"time"
)

func cplx(v Value) complex128 {
	v = numeric(v)
	return complex(v.Real(), v.Imag())
}
func fromC(c complex128) Value { return CmplxVal(real(c), imag(c)) }

func realArg(v Value, fname string) float64 {
	v = numeric(v)
	if v.T == VCmplx && v.Im != 0 {
		return v.R
	}
	return v.Real()
}

var randState [2]int64 = [2]int64{1234567890, 1234567890}

func gpRand(seed Value) float64 {
	// L'Ecuyer combined generator
	s := intOf(seed)
	if s < 0 {
		randState = [2]int64{1234567890, 1234567890}
	}
	if s > 0 {
		randState = [2]int64{s, s}
	}
	const m1, m2 = 2147483563, 2147483399
	const a1, a2 = 40014, 40692
	const q1, q2 = 53668, 52774
	const r1, r2 = 12211, 3791
	k := randState[0] / q1
	randState[0] = a1*(randState[0]-k*q1) - k*r1
	if randState[0] < 0 {
		randState[0] += m1
	}
	k = randState[1] / q2
	randState[1] = a2*(randState[1]-k*q2) - k*r2
	if randState[1] < 0 {
		randState[1] += m2
	}
	z := randState[0] - randState[1]
	if z < 1 {
		z += m1 - 1
	}
	return float64(z) * 4.656613057e-10
}

func besI0(x float64) float64 {
	ax := math.Abs(x)
	if ax < 3.75 {
		y := x / 3.75
		y *= y
		return 1.0 + y*(3.5156229+y*(3.0899424+y*(1.2067492+y*(0.2659732+y*(0.360768e-1+y*0.45813e-2)))))
	}
	y := 3.75 / ax
	return (math.Exp(ax) / math.Sqrt(ax)) * (0.39894228 + y*(0.1328592e-1+y*(0.225319e-2+y*(-0.157565e-2+y*(0.916281e-2+y*(-0.2057706e-1+y*(0.2635537e-1+y*(-0.1647633e-1+y*0.392377e-2))))))))
}
func besI1(x float64) float64 {
	ax := math.Abs(x)
	var ans float64
	if ax < 3.75 {
		y := x / 3.75
		y *= y
		ans = ax * (0.5 + y*(0.87890594+y*(0.51498869+y*(0.15084934+y*(0.2658733e-1+y*(0.301532e-2+y*0.32411e-3))))))
	} else {
		y := 3.75 / ax
		ans = 0.2282967e-1 + y*(-0.2895312e-1+y*(0.1787654e-1-y*0.420059e-2))
		ans = 0.39894228 + y*(-0.3988024e-1+y*(-0.362018e-2+y*(0.163801e-2+y*(-0.1031555e-1+y*ans))))
		ans *= math.Exp(ax) / math.Sqrt(ax)
	}
	if x < 0 {
		return -ans
	}
	return ans
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		return 0
	}
	if x < a+1 {
		ap := a
		sum := 1.0 / a
		del := sum
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		lg, _ := math.Lgamma(a)
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	lg, _ := math.Lgamma(a)
	b := x + 1 - a
	c := 1.0 / 1e-300
	d := 1.0 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	la, _ := math.Lgamma(a)
	lb, _ := math.Lgamma(b)
	lab, _ := math.Lgamma(a + b)
	bt := math.Exp(lab - la - lb + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1e-300)
		if w < 0 {
			w = 0.5
		}
	} else {
		w = x
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func needArgs(args []Value, n int) {
	if len(args) < n {
		gpErr(-1, "stack underflow (function call with missing parameters?)")
	}
}

type builtin func(args []Value) Value

func real1(f func(float64) float64) builtin {
	return func(a []Value) Value {
		needArgs(a, 1)
		if a[0].T == VUndef {
			return a[0]
		}
		return finite(FloatVal(f(numeric(a[0]).Real())))
	}
}

func finite(v Value) Value {
	if math.IsInf(v.R, 0) || math.IsNaN(v.R) || math.IsInf(v.Im, 0) || math.IsNaN(v.Im) {
		return Value{}
	}
	return v
}

func angIn(name string, x float64) float64 { return x }

func angF() float64 {
	if S.angleDeg {
		return math.Pi / 180
	}
	return 1
}

func cplx1(fr func(float64) float64, fc func(complex128) complex128, domainOK func(float64) bool) builtin {
	name := ""
	return func(a []Value) Value {
		needArgs(a, 1)
		v := numeric(a[0])
		if v.T == VInt || v.Im == 0 {
			x := v.Real()
			if domainOK == nil || domainOK(x) {
				return finite(FloatVal(fr(angIn(name, x))))
			}
		}
		return finite(fromC(fc(complex(v.Real(), v.Imag()))))
	}
}

var builtins map[string]builtin

func init() {
	builtins = map[string]builtin{
		"abs": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			if v.T == VInt {
				if v.I < 0 {
					return IntVal(-v.I)
				}
				return v
			}
			if v.Im != 0 {
				return FloatVal(math.Hypot(v.R, v.Im))
			}
			return FloatVal(math.Abs(v.R))
		},
		"sgn": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			x := v.Real()
			if x > 0 {
				return IntVal(1)
			} else if x < 0 {
				return IntVal(-1)
			}
			return IntVal(0)
		},
		"int": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			if v.T == VInt {
				return v
			}
			if math.IsNaN(v.R) || math.IsInf(v.R, 0) {
				return Value{}
			}
			return IntVal(int64(v.R))
		},
		"floor": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			if v.T == VInt {
				return v
			}
			return IntVal(int64(math.Floor(v.R)))
		},
		"ceil": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			if v.T == VInt {
				return v
			}
			return IntVal(int64(math.Ceil(v.R)))
		},
		"real": func(a []Value) Value { needArgs(a, 1); v := numeric(a[0]); return FloatVal(v.Real()) },
		"imag": func(a []Value) Value { needArgs(a, 1); v := numeric(a[0]); return FloatVal(v.Imag()) },
		"arg": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			return FloatVal(math.Atan2(v.Imag(), v.Real()))
		},
		"conj": func(a []Value) Value {
			needArgs(a, 1)
			v := numeric(a[0])
			if v.T == VInt {
				return v
			}
			return CmplxVal(v.R, -v.Im)
		},
		"sqrt": cplx1(math.Sqrt, cmplx.Sqrt, func(x float64) bool { return x >= 0 }),
		"exp":  cplx1(math.Exp, cmplx.Exp, nil),
		"log":  cplx1(math.Log, cmplx.Log, func(x float64) bool { return x >= 0 }),
		"log10": cplx1(math.Log10, cmplx.Log10, func(x float64) bool { return x >= 0 }),
		"sin":  cplx1(func(x float64) float64 { return math.Sin(x * angF()) }, cmplx.Sin, nil),
		"cos":  cplx1(func(x float64) float64 { return math.Cos(x * angF()) }, cmplx.Cos, nil),
		"tan":  cplx1(func(x float64) float64 { return math.Tan(x * angF()) }, cmplx.Tan, nil),
		"asin": cplx1(func(x float64) float64 { return math.Asin(x) / angF() }, cmplx.Asin, func(x float64) bool { return x >= -1 && x <= 1 }),
		"acos": cplx1(func(x float64) float64 { return math.Acos(x) / angF() }, cmplx.Acos, func(x float64) bool { return x >= -1 && x <= 1 }),
		"atan": cplx1(func(x float64) float64 { return math.Atan(x) / angF() }, cmplx.Atan, nil),
		"sinh": cplx1(math.Sinh, cmplx.Sinh, nil),
		"cosh": cplx1(math.Cosh, cmplx.Cosh, nil),
		"tanh": cplx1(math.Tanh, cmplx.Tanh, nil),
		"asinh": cplx1(math.Asinh, cmplx.Asinh, nil),
		"acosh": cplx1(math.Acosh, cmplx.Acosh, func(x float64) bool { return x >= 1 }),
		"atanh": cplx1(math.Atanh, cmplx.Atanh, func(x float64) bool { return x > -1 && x < 1 }),
		"atan2": func(a []Value) Value {
			needArgs(a, 2)
			return FloatVal(math.Atan2(numeric(a[0]).Real(), numeric(a[1]).Real()) / angF())
		},
		"erf":   real1(math.Erf),
		"erfc":  real1(math.Erfc),
		"inverf": real1(math.Erfinv),
		"gamma": real1(math.Gamma),
		"lgamma": real1(func(x float64) float64 { l, _ := math.Lgamma(x); return l }),
		"besj0": real1(math.J0),
		"besj1": real1(math.J1),
		"besy0": real1(math.Y0),
		"besy1": real1(math.Y1),
		"besi0": real1(besI0),
		"besi1": real1(besI1),
		"norm":  real1(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": real1(func(x float64) float64 { return -math.Sqrt2 * math.Erfcinv(2*x) }),
		"lambertw": real1(lambertw),
		"rand": func(a []Value) Value { needArgs(a, 1); return FloatVal(gpRand(a[0])) },
		"igamma": func(a []Value) Value {
			needArgs(a, 2)
			return FloatVal(igamma(numeric(a[0]).Real(), numeric(a[1]).Real()))
		},
		"ibeta": func(a []Value) Value {
			needArgs(a, 3)
			return FloatVal(ibeta(numeric(a[0]).Real(), numeric(a[1]).Real(), numeric(a[2]).Real()))
		},
		"strlen": func(a []Value) Value {
			needArgs(a, 1)
			if a[0].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return IntVal(int64(len([]rune(a[0].S))))
		},
		"substr": func(a []Value) Value {
			needArgs(a, 3)
			if a[0].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return StrVal(substr(a[0].S, intOf(a[1]), intOf(a[2])))
		},
		"strstrt": func(a []Value) Value {
			needArgs(a, 2)
			if a[0].T != VStr || a[1].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return IntVal(int64(strings.Index(a[0].S, a[1].S) + 1))
		},
		"words": func(a []Value) Value {
			needArgs(a, 1)
			if a[0].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return IntVal(int64(len(splitWords(a[0].S))))
		},
		"word": func(a []Value) Value {
			needArgs(a, 2)
			if a[0].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			w := splitWords(a[0].S)
			i := intOf(a[1])
			if i < 1 || i > int64(len(w)) {
				return StrVal("")
			}
			return StrVal(w[i-1])
		},
		"trim": func(a []Value) Value {
			needArgs(a, 1)
			if a[0].T != VStr {
				gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return StrVal(strings.Trim(a[0].S, " \t\n\r\f\v"))
		},
		"sprintf": func(a []Value) Value {
			needArgs(a, 1)
			if a[0].T != VStr {
				gpErr(-1, "First parameter to sprintf must be a format string")
			}
			return StrVal(gpSprintf(a[0].S, a[1:]))
		},
		"gprintf": func(a []Value) Value {
			needArgs(a, 2)
			if a[0].T != VStr {
				gpErr(-1, "First parameter to gprintf must be a format string")
			}
			return StrVal(gprintf(a[0].S, numeric(a[1]).Real()))
		},
		"strftime": func(a []Value) Value {
			needArgs(a, 2)
			if a[0].T != VStr {
				gpErr(-1, "First parameter to strftime must be a format string")
			}
			return StrVal(gpStrftime(a[0].S, numeric(a[1]).Real()))
		},
		"strptime": func(a []Value) Value {
			needArgs(a, 2)
			t, ok := gpStrptime(a[0].S, a[1].S)
			if !ok {
				return Value{}
			}
			return FloatVal(t)
		},
		"time": func(a []Value) Value {
			now := time.Now()
			if len(a) > 0 && a[0].T == VStr {
				return StrVal(gpStrftime(a[0].S, float64(now.Unix())))
			}
			if len(a) > 0 && a[0].T == VCmplx {
				return FloatVal(float64(now.UnixNano()) / 1e9)
			}
			return IntVal(now.Unix())
		},
		"system": func(a []Value) Value {
			needArgs(a, 1)
			out, _ := exec.Command("/bin/sh", "-c", a[0].S).Output()
			s := string(out)
			s = strings.TrimSuffix(s, "\n")
			return StrVal(s)
		},
		"exists": func(a []Value) Value {
			needArgs(a, 1)
			_, ok := globals[a[0].S]
			return boolVal(ok)
		},
		"value": func(a []Value) Value {
			needArgs(a, 1)
			v, ok := globals[a[0].S]
			if !ok {
				return Value{}
			}
			return v
		},
		"valid": func(a []Value) Value {
			needArgs(a, 1)
			return validHook(a[0])
		},
		"column":       func(a []Value) Value { needArgs(a, 1); return columnFunc(a[0]) },
		"stringcolumn": func(a []Value) Value { needArgs(a, 1); return strcolFunc(a[0]) },
		"strcol":       func(a []Value) Value { needArgs(a, 1); return strcolFunc(a[0]) },
		"columnhead":   func(a []Value) Value { needArgs(a, 1); return colheadFunc(a[0]) },
		"columnheader": func(a []Value) Value { needArgs(a, 1); return colheadFunc(a[0]) },
		"timecolumn": func(a []Value) Value {
			needArgs(a, 1)
			return timecolFunc(a)
		},
		"tm_sec":  tmPart(func(t time.Time) int64 { return int64(t.Second()) }),
		"tm_min":  tmPart(func(t time.Time) int64 { return int64(t.Minute()) }),
		"tm_hour": tmPart(func(t time.Time) int64 { return int64(t.Hour()) }),
		"tm_mday": tmPart(func(t time.Time) int64 { return int64(t.Day()) }),
		"tm_mon":  tmPart(func(t time.Time) int64 { return int64(t.Month()) - 1 }),
		"tm_year": tmPart(func(t time.Time) int64 { return int64(t.Year()) }),
		"tm_wday": tmPart(func(t time.Time) int64 { return int64(t.Weekday()) }),
		"tm_yday": tmPart(func(t time.Time) int64 { return int64(t.YearDay()) - 1 }),
		"voigt": func(a []Value) Value {
			needArgs(a, 2)
			return FloatVal(voigt(numeric(a[0]).Real(), numeric(a[1]).Real()))
		},
		"expint": func(a []Value) Value {
			needArgs(a, 2)
			return FloatVal(expint(int(intOf(a[0])), numeric(a[1]).Real()))
		},
	}
	_ = os.Stdout
}

func tmPart(f func(time.Time) int64) builtin {
	return func(a []Value) Value {
		needArgs(a, 1)
		x := numeric(a[0]).Real()
		sec := math.Floor(x)
		t := time.Unix(int64(sec), 0).UTC()
		return FloatVal(float64(f(t)))
	}
}

func voigt(x, y float64) float64 {
	// numerical integration of Faddeeva real part
	if y <= 0 {
		return math.Exp(-x*x) / math.Sqrt(math.Pi)
	}
	n := 2000
	L := 30.0 + math.Abs(x)
	h := 2 * L / float64(n)
	s := 0.0
	for i := 0; i <= n; i++ {
		t := -L + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		s += w * math.Exp(-t*t) / (y*y + (x-t)*(x-t))
	}
	return s * h * y / (math.Pi * math.Sqrt(math.Pi))
}

func expint(n int, x float64) float64 {
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 1000; i++ {
			an := -float64(i) * float64(n-1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	nm1 := n - 1
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 1000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

func splitWords(s string) []string {
	// gnuplot words: whitespace separated, with quoted strings
	var out []string
	i := 0
	for i < len(s) {
		for i < len(s) && strings.IndexByte(" \t\n\r", s[i]) >= 0 {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]
			j := i + 1
			for j < len(s) && s[j] != q {
				j++
			}
			out = append(out, s[i+1:j])
			i = j + 1
			continue
		}
		j := i
		for j < len(s) && strings.IndexByte(" \t\n\r", s[j]) < 0 {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

func (p *Parser) makeCall(name string, args []Expr, pos int) Expr {
	if f, ok := builtins[name]; ok {
		return func() Value {
			vals := make([]Value, len(args))
			for i, a := range args {
				vals[i] = a()
			}
			return f(vals)
		}
	}
	return func() Value {
		u, ok := udfs[name]
		if !ok {
			gpErr(-1, "undefined function: "+name)
		}
		if len(u.Params) != len(args) {
			if len(u.Params) == 1 {
				gpErr(-1, "function "+name+" requires 1 variable")
			}
			gpErr(-1, "function "+name+" requires "+itoa(len(u.Params))+" variables")
		}
		fr := map[string]Value{}
		for i, a := range args {
			fr[u.Params[i]] = a()
		}
		frames = append(frames, fr)
		defer func() { frames = frames[:len(frames)-1] }()
		return u.Body()
	}
}

func itoa(i int) string {
	return IntVal(int64(i)).PrintStr()
}
