package main

import (
	"os"
	"strings"
)

var outFile *os.File

func termWrite(s string) {
	if outFile != nil {
		outFile.WriteString(s)
		return
	}
	stdout.WriteString(s)
}

func setOutput(fn string) {
	if outFile != nil {
		outFile.Close()
		outFile = nil
	}
	S.output = fn
	keepTerm.output = fn
	if fn != "" {
		f, err := os.Create(fn)
		if err != nil {
			gpErr(-1, "cannot open file; output not changed")
		}
		outFile = f
	}
}

func finishOutput() {
	if multiplotActive {
		flushMultiplot()
	}
	if outFile != nil {
		outFile.Close()
	}
}

func termOptions() string { return "" }

func parseTerm(p *Parser) {
	if p.endOfCmd() {
		return
	}
	name := p.next().Text
	switch {
	case almostEq(name, "dumb"):
		S.termName = "dumb"
		S.termW, S.termH = 79, 24
		S.termFeed = true
		for !p.endOfCmd() {
			if p.almost("si$ze") {
				p.next()
				S.termW = int(p.parseNum())
				if p.isOp(",") {
					p.next()
					S.termH = int(p.parseNum())
				}
				continue
			}
			if p.almost("nofeed") {
				S.termFeed = false
			} else if p.almost("feed") {
				S.termFeed = true
			}
			if p.cur().Kind == TNum {
				S.termW = int(p.parseNum())
				if p.isOp(",") {
					p.next()
					S.termH = int(p.parseNum())
				}
				continue
			}
			p.next()
		}
	case almostEq(name, "svg"):
		S.termName = "svg"
		S.termW, S.termH = 640, 480
		parseSizeOpts(p)
	case almostEq(name, "canvas"):
		S.termName = "canvas"
		S.termW, S.termH = 600, 400
		parseSizeOpts(p)
	case almostEq(name, "unknown"):
		S.termName = "unknown"
	case almostEq(name, "push"), almostEq(name, "pop"):
	default:
		if strings.HasPrefix(name, "post") || name == "png" || name == "pngcairo" || name == "pdfcairo" || name == "x11" || name == "qt" || name == "wxt" {
			gpErr(p.toks[p.i-1].Pos, "unknown or ambiguous terminal type; type just 'set terminal' for a list")
		}
		S.termName = name
		skipRest(p)
	}
	keepTerm.name = S.termName
	keepTerm.w, keepTerm.h = S.termW, S.termH
	globals["GPVAL_TERM"] = StrVal(S.termName)
}

func parseSizeOpts(p *Parser) {
	for !p.endOfCmd() {
		if p.almost("si$ze") {
			p.next()
			S.termW = int(p.parseNum())
			if p.isOp(",") {
				p.next()
				S.termH = int(p.parseNum())
			}
			continue
		}
		p.next()
	}
}

func termClear() {}
