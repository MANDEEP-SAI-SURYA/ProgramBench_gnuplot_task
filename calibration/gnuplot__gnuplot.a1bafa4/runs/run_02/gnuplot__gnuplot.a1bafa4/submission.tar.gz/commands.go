package main

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

type ctrl int

const (
	cNone ctrl = iota
	cBreak
	cContinue
)

type Exec struct {
	Parser
}

var printOut *os.File
var printBuf strings.Builder
var printFileName string

func flushPrint() {
	if printBuf.Len() > 0 {
		if printOut != nil {
			printOut.WriteString(printBuf.String())
		}
		printBuf.Reset()
	}
}

func printWrite(s string) {
	if printOut == nil {
		if printToStdout {
			stdout.WriteString(s)
			return
		}
		stdout.Flush()
		os.Stderr.WriteString(s)
		return
	}
	printOut.WriteString(s)
}

var printToStdout bool

func closeOutputs() {
	if printOut != nil {
		printOut.Close()
		printOut = nil
	}
	closeTermOutput()
}

func macroExpand(l string) string {
	if !strings.Contains(l, "@") && !strings.Contains(l, "`") {
		return l
	}
	var sb strings.Builder
	inS, inD := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inD {
			sb.WriteByte(c)
			if c == '\\' && i+1 < len(l) {
				i++
				sb.WriteByte(l[i])
			} else if c == '"' {
				inD = false
			}
			continue
		}
		if inS {
			sb.WriteByte(c)
			if c == '\'' {
				inS = false
			}
			continue
		}
		switch c {
		case '"':
			inD = true
			sb.WriteByte(c)
		case '\'':
			inS = true
			sb.WriteByte(c)
		case '#':
			sb.WriteString(l[i:])
			return sb.String()
		case '`':
			j := strings.IndexByte(l[i+1:], '`')
			if j < 0 {
				sb.WriteString(l[i:])
				return sb.String()
			}
			cmd := l[i+1 : i+1+j]
			out := runSystem(cmd)
			out = strings.TrimSuffix(out, "\n")
			sb.WriteString(out)
			i += j + 1
		case '@':
			j := i + 1
			for j < len(l) && isAlnum(l[j]) {
				j++
			}
			name := l[i+1 : j]
			if name == "" {
				sb.WriteByte(c)
				continue
			}
			v, ok := globals[name]
			if !ok || v.K != KStr {
				gpErrNC("macro substitution: '" + name + "' is not a string variable")
			}
			sb.WriteString(v.S)
			i = j - 1
		default:
			sb.WriteByte(c)
		}
	}
	return sb.String()
}

func execLine(l string) {
	l = macroExpand(l)
	curLine = l
	toks, lerr := lex(l)
	if lerr != nil {
		gpErr(lerr.Pos, lerr.Msg)
	}
	ex := &Exec{Parser{toks: toks, line: l}}
	ex.runAll()
}

func (ex *Exec) runAll() ctrl {
	for {
		for ex.isOp(";") {
			ex.p++
		}
		if ex.cur().T == TEnd {
			return cNone
		}
		c := ex.command()
		if c != cNone {
			return c
		}
		if !ex.atEnd() {
			gpErr(ex.cur().Pos, "unexpected or unrecognized token: "+tokText(ex.cur()))
		}
	}
}

func tokText(t Token) string {
	if t.T == TStr {
		return t.S
	}
	if t.T == TNum {
		return t.S
	}
	return t.S
}

// almostEquals: pattern like "pr$int"
func almost(tok string, pat string) bool {
	i := strings.IndexByte(pat, '$')
	if i < 0 {
		return tok == pat
	}
	full := pat[:i] + pat[i+1:]
	if len(tok) < i || len(tok) > len(full) {
		return false
	}
	return strings.HasPrefix(full, tok)
}

func (ex *Exec) isCmd(pat string) bool {
	t := ex.cur()
	return t.T == TName && almost(t.S, pat)
}

// block extraction: current token is '{', returns sub-exec over block and advances past '}'
func (ex *Exec) takeBlock() []Token {
	if !ex.isOp("{") {
		gpErr(ex.cur().Pos, "expected {")
	}
	d := 0
	st := ex.p + 1
	for k := ex.p; k < len(ex.toks); k++ {
		t := ex.toks[k]
		if t.T == TEnd {
			gpErr(ex.toks[ex.p].Pos, "Unmatched '{'")
		}
		if t.T == TOp && t.S == "{" {
			d++
		} else if t.T == TOp && t.S == "}" {
			d--
			if d == 0 {
				blk := make([]Token, 0, k-st+1)
				blk = append(blk, ex.toks[st:k]...)
				blk = append(blk, Token{T: TEnd, Pos: t.Pos, End: t.Pos})
				ex.p = k + 1
				return blk
			}
		}
	}
	return nil
}

func (ex *Exec) runBlock(blk []Token) ctrl {
	sub := &Exec{Parser{toks: blk, line: ex.line}}
	return sub.runAll()
}

func (ex *Exec) command() ctrl {
	t := ex.cur()
	if t.T == TOp && t.S == "!" {
		// shell command: rest of line
		cmd := ex.line[ex.toks[ex.p].End:]
		c := exec.Command("/bin/sh", "-c", cmd)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		stdout.Flush()
		c.Run()
		ex.p = len(ex.toks) - 1
		return cNone
	}
	if t.T == TOp && t.S == "{" {
		blk := ex.takeBlock()
		return ex.runBlock(blk)
	}
	if t.T != TName {
		gpErr(t.Pos, "invalid command")
	}
	n1 := ex.peek(1)
	// datablock
	if strings.HasPrefix(t.S, "$") {
		if n1.T == TOp && n1.S == "<<" {
			ex.defineDatablock()
			return cNone
		}
		if n1.T == TOp && n1.S == "=" {
			// $a = $b?
			ex.p += 2
			v := ex.evalExpr()
			if v.K == KStr {
				if db, ok := datablocks[v.S]; ok {
					datablocks[t.S] = append([]string{}, db...)
					return cNone
				}
			}
			gpErr(t.Pos, "invalid command")
		}
		gpErr(t.Pos, "invalid command")
	}
	// function definition
	if n1.T == TOp && n1.S == "(" && ex.isFuncDef() {
		ex.defineFunction()
		return cNone
	}
	if n1.T == TOp && (n1.S == "=" || n1.S == "[") {
		if n1.S == "=" || ex.isArrayAssign() {
			ex.evalExpr()
			return cNone
		}
	}
	switch {
	case ex.isCmd("pr$int"):
		ex.p++
		ex.cmdPrint(false)
	case ex.isCmd("printerr"):
		ex.p++
		ex.cmdPrint(true)
	case ex.isCmd("if"):
		return ex.cmdIf()
	case ex.isCmd("else"):
		gpErr(t.Pos, "else without if")
	case ex.isCmd("do"):
		return ex.cmdDo()
	case ex.isCmd("wh$ile"):
		return ex.cmdWhile()
	case ex.isCmd("break"):
		ex.p++
		return cBreak
	case ex.isCmd("continue"):
		ex.p++
		return cContinue
	case ex.isCmd("ev$al"):
		ex.p++
		v := ex.evalExpr()
		if v.K != KStr {
			gpErrNC("expected string")
		}
		saved := curLine
		execLine(v.S)
		curLine = saved
	case ex.isCmd("l$oad"):
		ex.p++
		fn := ex.evalString()
		loadFile(fn)
	case ex.isCmd("cal$l"):
		ex.p++
		fn := ex.evalString()
		var args []Value
		for !ex.atEnd() {
			tk := ex.next()
			switch tk.T {
			case TStr:
				args = append(args, StrV(tk.S))
			case TNum:
				args = append(args, Value{K: KCmplx, F: tk.V.real(), S: tk.S})
			default:
				if tk.T == TName && ex.isOp("(") {
				}
				if v, ok := globals[tk.S]; ok && tk.T == TName && v.K == KStr {
					args = append(args, v)
				} else {
					args = append(args, StrV(tk.S))
				}
			}
		}
		for i := range args {
			if args[i].K == KCmplx {
				// keep numeric value for ARGV but text for ARGn
			}
		}
		callFileArgs(fn, args)
	case ex.isCmd("ex$it") || ex.isCmd("q$uit"):
		ex.p++
		if ex.isCmd("st$atus") {
			ex.p++
			code := 0
			if !ex.atEnd() {
				v := toNum(ex.evalExpr())
				code = int(v.real())
			}
			exitProgram(code)
		}
		if !ex.atEnd() {
			ex.evalExpr()
		}
		if isStdinMode() || len(srcStack) > 1 && curSrc().kind == 0 {
		}
		panic(exitSource{})
	case ex.isCmd("res$et"):
		ex.p++
		if ex.isName("session") || ex.isName("errors") || ex.isName("bind") {
			if ex.isName("session") {
				resetSession()
			}
			ex.p++
		} else {
			resetSettings()
		}
	case ex.isCmd("undef$ine"):
		ex.p++
		for !ex.atEnd() {
			tk := ex.next()
			name := tk.S
			if strings.HasSuffix(name, "*") {
			}
			if ex.isOp("*") {
				ex.p++
				for k := range globals {
					if strings.HasPrefix(k, name) {
						delete(globals, k)
					}
				}
				continue
			}
			if strings.HasPrefix(name, "$") {
				delete(datablocks, name)
			} else {
				delete(globals, name)
			}
		}
	case ex.isCmd("cl$ear"):
		ex.p++
	case ex.isCmd("pa$use"):
		ex.p++
		for !ex.atEnd() {
			ex.p++
		}
	case ex.isCmd("array"):
		ex.cmdArray()
	case ex.isCmd("se$t"):
		ex.p++
		ex.cmdSet()
	case ex.isCmd("uns$et"):
		ex.p++
		ex.cmdUnset()
	case ex.isCmd("sh$ow"):
		ex.p++
		ex.cmdShow()
	case ex.isCmd("p$lot"):
		ex.p++
		ex.cmdPlot(false, false)
	case ex.isCmd("sp$lot"):
		ex.p++
		ex.cmdPlot(true, false)
	case ex.isCmd("rep$lot"):
		ex.p++
		ex.cmdReplot()
	case ex.isCmd("stat$s"):
		ex.p++
		ex.cmdStats()
	case ex.isCmd("f$it"):
		ex.p++
		ex.cmdFit()
	case ex.isCmd("sy$stem"):
		ex.p++
		s := ex.evalString()
		out := runSystem(s)
		if ex.isOp(";") || ex.atEnd() {
			stdout.WriteString(out)
		}
	case ex.isCmd("cd"):
		ex.p++
		d := ex.evalString()
		if err := os.Chdir(d); err != nil {
			gpErrNC("Can't change to this directory")
		}
	case ex.isCmd("pwd"):
		ex.p++
		wd, _ := os.Getwd()
		stdout.Flush()
		os.Stderr.WriteString(wd + "\n")
	case ex.isCmd("te$st"), ex.isCmd("h$elp"), ex.isCmd("hi$story"), ex.isCmd("ref$resh"), ex.isCmd("bi$nd"), ex.isCmd("ra$ise"), ex.isCmd("lo$wer"), ex.isCmd("vclear"), ex.isCmd("update"), ex.isCmd("save"):
		ex.p++
		for !ex.atEnd() {
			ex.p++
		}
	case ex.isCmd("toggle"):
		ex.p++
		for !ex.atEnd() {
			ex.p++
		}
	default:
		gpErr(t.Pos, "invalid command")
	}
	return cNone
}

func callFileArgs(fn string, args []Value) {
	// convert numeric args: ARGn get text, ARGV gets number
	saved := map[string]Value{}
	had := map[string]bool{}
	names := []string{"ARGC", "ARGV", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"}
	for _, n := range names {
		saved[n], had[n] = globals[n]
	}
	globals["ARGC"] = IntV(int64(len(args)))
	globals["ARG0"] = StrV(fn)
	arr := &Array{}
	for i := 1; i <= 9; i++ {
		name := fmt.Sprintf("ARG%d", i)
		if i <= len(args) {
			a := args[i-1]
			if a.K == KStr {
				globals[name] = a
			} else {
				globals[name] = StrV(a.S)
			}
		} else {
			globals[name] = StrV("")
		}
	}
	for _, a := range args {
		if a.K == KCmplx {
			arr.V = append(arr.V, FltV(a.F))
		} else {
			arr.V = append(arr.V, a)
		}
	}
	globals["ARGV"] = Value{K: KArr, A: arr}
	defer func() {
		for _, n := range names {
			if had[n] {
				globals[n] = saved[n]
			} else {
				delete(globals, n)
			}
		}
	}()
	loadFile(fn)
}

func (ex *Exec) isArrayAssign() bool {
	t := ex.cur()
	v, ok := globals[t.S]
	if !ok || v.K != KArr {
		return false
	}
	d := 0
	for k := ex.p + 1; k < len(ex.toks); k++ {
		tk := ex.toks[k]
		if tk.T == TEnd {
			return false
		}
		if tk.T == TOp && tk.S == "[" {
			d++
		} else if tk.T == TOp && tk.S == "]" {
			d--
			if d == 0 {
				return k+1 < len(ex.toks) && ex.toks[k+1].T == TOp && ex.toks[k+1].S == "="
			}
		}
	}
	return false
}

func (ex *Exec) isFuncDef() bool {
	// name ( name , name ... ) =
	k := ex.p + 2
	for {
		if ex.toks[k].T != TName {
			return false
		}
		k++
		if ex.toks[k].T == TOp && ex.toks[k].S == "," {
			k++
			continue
		}
		if ex.toks[k].T == TOp && ex.toks[k].S == ")" {
			k++
			break
		}
		return false
	}
	return ex.toks[k].T == TOp && ex.toks[k].S == "="
}

func (ex *Exec) defineFunction() {
	name := ex.next().S
	ex.p++
	var params []string
	for {
		params = append(params, ex.next().S)
		if ex.isOp(",") {
			ex.p++
			continue
		}
		break
	}
	ex.p++ // )
	ex.p++ // =
	st := ex.cur().Pos
	// allow recursion: register placeholder
	_, existed := userFuncs[name]
	if !existed {
		userFuncs[name] = &UserFunc{Name: name, Params: params}
	}
	var body *Node
	func() {
		defer func() {
			if r := recover(); r != nil {
				if !existed {
					delete(userFuncs, name)
				}
				panic(r)
			}
		}()
		body = ex.parseExpr()
	}()
	en := ex.cur().Pos
	text := strings.TrimSpace(ex.line[st:en])
	userFuncs[name] = &UserFunc{Name: name, Params: params, Body: body, Text: text}
	funcDefOrder = append(funcDefOrder, name)
}

func (ex *Exec) defineDatablock() {
	name := ex.next().S
	ex.p++ // <<
	tk := ex.next()
	term := tk.S
	if tk.T != TName {
		gpErr(tk.Pos, "missing terminator")
	}
	// rest of line ignored
	s := curSrc()
	var lines []string
	for {
		l, ok := s.readRaw()
		if !ok {
			break
		}
		if strings.HasPrefix(l, term) {
			break
		}
		lines = append(lines, l)
	}
	datablocks[name] = lines
	found := false
	for _, n := range varDefOrder {
		if n == name {
			found = true
		}
	}
	if !found {
		varDefOrder = append(varDefOrder, name)
	}
	ex.p = len(ex.toks) - 1
}

// evalExpr parses and evaluates one expression, raising undefined value error
func (ex *Exec) evalExpr() Value {
	st := ex.cur().Pos
	nd := ex.parseExpr()
	undefFlag = false
	v := eval(nd)
	if undefFlag {
		undefFlag = false
		gpErr(st, "undefined value")
	}
	return v
}

func (ex *Exec) evalNum() float64 {
	v := ex.evalExpr()
	return toNum(v).real()
}

func (ex *Exec) evalString() string {
	t := ex.cur()
	v := ex.evalExpr()
	if v.K != KStr {
		gpErr(t.Pos, "expecting string")
	}
	return v.S
}

func (ex *Exec) cmdPrint(toErr bool) {
	var sb strings.Builder
	first := true; _ = first
	if ex.atEnd() {
		out := "\n"
		if toErr {
			stdout.Flush()
			os.Stderr.WriteString(out)
		} else {
			printWrite(out)
		}
		return
	}
	emit := func(s string) {
		if toErr {
			stdout.Flush()
			os.Stderr.WriteString(s)
		} else {
			printWrite(s)
		}
	}
	for {
		v := ex.evalExpr()
		first = false
		if v.K == KArr {
			sb.WriteString(v.String())
			sb.WriteString("\n")
		} else if v.K == KNone {
			sb.WriteString("<undefined>")
		} else if v.K == KStr {
			if db, ok := datablocks[v.S]; ok && strings.HasPrefix(v.S, "$") {
				for _, l := range db {
					sb.WriteString(l + "\n")
				}
				if len(db) == 0 {
				}
			} else {
				sb.WriteString(v.S)
			}
		} else {
			sb.WriteString(v.String())
		}
		if ex.isOp(",") {
			sb.WriteString(" ")
		}
		emit(sb.String())
		sb.Reset()
		if ex.isOp(",") {
			ex.p++
			continue
		}
		break
	}
	emit("\n")
}

func (ex *Exec) cmdIf() ctrl {
	ex.p++
	ex.expectOp("(", "expecting '('")
	cond := ex.evalExpr()
	ex.expectOp(")", "expecting ')'")
	tv := isTrue(cond, 0)
	if !ex.isOp("{") {
		// old style: rest of line
		if tv {
			return ex.runAll()
		}
		ex.p = len(ex.toks) - 1
		return cNone
	}
	blk := ex.takeBlock()
	if tv {
		c := ex.runBlock(blk)
		// skip else branches
		for ex.isName("else") {
			ex.p++
			if ex.isName("if") {
				ex.p++
				ex.skipParens()
			}
			if ex.isOp("{") {
				ex.takeBlock()
			}
		}
		return c
	}
	if ex.isName("else") {
		ex.p++
		if ex.isName("if") {
			return ex.cmdIf()
		}
		blk2 := ex.takeBlock()
		return ex.runBlock(blk2)
	}
	return cNone
}

func (ex *Exec) skipParens() {
	if !ex.isOp("(") {
		return
	}
	d := 0
	for {
		t := ex.next()
		if t.T == TEnd {
			return
		}
		if t.T == TOp && t.S == "(" {
			d++
		} else if t.T == TOp && t.S == ")" {
			d--
			if d == 0 {
				return
			}
		}
	}
}

type iterSpec struct {
	varName string
	isStr   bool
	words   []string
	start   int64
	end     int64
	step    int64
	inf     bool
}

func (ex *Exec) parseIter() *iterSpec {
	// at '['
	ex.expectOp("[", "expecting '['")
	vt := ex.next()
	if vt.T != TName {
		gpErr(vt.Pos, "Expecting iterator \tfor [<var> = <start> : <end> ] \n\t\t\tor\tfor [<var> in \"string of words\"]")
	}
	it := &iterSpec{varName: vt.S, step: 1}
	if ex.isName("in") {
		ex.p++
		s := ex.evalExpr()
		if s.K == KArr {
			it.isStr = true
			for _, e := range s.A.V {
				it.words = append(it.words, e.String())
			}
		} else {
			it.isStr = true
			it.words = gpWords(strArg(s))
		}
		ex.expectOp("]", "expecting ']'")
		return it
	}
	ex.expectOp("=", "Expecting iterator \tfor [<var> = <start> : <end> ] \n\t\t\tor\tfor [<var> in \"string of words\"]")
	a := toNum(ex.evalExpr())
	ex.expectOp(":", "expecting ':'")
	if ex.isOp("*") {
		ex.p++
		it.inf = true
	} else {
		b := toNum(ex.evalExpr())
		it.end = int64(b.real())
		if b.K == KInt {
			it.end = b.I
		}
	}
	it.start = int64(a.real())
	if a.K == KInt {
		it.start = a.I
	}
	if ex.isOp(":") {
		ex.p++
		c := toNum(ex.evalExpr())
		it.step = int64(c.real())
		if c.K == KInt {
			it.step = c.I
		}
	}
	ex.expectOp("]", "expecting ']'")
	return it
}

func (it *iterSpec) values() []Value {
	var out []Value
	if it.isStr {
		for _, w := range it.words {
			out = append(out, StrV(w))
		}
		return out
	}
	if it.step == 0 {
		return nil
	}
	if it.inf {
		return nil
	}
	if it.step > 0 {
		for i := it.start; i <= it.end; i += it.step {
			out = append(out, IntV(i))
		}
	} else {
		for i := it.start; i >= it.end; i += it.step {
			out = append(out, IntV(i))
		}
	}
	return out
}

func (ex *Exec) cmdDo() ctrl {
	ex.p++
	if !ex.isName("for") {
		gpErr(ex.cur().Pos, "expecting 'for'")
	}
	ex.p++
	var its []*iterSpec
	for ex.isOp("[") {
		its = append(its, ex.parseIter())
		if ex.isName("for") {
			ex.p++
		}
	}
	blk := ex.takeBlock()
	brk := false
	var rec func(k int)
	rec = func(k int) {
		if k >= len(its) {
			c := ex.runBlock(blk)
			if c == cBreak {
				brk = true
			}
			return
		}
		it := its[k]
		old, had := globals[it.varName]
		if !it.isStr && it.inf {
			for i := it.start; !brk; i += it.step {
				globals[it.varName] = IntV(i)
				rec(k + 1)
			}
		} else {
			for _, v := range it.values() {
				if brk {
					break
				}
				globals[it.varName] = v
				rec(k + 1)
			}
		}
		if had {
			globals[it.varName] = old
		} else {
			delete(globals, it.varName)
		}
		_ = old
	}
	rec(0)
	return cNone
}

func (ex *Exec) cmdWhile() ctrl {
	ex.p++
	condStart := ex.p
	ex.skipParens()
	condEnd := ex.p
	blk := ex.takeBlock()
	for {
		sub := &Exec{Parser{toks: append(append([]Token{}, ex.toks[condStart:condEnd]...), Token{T: TEnd}), line: ex.line}}
		v := sub.evalExpr()
		if !isTrue(v, 0) {
			break
		}
		c := ex.runBlock(blk)
		if c == cBreak {
			break
		}
	}
	return cNone
}

func (ex *Exec) cmdArray() {
	ex.p++
	nt := ex.next()
	if nt.T != TName {
		gpErr(nt.Pos, "illegal array name")
	}
	name := nt.S
	size := -1
	if ex.isOp("[") {
		ex.p++
		v := toNum(ex.evalExpr())
		size = int(v.real())
		ex.expectOp("]", "expecting ']'")
	}
	var init []Value
	if ex.isOp("=") {
		ex.p++
		if ex.isOp("[") {
			ex.p++
			if !ex.isOp("]") {
				for {
					init = append(init, ex.evalExpr())
					if ex.isOp(",") {
						ex.p++
						continue
					}
					break
				}
			}
			ex.expectOp("]", "expecting ']'")
		} else {
			v := ex.evalExpr()
			if v.K == KArr {
				init = append(init, v.A.V...)
			}
		}
		if size < 0 {
			size = len(init)
		}
	}
	if size < 0 {
		gpErr(nt.Pos, "expecting [")
	}
	a := &Array{V: make([]Value, size)}
	for i := 0; i < size && i < len(init); i++ {
		a.V[i] = init[i]
	}
	setGlobal(name, Value{K: KArr, A: a})
}
