package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

var stdout = bufio.NewWriterSize(os.Stdout, 65536)
var stderrW = os.Stderr

func errWrite(s string) {
	stdout.Flush()
	flushPrint()
	stderrW.WriteString(s)
}

type Source struct {
	name   string
	kind   int // 0 file, 1 -e, 2 stdin
	lines  []string
	idx    int
	lineNo int
	sc     *bufio.Reader
}

func (s *Source) readRaw() (string, bool) {
	if s.sc != nil {
		l, err := s.sc.ReadString('\n')
		if err != nil && l == "" {
			return "", false
		}
		s.lineNo++
		return strings.TrimRight(l, "\n"), true
	}
	if s.idx >= len(s.lines) {
		return "", false
	}
	l := s.lines[s.idx]
	s.idx++
	s.lineNo++
	return l, true
}

var srcStack []*Source
var curLine string
var anyError bool
var interactive bool

func curSrc() *Source {
	if len(srcStack) == 0 {
		return nil
	}
	return srcStack[len(srcStack)-1]
}

func locPrefix() string {
	s := curSrc()
	if s == nil {
		return "line 0: "
	}
	if s.kind == 0 {
		return fmt.Sprintf("\"%s\" line %d: ", s.name, s.lineNo)
	}
	if s.kind == 2 {
		return "         line 0: "
	}
	return "line 0: "
}

func isStdinMode() bool {
	for _, s := range srcStack {
		if s.kind == 2 {
			return true
		}
	}
	return false
}

func reportError(e *GPError) {
	var sb strings.Builder
	stdinTop := curSrc() != nil && curSrc().kind == 2
	if e.Pos >= 0 {
		sb.WriteString("\n")
		if stdinTop {
			sb.WriteString("gnuplot> ")
		}
		sb.WriteString(curLine)
		sb.WriteString("\n")
		pad := e.Pos
		if stdinTop {
			pad += 9
		}
		sb.WriteString(strings.Repeat(" ", pad))
		sb.WriteString("^\n")
	}
	sb.WriteString(locPrefix())
	sb.WriteString(e.Msg)
	sb.WriteString("\n\n")
	errWrite(sb.String())
}

type exitSignal struct{ code int }
type exitSource struct{}

// readCommandLine reads a logical line with continuation and brace accumulation.
func readLogicalLine(s *Source) (string, bool) {
	l, ok := s.readRaw()
	if !ok {
		return "", false
	}
	for strings.HasSuffix(l, "\\") {
		n, ok2 := s.readRaw()
		if !ok2 {
			l = l[:len(l)-1]
			break
		}
		l = l[:len(l)-1] + n
	}
	// brace accumulation
	depth := braceDepth(l)
	for depth > 0 {
		n, ok2 := s.readRaw()
		if !ok2 {
			break
		}
		for strings.HasSuffix(n, "\\") {
			m, ok3 := s.readRaw()
			if !ok3 {
				break
			}
			n = n[:len(n)-1] + m
		}
		l = stripComment(l) + "\n" + n
		depth = braceDepth(l)
	}
	return l, true
}

func stripComment(l string) string {
	inS, inD := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		switch {
		case inD:
			if c == '\\' {
				i++
			} else if c == '"' {
				inD = false
			}
		case inS:
			if c == '\'' {
				inS = false
			}
		case c == '"':
			inD = true
		case c == '\'':
			inS = true
		case c == '#':
			return l[:i]
		}
	}
	return l
}

func braceDepth(l string) int {
	d := 0
	inS, inD := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		switch {
		case inD:
			if c == '\\' {
				i++
			} else if c == '"' {
				inD = false
			}
		case inS:
			if c == '\'' {
				inS = false
			}
		case c == '"':
			inD = true
		case c == '\'':
			inS = true
		case c == '#':
			return d
		case c == '{':
			d++
		case c == '}':
			d--
		}
	}
	return d
}

// runSource executes all lines in a source. Returns on exit command.
func runSource(s *Source) {
	srcStack = append(srcStack, s)
	defer func() { srcStack = srcStack[:len(srcStack)-1] }()
	for {
		l, ok := readLogicalLine(s)
		if !ok {
			return
		}
		if stop := execTopLine(l, s); stop {
			return
		}
	}
}

// execTopLine executes one line, handling errors. returns true when source should stop.
func execTopLine(l string, s *Source) (stop bool) {
	defer func() {
		if r := recover(); r != nil {
			switch e := r.(type) {
			case *GPError:
				anyError = true
				if !e.Special {
					reportError(e)
				}
				if s.kind == 2 {
					stop = false
					return
				}
				exitProgram(1)
			case exitSource:
				stop = true
				if len(srcStack) > 1 && s.kind != 2 {
					// exit inside loaded file exits that file only? gnuplot: exit terminates program
				}
				return
			default:
				panic(r)
			}
		}
	}()
	execLine(l)
	return false
}

func exitProgram(code int) {
	stdout.Flush()
	flushPrint()
	closeOutputs()
	os.Exit(code)
}

func main() {
	initState()
	args := os.Args[1:]
	didSomething := false
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GPError); ok {
				reportError(e)
				exitProgram(1)
			}
			panic(r)
		}
	}()
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			fmt.Fprintln(stdout, "gnuplot 5.4 patchlevel 9")
			exitProgram(0)
		case a == "-h" || a == "--help":
			fmt.Fprint(stdout, "Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\ngnuplot 5.4 patchlevel 9\n")
			exitProgram(0)
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings":
		case a == "-e":
			if i+1 < len(args) {
				i++
				didSomething = true
				s := &Source{name: "", kind: 1, lines: strings.Split(args[i], "\n")}
				s.lineNo = -1
				runSourceE(s)
			}
		case a == "-c":
			if i+1 < len(args) {
				didSomething = true
				fn := args[i+1]
				cargs := args[i+2:]
				callFile(fn, cargsToValues(cargs), true)
				exitProgram(boolCode())
			}
		case a == "-":
			didSomething = true
			runStdin()
		case strings.HasPrefix(a, "-") && len(a) > 1:
			fmt.Fprintf(os.Stderr, "unrecognized option %s\n", a)
		default:
			didSomething = true
			loadFileTop(a)
		}
	}
	if !didSomething {
		runStdin()
	}
	exitProgram(boolCode())
}

func boolCode() int {
	if anyError {
		return 1
	}
	return 0
}

func runSourceE(s *Source) {
	// -e: line number reported as 0
	srcStack = append(srcStack, s)
	defer func() { srcStack = srcStack[:len(srcStack)-1] }()
	for {
		l, ok := readLogicalLine(s)
		s.lineNo = 0
		if !ok {
			return
		}
		if stop := execTopLine(l, s); stop {
			return
		}
	}
}

func runStdin() {
	s := &Source{name: "", kind: 2, sc: bufio.NewReader(os.Stdin)}
	interactive = true
	runSource(s)
	interactive = false
}

func loadFileTop(fn string) {
	data, err := os.ReadFile(fn)
	if err != nil {
		reportError(&GPError{Msg: "Cannot load input from '" + fn + "'", Pos: -1})
		exitProgram(1)
	}
	s := &Source{name: fn, kind: 0, lines: splitLines(string(data))}
	setGlobal("ARGC", IntV(0))
	setGlobal("ARG0", StrV(fn))
	setGlobal("ARGV", Value{K: KArr, A: &Array{}})
	for i := 1; i <= 9; i++ {
		setGlobal(fmt.Sprintf("ARG%d", i), StrV(""))
	}
	runSource(s)
}

func splitLines(d string) []string {
	if d == "" {
		return nil
	}
	d = strings.TrimSuffix(d, "\n")
	ls := strings.Split(d, "\n")
	for i := range ls {
		ls[i] = strings.TrimSuffix(ls[i], "\r")
	}
	return ls
}

func cargsToValues(a []string) []Value {
	var out []Value
	for _, s := range a {
		out = append(out, StrV(s))
	}
	return out
}

// loadFile runs a file as a nested source (load / call)
func loadFile(fn string) {
	data, err := os.ReadFile(fn)
	if err != nil {
		gpErrNC("Cannot load input from '" + fn + "'")
	}
	s := &Source{name: fn, kind: 0, lines: splitLines(string(data))}
	srcStack = append(srcStack, s)
	saved := curLine
	defer func() {
		srcStack = srcStack[:len(srcStack)-1]
		curLine = saved
	}()
	for {
		l, ok := readLogicalLine(s)
		if !ok {
			return
		}
		stop := func() (stop bool) {
			defer func() {
				if r := recover(); r != nil {
					if _, ok := r.(exitSource); ok {
						stop = true
						return
					}
					if e, ok := r.(*GPError); ok && !e.Special {
						// report here with this file's context, then propagate as already-reported
						reportError(e)
						anyError = true
						panic(&GPError{Msg: e.Msg, Pos: -2, Special: true})
					}
					panic(r)
				}
			}()
			execLine(l)
			return false
		}()
		if stop {
			return
		}
	}
}

func callFile(fn string, args []Value, top bool) {
	saved := map[string]Value{}
	had := map[string]bool{}
	names := []string{"ARGC", "ARGV", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"}
	for _, n := range names {
		saved[n], had[n] = globals[n]
	}
	globals["ARGC"] = IntV(int64(len(args)))
	globals["ARG0"] = StrV(fn)
	arr := &Array{}
	for i := 1; i <= 9; i++ {
		if i <= len(args) {
			a := args[i-1]
			if a.K == KStr {
				globals[fmt.Sprintf("ARG%d", i)] = a
			} else {
				globals[fmt.Sprintf("ARG%d", i)] = StrV(a.argString())
			}
		} else {
			globals[fmt.Sprintf("ARG%d", i)] = StrV("")
		}
	}
	for _, a := range args {
		arr.V = append(arr.V, a)
	}
	globals["ARGV"] = Value{K: KArr, A: arr}
	defer func() {
		for _, n := range names {
			if had[n] {
				globals[n] = saved[n]
			} else {
				delete(globals, n)
			}
		}
	}()
	if top {
		data, err := os.ReadFile(fn)
		if err != nil {
			reportError(&GPError{Msg: "Cannot load input from '" + fn + "'", Pos: -1})
			exitProgram(1)
		}
		s := &Source{name: fn, kind: 0, lines: splitLines(string(data))}
		runSource(s)
		return
	}
	loadFile(fn)
}

func (v Value) argString() string {
	if v.K == KInt {
		return strconv.FormatInt(v.I, 10)
	}
	if v.K == KCmplx {
		return fmtG15(v.F)
	}
	return v.String()
}

var _ = math.Pi
