package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

var rs1, rs2 int64 = 1234567890, 1234567890

func gpRand(a []Value) float64 {
	if len(a) > 0 {
		v := toNum(a[0])
		if v.K == KCmplx && v.Im != 0 {
			rs1, rs2 = int64(v.F), int64(v.Im)
		} else {
			x := v.real()
			if x < 0 {
				rs1, rs2 = 1234567890, 1234567890
				return 0
			} else if x > 0 {
				rs1, rs2 = int64(x), int64(x)
			}
		}
	}
	k := rs1 / 53668
	rs1 = 40014*(rs1-k*53668) - k*12211
	if rs1 < 0 {
		rs1 += 2147483563
	}
	k = rs2 / 52774
	rs2 = 40692*(rs2-k*52774) - k*3791
	if rs2 < 0 {
		rs2 += 2147483399
	}
	z := rs1 - rs2
	if z < 1 {
		z += 2147483562
	}
	return float64(z) * 4.656613057e-10
}

func lambertW(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1)
	} else if x > -0.3 {
		w = x
	} else {
		w = -1 + math.Sqrt(2*(1+math.E*x))
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func voigt(x, y float64) float64 {
	// numerical integration of Voigt profile (Humlicek approx would be better)
	// K(x,y) = y/pi * integral exp(-t^2)/((x-t)^2+y^2) dt
	if y <= 0 {
		return math.Exp(-x*x) / math.Sqrt(math.Pi)
	}
	n := 4000
	lim := 12.0
	h := 2 * lim / float64(n)
	s := 0.0
	for i := 0; i <= n; i++ {
		t := -lim + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		s += w * math.Exp(-t*t) / ((x-t)*(x-t) + y*y)
	}
	return y / math.Pi * s * h / math.Sqrt(math.Pi)
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		if x == 0 {
			return 0
		}
		undefFlag = true
		return math.NaN()
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		sum := 1 / a
		del := sum
		ap := a
		for i := 0; i < 10000; i++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 10000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m < 10000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x < 0 || x > 1 || a <= 0 || b <= 0 {
		undefFlag = true
		return math.NaN()
	}
	if x == 0 || x == 1 {
		return x
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func expint(n int, x float64) float64 {
	if n < 0 || x < 0 || (x == 0 && (n == 0 || n == 1)) {
		undefFlag = true
		return math.NaN()
	}
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x == 0 {
		return 1 / float64(n-1)
	}
	nm1 := n - 1
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 10000; i++ {
			an := -float64(i) * float64(nm1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 10000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

func airyAi(x float64) float64 {
	// power series for moderate x, asymptotic otherwise
	if x > 8 {
		z := 2.0 / 3 * math.Pow(x, 1.5)
		return math.Exp(-z) / (2 * math.Sqrt(math.Pi) * math.Pow(x, 0.25))
	}
	if x < -8 {
		ax := -x
		z := 2.0 / 3 * math.Pow(ax, 1.5)
		return math.Sin(z+math.Pi/4) / (math.Sqrt(math.Pi) * math.Pow(ax, 0.25))
	}
	c1 := 0.355028053887817
	c2 := 0.258819403792807
	f := 1.0
	g := x
	tf, tg := 1.0, x
	x3 := x * x * x
	for k := 1; k < 200; k++ {
		fk := float64(k)
		tf *= x3 / ((3*fk - 1) * (3 * fk))
		tg *= x3 / ((3 * fk) * (3*fk + 1))
		f += tf
		g += tg
		if math.Abs(tf) < 1e-18 && math.Abs(tg) < 1e-18 {
			break
		}
	}
	return c1*f - c2*g
}

func besI(n int, x float64) float64 {
	s := 0.0
	t := math.Pow(x/2, float64(n))
	for k := 1; k <= n; k++ {
		t /= float64(k)
	}
	for k := 0; k < 500; k++ {
		s += t
		t *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if t < 1e-17*s {
			break
		}
	}
	return s
}

func hsv2rgb(h, s, v float64) (int, int, int) {
	if s == 0 {
		c := int(v * 255)
		return c, c, c
	}
	h = h - math.Floor(h)
	h *= 6
	i := int(h)
	f := h - float64(i)
	p := v * (1 - s)
	q := v * (1 - s*f)
	t := v * (1 - s*(1-f))
	var r, g, b float64
	switch i {
	case 0:
		r, g, b = v, t, p
	case 1:
		r, g, b = q, v, p
	case 2:
		r, g, b = p, v, t
	case 3:
		r, g, b = p, q, v
	case 4:
		r, g, b = t, p, v
	default:
		r, g, b = v, p, q
	}
	return int(r*255 + 0.5), int(g*255 + 0.5), int(b*255 + 0.5)
}

var colorNames = map[string]int64{
	"white": 0xffffff, "black": 0x000000, "dark-grey": 0xa0a0a0, "red": 0xff0000, "web-green": 0x00c000, "web-blue": 0x0080ff,
	"dark-magenta": 0xc000ff, "dark-cyan": 0x00eeee, "dark-orange": 0xc04000, "dark-yellow": 0xc8c800, "royalblue": 0x4169e1,
	"goldenrod": 0xffc020, "dark-spring-green": 0x008040, "purple": 0xc080ff, "steelblue": 0x306080, "dark-red": 0x8b0000,
	"dark-chartreuse": 0x408000, "orchid": 0xff80ff, "aquamarine": 0x7fffd4, "brown": 0xa52a2a, "yellow": 0xffff00,
	"turquoise": 0x40e0d0, "grey": 0xc0c0c0, "gray": 0xbebebe, "light-grey": 0xd3d3d3, "green": 0x00ff00, "blue": 0x0000ff,
	"magenta": 0xff00ff, "cyan": 0x00ffff, "orange": 0xffa500, "violet": 0xee82ee, "dark-blue": 0x00008b, "dark-green": 0x006400,
}

func parseColorName(s string) int64 {
	if strings.HasPrefix(s, "#") {
		v, _ := strconv.ParseUint(s[1:], 16, 64)
		return int64(v)
	}
	if strings.HasPrefix(s, "0x") {
		v, _ := strconv.ParseUint(s[2:], 16, 64)
		return int64(v)
	}
	if v, ok := colorNames[s]; ok {
		return v
	}
	return 0
}

// ---------- time ----------

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gstrftime(f string, t float64) string {
	sec := math.Floor(t)
	frac := t - sec
	tt := time.Unix(int64(sec), 0).UTC()
	var sb strings.Builder
	for i := 0; i < len(f); i++ {
		if f[i] != '%' || i+1 >= len(f) {
			sb.WriteByte(f[i])
			continue
		}
		i++
		// optional width/precision for %S
		pad := true
		if f[i] == '0' {
			i++
		}
		if f[i] == '-' {
			pad = false
			i++
		}
		prec := -1
		if f[i] == '.' && i+1 < len(f) && isDigit(f[i+1]) {
			prec = int(f[i+1] - '0')
			i += 2
		}
		d2 := func(n int) string {
			if pad {
				return fmt.Sprintf("%02d", n)
			}
			return strconv.Itoa(n)
		}
		switch f[i] {
		case 'Y':
			sb.WriteString(strconv.Itoa(tt.Year()))
		case 'y':
			sb.WriteString(fmt.Sprintf("%02d", tt.Year()%100))
		case 'm':
			sb.WriteString(d2(int(tt.Month())))
		case 'd':
			sb.WriteString(d2(tt.Day()))
		case 'e':
			sb.WriteString(fmt.Sprintf("%2d", tt.Day()))
		case 'H':
			sb.WriteString(d2(tt.Hour()))
		case 'k':
			sb.WriteString(fmt.Sprintf("%2d", tt.Hour()))
		case 'I':
			h := tt.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(d2(h))
		case 'l':
			h := tt.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(fmt.Sprintf("%2d", h))
		case 'M':
			sb.WriteString(d2(tt.Minute()))
		case 'S':
			sb.WriteString(d2(tt.Second()))
			if prec > 0 {
				s := fmt.Sprintf("%.*f", prec, frac)
				sb.WriteString(s[1:])
			}
		case 'j':
			sb.WriteString(fmt.Sprintf("%03d", tt.YearDay()))
		case 'b', 'h':
			sb.WriteString(monNames[tt.Month()-1][:3])
		case 'B':
			sb.WriteString(monNames[tt.Month()-1])
		case 'a':
			sb.WriteString(dayNames[tt.Weekday()][:3])
		case 'A':
			sb.WriteString(dayNames[tt.Weekday()])
		case 'p':
			if tt.Hour() < 12 {
				sb.WriteString("AM")
			} else {
				sb.WriteString("PM")
			}
		case 's':
			sb.WriteString(strconv.FormatInt(int64(sec), 10))
		case 'w':
			sb.WriteString(strconv.Itoa(int(tt.Weekday())))
		case 'D':
			sb.WriteString(fmt.Sprintf("%02d/%02d/%02d", tt.Month(), tt.Day(), tt.Year()%100))
		case 'F':
			sb.WriteString(fmt.Sprintf("%d-%02d-%02d", tt.Year(), tt.Month(), tt.Day()))
		case 'T':
			sb.WriteString(fmt.Sprintf("%02d:%02d:%02d", tt.Hour(), tt.Minute(), tt.Second()))
		case 'R':
			sb.WriteString(fmt.Sprintf("%02d:%02d", tt.Hour(), tt.Minute()))
		case 'n':
			sb.WriteByte('\n')
		case 't':
			sb.WriteByte('\t')
		case '%':
			sb.WriteByte('%')
		default:
			sb.WriteByte('%')
			sb.WriteByte(f[i])
		}
	}
	return sb.String()
}

func gstrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min_, sec := 1970, 1, 1, 0, 0, 0.0
	yday := -1
	pm := -1
	epoch := math.NaN()
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		neg := false
		if si < len(s) && (s[si] == '-' || s[si] == '+') {
			neg = s[si] == '-'
			si++
		}
		st := si
		for si < len(s) && si-st < maxd && isDigit(s[si]) {
			si++
		}
		if si == st {
			return 0, false
		}
		v, _ := strconv.Atoi(s[st:si])
		if neg {
			v = -v
		}
		return v, true
	}
	for i := 0; i < len(f); i++ {
		if f[i] != '%' {
			if f[i] == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == f[i] {
				si++
			} else {
				return 0, false
			}
			continue
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			var y int
			y, ok = readInt(2)
			if y < 69 {
				year = 2000 + y
			} else {
				year = 1900 + y
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k', 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min_, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			var v int
			v, ok = readInt(2)
			sec = float64(v)
			if si < len(s) && s[si] == '.' {
				st := si
				si++
				for si < len(s) && isDigit(s[si]) {
					si++
				}
				fr, _ := strconv.ParseFloat("0"+s[st:si], 64)
				sec += fr
			}
		case 's':
			st := si
			for si < len(s) && (isDigit(s[si]) || s[si] == '.' || s[si] == '-') {
				si++
			}
			v, err := strconv.ParseFloat(s[st:si], 64)
			ok = err == nil
			epoch = v
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m[:3]) {
					mon = k + 1
					if f[i] == 'B' && len(s)-si >= len(m) && strings.EqualFold(s[si:si+len(m)], m) {
						si += len(m)
					} else {
						si += 3
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			ok = false
			for _, m := range dayNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m[:3]) {
					if f[i] == 'A' && len(s)-si >= len(m) && strings.EqualFold(s[si:si+len(m)], m) {
						si += len(m)
					} else {
						si += 3
					}
					ok = true
					break
				}
			}
		case 'p':
			if len(s)-si >= 2 {
				if strings.EqualFold(s[si:si+2], "PM") {
					pm = 1
				} else {
					pm = 0
				}
				si += 2
				ok = true
			}
		case '%':
			ok = si < len(s) && s[si] == '%'
			si++
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if !math.IsNaN(epoch) {
		return epoch, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min_, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min_, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + sec, true
}
