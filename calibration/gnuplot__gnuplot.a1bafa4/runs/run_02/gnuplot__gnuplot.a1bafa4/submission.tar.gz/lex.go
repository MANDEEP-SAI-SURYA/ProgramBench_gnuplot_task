package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
)

type TokT int

const (
	TName TokT = iota
	TNum
	TStr
	TOp
	TEnd
)

type Token struct {
	T   TokT
	S   string // raw text (for op/name), decoded string for TStr
	V   Value  // number
	Pos int    // byte position in line
	End int
	Sq  bool // single-quoted string
}

type LexError struct {
	Pos int
	Msg string
}

func isAlpha(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_' || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }
func isAlnum(c byte) bool { return isAlpha(c) || isDigit(c) }

var twoOps = []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "+=", "-=", "*=", "/="}

func decodeDQ(s string) string {
	var sb strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c != '\\' || i+1 >= len(s) {
			sb.WriteByte(c)
			continue
		}
		i++
		c = s[i]
		switch c {
		case 'n':
			sb.WriteByte('\n')
		case 't':
			sb.WriteByte('\t')
		case 'r':
			sb.WriteByte('\r')
		case 'a':
			sb.WriteByte(7)
		case 'b':
			sb.WriteByte(8)
		case 'f':
			sb.WriteByte(12)
		case 'v':
			sb.WriteByte(11)
		case '"':
			sb.WriteByte('"')
		case '\\':
			sb.WriteByte('\\')
		case '0', '1', '2', '3', '4', '5', '6', '7':
			n := 0
			k := 0
			for k < 3 && i < len(s) && s[i] >= '0' && s[i] <= '7' {
				n = n*8 + int(s[i]-'0')
				i++
				k++
			}
			i--
			sb.WriteByte(byte(n))
		default:
			sb.WriteByte('\\')
			sb.WriteByte(c)
		}
	}
	return sb.String()
}

// lex tokenizes a full line. Comments (#) end the line unless inside strings.
func lex(line string) ([]Token, *LexError) {
	var toks []Token
	i := 0
	n := len(line)
	for i < n {
		c := line[i]
		if c == '\n' {
			toks = append(toks, Token{T: TOp, S: ";", Pos: i, End: i + 1})
			i++
			continue
		}
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '#' {
			for i < n && line[i] != '\n' {
				i++
			}
			continue
		}
		st := i
		switch {
		case isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])):
			// number
			if c == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
				toks = append(toks, Token{T: TNum, V: IntV(int64(v)), Pos: st, End: j, S: line[st:j]})
				i = j
				continue
			}
			j := i
			isf := false
			for j < n && isDigit(line[j]) {
				j++
			}
			if j < n && line[j] == '.' {
				isf = true
				j++
				for j < n && isDigit(line[j]) {
					j++
				}
			}
			if j < n && (line[j] == 'e' || line[j] == 'E' || line[j] == 'd' || line[j] == 'D' || line[j] == 'q' || line[j] == 'Q') {
				k := j + 1
				if k < n && (line[k] == '+' || line[k] == '-') {
					k++
				}
				if k < n && isDigit(line[k]) {
					for k < n && isDigit(line[k]) {
						k++
					}
					isf = true
					j = k
				}
			}
			txt := line[i:j]
			var v Value
			if isf {
				t := strings.Map(func(r rune) rune {
					if r == 'd' || r == 'D' || r == 'q' || r == 'Q' {
						return 'e'
					}
					return r
				}, txt)
				f, _ := strconv.ParseFloat(t, 64)
				v = FltV(f)
			} else {
				if len(txt) > 1 && txt[0] == '0' {
					// octal
					u, err := strconv.ParseUint(txt, 8, 64)
					if err == nil {
						v = IntV(int64(u))
					} else {
						u2, _ := strconv.ParseInt(txt, 10, 64)
						v = IntV(u2)
					}
				} else {
					u, err := strconv.ParseInt(txt, 10, 64)
					if err != nil {
						f, _ := strconv.ParseFloat(txt, 64)
						v = FltV(f)
					} else {
						v = IntV(u)
					}
				}
			}
			toks = append(toks, Token{T: TNum, V: v, Pos: st, End: j, S: txt})
			i = j
		case isAlpha(c):
			j := i
			for j < n && isAlnum(line[j]) {
				j++
			}
			toks = append(toks, Token{T: TName, S: line[i:j], Pos: st, End: j})
			i = j
		case c == '$':
			j := i + 1
			for j < n && isAlnum(line[j]) {
				j++
			}
			toks = append(toks, Token{T: TName, S: line[i:j], Pos: st, End: j})
			i = j
		case c == '"':
			j := i + 1
			for j < n && line[j] != '"' {
				if line[j] == '\\' && j+1 < n {
					j++
				}
				j++
			}
			if j >= n {
				return toks, &LexError{st, "invalid character"}
			}
			toks = append(toks, Token{T: TStr, S: decodeDQ(line[i+1 : j]), Pos: st, End: j + 1})
			i = j + 1
		case c == '\'':
			var sb strings.Builder
			j := i + 1
			for {
				if j >= n {
					return toks, &LexError{st, "invalid character"}
				}
				if line[j] == '\'' {
					if j+1 < n && line[j+1] == '\'' {
						sb.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				sb.WriteByte(line[j])
				j++
			}
			toks = append(toks, Token{T: TStr, S: sb.String(), Pos: st, End: j + 1, Sq: true})
			i = j + 1
		default:
			op := ""
			if i+1 < n {
				two := line[i : i+2]
				for _, o := range twoOps {
					if o == two {
						op = two
						break
					}
				}
			}
			if op == "" {
				op = line[i : i+1]
			}
			toks = append(toks, Token{T: TOp, S: op, Pos: st, End: i + len(op)})
			i += len(op)
		}
	}
	toks = append(toks, Token{T: TEnd, Pos: n, End: n})
	return toks, nil
}

// ---------- C style formatting ----------

type fspec struct {
	flags string
	width string
	prec  string
	conv  byte
}

func parseSpec(s string) (fspec, int) {
	// s starts after '%'
	var f fspec
	i := 0
	for i < len(s) && strings.IndexByte("-+ #0'", s[i]) >= 0 {
		if s[i] != '\'' {
			f.flags += string(s[i])
		}
		i++
	}
	st := i
	for i < len(s) && (isDigit(s[i]) || s[i] == '*') {
		i++
	}
	f.width = s[st:i]
	if i < len(s) && s[i] == '.' {
		i++
		st = i
		for i < len(s) && isDigit(s[i]) {
			i++
		}
		f.prec = "." + s[st:i]
		if f.prec == "." {
			f.prec = ".0"
		}
	}
	for i+1 < len(s) && strings.IndexByte("hlLqjz", s[i]) >= 0 && strings.IndexByte("diouxXeEfgGcshlL", s[i+1]) >= 0 {
		i++
	}
	if i < len(s) {
		f.conv = s[i]
		i++
	}
	return f, i
}

func fmtFloatSpec(f fspec, x float64) string {
	conv := f.conv
	prec := f.prec
	if prec == "" {
		prec = ".6"
	}
	if math.IsInf(x, 0) || math.IsNaN(x) {
		var s string
		if math.IsNaN(x) {
			s = "nan"
		} else if x > 0 {
			s = "inf"
			if strings.Contains(f.flags, "+") {
				s = "+inf"
			} else if strings.Contains(f.flags, " ") {
				s = " inf"
			}
		} else {
			s = "-inf"
		}
		if conv == 'E' || conv == 'G' || conv == 'F' {
			s = strings.ToUpper(s)
		}
		fl := strings.ReplaceAll(f.flags, "0", "")
		return fmt.Sprintf("%"+fl+f.width+"s", s)
	}
	if conv == 'g' || conv == 'G' {
		if strings.Contains(f.flags, "#") {
			// C %#g keeps trailing zeros
			p, _ := strconv.Atoi(prec[1:])
			if p == 0 {
				p = 1
			}
			fl := strings.ReplaceAll(f.flags, "#", "")
			e := 0
			if x != 0 {
				e = int(math.Floor(math.Log10(math.Abs(x))))
				// correct with rounding
				r := strconv.FormatFloat(math.Abs(x), 'e', p-1, 64)
				ei := strings.IndexByte(r, 'e')
				e, _ = strconv.Atoi(r[ei+1:])
			}
			var s string
			if e < -4 || e >= p {
				s = fmt.Sprintf("%"+fl+f.width+"."+strconv.Itoa(p-1)+string(conv-2), x)
			} else {
				s = fmt.Sprintf("%"+fl+f.width+"."+strconv.Itoa(p-1-e)+"f", x)
			}
			return s
		}
		if prec == ".0" {
			prec = ".1"
		}
	}
	return fmt.Sprintf("%"+f.flags+f.width+prec+string(conv), x)
}

func fmtIntSpec(f fspec, v int64) string {
	switch f.conv {
	case 'd', 'i':
		if f.prec != "" {
			// C precision for ints: min digits
			p, _ := strconv.Atoi(f.prec[1:])
			s := strconv.FormatInt(absI(v), 10)
			for len(s) < p {
				s = "0" + s
			}
			if v < 0 {
				s = "-" + s
			} else if strings.Contains(f.flags, "+") {
				s = "+" + s
			} else if strings.Contains(f.flags, " ") {
				s = " " + s
			}
			fl := strings.ReplaceAll(f.flags, "0", "")
			fl = strings.ReplaceAll(fl, "+", "")
			fl = strings.ReplaceAll(fl, " ", "")
			return fmt.Sprintf("%"+fl+f.width+"s", s)
		}
		return fmt.Sprintf("%"+f.flags+f.width+"d", v)
	case 'x', 'X', 'o':
		fl := f.flags
		u := uint64(v)
		pre := ""
		if strings.Contains(fl, "#") && u != 0 {
			if f.conv == 'x' {
				pre = "0x"
			} else if f.conv == 'X' {
				pre = "0X"
			} else {
				pre = "0"
			}
		}
		fl = strings.ReplaceAll(fl, "#", "")
		var digits string
		switch f.conv {
		case 'x':
			digits = strconv.FormatUint(u, 16)
		case 'X':
			digits = strings.ToUpper(strconv.FormatUint(u, 16))
		default:
			digits = strconv.FormatUint(u, 8)
		}
		if f.prec != "" {
			p, _ := strconv.Atoi(f.prec[1:])
			for len(digits) < p {
				digits = "0" + digits
			}
			fl = strings.ReplaceAll(fl, "0", "")
		}
		s := pre + digits
		w, _ := strconv.Atoi(f.width)
		if len(s) < w {
			if strings.Contains(fl, "-") {
				s = s + strings.Repeat(" ", w-len(s))
			} else if strings.Contains(fl, "0") {
				s = pre + strings.Repeat("0", w-len(s)) + digits
			} else {
				s = strings.Repeat(" ", w-len(s)) + s
			}
		}
		return s
	case 'c':
		return fmt.Sprintf("%"+strings.ReplaceAll(f.flags, "0", "")+f.width+"s", string([]byte{byte(v)}))
	}
	return ""
}

func absI(v int64) int64 {
	if v < 0 {
		return -v
	}
	return v
}

// cfmt formats a single numeric value with a C format containing one spec.
func cfmt(format string, x float64) string {
	var sb strings.Builder
	for i := 0; i < len(format); i++ {
		if format[i] != '%' {
			sb.WriteByte(format[i])
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			sb.WriteByte('%')
			i++
			continue
		}
		f, l := parseSpec(format[i+1:])
		i += l
		switch f.conv {
		case 'd', 'i', 'x', 'X', 'o', 'c':
			sb.WriteString(fmtIntSpec(f, int64(x)))
		default:
			sb.WriteString(fmtFloatSpec(f, x))
		}
	}
	return sb.String()
}
