package main

func renderDumb(curves []*Curve, xr, yr *Axis, is3D bool) {}
