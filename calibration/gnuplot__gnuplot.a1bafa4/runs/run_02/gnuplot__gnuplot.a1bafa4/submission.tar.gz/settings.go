package main

import (
	"fmt"
	"math"
	"os"
	"strings"
)

type Axis struct {
	name           string
	min, max       float64
	autoMin        bool
	autoMax        bool
	reverse        bool
	log            bool
	base           float64
	format         string
	label          string
	labelOff       [2]float64
	timeData       bool
	ticsOn         bool
	ticStep        float64 // 0 = auto
	ticStart       float64
	ticEnd         float64
	ticHasStart    bool
	ticList        []ticEntry
	ticListAdd     bool
	mirror         bool
	minorTics      int
	curMin, curMax float64
}

type ticEntry struct {
	label string
	pos   float64
	hasLb bool
}

type Settings struct {
	samples1, samples2 int
	iso1, iso2         int
	axes               map[string]*Axis
	title              string
	styleData          string
	styleFunc          string
	dummy              [2]string
	timefmt            string
	tableOn            bool
	tableFile          string
	termName           string
	termW, termH       int
	termFeed           bool
	outputFile         string
	parametric         bool
	boxwidth           float64
	boxwidthRel        bool
	grid               bool
	keyOn              bool
	keyPos             string // e.g. "top right"
	keyLeft            bool
	keyBottom          bool
	keyCenterV         bool
	keyCenterH         bool
	keyOutside         bool
	keyBox             bool
	keyReverse         bool
	keyTitle           string
	keyJustLeft        bool
	sepChar            string
	missing            string
	hasMissing         bool
	border             int
	xzeroaxis          bool
	yzeroaxis          bool
	offsets            [4]float64
	fitLog             string
	fitQuiet           bool
	fitErrVars         bool
	fitCovVars         bool
	fitPrescale        bool
	fitLimit           float64
	fitMaxIter         int
	fitStartLambda     float64
	fitLambdaFactor    float64
	clipPoints         bool
	labels             []*Label
	arrows             []string
	multiplot          bool
	polar              bool
	decimalsign        string
	ticsFront          bool
	view               [4]float64
	surface            bool
	hidden3d           bool
	contour            bool
	pointsize          float64
	tableSep           string
}

type Label struct {
	tag  int
	text string
	x, y float64
	just string
}

var S Settings

var datablocks = map[string][]string{}

var timefmtIn = "%d/%m/%y,%H:%M"

func newAxis(name string) *Axis {
	return &Axis{name: name, autoMin: true, autoMax: true, base: 10, format: "% h", ticsOn: name == "x" || name == "y" || name == "z" || name == "cb", mirror: true, min: -10, max: 10}
}

func resetSettings() {
	S.samples1, S.samples2 = 100, 100
	S.iso1, S.iso2 = 10, 10
	S.axes = map[string]*Axis{}
	for _, a := range []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"} {
		S.axes[a] = newAxis(a)
	}
	S.axes["t"].min, S.axes["t"].max = -5, 5
	S.axes["u"].min, S.axes["u"].max = -5, 5
	S.axes["v"].min, S.axes["v"].max = -5, 5
	S.axes["r"].min, S.axes["r"].max = 0, 10
	S.title = ""
	S.styleData = "points"
	S.styleFunc = "lines"
	S.dummy = [2]string{"x", "y"}
	S.timefmt = "%d/%m/%y,%H:%M"
	timefmtIn = S.timefmt
	S.parametric = false
	S.boxwidth = -1
	S.grid = false
	S.keyOn = true
	S.keyLeft, S.keyBottom, S.keyCenterH, S.keyCenterV, S.keyOutside, S.keyBox, S.keyReverse = false, false, false, false, false, false, false
	S.keyTitle = ""
	S.keyJustLeft = false
	S.sepChar = ""
	S.missing = ""
	S.hasMissing = false
	S.border = 31
	S.xzeroaxis, S.yzeroaxis = false, false
	S.offsets = [4]float64{}
	S.fitErrVars = true
	S.fitPrescale = true
	S.fitLimit = 1e-5
	S.fitMaxIter = 0
	S.fitStartLambda = 0
	S.fitLambdaFactor = 10
	S.labels = nil
	S.arrows = nil
	S.polar = false
	S.decimalsign = ""
	S.view = [4]float64{60, 30, 1, 1}
	S.surface = true
	S.hidden3d = false
	S.contour = false
	S.pointsize = 1
	angleDegrees = false
}

func initState() {
	resetSettings()
	S.termName = "unknown"
	S.termW, S.termH = 79, 24
	S.termFeed = true
	S.fitLog = ""
	S.fitQuiet = false
	globals["pi"] = FltV(math.Pi)
	globals["I"] = CV(0, 1)
	globals["NaN"] = FltV(math.NaN())
	globals["VoxelDistance"] = FltV(0)
	globals["GPVAL_TERM"] = StrV("unknown")
}

func resetSession() {
	globals = map[string]Value{}
	userFuncs = map[string]*UserFunc{}
	datablocks = map[string][]string{}
	resetSettings()
	initState()
}

var termOut *os.File

func closeTermOutput() {
	if termOut != nil {
		termOut.Close()
		termOut = nil
	}
}

func termWriter() func(string) {
	if termOut != nil {
		return func(s string) { termOut.WriteString(s) }
	}
	return func(s string) { stdout.WriteString(s) }
}

// ---------- set ----------

var axisNames = []string{"x2", "y2", "cb", "x", "y", "z", "r", "t", "u", "v"}

func axisPrefix(name, suffix string) (string, bool) {
	for _, a := range axisNames {
		if name == a+suffix {
			return a, true
		}
	}
	return "", false
}

func (ex *Exec) parseRange(ax *Axis) {
	// at '['
	ex.expectOp("[", "expecting '['")
	if ex.isOp(":") {
		ex.p++
	} else if ex.isOp("]") {
	} else {
		if ex.isOp("*") {
			ex.p++
			ax.autoMin = true
		} else {
			v := ex.evalRangeVal(ax)
			ax.min = v
			ax.autoMin = false
		}
		if ex.isOp(":") {
			ex.p++
		}
	}
	if !ex.isOp("]") {
		if ex.isOp("*") {
			ex.p++
			ax.autoMax = true
		} else {
			v := ex.evalRangeVal(ax)
			ax.max = v
			ax.autoMax = false
		}
	}
	ex.expectOp("]", "expecting ']'")
}

func (ex *Exec) evalRangeVal(ax *Axis) float64 {
	v := ex.evalExpr()
	if v.K == KStr && ax.timeData {
		t, _ := gstrptime(timefmtIn, v.S)
		return t
	}
	return toNum(v).real()
}

func (ex *Exec) skipToEnd() {
	for !ex.atEnd() {
		ex.p++
	}
}

func (ex *Exec) cmdSet() {
	t := ex.cur()
	if t.T != TName {
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
	name := t.S
	ex.p++
	if a, ok := axisPrefix(name, "range"); ok {
		ax := S.axes[a]
		if ex.isOp("[") {
			ex.parseRange(ax)
		}
		for !ex.atEnd() {
			if ex.isName("reverse") {
				ax.reverse = true
			} else if ex.isName("noreverse") {
				ax.reverse = false
			}
			ex.p++
		}
		return
	}
	if a, ok := axisPrefix(name, "label"); ok {
		ax := S.axes[a]
		if !ex.atEnd() {
			ax.label = ex.evalString()
		} else {
			ax.label = ""
		}
		for !ex.atEnd() {
			if ex.isName("offset") {
				ex.p++
				ax.labelOff[0] = ex.evalNum()
				if ex.isOp(",") {
					ex.p++
					ax.labelOff[1] = ex.evalNum()
				}
				continue
			}
			ex.p++
		}
		return
	}
	if a, ok := axisPrefix(name, "tics"); ok {
		ex.setTics(S.axes[a])
		return
	}
	if a, ok := axisPrefix(name, "data"); ok {
		if ex.isName("time") {
			S.axes[a].timeData = true
			ex.p++
		} else {
			S.axes[a].timeData = false
		}
		return
	}
	if strings.HasPrefix(name, "m") {
		if a, ok := axisPrefix(name[1:], "tics"); ok {
			ax := S.axes[a]
			ax.minorTics = -1
			if !ex.atEnd() {
				ax.minorTics = int(ex.evalNum())
			}
			return
		}
	}
	if a, ok := axisPrefix(name, "zeroaxis"); ok {
		if a == "x" {
			S.xzeroaxis = true
		} else if a == "y" {
			S.yzeroaxis = true
		}
		ex.skipToEnd()
		return
	}
	switch {
	case almost(name, "sa$mples"):
		S.samples1 = int(ex.evalNum())
		S.samples2 = S.samples1
		if ex.isOp(",") {
			ex.p++
			S.samples2 = int(ex.evalNum())
		}
	case almost(name, "isos$amples"):
		S.iso1 = int(ex.evalNum())
		S.iso2 = S.iso1
		if ex.isOp(",") {
			ex.p++
			S.iso2 = int(ex.evalNum())
		}
	case almost(name, "tit$le"):
		if ex.atEnd() {
			S.title = ""
		} else {
			S.title = ex.evalString()
		}
		ex.skipToEnd()
	case almost(name, "log$scale"):
		axes := "xyzcb"
		if !ex.atEnd() && ex.cur().T == TName {
			axes = ex.next().S
		}
		base := 10.0
		if !ex.atEnd() {
			base = ex.evalNum()
		}
		for _, a := range splitAxes(axes) {
			S.axes[a].log = true
			S.axes[a].base = base
		}
	case almost(name, "st$yle"):
		ex.setStyle()
	case almost(name, "du$mmy"):
		S.dummy[0] = ex.next().S
		if ex.isOp(",") {
			ex.p++
			S.dummy[1] = ex.next().S
		}
	case almost(name, "time$fmt"):
		S.timefmt = ex.evalString()
		timefmtIn = S.timefmt
	case almost(name, "ta$ble"):
		S.tableOn = true
		S.tableFile = ""
		if !ex.atEnd() {
			if ex.cur().T == TName && strings.HasPrefix(ex.cur().S, "$") {
				S.tableFile = ex.next().S
			} else {
				S.tableFile = ex.evalString()
			}
		}
		ex.skipToEnd()
	case almost(name, "t$erminal"):
		if ex.atEnd() {
			return
		}
		tn := ex.next().S
		switch {
		case almost(tn, "dumb"):
			S.termName = "dumb"
			for !ex.atEnd() {
				if ex.isName("size") {
					ex.p++
					S.termW = int(ex.evalNum())
					ex.expectOp(",", "expecting comma")
					S.termH = int(ex.evalNum())
					continue
				}
				if ex.isName("feed") {
					S.termFeed = true
				} else if ex.isName("nofeed") {
					S.termFeed = false
				}
				ex.p++
			}
		default:
			S.termName = tn
			ex.skipToEnd()
		}
		globals["GPVAL_TERM"] = StrV(S.termName)
	case almost(name, "o$utput"):
		closeTermOutput()
		S.outputFile = ""
		if !ex.atEnd() {
			S.outputFile = ex.evalString()
			f, err := os.Create(S.outputFile)
			if err == nil {
				termOut = f
			}
		}
	case almost(name, "pr$int"):
		flushPrint()
		if printOut != nil {
			printOut.Close()
			printOut = nil
		}
		printToStdout = false
		printFileName = ""
		if !ex.atEnd() {
			var fn string
			if ex.cur().T == TName && strings.HasPrefix(ex.cur().S, "$") {
				fn = ex.next().S
			} else {
				fn = ex.evalString()
			}
			app := false
			if ex.isName("append") {
				app = true
				ex.p++
			}
			printFileName = fn
			if fn == "-" {
				printToStdout = true
			} else {
				var f *os.File
				var err error
				if app {
					f, err = os.OpenFile(fn, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
				} else {
					f, err = os.Create(fn)
				}
				if err != nil {
					gpErrNC("cannot open print file")
				}
				printOut = f
			}
		}
	case almost(name, "param$etric"):
		S.parametric = true
		S.dummy[0] = "t"
	case almost(name, "pol$ar"):
		S.polar = true
		S.dummy[0] = "t"
	case almost(name, "bo$xwidth"):
		if ex.atEnd() {
			S.boxwidth = -1
		} else {
			S.boxwidth = ex.evalNum()
			S.boxwidthRel = false
			if ex.isName("rel$ative") || ex.isName("relative") {
				S.boxwidthRel = true
				ex.p++
			} else if ex.isName("abs$olute") || ex.isName("absolute") {
				ex.p++
			}
		}
	case almost(name, "g$rid"):
		S.grid = true
		ex.skipToEnd()
	case almost(name, "k$ey"):
		ex.setKey()
	case almost(name, "form$at"):
		axes := "xyzcb"
		if !ex.atEnd() && ex.cur().T == TName {
			axes = ex.next().S
		}
		f := "% h"
		if !ex.atEnd() {
			f = ex.evalString()
		}
		for _, a := range splitAxes(axes) {
			S.axes[a].format = f
		}
		ex.skipToEnd()
	case almost(name, "da$tafile"):
		ex.setDatafile()
	case almost(name, "fit"):
		for !ex.atEnd() {
			switch {
			case ex.isName("nolog"):
				S.fitLog = "-"
			case ex.isName("logfile"):
				ex.p++
				S.fitLog = ex.evalString()
				continue
			case ex.isName("quiet"):
				S.fitQuiet = true
			case ex.isName("noquiet"), ex.isName("verbose"), ex.isName("brief"):
				S.fitQuiet = false
			case ex.isName("errorvariables"):
				S.fitErrVars = true
			case ex.isName("noerrorvariables"):
				S.fitErrVars = false
			case ex.isName("covariancevariables"):
				S.fitCovVars = true
			case ex.isName("nocovariancevariables"):
				S.fitCovVars = false
			case ex.isName("prescale"):
				S.fitPrescale = true
			case ex.isName("noprescale"):
				S.fitPrescale = false
			case ex.isName("limit"):
				ex.p++
				S.fitLimit = ex.evalNum()
				continue
			case ex.isName("maxiter"):
				ex.p++
				S.fitMaxIter = int(ex.evalNum())
				continue
			case ex.isName("start_lambda"), ex.isName("start-lambda"):
				ex.p++
				S.fitStartLambda = ex.evalNum()
				continue
			case ex.isName("lambda_factor"):
				ex.p++
				S.fitLambdaFactor = ex.evalNum()
				continue
			}
			ex.p++
		}
	case almost(name, "ang$les"):
		if ex.isName("degrees") || ex.isName("d") || (ex.cur().T == TName && strings.HasPrefix(ex.cur().S, "deg")) {
			angleDegrees = true
		} else {
			angleDegrees = false
		}
		ex.skipToEnd()
	case almost(name, "bor$der"):
		if !ex.atEnd() && ex.cur().T == TNum {
			S.border = int(ex.evalNum())
		} else {
			S.border = 31
		}
		ex.skipToEnd()
	case almost(name, "off$sets"):
		for i := 0; i < 4 && !ex.atEnd(); i++ {
			if ex.isName("graph") || ex.isName("first") {
				ex.p++
			}
			S.offsets[i] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
			}
		}
	case almost(name, "lab$el"):
		ex.setLabel()
	case almost(name, "mu$ltiplot"):
		S.multiplot = true
		ex.skipToEnd()
	case almost(name, "si$ze"), almost(name, "or$igin"), almost(name, "mar$gins"), almost(name, "lm$argin"), almost(name, "rm$argin"), almost(name, "tm$argin"), almost(name, "bm$argin"),
		almost(name, "cl$ip"), almost(name, "ar$row"), almost(name, "obj$ect"), almost(name, "pal$ette"), almost(name, "colorb$ox"), almost(name, "enc$oding"),
		almost(name, "termopt$ion"), almost(name, "loa$dpath"), almost(name, "fontp$ath"), almost(name, "hist$orysize"), almost(name, "ma$cros"), almost(name, "mo$use"),
		almost(name, "ticsl$evel"), almost(name, "xyp$lane"), almost(name, "pm$3d"), almost(name, "lin$etype"), almost(name, "colors$equence"), almost(name, "jitter"), almost(name, "errorbars"), almost(name, "bars"), almost(name, "theta"), almost(name, "rti$cs"):
		ex.skipToEnd()
	case almost(name, "tics"):
		ex.skipToEnd()
	case almost(name, "view"):
		for i := 0; i < 4 && !ex.atEnd(); i++ {
			if ex.isOp(",") {
				ex.p++
				continue
			}
			if ex.cur().T == TName {
				ex.p++
				continue
			}
			S.view[i] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
			}
		}
		ex.skipToEnd()
	case almost(name, "surf$ace"):
		S.surface = true
		ex.skipToEnd()
	case almost(name, "hid$den3d"):
		S.hidden3d = true
		ex.skipToEnd()
	case almost(name, "cont$ours"):
		S.contour = true
		ex.skipToEnd()
	case almost(name, "poi$ntsize"):
		S.pointsize = ex.evalNum()
	case almost(name, "decimals$ign"):
		ex.skipToEnd()
	default:
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

func splitAxes(s string) []string {
	var out []string
	for i := 0; i < len(s); {
		if strings.HasPrefix(s[i:], "x2") || strings.HasPrefix(s[i:], "y2") || strings.HasPrefix(s[i:], "cb") {
			out = append(out, s[i:i+2])
			i += 2
			continue
		}
		out = append(out, s[i:i+1])
		i++
	}
	var ok []string
	for _, a := range out {
		if _, e := S.axes[a]; e {
			ok = append(ok, a)
		}
	}
	return ok
}

func (ex *Exec) setTics(ax *Axis) {
	ax.ticsOn = true
	for !ex.atEnd() {
		switch {
		case ex.isName("nomirror"):
			ax.mirror = false
			ex.p++
		case ex.isName("mirror"):
			ax.mirror = true
			ex.p++
		case ex.isName("format"):
			ex.p++
			ax.format = ex.evalString()
		case ex.isName("add"):
			ax.ticListAdd = true
			ex.p++
		case ex.isOp("("):
			ex.p++
			ax.ticList = nil
			for !ex.isOp(")") && !ex.atEnd() {
				var e ticEntry
				if ex.cur().T == TStr {
					e.label = ex.next().S
					e.hasLb = true
				}
				e.pos = ex.evalNum()
				if !ex.isOp(",") && !ex.isOp(")") {
					ex.evalNum()
				}
				ax.ticList = append(ax.ticList, e)
				if ex.isOp(",") {
					ex.p++
				}
			}
			ex.p++
			ax.ticStep = 0
		case ex.cur().T == TName:
			ex.p++
			if ex.isName("offset") {
			}
		default:
			v := ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				w := ex.evalNum()
				ax.ticStart = v
				ax.ticHasStart = true
				ax.ticStep = w
				ax.ticEnd = math.Inf(1)
				if ex.isOp(",") {
					ex.p++
					ax.ticEnd = ex.evalNum()
				}
			} else {
				ax.ticStep = v
				ax.ticHasStart = false
			}
			ax.ticList = nil
		}
	}
}

func (ex *Exec) setStyle() {
	if ex.isName("data") || ex.isName("d") {
		ex.p++
		S.styleData = ex.parseStyleName()
		ex.skipToEnd()
		return
	}
	if ex.isName("function") || ex.isName("fu") || ex.isName("func") {
		ex.p++
		S.styleFunc = ex.parseStyleName()
		ex.skipToEnd()
		return
	}
	ex.skipToEnd()
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xyerrorb$ars",
	"errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "boxes", "boxerrorb$ars", "boxxyerror", "vec$tors", "fin$ancebars", "candlesticks", "filledc$urves",
	"histograms", "labels", "image", "circles", "ellipses", "zerror", "surface", "pm3d", "table", "parallelaxes", "fillsteps", "arrows", "rgbimage", "spiderplot", "polygons"}

func canonStyle(n string) string {
	for _, s := range styleNames {
		if almost(n, s) {
			c := strings.ReplaceAll(s, "$", "")
			switch c {
			case "lp":
				return "linespoints"
			case "errorbars":
				return "yerrorbars"
			case "errorlines":
				return "yerrorlines"
			}
			return c
		}
	}
	return ""
}

func (ex *Exec) parseStyleName() string {
	t := ex.cur()
	if t.T != TName {
		gpErr(t.Pos, "expecting style name")
	}
	c := canonStyle(t.S)
	if c == "" {
		gpErr(t.Pos, "unrecognized plot type")
	}
	ex.p++
	return c
}

func (ex *Exec) setKey() {
	S.keyOn = true
	for !ex.atEnd() {
		switch {
		case ex.isName("off"):
			S.keyOn = false
		case ex.isName("on"):
			S.keyOn = true
		case ex.isName("left"):
			S.keyLeft = true
			S.keyCenterH = false
		case ex.isName("right"):
			S.keyLeft = false
			S.keyCenterH = false
		case ex.isName("top"):
			S.keyBottom = false
			S.keyCenterV = false
		case ex.isName("bottom"):
			S.keyBottom = true
			S.keyCenterV = false
		case ex.isName("center"):
			S.keyCenterV = true
		case ex.isName("box"):
			S.keyBox = true
		case ex.isName("nobox"):
			S.keyBox = false
		case ex.isName("reverse"):
			S.keyReverse = true
		case ex.isName("noreverse"):
			S.keyReverse = false
		case ex.isName("Left"):
			S.keyJustLeft = true
		case ex.isName("Right"):
			S.keyJustLeft = false
		case ex.isName("outside"):
			S.keyOutside = true
		case ex.isName("inside"):
			S.keyOutside = false
		case ex.isName("title"):
			ex.p++
			if !ex.atEnd() && ex.cur().T == TStr {
				S.keyTitle = ex.evalString()
			}
			continue
		}
		ex.p++
	}
}

func (ex *Exec) setDatafile() {
	if ex.isName("separator") || ex.isName("sep") {
		ex.p++
		if ex.atEnd() || ex.isName("whitespace") {
			S.sepChar = ""
		} else if ex.isName("tab") {
			S.sepChar = "\t"
		} else if ex.isName("comma") {
			S.sepChar = ","
		} else {
			S.sepChar = ex.evalString()
		}
		ex.skipToEnd()
		return
	}
	if ex.isName("missing") {
		ex.p++
		if ex.atEnd() {
			S.hasMissing = false
		} else {
			S.missing = ex.evalString()
			S.hasMissing = true
		}
		return
	}
	ex.skipToEnd()
}

func (ex *Exec) setLabel() {
	lb := &Label{tag: len(S.labels) + 1, just: "left"}
	if ex.cur().T == TNum {
		lb.tag = int(ex.evalNum())
	}
	if ex.cur().T == TStr || (ex.cur().T == TName && !ex.isName("at")) {
		lb.text = ex.evalString()
	}
	for !ex.atEnd() {
		if ex.isName("at") {
			ex.p++
			for _, c := range []string{"first", "graph", "screen", "character"} {
				if ex.isName(c) {
					ex.p++
				}
			}
			lb.x = ex.evalNum()
			ex.expectOp(",", "expecting comma")
			for _, c := range []string{"first", "graph", "screen", "character"} {
				if ex.isName(c) {
					ex.p++
				}
			}
			lb.y = ex.evalNum()
			continue
		}
		if ex.isName("center") || ex.isName("right") || ex.isName("left") {
			lb.just = ex.cur().S
		}
		ex.p++
	}
	// replace same tag
	for i, l := range S.labels {
		if l.tag == lb.tag {
			S.labels[i] = lb
			return
		}
	}
	S.labels = append(S.labels, lb)
}

func (ex *Exec) cmdUnset() {
	t := ex.cur()
	if t.T != TName {
		gpErr(t.Pos, "unrecognized option - see 'help unset'.")
	}
	name := t.S
	ex.p++
	if a, ok := axisPrefix(name, "tics"); ok {
		S.axes[a].ticsOn = false
		return
	}
	if a, ok := axisPrefix(name, "label"); ok {
		S.axes[a].label = ""
		return
	}
	if a, ok := axisPrefix(name, "range"); ok {
		S.axes[a].autoMin, S.axes[a].autoMax = true, true
		return
	}
	if a, ok := axisPrefix(name, "data"); ok {
		S.axes[a].timeData = false
		return
	}
	switch {
	case almost(name, "log$scale"):
		axes := "xyzcbx2y2"
		if !ex.atEnd() {
			axes = ex.next().S
		}
		for _, a := range splitAxes(axes) {
			S.axes[a].log = false
		}
	case almost(name, "ta$ble"):
		S.tableOn = false
	case almost(name, "k$ey"):
		S.keyOn = false
	case almost(name, "tit$le"):
		S.title = ""
	case almost(name, "g$rid"):
		S.grid = false
	case almost(name, "param$etric"):
		S.parametric = false
		S.dummy[0] = "x"
	case almost(name, "pol$ar"):
		S.polar = false
		S.dummy[0] = "x"
	case almost(name, "pr$int"):
		flushPrint()
		if printOut != nil {
			printOut.Close()
			printOut = nil
		}
		printToStdout = false
	case almost(name, "o$utput"):
		closeTermOutput()
		S.outputFile = ""
	case almost(name, "bor$der"):
		S.border = 0
	case almost(name, "mu$ltiplot"):
		S.multiplot = false
	case almost(name, "lab$el"):
		S.labels = nil
		ex.skipToEnd()
	case almost(name, "t$erminal"):
		S.termName = "unknown"
	default:
		ex.skipToEnd()
	}
}

// ---------- show ----------

func showWrite(s string) {
	stdout.Flush()
	os.Stderr.WriteString(s)
}

func fmtRangeNum(ax *Axis, v float64) string {
	if ax.timeData {
		return "\"" + gstrftime(timefmtIn, v) + "\""
	}
	return fmtFloatSpec(fspec{flags: "#", conv: 'g'}, v)
}

func (ex *Exec) cmdShow() {
	t := ex.cur()
	if t.T != TName {
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
	name := t.S
	ex.p++
	if a, ok := axisPrefix(name, "range"); ok {
		ax := S.axes[a]
		var sb strings.Builder
		sb.WriteString("\n")
		if ax.timeData {
			sb.WriteString("\tset " + a + "data time\n")
		}
		sb.WriteString("\tset " + a + "range [ ")
		if ax.autoMin {
			sb.WriteString("*")
		} else {
			sb.WriteString(fmtRangeNum(ax, ax.min))
		}
		sb.WriteString(" : ")
		if ax.autoMax {
			sb.WriteString("*")
		} else {
			sb.WriteString(fmtRangeNum(ax, ax.max))
		}
		sb.WriteString(" ] ")
		if ax.reverse {
			sb.WriteString("reverse")
		} else {
			sb.WriteString("noreverse")
		}
		sb.WriteString(" nowriteback")
		if ax.autoMin || ax.autoMax {
			sb.WriteString(fmt.Sprintf("  # (currently [%s:%s] )", fmtRangeNum(ax, ax.min), fmtRangeNum(ax, ax.max)))
		}
		sb.WriteString("\n\n")
		showWrite(sb.String())
		return
	}
	if a, ok := axisPrefix(name, "label"); ok {
		ax := S.axes[a]
		showWrite(fmt.Sprintf("\n\t%slabel is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", a, ax.label, gnum(ax.labelOff[0]), gnum(ax.labelOff[1])))
		return
	}
	if a, ok := axisPrefix(name, "data"); ok {
		if S.axes[a].timeData {
			showWrite("\n\t" + a + " is set to time\n\n")
		} else {
			showWrite("\n\t" + a + " is set to numerical\n\n")
		}
		return
	}
	switch {
	case almost(name, "sa$mples"):
		showWrite(fmt.Sprintf("\n\tsampling rate is %d, %d\n\n", S.samples1, S.samples2))
	case almost(name, "isos$amples"):
		showWrite(fmt.Sprintf("\n\tiso sampling rate is %d, %d\n\n", S.iso1, S.iso2))
	case almost(name, "log$scale"):
		var sb strings.Builder
		sb.WriteString("\n\tlogscaling on ")
		cnt := 0
		for _, a := range []string{"x", "y", "z", "cb", "x2", "y2"} {
			ax := S.axes[a]
			if ax.log {
				cnt++
				if ax.base == 10 {
					sb.WriteString(" " + a)
				} else {
					sb.WriteString(" " + a + " (base " + gnum(ax.base) + ")")
				}
			}
		}
		if cnt == 0 {
			sb.WriteString("none")
		}
		sb.WriteString("\n\n")
		showWrite(sb.String())
	case almost(name, "tit$le"):
		showWrite(fmt.Sprintf("\n\ttitle is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", S.title))
	case almost(name, "st$yle"):
		if ex.isName("data") {
			ex.p++
			showWrite("\n\tData are plotted with " + S.styleData + "\n\n")
		} else if ex.isName("function") {
			ex.p++
			showWrite("\n\tFunctions are plotted with " + S.styleFunc + "\n\n")
		}
		ex.skipToEnd()
	case almost(name, "ang$les"):
		if angleDegrees {
			showWrite("\n\tAngles are in degrees\n\n")
		} else {
			showWrite("\n\tAngles are in radians\n\n")
		}
	case almost(name, "du$mmy"):
		showWrite(fmt.Sprintf("\n\tdummy variables are %s %s \n\n", S.dummy[0], S.dummy[1]))
	case almost(name, "time$fmt"):
		showWrite(fmt.Sprintf("\n\tDefault format for reading time data is \"%s\"\n\n", S.timefmt))
	case almost(name, "t$erminal"):
		if S.termName == "dumb" {
			feed := "feed"
			if !S.termFeed {
				feed = "nofeed"
			}
			showWrite(fmt.Sprintf("\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", feed, S.termW, S.termH))
		} else {
			showWrite("\n   terminal type is " + S.termName + " \n\n")
		}
	case almost(name, "o$utput"):
		if S.outputFile == "" {
			showWrite("\n\toutput is sent to STDOUT\n\n")
		} else {
			showWrite("\n\toutput is sent to '" + S.outputFile + "'\n\n")
		}
	case almost(name, "ta$ble"):
		if S.tableOn {
			showWrite("\n\ttable mode is on, field separator tab\n\n")
		} else {
			showWrite("\n\ttable mode is off\n\n")
		}
	case almost(name, "param$etric"):
		if S.parametric {
			showWrite("\n\tparametric is ON\n\n")
		} else {
			showWrite("\n\tparametric is OFF\n\n")
		}
	case almost(name, "pr$int"):
		if printOut == nil && !printToStdout {
			showWrite("\n\tprint output is sent to '<stderr>'\n\n")
		} else if printToStdout {
			showWrite("\n\tprint output is sent to '<stdout>'\n\n")
		} else {
			showWrite("\n\tprint output is sent to '" + printFileName + "'\n\n")
		}
	case almost(name, "bo$xwidth"):
		if S.boxwidth < 0 {
			showWrite("\n\tboxwidth is auto\n\tboxdepth is 0\n\n")
		} else {
			r := "absolute"
			if S.boxwidthRel {
				r = "relative"
			}
			showWrite(fmt.Sprintf("\n\tboxwidth is %s %s\n\tboxdepth is 0\n\n", gnum(S.boxwidth), r))
		}
	case almost(name, "g$rid"):
		if !S.grid {
			showWrite("\n\tgrid is OFF\n\n")
		} else {
			showWrite("\n\tRectangular grid drawn at x y tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case almost(name, "v$ariables"):
		ex.showVariables()
	case almost(name, "fu$nctions"):
		var sb strings.Builder
		sb.WriteString("\n\tUser-Defined Functions:\n")
		for _, n := range sortedFuncNames() {
			f := userFuncs[n]
			sb.WriteString(fmt.Sprintf("\t%s(%s) = %s\n", n, strings.Join(f.Params, ","), f.Text))
		}
		sb.WriteString("\n")
		showWrite(sb.String())
	case almost(name, "ver$sion"):
		showWrite("\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		ex.skipToEnd()
	case almost(name, "form$at"):
		var sb strings.Builder
		sb.WriteString("\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			sb.WriteString(fmt.Sprintf("\t  %s-axis: \"%s\"\n", a, S.axes[a].format))
		}
		sb.WriteString("\n")
		showWrite(sb.String())
	case almost(name, "k$ey"):
		ex.showKey()
	case almost(name, "da$tafile"):
		var sb strings.Builder
		sb.WriteString("\n")
		if S.hasMissing {
			sb.WriteString("\t\"" + S.missing + "\" in datafile is interpreted as missing value\n")
		} else {
			sb.WriteString("\tNo missing data string set for datafile\n")
		}
		if S.sepChar == "" {
			sb.WriteString("\tdatafile fields separated by whitespace\n")
		} else {
			sb.WriteString(fmt.Sprintf("\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.sepChar), S.sepChar))
		}
		sb.WriteString("\tComments chars are \"#\"\n\tFirst line is treated as headers only if accessed explicitly\n\n")
		showWrite(sb.String())
	case almost(name, "bor$der"):
		showWrite(fmt.Sprintf("\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.border, S.border))
	case almost(name, "enc$oding"):
		showWrite("\n\tnominal character encoding is utf8\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case almost(name, "decimals$ign"):
		showWrite("\n\tdecimalsign for input is  . \n\tdecimalsign for output has default value (normally '.')\n\tdegree sign for output is \xc2\xb0 \n\n")
	case almost(name, "off$sets"):
		showWrite(fmt.Sprintf("\n\toffsets are %s, %s, %s, %s\n\n", gnum(S.offsets[0]), gnum(S.offsets[1]), gnum(S.offsets[2]), gnum(S.offsets[3])))
	case almost(name, "si$ze"):
		showWrite("\n\tsize is scaled by 1,1\n\tNo attempt to control aspect ratio\n\n")
	case almost(name, "or$igin"):
		showWrite("\n\torigin is set to 0,0\n\n")
	case almost(name, "mar$gins"):
		showWrite("\n\tlmargin is computed automatically\n\trmargin is computed automatically\n\tbmargin is computed automatically\n\ttmargin is computed automatically\n\n")
	case almost(name, "cl$ip"):
		showWrite("\n\tpoint clip is OFF\n\tclipping lines with one end out of range (clip one)\n\tnot drawing lines with both ends out of range (clip two)\n\tnot clipping lines on polar plot at maximum radius\n\n")
	case almost(name, "zero$axis"):
		f := func(b bool) string {
			if b {
				return "ON"
			}
			return "OFF"
		}
		showWrite("\n\txzeroaxis is " + f(S.xzeroaxis) + "\n\n\tx2zeroaxis is OFF\n\n\tyzeroaxis is " + f(S.yzeroaxis) + "\n\n\ty2zeroaxis is OFF\n\n\tzzeroaxis is OFF\n\n")
	case almost(name, "fit"):
		showWrite("\n\tfit will output brief results to console and log-file.\n\tfit can handle up to 12 independent variables\n\tfit will prescale parameters by their initial values\n\tfit will place parameter errors in variables\n\tfit will not place covariances in variables\n\tfit will scale parameter errors with the reduced chi square\n\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n\tfits will be considered to have converged if  delta chisq < chisq * 1e-05\n\tfit has no limit in the number of iterations\n\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
	default:
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
}

func gnum(f float64) string {
	return cfmt("%g", f)
}

func (ex *Exec) showKey() {
	var sb strings.Builder
	if !S.keyOn {
		sb.WriteString("\n\tkey is OFF\n")
	} else {
		v := "top"
		if S.keyBottom {
			v = "bottom"
		} else if S.keyCenterV {
			v = "center"
		}
		h := "right"
		if S.keyLeft {
			h = "left"
		}
		sb.WriteString(fmt.Sprintf("\n\tkey is ON, position: %s %s vertical fixed  offset: (character 0, 0)\n", v, h))
		just := "right"
		if S.keyJustLeft {
			just = "left"
		}
		rev := "not reversed"
		if S.keyReverse {
			rev = "reversed"
		}
		boxed := "not boxed"
		if S.keyBox {
			boxed = "boxed\n\twith linecolor black linewidth 1.000 dashtype solid"
		}
		sb.WriteString(fmt.Sprintf("\tkey is %s justified, %s, not inverted, enhanced and %s\n", just, rev, boxed))
		sb.WriteString("\tsample length is 4 characters\n\tvertical spacing is 1 characters\n\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n")
	}
	sb.WriteString("\n\tkey title is \"" + S.keyTitle + "\" center justified \n\n")
	showWrite(sb.String())
}

func sortedFuncNames() []string {
	// gnuplot lists in reverse definition order? use definition order tracking
	return funcOrder()
}

var funcDefOrder []string

func funcOrder() []string {
	var out []string
	seen := map[string]bool{}
	for _, n := range funcDefOrder {
		if _, ok := userFuncs[n]; ok && !seen[n] {
			out = append(out, n)
			seen[n] = true
		}
	}
	return out
}

var varDefOrder []string

func (ex *Exec) showVariables() {
	prefix := ""
	if !ex.atEnd() {
		if ex.isName("all") {
			ex.p++
		} else {
			prefix = ex.next().S
		}
	}
	var sb strings.Builder
	if prefix == "" {
		sb.WriteString("\n\tUser and default variables:\n")
	} else {
		sb.WriteString("\n\tVariables beginning with " + prefix + ":\n")
	}
	for _, n := range varOrder() {
		if !strings.HasPrefix(n, prefix) || strings.HasPrefix(n, "GPVAL_") || strings.HasPrefix(n, "MOUSE_") {
			continue
		}
		if strings.HasPrefix(n, "$") {
			sb.WriteString(fmt.Sprintf("\t%s = <%d line data block>\n", n, len(datablocks[n])))
			continue
		}
		v := globals[n]
		sb.WriteString("\t" + n + " = " + showVal(v) + "\n")
	}
	sb.WriteString("\n")
	showWrite(sb.String())
}

func showVal(v Value) string {
	switch v.K {
	case KStr:
		return "\"" + v.S + "\""
	case KArr:
		return fmt.Sprintf("<%d element array>", len(v.A.V))
	case KNone:
		return "<undefined>"
	}
	return v.String()
}

func varOrder() []string {
	var out []string
	seen := map[string]bool{}
	for _, n := range []string{"pi", "I", "NaN", "VoxelDistance"} {
		if _, ok := globals[n]; ok {
			out = append(out, n)
			seen[n] = true
		}
	}
	for _, n := range varDefOrder {
		if _, ok := datablocks[n]; ok && !seen[n] && strings.HasPrefix(n, "$") {
			out = append(out, n)
			seen[n] = true
			continue
		}
		if _, ok := globals[n]; ok && !seen[n] {
			out = append(out, n)
			seen[n] = true
		}
	}
	return out
}
