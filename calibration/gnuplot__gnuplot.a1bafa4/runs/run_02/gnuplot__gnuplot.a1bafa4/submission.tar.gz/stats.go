package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                int
	mean, sd, ssd, skew, kurt, adev  float64
	sum, sumsq                       float64
	min, max                         float64
	imin, imax                       int
	median, q1, q3                   float64
	meanErr, sdErr, skewErr, kurtErr float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x >= s.max {
			s.max = x
			s.imax = i
		}
	}
	fn := float64(n)
	s.mean = s.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	s.sd = math.Sqrt(m2 / fn)
	if n > 1 {
		s.ssd = math.Sqrt(m2 / (fn - 1))
	}
	s.adev = ad / fn
	if s.sd != 0 {
		s.skew = (m3 / fn) / (s.sd * s.sd * s.sd)
		s.kurt = (m4 / fn) / (s.sd * s.sd * s.sd * s.sd)
	} else {
		s.skew = math.NaN()
		s.kurt = math.NaN()
	}
	s.meanErr = s.sd / math.Sqrt(fn)
	s.sdErr = s.sd / math.Sqrt(2*fn)
	s.skewErr = math.Sqrt(6 / fn)
	s.kurtErr = math.Sqrt(24 / fn)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	med := func(a []float64) float64 {
		k := len(a)
		if k == 0 {
			return 0
		}
		if k%2 == 1 {
			return a[k/2]
		}
		return (a[k/2-1] + a[k/2]) / 2
	}
	s.median = med(sv)
	h := (n + 1) / 2
	s.q1 = med(sv[:h])
	s.q3 = med(sv[n-h:])
	return s
}

func statNum(x float64) string {
	if math.Abs(x) >= 1e6 {
		return fmtFloatSpec(fspec{flags: "#", prec: ".6", conv: 'g'}, x)
	}
	return cfmt("%.4f", x)
}

func (ex *Exec) parseUsingInto(e *PlotElem) {
	e.usingSet = true
	for {
		if ex.isOp("(") {
			ex.p++
			nd := ex.parseExpr()
			ex.expectOp(")", "')' expected")
			e.using = append(e.using, UsingCol{expr: nd})
		} else if ex.cur().T == TNum {
			e.using = append(e.using, UsingCol{col: int(ex.next().V.real())})
		} else if ex.cur().T == TStr {
			e.using = append(e.using, UsingCol{col: -99, str: ex.next().S})
		} else {
			e.using = append(e.using, UsingCol{expr: ex.parseExpr()})
		}
		if ex.isOp(":") {
			ex.p++
			continue
		}
		break
	}
}

func (ex *Exec) cmdStats() {
	st := ex.cur()
	var src string
	if st.T == TStr {
		src = st.S
		ex.p++
	} else if st.T == TName && strings.HasPrefix(st.S, "$") {
		src = st.S
		ex.p++
	} else {
		gpErr(st.Pos, "stats: expecting a data source")
	}
	e := &PlotElem{lt: -1, pt: -1, src: src, style: "points"}
	e.every = [6]int{1, 1, 0, 0, -1, -1}
	prefix := "STATS"
	output := true
	for !ex.atEnd() {
		t := ex.cur()
		switch {
		case almost(t.S, "u$sing"):
			ex.p++
			ex.parseUsingInto(e)
		case almost(t.S, "i$ndex"):
			ex.p++
			e.indexSet = true
			a := int(ex.evalNum())
			e.index = [3]int{a, a, 1}
			if ex.isOp(":") {
				ex.p++
				e.index[1] = int(ex.evalNum())
			}
		case almost(t.S, "ev$ery"):
			ex.p++
			e.everySet = true
			for k := 0; k < 6; k++ {
				if ex.isOp(":") {
					ex.p++
					continue
				}
				if ex.cur().T == TNum {
					e.every[k] = int(ex.evalNum())
				}
				if ex.isOp(":") {
					ex.p++
				} else {
					break
				}
			}
		case t.S == "name" || t.S == "prefix":
			ex.p++
			prefix = ex.evalString()
		case almost(t.S, "noout$put"):
			ex.p++
			output = false
		case almost(t.S, "out$put"):
			ex.p++
			output = true
		default:
			gpErr(t.Pos, "unrecognized stats option")
		}
	}
	lines := readDataLines(src)
	ncols := 0
	if !e.usingSet {
		for _, l := range lines {
			tl := strings.TrimSpace(l)
			if tl == "" || strings.HasPrefix(tl, "#") {
				continue
			}
			ncols = len(splitFields(l))
			break
		}
		if ncols >= 2 {
			e.using = []UsingCol{{col: 1}, {col: 2}}
		} else {
			e.using = []UsingCol{{col: 1}}
		}
		e.usingSet = true
	}
	twoCol := len(e.using) >= 2
	var xs, ys []float64
	records, invalid, blank, blocks := 0, 0, 0, 0
	dset, block, pidx := 0, 0, 0
	blankRun := 0
	maxCols := 0
	sawData := false
	for _, l := range lines {
		tl := strings.TrimSpace(l)
		if tl == "" {
			blankRun++
			blank++
			continue
		}
		if strings.HasPrefix(tl, "#") {
			continue
		}
		if blankRun > 0 && sawData {
			if blankRun >= 2 {
				dset++
				block = 0
			} else {
				block++
			}
			pidx = 0
		}
		blankRun = 0
		if e.indexSet && (dset < e.index[0] || dset > e.index[1]) {
			continue
		}
		blocks = dset + 1
		sawData = true
		row := makeRow(l)
		if len(row.fields) > maxCols {
			maxCols = len(row.fields)
		}
		row.ptIdx = pidx
		row.block = block
		row.dset = dset
		pidx++
		if e.everySet {
			pi := e.every[0]
			if pi <= 0 {
				pi = 1
			}
			if row.ptIdx < e.every[2] || (e.every[4] >= 0 && row.ptIdx > e.every[4]) || (row.ptIdx-e.every[2])%pi != 0 {
				continue
			}
		}
		curDataRow = row
		rp := evalUsing(e, row, false)
		curDataRow = nil
		if rp == nil || !rp.ok {
			invalid++
			continue
		}
		vals := rp.vals
		if !twoCol {
			ys = append(ys, vals[1])
		} else {
			xs = append(xs, vals[0])
			ys = append(ys, vals[1])
		}
		records++
	}
	if records == 0 {
		gpErrNC("All points out of range")
	}
	setV := func(n string, v Value) { setGlobal(prefix+"_"+n, v) }
	setV("records", IntV(int64(records)))
	setV("invalid", IntV(int64(invalid)))
	setV("headers", IntV(0))
	setV("blank", IntV(int64(blank)))
	setV("blocks", IntV(int64(blocks)))
	setV("outofrange", IntV(0))
	setV("columns", IntV(int64(maxCols)))
	setCol := func(s colStats, suf string) {
		setV("mean"+suf, FltV(s.mean))
		setV("stddev"+suf, FltV(s.sd))
		setV("ssd"+suf, FltV(s.ssd))
		setV("skewness"+suf, FltV(s.skew))
		setV("kurtosis"+suf, FltV(s.kurt))
		setV("adev"+suf, FltV(s.adev))
		setV("mean_err"+suf, FltV(s.meanErr))
		setV("stddev_err"+suf, FltV(s.sdErr))
		setV("skewness_err"+suf, FltV(s.skewErr))
		setV("kurtosis_err"+suf, FltV(s.kurtErr))
		setV("sum"+suf, FltV(s.sum))
		setV("sumsq"+suf, FltV(s.sumsq))
		setV("min"+suf, FltV(s.min))
		setV("max"+suf, FltV(s.max))
		setV("median"+suf, FltV(s.median))
		setV("lo_quartile"+suf, FltV(s.q1))
		setV("up_quartile"+suf, FltV(s.q3))
		setV("index_min"+suf, IntV(int64(s.imin)))
		setV("index_max"+suf, IntV(int64(s.imax)))
	}
	w := len(fmt.Sprint(records))
	var sb strings.Builder
	sb.WriteString("\n* FILE: \n")
	sb.WriteString(fmt.Sprintf("  Records:           %*d\n", w, records))
	sb.WriteString(fmt.Sprintf("  Out of range:      %*d\n", w, 0))
	sb.WriteString(fmt.Sprintf("  Invalid:           %*d\n", w, invalid))
	sb.WriteString(fmt.Sprintf("  Header records:    %*d\n", w, 0))
	sb.WriteString(fmt.Sprintf("  Blank:             %*d\n", w, blank))
	sb.WriteString(fmt.Sprintf("  Data Blocks:       %*d\n", w, blocks))
	lv := func(l string, x float64) string {
		l = "  " + l
		w := 28 - len(l)
		if w < 0 {
			w = 0
		}
		return l + fmt.Sprintf("%*s", w, statNum(x))
	}
	f14 := func(x float64) string { return fmt.Sprintf("%14s", statNum(x)) }
	type row1 struct {
		l string
		v float64
	}
	type row2 struct {
		l    string
		a, b float64
	}
	if !twoCol {
		s := computeStats(ys)
		setCol(s, "")
		sb.WriteString("\n* COLUMN: \n")
		for _, r := range []row1{{"Mean:", s.mean}, {"Std Dev:", s.sd}, {"Sample StdDev:", s.ssd}, {"Skewness:", s.skew}, {"Kurtosis:", s.kurt}, {"Avg Dev:", s.adev}, {"Sum:", s.sum}, {"Sum Sq.:", s.sumsq}} {
			sb.WriteString(lv(r.l, r.v) + "\n")
		}
		sb.WriteString("\n")
		for _, r := range []row1{{"Mean Err.:", s.meanErr}, {"Std Dev Err.:", s.sdErr}, {"Skewness Err.:", s.skewErr}, {"Kurtosis Err.:", s.kurtErr}} {
			sb.WriteString(lv(r.l, r.v) + "\n")
		}
		sb.WriteString("\n")
		sb.WriteString(lv("Minimum:", s.min) + fmt.Sprintf(" [%*d]\n", w, s.imin))
		sb.WriteString(lv("Maximum:", s.max) + fmt.Sprintf(" [%*d]\n", w, s.imax))
		sb.WriteString(lv("Quartile:", s.q1) + " \n")
		sb.WriteString(lv("Median:", s.median) + " \n")
		sb.WriteString(lv("Quartile:", s.q3) + " \n")
		sb.WriteString("\n")
	} else {
		sx := computeStats(xs)
		sy := computeStats(ys)
		setCol(sx, "_x")
		setCol(sy, "_y")
		n := float64(len(xs))
		var sxx, sxy, syy, sumxy float64
		for i := range xs {
			dx := xs[i] - sx.mean
			dy := ys[i] - sy.mean
			sxx += dx * dx
			sxy += dx * dy
			syy += dy * dy
			sumxy += xs[i] * ys[i]
		}
		slope := sxy / sxx
		icept := sy.mean - slope*sx.mean
		ssr := 0.0
		for i := range xs {
			r := ys[i] - (icept + slope*xs[i])
			ssr += r * r
		}
		sres := math.Sqrt(ssr / (n - 2))
		slopeErr := sres / math.Sqrt(sxx)
		iceptErr := sres * math.Sqrt(1/n+sx.mean*sx.mean/sxx)
		corr := sxy / math.Sqrt(sxx*syy)
		setV("slope", FltV(slope))
		setV("intercept", FltV(icept))
		setV("slope_err", FltV(slopeErr))
		setV("intercept_err", FltV(iceptErr))
		setV("correlation", FltV(corr))
		setV("sumxy", FltV(sumxy))
		setV("pos_min_y", FltV(xs[sy.imin]))
		setV("pos_max_y", FltV(xs[sy.imax]))
		pad := strings.Repeat(" ", w+3)
		sb.WriteString("\n* COLUMNS:\n")
		for _, r := range []row2{{"Mean:", sx.mean, sy.mean}, {"Std Dev:", sx.sd, sy.sd}, {"Sample StdDev:", sx.ssd, sy.ssd}, {"Skewness:", sx.skew, sy.skew}, {"Kurtosis:", sx.kurt, sy.kurt}, {"Avg Dev:", sx.adev, sy.adev}, {"Sum:", sx.sum, sy.sum}, {"Sum Sq.:", sx.sumsq, sy.sumsq}} {
			sb.WriteString(lv(r.l, r.a) + pad + f14(r.b) + "\n")
		}
		sb.WriteString("\n")
		for _, r := range []row2{{"Mean Err.:", sx.meanErr, sy.meanErr}, {"Std Dev Err.:", sx.sdErr, sy.sdErr}, {"Skewness Err.:", sx.skewErr, sy.skewErr}, {"Kurtosis Err.:", sx.kurtErr, sy.kurtErr}} {
			sb.WriteString(lv(r.l, r.a) + pad + f14(r.b) + "\n")
		}
		sb.WriteString("\n")
		sb.WriteString(lv("Minimum:", sx.min) + fmt.Sprintf(" [%*d]", w, sx.imin) + f14(sy.min) + fmt.Sprintf(" [%*d]\n", w, sy.imin))
		sb.WriteString(lv("Maximum:", sx.max) + fmt.Sprintf(" [%*d]", w, sx.imax) + f14(sy.max) + fmt.Sprintf(" [%*d]\n", w, sy.imax))
		sb.WriteString(lv("Quartile:", sx.q1) + pad + f14(sy.q1) + "\n")
		sb.WriteString(lv("Median:", sx.median) + pad + f14(sy.median) + "\n")
		sb.WriteString(lv("Quartile:", sx.q3) + pad + f14(sy.q3) + "\n")
		sb.WriteString("\n")
		sign := '+'
		if icept < 0 {
			sign = '-'
		}
		sb.WriteString(fmt.Sprintf("  Linear Model:       y = %s x %c %s\n", cfmt("%.4g", slope), sign, cfmt("%.4g", math.Abs(icept))))
		sb.WriteString(fmt.Sprintf("  Slope:              %s +- %s\n", cfmt("%.4g", slope), cfmt("%.4g", slopeErr)))
		sb.WriteString(fmt.Sprintf("  Intercept:          %s +- %s\n", cfmt("%.4g", icept), cfmt("%.4g", iceptErr)))
		sb.WriteString(fmt.Sprintf("  Correlation:        r = %s\n", cfmt("%.4f", corr)))
		sb.WriteString(fmt.Sprintf("  Sum xy:             %s\n", cfmt("%.4g", sumxy)))
		sb.WriteString("\n")
	}
	if output {
		stdout.Flush()
		if printOut != nil {
			printOut.WriteString(sb.String())
		} else if printToStdout {
			stdout.WriteString(sb.String())
		} else {
			showWrite(sb.String())
		}
	}
}
