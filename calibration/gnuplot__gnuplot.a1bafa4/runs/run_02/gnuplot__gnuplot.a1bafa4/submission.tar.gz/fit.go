package main

import (
	"fmt"
	"math"
	"strings"
)

func (ex *Exec) cmdFit() {
	var ranges []*Axis
	for ex.isOp("[") {
		a := &Axis{autoMin: true, autoMax: true}
		if ex.peek(1).T == TName && ex.peek(2).T == TOp && ex.peek(2).S == "=" {
			ex.p += 2
			ex.toks[ex.p] = Token{T: TOp, S: "[", Pos: ex.toks[ex.p].Pos}
		}
		ex.parseRange(a)
		ranges = append(ranges, a)
	}
	fn := ex.parseExpr()
	st := ex.cur()
	var src string
	if st.T == TStr {
		src = st.S
		ex.p++
	} else if st.T == TName && strings.HasPrefix(st.S, "$") {
		src = st.S
		ex.p++
	} else {
		gpErr(st.Pos, "missing datafile name")
	}
	e := &PlotElem{lt: -1, pt: -1, src: src, style: "points"}
	e.every = [6]int{1, 1, 0, 0, -1, -1}
	var params []string
	for !ex.atEnd() {
		t := ex.cur()
		switch {
		case almost(t.S, "u$sing"):
			ex.p++
			ex.parseUsingInto(e)
		case almost(t.S, "i$ndex"):
			ex.p++
			e.indexSet = true
			a := int(ex.evalNum())
			e.index = [3]int{a, a, 1}
		case almost(t.S, "ev$ery"):
			ex.p++
			e.everySet = true
			for k := 0; k < 6; k++ {
				if ex.isOp(":") {
					ex.p++
					continue
				}
				if ex.cur().T == TNum {
					e.every[k] = int(ex.evalNum())
				}
				if ex.isOp(":") {
					ex.p++
				} else {
					break
				}
			}
		case t.S == "yerror" || t.S == "yerrors" || t.S == "xyerror" || t.S == "xyerrors" || t.S == "zerror" || t.S == "errors" || t.S == "unitweights":
			ex.p++
			for ex.cur().T == TName && !ex.isName("via") {
				ex.p++
				if ex.isOp(",") {
					ex.p++
				}
			}
		case t.S == "via":
			ex.p++
			for {
				tk := ex.next()
				if tk.T != TName {
					gpErr(tk.Pos, "no parameter specified")
				}
				params = append(params, tk.S)
				if ex.isOp(",") {
					ex.p++
					continue
				}
				break
			}
		default:
			gpErr(t.Pos, "unrecognized option")
		}
	}
	if len(params) == 0 {
		gpErr(ex.cur().Pos, "Need via and either parameter list or file")
	}
	if !e.usingSet {
		e.using = []UsingCol{{col: 1}, {col: 2}}
		e.usingSet = true
	}
	lines := readDataLines(src)
	var xs, ys, ws []float64
	dset, block, pidx, blankRun := 0, 0, 0, 0
	for _, l := range lines {
		tl := strings.TrimSpace(l)
		if tl == "" {
			blankRun++
			continue
		}
		if strings.HasPrefix(tl, "#") {
			continue
		}
		if blankRun > 0 {
			if blankRun >= 2 {
				dset++
				block = 0
			} else {
				block++
			}
			pidx = 0
			blankRun = 0
		}
		if e.indexSet && (dset < e.index[0] || dset > e.index[1]) {
			continue
		}
		row := makeRow(l)
		row.ptIdx, row.block, row.dset = pidx, block, dset
		pidx++
		curDataRow = row
		rp := evalUsing(e, row, false)
		curDataRow = nil
		if rp == nil || !rp.ok {
			continue
		}
		x, y := rp.vals[0], rp.vals[1]
		if len(ranges) > 0 && !inRange(ranges[0], x) {
			continue
		}
		w := 1.0
		if len(rp.vals) >= 3 && len(e.using) >= 3 {
			w = rp.vals[2]
		}
		xs = append(xs, x)
		ys = append(ys, y)
		ws = append(ws, w)
	}
	n := len(xs)
	m := len(params)
	p := make([]float64, m)
	for j, name := range params {
		v, ok := globals[name]
		if !ok || !v.isNum() {
			p[j] = 1.0
			setGlobal(name, FltV(1.0))
		} else {
			p[j] = v.real()
		}
	}
	dummy := S.dummy[0]
	model := func(pv []float64) []float64 {
		for j, name := range params {
			globals[name] = FltV(pv[j])
		}
		out := make([]float64, n)
		for i := 0; i < n; i++ {
			v, _ := evalFunc(fn, map[string]Value{dummy: FltV(xs[i])})
			out[i] = v
		}
		return out
	}
	scale := make([]float64, m)
	for j := range p {
		if S.fitPrescale && p[j] != 0 {
			scale[j] = math.Abs(p[j])
		} else {
			scale[j] = 1
		}
	}
	chisqOf := func(f []float64) float64 {
		s := 0.0
		for i := range f {
			r := (ys[i] - f[i]) / ws[i]
			s += r * r
		}
		return s
	}
	jac := func(pv []float64, f0 []float64) [][]float64 {
		J := make([][]float64, n)
		for i := range J {
			J[i] = make([]float64, m)
		}
		for j := 0; j < m; j++ {
			q := append([]float64{}, pv...)
			h := 1e-3 * math.Abs(pv[j])
			if h == 0 {
				h = 1e-30
			}
			q[j] += h
			f1 := model(q)
			for i := 0; i < n; i++ {
				J[i][j] = (f1[i] - f0[i]) / h * scale[j] / ws[i]
			}
		}
		return J
	}
	quiet := S.fitQuiet
	out := func(s string) {
		if !quiet {
			showWrite(s)
		}
	}
	hdr := "iter      chisq       delta/lim  lambda  "
	for _, name := range params {
		hdr += fmt.Sprintf(" %-13s", name)
	}
	hdr += "\n"
	f0 := model(p)
	chisq := chisqOf(f0)
	J := jac(p, f0)
	ss := 0.0
	for i := 0; i < n; i++ {
		for j := 0; j < m; j++ {
			ss += J[i][j] * J[i][j]
		}
	}
	lambda := math.Sqrt(ss / float64(n) / float64(m))
	if S.fitStartLambda > 0 {
		lambda = S.fitStartLambda
	}
	iterLine := func(it int, chi, delta, lam float64, pv []float64) string {
		s := fmt.Sprintf("%4d %-17s%10s %9s ", it, cfmt("%.10e", chi), cfmt("%.2e", delta), cfmt("%.2e", lam))
		for _, v := range pv {
			s += fmt.Sprintf(" %14s", cfmt("%.6e", v))
		}
		return s + "\n"
	}
	out(hdr)
	out(iterLine(0, chisq, 0, lambda, p))
	iter := 0
	lastRel := 0.0
	converged := false
	maxIter := S.fitMaxIter
	for {
		r := make([]float64, n)
		for i := 0; i < n; i++ {
			r[i] = (ys[i] - f0[i]) / ws[i]
		}
		A := make([][]float64, m)
		g := make([]float64, m)
		for a := 0; a < m; a++ {
			A[a] = make([]float64, m)
			for b := 0; b < m; b++ {
				s := 0.0
				for i := 0; i < n; i++ {
					s += J[i][a] * J[i][b]
				}
				A[a][b] = s
			}
			A[a][a] += lambda * lambda
			s := 0.0
			for i := 0; i < n; i++ {
				s += J[i][a] * r[i]
			}
			g[a] = s
		}
		_ = A
		_ = g
		d := givensLS(J, r, lambda)
		np := make([]float64, m)
		for j := range p {
			np[j] = p[j] + d[j]*scale[j]
		}
		f1 := model(np)
		nchi := chisqOf(f1)
		if nchi <= chisq {
			rel := 0.0
			if nchi != 0 {
				rel = (nchi - chisq) / nchi
			}
			lambda /= S.fitLambdaFactor
			iter++
			p = np
			f0 = f1
			chisq = nchi
			lastRel = rel
			out(iterLine(iter, chisq, rel/S.fitLimit, lambda, p))
			J = jac(p, f0)
			if -rel < S.fitLimit {
				converged = true
				break
			}
		} else {
			lambda *= S.fitLambdaFactor
			if lambda > 1e20 {
				break
			}
		}
		if maxIter > 0 && iter >= maxIter {
			break
		}
	}
	for j, name := range params {
		globals[name] = FltV(p[j])
	}
	out(hdr)
	ndf := n - m
	stdfit := math.Sqrt(chisq / float64(ndf))
	A := make([][]float64, m)
	for a := 0; a < m; a++ {
		A[a] = make([]float64, m)
		for b := 0; b < m; b++ {
			s := 0.0
			for i := 0; i < n; i++ {
				s += J[i][a] * J[i][b]
			}
			A[a][b] = s / (scale[a] * scale[b])
		}
	}
	cov := invert(A)
	errs := make([]float64, m)
	for j := 0; j < m; j++ {
		errs[j] = math.Sqrt(cov[j][j] * chisq / float64(ndf))
	}
	var sb strings.Builder
	if converged {
		sb.WriteString(fmt.Sprintf("\nAfter %d iterations the fit converged.\n", iter))
	} else {
		sb.WriteString(fmt.Sprintf("\nAfter %d iterations the fit did not converge.\n", iter))
	}
	sb.WriteString("final sum of squares of residuals : " + cfmt("%g", chisq) + "\n")
	sb.WriteString("rel. change during last iteration : " + cfmt("%g", lastRel) + "\n\n")
	sb.WriteString(fmt.Sprintf("degrees of freedom    (FIT_NDF)                        : %d\n", ndf))
	sb.WriteString("rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : " + cfmt("%g", stdfit) + "\n")
	sb.WriteString("variance of residuals (reduced chisquare) = WSSR/ndf   : " + cfmt("%g", chisq/float64(ndf)) + "\n\n")
	sb.WriteString("Final set of parameters            Asymptotic Standard Error\n")
	sb.WriteString("=======================            ==========================\n")
	for j, name := range params {
		pct := math.Abs(errs[j] / p[j] * 100)
		sb.WriteString(fmt.Sprintf("%-15s = %-15s  +/- %-12s (%s%%)\n", name, cfmt("%g", p[j]), cfmt("%.4g", errs[j]), cfmt("%.4g", pct)))
	}
	sb.WriteString("\ncorrelation matrix of the fit parameters:\n")
	sb.WriteString(strings.Repeat(" ", 16))
	for _, name := range params {
		sb.WriteString(fmt.Sprintf("%-6.6s ", name))
	}
	sb.WriteString("\n")
	for a, name := range params {
		sb.WriteString(fmt.Sprintf("%-15.15s", name))
		for b := 0; b <= a; b++ {
			c := cov[a][b] / math.Sqrt(cov[a][a]*cov[b][b])
			sb.WriteString(fmt.Sprintf("%6s ", cfmt("%.3f", c)))
		}
		sb.WriteString("\n")
	}
	out(sb.String())
	setGlobal("FIT_CONVERGED", boolV(converged))
	setGlobal("FIT_NDF", IntV(int64(ndf)))
	setGlobal("FIT_STDFIT", FltV(stdfit))
	setGlobal("FIT_WSSR", FltV(chisq))
	setGlobal("FIT_P", FltV(1-igamma(float64(ndf)/2, chisq/2)))
	setGlobal("FIT_NITER", IntV(int64(iter)))
	if S.fitErrVars {
		for j, name := range params {
			setGlobal(name+"_err", FltV(errs[j]))
		}
	}
}

func solveLin(A [][]float64, b []float64) []float64 {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		M[c], M[piv] = M[piv], M[c]
		for r := 0; r < n; r++ {
			if r == c || M[c][c] == 0 {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := 0; i < n; i++ {
		x[i] = M[i][n] / M[i][i]
	}
	return x
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for i := range inv {
		inv[i] = make([]float64, n)
	}
	for j := 0; j < n; j++ {
		e := make([]float64, n)
		e[j] = 1
		col := solveLin(A, e)
		for i := 0; i < n; i++ {
			inv[i][j] = col[i]
		}
	}
	return inv
}

// givensLS solves min || [J; lambda I] d - [r; 0] || via Givens rotations.
func givensLS(J [][]float64, r []float64, lambda float64) []float64 {
	n := len(J)
	m := 0
	if n > 0 {
		m = len(J[0])
	}
	rows := n + m
	C := make([][]float64, rows)
	d := make([]float64, rows)
	for i := 0; i < n; i++ {
		C[i] = append([]float64{}, J[i]...)
		d[i] = r[i]
	}
	for j := 0; j < m; j++ {
		C[n+j] = make([]float64, m)
		C[n+j][j] = lambda
	}
	for j := 0; j < m; j++ {
		for i := j + 1; i < rows; i++ {
			if C[i][j] == 0 {
				continue
			}
			a, b := C[j][j], C[i][j]
			var c, s float64
			if math.Abs(a) > math.Abs(b) {
				t := b / a
				c = 1 / math.Sqrt(1+t*t)
				s = c * t
			} else {
				t := a / b
				s = 1 / math.Sqrt(1+t*t)
				c = s * t
			}
			for k := j; k < m; k++ {
				x, y := C[j][k], C[i][k]
				C[j][k] = c*x + s*y
				C[i][k] = -s*x + c*y
			}
			x, y := d[j], d[i]
			d[j] = c*x + s*y
			d[i] = -s*x + c*y
		}
	}
	out := make([]float64, m)
	for j := m - 1; j >= 0; j-- {
		v := d[j]
		for k := j + 1; k < m; k++ {
			v -= C[j][k] * out[k]
		}
		out[j] = v / C[j][j]
	}
	return out
}
