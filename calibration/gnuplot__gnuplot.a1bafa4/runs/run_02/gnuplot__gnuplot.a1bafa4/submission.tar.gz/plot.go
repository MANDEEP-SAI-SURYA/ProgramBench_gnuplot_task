package main

import (
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type DataRow struct {
	fields []string
	nums   []float64
	ok     []bool
	ptIdx  int
	block  int
	dset   int
	header []string
}

type Point struct {
	x, y   float64
	ex     []float64
	typ    byte // i o u
	brk    bool // blank line marker
	label  string
}

type Curve struct {
	title    string
	hasTitle bool
	style    string
	points   []Point
	cols     []string // header column names besides x y
	isFunc   bool
	smooth   string
	origCnt  int
	extraNL  bool
	binsHdr  bool
	lt       int
	pt       int
	axisY2   bool
}

func readDataLines(src string) []string {
	if strings.HasPrefix(src, "$") {
		db, ok := datablocks[src]
		if !ok {
			gpErrNC("undefined datablock " + src)
		}
		return db
	}
	data, err := os.ReadFile(src)
	if err != nil {
		gpErrNC("Cannot find or open file \"" + src + "\"")
	}
	return splitLines(string(data))
}

func splitFields(l string) []string {
	var out []string
	if S.sepChar != "" {
		// separator characters
		cur := ""
		inQ := false
		for i := 0; i < len(l); i++ {
			c := l[i]
			if c == '"' {
				inQ = !inQ
				continue
			}
			if !inQ && strings.IndexByte(S.sepChar, c) >= 0 {
				out = append(out, strings.TrimSpace(cur))
				cur = ""
				continue
			}
			cur += string(c)
		}
		out = append(out, strings.TrimSpace(cur))
		return out
	}
	i := 0
	for i < len(l) {
		for i < len(l) && (l[i] == ' ' || l[i] == '\t') {
			i++
		}
		if i >= len(l) {
			break
		}
		if l[i] == '"' {
			j := i + 1
			for j < len(l) && l[j] != '"' {
				j++
			}
			out = append(out, l[i+1:min(j, len(l))])
			i = j + 1
			continue
		}
		j := i
		for j < len(l) && !(l[j] == ' ' || l[j] == '\t') {
			j++
		}
		out = append(out, l[i:j])
		i = j
	}
	return out
}

func parseFieldNum(s string) (float64, bool) {
	if S.hasMissing && s == S.missing {
		return 0, false
	}
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	// strtod-like: leading numeric prefix
	j := 0
	if j < len(s) && (s[j] == '+' || s[j] == '-') {
		j++
	}
	st := j
	for j < len(s) && isDigit(s[j]) {
		j++
	}
	if j < len(s) && s[j] == '.' {
		j++
		for j < len(s) && isDigit(s[j]) {
			j++
		}
	}
	if j == st || (j == st+1 && s[st] == '.') {
		low := strings.ToLower(s[st:])
		if strings.HasPrefix(low, "nan") {
			return math.NaN(), true
		}
		if strings.HasPrefix(low, "inf") {
			if s[0] == '-' {
				return math.Inf(-1), true
			}
			return math.Inf(1), true
		}
		return 0, false
	}
	if j < len(s) && (s[j] == 'e' || s[j] == 'E' || s[j] == 'd' || s[j] == 'D') {
		k := j + 1
		if k < len(s) && (s[k] == '+' || s[k] == '-') {
			k++
		}
		if k < len(s) && isDigit(s[k]) {
			for k < len(s) && isDigit(s[k]) {
				k++
			}
			j = k
		}
	}
	t := strings.Map(func(r rune) rune {
		if r == 'd' || r == 'D' {
			return 'e'
		}
		return r
	}, s[:j])
	f, err := strconv.ParseFloat(t, 64)
	if err != nil {
		return 0, false
	}
	return f, true
}

func makeRow(l string) *DataRow {
	f := splitFields(l)
	r := &DataRow{fields: f, nums: make([]float64, len(f)), ok: make([]bool, len(f))}
	for i, s := range f {
		r.nums[i], r.ok[i] = parseFieldNum(s)
	}
	return r
}

var colMissingFlag bool

func getColumn(n int) Value {
	r := curDataRow
	if r == nil {
		gpErrNC("column() called from invalid context")
	}
	switch n {
	case 0:
		return FltV(float64(r.ptIdx))
	case -1:
		return FltV(float64(r.block))
	case -2:
		return FltV(float64(r.dset))
	}
	if n < 1 || n > len(r.fields) {
		undefFlag = true
		return FltV(math.NaN())
	}
	if S.hasMissing && r.fields[n-1] == S.missing {
		colMissingFlag = true
		undefFlag = true
		return FltV(math.NaN())
	}
	if !r.ok[n-1] {
		undefFlag = true
		return FltV(math.NaN())
	}
	return FltV(r.nums[n-1])
}

func headerIndex(name string) int {
	r := curDataRow
	if r == nil || r.header == nil {
		return -1
	}
	for i, h := range r.header {
		if h == name {
			return i + 1
		}
	}
	return -1
}

func getColumnByName(name string) Value {
	i := headerIndex(name)
	if i < 0 {
		undefFlag = true
		return FltV(math.NaN())
	}
	return getColumn(i)
}
func getStrColumnByName(name string) Value {
	i := headerIndex(name)
	if i < 0 {
		undefFlag = true
		return StrV("")
	}
	return getStrColumn(i)
}

func getStrColumn(n int) Value {
	r := curDataRow
	if r == nil {
		gpErrNC("column() called from invalid context")
	}
	if n < 1 || n > len(r.fields) {
		undefFlag = true
		return StrV("")
	}
	return StrV(r.fields[n-1])
}

func validColumn(n int) bool {
	r := curDataRow
	if r == nil || n < 1 || n > len(r.fields) {
		return false
	}
	return r.ok[n-1]
}

func columnHead(n int) string {
	r := curDataRow
	if r == nil || r.header == nil || n < 1 || n > len(r.header) {
		return ""
	}
	return r.header[n-1]
}

// ---------- plot command ----------

type UsingCol struct {
	col  int
	expr *Node
	str  string
}

type PlotElem struct {
	isFunc   bool
	fn       *Node
	fnText   string
	src      string
	srcText  string
	using    []UsingCol
	usingSet bool
	every    [6]int
	everySet bool
	index    [3]int
	indexSet bool
	smooth   string
	bins     int
	binsSet  bool
	title    string
	titleSet bool
	noTitle  bool
	style    string
	rng      [2]float64
	rngSet   [2]bool
	lt, pt   int
	ltSet    bool
	axisY2   bool
	colHead  bool
	usingTxt string
}

func (ex *Exec) cmdReplot() {
	if lastPlotLine == "" {
		gpErrNC("no previous plot")
	}
	saved := curLine
	toks, _ := lex(lastPlotLine)
	sub := &Exec{Parser{toks: toks, line: lastPlotLine}}
	sub.p = lastPlotStart
	curLine = lastPlotLine
	sub.cmdPlot(lastPlot3D, true)
	curLine = saved
	ex.skipToEnd()
}

var lastPlotLine string
var lastPlotStart int
var lastPlot3D bool

func (ex *Exec) cmdPlot(is3D bool, replot bool) {
	if !replot {
		lastPlotLine = ex.line
		lastPlotStart = ex.p
		lastPlot3D = is3D
	}
	// ranges
	xr := *S.axes["x"]
	yr := *S.axes["y"]
	zr := *S.axes["z"]
	rangeAxes := []*Axis{&xr, &yr}
	if is3D {
		rangeAxes = []*Axis{&xr, &yr, &zr}
	}
	if S.parametric {
		tr := *S.axes["t"]
		rangeAxes = append([]*Axis{&tr}, rangeAxes...)
	}
	ri := 0
	dummyName := S.dummy[0]
	for ex.isOp("[") {
		// [var=a:b] dummy rename
		if ex.peek(1).T == TName && ex.peek(2).T == TOp && ex.peek(2).S == "=" {
			dummyName = ex.peek(1).S
			ex.p += 2
			ex.toks[ex.p] = Token{T: TOp, S: "[", Pos: ex.toks[ex.p].Pos}
		}
		if ri < len(rangeAxes) {
			ex.parseRange(rangeAxes[ri])
		} else {
			var dummy Axis
			ex.parseRange(&dummy)
		}
		ri++
	}
	var elems []*PlotElem
	for {
		if ex.atEnd() {
			if len(elems) == 0 {
				gpErr(ex.cur().Pos, "function to plot expected")
			}
			break
		}
		// iteration
		if ex.isName("for") {
			ex.p++
			it := ex.parseIter()
			st := ex.p
			vals := it.values()
			old, had := globals[it.varName]
			endp := st
			for _, v := range vals {
				globals[it.varName] = v
				ex.p = st
				elems = append(elems, ex.parsePlotElem(is3D, dummyName))
				endp = ex.p
			}
			if len(vals) == 0 {
				// skip element
				ex.p = st
				ex.parsePlotElem(is3D, dummyName)
				endp = ex.p
			}
			ex.p = endp
			if had {
				globals[it.varName] = old
			} else {
				delete(globals, it.varName)
			}
		} else {
			elems = append(elems, ex.parsePlotElem(is3D, dummyName))
		}
		if ex.isOp(",") {
			ex.p++
			continue
		}
		break
	}
	curves := buildCurves(elems, &xr, &yr, is3D, dummyName)
	if S.tableOn {
		writeTable(curves, is3D)
		return
	}
	switch S.termName {
	case "dumb":
		renderDumb(curves, &xr, &yr, is3D)
	default:
	}
}

func (ex *Exec) parsePlotElem(is3D bool, dummy string) *PlotElem {
	e := &PlotElem{lt: -1, pt: -1}
	e.every = [6]int{1, 1, 0, 0, -1, -1}
	// optional local sampling range
	if ex.isOp("[") {
		var a Axis
		a.autoMin, a.autoMax = true, true
		ex.parseRange(&a)
		if !a.autoMin {
			e.rng[0] = a.min
			e.rngSet[0] = true
		}
		if !a.autoMax {
			e.rng[1] = a.max
			e.rngSet[1] = true
		}
	}
	st := ex.cur()
	isData := false
	if st.T == TStr {
		isData = true
	} else if st.T == TName && strings.HasPrefix(st.S, "$") && (ex.peek(1).T == TEnd || ex.peek(1).T != TOp || ex.peek(1).S != "[") {
		if _, ok := datablocks[st.S]; ok {
			isData = true
		}
	}
	if isData {
		ex.p++
		e.src = st.S
		if st.T == TStr && st.S == "" {
			e.src = lastDataFile
		}
		lastDataFile = e.src
		e.srcText = ex.line[st.Pos:st.End]
		if st.T == TStr {
			e.srcText = st.S
			if !st.Sq {
				e.srcText = st.S
			}
		}
	} else {
		e.isFunc = true
		e.fn = ex.parseExpr()
		e.fnText = strings.TrimSpace(ex.line[st.Pos:ex.cur().Pos])
	}
	titleEnd := ex.cur().Pos
	// modifiers
	for !ex.atEnd() && !ex.isOp(",") {
		t := ex.cur()
		if t.T != TName {
			gpErr(t.Pos, "unexpected or unrecognized token: "+tokText(t))
		}
		switch {
		case almost(t.S, "u$sing"):
			ex.p++
			e.usingSet = true
			ust := ex.cur().Pos
			for {
				if ex.isOp("(") {
					ex.p++
					nd := ex.parseExpr()
					ex.expectOp(")", "')' expected")
					e.using = append(e.using, UsingCol{expr: nd})
				} else if ex.cur().T == TNum {
					e.using = append(e.using, UsingCol{col: int(ex.next().V.real())})
				} else if ex.cur().T == TStr {
					s := ex.next().S
					e.using = append(e.using, UsingCol{col: -99, str: s})
				} else if ex.cur().T == TName && ex.peek(1).T == TOp && ex.peek(1).S == "(" {
					nd := ex.parseExpr()
					e.using = append(e.using, UsingCol{expr: nd, col: -100})
				} else {
					nd := ex.parseExpr()
					e.using = append(e.using, UsingCol{expr: nd})
				}
				if ex.isOp(":") {
					ex.p++
					continue
				}
				break
			}
			e.usingTxt = ex.line[ust:ex.cur().Pos]
			titleEnd = ex.cur().Pos
		case almost(t.S, "ev$ery"):
			ex.p++
			e.everySet = true
			for k := 0; k < 6; k++ {
				if ex.isOp(":") {
					ex.p++
					continue
				}
				if ex.cur().T == TNum || ex.isOp("(") {
					e.every[k] = int(ex.evalNum())
				}
				if ex.isOp(":") {
					ex.p++
				} else {
					break
				}
			}
			titleEnd = ex.cur().Pos
		case almost(t.S, "i$ndex"):
			ex.p++
			e.indexSet = true
			a := int(ex.evalNum())
			e.index = [3]int{a, a, 1}
			if ex.isOp(":") {
				ex.p++
				e.index[1] = int(ex.evalNum())
				if ex.isOp(":") {
					ex.p++
					e.index[2] = int(ex.evalNum())
				}
			}
			titleEnd = ex.cur().Pos
		case almost(t.S, "s$mooth"):
			ex.p++
			e.smooth = ex.next().S
			switch {
			case almost(e.smooth, "u$nique"):
				e.smooth = "unique"
			case almost(e.smooth, "f$requency"):
				e.smooth = "frequency"
			case almost(e.smooth, "cu$mulative"):
				e.smooth = "cumulative"
			case almost(e.smooth, "cn$ormal"):
				e.smooth = "cnormal"
			case almost(e.smooth, "c$splines"):
				e.smooth = "csplines"
			case almost(e.smooth, "a$csplines"):
				e.smooth = "acsplines"
			case almost(e.smooth, "b$ezier"):
				e.smooth = "bezier"
			case almost(e.smooth, "sb$ezier"):
				e.smooth = "sbezier"
			case almost(e.smooth, "k$density"):
				e.smooth = "kdensity"
			case almost(e.smooth, "m$csplines"):
				e.smooth = "mcsplines"
			}
		case t.S == "bins":
			ex.p++
			e.binsSet = true
			e.bins = 0
			if ex.isOp("=") {
				ex.p++
				e.bins = int(ex.evalNum())
			}
		case almost(t.S, "t$itle"):
			ex.p++
			if ex.isName("columnheader") || ex.isName("columnhead") || ex.isName("col") {
				ex.p++
				e.colHead = true
				if ex.isOp("(") {
					ex.p++
					ex.evalNum()
					ex.expectOp(")", "')' expected")
				}
			} else {
				v := ex.evalExpr()
				if v.K == KStr {
					e.title = v.S
				} else {
					e.title = v.String()
				}
			}
			e.titleSet = true
		case almost(t.S, "not$itle"):
			ex.p++
			e.noTitle = true
			if ex.cur().T == TStr {
				ex.p++
			}
		case almost(t.S, "w$ith"):
			ex.p++
			e.style = ex.parseStyleName()
		case almost(t.S, "ax$es"), t.S == "axis":
			ex.p++
			a := ex.next().S
			e.axisY2 = strings.HasSuffix(a, "2")
		case t.S == "lt" || almost(t.S, "linet$ype") || t.S == "ls" || almost(t.S, "lines$tyle") || t.S == "lc" || almost(t.S, "linec$olor"):
			ex.p++
			if ex.isName("rgb") || ex.isName("rgbcolor") {
				ex.p++
				ex.evalExpr()
			} else if ex.isName("palette") || ex.isName("variable") || ex.isName("black") || ex.isName("bgnd") {
				ex.p++
			} else {
				v := ex.evalNum()
				if t.S == "lt" || strings.HasPrefix(t.S, "linet") || t.S == "lc" || strings.HasPrefix(t.S, "linec") {
					e.lt = int(v)
					e.ltSet = true
				}
			}
		case t.S == "pt" || almost(t.S, "pointt$ype"):
			ex.p++
			e.pt = int(ex.evalNum())
		case t.S == "lw" || almost(t.S, "linew$idth") || t.S == "ps" || almost(t.S, "points$ize") || t.S == "dt" || almost(t.S, "dasht$ype") || t.S == "pi" || t.S == "pn" || almost(t.S, "fs") || almost(t.S, "fill$style"):
			ex.p++
			if ex.isName("solid") || ex.isName("empty") || ex.isName("pattern") || ex.isName("transparent") || ex.isName("variable") {
				ex.p++
				if !ex.atEnd() && ex.cur().T == TNum {
					ex.evalNum()
				}
			} else if !ex.atEnd() && !ex.isOp(",") {
				ex.evalExpr()
			}
		case t.S == "nohidden3d" || t.S == "nocontours" || t.S == "nosurface" || t.S == "palette" || t.S == "notitle" || t.S == "noenhanced" || t.S == "enhanced":
			ex.p++
		default:
			gpErr(t.Pos, "unexpected or unrecognized token: "+t.S)
		}
	}
	if !e.titleSet && !e.noTitle {
		if e.isFunc {
			e.title = e.fnText
		} else {
			tt := ex.line[st.Pos:titleEnd]
			tt = strings.TrimSpace(tt)
			if st.T == TStr {
				// gnuplot shows the filename without quotes followed by rest
				rest := strings.TrimSpace(ex.line[st.End:titleEnd])
				tt = st.S
				if rest != "" {
					tt += " " + rest
				}
			}
			e.title = tt
		}
	}
	if e.style == "" {
		if e.isFunc {
			e.style = S.styleFunc
		} else {
			e.style = S.styleData
		}
	}
	return e
}

var lastDataFile string

func sampleRange(xr *Axis, e *PlotElem) (float64, float64) {
	lo, hi := xr.min, xr.max
	if xr.autoMin {
		lo = -10
	}
	if xr.autoMax {
		hi = 10
	}
	if xr.autoMin && !xr.autoMax && hi <= lo {
		lo = hi - 20
	}
	if e.rngSet[0] {
		lo = e.rng[0]
	}
	if e.rngSet[1] {
		hi = e.rng[1]
	}
	return lo, hi
}

func evalFunc(fn *Node, vars map[string]Value) (float64, bool) {
	frames = append(frames, vars)
	defer func() { frames = frames[:len(frames)-1] }()
	undefFlag = false
	v := eval(fn)
	if undefFlag {
		undefFlag = false
		return math.NaN(), false
	}
	if v.K == KStr {
		gpErrNC("all points y value undefined!")
	}
	n := toNum(v)
	if n.K == KCmplx && n.Im != 0 && math.Abs(n.Im) > 1e-15*math.Abs(n.F) {
		return n.F, false
	}
	r := n.real()
	if math.IsNaN(r) || math.IsInf(r, 0) {
		return r, false
	}
	return r, true
}

func inRange(ax *Axis, v float64) bool {
	lo, hi := ax.min, ax.max
	if lo > hi {
		lo, hi = hi, lo
	}
	if !ax.autoMin && v < lo {
		return false
	}
	if !ax.autoMax && v > hi {
		return false
	}
	return true
}

func buildCurves(elems []*PlotElem, xr, yr *Axis, is3D bool, dummy string) []*Curve {
	var curves []*Curve
	for _, e := range elems {
		c := &Curve{title: e.title, hasTitle: !e.noTitle, style: e.style, isFunc: e.isFunc, smooth: e.smooth, lt: e.lt, pt: e.pt, axisY2: e.axisY2}
		if e.isFunc {
			if is3D {
				c.points = sample3D(e, xr, yr, dummy)
			} else if S.parametric {
				tr := S.axes["t"]
				lo, hi := tr.min, tr.max
				if e.rngSet[0] {
					lo = e.rng[0]
				}
				if e.rngSet[1] {
					hi = e.rng[1]
				}
				_ = lo
				_ = hi
				c.points = nil
			} else {
				lo, hi := sampleRange(xr, e)
				n := S.samples1
				for i := 0; i < n; i++ {
					var x float64
					if xr.log {
						llo, lhi := math.Log(lo), math.Log(hi)
						x = math.Exp(llo + float64(i)*(lhi-llo)/float64(n-1))
					} else {
						x = lo + float64(i)*(hi-lo)/float64(n-1)
					}
					y, ok := evalFunc(e.fn, map[string]Value{dummy: FltV(x)})
					p := Point{x: x, y: y, typ: 'i'}
					if !ok {
						p.typ = 'u'
						p.x, p.y = 0, 0
					} else if !inRange(yr, y) {
						p.typ = 'o'
					}
					c.points = append(c.points, p)
				}
			}
			c.origCnt = len(c.points)
			addStyleCols(c)
		} else {
			readDataCurve(e, c, xr, yr, is3D)
		}
		curves = append(curves, c)
	}
	return curves
}

func sample3D(e *PlotElem, xr, yr *Axis, dummy string) []Point {
	var pts []Point
	xlo, xhi := sampleRange(xr, e)
	ylo, yhi := yr.min, yr.max
	if yr.autoMin {
		ylo = -10
	}
	if yr.autoMax {
		yhi = 10
	}
	nx, ny := S.iso1, S.iso2
	for j := 0; j < ny; j++ {
		y := ylo + float64(j)*(yhi-ylo)/float64(ny-1)
		for i := 0; i < S.samples1; i++ {
			x := xlo + float64(i)*(xhi-xlo)/float64(S.samples1-1)
			z, ok := evalFunc(e.fn, map[string]Value{dummy: FltV(x), S.dummy[1]: FltV(y)})
			p := Point{x: x, y: y, ex: []float64{z}, typ: 'i'}
			if !ok {
				p.typ = 'u'
			}
			pts = append(pts, p)
		}
		pts = append(pts, Point{brk: true})
	}
	_ = nx
	return pts
}

func addStyleCols(c *Curve) {
	switch c.style {
	case "yerrorbars", "yerrorlines":
		c.cols = []string{"ylow", "yhigh"}
	case "xerrorbars", "xerrorlines":
		c.cols = []string{"xlow", "xhigh"}
	case "xyerrorbars", "xyerrorlines":
		c.cols = []string{"xlow", "xhigh", "ylow", "yhigh"}
	case "boxes":
		c.cols = []string{"xlow", "xhigh"}
	}
}

type rawPt struct {
	vals []float64
	ok   bool
	brk  bool
	str  string
}

func readDataCurve(e *PlotElem, c *Curve, xr, yr *Axis, is3D bool) {
	lines := readDataLines(e.src)
	dset, block, pidx := 0, 0, 0
	blankRun := 0
	var header []string
	needHeader := e.colHead
	for _, u := range e.using {
		if u.col == -99 {
			needHeader = true
		}
	}
	var raws []rawPt
	everyCount := 0
	firstData := true
	for _, l := range lines {
		tl := strings.TrimSpace(l)
		if tl == "" {
			blankRun++
			continue
		}
		if strings.HasPrefix(tl, "#") {
			continue
		}
		if blankRun > 0 {
			if blankRun >= 2 {
				dset++
				block = 0
			} else {
				block++
			}
			pidx = 0
			everyCount = 0
			if !e.indexSet || (dset >= e.index[0] && dset <= e.index[1]) {
				if len(raws) > 0 {
					raws = append(raws, rawPt{brk: true})
				}
			}
			blankRun = 0
		}
		if e.indexSet && (dset < e.index[0] || dset > e.index[1] || (dset-e.index[0])%e.index[2] != 0) {
			continue
		}
		if !e.indexSet && dset > 0 && firstData {
		}
		row := makeRow(l)
		if needHeader && header == nil {
			header = row.fields
			if e.colHead && e.titleSet {
				// title columnhead: use y column header
			}
			continue
		}
		firstData = false
		row.header = header
		row.ptIdx = pidx
		row.block = block
		row.dset = dset
		pidx++
		// every
		if e.everySet {
			pi, bi := e.every[0], e.every[1]
			sp, sb, ep, eb := e.every[2], e.every[3], e.every[4], e.every[5]
			if pi <= 0 {
				pi = 1
			}
			if bi <= 0 {
				bi = 1
			}
			if row.ptIdx < sp || (ep >= 0 && row.ptIdx > ep) || (row.ptIdx-sp)%pi != 0 {
				continue
			}
			if block < sb || (eb >= 0 && block > eb) || (block-sb)%bi != 0 {
				continue
			}
		}
		everyCount++
		curDataRow = row
		rp := evalUsing(e, row, is3D)
		curDataRow = nil
		if rp == nil {
			continue
		}
		raws = append(raws, *rp)
	}
	if e.colHead && header != nil && !e.titleSet {
		yc := 2
		if len(e.using) >= 2 && e.using[1].col > 0 {
			yc = e.using[1].col
		}
		if yc-1 < len(header) {
			c.title = header[yc-1]
		}
	}
	// convert raws to points
	c.origCnt = len(raws)
	for _, r := range raws {
		if r.brk {
			c.points = append(c.points, Point{brk: true})
			continue
		}
		p := Point{typ: 'i', label: r.str}
		if len(r.vals) >= 2 {
			p.x, p.y = r.vals[0], r.vals[1]
		}
		if len(r.vals) > 2 {
			p.ex = r.vals[2:]
		}
		if !r.ok {
			p.typ = 'u'
		} else if !inRange(xr, p.x) || !inRange(yr, p.y) {
			p.typ = 'o'
		}
		c.points = append(c.points, p)
	}
	addStyleCols(c)
	postProcessStyle(c)
	if e.smooth != "" {
		applySmooth(c, e)
	} else if e.binsSet {
		applyBins(c, e, xr)
	}
}

func evalUsing(e *PlotElem, row *DataRow, is3D bool) *rawPt {
	var cols []UsingCol
	if e.usingSet {
		cols = e.using
	} else {
		n := 2
		if is3D {
			n = 3
		}
		switch e.style {
		case "yerrorbars", "xerrorbars", "boxerrorbars", "yerrorlines", "xerrorlines":
			n = 3
		case "xyerrorbars", "xyerrorlines", "candlesticks", "financebars", "vectors", "boxxyerror":
			n = 4
		}
		if len(row.fields) < n {
			n = len(row.fields)
		}
		if len(row.fields) == 1 && !is3D {
			cols = []UsingCol{{col: 0}, {col: 1}}
		} else {
			for i := 1; i <= n; i++ {
				cols = append(cols, UsingCol{col: i})
			}
		}
	}
	rp := &rawPt{ok: true}
	for _, u := range cols {
		if u.expr != nil {
			undefFlag = false
			v := eval(u.expr)
			if u.col == -100 && v.K == KStr {
				rp.str = v.S
				continue
			}
			if undefFlag {
				undefFlag = false
				rp.ok = false
				rp.vals = append(rp.vals, math.NaN())
				continue
			}
			if v.K == KStr {
				f, ok := parseFieldNum(v.S)
				if !ok {
					rp.ok = false
				}
				rp.vals = append(rp.vals, f)
				continue
			}
			f := toNum(v).real()
			if math.IsNaN(f) || math.IsInf(f, 0) {
				rp.ok = false
			}
			rp.vals = append(rp.vals, f)
			continue
		}
		cn := u.col
		if cn == -99 {
			cn = headerIndex(u.str)
			if cn < 0 {
				return nil
			}
		}
		switch {
		case cn == 0:
			rp.vals = append(rp.vals, float64(row.ptIdx))
		case cn == -1:
			rp.vals = append(rp.vals, float64(row.block))
		case cn == -2:
			rp.vals = append(rp.vals, float64(row.dset))
		case cn > len(row.fields):
			return nil
		default:
			if S.hasMissing && row.fields[cn-1] == S.missing {
				return nil
			}
			if len(rp.vals) == 0 && S.axes["x"].timeData {
				t, ok := gstrptime(timefmtIn, row.fields[cn-1])
				if !ok {
					return nil
				}
				rp.vals = append(rp.vals, t)
				continue
			}
			if !row.ok[cn-1] {
				return nil
			}
			f := row.nums[cn-1]
			if math.IsNaN(f) || math.IsInf(f, 0) {
				rp.ok = false
			}
			rp.vals = append(rp.vals, f)
		}
	}
	if len(rp.vals) == 1 {
		rp.vals = []float64{float64(row.ptIdx), rp.vals[0]}
	}
	return rp
}

func postProcessStyle(c *Curve) {
	for i := range c.points {
		p := &c.points[i]
		if p.brk {
			continue
		}
		switch c.style {
		case "yerrorbars", "yerrorlines":
			if len(p.ex) == 1 {
				d := p.ex[0]
				p.ex = []float64{p.y - d, p.y + d}
			} else if len(p.ex) == 0 {
				p.ex = []float64{p.y, p.y}
			}
		case "xerrorbars", "xerrorlines":
			if len(p.ex) == 1 {
				d := p.ex[0]
				p.ex = []float64{p.x - d, p.x + d}
			}
		case "xyerrorbars", "xyerrorlines":
			if len(p.ex) == 2 {
				dx, dy := p.ex[0], p.ex[1]
				p.ex = []float64{p.x - dx, p.x + dx, p.y - dy, p.y + dy}
			}
		case "boxes":
			if len(p.ex) == 0 {
				w := 0.0
				if S.boxwidth > 0 && !S.boxwidthRel {
					w = S.boxwidth
				}
				p.ex = []float64{p.x - w/2, p.x + w/2}
			} else if len(p.ex) == 1 {
				p.ex = []float64{p.x - p.ex[0]/2, p.x + p.ex[0]/2}
			}
		}
		if p.typ == 'u' && (c.style == "yerrorbars" || c.style == "yerrorlines") {
			p.ex = []float64{-8.98847e+307, -8.98847e+307}
		}
	}
}

func tableNum(f float64) string {
	if math.IsNaN(f) {
		return " NaN"
	}
	return cfmt("% g", f)
}

func writeTable(curves []*Curve, is3D bool) {
	var w func(string)
	var sb strings.Builder
	w = func(s string) { sb.WriteString(s) }
	for i, c := range curves {
		cnt := c.origCnt
		if cnt == 0 {
			cnt = len(c.points)
		}
		if is3D {
			w("\n# Surface " + strconv.Itoa(i) + " of " + strconv.Itoa(len(curves)) + " surfaces\n")
			w("# Curve title: \"" + c.title + "\"\n")
			w("# x y z type\n")
			for _, p := range c.points {
				if p.brk {
					w("\n")
					continue
				}
				z := 0.0
				if len(p.ex) > 0 {
					z = p.ex[0]
				}
				w(tableNum(p.x) + " " + tableNum(p.y) + " " + tableNum(z) + " " + string(p.typ) + "\n")
			}
			w("\n")
			continue
		}
		w("\n# Curve " + strconv.Itoa(i) + " of " + strconv.Itoa(len(curves)) + ", " + strconv.Itoa(cnt) + " points\n")
		if c.hasTitle {
			w("# Curve title: \"" + c.title + "\"\n")
		}
		if c.binsHdr {
			w("# x y  N type\n")
		} else {
			w("# x y " + strings.Join(append(append([]string{}, c.cols...), "type"), " ") + "\n")
		}
		for _, p := range c.points {
			if p.brk {
				w("\n")
				continue
			}
			if c.binsHdr {
				w(tableNum(p.x) + " " + tableNum(p.y) + "     " + strconv.Itoa(int(p.ex[0])) + " " + string(p.typ) + "\n")
				continue
			}
			xs := tableNum(p.x)
			if S.axes["x"].timeData {
				xs = "\"" + gstrftime(S.timefmt, p.x) + "\""
			}
			line := xs + " " + tableNum(p.y)
			for k := range c.cols {
				v := 0.0
				if k < len(p.ex) {
					v = p.ex[k]
				}
				line += " " + tableNum(v)
			}
			w(line + "  " + string(p.typ) + "\n")
		}
		w("\n")
		if c.extraNL {
			w("\n")
		}
	}
	out := sb.String()
	if S.tableFile != "" {
		if strings.HasPrefix(S.tableFile, "$") {
			lines := strings.Split(strings.TrimSuffix(out, "\n"), "\n")
			datablocks[S.tableFile] = append(datablocks[S.tableFile], lines...)
		} else {
			f, err := os.OpenFile(S.tableFile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
			if err == nil {
				f.WriteString(out)
				f.Close()
			}
		}
		return
	}
	termWriter()(out)
}

// ---------- smoothing ----------

func validPts(c *Curve) []Point {
	var out []Point
	for _, p := range c.points {
		if !p.brk && p.typ != 'u' {
			out = append(out, p)
		}
	}
	return out
}

func applySmooth(c *Curve, e *PlotElem) {
	pts := validPts(c)
	orig := append([]Point{}, pts...)
	sort.SliceStable(pts, func(i, j int) bool { return pts[i].x < pts[j].x })
	switch c.smooth {
	case "unique", "frequency", "cumulative", "cnormal":
		var out []Point
		for i := 0; i < len(pts); {
			j := i
			sum := 0.0
			for j < len(pts) && pts[j].x == pts[i].x {
				sum += pts[j].y
				j++
			}
			y := sum
			if c.smooth == "unique" {
				y = sum / float64(j-i)
			}
			out = append(out, Point{x: pts[i].x, y: y, typ: 'i'})
			i = j
		}
		if c.smooth == "cumulative" || c.smooth == "cnormal" {
			acc := 0.0
			for i := range out {
				acc += out[i].y
				out[i].y = acc
			}
			if c.smooth == "cnormal" && acc != 0 {
				for i := range out {
					out[i].y /= acc
				}
			}
		}
		c.points = out
		c.extraNL = true
		c.cols = nil
	case "csplines", "acsplines", "bezier", "sbezier", "kdensity", "mcsplines":
		// merge unique x for splines
		var u []Point
		if c.smooth == "bezier" {
			u = orig
		} else if c.smooth == "kdensity" {
			u = pts
		} else {
			for i := 0; i < len(pts); {
				j := i
				sum := 0.0
				for j < len(pts) && pts[j].x == pts[i].x {
					sum += pts[j].y
					j++
				}
				u = append(u, Point{x: pts[i].x, y: sum / float64(j-i)})
				i = j
			}
		}
		n := S.samples1
		var out []Point
		if len(u) == 0 {
			c.points = nil
			return
		}
		lo, hi := u[0].x, u[len(u)-1].x
		if c.smooth == "kdensity" {
			lo, hi = pts[0].x, pts[len(pts)-1].x
		}
		switch c.smooth {
		case "csplines", "mcsplines", "acsplines":
			ys := naturalSpline(u)
			for i := 0; i < n; i++ {
				x := lo + float64(i)*(hi-lo)/float64(n-1)
				out = append(out, Point{x: x, y: ys(x), typ: 'i'})
			}
		case "bezier", "sbezier":
			ctrl := u
			if c.smooth == "sbezier" {
				ctrl = u
			}
			for i := 0; i < n; i++ {
				t := float64(i) / float64(n-1)
				x, y := bezier(ctrl, t)
				out = append(out, Point{x: x, y: y, typ: 'i'})
			}
		case "kdensity":
			// gaussian KDE with default bandwidth
			m := float64(len(u))
			mean, sd := 0.0, 0.0
			for _, p := range u {
				mean += p.x
			}
			mean /= m
			for _, p := range u {
				sd += (p.x - mean) * (p.x - mean)
			}
			sd = math.Sqrt(sd / m)
			h := 1.06 * sd * math.Pow(m, -0.2)
			if h == 0 {
				h = 1
			}
			for i := 0; i < n; i++ {
				x := lo + float64(i)*(hi-lo)/float64(n-1)
				s := 0.0
				for _, p := range u {
					z := (x - p.x) / h
					s += p.y * math.Exp(-z*z/2) / (h * math.Sqrt(2*math.Pi))
				}
				out = append(out, Point{x: x, y: s, typ: 'i'})
			}
		}
		c.points = out
		c.cols = nil
	}
}

func bezier(p []Point, t float64) (float64, float64) {
	n := len(p) - 1
	x, y := 0.0, 0.0
	for i := 0; i <= n; i++ {
		b := binom(n, i) * math.Pow(t, float64(i)) * math.Pow(1-t, float64(n-i))
		x += b * p[i].x
		y += b * p[i].y
	}
	return x, y
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func naturalSpline(p []Point) func(float64) float64 {
	n := len(p)
	if n < 3 {
		return func(x float64) float64 {
			if n == 1 {
				return p[0].y
			}
			t := (x - p[0].x) / (p[1].x - p[0].x)
			return p[0].y + t*(p[1].y-p[0].y)
		}
	}
	h := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		h[i] = p[i+1].x - p[i].x
	}
	// solve for second derivatives
	a := make([]float64, n)
	b := make([]float64, n)
	cc := make([]float64, n)
	d := make([]float64, n)
	b[0], b[n-1] = 1, 1
	for i := 1; i < n-1; i++ {
		a[i] = h[i-1]
		b[i] = 2 * (h[i-1] + h[i])
		cc[i] = h[i]
		d[i] = 6 * ((p[i+1].y-p[i].y)/h[i] - (p[i].y-p[i-1].y)/h[i-1])
	}
	for i := 1; i < n; i++ {
		m := a[i] / b[i-1]
		b[i] -= m * cc[i-1]
		d[i] -= m * d[i-1]
	}
	M := make([]float64, n)
	M[n-1] = d[n-1] / b[n-1]
	for i := n - 2; i >= 0; i-- {
		M[i] = (d[i] - cc[i]*M[i+1]) / b[i]
	}
	return func(x float64) float64 {
		k := 0
		for k < n-2 && x > p[k+1].x {
			k++
		}
		hh := h[k]
		t1 := p[k+1].x - x
		t2 := x - p[k].x
		return M[k]*t1*t1*t1/(6*hh) + M[k+1]*t2*t2*t2/(6*hh) + (p[k].y/hh-M[k]*hh/6)*t1 + (p[k+1].y/hh-M[k+1]*hh/6)*t2
	}
}

func applyBins(c *Curve, e *PlotElem, xr *Axis) {
	pts := validPts(c)
	if len(pts) == 0 {
		return
	}
	nb := e.bins
	if nb <= 0 {
		nb = S.samples1
	}
	lo, hi := pts[0].x, pts[0].x
	for _, p := range pts {
		lo = math.Min(lo, p.x)
		hi = math.Max(hi, p.x)
	}
	if !xr.autoMin {
		lo = xr.min
	}
	if !xr.autoMax {
		hi = xr.max
	}
	w := (hi - lo) / float64(nb-1)
	if nb == 1 {
		w = hi - lo
	}
	start := lo - w/2
	ys := make([]float64, nb)
	ns := make([]int, nb)
	for _, p := range pts {
		k := int(math.Floor((p.x - start) / w))
		if k < 0 || k >= nb {
			continue
		}
		ys[k] += p.y
		ns[k]++
	}
	var out []Point
	for k := 0; k < nb; k++ {
		if ns[k] == 0 {
			continue
		}
		out = append(out, Point{x: start + (float64(k)+0.5)*w, y: ys[k], ex: []float64{float64(ns[k])}, typ: 'i'})
	}
	c.points = out
	c.origCnt = len(out)
	c.binsHdr = true
	c.cols = nil
}
