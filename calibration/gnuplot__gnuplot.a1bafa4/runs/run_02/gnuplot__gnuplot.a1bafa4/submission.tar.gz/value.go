package main

import (
	"math"
	"strconv"
	"strings"
)

type Kind int

const (
	KNone Kind = iota
	KInt
	KCmplx
	KStr
	KArr
)

type Array struct {
	V []Value
}

type Value struct {
	K  Kind
	I  int64
	F  float64 // real part
	Im float64
	S  string
	A  *Array
}

func IntV(i int64) Value       { return Value{K: KInt, I: i} }
func FltV(f float64) Value     { return Value{K: KCmplx, F: f} }
func CV(r, i float64) Value    { return Value{K: KCmplx, F: r, Im: i} }
func StrV(s string) Value      { return Value{K: KStr, S: s} }
func boolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

func fmtG15(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	return cfmt("%.15g", f)
}

func numStr(f float64) string {
	s := fmtG15(f)
	if math.IsNaN(f) {
		return s
	}
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

func (v Value) String() string {
	switch v.K {
	case KInt:
		return strconv.FormatInt(v.I, 10)
	case KCmplx:
		if v.Im == 0 {
			return numStr(v.F)
		}
		return "{" + numStr(v.F) + ", " + numStr(v.Im) + "}"
	case KStr:
		return v.S
	case KArr:
		var sb strings.Builder
		sb.WriteString("[")
		for i, e := range v.A.V {
			if i > 0 {
				sb.WriteString(",")
			}
			switch e.K {
			case KNone:
			case KStr:
				sb.WriteString("\"" + e.S + "\"")
			default:
				sb.WriteString(e.String())
			}
		}
		sb.WriteString("]")
		return sb.String()
	}
	return ""
}

func (v Value) real() float64 {
	switch v.K {
	case KInt:
		return float64(v.I)
	case KCmplx:
		return v.F
	}
	return 0
}

func (v Value) isNum() bool { return v.K == KInt || v.K == KCmplx }
