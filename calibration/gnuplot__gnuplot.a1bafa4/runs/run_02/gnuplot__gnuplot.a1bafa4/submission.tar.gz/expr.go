package main

import (
	"math"
	"math/cmplx"
	"strings"
)

type Node struct {
	Op   string
	Kids []*Node
	Val  Value
	Name string
	Pos  int
	Fn   *UserFunc
}

type GPError struct {
	Msg     string
	Pos     int // -1 => no caret
	Special bool
}

func gpErr(pos int, msg string) {
	panic(&GPError{Msg: msg, Pos: pos})
}
func gpErrNC(msg string) {
	panic(&GPError{Msg: msg, Pos: -1})
}

// Parser over tokens
type Parser struct {
	toks []Token
	p    int
	line string
}

func (ps *Parser) cur() Token  { return ps.toks[ps.p] }
func (ps *Parser) peek(k int) Token {
	if ps.p+k < len(ps.toks) {
		return ps.toks[ps.p+k]
	}
	return ps.toks[len(ps.toks)-1]
}
func (ps *Parser) isOp(s string) bool {
	t := ps.toks[ps.p]
	return t.T == TOp && t.S == s
}
func (ps *Parser) isName(s string) bool {
	t := ps.toks[ps.p]
	return t.T == TName && t.S == s
}
func (ps *Parser) atEnd() bool {
	t := ps.toks[ps.p]
	return t.T == TEnd || (t.T == TOp && t.S == ";")
}
func (ps *Parser) next() Token {
	t := ps.toks[ps.p]
	if t.T != TEnd {
		ps.p++
	}
	return t
}
func (ps *Parser) expectOp(s string, msg string) {
	if !ps.isOp(s) {
		gpErr(ps.cur().Pos, msg)
	}
	ps.p++
}

// parseExpr parses a full expression including assignment (no serial comma)
func (ps *Parser) parseExpr() *Node {
	t := ps.cur()
	if ps.atEnd() {
		gpErr(t.Pos, "constant expression required")
	}
	if t.T == TName && ps.peek(1).T == TOp && ps.peek(1).S == "=" && !strings.HasPrefix(t.S, "$") {
		ps.p += 2
		rhs := ps.parseExpr()
		return &Node{Op: "assign", Name: t.S, Kids: []*Node{rhs}, Pos: t.Pos}
	}
	// array element assignment A[i] = expr
	if t.T == TName && ps.peek(1).T == TOp && ps.peek(1).S == "[" {
		// scan for matching ] followed by =
		d := 0
		k := ps.p + 1
		for ; k < len(ps.toks); k++ {
			tk := ps.toks[k]
			if tk.T == TEnd {
				break
			}
			if tk.T == TOp && tk.S == "[" {
				d++
			} else if tk.T == TOp && tk.S == "]" {
				d--
				if d == 0 {
					break
				}
			}
		}
		if k+1 < len(ps.toks) && ps.toks[k+1].T == TOp && ps.toks[k+1].S == "=" {
			if v, ok := globals[t.S]; ok && v.K == KArr {
				ps.p += 2
				idx := ps.parseExpr()
				ps.expectOp("]", "']' expected")
				ps.p++
				rhs := ps.parseExpr()
				return &Node{Op: "aassign", Name: t.S, Kids: []*Node{idx, rhs}, Pos: t.Pos}
			}
		}
	}
	return ps.parseTernary()
}

func (ps *Parser) parseTernary() *Node {
	c := ps.parseBin(0)
	if ps.isOp("?") {
		pos := ps.cur().Pos
		ps.p++
		a := ps.parseExpr()
		if !ps.isOp(":") {
			gpErr(ps.cur().Pos, "expecting ':'")
		}
		ps.p++
		b := ps.parseExpr()
		return &Node{Op: "?:", Kids: []*Node{c, a, b}, Pos: pos}
	}
	return c
}

var binLevels = [][]string{
	{"||"}, {"&&"}, {"|"}, {"^"}, {"&"}, {"==", "!=", "eq", "ne"}, {"<", "<=", ">", ">="}, {"<<", ">>"}, {"+", "-", "."}, {"*", "/", "%"},
}

func (ps *Parser) matchBin(level int) string {
	t := ps.cur()
	for _, o := range binLevels[level] {
		if (t.T == TOp || (t.T == TName && (o == "eq" || o == "ne"))) && t.S == o {
			return o
		}
	}
	return ""
}

func (ps *Parser) parseBin(level int) *Node {
	if level >= len(binLevels) {
		return ps.parseUnary()
	}
	l := ps.parseBin(level + 1)
	for {
		o := ps.matchBin(level)
		if o == "" {
			return l
		}
		pos := ps.cur().Pos
		ps.p++
		r := ps.parseBin(level + 1)
		l = &Node{Op: o, Kids: []*Node{l, r}, Pos: pos}
	}
}

func (ps *Parser) parseUnary() *Node {
	t := ps.cur()
	if t.T == TOp {
		switch t.S {
		case "-", "+", "!", "~":
			ps.p++
			k := ps.parseUnary()
			return &Node{Op: "u" + t.S, Kids: []*Node{k}, Pos: t.Pos}
		}
	}
	return ps.parsePow()
}

func (ps *Parser) parsePow() *Node {
	b := ps.parsePostfix()
	if ps.isOp("**") {
		pos := ps.cur().Pos
		ps.p++
		e := ps.parseUnary()
		return &Node{Op: "**", Kids: []*Node{b, e}, Pos: pos}
	}
	return b
}

func (ps *Parser) parsePostfix() *Node {
	n := ps.parsePrimary()
	for {
		if ps.isOp("!") && !(ps.peek(1).T == TOp && ps.peek(1).S == "=") {
			pos := ps.cur().Pos
			ps.p++
			n = &Node{Op: "fact", Kids: []*Node{n}, Pos: pos}
			continue
		}
		if ps.isOp("[") {
			pos := ps.cur().Pos
			ps.p++
			var a, b *Node
			if !ps.isOp(":") {
				a = ps.parseExpr()
			}
			if ps.isOp(":") {
				ps.p++
				if !ps.isOp("]") {
					b = ps.parseExpr()
				}
				ps.expectOp("]", "']' expected")
				n = &Node{Op: "substr", Kids: []*Node{n, a, b}, Pos: pos}
				continue
			}
			ps.expectOp("]", "']' expected")
			n = &Node{Op: "index", Kids: []*Node{n, a}, Pos: pos}
			continue
		}
		return n
	}
}

func (ps *Parser) parsePrimary() *Node {
	t := ps.cur()
	switch t.T {
	case TNum:
		ps.p++
		return &Node{Op: "const", Val: t.V, Pos: t.Pos}
	case TStr:
		ps.p++
		return &Node{Op: "const", Val: StrV(t.S), Pos: t.Pos}
	case TName:
		if strings.HasPrefix(t.S, "$") {
			ps.p++
			s := t.S[1:]
			if len(s) > 0 && isDigit(s[0]) {
				num := 0
				for _, c := range s {
					num = num*10 + int(c-'0')
				}
				return &Node{Op: "col", Val: IntV(int64(num)), Pos: t.Pos}
			}
			if s == "" {
				// $(expr)
				if ps.isOp("(") {
					ps.p++
					e := ps.parseExpr()
					ps.expectOp(")", "')' expected")
					return &Node{Op: "colx", Kids: []*Node{e}, Pos: t.Pos}
				}
				gpErr(t.Pos, "invalid expression")
			}
			if ps.isOp("[") {
				// datablock line index
				return &Node{Op: "dbvar", Name: t.S, Pos: t.Pos}
			}
			return &Node{Op: "dbvar", Name: t.S, Pos: t.Pos}
		}
		if t.S == "sum" && ps.peek(1).T == TOp && ps.peek(1).S == "[" {
			ps.p += 2
			vn := ps.cur()
			if vn.T != TName {
				gpErr(vn.Pos, "Expecting iterator \tsum [<var> = <start>:<end>] <expression>")
			}
			ps.p++
			ps.expectOp("=", "Expecting iterator \tsum [<var> = <start>:<end>] <expression>")
			a := ps.parseExpr()
			ps.expectOp(":", "Expecting iterator \tsum [<var> = <start>:<end>] <expression>")
			b := ps.parseExpr()
			ps.expectOp("]", "Expecting iterator \tsum [<var> = <start>:<end>] <expression>")
			body := ps.parseUnaryNoPostfixLimit()
			return &Node{Op: "sum", Name: vn.S, Kids: []*Node{a, b, body}, Pos: t.Pos}
		}
		if ps.peek(1).T == TOp && ps.peek(1).S == "(" {
			ps.p += 2
			var args []*Node
			if ps.isOp(")") {
				gpErr(ps.cur().Pos, "invalid expression ")
			}
			{
				for {
					args = append(args, ps.parseExpr())
					if ps.isOp(",") {
						ps.p++
						continue
					}
					break
				}
			}
			ps.expectOp(")", "')' expected")
			nd := &Node{Op: "call", Name: t.S, Kids: args, Pos: t.Pos}
			if _, ok := builtins[t.S]; !ok {
				if _, ok2 := userFuncs[t.S]; !ok2 {
					gpErrNC("undefined function: "+t.S)
				}
			}
			return nd
		}
		ps.p++
		return &Node{Op: "var", Name: t.S, Pos: t.Pos}
	case TOp:
		switch t.S {
		case "(":
			ps.p++
			e := ps.parseExpr()
			for ps.isOp(",") {
				ps.p++
				e2 := ps.parseExpr()
				e = &Node{Op: ",", Kids: []*Node{e, e2}, Pos: t.Pos}
			}
			ps.expectOp(")", "')' expected")
			return e
		case "{":
			ps.p++
			re := ps.parseExpr()
			ps.expectOp(",", "',' expected")
			im := ps.parseExpr()
			ps.expectOp("}", "'}' expected")
			return &Node{Op: "cmplx", Kids: []*Node{re, im}, Pos: t.Pos}
		case "|":
			ps.p++
			e := ps.parseBin(3) // above |
			ps.expectOp("|", "'|' expected")
			return &Node{Op: "card", Kids: []*Node{e}, Pos: t.Pos}
		case "[!":
			// array literal
			ps.p++
			var els []*Node
			if !ps.isOp("]") {
				for {
					els = append(els, ps.parseExpr())
					if ps.isOp(",") {
						ps.p++
						continue
					}
					break
				}
			}
			ps.expectOp("]", "']' expected")
			return &Node{Op: "arrlit", Kids: els, Pos: t.Pos}
		}
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (ps *Parser) parseUnaryNoPostfixLimit() *Node {
	return ps.parseUnary()
}

// ---------------- evaluation ----------------

type UserFunc struct {
	Name   string
	Params []string
	Body   *Node
	Text   string
}

var globals = map[string]Value{}
var userFuncs = map[string]*UserFunc{}
var frames []map[string]Value
var undefFlag bool
var curDataRow *DataRow // for column()

func lookupVar(name string, pos int) Value {
	if len(frames) > 0 {
		if v, ok := frames[len(frames)-1][name]; ok {
			return v
		}
	}
	if v, ok := globals[name]; ok {
		if v.K == KNone {
			gpErrNC("undefined variable: " + name)
		}
		return v
	}
	gpErrNC("undefined variable: " + name)
	return Value{}
}

func toNum(v Value) Value {
	switch v.K {
	case KInt, KCmplx:
		return v
	case KStr:
		s := strings.TrimSpace(v.S)
		f, ok := parseLeadingFloat(s)
		if !ok {
			gpErrNC("Non-numeric string found where a numeric expression was expected")
		}
		_ = f
		return f
	case KArr:
		gpErrNC("non-scalar value where a number was expected") // approx
	}
	gpErrNC("Non-numeric string found where a numeric expression was expected")
	return Value{}
}

// parseLeadingFloat parses a number at the start of s (strtod like).
func parseLeadingFloat(s string) (Value, bool) {
	toks, err := lex(s)
	if err != nil || len(toks) < 1 {
		return Value{}, false
	}
	neg := false
	i := 0
	if toks[0].T == TOp && (toks[0].S == "-" || toks[0].S == "+") {
		neg = toks[0].S == "-"
		i = 1
	}
	if toks[i].T != TNum {
		return Value{}, false
	}
	v := toks[i].V
	if v.K == KInt {
		// gnuplot converts strings via strtod -> float? keep int when integral
		f := float64(v.I)
		if neg {
			f = -f
		}
		if strings.ContainsAny(toks[i].S, ".eE") {
			return FltV(f), true
		}
		x := v.I
		if neg {
			x = -x
		}
		return IntV(x), true
	}
	if neg {
		v.F = -v.F
	}
	return v, true
}

func isTrue(v Value, pos int) bool {
	switch v.K {
	case KInt:
		return v.I != 0
	case KCmplx:
		return v.F != 0 || v.Im != 0
	case KStr:
		n := toNum(v)
		return isTrue(n, pos)
	}
	gpErrNC("non-numeric argument")
	return false
}

func asInt(v Value, op string) int64 {
	v = toNum(v)
	if v.K != KInt {
		gpErrNC("non-integer operand for " + op)
	}
	return v.I
}

func eval(n *Node) Value {
	switch n.Op {
	case "const":
		return n.Val
	case "var":
		return lookupVar(n.Name, n.Pos)
	case "dbvar":
		if db, ok := datablocks[n.Name]; ok {
			_ = db
			return StrV(n.Name)
		}
		if v, ok := globals[n.Name]; ok {
			return v
		}
		gpErrNC("undefined variable: " + n.Name)
	case "assign":
		v := eval(n.Kids[0])
		if v.K == KArr && n.Kids[0].Op == "arrlit" {
			globals[n.Name] = v
			return v
		}
		if old, ok := globals[n.Name]; ok && old.K == KArr && v.K != KArr {
			// assigning scalar to array name replaces it
		}
		setGlobal(n.Name, v)
		return v
	case "aassign":
		arr := globals[n.Name]
		iv := toNum(eval(n.Kids[0]))
		idx := int(iv.real())
		v := eval(n.Kids[1])
		if idx < 1 || idx > len(arr.A.V) {
			gpErrNC("array index out of range")
		}
		arr.A.V[idx-1] = v
		return v
	case "arrlit":
		a := &Array{}
		for _, k := range n.Kids {
			a.V = append(a.V, eval(k))
		}
		return Value{K: KArr, A: a}
	case ",":
		eval(n.Kids[0])
		return eval(n.Kids[1])
	case "?:":
		c := eval(n.Kids[0])
		if isTrue(c, n.Pos) {
			return eval(n.Kids[1])
		}
		return eval(n.Kids[2])
	case "cmplx":
		re := toNum(eval(n.Kids[0]))
		im := toNum(eval(n.Kids[1]))
		return CV(re.real(), im.real())
	case "card":
		v := eval(n.Kids[0])
		if v.K == KArr {
			return IntV(int64(len(v.A.V)))
		}
		if v.K == KStr {
			if db, ok := datablocks[v.S]; ok {
				return IntV(int64(len(db)))
			}
		}
		gpErrNC("cardinality of a non-array")
	case "u-":
		v := toNum(eval(n.Kids[0]))
		if v.K == KInt {
			return IntV(-v.I)
		}
		return CV(-v.F, -v.Im)
	case "u+":
		return toNum(eval(n.Kids[0]))
	case "u!":
		v := eval(n.Kids[0])
		return boolV(!isTrue(v, n.Pos))
	case "u~":
		v := eval(n.Kids[0])
		return IntV(^asInt(v, "~"))
	case "fact":
		v := toNum(eval(n.Kids[0]))
		if v.K != KInt {
			gpErrNC("factorial (!) argument must be an integer")
		}
		if v.I <= 20 {
			r := int64(1)
			for i := int64(2); i <= v.I; i++ {
				r *= i
			}
			return IntV(r)
		}
		r := 1.0
		for i := int64(2); i <= v.I; i++ {
			r *= float64(i)
		}
		return FltV(r)
	case "index":
		base := eval(n.Kids[0])
		iv := eval(n.Kids[1])
		if base.K == KArr {
			iv = toNum(iv)
			idx := iv.real()
			i := int(idx)
			if i < 1 || i > len(base.A.V) {
				gpErrNC("array index out of range")
			}
			e := base.A.V[i-1]
			if e.K == KNone {
				gpErrNC("undefined array element")
			}
			return e
		}
		if base.K == KStr {
			if db, ok := datablocks[base.S]; ok {
				i := int(toNum(iv).real())
				if i < 1 || i > len(db) {
					gpErrNC("index out of range")
				}
				return StrV(db[i-1])
			}
		}
		gpErr(n.Pos, "unexpected or unrecognized token")
	case "substr":
		base := eval(n.Kids[0])
		if base.K != KStr {
			gpErrNC("internal error : substring range operator applied to non-STRING type")
		}
		s := base.S
		beg := int64(1)
		end := int64(len(s))
		if n.Kids[1] != nil {
			beg = int64(toNum(eval(n.Kids[1])).real())
		}
		if n.Kids[2] != nil {
			end = int64(toNum(eval(n.Kids[2])).real())
		}
		return StrV(substrG(s, beg, end))
	case "sum":
		a := toNum(eval(n.Kids[0]))
		b := toNum(eval(n.Kids[1]))
		if a.K != KInt || b.K != KInt {
			gpErrNC("range specifiers of sum must have integer values")
		}
		old, had := globals[n.Name]
		var acc Value = IntV(0)
		for i := a.I; i <= b.I; i++ {
			globals[n.Name] = IntV(i)
			acc = arith("+", acc, toNum(eval(n.Kids[2])))
		}
		if had {
			globals[n.Name] = old
		} else {
			delete(globals, n.Name)
		}
		return acc
	case "col":
		return getColumn(int(n.Val.I))
	case "colx":
		v := eval(n.Kids[0])
		if v.K == KStr {
			return getColumnByName(v.S)
		}
		return getColumn(int(toNum(v).real()))
	case "call":
		return callFunc(n)
	case "&&":
		if !isTrue(eval(n.Kids[0]), n.Pos) {
			return IntV(0)
		}
		return boolV(isTrue(eval(n.Kids[1]), n.Pos))
	case "||":
		if isTrue(eval(n.Kids[0]), n.Pos) {
			return IntV(1)
		}
		return boolV(isTrue(eval(n.Kids[1]), n.Pos))
	case ".":
		a := eval(n.Kids[0])
		b := eval(n.Kids[1])
		if a.K != KStr {
			gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		if b.K != KStr {
			if b.K == KArr {
				gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
			}
			b = StrV(b.String())
		}
		return StrV(a.S + b.S)
	case "eq", "ne":
		a := eval(n.Kids[0])
		b := eval(n.Kids[1])
		if a.K != KStr || b.K != KStr {
			gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		if n.Op == "eq" {
			return boolV(a.S == b.S)
		}
		return boolV(a.S != b.S)
	}
	if len(n.Kids) == 2 {
		a := eval(n.Kids[0])
		b := eval(n.Kids[1])
		return binop(n.Op, a, b)
	}
	gpErr(n.Pos, "invalid expression")
	return Value{}
}

func substrG(s string, beg, end int64) string {
	// gnuplot uses UTF-8 aware? use bytes
	r := []rune(s)
	l := int64(len(r))
	if beg < 1 {
		beg = 1
	}
	if end > l {
		end = l
	}
	if beg > end {
		return ""
	}
	return string(r[beg-1 : end])
}

func binop(op string, a, b Value) Value {
	switch op {
	case "+", "-", "*", "/", "**":
		return arith(op, toNum(a), toNum(b))
	case "%":
		x := toNum(a)
		y := toNum(b)
		if x.K != KInt || y.K != KInt {
			gpErrNC("non-integer operand for %")
		}
		if y.I == 0 {
			undefFlag = true
			return IntV(0)
		}
		return IntV(x.I % y.I)
	case "&":
		return IntV(asInt(a, "&") & asInt(b, "&"))
	case "|":
		return IntV(asInt(a, "|") | asInt(b, "|"))
	case "^":
		return IntV(asInt(a, "^") ^ asInt(b, "^"))
	case "<<":
		return IntV(int64(uint64(asInt(a, "<<")) << uint64(asInt(b, "<<"))))
	case ">>":
		return IntV(int64(uint64(asInt(a, ">>")) >> uint64(asInt(b, ">>"))))
	case "==", "!=", "<", "<=", ">", ">=":
		x := toNum(a)
		y := toNum(b)
		var r bool
		if x.K == KInt && y.K == KInt {
			switch op {
			case "==":
				r = x.I == y.I
			case "!=":
				r = x.I != y.I
			case "<":
				r = x.I < y.I
			case "<=":
				r = x.I <= y.I
			case ">":
				r = x.I > y.I
			case ">=":
				r = x.I >= y.I
			}
		} else {
			xf, yf := x.real(), y.real()
			switch op {
			case "==":
				r = xf == yf && x.Im == y.Im
			case "!=":
				r = !(xf == yf && x.Im == y.Im)
			case "<":
				r = xf < yf
			case "<=":
				r = xf <= yf
			case ">":
				r = xf > yf
			case ">=":
				r = xf >= yf
			}
		}
		return boolV(r)
	}
	gpErrNC("unknown operator " + op)
	return Value{}
}

func arith(op string, a, b Value) Value {
	if a.K == KInt && b.K == KInt {
		x, y := a.I, b.I
		switch op {
		case "+":
			r := x + y
			if (x >= 0) == (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) + float64(y))
			}
			return IntV(r)
		case "-":
			r := x - y
			if (x >= 0) != (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) - float64(y))
			}
			return IntV(r)
		case "*":
			if x == 0 || y == 0 {
				return IntV(0)
			}
			r := x * y
			if r/y != x || (x == -1 && y == math.MinInt64) || (y == -1 && x == math.MinInt64) {
				return FltV(float64(x) * float64(y))
			}
			return IntV(r)
		case "/":
			if y == 0 {
				undefFlag = true
				return IntV(0)
			}
			return IntV(x / y)
		case "**":
			if y < 0 {
				if x == 1 {
					return IntV(1)
				}
				if x == -1 {
					if y%2 == 0 {
						return IntV(1)
					}
					return IntV(-1)
				}
				if x == 0 {
					undefFlag = true
					return IntV(0)
				}
				return FltV(math.Pow(float64(x), float64(y)))
			}
			r := int64(1)
			ov := false
			for i := int64(0); i < y; i++ {
				nr := r * x
				if x != 0 && nr/x != r {
					ov = true
					break
				}
				r = nr
				if r == 0 || r == 1 && x == 1 {
					break
				}
			}
			if ov {
				return FltV(math.Pow(float64(x), float64(y)))
			}
			return IntV(r)
		}
	}
	ar, ai := a.real(), a.Im
	br, bi := b.real(), b.Im
	if a.K == KInt {
		ai = 0
	}
	if b.K == KInt {
		bi = 0
	}
	switch op {
	case "+":
		return CV(ar+br, ai+bi)
	case "-":
		return CV(ar-br, ai-bi)
	case "*":
		if ai == 0 && bi == 0 {
			return FltV(ar * br)
		}
		return CV(ar*br-ai*bi, ar*bi+ai*br)
	case "/":
		if ai == 0 && bi == 0 {
			if br == 0 {
				undefFlag = true
				return FltV(0)
			}
			return FltV(ar / br)
		}
		sq := br*br + bi*bi
		if sq == 0 {
			undefFlag = true
			return FltV(0)
		}
		return CV((ar*br+ai*bi)/sq, (ai*br-ar*bi)/sq)
	case "**":
		if ai == 0 && bi == 0 {
			if b.K == KInt {
				// real base, integer exponent
				return FltV(math.Pow(ar, br))
			}
			if ar >= 0 {
				if ar == 0 && br < 0 {
					undefFlag = true
					return FltV(0)
				}
				return FltV(math.Pow(ar, br))
			}
		}
		if ar == 0 && ai == 0 {
			if br == 0 && bi == 0 {
				return FltV(1)
			}
			return FltV(0)
		}
		r := cmplx.Pow(complex(ar, ai), complex(br, bi))
		return CV(real(r), imag(r))
	}
	return Value{}
}

func setGlobal(name string, v Value) {
	if _, ok := globals[name]; !ok {
		varDefOrder = append(varDefOrder, name)
	}
	globals[name] = v
}
