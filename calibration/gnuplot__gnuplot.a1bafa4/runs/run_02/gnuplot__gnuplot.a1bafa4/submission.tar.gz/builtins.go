package main

import (
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

type Builtin func(n *Node, args []Value) Value

var builtins map[string]Builtin

func rarg(args []Value, i int) float64 {
	v := toNum(args[i])
	return v.real()
}

func m1(f func(float64) float64) Builtin {
	return func(n *Node, a []Value) Value {
		v := toNum(a[0])
		r := f(v.real())
		if math.IsNaN(r) || math.IsInf(r, 0) {
			undefFlag = true
		}
		return FltV(r)
	}
}

func cm1(fr func(float64) (float64, bool), fc func(complex128) complex128) Builtin {
	return func(n *Node, a []Value) Value {
		v := toNum(a[0])
		if v.K == KCmplx && v.Im != 0 || fr == nil {
			r := fc(complex(v.real(), v.Im))
			return CV(real(r), imag(r))
		}
		x, ok := fr(v.real())
		if !ok {
			r := fc(complex(v.real(), 0))
			return CV(real(r), imag(r))
		}
		if math.IsNaN(x) || math.IsInf(x, 0) {
			undefFlag = true
		}
		return FltV(x)
	}
}

var randState [2]int64 = [2]int64{0, 0}

func init() {
	builtins = map[string]Builtin{
		"abs": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			if v.K == KInt {
				return IntV(absI(v.I))
			}
			if v.Im != 0 {
				return FltV(math.Hypot(v.F, v.Im))
			}
			return FltV(math.Abs(v.F))
		},
		"sgn": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			x := v.real()
			if x > 0 {
				return IntV(1)
			} else if x < 0 {
				return IntV(-1)
			}
			return IntV(0)
		},
		"int": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			if v.K == KInt {
				return v
			}
			if math.IsNaN(v.F) || math.Abs(v.F) >= 9.3e18 {
				undefFlag = true
				return FltV(math.NaN())
			}
			return IntV(int64(v.F))
		},
		"floor": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			if v.K == KInt {
				return v
			}
			f := math.Floor(v.F)
			if math.Abs(f) >= 9.2e18 {
				return FltV(f)
			}
			return IntV(int64(f))
		},
		"ceil": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			if v.K == KInt {
				return v
			}
			f := math.Ceil(v.F)
			if math.Abs(f) >= 9.2e18 {
				return FltV(f)
			}
			return IntV(int64(f))
		},
		"round_": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			if v.K == KInt {
				return v
			}
			return IntV(int64(math.Round(v.F)))
		},
		"real": func(n *Node, a []Value) Value { v := toNum(a[0]); return FltV(v.real()) },
		"imag": func(n *Node, a []Value) Value { v := toNum(a[0]); return FltV(v.Im) },
		"arg": func(n *Node, a []Value) Value {
			v := toNum(a[0])
			return FltV(angOut(math.Atan2(v.Im, v.real())))
		},
		"conj": func(n *Node, a []Value) Value { v := toNum(a[0]); return CV(v.real(), -v.Im) },
		"sqrt": cm1(func(x float64) (float64, bool) {
			if x < 0 {
				return 0, false
			}
			return math.Sqrt(x), true
		}, cmplx.Sqrt),
		"exp": cm1(func(x float64) (float64, bool) { return math.Exp(x), true }, cmplx.Exp),
		"log": cm1(func(x float64) (float64, bool) {
			if x < 0 {
				return 0, false
			}
			return math.Log(x), true
		}, cmplx.Log),
		"log10": cm1(func(x float64) (float64, bool) {
			if x < 0 {
				return 0, false
			}
			return math.Log10(x), true
		}, cmplx.Log10),
		"sin":  cm1(func(x float64) (float64, bool) { return math.Sin(angIn(x)), true }, cmplx.Sin),
		"cos":  cm1(func(x float64) (float64, bool) { return math.Cos(angIn(x)), true }, cmplx.Cos),
		"tan":  cm1(func(x float64) (float64, bool) { return math.Tan(angIn(x)), true }, cmplx.Tan),
		"sinh": cm1(func(x float64) (float64, bool) { return math.Sinh(x), true }, cmplx.Sinh),
		"cosh": cm1(func(x float64) (float64, bool) { return math.Cosh(x), true }, cmplx.Cosh),
		"tanh": cm1(func(x float64) (float64, bool) { return math.Tanh(x), true }, cmplx.Tanh),
		"asin": cm1(func(x float64) (float64, bool) {
			if x < -1 || x > 1 {
				return 0, false
			}
			return angOut(math.Asin(x)), true
		}, cmplx.Asin),
		"acos": cm1(func(x float64) (float64, bool) {
			if x < -1 || x > 1 {
				return 0, false
			}
			return angOut(math.Acos(x)), true
		}, cmplx.Acos),
		"atan":  cm1(func(x float64) (float64, bool) { return angOut(math.Atan(x)), true }, cmplx.Atan),
		"asinh": cm1(func(x float64) (float64, bool) { return math.Asinh(x), true }, cmplx.Asinh),
		"acosh": cm1(func(x float64) (float64, bool) {
			if x < 1 {
				return 0, false
			}
			return math.Acosh(x), true
		}, cmplx.Acosh),
		"atanh": cm1(func(x float64) (float64, bool) {
			if x <= -1 || x >= 1 {
				return 0, false
			}
			return math.Atanh(x), true
		}, cmplx.Atanh),
		"atan2": func(n *Node, a []Value) Value {
			return FltV(angOut(math.Atan2(rarg(a, 0), rarg(a, 1))))
		},
		"besj0":  m1(math.J0),
		"besj1":  m1(math.J1),
		"besy0":  m1(math.Y0),
		"besy1":  m1(math.Y1),
		"besjn": func(n *Node, a []Value) Value { return FltV(math.Jn(int(rarg(a, 0)), rarg(a, 1))) },
		"besyn": func(n *Node, a []Value) Value { return FltV(math.Yn(int(rarg(a, 0)), rarg(a, 1))) },
		"erf":    m1(math.Erf),
		"erfc":   m1(math.Erfc),
		"inverf": m1(math.Erfinv),
		"gamma":  m1(math.Gamma),
		"lgamma": m1(func(x float64) float64 { r, _ := math.Lgamma(x); return r }),
		"norm":   m1(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": m1(func(x float64) float64 {
			return -math.Sqrt2 * math.Erfcinv(2*x)
		}),
		"rand": func(n *Node, a []Value) Value {
			return FltV(gpRand(a))
		},
		"strlen": func(n *Node, a []Value) Value {
			s := strArg(a[0])
			return IntV(int64(len([]rune(s))))
		},
		"substr": func(n *Node, a []Value) Value {
			s := strArg(a[0])
			return StrV(substrG(s, int64(rarg(a, 1)), int64(rarg(a, 2))))
		},
		"strstrt": func(n *Node, a []Value) Value {
			s := strArg(a[0])
			t := strArg(a[1])
			i := strings.Index(s, t)
			if i < 0 {
				return IntV(0)
			}
			return IntV(int64(len([]rune(s[:i]))) + 1)
		},
		"words": func(n *Node, a []Value) Value {
			return IntV(int64(len(gpWords(strArg(a[0])))))
		},
		"word": func(n *Node, a []Value) Value {
			w := gpWords(strArg(a[0]))
			i := int(rarg(a, 1))
			if i < 1 || i > len(w) {
				return StrV("")
			}
			return StrV(w[i-1])
		},
		"trim": func(n *Node, a []Value) Value {
			return StrV(strings.Trim(strArg(a[0]), " \t\n\r\f\v"))
		},
		"sprintf": func(n *Node, a []Value) Value {
			if len(a) == 0 {
				gpErrNC("sprintf: no format string")
			}
			return StrV(gpSprintf(strArg(a[0]), a[1:]))
		},
		"gprintf": func(n *Node, a []Value) Value {
			v := toNum(a[1])
			return StrV(gprintf(strArg(a[0]), v.real(), 10))
		},
		"exists": func(n *Node, a []Value) Value {
			s := strArg(a[0])
			v, ok := globals[s]
			return boolV(ok && v.K != KNone)
		},
		"value": func(n *Node, a []Value) Value {
			s := strArg(a[0])
			v, ok := globals[s]
			if !ok {
				undefFlag = true
				return FltV(math.NaN())
			}
			return v
		},
		"system": func(n *Node, a []Value) Value {
			out := runSystem(strArg(a[0]))
			out = strings.TrimSuffix(out, "\n")
			return StrV(out)
		},
		"time": func(n *Node, a []Value) Value {
			t := float64(time.Now().UnixNano()) / 1e9
			if len(a) > 0 && a[0].K == KStr {
				return StrV(gstrftime(a[0].S, t))
			}
			if len(a) > 0 && a[0].K == KInt {
				return IntV(int64(t))
			}
			return FltV(t)
		},
		"strftime": func(n *Node, a []Value) Value {
			return StrV(gstrftime(strArg(a[0]), rarg(a, 1)))
		},
		"strptime": func(n *Node, a []Value) Value {
			t, ok := gstrptime(strArg(a[0]), strArg(a[1]))
			if !ok {
				undefFlag = true
			}
			return FltV(t)
		},
		"column": func(n *Node, a []Value) Value {
			if a[0].K == KStr {
				return getColumnByName(a[0].S)
			}
			return getColumn(int(rarg(a, 0)))
		},
		"stringcolumn": func(n *Node, a []Value) Value {
			if a[0].K == KStr {
				return getStrColumnByName(a[0].S)
			}
			return getStrColumn(int(rarg(a, 0)))
		},
		"strcol": func(n *Node, a []Value) Value {
			if a[0].K == KStr {
				return getStrColumnByName(a[0].S)
			}
			return getStrColumn(int(rarg(a, 0)))
		},
		"valid": func(n *Node, a []Value) Value {
			return boolV(validColumn(int(rarg(a, 0))))
		},
		"columnhead": func(n *Node, a []Value) Value {
			return StrV(columnHead(int(rarg(a, 0))))
		},
		"columnheader": func(n *Node, a []Value) Value {
			return StrV(columnHead(int(rarg(a, 0))))
		},
		"timecolumn": func(n *Node, a []Value) Value {
			s := getStrColumn(int(rarg(a, 0)))
			if s.K != KStr {
				undefFlag = true
				return FltV(0)
			}
			f := timefmtIn
			if len(a) > 1 {
				f = strArg(a[1])
			}
			t, ok := gstrptime(f, s.S)
			if !ok {
				undefFlag = true
			}
			return FltV(t)
		},
		"tm_sec":  tmf(func(t time.Time) int { return t.Second() }),
		"tm_min":  tmf(func(t time.Time) int { return t.Minute() }),
		"tm_hour": tmf(func(t time.Time) int { return t.Hour() }),
		"tm_mday": tmf(func(t time.Time) int { return t.Day() }),
		"tm_mon":  tmf(func(t time.Time) int { return int(t.Month()) - 1 }),
		"tm_year": tmf(func(t time.Time) int { return t.Year() }),
		"tm_wday": tmf(func(t time.Time) int { return int(t.Weekday()) }),
		"tm_yday": tmf(func(t time.Time) int { return t.YearDay() - 1 }),
		"hsv2rgb": func(n *Node, a []Value) Value {
			h, s, v := rarg(a, 0), rarg(a, 1), rarg(a, 2)
			r, g, b := hsv2rgb(h, s, v)
			return IntV(int64(r)<<16 | int64(g)<<8 | int64(b))
		},
		"rgbcolor": func(n *Node, a []Value) Value {
			return IntV(parseColorName(strArg(a[0])))
		},
		"lambertw": m1(lambertW),
		"voigt": func(n *Node, a []Value) Value { return FltV(voigt(rarg(a, 0), rarg(a, 1))) },
		"igamma": func(n *Node, a []Value) Value {
			r := igamma(rarg(a, 0), rarg(a, 1))
			return FltV(r)
		},
		"ibeta": func(n *Node, a []Value) Value {
			return FltV(ibeta(rarg(a, 0), rarg(a, 1), rarg(a, 2)))
		},
		"expint": func(n *Node, a []Value) Value {
			return FltV(expint(int(rarg(a, 0)), rarg(a, 1)))
		},
		"airy": m1(func(x float64) float64 { return airyAi(x) }),
		"besi0": m1(func(x float64) float64 { return besI(0, x) }),
		"besi1": m1(func(x float64) float64 { return besI(1, x) }),
	}
}

func tmf(f func(time.Time) int) Builtin {
	return func(n *Node, a []Value) Value {
		t := rarg(a, 0)
		tt := time.Unix(int64(math.Floor(t)), 0).UTC()
		return IntV(int64(f(tt)))
	}
}

func strArg(v Value) string {
	if v.K != KStr {
		gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
	}
	return v.S
}

func gpWords(s string) []string {
	// words separated by whitespace, quotes group
	var out []string
	i := 0
	for i < len(s) {
		for i < len(s) && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]
			j := i + 1
			for j < len(s) && s[j] != q {
				j++
			}
			out = append(out, s[i+1:min(j, len(s))])
			i = j + 1
			continue
		}
		j := i
		for j < len(s) && !(s[j] == ' ' || s[j] == '\t' || s[j] == '\n') {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

var angleDegrees = false

func angIn(x float64) float64 {
	if angleDegrees {
		return x * math.Pi / 180
	}
	return x
}
func angOut(x float64) float64 {
	if angleDegrees {
		return x * 180 / math.Pi
	}
	return x
}

var builtinArity = map[string]int{
	"atan2": 2, "besjn": 2, "besyn": 2, "substr": 3, "strstrt": 2, "word": 2, "gprintf": 2, "strftime": 2, "strptime": 2,
	"hsv2rgb": 3, "voigt": 2, "igamma": 2, "ibeta": 3, "expint": 2,
}

func callFunc(n *Node) Value {
	if uf, ok := userFuncs[n.Name]; ok {
		if len(n.Kids) != len(uf.Params) {
			gpErr(n.Pos, "function "+n.Name+" requires "+strconv.Itoa(len(uf.Params))+" variable"+plural(len(uf.Params)))
		}
		fr := map[string]Value{}
		for i, k := range n.Kids {
			fr[uf.Params[i]] = eval(k)
		}
		frames = append(frames, fr)
		defer func() { frames = frames[:len(frames)-1] }()
		return eval(uf.Body)
	}
	b := builtins[n.Name]
	args := make([]Value, len(n.Kids))
	for i, k := range n.Kids {
		args[i] = eval(k)
	}
	want := 1
	if w, ok := builtinArity[n.Name]; ok {
		want = w
	}
	switch n.Name {
	case "sprintf", "time", "timecolumn", "rand":
	default:
		if len(args) != want {
			if want > len(args) {
				gpErr(n.Pos, "Not enough parameters for "+n.Name)
			}
			gpErr(n.Pos, "Too many parameters for "+n.Name)
		}
	}
	return b(n, args)
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

func runSystem(cmd string) string {
	c := exec.Command("/bin/sh", "-c", cmd)
	c.Stdin = os.Stdin
	c.Stderr = os.Stderr
	out, _ := c.Output()
	return string(out)
}

// ---------- sprintf ----------

func gpSprintf(format string, args []Value) string {
	var sb strings.Builder
	ai := 0
	for i := 0; i < len(format); i++ {
		c := format[i]
		if c != '%' {
			sb.WriteByte(c)
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			sb.WriteByte('%')
			i++
			continue
		}
		if ai >= len(args) {
			sb.WriteString(format[i:])
			break
		}
		f, l := parseSpec(format[i+1:])
		i += l
		a := args[ai]
		ai++
		switch f.conv {
		case 'd', 'i', 'x', 'X', 'o', 'c':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			a = toNum(a)
			var iv int64
			if a.K == KInt {
				iv = a.I
			} else {
				iv = int64(a.F)
			}
			sb.WriteString(fmtIntSpec(f, iv))
		case 'f', 'F', 'e', 'E', 'g', 'G', 'a', 'A':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			a = toNum(a)
			sb.WriteString(fmtFloatSpec(f, a.real()))
		case 's':
			if a.K != KStr {
				gpErrNC("f_sprintf: attempt to print numeric value with string format")
			}
			s := a.S
			if f.prec != "" {
				p, _ := strconv.Atoi(f.prec[1:])
				if p < len(s) {
					s = s[:p]
				}
			}
			w, _ := strconv.Atoi(f.width)
			if len(s) < w {
				if strings.Contains(f.flags, "-") {
					s = s + strings.Repeat(" ", w-len(s))
				} else {
					s = strings.Repeat(" ", w-len(s)) + s
				}
			}
			sb.WriteString(s)
		default:
			gpErrNC("f_sprintf: unsupported or invalid format specifier")
		}
	}
	return sb.String()
}

// ---------- gprintf ----------

func mantExp(x, base float64) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	p := int(math.Floor(math.Log(math.Abs(x)) / math.Log(base)))
	m := x / math.Pow(base, float64(p))
	return m, p
}

var prefixes = "yzafpnum kMGTPEZY"

func gprintf(format string, x float64, logbase float64) string {
	var sb strings.Builder
	const eps = 1e-12
	for i := 0; i < len(format); i++ {
		c := format[i]
		if c != '%' {
			sb.WriteByte(c)
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			sb.WriteByte('%')
			i++
			continue
		}
		f, l := parseSpec(format[i+1:])
		i += l
		fl := fspec{flags: f.flags, width: f.width, prec: f.prec}
		switch f.conv {
		case 't', 'T':
			m, p := 0.0, 0
			if x != 0 {
				p = int(math.Floor(math.Log10(math.Abs(x))))
				m = x / math.Pow(10, float64(p))
				// rounding check
				prec := 6
				if f.prec != "" {
					prec, _ = strconv.Atoi(f.prec[1:])
				}
				if math.Abs(m) >= 10-0.5*math.Pow(10, -float64(prec)) {
					m /= 10
					p++
				}
				_ = eps
			}
			if f.conv == 't' {
				fl.conv = 'f'
				sb.WriteString(fmtFloatSpec(fl, m))
			} else {
				fl.conv = 'd'
				sb.WriteString(fmtIntSpec(fl, int64(p)))
			}
		case 'l', 'L':
			m, p := x, 0
			if logbase > 1 && x != 0 && logScaleActive {
				p = int(math.Floor(math.Log(math.Abs(x)) / math.Log(logbase)))
				m = x / math.Pow(logbase, float64(p))
			}
			if f.conv == 'l' {
				fl.conv = 'f'
				sb.WriteString(fmtFloatSpec(fl, m))
			} else {
				fl.conv = 'd'
				sb.WriteString(fmtIntSpec(fl, int64(p)))
			}
		case 's', 'S', 'c':
			m, p := 0.0, 0
			if x != 0 {
				p = int(math.Floor(math.Log10(math.Abs(x))))
				prec := 6
				if f.prec != "" {
					prec, _ = strconv.Atoi(f.prec[1:])
				}
				m = x / math.Pow(10, float64(p))
				if math.Abs(m) >= 10-0.5*math.Pow(10, -float64(prec)) {
					p++
				}
				p3 := int(math.Floor(float64(p) / 3))
				p = p3 * 3
				m = x / math.Pow(10, float64(p))
			}
			if f.conv == 's' {
				fl.conv = 'f'
				sb.WriteString(fmtFloatSpec(fl, m))
			} else if f.conv == 'S' {
				fl.conv = 'd'
				sb.WriteString(fmtIntSpec(fl, int64(p)))
			} else {
				idx := p/3 + 8
				if idx >= 0 && idx < len(prefixes) {
					ch := prefixes[idx]
					if ch != ' ' {
						sb.WriteString(fmtIntSpec(fspec{flags: f.flags, width: f.width, conv: 'c'}, int64(ch)))
					}
				} else {
					sb.WriteString("e" + strconv.Itoa(p))
				}
			}
		case 'P':
			fl.conv = 'f'
			sb.WriteString(fmtFloatSpec(fl, x/math.Pi))
		case 'd', 'i', 'x', 'X', 'o':
			fl.conv = f.conv
			sb.WriteString(fmtIntSpec(fl, int64(x)))
		default:
			fl.conv = f.conv
			sb.WriteString(fmtFloatSpec(fl, x))
		}
	}
	return sb.String()
}

var logScaleActive = false
