package main

import (
	"fmt"
	"math"
	"strings"
)

// cfmt formats a single numeric/string value using a C style spec (one conversion)
func cfmt(spec string, arg interface{}) string {
	// parse spec: %[flags][width][.prec]conv
	if len(spec) < 2 || spec[0] != '%' {
		return spec
	}
	conv := spec[len(spec)-1]
	body := spec[1 : len(spec)-1]
	// remove length modifiers
	body = strings.Map(func(r rune) rune {
		if r == 'l' || r == 'h' || r == 'L' || r == 'q' || r == 'j' || r == 'z' || r == 't' {
			return -1
		}
		return r
	}, body)
	switch conv {
	case 'e', 'E', 'f', 'F', 'g', 'G':
		f := toFloat(arg)
		if !strings.Contains(body, ".") {
			body += ".6"
		}
		if conv == 'F' {
			conv = 'f'
		}
		if math.IsNaN(f) || math.IsInf(f, 0) {
			s := "nan"
			if math.IsInf(f, 1) {
				s = "inf"
			} else if math.IsInf(f, -1) {
				s = "-inf"
			}
			if conv == 'E' || conv == 'G' {
				s = strings.ToUpper(s)
			}
			if s[0] != '-' {
				if strings.Contains(body, "+") {
					s = "+" + s
				} else if strings.Contains(body, " ") {
					s = " " + s
				}
			}
			w := 0
			fl := strings.TrimLeft(body, "-+ #0")
			fmt.Sscanf(fl, "%d", &w)
			if strings.Contains(body, "-") {
				return fmt.Sprintf("%-*s", w, s)
			}
			return fmt.Sprintf("%*s", w, s)
		}
		if (conv == 'g' || conv == 'G') && strings.Contains(body, "#") {
			return cfmtAltG(body, conv, f)
		}
		return fmt.Sprintf("%"+body+string(conv), f)
	case 'd', 'i', 'u':
		return fmt.Sprintf("%"+body+"d", toInt(arg))
	case 'x', 'X', 'o':
		i := toInt(arg)
		var u uint64
		if i >= math.MinInt32 && i <= math.MaxInt32 {
			u = uint64(uint32(int32(i)))
		} else {
			u = uint64(i)
		}
		if conv == 'o' && strings.Contains(body, "#") {
			body = strings.Replace(body, "#", "", 1)
			s := fmt.Sprintf("%o", u)
			if s != "0" {
				s = "0" + s
			}
			return fmt.Sprintf("%"+body+"s", s)
		}
		return fmt.Sprintf("%"+body+string(conv), u)
	case 'c':
		return fmt.Sprintf("%"+body+"c", rune(toInt(arg)))
	case 's':
		if s, ok := arg.(string); ok {
			return fmt.Sprintf("%"+body+"s", s)
		}
		return fmt.Sprint(arg)
	}
	return spec
}

func cfmtAltG(body string, conv byte, f float64) string {
	body = strings.Replace(body, "#", "", 1)
	prec := 6
	if i := strings.IndexByte(body, '.'); i >= 0 {
		fmt.Sscanf(body[i+1:], "%d", &prec)
		body = body[:i]
	}
	if prec == 0 {
		prec = 1
	}
	var s string
	if f == 0 {
		s = fmt.Sprintf("%.*f", prec-1, 0.0)
	} else {
		es := fmt.Sprintf("%.*e", prec-1, f)
		ei := strings.LastIndexAny(es, "eE")
		var x int
		fmt.Sscanf(es[ei+1:], "%d", &x)
		if x < -4 || x >= prec {
			s = es
			if conv == 'G' {
				s = strings.ToUpper(s)
			}
		} else {
			s = fmt.Sprintf("%.*f", prec-1-x, f)
			if !strings.Contains(s, ".") {
				s += "."
			}
		}
	}
	return fmt.Sprintf("%"+body+"s", s)
}

func toFloat(a interface{}) float64 {
	switch x := a.(type) {
	case float64:
		return x
	case int64:
		return float64(x)
	case int:
		return float64(x)
	}
	return 0
}

func toInt(a interface{}) int64 {
	switch x := a.(type) {
	case float64:
		if math.IsNaN(x) {
			return math.MinInt64
		}
		if x >= 9.2233720368547758e18 || x < -9.2233720368547758e18 {
			return math.MinInt64
		}
		return int64(x)
	case int64:
		return x
	case int:
		return int64(x)
	}
	return 0
}

// splitFormat splits a printf format into literal text and conversion specs.
type fmtPiece struct {
	lit  string
	spec string // empty if literal
}

func splitFormat(f string) []fmtPiece {
	var out []fmtPiece
	var lit strings.Builder
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' {
			lit.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			lit.WriteByte('%')
			i += 2
			continue
		}
		j := i + 1
		for j < len(f) && strings.IndexByte("-+ #0", f[j]) >= 0 {
			j++
		}
		for j < len(f) && (f[j] >= '0' && f[j] <= '9' || f[j] == '*') {
			j++
		}
		if j < len(f) && f[j] == '.' {
			j++
			for j < len(f) && f[j] >= '0' && f[j] <= '9' {
				j++
			}
		}
		for j < len(f) && strings.IndexByte("hlLqjzt", f[j]) >= 0 {
			j++
		}
		if j >= len(f) {
			lit.WriteString(f[i:])
			break
		}
		if lit.Len() > 0 {
			out = append(out, fmtPiece{lit: lit.String()})
			lit.Reset()
		}
		out = append(out, fmtPiece{spec: f[i : j+1]})
		i = j + 1
	}
	if lit.Len() > 0 {
		out = append(out, fmtPiece{lit: lit.String()})
	}
	return out
}

func gpSprintf(args []Value) string {
	if len(args) == 0 {
		gpErrNC("sprintf: no format string")
	}
	if args[0].K != KStr {
		gpErrNC("First parameter to sprintf must be a format string")
	}
	pieces := splitFormat(args[0].S)
	var b strings.Builder
	ai := 1
	for _, p := range pieces {
		if p.spec == "" {
			b.WriteString(p.lit)
			continue
		}
		if ai >= len(args) {
			b.WriteString(p.spec)
			continue
		}
		a := args[ai]
		ai++
		conv := p.spec[len(p.spec)-1]
		switch conv {
		case 's':
			if a.K != KStr {
				gpErrNC("f_sprintf: attempt to print numeric value with string format")
			}
			b.WriteString(cfmt(p.spec, a.S))
		case 'd', 'i', 'u', 'x', 'X', 'o', 'c':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			if a.K == KInt {
				b.WriteString(cfmt(p.spec, a.I))
			} else {
				b.WriteString(cfmt(p.spec, a.Re))
			}
		case 'e', 'E', 'f', 'F', 'g', 'G':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			b.WriteString(cfmt(p.spec, a.Real()))
		default:
			gpErrNC("bad format character")
		}
	}
	return b.String()
}
