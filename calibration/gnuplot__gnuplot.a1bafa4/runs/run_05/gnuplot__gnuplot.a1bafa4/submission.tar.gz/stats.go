package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
)

type colStats struct {
	n                                      int
	mean, sd, ssd, skew, kurt, adev        float64
	sum, sumsq, min, max, median, q1, q3   float64
	imin, imax                             int
	meanErr, sdErr, skewErr, kurtErr       float64
	vals                                   []float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	s.vals = v
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x >= s.max {
			s.max = x
			s.imax = i
		}
	}
	fn := float64(n)
	s.mean = s.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	s.sd = math.Sqrt(m2 / fn)
	s.ssd = math.Sqrt(m2 / (fn - 1))
	if n < 2 {
		s.ssd = math.NaN()
	}
	s.skew = (m3 / fn) / math.Pow(s.sd, 3)
	s.kurt = (m4 / fn) / math.Pow(s.sd, 4)
	s.adev = ad / fn
	s.meanErr = s.sd / math.Sqrt(fn)
	s.sdErr = s.sd / math.Sqrt(2*fn)
	s.skewErr = math.Sqrt(6 / fn)
	s.kurtErr = math.Sqrt(24 / fn)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	med := func(a []float64) float64 {
		m := len(a)
		if m == 0 {
			return math.NaN()
		}
		if m%2 == 1 {
			return a[m/2]
		}
		return (a[m/2-1] + a[m/2]) / 2
	}
	s.median = med(sv)
	if n == 1 {
		s.q1, s.q3 = sv[0], sv[0]
	} else {
		lo := sv[:n/2]
		hi := sv[(n+1)/2:]
		s.q1 = med(lo)
		s.q3 = med(hi)
	}
	return s
}

func rjust(s string, w int) string {
	if len(s) >= w {
		return s
	}
	return strings.Repeat(" ", w-len(s)) + s
}

func f4(x float64) string {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		return "undefined"
	}
	return fmt.Sprintf("%.4f", x)
}

func (in *Interp) statsCmd(p *P) {
	S := in.S
	var rng []*Range
	for p.is("[") {
		r := &Range{AutoMin: true, AutoMax: true}
		in.parseRange(p, r)
		rng = append(rng, r)
	}
	el := &PlotElem{Every: defaultEvery(), Index: -1, IndexEnd: -1, IndexStep: 1, Style: "points"}
	t := p.tok()
	if t.K == TStr {
		el.DataName = t.Str
		p.i++
	} else if t.K == TIdent && strings.HasPrefix(t.Text, "$") {
		el.DataName = t.Text
		p.i++
	} else {
		el.DataName = in.evalStr(p)
	}
	prefix := "STATS"
	output := true
	usingTok := -1
	for !p.atEnd() {
		switch {
		case p.isAbbr("i$ndex"):
			p.i++
			el.Index = int(in.evalInt(p))
			if p.is(":") {
				p.i++
				el.IndexEnd = int(in.evalInt(p))
			}
		case p.isAbbr("ev$ery"):
			p.i++
			vals := []*int{&el.Every.PInc, &el.Every.BInc, &el.Every.PStart, &el.Every.BStart, &el.Every.PEnd, &el.Every.BEnd}
			k := 0
			for k < 6 {
				if !p.is(":") && !p.atEnd() && p.tok().K == TNum {
					*vals[k] = int(in.evalInt(p))
				}
				if p.is(":") {
					p.i++
					k++
					continue
				}
				break
			}
		case p.isAbbr("u$sing"):
			p.i++
			usingTok = p.i
			in.parseUsing(p, el)
		case p.isAbbr("name") || p.isAbbr("pre$fix"):
			p.i++
			prefix = in.evalStr(p)
		case p.isAbbr("noout$put"):
			p.i++
			output = false
		case p.isAbbr("out$put"):
			p.i++
			output = true
		case p.isAbbr("mat$rix"):
			p.i++
		default:
			gpErr(p.tok().Pos, "Unrecognized option")
		}
	}
	if len(el.Using) > 2 {
		gpErr(p.tok().Pos, "Too many columns in using specification")
	}
	_ = usingTok
	lines := in.dataLines(el.DataName)
	// count blanks / blocks
	blank := 0
	blocks := 0
	prevBlank := 0
	seenData := false
	for _, l := range lines {
		if isBlank(l) {
			blank++
			prevBlank++
			continue
		}
		if in.isComment(l) {
			continue
		}
		if !seenData || prevBlank >= 2 {
			blocks++
		}
		seenData = true
		prevBlank = 0
	}
	recs, _ := in.scanData(lines, el.Index, el.IndexEnd, el.IndexStep, el.Every)
	ncols := 0
	for _, r := range recs {
		if r.Fields != nil {
			ncols = len(r.Fields)
			break
		}
	}
	using := el.Using
	raw := el.UsingRaw
	if len(using) == 0 {
		nc := 2
		if ncols < 2 {
			nc = 1
		}
		for k := 1; k <= nc; k++ {
			kk := k
			using = append(using, func(e *Env) Value { return columnValue(e, kk, in) })
			raw = append(raw, kk)
		}
	}
	ndim := len(using)
	var xs, ys []float64
	invalid, outr, headers := 0, 0, 0
	lineNo := 0
	for _, r := range recs {
		if r.Fields == nil {
			continue
		}
		lineNo++
		row := &DataRow{cols: r.Fields, line: r.Line, index: r.Index}
		vals := make([]float64, ndim)
		bad := false
		for k, f := range using {
			if raw[k] > 0 {
				if raw[k] > len(r.Fields) {
					bad = true
					break
				}
				s := r.Fields[raw[k]-1]
				if S.DFMissing != "" && s == S.DFMissing {
					bad = true
					break
				}
				v, ok := parseField(s)
				if !ok {
					bad = true
					break
				}
				vals[k] = v
				continue
			}
			e := &Env{row: row}
			v := f(e)
			if e.undef {
				bad = true
				invalid++
				break
			}
			vals[k] = numify(v).Real()
		}
		if bad {
			// header line?
			if r == firstRec(recs) && raw[0] != 0 {
				in.warn(fmt.Sprintf("bad data on line %d of file %s", lineNo, el.DataName))
			}
			continue
		}
		in := func(k int, ax string) bool {
			if k >= len(rng) {
				return true
			}
			rr := rng[k]
			if !rr.AutoMin && vals[k] < rr.Min {
				return false
			}
			if !rr.AutoMax && vals[k] > rr.Max {
				return false
			}
			return true
		}
		ok := in(0, "x")
		if ndim > 1 && !in(1, "y") {
			ok = false
		}
		if !ok {
			outr++
			continue
		}
		xs = append(xs, vals[0])
		if ndim > 1 {
			ys = append(ys, vals[1])
		}
	}
	if len(xs) == 0 {
		gpErrNC("All points out of range")
	}
	sx := computeStats(xs)
	var sy colStats
	if ndim > 1 {
		sy = computeStats(ys)
	}
	set := func(name string, v Value) { in.sv(prefix+"_"+name, v) }
	setf := func(name string, f float64) { set(name, FltV(f)) }
	set("records", IntV(int64(len(xs))))
	set("invalid", IntV(int64(invalid)))
	set("headers", IntV(int64(headers)))
	set("blank", IntV(int64(blank)))
	set("blocks", IntV(int64(blocks)))
	set("outofrange", IntV(int64(outr)))
	set("columns", IntV(int64(ncols)))
	putCol := func(s colStats, suf string) {
		setf("mean"+suf, s.mean)
		setf("stddev"+suf, s.sd)
		setf("ssd"+suf, s.ssd)
		setf("skewness"+suf, s.skew)
		setf("kurtosis"+suf, s.kurt)
		setf("adev"+suf, s.adev)
		setf("mean_err"+suf, s.meanErr)
		setf("stddev_err"+suf, s.sdErr)
		setf("skewness_err"+suf, s.skewErr)
		setf("kurtosis_err"+suf, s.kurtErr)
		setf("sum"+suf, s.sum)
		setf("sumsq"+suf, s.sumsq)
		setf("min"+suf, s.min)
		setf("max"+suf, s.max)
		setf("median"+suf, s.median)
		setf("lo_quartile"+suf, s.q1)
		setf("up_quartile"+suf, s.q3)
		set("index_min"+suf, IntV(int64(s.imin)))
		set("index_max"+suf, IntV(int64(s.imax)))
	}
	var slope, icept, slopeErr, iceptErr, corr, sumxy float64
	if ndim == 1 {
		putCol(sx, "")
	} else {
		putCol(sx, "_x")
		putCol(sy, "_y")
		n := float64(len(xs))
		for i := range xs {
			sumxy += xs[i] * ys[i]
		}
		sxx := sx.sumsq/n - sx.mean*sx.mean
		sxy := sumxy/n - sx.mean*sy.mean
		syy := sy.sumsq/n - sy.mean*sy.mean
		slope = sxy / sxx
		icept = sy.mean - slope*sx.mean
		corr = sxy / math.Sqrt(sxx*syy)
		// errors
		var rss float64
		for i := range xs {
			d := ys[i] - (slope*xs[i] + icept)
			rss += d * d
		}
		s2 := rss / (n - 2)
		slopeErr = math.Sqrt(s2 / (sxx * n))
		iceptErr = math.Sqrt(s2 * (1/n + sx.mean*sx.mean/(sxx*n)))
		setf("slope", slope)
		setf("intercept", icept)
		setf("slope_err", slopeErr)
		setf("intercept_err", iceptErr)
		setf("correlation", corr)
		setf("sumxy", sumxy)
		setf("pos_min_y", xs[sy.imin])
		setf("pos_max_y", xs[sy.imax])
	}
	if !output {
		return
	}
	var b strings.Builder
	w := &b
	fmt.Fprintf(w, "\n* FILE: \n")
	line := func(label string, v string, wd int) string {
		return label + rjust(v, wd-len(label))
	}
	fmt.Fprintln(w, line("  Records:", fmt.Sprint(len(xs)), 22))
	fmt.Fprintln(w, line("  Out of range:", fmt.Sprint(outr), 22))
	fmt.Fprintln(w, line("  Invalid:", fmt.Sprint(invalid), 22))
	fmt.Fprintln(w, line("  Header records:", fmt.Sprint(headers), 22))
	fmt.Fprintln(w, line("  Blank:", fmt.Sprint(blank), 22))
	fmt.Fprintln(w, line("  Data Blocks:", fmt.Sprint(blocks), 22))
	fmt.Fprintln(w)
	if ndim == 1 {
		fmt.Fprintf(w, "* COLUMN: \n")
	} else {
		fmt.Fprintf(w, "* COLUMNS:\n")
	}
	row := func(label string, a, c float64) {
		s := line(label, f4(a), 28)
		if ndim > 1 {
			s += rjust(f4(c), 18)
		}
		fmt.Fprintln(w, s)
	}
	row("  Mean:", sx.mean, sy.mean)
	row("  Std Dev:", sx.sd, sy.sd)
	row("  Sample StdDev:", sx.ssd, sy.ssd)
	row("  Skewness:", sx.skew, sy.skew)
	row("  Kurtosis:", sx.kurt, sy.kurt)
	row("  Avg Dev:", sx.adev, sy.adev)
	row("  Sum:", sx.sum, sy.sum)
	row("  Sum Sq.:", sx.sumsq, sy.sumsq)
	fmt.Fprintln(w)
	row("  Mean Err.:", sx.meanErr, sy.meanErr)
	row("  Std Dev Err.:", sx.sdErr, sy.sdErr)
	row("  Skewness Err.:", sx.skewErr, sy.skewErr)
	row("  Kurtosis Err.:", sx.kurtErr, sy.kurtErr)
	fmt.Fprintln(w)
	mm := func(label string, a float64, ia int, c float64, ic int) {
		s := line(label, f4(a), 28) + fmt.Sprintf(" [%d]", ia)
		if ndim > 1 {
			s += rjust(f4(c), 14) + fmt.Sprintf(" [%d]", ic)
		}
		fmt.Fprintln(w, s)
	}
	mm("  Minimum:", sx.min, sx.imin, sy.min, sy.imin)
	mm("  Maximum:", sx.max, sx.imax, sy.max, sy.imax)
	q := func(label string, a, c float64) {
		s := line(label, f4(a), 28)
		if ndim > 1 {
			s += rjust(f4(c), 18)
		} else {
			s += " "
		}
		fmt.Fprintln(w, s)
	}
	q("  Quartile:", sx.q1, sy.q1)
	q("  Median:", sx.median, sy.median)
	q("  Quartile:", sx.q3, sy.q3)
	fmt.Fprintln(w)
	if ndim > 1 {
		fmt.Fprintf(w, "  Linear Model:       y = %s x + %s\n", g4(slope), g4(icept))
		fmt.Fprintf(w, "  Slope:              %s +- %s\n", g4(slope), g4(slopeErr))
		fmt.Fprintf(w, "  Intercept:          %s +- %s\n", g4(icept), g4(iceptErr))
		fmt.Fprintf(w, "  Correlation:        r = %s\n", g4(corr))
		fmt.Fprintf(w, "  Sum xy:             %s\n", g4(sumxy))
		fmt.Fprintln(w)
	}
	in.flushOut()
	if ndim > 1 && len(xs) < 3 {
		os.Stderr.WriteString("Warning:  Can't compute errors of slope and intercept. Not enough data points.\n")
	}
	in.printOut.Write([]byte(b.String()))
	in.flushPrint()
}

func g4(x float64) string {
	return cfmt("%.4g", x)
}
