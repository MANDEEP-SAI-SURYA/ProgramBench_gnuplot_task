package main

import (
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strings"
)

type Pt struct {
	X, Y, Z float64
	Ex      []float64 // extra columns (ylow,yhigh etc)
	Typ     byte      // 'i','o','u'
	Brk     bool      // break marker (no data)
	Label   string
	XTic    string
	HasXTic bool
}

type PlotElem struct {
	IsFunc    bool
	Fn        EvalFn
	Fn2       EvalFn // parametric second / unused
	FnText    string
	DataName  string
	SpecText  string
	Title     string
	NoTitle   bool
	TitleSet  bool
	TitleColHead bool
	Style     string
	Using     []EvalFn
	UsingRaw  []int // column numbers for plain column (0 = expr)
	UsingStr  []bool
	XticFn    EvalFn
	NUsing    int
	Smooth    string
	Every     EverySpec
	Index     int
	IndexEnd  int
	IndexStep int
	Pts       []Pt
	OrigCount int
	Headers   []string
	PtType    int
	LineType  int
	Axes      string
	Is3D      bool
	Range     *Range // per-plot sampling range
	BinsN     int
	BinWidth  float64
	BinsSet   bool
	LabelFn   EvalFn
	LT        int
	PointChar byte
	SmoothTotal float64
	IterVars  map[string]Value
	UsesNames bool
	Missing   bool
}

func (in *Interp) parsePlotRanges(p *P, is3d bool) []*Range {
	var rs []*Range
	for p.is("[") {
		r := &Range{AutoMin: true, AutoMax: true}
		// allow [t=..]
		in.parseRange(p, r)
		rs = append(rs, r)
	}
	return rs
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "xerr$orbars", "yerr$orbars", "xyerr$orbars", "errorl$ines", "xerrorl$ines", "yerrorl$ines", "xyerrorl$ines", "boxes", "boxer$rorbars", "boxxy$errorbars", "fillst$eps", "filledc$urves", "labels", "vec$tors", "financebars", "candlesticks", "histograms", "image", "rgbimage", "pm3d", "circles", "ellipses", "surface", "boxplot", "zerrorfill", "parallelaxes", "table", "arrows", "fillsteps"}

func (in *Interp) plotCmd(p *P, is3d bool) {
	startTok := p.i
	S := in.S
	ranges := in.parsePlotRanges(p, is3d)
	var elems []*PlotElem
	sampleRange := (*Range)(nil)
	for {
		if p.atEnd() {
			if len(elems) == 0 {
				gpErr(p.tok().Pos, "function to plot expected")
			}
			break
		}
		// iteration
		var iters []*iterSpec
		for p.isAbbr("for") {
			p.i++
			iters = append(iters, in.parseIter(p))
		}
		elStart := p.i
		if len(iters) > 0 {
			// run element for each iteration value
			var rec func(k int)
			endI := elStart
			rec = func(k int) {
				if k >= len(iters) {
					p.i = elStart
					el := in.parsePlotElem(p, is3d, sampleRange)
					if el != nil {
						el.IterVars = map[string]Value{}
						for _, it2 := range iters {
							el.IterVars[it2.name] = in.vars[it2.name]
						}
						elems = append(elems, el)
					}
					endI = p.i
					return
				}
				it := iters[k]
				for _, v := range it.values() {
					in.sv(it.name, v)
					rec(k + 1)
				}
			}
			rec(0)
			p.i = endI
		} else {
			// local range for this element
			if p.is("[") {
				r := &Range{AutoMin: true, AutoMax: true}
				in.parseRange(p, r)
				sampleRange = r
			}
			el := in.parsePlotElem(p, is3d, sampleRange)
			if el != nil {
				elems = append(elems, el)
			}
		}
		if p.is(",") {
			p.i++
			continue
		}
		break
	}
	in.lastPlotCmd = p.line[p.toks[startTok].Pos:p.tok().Pos]
	in.lastPlot = "plot"
	if is3d {
		in.lastPlot = "splot"
	}
	in.executePlot(elems, ranges, is3d)
	_ = S
}

func (in *Interp) replotCmd(p *P) {
	in.skipToEnd(p)
	if in.lastPlotCmd == "" {
		gpErrNC("no previous plot")
	}
	cmd := in.lastPlot + " " + in.lastPlotCmd
	toks := tokenize(cmd)
	np := &P{in: in, toks: toks, line: cmd}
	np.i = 1
	in.plotCmd(np, in.lastPlot == "splot")
}

func (in *Interp) parsePlotElem(p *P, is3d bool, srange *Range) *PlotElem {
	S := in.S
	el := &PlotElem{Every: defaultEvery(), Index: -1, IndexEnd: -1, IndexStep: 1, Is3D: is3d, LT: -1}
	t := p.tok()
	startPos := t.Pos
	// definitions inside plot command: a=..., f(x)=...
	if t.K == TIdent && p.peek(1).Text == "=" && !strings.HasPrefix(t.Text, "$") {
		p.i += 2
		v := in.constExpr(p)
		in.setVar(t.Text, v)
		return nil
	}
	if t.K == TIdent && p.peek(1).Text == "(" {
		// function definition?
		j := p.i + 2
		ok := true
		var params []string
		for {
			if p.toks[j].K != TIdent {
				ok = false
				break
			}
			params = append(params, p.toks[j].Text)
			j++
			if p.toks[j].Text == "," {
				j++
				continue
			}
			if p.toks[j].Text == ")" {
				j++
				break
			}
			ok = false
			break
		}
		if ok && p.toks[j].Text == "=" && p.toks[j].K == TOp {
			p.i = j + 1
			body := p.parseExpr()
			if _, ok := in.funcs[t.Text]; !ok {
				in.seq++
				in.funcSeq[t.Text] = in.seq
			}
			in.funcs[t.Text] = &UserFunc{Name: t.Text, Params: params, Body: body, Text: strings.TrimSpace(p.line[t.Pos:p.tok().Pos])}
			return nil
		}
	}
	isData := false
	if t.K == TStr || (t.K == TIdent && strings.HasPrefix(t.Text, "$") && len(t.Text) > 1 && !(t.Text[1] >= '0' && t.Text[1] <= '9')) {
		isData = true
	}
	if t.K == TOp && t.Text == "'" {
		isData = true
	}
	if !isData && p.isStringStart() && t.K == TIdent {
		// string variable holding filename
		v, ok := in.vars[t.Text]
		if ok && v.K == KStr && p.peek(1).Text != "(" {
			isData = true
		}
	}
	if isData {
		if t.K == TStr {
			el.DataName = t.Str
			p.i++
		} else if strings.HasPrefix(t.Text, "$") {
			el.DataName = t.Text
			p.i++
		} else {
			el.DataName = in.evalStr(p)
		}
		if el.DataName == "" {
			el.DataName = in.lastDataFile
		}
		in.lastDataFile = el.DataName
		specEnd := p.tok().Pos
		// data modifiers
		for !p.atEnd() && !p.is(",") {
			switch {
			case p.isAbbr("i$ndex"):
				p.i++
				if p.isStringStart() {
					in.evalStr(p)
				} else {
					el.Index = int(in.evalInt(p))
					if p.is(":") {
						p.i++
						el.IndexEnd = int(in.evalInt(p))
						if p.is(":") {
							p.i++
							el.IndexStep = int(in.evalInt(p))
						}
					}
				}
				specEnd = p.toks[p.i-1].End
			case p.isAbbr("ev$ery"):
				p.i++
				vals := []*int{&el.Every.PInc, &el.Every.BInc, &el.Every.PStart, &el.Every.BStart, &el.Every.PEnd, &el.Every.BEnd}
				k := 0
				for k < 6 {
					if !p.is(":") && !p.atEnd() && !p.is(",") && (p.tok().K == TNum || p.tok().K == TIdent && in.isVarOrFunc(p) || p.is("(")) {
						*vals[k] = int(in.evalInt(p))
					}
					if p.is(":") {
						p.i++
						k++
						continue
					}
					break
				}
				if el.Every.PInc <= 0 {
					el.Every.PInc = 1
				}
				if el.Every.BInc <= 0 {
					el.Every.BInc = 1
				}
				specEnd = p.toks[p.i-1].End
			case p.isAbbr("u$sing"):
				p.i++
				in.parseUsing(p, el)
				specEnd = p.toks[p.i-1].End
			case p.isAbbr("s$mooth"):
				p.i++
				el.Smooth = "unique"
				if p.tok().K == TIdent {
					for _, sm := range []string{"a$csplines", "b$ezier", "c$splines", "s$bezier", "u$nique", "f$requency", "fnormal", "cum$ulative", "k$density", "cn$ormal", "mcs$plines", "path", "uniq$ue", "bins", "zsort", "unwrap"} {
						if p.isAbbr(sm) {
							el.Smooth = strings.Replace(sm, "$", "", 1)
							p.i++
							break
						}
					}
				}
				if el.Smooth == "kdensity" {
					// optional bandwidth etc
					for p.isAbbr("bandwidth") || p.isAbbr("period") {
						p.i++
						in.evalNum(p)
					}
				}
			case p.isAbbr("bins"):
				p.i++
				el.Smooth = "bins"
				el.BinsSet = true
				if p.is("=") {
					p.i++
					el.BinsN = int(in.evalInt(p))
				}
				for p.isAbbr("binr$ange") || p.isAbbr("binw$idth") {
					if p.isAbbr("binw$idth") {
						p.i++
						p.expect("=")
						el.BinWidth = in.evalNum(p)
					} else {
						p.i++
						r := &Range{}
						in.parseRange(p, r)
					}
				}
			default:
				goto common
			}
		}
	common:
		el.SpecText = p.line[startPos:specEnd]
		if el.SpecText == "" {
			el.SpecText = p.line[startPos:p.tok().Pos]
		}
		el.Style = S.StyleData
	} else {
		el.IsFunc = true
		st := p.i
		el.Fn = p.parseExpr()
		if is3d && false {
		}
		el.FnText = p.line[startPos:p.toks[p.i-1].End]
		_ = st
		el.Style = S.StyleFunc
		el.Range = srange
		if S.Parametric && !is3d && p.is(",") {
			// parametric: second function
			p.i++
			st2 := p.tok().Pos
			el.Fn2 = p.parseExpr()
			el.FnText = p.line[startPos:p.toks[p.i-1].End]
			_ = st2
		}
	}
	// common options
	for !p.atEnd() && !p.is(",") {
		switch {
		case p.isAbbr("t$itle"):
			p.i++
			el.TitleSet = true
			if p.isAbbr("col$umnheader") || p.isAbbr("columnhead") {
				el.TitleColHead = true
				p.i++
				if p.is("(") {
					p.i++
					in.evalInt(p)
					p.expect(")")
				}
			} else {
				v := in.constExpr(p)
				if v.K == KStr {
					el.Title = v.S
				} else {
					el.Title = v.PrintString()
				}
			}
		case p.isAbbr("not$itle"):
			p.i++
			el.NoTitle = true
			if p.tok().K == TStr {
				p.i++
			}
		case p.isAbbr("w$ith"):
			p.i++
			el.Style = in.parseStyleName(p)
		case p.isAbbr("ax$es") || p.isAbbr("ax$is"):
			p.i++
			el.Axes = p.tok().Text
			p.i++
		case p.isAbbr("lt") || p.isAbbr("linet$ype") || p.isAbbr("ls") || p.isAbbr("lines$tyle"):
			p.i++
			el.LT = int(in.evalInt(p)) - 1
		case p.isAbbr("pt") || p.isAbbr("pointt$ype"):
			p.i++
			if p.tok().K == TStr {
				el.PointChar = p.tok().Str[0]
				p.i++
			} else {
				el.PtType = int(in.evalInt(p))
			}
		case p.isAbbr("lw") || p.isAbbr("linew$idth") || p.isAbbr("ps") || p.isAbbr("points$ize") || p.isAbbr("dt") || p.isAbbr("dasht$ype") || p.isAbbr("pi") || p.isAbbr("pn") || p.isAbbr("fs") || p.isAbbr("fill$style"):
			p.i++
			if p.isAbbr("solid") || p.isAbbr("empty") || p.isAbbr("pattern") || p.isAbbr("transparent") {
				p.i++
			}
			if !p.atEnd() && !p.is(",") && (p.tok().K == TNum || p.tok().K == TStr || p.is("(")) {
				in.constExpr(p)
			}
		case p.isAbbr("lc") || p.isAbbr("linec$olor") || p.isAbbr("tc") || p.isAbbr("textc$olor") || p.isAbbr("fc") || p.isAbbr("fillc$olor"):
			p.i++
			if p.isAbbr("rgb$color") {
				p.i++
				in.constExpr(p)
			} else if p.isAbbr("palette") {
				p.i++
				if p.isAbbr("z") || p.isAbbr("cb") || p.isAbbr("frac") {
					p.i++
					if !p.atEnd() && p.tok().K == TNum {
						in.constExpr(p)
					}
				}
			} else if p.isAbbr("var$iable") || p.isAbbr("bgnd") || p.isAbbr("black") {
				p.i++
			} else {
				in.constExpr(p)
			}
		case p.isAbbr("nohidden3d") || p.isAbbr("nocontours") || p.isAbbr("nosurface") || p.isAbbr("noenh$anced") || p.isAbbr("enh$anced") || p.isAbbr("hidden3d") || p.isAbbr("point") || p.isAbbr("nopoint") || p.isAbbr("left") || p.isAbbr("right") || p.isAbbr("center") || p.isAbbr("front") || p.isAbbr("back") || p.isAbbr("above") || p.isAbbr("below") || p.isAbbr("closed") || p.isAbbr("x1") || p.isAbbr("x2") || p.isAbbr("y1") || p.isAbbr("y2") || p.isAbbr("heads") || p.isAbbr("nohead") || p.isAbbr("head") || p.isAbbr("filled") || p.isAbbr("empty") || p.isAbbr("solid") || p.isAbbr("border") || p.isAbbr("noborder") || p.isAbbr("rotate") || p.isAbbr("norotate"):
			p.i++
		case p.isAbbr("offset") || p.isAbbr("font") || p.isAbbr("boxwidth"):
			p.i++
			in.constExpr(p)
			if p.is(",") && p.peek(1).K == TNum {
				p.i++
				in.constExpr(p)
			}
		default:
			if p.isAbbr("s$mooth") && !el.IsFunc {
				p.i++
				if p.tok().K == TIdent {
					p.i++
				}
				continue
			}
			gpErr(p.tok().Pos, "unexpected or unrecognized token: "+p.tok().Text)
		}
	}
	return el
}

func (in *Interp) parseUsing(p *P, el *PlotElem) {
	for {
		t := p.tok()
		if t.K == TNum && t.Num.K == KInt && (p.peek(1).Text == ":" || p.peek(1).K == TEnd || p.peek(1).Text == "," || p.peek(1).K == TIdent || p.peek(1).Text == ";") {
			n := int(t.Num.I)
			p.i++
			el.UsingRaw = append(el.UsingRaw, n)
			nn := n
			el.Using = append(el.Using, func(e *Env) Value { return columnValue(e, nn, in) })
			el.UsingStr = append(el.UsingStr, false)
		} else if t.K == TStr {
			name := t.Str
			p.i++
			el.UsingRaw = append(el.UsingRaw, -100)
			el.UsesNames = true
			el.Using = append(el.Using, func(e *Env) Value { return columnByName(e, name, in) })
			el.UsingStr = append(el.UsingStr, false)
		} else if t.K == TIdent && (abbrev(t.Text, "xtic$labels") || abbrev(t.Text, "ytic$labels") || abbrev(t.Text, "x2tic$labels") || t.Text == "key") && p.peek(1).Text == "(" {
			p.i++
			f := p.parsePrimary()
			_ = f
			p.i-- // parsePrimary on '(' consumed paren expression
			p.i++
			if t.Text[0] == 'x' {
				el.XticFn = f
			}
		} else if !p.is("(") {
			v := in.constExpr(p)
			if v.K == KStr {
				name := v.S
				el.UsingRaw = append(el.UsingRaw, -100)
				el.UsesNames = true
				el.Using = append(el.Using, func(e *Env) Value { return columnByName(e, name, in) })
			} else {
				n := int(numToInt(numify(v)))
				el.UsingRaw = append(el.UsingRaw, n)
				el.Using = append(el.Using, func(e *Env) Value { return columnValue(e, n, in) })
			}
			el.UsingStr = append(el.UsingStr, false)
		} else {
			f := p.parseExpr()
			el.UsingRaw = append(el.UsingRaw, 0)
			el.Using = append(el.Using, f)
			el.UsingStr = append(el.UsingStr, false)
		}
		if p.is(":") {
			p.i++
			continue
		}
		break
	}
	el.NUsing = len(el.Using)
}

// --- data evaluation ---

func (in *Interp) inRange(ax string, v float64) bool {
	r := in.S.Ranges[ax]
	lo, hi := r.Min, r.Max
	if lo > hi {
		lo, hi = hi, lo
	}
	if !r.AutoMin && v < lo {
		return false
	}
	if !r.AutoMax && v > hi {
		return false
	}
	return true
}

func (in *Interp) loadDataElem(el *PlotElem) {
	lines := in.dataLines(el.DataName)
	recs, headers := in.scanData(lines, el.Index, el.IndexEnd, el.IndexStep, el.Every)
	el.Headers = headers
	using := el.Using
	raw := el.UsingRaw
	if len(using) == 0 {
		// default using
		ncol := 2
		if el.Is3D {
			ncol = 3
		}
		switch el.Style {
		case "errorbars", "yerrorbars", "xerrorbars", "errorlines", "yerrorlines", "xerrorlines", "boxes", "labels":
			ncol = 3
		case "xyerrorbars", "xyerrorlines", "boxerrorbars", "vectors":
			ncol = 4
		}
		// limited by available columns in first record
		for _, r := range recs {
			if r.Fields != nil {
				if len(r.Fields) < ncol {
					ncol = len(r.Fields)
				}
				break
			}
		}
		if ncol < 1 {
			ncol = 1
		}
		for k := 1; k <= ncol; k++ {
			kk := k
			using = append(using, func(e *Env) Value { return columnValue(e, kk, in) })
			raw = append(raw, kk)
		}
		if ncol == 1 && !el.Is3D {
			using = []EvalFn{func(e *Env) Value { return columnValue(e, 0, in) }, using[0]}
			raw = []int{0, 1}
			raw[0] = -1
		}
	} else if len(using) == 1 && !el.Is3D {
		using = []EvalFn{func(e *Env) Value { return columnValue(e, 0, in) }, using[0]}
		raw = []int{-1, raw[0]}
	} else if len(using) == 2 && el.Is3D {
		using = []EvalFn{func(e *Env) Value { return columnValue(e, -3, in) }, func(e *Env) Value { return columnValue(e, -4, in) }, using[1]}
		raw = []int{-1, -1, raw[1]}
	}
	el.NUsing = len(using)
	headerSkipped := false
	for ri, r := range recs {
		if r.Fields == nil {
			if len(el.Pts) > 0 && !el.Pts[len(el.Pts)-1].Brk {
				el.Pts = append(el.Pts, Pt{Brk: true})
			}
			continue
		}
		_ = ri
		if (el.TitleColHead || el.UsesNames || in.S.KeyColHead) && !headerSkipped && r == firstRec(recs) {
			headerSkipped = true
			continue
		}
		row := &DataRow{cols: r.Fields, line: r.Line, index: r.Index, headers: headers}
		vals := make([]float64, len(using))
		undef := false
		skip := false
		for k, f := range using {
			if raw[k] > 0 {
				// plain column
				n := raw[k]
				if n > len(r.Fields) {
					skip = true
					break
				}
				s := r.Fields[n-1]
				if in.S.DFMissing != "" && s == in.S.DFMissing {
					skip = true
					break
				}
				v, ok := parseField(s)
				if !ok {
					skip = true
					break
				}
				vals[k] = v
				continue
			}
			e := &Env{row: row}
			v := f(e)
			if e.undef {
				undef = true
				vals[k] = math.NaN()
				continue
			}
			if v.K == KStr {
				fv, ok := parseField(v.S)
				if !ok {
					undef = true
					vals[k] = math.NaN()
					continue
				}
				vals[k] = fv
				continue
			}
			vals[k] = numify(v).Real()
			if math.IsNaN(vals[k]) {
				undef = true
			}
		}
		if skip {
			continue
		}
		pt := Pt{X: vals[0], Typ: 'i'}
		if len(vals) > 1 {
			pt.Y = vals[1]
		}
		if len(vals) > 2 {
			pt.Ex = vals[2:]
			if el.Is3D {
				pt.Z = vals[2]
				pt.Ex = vals[3:]
			}
		}
		if el.XticFn != nil {
			e := &Env{row: row}
			v := el.XticFn(e)
			if v.K == KStr {
				pt.XTic = v.S
			} else {
				pt.XTic = v.PrintString()
			}
			pt.HasXTic = true
		}
		if undef {
			pt.Typ = 'u'
		} else if !in.inRange("x", pt.X) || (!el.Is3D && !in.inRange("y", pt.Y)) || (el.Is3D && !in.inRange("z", pt.Z)) {
			pt.Typ = 'o'
		}
		el.Pts = append(el.Pts, pt)
	}
	for len(el.Pts) > 0 && el.Pts[len(el.Pts)-1].Brk {
		el.Pts = el.Pts[:len(el.Pts)-1]
	}
	if (el.TitleColHead || (in.S.KeyColHead && !el.TitleSet && !el.NoTitle)) && len(raw) > 1 {
		el.TitleColHead = true
		c := raw[1]
		if el.Is3D && len(raw) > 2 {
			c = raw[2]
		}
		if c > 0 && c <= len(headers) {
			el.Title = headers[c-1]
		}
	}
}

func firstRec(recs []*DataRec) *DataRec {
	for _, r := range recs {
		if r.Fields != nil {
			return r
		}
	}
	return nil
}

func (in *Interp) evalFuncAt(el *PlotElem, x float64) (float64, bool) {
	e := &Env{locals: map[string]Value{in.S.Dummy[0]: FltV(x)}}
	v := el.Fn(e)
	if e.undef {
		return math.NaN(), false
	}
	if v.K == KStr {
		gpErrNC("all points y value undefined!")
	}
	v = numify(v)
	re, im := cparts(v)
	if math.Abs(im) > in.S.Zero && v.K == KCmplx {
		return math.NaN(), false
	}
	if math.IsNaN(re) || math.IsInf(re, 0) {
		return re, false
	}
	return re, true
}

// executePlot computes ranges, samples functions and outputs
func (in *Interp) executePlot(elems []*PlotElem, ranges []*Range, is3d bool) {
	S := in.S
	// apply command-line ranges temporarily
	axes := []string{"x", "y"}
	if S.Parametric && !is3d {
		axes = []string{"t", "x", "y"}
	} else if S.Polar && !is3d {
		axes = []string{"t", "x", "y"}
	}
	if is3d && S.Parametric {
		axes = []string{"u", "v", "x", "y", "z"}
	} else if is3d {
		axes = []string{"x", "y", "z"}
	}
	saved := map[string]Range{}
	for _, a := range []string{"x", "y", "z", "t", "u", "v"} {
		saved[a] = *S.Ranges[a]
	}
	defer func() {
		for a, r := range saved {
			*S.Ranges[a] = r
		}
	}()
	for k, r := range ranges {
		if k >= len(axes) {
			break
		}
		cr := S.Ranges[axes[k]]
		if !r.AutoMin {
			cr.Min = r.Min
			cr.AutoMin = false
		}
		if !r.AutoMax {
			cr.Max = r.Max
			cr.AutoMax = false
		}
	}
	// load data
	nodata := true
	for _, el := range elems {
		for k, v := range el.IterVars {
			in.sv(k, v)
		}
		if !el.IsFunc {
			if !strings.HasPrefix(el.DataName, "$") {
				if _, err := os.Stat(el.DataName); err != nil {
					in.warn("Cannot find or open file \"" + el.DataName + "\"")
					el.Missing = true
					continue
				}
			}
			in.loadDataElem(el)
			el.OrigCount = len(el.Pts)
			if len(el.Pts) > 0 {
				nodata = false
			}
		} else {
			nodata = false
		}
	}
	if nodata {
		gpErrNC("No data in plot")
	}
	// x range from data
	xr := S.Ranges["x"]
	xmin, xmax := math.Inf(1), math.Inf(-1)
	for _, el := range elems {
		if el.IsFunc {
			continue
		}
		for _, pt := range el.Pts {
			if pt.Brk || pt.Typ == 'u' {
				continue
			}
			if !in.inRange("x", pt.X) {
				continue
			}
			xmin = math.Min(xmin, pt.X)
			xmax = math.Max(xmax, pt.X)
			if el.Style == "boxes" || el.Style == "xerrorbars" {
			}
		}
	}
	lo, hi := xr.Min, xr.Max
	if xr.AutoMin {
		if !math.IsInf(xmin, 0) {
			lo = xmin
		} else {
			lo = -10
		}
	}
	if xr.AutoMax {
		if !math.IsInf(xmax, 0) {
			hi = xmax
		} else {
			hi = 10
		}
	}
	if S.Log["x"] > 0 && xr.AutoMin && math.IsInf(xmin, 0) {
		lo, hi = 0.1, 10
	}
	// sample functions
	for _, el := range elems {
		if !el.IsFunc {
			continue
		}
		for k, v := range el.IterVars {
			in.sv(k, v)
		}
		flo, fhi := lo, hi
		if el.Range != nil {
			if !el.Range.AutoMin {
				flo = el.Range.Min
			}
			if !el.Range.AutoMax {
				fhi = el.Range.Max
			}
		}
		n := S.Samples1
		if S.Parametric || S.Polar {
			tr := S.Ranges["t"]
			flo, fhi = tr.Min, tr.Max
			if el.Range != nil {
				if !el.Range.AutoMin {
					flo = el.Range.Min
				}
				if !el.Range.AutoMax {
					fhi = el.Range.Max
				}
			}
		}
		logx := S.Log["x"]
		for k := 0; k < n; k++ {
			var x float64
			if logx > 0 && !S.Parametric {
				l0, l1 := math.Log(flo), math.Log(fhi)
				x = math.Exp(l0 + float64(k)*(l1-l0)/float64(n-1))
			} else {
				x = flo + float64(k)*(fhi-flo)/float64(n-1)
			}
			if S.Parametric && el.Fn2 != nil {
				xv, ok1 := in.evalFuncAt(el, x)
				e := &Env{locals: map[string]Value{S.Dummy[0]: FltV(x)}}
				yv := numify(el.Fn2(e))
				pt := Pt{X: xv, Y: yv.Real(), Typ: 'i'}
				if !ok1 || e.undef {
					pt.Typ = 'u'
				}
				el.Pts = append(el.Pts, pt)
				continue
			}
			y, ok := in.evalFuncAt(el, x)
			pt := Pt{X: x, Y: y, Typ: 'i'}
			if S.Polar {
				pt.X = y * math.Cos(in.angIn(x))
				pt.Y = y * math.Sin(in.angIn(x))
			}
			if !ok {
				pt.Typ = 'u'
				pt.X, pt.Y = 0, 0
			} else if !in.inRange("y", pt.Y) || !in.inRange("x", pt.X) {
				pt.Typ = 'o'
			}
			el.Pts = append(el.Pts, pt)
		}
		el.OrigCount = len(el.Pts)
	}
	// smoothing
	for _, el := range elems {
		if el.Smooth != "" {
			in.applySmooth(el)
		}
	}
	if S.TableOn {
		in.writeTable(elems)
		return
	}
	in.renderPlot(elems, is3d)
}

func (in *Interp) elemTitle(el *PlotElem) string {
	if el.TitleSet || el.TitleColHead {
		return el.Title
	}
	if el.IsFunc {
		return el.FnText
	}
	return el.SpecText
}

func fmtTbl(f float64) string {
	return cfmt("% g", f)
}

func (in *Interp) writeTable(elems []*PlotElem) {
	var w io.Writer = in.tableWriter()
	var b strings.Builder
	for ci, el := range elems {
		fmt.Fprintf(&b, "\n# Curve %d of %d, %d points\n", ci, len(elems), el.OrigCount)
		fmt.Fprintf(&b, "# Curve title: \"%s\"\n", in.elemTitle(el))
		cols := "x y"
		switch el.Style {
		case "errorbars", "yerrorbars", "errorlines", "yerrorlines":
			cols = "x y ylow yhigh"
		case "xerrorbars", "xerrorlines", "boxes":
			cols = "x y xlow xhigh"
		case "xyerrorbars", "xyerrorlines":
			cols = "x y xlow xhigh ylow yhigh"
		case "labels":
			cols = "x y label"
		}
		if el.Is3D {
			cols = "x y z"
		}
		fmt.Fprintf(&b, "# %s type\n", cols)
		for _, pt := range el.Pts {
			if pt.Brk {
				b.WriteString("\n")
				continue
			}
			vals := []float64{pt.X, pt.Y}
			if el.Is3D {
				vals = append(vals, pt.Z)
			}
			switch el.Style {
			case "errorbars", "yerrorbars", "errorlines", "yerrorlines":
				if len(pt.Ex) >= 2 {
					vals = append(vals, pt.Ex[0], pt.Ex[1])
				} else if len(pt.Ex) == 1 {
					vals = append(vals, pt.Y-pt.Ex[0], pt.Y+pt.Ex[0])
				} else {
					vals = append(vals, pt.Y, pt.Y)
				}
			case "xerrorbars", "xerrorlines":
				if len(pt.Ex) >= 2 {
					vals = append(vals, pt.Ex[0], pt.Ex[1])
				} else if len(pt.Ex) == 1 {
					vals = append(vals, pt.X-pt.Ex[0], pt.X+pt.Ex[0])
				} else {
					vals = append(vals, pt.X, pt.X)
				}
			case "boxes":
				if len(pt.Ex) >= 1 {
					vals = append(vals, pt.X-pt.Ex[0]/2, pt.X+pt.Ex[0]/2)
				} else if in.S.BoxWidth > 0 && in.S.BoxAbs {
					vals = append(vals, pt.X-in.S.BoxWidth/2, pt.X+in.S.BoxWidth/2)
				} else {
					vals = append(vals, pt.X, pt.X)
				}
			case "xyerrorbars", "xyerrorlines":
				if len(pt.Ex) >= 4 {
					vals = append(vals, pt.Ex[0], pt.Ex[1], pt.Ex[2], pt.Ex[3])
				} else if len(pt.Ex) >= 2 {
					vals = append(vals, pt.X-pt.Ex[0], pt.X+pt.Ex[0], pt.Y-pt.Ex[1], pt.Y+pt.Ex[1])
				}
			case "labels":
				var parts []string
				for _, v := range vals {
					parts = append(parts, fmtTbl(v))
				}
				fmt.Fprintf(&b, "%s \"%s\"\n", strings.Join(parts, " "), pt.Label)
				continue
			}
			var parts []string
			for _, v := range vals {
				parts = append(parts, fmtTblV(v))
			}
			fmt.Fprintf(&b, "%s  %c\n", strings.Join(parts, " "), pt.Typ)
		}
		b.WriteString("\n")
	}
	io.WriteString(w, b.String())
}

func fmtTblV(v float64) string {
	if math.IsNaN(v) {
		return " NaN"
	}
	if math.IsInf(v, 1) {
		return " inf"
	}
	if math.IsInf(v, -1) {
		return "-inf"
	}
	return cfmt("% g", v)
}

func (in *Interp) tableWriter() io.Writer {
	if in.tableOut != nil {
		return in.tableOut
	}
	return in.stdout
}

func (in *Interp) openTable() {
	S := in.S
	if S.TableFile == "" {
		in.tableOut = nil
		return
	}
	if strings.HasPrefix(S.TableFile, "$") {
		in.tableOut = &dbWriter{in: in, name: S.TableFile}
		return
	}
	f, err := os.Create(S.TableFile)
	if err != nil {
		gpErrNC("cannot open table output file")
	}
	in.tableOut = f
}

func (in *Interp) closeTable() {
	if f, ok := in.tableOut.(*os.File); ok {
		f.Close()
	}
	in.tableOut = nil
}

// --- smoothing ---

func (in *Interp) applySmooth(el *PlotElem) {
	var segs [][]Pt
	var cur []Pt
	total := 0.0
	for _, p := range el.Pts {
		if p.Brk {
			if len(cur) > 0 {
				segs = append(segs, cur)
			}
			cur = nil
			continue
		}
		if p.Typ == 'u' {
			continue
		}
		total += p.Y
		cur = append(cur, p)
	}
	if len(cur) > 0 {
		segs = append(segs, cur)
	}
	el.SmoothTotal = total
	var out []Pt
	for k, sg := range segs {
		if k > 0 {
			out = append(out, Pt{Brk: true})
		}
		el.Pts = sg
		in.applySmoothSeg(el, sg)
		out = append(out, el.Pts...)
	}
	el.Pts = out
	switch el.Smooth {
	case "unique", "frequency", "cumulative", "cnormal", "fnormal":
		for len(el.Pts) < el.OrigCount {
			el.Pts = append(el.Pts, Pt{Brk: true})
		}
	default:
		el.OrigCount = len(el.Pts)
	}
}

func (in *Interp) applySmoothSeg(el *PlotElem, pts []Pt) {
	switch el.Smooth {
	case "unique", "frequency", "cumulative", "cnormal", "fnormal":
		sort.SliceStable(pts, func(i, j int) bool { return pts[i].X < pts[j].X })
		var out []Pt
		if el.Smooth == "unique" || el.Smooth == "frequency" {
			for i := 0; i < len(pts); {
				j := i
				sum := 0.0
				for j < len(pts) && pts[j].X == pts[i].X {
					sum += pts[j].Y
					j++
				}
				y := sum
				if el.Smooth == "unique" {
					y = sum / float64(j-i)
				}
				out = append(out, Pt{X: pts[i].X, Y: y, Typ: 'i'})
				i = j
			}
		} else {
			sum := 0.0
			total := 0.0
			for _, p := range pts {
				total += p.Y
			}
			for i := 0; i < len(pts); {
				j := i
				for j < len(pts) && pts[j].X == pts[i].X {
					sum += pts[j].Y
					j++
				}
				y := sum
				if el.Smooth == "cnormal" {
					y = sum / el.SmoothTotal
				}
				out = append(out, Pt{X: pts[i].X, Y: y, Typ: 'i'})
				i = j
			}
		}
		for k := range out {
			if !in.inRange("y", out[k].Y) || !in.inRange("x", out[k].X) {
				out[k].Typ = 'o'
			}
		}
		el.Pts = out
	case "csplines", "acsplines", "mcsplines", "bezier", "sbezier":
		sort.SliceStable(pts, func(i, j int) bool { return pts[i].X < pts[j].X })
		// merge identical x (average)
		var u []Pt
		for i := 0; i < len(pts); {
			j := i
			sum := 0.0
			for j < len(pts) && pts[j].X == pts[i].X {
				sum += pts[j].Y
				j++
			}
			u = append(u, Pt{X: pts[i].X, Y: sum / float64(j-i)})
			i = j
		}
		if el.Smooth == "bezier" || el.Smooth == "sbezier" {
			u = pts
		}
		n := in.S.Samples1
		if len(u) == 0 {
			el.Pts = nil
			return
		}
		x0, x1 := u[0].X, u[len(u)-1].X
		var f func(x float64) float64
		switch el.Smooth {
		case "csplines", "acsplines":
			f = naturalSpline(u)
		case "mcsplines":
			f = monotoneSpline(u)
		}
		var out []Pt
		if f != nil {
			for k := 0; k < n; k++ {
				x := x0 + float64(k)*(x1-x0)/float64(n-1)
				out = append(out, Pt{X: x, Y: f(x), Typ: 'i'})
			}
		} else {
			if el.Smooth == "sbezier" {
				u = naturalSplineInterp(u)
			}
			for k := 0; k < n; k++ {
				t := float64(k) / float64(n-1)
				x, y := bezier(u, t)
				out = append(out, Pt{X: x, Y: y, Typ: 'i'})
			}
		}
		for k := range out {
			if !in.inRange("y", out[k].Y) || !in.inRange("x", out[k].X) {
				out[k].Typ = 'o'
			}
		}
		el.Pts = out
	case "kdensity":
		el.Pts = in.kdensity(pts)
	case "bins":
		el.Pts = in.bins(el, pts)
	}
}

func naturalSpline(u []Pt) func(float64) float64 {
	n := len(u)
	if n < 2 {
		return func(x float64) float64 { return u[0].Y }
	}
	if n == 2 {
		return func(x float64) float64 {
			return u[0].Y + (u[1].Y-u[0].Y)*(x-u[0].X)/(u[1].X-u[0].X)
		}
	}
	h := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		h[i] = u[i+1].X - u[i].X
	}
	// solve for second derivatives M
	a := make([]float64, n)
	b := make([]float64, n)
	c := make([]float64, n)
	d := make([]float64, n)
	b[0], b[n-1] = 1, 1
	for i := 1; i < n-1; i++ {
		a[i] = h[i-1]
		b[i] = 2 * (h[i-1] + h[i])
		c[i] = h[i]
		d[i] = 6 * ((u[i+1].Y-u[i].Y)/h[i] - (u[i].Y-u[i-1].Y)/h[i-1])
	}
	// thomas
	for i := 1; i < n; i++ {
		m := a[i] / b[i-1]
		b[i] -= m * c[i-1]
		d[i] -= m * d[i-1]
	}
	M := make([]float64, n)
	M[n-1] = d[n-1] / b[n-1]
	for i := n - 2; i >= 0; i-- {
		M[i] = (d[i] - c[i]*M[i+1]) / b[i]
	}
	return func(x float64) float64 {
		i := sort.Search(n-1, func(k int) bool { return u[k+1].X >= x })
		if i >= n-1 {
			i = n - 2
		}
		hi := h[i]
		t1 := u[i+1].X - x
		t2 := x - u[i].X
		return M[i]*t1*t1*t1/(6*hi) + M[i+1]*t2*t2*t2/(6*hi) + (u[i].Y/hi-M[i]*hi/6)*t1 + (u[i+1].Y/hi-M[i+1]*hi/6)*t2
	}
}

func naturalSplineInterp(u []Pt) []Pt { return u }

func monotoneSpline(u []Pt) func(float64) float64 {
	n := len(u)
	if n < 2 {
		return func(x float64) float64 { return u[0].Y }
	}
	d := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		d[i] = (u[i+1].Y - u[i].Y) / (u[i+1].X - u[i].X)
	}
	m := make([]float64, n)
	m[0] = d[0]
	m[n-1] = d[n-2]
	for i := 1; i < n-1; i++ {
		if d[i-1]*d[i] <= 0 {
			m[i] = 0
		} else {
			m[i] = (d[i-1] + d[i]) / 2
		}
	}
	for i := 0; i < n-1; i++ {
		if d[i] == 0 {
			m[i], m[i+1] = 0, 0
			continue
		}
		a := m[i] / d[i]
		b := m[i+1] / d[i]
		s := a*a + b*b
		if s > 9 {
			t := 3 / math.Sqrt(s)
			m[i] = t * a * d[i]
			m[i+1] = t * b * d[i]
		}
	}
	return func(x float64) float64 {
		i := sort.Search(n-1, func(k int) bool { return u[k+1].X >= x })
		if i >= n-1 {
			i = n - 2
		}
		h := u[i+1].X - u[i].X
		t := (x - u[i].X) / h
		t2, t3 := t*t, t*t*t
		return (2*t3-3*t2+1)*u[i].Y + (t3-2*t2+t)*h*m[i] + (-2*t3+3*t2)*u[i+1].Y + (t3-t2)*h*m[i+1]
	}
}

func bezier(u []Pt, t float64) (float64, float64) {
	n := len(u) - 1
	x, y := 0.0, 0.0
	for k := 0; k <= n; k++ {
		c := binom(n, k) * math.Pow(t, float64(k)) * math.Pow(1-t, float64(n-k))
		x += c * u[k].X
		y += c * u[k].Y
	}
	return x, y
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func (in *Interp) kdensity(pts []Pt) []Pt {
	n := len(pts)
	if n == 0 {
		return nil
	}
	// default bandwidth
	mean, sd := 0.0, 0.0
	for _, p := range pts {
		mean += p.X
	}
	mean /= float64(n)
	for _, p := range pts {
		sd += (p.X - mean) * (p.X - mean)
	}
	sd = math.Sqrt(sd / float64(n))
	bw := sd * math.Pow(4.0/(3.0*float64(n)), 0.2)
	lo, hi := math.Inf(1), math.Inf(-1)
	for _, p := range pts {
		lo = math.Min(lo, p.X)
		hi = math.Max(hi, p.X)
	}
	ns := in.S.Samples1
	var out []Pt
	for k := 0; k < ns; k++ {
		x := lo + float64(k)*(hi-lo)/float64(ns-1)
		y := 0.0
		for _, p := range pts {
			z := (x - p.X) / bw
			y += p.Y * math.Exp(-z*z/2) / (bw * math.Sqrt(2*math.Pi))
		}
		out = append(out, Pt{X: x, Y: y, Typ: 'i'})
	}
	return out
}

func (in *Interp) bins(el *PlotElem, pts []Pt) []Pt {
	if len(pts) == 0 {
		return nil
	}
	lo, hi := math.Inf(1), math.Inf(-1)
	for _, p := range pts {
		lo = math.Min(lo, p.X)
		hi = math.Max(hi, p.X)
	}
	nb := el.BinsN
	if nb <= 0 {
		nb = 10
	}
	w := (hi - lo) / float64(nb-1)
	if el.BinWidth > 0 {
		w = el.BinWidth
		nb = int(math.Floor((hi-lo)/w)) + 1
	}
	if w == 0 {
		w = 1
	}
	cnt := make([]float64, nb)
	for _, p := range pts {
		k := int(math.Floor((p.X-lo)/w + 0.5))
		if k < 0 || k >= nb {
			continue
		}
		cnt[k] += p.Y
	}
	var out []Pt
	for k := 0; k < nb; k++ {
		out = append(out, Pt{X: lo + float64(k)*w, Y: cnt[k], Typ: 'i'})
	}
	return out
}
