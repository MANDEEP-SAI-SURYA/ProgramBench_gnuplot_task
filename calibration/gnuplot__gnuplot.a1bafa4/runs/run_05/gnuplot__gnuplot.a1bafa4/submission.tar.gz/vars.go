package main

import "sort"

func (in *Interp) sv(name string, v Value) {
	if _, ok := in.vars[name]; !ok {
		in.seq++
		in.varSeq[name] = in.seq
	}
	in.vars[name] = v
}

func (in *Interp) delVar(name string) {
	delete(in.vars, name)
	delete(in.varSeq, name)
}

func (in *Interp) varOrderList() []string {
	var names []string
	for n := range in.vars {
		names = append(names, n)
	}
	sort.Slice(names, func(i, j int) bool { return in.varSeq[names[i]] < in.varSeq[names[j]] })
	return names
}
