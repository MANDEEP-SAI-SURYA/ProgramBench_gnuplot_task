package main

import (
	"math"
	"strconv"
	"strings"
)

type Kind int

const (
	KUndef Kind = iota
	KInt
	KCmplx
	KStr
	KArr
)

type Value struct {
	K   Kind
	I   int64
	Re  float64
	Im  float64
	S   string
	Arr *[]Value
}

func IntV(i int64) Value     { return Value{K: KInt, I: i} }
func FltV(f float64) Value   { return Value{K: KCmplx, Re: f} }
func CpxV(r, i float64) Value { return Value{K: KCmplx, Re: r, Im: i} }
func StrV(s string) Value    { return Value{K: KStr, S: s} }

func (v Value) IsNum() bool { return v.K == KInt || v.K == KCmplx }

// Real returns the real part as float.
func (v Value) Real() float64 {
	switch v.K {
	case KInt:
		return float64(v.I)
	case KCmplx:
		return v.Re
	case KStr:
		f, ok := strToNum(v.S)
		if ok {
			return f.Real()
		}
	}
	return 0
}

func strToNum(s string) (Value, bool) {
	t := strings.TrimSpace(s)
	if t == "" {
		return Value{}, false
	}
	// parse leading numeric like strtod
	n := scanNumberPrefix(t)
	if n == 0 {
		return Value{}, false
	}
	f, err := strconv.ParseFloat(t[:n], 64)
	if err != nil {
		if ne, ok := err.(*strconv.NumError); ok && ne.Err == strconv.ErrRange {
		} else {
			return Value{}, false
		}
	}
	if !strings.ContainsAny(t[:n], ".eE") {
		i, err := strconv.ParseInt(t[:n], 10, 64)
		if err == nil {
			return IntV(i), true
		}
	}
	return FltV(f), true
}

func scanNumberPrefix(t string) int {
	i := 0
	if i < len(t) && (t[i] == '+' || t[i] == '-') {
		i++
	}
	d := 0
	for i < len(t) && t[i] >= '0' && t[i] <= '9' {
		i++
		d++
	}
	if i < len(t) && t[i] == '.' {
		i++
		for i < len(t) && t[i] >= '0' && t[i] <= '9' {
			i++
			d++
		}
	}
	if d == 0 {
		return 0
	}
	if i < len(t) && (t[i] == 'e' || t[i] == 'E') {
		j := i + 1
		if j < len(t) && (t[j] == '+' || t[j] == '-') {
			j++
		}
		k := j
		for k < len(t) && t[k] >= '0' && t[k] <= '9' {
			k++
		}
		if k > j {
			i = k
		}
	}
	return i
}

func fmtG15(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	return cfmt("%.15g", f)
}

func fmtReal(f float64) string {
	s := fmtG15(f)
	if s == "NaN" {
		return s
	}
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

// format value as print does
func (v Value) PrintString() string {
	switch v.K {
	case KInt:
		return strconv.FormatInt(v.I, 10)
	case KCmplx:
		if v.Im == 0 {
			return fmtReal(v.Re)
		}
		return "{" + fmtReal(v.Re) + ", " + fmtReal(v.Im) + "}"
	case KStr:
		return v.S
	case KArr:
		var b strings.Builder
		b.WriteString("[")
		for i, e := range (*v.Arr)[1:] {
			if i > 0 {
				b.WriteString(",")
			}
			switch e.K {
			case KStr:
				b.WriteString("\"" + e.S + "\"")
			case KUndef:
			default:
				b.WriteString(e.PrintString())
			}
		}
		b.WriteString("]\n")
		return b.String()
	}
	return ""
}

func truthy(v Value) bool {
	switch v.K {
	case KInt:
		return v.I != 0
	case KCmplx:
		return v.Re != 0 || v.Im != 0
	}
	return false
}
