package main

import "os"

func (in *Interp) clearCmd()                               {}
func (in *Interp) closeOutput() {
	if in.outFile != nil {
		in.outFile.Close()
		in.outFile = nil
	}
}
func (in *Interp) setMultiplot(p *P, unset bool) { in.skipToEnd(p) }

func createFile(name string) (*os.File, error) { return os.Create(name) }
