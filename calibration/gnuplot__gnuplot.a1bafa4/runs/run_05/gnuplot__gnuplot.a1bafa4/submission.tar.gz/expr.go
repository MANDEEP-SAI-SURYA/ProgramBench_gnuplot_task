package main

import (
	"math"
	"math/cmplx"
	"strconv"
	"strings"
)

type GpErr struct {
	Msg string
	Pos int // -1: no caret
}

func gpErr(pos int, msg string) { panic(&GpErr{Msg: msg, Pos: pos}) }
func gpErrNC(msg string)        { panic(&GpErr{Msg: msg, Pos: -1}) }

type Env struct {
	locals map[string]Value
	undef  bool
	row    *DataRow
}

type DataRow struct {
	cols    []string // raw fields
	line    int      // line number in dataset (0-based)
	index   int
	headers []string
	colhead bool
}

type EvalFn func(e *Env) Value

type UserFunc struct {
	Name   string
	Params []string
	Body   EvalFn
	Text   string
}

type P struct {
	in   *Interp
	toks []Token
	i    int
	line string
	// dummy names usable inside expression (for function definition)
}

func (p *P) tok() *Token { return &p.toks[p.i] }
func (p *P) peek(k int) *Token {
	if p.i+k < len(p.toks) {
		return &p.toks[p.i+k]
	}
	return &p.toks[len(p.toks)-1]
}
func (p *P) is(s string) bool {
	t := p.tok()
	return (t.K == TOp || t.K == TIdent) && t.Text == s
}
func (p *P) atEnd() bool {
	t := p.tok()
	return t.K == TEnd || (t.K == TOp && t.Text == ";")
}
func (p *P) expect(s string) {
	if !p.is(s) {
		gpErr(p.tok().Pos, "'"+s+"' expected")
	}
	p.i++
}

// almost_equals style abbreviation matching, e.g. "rep$lot"
func abbrev(word, pat string) bool {
	d := strings.IndexByte(pat, '$')
	if d < 0 {
		return word == pat
	}
	full := pat[:d] + pat[d+1:]
	if len(word) < d || len(word) > len(full) {
		return false
	}
	return strings.HasPrefix(full, word)
}
func (p *P) isAbbr(pat string) bool {
	t := p.tok()
	return t.K == TIdent && abbrev(t.Text, pat)
}

func (p *P) parseExpr() EvalFn {
	t := p.tok()
	// assignment inside expression
	if t.K == TIdent && p.peek(1).K == TOp && p.peek(1).Text == "=" {
		name := t.Text
		p.i += 2
		rhs := p.parseExpr()
		in := p.in
		return func(e *Env) Value {
			v := rhs(e)
			in.setVar(name, v)
			return v
		}
	}
	return p.parseTernary()
}

func (p *P) parseTernary() EvalFn {
	c := p.parseBinary(0)
	if p.is("?") {
		p.i++
		a := p.parseTernary()
		p.expect(":")
		b := p.parseTernary()
		return func(e *Env) Value {
			cv := c(e)
			if truthy(numify(cv)) {
				return a(e)
			}
			return b(e)
		}
	}
	return c
}

var binLevels = [][]string{
	{"||"}, {"&&"}, {"|"}, {"^"}, {"&"}, {"==", "!=", "eq", "ne"}, {"<", "<=", ">", ">="}, {"<<", ">>"}, {"+", "-", "."}, {"*", "/", "%"},
}

func (p *P) parseBinary(level int) EvalFn {
	if level >= len(binLevels) {
		return p.parseUnary()
	}
	left := p.parseBinary(level + 1)
	for {
		t := p.tok()
		if t.K != TOp && t.K != TIdent {
			return left
		}
		found := ""
		for _, o := range binLevels[level] {
			if t.Text == o {
				found = o
			}
		}
		if found == "" {
			return left
		}
		if t.K == TIdent && found != "eq" && found != "ne" {
			return left
		}
		p.i++
		right := p.parseBinary(level + 1)
		l := left
		op := found
		switch op {
		case "&&":
			left = func(e *Env) Value {
				a := numify(l(e))
				if !truthy(a) {
					return IntV(0)
				}
				if truthy(numify(right(e))) {
					return IntV(1)
				}
				return IntV(0)
			}
		case "||":
			left = func(e *Env) Value {
				a := numify(l(e))
				if truthy(a) {
					return IntV(1)
				}
				if truthy(numify(right(e))) {
					return IntV(1)
				}
				return IntV(0)
			}
		default:
			left = func(e *Env) Value { return binop(e, op, l(e), right(e)) }
		}
	}
}

func numify(v Value) Value {
	if v.K == KStr {
		n, ok := strToNum(v.S)
		if !ok {
			gpErrNC("Non-numeric string found where a numeric expression was expected")
		}
		return n
	}
	if v.K == KArr {
		gpErrNC("non-scalar argument")
	}
	return v
}

func checkInt(v Value, msg string) int64 {
	if v.K != KInt {
		gpErrNC(msg)
	}
	return v.I
}

func binop(e *Env, op string, a, b Value) Value {
	switch op {
	case ".":
		if a.K != KStr {
			gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		if b.K == KStr {
			return StrV(a.S + b.S)
		}
		if b.K == KInt {
			return StrV(a.S + strconv.FormatInt(b.I, 10))
		}
		gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
	case "eq", "ne":
		if a.K != KStr || b.K != KStr {
			gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		r := a.S == b.S
		if op == "ne" {
			r = !r
		}
		return boolV(r)
	}
	if a.K == KStr && b.K == KStr && (op == "==" || op == "!=") {
		// gnuplot treats both strings numerically
	}
	a = numify(a)
	b = numify(b)
	if a.K == KInt && b.K == KInt {
		x, y := a.I, b.I
		switch op {
		case "+":
			r := x + y
			if (x >= 0) == (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) + float64(y))
			}
			return IntV(r)
		case "-":
			r := x - y
			if (x >= 0) != (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) - float64(y))
			}
			return IntV(r)
		case "*":
			if x != 0 && y != 0 {
				r := x * y
				if r/y != x || (x == -1 && y == math.MinInt64) || (y == -1 && x == math.MinInt64) {
					return FltV(float64(x) * float64(y))
				}
				return IntV(r)
			}
			return IntV(0)
		case "/":
			if y == 0 {
				e.undef = true
				return IntV(0)
			}
			return IntV(x / y)
		case "%":
			if y == 0 {
				e.undef = true
				return IntV(0)
			}
			return IntV(x % y)
		case "==":
			return boolV(x == y)
		case "!=":
			return boolV(x != y)
		case "<":
			return boolV(x < y)
		case "<=":
			return boolV(x <= y)
		case ">":
			return boolV(x > y)
		case ">=":
			return boolV(x >= y)
		case "&":
			return IntV(x & y)
		case "|":
			return IntV(x | y)
		case "^":
			return IntV(x ^ y)
		case "<<":
			return IntV(int64(uint64(x) << uint64(y)))
		case ">>":
			return IntV(int64(uint64(x) >> uint64(y)))
		case "**":
			return intPow(x, y)
		}
	}
	switch op {
	case "%", "&", "|", "^", "<<", ">>":
		gpErrNC(map[string]string{"%": "non-integer operand for %", "&": "non-integer operand for &", "|": "non-integer operand for |", "^": "non-integer operand for ^", "<<": "non-integer operand for <<", ">>": "non-integer operand for >>"}[op])
	}
	ar, ai := cparts(a)
	br, bi := cparts(b)
	switch op {
	case "+":
		return CpxV(ar+br, ai+bi)
	case "-":
		return CpxV(ar-br, ai-bi)
	case "*":
		if ai == 0 && bi == 0 {
			return FltV(ar * br)
		}
		return CpxV(ar*br-ai*bi, ar*bi+ai*br)
	case "/":
		if bi == 0 {
			if br == 0 {
				e.undef = true
				return FltV(0)
			}
			return CpxV(ar/br, ai/br)
		}
		c := complex(ar, ai) / complex(br, bi)
		return CpxV(real(c), imag(c))
	case "==":
		return boolV(ar == br && ai == bi)
	case "!=":
		return boolV(!(ar == br && ai == bi))
	case "<":
		return boolV(ar < br)
	case "<=":
		return boolV(ar <= br)
	case ">":
		return boolV(ar > br)
	case ">=":
		return boolV(ar >= br)
	case "**":
		if ai == 0 && bi == 0 {
			if b.K == KInt && ar == 0 && b.I < 0 {
				e.undef = true
				return FltV(0)
			}
			if ar < 0 && br != math.Trunc(br) {
				c := cmplx.Pow(complex(ar, 0), complex(br, 0))
				return CpxV(real(c), imag(c))
			}
			if ar == 0 && br == 0 {
				return FltV(1)
			}
			return FltV(math.Pow(ar, br))
		}
		if ar == 0 && ai == 0 {
			return FltV(0)
		}
		c := cmplx.Pow(complex(ar, ai), complex(br, bi))
		return CpxV(real(c), imag(c))
	}
	gpErrNC("unknown operator " + op)
	return Value{}
}

func intPow(x, y int64) Value {
	if y < 0 {
		if x == 0 {
			return FltV(math.Inf(1))
		}
		return FltV(math.Pow(float64(x), float64(y)))
	}
	r := int64(1)
	base := x
	ov := false
	for i := int64(0); i < y; i++ {
		nr := r * base
		if base != 0 && nr/base != r {
			ov = true
			break
		}
		r = nr
		if r == 0 || r == 1 && base == 1 {
			break
		}
		if base == -1 {
			if y%2 == 0 {
				r = 1
			} else {
				r = -1
			}
			break
		}
	}
	if ov {
		return FltV(math.Pow(float64(x), float64(y)))
	}
	return IntV(r)
}

func cparts(v Value) (float64, float64) {
	if v.K == KInt {
		return float64(v.I), 0
	}
	return v.Re, v.Im
}

func boolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

func (p *P) parseUnary() EvalFn {
	t := p.tok()
	if t.K == TOp {
		switch t.Text {
		case "-":
			p.i++
			a := p.parseUnary()
			return func(e *Env) Value {
				v := numify(a(e))
				if v.K == KInt {
					return IntV(-v.I)
				}
				return CpxV(-v.Re, -v.Im)
			}
		case "+":
			p.i++
			a := p.parseUnary()
			return func(e *Env) Value { return numify(a(e)) }
		case "~":
			p.i++
			a := p.parseUnary()
			return func(e *Env) Value {
				v := numify(a(e))
				return IntV(^checkInt(v, "~ operator requires an integer argument"))
			}
		case "!":
			p.i++
			a := p.parseUnary()
			return func(e *Env) Value {
				v := numify(a(e))
				return boolV(!truthy(v))
			}
		}
	}
	return p.parsePow()
}

func (p *P) parsePow() EvalFn {
	base := p.parsePostfix()
	if p.is("**") {
		p.i++
		ex := p.parseUnary()
		return func(e *Env) Value { return binop(e, "**", base(e), ex(e)) }
	}
	return base
}

func factorial(v Value) Value {
	if v.K != KInt {
		gpErrNC("factorial (!) argument must be an integer")
	}
	n := v.I
	if n < 0 {
		return FltV(math.NaN())
	}
	if n <= 20 {
		r := int64(1)
		for i := int64(2); i <= n; i++ {
			r *= i
		}
		return IntV(r)
	}
	r := 1.0
	for i := int64(2); i <= n; i++ {
		r *= float64(i)
	}
	return FltV(r)
}

func (p *P) parsePostfix() EvalFn {
	a := p.parsePrimary()
	for {
		if p.is("!") && !(p.peek(1).K == TOp && p.peek(1).Text == "=") {
			p.i++
			x := a
			a = func(e *Env) Value { return factorial(numify(x(e))) }
			continue
		}
		if p.is("[") {
			p.i++
			var lo, hi EvalFn
			rng := false
			if !p.is(":") {
				lo = p.parseExpr()
			}
			if p.is(":") {
				rng = true
				p.i++
				if !p.is("]") {
					hi = p.parseExpr()
				}
			}
			p.expect("]")
			x := a
			if rng {
				a = func(e *Env) Value {
					v := x(e)
					if v.K != KStr {
						if v.K == KArr {
							arr := *v.Arr
							n := int64(len(arr) - 1)
							l, h := int64(1), n
							if lo != nil {
								l = numToInt(numify(lo(e)))
							}
							if hi != nil {
								h = numToInt(numify(hi(e)))
							}
							if l < 1 {
								l = 1
							}
							if h > n {
								h = n
							}
							na := []Value{{}}
							for k := l; k <= h; k++ {
								na = append(na, arr[k])
							}
							return Value{K: KArr, Arr: &na}
						}
						gpErrNC("substring range specifier applied to non-STRING variable")
					}
					s := v.S
					n := int64(len([]rune(s)))
					l, h := int64(1), n
					if lo != nil {
						l = numToInt(numify(lo(e)))
					}
					if hi != nil {
						h = numToInt(numify(hi(e)))
					}
					return StrV(substrRunes(s, l, h))
				}
			} else {
				a = func(e *Env) Value {
					v := x(e)
					if v.K != KArr {
						gpErrNC("internal error: attempt to index a scalar variable")
					}
					idx := numify(lo(e))
					var k int64
					if idx.K == KInt {
						k = idx.I
					} else {
						k = int64(idx.Re)
					}
					arr := *v.Arr
					if k < 1 || k >= int64(len(arr)) {
						gpErrNC("array index out of range")
					}
					return arr[k]
				}
			}
			continue
		}
		return a
	}
}

func numToInt(v Value) int64 {
	if v.K == KInt {
		return v.I
	}
	return int64(v.Re)
}

func substrRunes(s string, l, h int64) string {
	r := []rune(s)
	n := int64(len(r))
	if l < 1 {
		l = 1
	}
	if h > n {
		h = n
	}
	if l > h {
		return ""
	}
	return string(r[l-1 : h])
}

func (p *P) parsePrimary() EvalFn {
	t := p.tok()
	switch t.K {
	case TNum:
		p.i++
		v := t.Num
		return func(e *Env) Value { return v }
	case TStr:
		p.i++
		v := StrV(t.Str)
		return func(e *Env) Value { return v }
	case TIdent:
		name := t.Text
		if name == "sum" && p.peek(1).K == TOp && p.peek(1).Text == "[" {
			return p.parseSum()
		}
		if strings.HasPrefix(name, "$") {
			p.i++
			rest := name[1:]
			if rest == "" {
				gpErr(t.Pos, "invalid expression ")
			}
			if rest[0] >= '0' && rest[0] <= '9' {
				n, _ := strconv.Atoi(rest)
				return func(e *Env) Value { return columnValue(e, n, p.in) }
			}
			// datablock reference
			in := p.in
			return func(e *Env) Value {
				if db, ok := in.datablocks[name]; ok {
					_ = db
					return StrV(name)
				}
				gpErrNC("undefined variable: " + name)
				return Value{}
			}
		}
		if p.peek(1).K == TOp && p.peek(1).Text == "(" {
			return p.parseCall()
		}
		p.i++
		in := p.in
		return func(e *Env) Value {
			if e.locals != nil {
				if v, ok := e.locals[name]; ok {
					return v
				}
			}
			if v, ok := in.vars[name]; ok {
				return v
			}
			gpErrNC("undefined variable: " + name)
			return Value{}
		}
	case TOp:
		switch t.Text {
		case "(":
			p.i++
			list := []EvalFn{p.parseExpr()}
			for p.is(",") {
				p.i++
				list = append(list, p.parseExpr())
			}
			p.expect(")")
			if len(list) == 1 {
				return list[0]
			}
			return func(e *Env) Value {
				var v Value
				for _, f := range list {
					v = f(e)
				}
				return v
			}
		case "{":
			start := t.Pos
			p.i++
			re := p.cnum(start)
			if !p.is(",") {
				gpErr(start, "invalid complex constant")
			}
			p.i++
			im := p.cnum(start)
			if !p.is("}") {
				gpErr(start, "invalid complex constant")
			}
			p.i++
			v := CpxV(re, im)
			return func(e *Env) Value { return v }
		case "|":
			p.i++
			nt := p.tok()
			if nt.K != TIdent {
				gpErr(nt.Pos, "invalid expression ")
			}
			name := nt.Text
			p.i++
			p.expect("|")
			in := p.in
			return func(e *Env) Value {
				if strings.HasPrefix(name, "$") {
					if db, ok := in.datablocks[name]; ok {
						return IntV(int64(len(db)))
					}
					gpErrNC("undefined variable: " + name)
				}
				v, ok := in.vars[name]
				if !ok {
					gpErrNC("undefined variable: " + name)
				}
				if v.K != KArr {
					gpErrNC("cardinality operator applied to non-array")
				}
				return IntV(int64(len(*v.Arr) - 1))
			}
		case "$":
			// $(expr)? not supported
		}
	}
	if p.i == 0 || t.K == TEnd {
		gpErr(t.Pos, "invalid expression ")
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (p *P) cnum(start int) float64 {
	sign := 1.0
	if p.is("-") {
		sign = -1
		p.i++
	} else if p.is("+") {
		p.i++
	}
	t := p.tok()
	if t.K != TNum {
		gpErr(start, "invalid complex constant")
	}
	p.i++
	return sign * t.Num.Real()
}

func (p *P) parseSum() EvalFn {
	p.i += 2
	vt := p.tok()
	if vt.K != TIdent {
		gpErr(vt.Pos, "syntax error")
	}
	name := vt.Text
	p.i++
	p.expect("=")
	lo := p.parseExpr()
	p.expect(":")
	hi := p.parseExpr()
	p.expect("]")
	body := p.parseExpr()
	in := p.in
	return func(e *Env) Value {
		l := numToInt(numify(lo(e)))
		h := numToInt(numify(hi(e)))
		old, had := in.vars[name]
		acc := IntV(0)
		for k := l; k <= h; k++ {
			in.sv(name, IntV(k))
			acc = binop(e, "+", acc, body(e))
		}
		if had {
			in.sv(name, old)
		} else {
			in.delVar(name)
		}
		return acc
	}
}

func (p *P) parseCall() EvalFn {
	t := p.tok()
	name := t.Text
	p.i += 2
	var args []EvalFn
	if !p.is(")") {
		args = append(args, p.parseExpr())
		for p.is(",") {
			p.i++
			args = append(args, p.parseExpr())
		}
	}
	p.expect(")")
	in := p.in
	if bf, ok := builtins[name]; ok {
		return func(e *Env) Value {
			vals := make([]Value, len(args))
			for i, a := range args {
				vals[i] = a(e)
			}
			return bf(in, e, vals)
		}
	}
	return func(e *Env) Value {
		f, ok := in.funcs[name]
		if !ok {
			gpErrNC("undefined function: " + name)
		}
		if len(args) != len(f.Params) {
			if len(f.Params) == 1 {
				gpErrNC("function " + name + " requires 1 variable")
			}
			gpErrNC("function " + name + " requires " + strconv.Itoa(len(f.Params)) + " variables")
		}
		loc := map[string]Value{}
		for i, a := range args {
			loc[f.Params[i]] = a(e)
		}
		ne := &Env{locals: loc, row: e.row}
		v := f.Body(ne)
		if ne.undef {
			e.undef = true
		}
		return v
	}
}
