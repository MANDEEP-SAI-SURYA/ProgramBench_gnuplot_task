package main

import (
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
	"unicode"
)

type BuiltinFn func(in *Interp, e *Env, a []Value) Value

var builtins map[string]BuiltinFn

func nargs(a []Value, n int) {
	if len(a) < n {
		gpErrNC("stack underflow (function call with missing parameters?)")
	}
}

func real1(f func(float64) float64) BuiltinFn {
	return func(in *Interp, e *Env, a []Value) Value {
		nargs(a, 1)
		v := numify(a[0])
		r := f(v.Real())
		if math.IsNaN(r) || math.IsInf(r, 0) {
			e.undef = true
		}
		return FltV(r)
	}
}

func cplx1(fr func(float64) (float64, bool), fc func(complex128) complex128) BuiltinFn {
	return func(in *Interp, e *Env, a []Value) Value {
		nargs(a, 1)
		v := numify(a[0])
		re, im := cparts(v)
		if im == 0 {
			if r, ok := fr(re); ok {
				return FltV(r)
			}
		}
		c := fc(complex(re, im))
		return CpxV(real(c), imag(c))
	}
}

func (in *Interp) angIn(x float64) float64 {
	if in.degrees {
		return x * math.Pi / 180
	}
	return x
}
func (in *Interp) angOut(x float64) float64 {
	if in.degrees {
		return x * 180 / math.Pi
	}
	return x
}

func trig(f func(float64) float64, fc func(complex128) complex128) BuiltinFn {
	return func(in *Interp, e *Env, a []Value) Value {
		nargs(a, 1)
		v := numify(a[0])
		re, im := cparts(v)
		if im == 0 {
			return FltV(f(in.angIn(re)))
		}
		c := fc(complex(re, im))
		return CpxV(real(c), imag(c))
	}
}

func atrig(f func(float64) float64, ok func(float64) bool, fc func(complex128) complex128) BuiltinFn {
	return func(in *Interp, e *Env, a []Value) Value {
		nargs(a, 1)
		v := numify(a[0])
		re, im := cparts(v)
		if im == 0 && ok(re) {
			return FltV(in.angOut(f(re)))
		}
		c := fc(complex(re, im))
		return CpxV(in.angOut(real(c)), in.angOut(imag(c)))
	}
}

var randS1, randS2 int64 = 1234567890, 123456789

func gpRand(seed Value) float64 {
	s := seed.Real()
	if seed.K == KInt && seed.I < 0 || s < 0 {
		randS1, randS2 = 1234567890, 123456789
		return 0
	}
	if s > 0 {
		randS1 = int64(s)
		randS2 = int64(s)
		if seed.K == KInt {
			randS1 = seed.I
			randS2 = seed.I
		}
		randS1 = randS1 % 2147483563
		randS2 = randS2 % 2147483399
		if randS1 == 0 {
			randS1 = 1
		}
		if randS2 == 0 {
			randS2 = 1
		}
	}
	k := randS1 / 53668
	randS1 = 40014*(randS1-k*53668) - k*12211
	if randS1 < 0 {
		randS1 += 2147483563
	}
	k = randS2 / 52774
	randS2 = 40692*(randS2-k*52774) - k*3791
	if randS2 < 0 {
		randS2 += 2147483399
	}
	z := randS1 - randS2
	if z < 1 {
		z += 2147483562
	}
	return float64(z) * 4.656613057391769e-10
}

func strArg(a Value, fname string) string {
	if a.K != KStr {
		gpErrNC(fname + " requires a string argument")
	}
	return a.S
}

func init() {
	builtins = map[string]BuiltinFn{
		"sin":  trig(math.Sin, cmplx.Sin),
		"cos":  trig(math.Cos, cmplx.Cos),
		"tan":  trig(math.Tan, cmplx.Tan),
		"asin": atrig(math.Asin, func(x float64) bool { return x >= -1 && x <= 1 }, cmplx.Asin),
		"acos": atrig(math.Acos, func(x float64) bool { return x >= -1 && x <= 1 }, cmplx.Acos),
		"atan":  atrig(math.Atan, func(x float64) bool { return true }, cmplx.Atan),
		"sinh":  cplx1(func(x float64) (float64, bool) { return math.Sinh(x), true }, cmplx.Sinh),
		"cosh":  cplx1(func(x float64) (float64, bool) { return math.Cosh(x), true }, cmplx.Cosh),
		"tanh":  cplx1(func(x float64) (float64, bool) { return math.Tanh(x), true }, cmplx.Tanh),
		"asinh": cplx1(func(x float64) (float64, bool) { return math.Asinh(x), true }, cmplx.Asinh),
		"acosh": cplx1(func(x float64) (float64, bool) { return math.Acosh(x), x >= 1 }, cmplx.Acosh),
		"atanh": cplx1(func(x float64) (float64, bool) { return math.Atanh(x), x > -1 && x < 1 }, cmplx.Atanh),
		"exp": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			re, im := cparts(v)
			if im == 0 {
				r := math.Exp(re)
				if math.IsInf(r, 0) {
					e.undef = true
				}
				return FltV(r)
			}
			c := cmplx.Exp(complex(re, im))
			return CpxV(real(c), imag(c))
		},
		"log": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			re, im := cparts(v)
			if im == 0 && re > 0 {
				return FltV(math.Log(re))
			}
			if re == 0 && im == 0 {
				e.undef = true
				return FltV(0)
			}
			c := cmplx.Log(complex(re, im))
			return CpxV(real(c), imag(c))
		},
		"log10": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			re, im := cparts(v)
			if im == 0 && re > 0 {
				return FltV(math.Log10(re))
			}
			if re == 0 && im == 0 {
				e.undef = true
				return FltV(0)
			}
			c := cmplx.Log10(complex(re, im))
			return CpxV(real(c), imag(c))
		},
		"sqrt": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			re, im := cparts(v)
			if im == 0 && re >= 0 {
				return FltV(math.Sqrt(re))
			}
			if im == 0 {
				return CpxV(0, math.Sqrt(-re))
			}
			c := cmplx.Sqrt(complex(re, im))
			return CpxV(real(c), imag(c))
		},
		"abs": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			if v.K == KInt {
				if v.I < 0 {
					return IntV(-v.I)
				}
				return v
			}
			if v.Im == 0 {
				return FltV(math.Abs(v.Re))
			}
			return FltV(math.Hypot(v.Re, v.Im))
		},
		"sgn": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			x := numify(a[0]).Real()
			if x > 0 {
				return IntV(1)
			} else if x < 0 {
				return IntV(-1)
			}
			return IntV(0)
		},
		"real": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			return FltV(numify(a[0]).Real())
		},
		"imag": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			_, im := cparts(numify(a[0]))
			return FltV(im)
		},
		"arg": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			re, im := cparts(numify(a[0]))
			return FltV(in.angOut(math.Atan2(im, re)))
		},
		"int": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			if v.K == KInt {
				return v
			}
			f := math.Trunc(v.Re)
			if math.IsNaN(f) || f >= 9.2233720368547758e18 || f < -9.2233720368547758e18 {
				return FltV(math.NaN())
			}
			return IntV(int64(f))
		},
		"floor": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			if v.K == KInt {
				return v
			}
			f := math.Floor(v.Re)
			if math.IsNaN(f) || math.Abs(f) >= 9.2e18 {
				return FltV(f)
			}
			return IntV(int64(f))
		},
		"ceil": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			v := numify(a[0])
			if v.K == KInt {
				return v
			}
			f := math.Ceil(v.Re)
			if math.IsNaN(f) || math.Abs(f) >= 9.2e18 {
				return FltV(f)
			}
			return IntV(int64(f))
		},
		"round": nil,
		"atan2": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(in.angOut(math.Atan2(numify(a[0]).Real(), numify(a[1]).Real())))
		},
		"gamma": real1(math.Gamma),
		"lgamma": real1(func(x float64) float64 {
			r, _ := math.Lgamma(x)
			return r
		}),
		"erf":     real1(math.Erf),
		"erfc":    real1(math.Erfc),
		"inverf":  real1(math.Erfinv),
		"norm":    real1(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": real1(func(x float64) float64 { return -math.Sqrt2 * math.Erfcinv(2*x) }),
		"besj0":   real1(math.J0),
		"besj1":   real1(math.J1),
		"besy0":   real1(math.Y0),
		"besy1":   real1(math.Y1),
		"besi0":   real1(func(x float64) float64 { return besselI(0, x) }),
		"besi1":   real1(func(x float64) float64 { return besselI(1, x) }),
		"besjn": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(math.Jn(int(numToInt(numify(a[0]))), numify(a[1]).Real()))
		},
		"besyn": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(math.Yn(int(numToInt(numify(a[0]))), numify(a[1]).Real()))
		},
		"besin": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(besselI(int(numToInt(numify(a[0]))), numify(a[1]).Real()))
		},
		"lambertw": real1(lambertW),
		"rand": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			return FltV(gpRand(numify(a[0])))
		},
		"igamma": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(igamma(numify(a[0]).Real(), numify(a[1]).Real()))
		},
		"ibeta": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 3)
			return FltV(ibeta(numify(a[0]).Real(), numify(a[1]).Real(), numify(a[2]).Real()))
		},
		"strlen": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("strlen() requires a string argument")
			}
			return IntV(int64(len([]rune(a[0].S))))
		},
		"strstrt": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			if a[0].K != KStr || a[1].K != KStr {
				gpErrNC("strstrt() requires two string arguments")
			}
			i := strings.Index(a[0].S, a[1].S)
			if i < 0 {
				return IntV(0)
			}
			return IntV(int64(len([]rune(a[0].S[:i])) + 1))
		},
		"substr": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 3)
			if a[0].K != KStr {
				gpErrNC("substr() requires a string argument")
			}
			return StrV(substrRunes(a[0].S, numToInt(numify(a[1])), numToInt(numify(a[2]))))
		},
		"words": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("words() requires a string argument")
			}
			return IntV(int64(len(splitWords(a[0].S))))
		},
		"word": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			if a[0].K != KStr {
				gpErrNC("word() requires a string argument")
			}
			w := splitWords(a[0].S)
			n := numToInt(numify(a[1]))
			if n < 1 || n > int64(len(w)) {
				return StrV("")
			}
			return StrV(w[n-1])
		},
		"trim": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("trim() requires a string argument")
			}
			return StrV(strings.Trim(a[0].S, " \t\n\r\f\v"))
		},
		"sprintf": func(in *Interp, e *Env, a []Value) Value {
			return StrV(gpSprintf(a))
		},
		"gprintf": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			if a[0].K != KStr {
				gpErrNC("First parameter to gprintf must be a format string")
			}
			return StrV(gprintf(a[0].S, numify(a[1]).Real(), in))
		},
		"exists": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("exists() requires a string argument")
			}
			_, ok := in.vars[a[0].S]
			return boolV(ok)
		},
		"value": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("value() requires a string argument")
			}
			v, ok := in.vars[a[0].S]
			if !ok {
				return Value{K: KUndef}
			}
			return v
		},
		"system": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K != KStr {
				gpErrNC("non-string argument to system()")
			}
			out, _ := exec.Command("/bin/sh", "-c", a[0].S).Output()
			s := string(out)
			s = strings.TrimSuffix(s, "\n")
			return StrV(s)
		},
		"time": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			now := float64(time.Now().UnixNano()) / 1e9
			if a[0].K == KStr {
				return StrV(gpStrftime(a[0].S, now))
			}
			if a[0].K == KInt {
				return IntV(int64(now))
			}
			return FltV(now)
		},
		"strftime": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			if a[0].K != KStr {
				gpErrNC("First parameter to strftime must be a format string")
			}
			return StrV(gpStrftime(a[0].S, numify(a[1]).Real()))
		},
		"strptime": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			if a[0].K != KStr || a[1].K != KStr {
				gpErrNC("Both parameters to strptime must be strings")
			}
			t, ok := gpStrptime(a[0].S, a[1].S)
			if !ok {
				e.undef = true
				return FltV(math.NaN())
			}
			return FltV(t)
		},
		"column": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			if a[0].K == KStr {
				return columnByName(e, a[0].S, in)
			}
			return columnValue(e, int(numToInt(numify(a[0]))), in)
		},
		"stringcolumn": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			return stringColumn(e, a[0], in)
		},
		"strcol": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			return stringColumn(e, a[0], in)
		},
		"columnhead": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			n := int(numToInt(numify(a[0])))
			if e.row != nil && n >= 1 && n <= len(e.row.headers) {
				return StrV(e.row.headers[n-1])
			}
			return StrV("")
		},
		"valid": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 1)
			n := int(numToInt(numify(a[0])))
			if e.row == nil || n < 1 || n > len(e.row.cols) {
				return IntV(0)
			}
			_, ok := parseField(e.row.cols[n-1])
			return boolV(ok)
		},
		"timecolumn": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			n := int(numToInt(numify(a[0])))
			if e.row == nil || n < 1 || n > len(e.row.cols) {
				e.undef = true
				return FltV(0)
			}
			t, ok := gpStrptime(a[1].S, e.row.cols[n-1])
			if !ok {
				e.undef = true
			}
			return FltV(t)
		},
		"tm_sec":  tmfn(func(t time.Time) int { return t.Second() }),
		"tm_min":  tmfn(func(t time.Time) int { return t.Minute() }),
		"tm_hour": tmfn(func(t time.Time) int { return t.Hour() }),
		"tm_mday": tmfn(func(t time.Time) int { return t.Day() }),
		"tm_mon":  tmfn(func(t time.Time) int { return int(t.Month()) - 1 }),
		"tm_year": tmfn(func(t time.Time) int { return t.Year() }),
		"tm_wday": tmfn(func(t time.Time) int { return int(t.Weekday()) }),
		"tm_yday": tmfn(func(t time.Time) int { return t.YearDay() - 1 }),
		"voigt": func(in *Interp, e *Env, a []Value) Value {
			nargs(a, 2)
			return FltV(voigt(numify(a[0]).Real(), numify(a[1]).Real()))
		},
		"EllipticK": real1(func(k float64) float64 { return ellipK(k) }),
		"EllipticE": real1(func(k float64) float64 { return ellipE(k) }),
	}
	delete(builtins, "round")
}

func sign(x float64) float64 {
	if x < 0 {
		return -1
	}
	return 1
}

func tmfn(f func(time.Time) int) BuiltinFn {
	return func(in *Interp, e *Env, a []Value) Value {
		nargs(a, 1)
		x := numify(a[0]).Real()
		t := time.Unix(int64(math.Floor(x)), 0).UTC()
		return IntV(int64(f(t)))
	}
}

func splitWords(s string) []string {
	return strings.FieldsFunc(s, func(r rune) bool { return r == ' ' || r == '\t' || r == '\n' })
}

func besselI(n int, x float64) float64 {
	// series expansion
	sum := 0.0
	term := math.Pow(x/2, float64(n)) / math.Gamma(float64(n)+1)
	for k := 0; k < 500; k++ {
		sum += term
		term *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func lambertW(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1)
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		nw := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(nw-w) < 1e-15*(1+math.Abs(nw)) {
			w = nw
			break
		}
		w = nw
	}
	return w
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		return 0
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		sum := 1 / a
		del := sum
		ap := a
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func voigt(x, y float64) float64 {
	// numerical integration of Voigt profile (approx)
	n := 4000
	sum := 0.0
	lim := 40.0
	h := 2 * lim / float64(n)
	for i := 0; i <= n; i++ {
		t := -lim + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		sum += w * math.Exp(-t*t) / (y*y + (x-t)*(x-t))
	}
	return sum * h * y / (math.Pi * math.Sqrt(math.Pi))
}

func ellipK(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	for i := 0; i < 60; i++ {
		a, b = (a+b)/2, math.Sqrt(a*b)
	}
	return math.Pi / (2 * a)
}
func ellipE(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	c := k
	sum := c * c / 2
	p := 1.0
	for i := 0; i < 60; i++ {
		c = (a - b) / 2
		a, b = (a+b)/2, math.Sqrt(a*b)
		p *= 2
		sum += p * c * c / 2
	}
	return math.Pi / (2 * a) * (1 - sum)
}

var _ = os.Getenv
var _ = unicode.IsSpace
var _ = strconv.Itoa
