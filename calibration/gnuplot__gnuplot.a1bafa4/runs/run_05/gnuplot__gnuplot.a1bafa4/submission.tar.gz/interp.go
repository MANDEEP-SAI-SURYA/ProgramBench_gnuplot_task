package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
)

type Source struct {
	lines []string
	idx   int
	name  string // file name, "" for -e
	kind  int    // 0 = -e, 1 = file, 2 = stdin
	lineNo int
}

func (s *Source) next() (string, bool) {
	if s.idx >= len(s.lines) {
		return "", false
	}
	l := s.lines[s.idx]
	s.idx++
	s.lineNo++
	return l, true
}

type loopSignal struct{ kind int } // 1 break, 2 continue
type exitSignal struct{ code int }

type Interp struct {
	vars       map[string]Value
	funcs      map[string]*UserFunc
	datablocks map[string][]string
	dbOrder    []string
	srcStack   []*Source
	interactive bool
	hadError   bool
	printOut   io.Writer
	printFile  *os.File
	printName  string
	stdout     *bufio.Writer
	degrees    bool
	inBody     int
	bodyLine   int
	S          *Settings
	callArgs   [][]string
	lastPlot   string
	lastPlotCmd string
	tableOut   io.Writer
	lastDataFile string
	noInteractive bool
	outFile *os.File
	varSeq     map[string]int
	funcSeq    map[string]int
	seq        int
}

func NewInterp() *Interp {
	in := &Interp{
		vars:       map[string]Value{},
		varSeq:     map[string]int{},
		funcSeq:    map[string]int{},
		funcs:      map[string]*UserFunc{},
		datablocks: map[string][]string{},
	}
	in.stdout = bufio.NewWriter(os.Stdout)
	in.printOut = os.Stderr
	in.sv("pi", FltV(3.141592653589793))
	in.sv("I", CpxV(0, 1))
	in.sv("NaN", FltV(nanVal()))
	in.sv("GPVAL_TERM", StrV("unknown"))
	in.sv("GPVAL_TERMOPTIONS", StrV(""))
	in.sv("GPVAL_OUTPUT", StrV(""))
	in.sv("GPVAL_ENCODING", StrV("utf8"))
	in.sv("GPVAL_MINUS_SIGN", StrV("−"))
	in.sv("GPVAL_MICRO", StrV("µ"))
	in.sv("GPVAL_DEGREE_SIGN", StrV("°"))
	in.sv("GPVAL_VERSION", FltV(5.4))
	in.sv("GPVAL_PATCHLEVEL", StrV("9"))
	in.sv("GPVAL_COMPILE_OPTIONS", StrV("    +READLINE  -LIBREADLINE  +HISTORY  \n    +OBJECTS  +STATS \n    -LIBGD  \n    -USE_CWDRC  +HIDDEN3D_QUADTREE  \n"))
	in.sv("GPVAL_MULTIPLOT", IntV(0))
	in.sv("GPVAL_PLOT", IntV(0))
	in.sv("GPVAL_SPLOT", IntV(0))
	in.sv("GPVAL_TERMINALS", StrV(" canvas cgm context domterm dumb dxf emf epslatex fig hpgl mf mp pcl5 pict2e postscript pslatex pstex pstricks svg texdraw tkcanvas unknown "))
	in.sv("GPVAL_pi", FltV(3.141592653589793))
	in.sv("GPVAL_NaN", FltV(nanVal()))
	in.sv("GPVAL_SYSNAME", StrV("Linux"))
	in.sv("GPVAL_MACHINE", StrV("x86_64"))
	in.sv("GPVAL_BITS", IntV(64))
	in.sv("GPVAL_ERRNO", IntV(0))
	in.sv("GPVAL_ERRMSG", StrV(""))
	in.sv("GPVAL_SYSTEM_ERRNO", IntV(0))
	in.sv("GPVAL_SYSTEM_ERRMSG", StrV(""))
	in.sv("GPVAL_PWD", StrV(cwd()))
	in.sv("VoxelDistance", FltV(0))
	in.S = defaultSettings()
	return in
}

func cwd() string {
	d, _ := os.Getwd()
	return d
}

func (in *Interp) setVar(name string, v Value) {
	if strings.HasPrefix(name, "GPVAL_") || strings.HasPrefix(name, "MOUSE_") {
		gpErrNC("attempt to assign to a read-only variable")
	}
	in.sv(name, v)
}

func (in *Interp) curSrc() *Source {
	if len(in.srcStack) == 0 {
		return nil
	}
	return in.srcStack[len(in.srcStack)-1]
}

func (in *Interp) locPrefix() string {
	pre := ""
	// innermost file source
	for i := len(in.srcStack) - 1; i >= 0; i-- {
		s := in.srcStack[i]
		if s.kind == 1 {
			ln := s.lineNo
			if in.inBody > 0 && i == len(in.srcStack)-1 {
				ln = in.bodyLine
			}
			pre = fmt.Sprintf("\"%s\" line %d: ", s.name, ln)
			break
		}
		if s.kind == 3 {
			continue
		}
		pre = "line 0: "
		break
	}
	if pre == "" {
		pre = "line 0: "
	}
	if in.interactive {
		pre = "         " + pre
	}
	return pre
}

func (in *Interp) reportError(e *GpErr, line string) {
	in.flushOut()
	var b strings.Builder
	if e.Pos >= 0 && in.inBody == 0 {
		if in.interactive {
			b.WriteString("\ngnuplot> " + line + "\n")
			b.WriteString(strings.Repeat(" ", 9+e.Pos) + "^\n")
		} else {
			b.WriteString("\n" + line + "\n")
			b.WriteString(strings.Repeat(" ", e.Pos) + "^\n")
		}
	}
	b.WriteString(in.locPrefix() + e.Msg + "\n\n")
	os.Stderr.WriteString(b.String())
	in.sv("GPVAL_ERRNO", IntV(1))
	in.sv("GPVAL_ERRMSG", StrV(e.Msg))
}

func (in *Interp) flushOut() {
	in.stdout.Flush()
}

func (in *Interp) warn(msg string) {
	in.flushOut()
	os.Stderr.WriteString(in.warnPrefix() + "warning: " + msg + "\n")
}

func (in *Interp) warnPrefix() string {
	for i := len(in.srcStack) - 1; i >= 0; i-- {
		s := in.srcStack[i]
		if s.kind == 1 {
			ln := s.lineNo
			if in.inBody > 0 && i == len(in.srcStack)-1 {
				ln = in.bodyLine
			}
			p := fmt.Sprintf("\"%s\" line %d: ", s.name, ln)
			if in.interactive {
				p = "         " + p
			}
			return p
		}
	}
	return ""
}

// readLogical reads a logical line handling continuation and braces
func (in *Interp) readLogical(src *Source) (string, bool) {
	l, ok := src.next()
	if !ok {
		return "", false
	}
	for strings.HasSuffix(l, "\\") {
		n, ok2 := src.next()
		if !ok2 {
			l = l[:len(l)-1]
			break
		}
		l = l[:len(l)-1] + n
	}
	for braceDepth(l) > 0 {
		n, ok2 := src.next()
		if !ok2 {
			break
		}
		for strings.HasSuffix(n, "\\") {
			m, ok3 := src.next()
			if !ok3 {
				n = n[:len(n)-1]
				break
			}
			n = n[:len(n)-1] + m
		}
		l = l + "\n" + n
	}
	return l, true
}

func braceDepth(l string) int {
	d := 0
	inq := byte(0)
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inq != 0 {
			if c == '\\' && inq == '"' {
				i++
				continue
			}
			if c == inq {
				inq = 0
			}
			continue
		}
		switch c {
		case '"', '\'':
			inq = c
		case '#':
			for i < len(l) && l[i] != '\n' {
				i++
			}
		case '{':
			d++
		case '}':
			d--
		}
	}
	return d
}

// runSource executes all lines from source. Returns false if aborted by error.
func (in *Interp) runSource(src *Source) {
	in.srcStack = append(in.srcStack, src)
	defer func() { in.srcStack = in.srcStack[:len(in.srcStack)-1] }()
	for {
		line, ok := in.readLogical(src)
		if !ok {
			return
		}
		in.execLine(line)
	}
}

func (in *Interp) expandMacros(line string) string {
	if !strings.Contains(line, "@") && !strings.Contains(line, "`") {
		return line
	}
	var b strings.Builder
	inq := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if inq != 0 {
			b.WriteByte(c)
			if c == '\\' && inq == '"' && i+1 < len(line) {
				i++
				b.WriteByte(line[i])
				continue
			}
			if c == inq {
				inq = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			inq = c
			b.WriteByte(c)
			continue
		}
		if c == '#' {
			b.WriteString(line[i:])
			break
		}
		if c == '`' {
			j := strings.IndexByte(line[i+1:], '`')
			if j >= 0 {
				cmd := line[i+1 : i+1+j]
				v := builtins["system"](in, &Env{}, []Value{StrV(cmd)})
				b.WriteString(v.S)
				i = i + 1 + j
				continue
			}
		}
		if c == '@' && i+1 < len(line) && isIdentStart(line[i+1]) {
			j := i + 1
			for j < len(line) && isIdentChar(line[j]) {
				j++
			}
			name := line[i+1 : j]
			v, ok := in.vars[name]
			if !ok || v.K != KStr {
				in.warn(name + " is not a string variable")
			} else {
				b.WriteString(v.S)
			}
			i = j - 1
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

// execLine executes one logical line, catching errors.
func (in *Interp) execLine(line string) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GpErr); ok {
				in.reportError(e, line)
				in.hadError = true
				if !in.interactive || in.noInteractive {
					in.flushOut()
					in.closeAll()
					os.Exit(1)
				}
				return
			}
			panic(r)
		}
	}()
	in.execLineRaw(line)
}

func (in *Interp) execLineRaw(line string) {
	line = in.expandMacros(line)
	toks := tokenize(line)
	p := &P{in: in, toks: toks, line: line}
	in.execTokens(p)
}

func (in *Interp) execTokens(p *P) {
	for {
		for p.is(";") {
			p.i++
		}
		if p.tok().K == TEnd {
			return
		}
		in.command(p)
		if !p.atEnd() {
			gpErr(p.tok().Pos, "unexpected or unrecognized token: "+p.tok().Text)
		}
	}
}

// execBody runs text of a brace block
func (in *Interp) execBody(body string, startLine int) {
	src := &Source{lines: strings.Split(body, "\n"), kind: 3}
	saveBL := in.bodyLine
	in.inBody++
	in.srcStack = append(in.srcStack, src)
	defer func() {
		in.srcStack = in.srcStack[:len(in.srcStack)-1]
		in.inBody--
		in.bodyLine = saveBL
	}()
	for {
		in.bodyLine = startLine + src.lineNo
		line, ok := in.readLogical(src)
		if !ok {
			return
		}
		in.bodyLine = startLine + src.lineNo - strings.Count(line, "\n") - 0
		in.bodyLine = startLine + (src.lineNo - 1 - strings.Count(line, "\n"))
		in.execLineRaw(line)
	}
}

func (in *Interp) curLineNo() int {
	if in.inBody > 0 {
		return in.bodyLine
	}
	s := in.curSrc()
	if s == nil {
		return 0
	}
	return s.lineNo
}

func (in *Interp) closeAll() {
	if in.printFile != nil {
		in.printFile.Close()
	}
	in.closeOutput()
}

// evaluate expression in constant context
func (in *Interp) constExpr(p *P) Value {
	start := p.tok().Pos
	if p.atEnd() {
		gpErr(p.tok().Pos, "constant expression required")
	}
	f := p.parseExpr()
	e := &Env{}
	v := f(e)
	if e.undef {
		gpErr(start, "undefined value")
	}
	return v
}

func (in *Interp) evalNum(p *P) float64 {
	v := in.constExpr(p)
	return numify(v).Real()
}

func (in *Interp) evalInt(p *P) int64 {
	v := numify(in.constExpr(p))
	if v.K == KInt {
		return v.I
	}
	return int64(v.Re)
}

func (in *Interp) evalStr(p *P) string {
	pos := p.tok().Pos
	v := in.constExpr(p)
	if v.K != KStr {
		gpErr(pos, "expecting string")
	}
	return v.S
}

// isStringExpr: string literal or something that evaluates to string
func (p *P) isStringStart() bool {
	t := p.tok()
	if t.K == TStr {
		return true
	}
	if t.K == TIdent && !strings.HasPrefix(t.Text, "$") {
		v, ok := p.in.vars[t.Text]
		if ok && v.K == KStr {
			return true
		}
		if p.peek(1).K == TOp && p.peek(1).Text == "(" {
			switch t.Text {
			case "sprintf", "gprintf", "strftime", "substr", "word", "trim", "system", "columnhead", "strcol", "stringcolumn":
				return true
			}
		}
	}
	return false
}

func (in *Interp) printCmd(p *P, w io.Writer) {
	var parts []string
	if p.atEnd() {
		gpErr(p.tok().Pos, "constant expression required")
	}
	var b strings.Builder
	first := true; _ = first
	defer func() {
		if r := recover(); r != nil {
			// flush partial output
			io.WriteString(w, b.String())
			panic(r)
		}
	}()
	for {
		// datablock print
		t := p.tok()
		if t.K == TIdent && strings.HasPrefix(t.Text, "$") && len(t.Text) > 1 && !(t.Text[1] >= '0' && t.Text[1] <= '9') && (p.peek(1).K == TEnd || p.peek(1).Text == ";" || p.peek(1).Text == ",") {
			db, ok := in.datablocks[t.Text]
			if !ok {
				gpErrNC("undefined variable: " + t.Text)
			}
			p.i++
			for _, l := range db {
				b.WriteString(l + "\n")
			}
			first = false
		} else {
			v := in.constExpr(p)
			first = false
			b.WriteString(v.PrintString())
		}
		if p.is(",") {
			p.i++
			b.WriteString(" ")
			continue
		}
		break
	}
	_ = parts
	b.WriteString("\n")
	io.WriteString(w, b.String())
	in.flushPrint()
}

func (in *Interp) flushPrint() {
	if in.printOut == io.Writer(in.stdout) {
		in.stdout.Flush()
	}
}

func (in *Interp) findBlock(p *P) (string, int) {
	// p at '{'; returns body text and advances past matching '}'
	open := p.tok()
	depth := 0
	j := p.i
	for ; j < len(p.toks); j++ {
		t := p.toks[j]
		if t.K == TOp && t.Text == "{" {
			depth++
		} else if t.K == TOp && t.Text == "}" {
			depth--
			if depth == 0 {
				break
			}
		} else if t.K == TEnd {
			gpErr(open.Pos, "Unmatched {")
		}
	}
	body := p.line[open.End:p.toks[j].Pos]
	startLine := in.curLineNo() + strings.Count(p.line[:open.End], "\n")
	p.i = j + 1
	return body, startLine
}

func (in *Interp) ifCmd(p *P) {
	p.i++
	if !p.is("(") {
		gpErr(p.tok().Pos, "expecting (expression)")
	}
	cond := in.constExpr(p)
	_ = cond
	c := truthy(numify(cond))
	if !p.is("{") {
		// old style
		if c {
			in.execTokens(p)
			return
		}
		// skip rest of line, unless 'else'
		for !(p.tok().K == TEnd) {
			if p.isAbbr("else") {
				p.i++
				return
			}
			p.i++
		}
		return
	}
	body, sl := in.findBlock(p)
	done := false
	if c {
		in.execBody(body, sl)
		done = true
	}
	for p.isAbbr("else") {
		p.i++
		if p.isAbbr("if") && false {
			p.i++
			if !p.is("(") {
				gpErr(p.tok().Pos, "expecting (expression)")
			}
			var c2 bool
			if !done {
				c2 = truthy(numify(in.constExpr(p)))
			} else {
				// skip expression
				p.parseExpr()
			}
			if !p.is("{") {
				gpErr(p.tok().Pos, "expected {")
			}
			b2, sl2 := in.findBlock(p)
			if !done && c2 {
				in.execBody(b2, sl2)
				done = true
			}
			continue
		}
		if !p.is("{") {
			gpErr(p.tok().Pos, "expected {else-clause}")
		}
		b2, sl2 := in.findBlock(p)
		if !done {
			in.execBody(b2, sl2)
			done = true
		}
		break
	}
}

func (in *Interp) runLoopBody(body string, sl int) (brk bool) {
	defer func() {
		if r := recover(); r != nil {
			if ls, ok := r.(*loopSignal); ok {
				brk = ls.kind == 1
				return
			}
			panic(r)
		}
	}()
	in.execBody(body, sl)
	return false
}

type iterSpec struct {
	name   string
	isStr  bool
	words  []string
	lo, hi int64
	step   int64
	open   bool
}

func (in *Interp) parseIter(p *P) *iterSpec {
	// p at '['
	p.expect("[")
	t := p.tok()
	if t.K != TIdent {
		gpErr(t.Pos, "Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	it := &iterSpec{name: t.Text, step: 1}
	p.i++
	if p.isAbbr("in") {
		p.i++
		s := in.evalStr(p)
		it.isStr = true
		it.words = splitWords(s)
		p.expect("]")
		return it
	}
	if !p.is("=") {
		gpErr(p.tok().Pos, "Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	p.i++
	it.lo = in.evalInt(p)
	p.expect(":")
	if p.is("*") {
		p.i++
		it.open = true
	} else {
		it.hi = in.evalInt(p)
	}
	if p.is(":") {
		p.i++
		it.step = in.evalInt(p)
		if it.step == 0 {
			gpErrNC("Iteration step cannot be 0")
		}
	}
	p.expect("]")
	return it
}

func (it *iterSpec) values() []Value {
	var out []Value
	if it.isStr {
		for _, w := range it.words {
			out = append(out, StrV(w))
		}
		return out
	}
	if it.step > 0 {
		for k := it.lo; k <= it.hi; k += it.step {
			out = append(out, IntV(k))
		}
	} else {
		for k := it.lo; k >= it.hi; k += it.step {
			out = append(out, IntV(k))
		}
	}
	return out
}

func (in *Interp) doCmd(p *P) {
	p.i++
	if !p.isAbbr("for") {
		gpErr(p.tok().Pos, "expecting \"for\"")
	}
	p.i++
	var iters []*iterSpec
	for p.is("[") {
		iters = append(iters, in.parseIter(p))
		if p.isAbbr("for") {
			p.i++
		}
	}
	if !p.is("{") {
		gpErr(p.tok().Pos, "expecting {<command list>}")
	}
	body, sl := in.findBlock(p)
	var rec func(k int) bool
	rec = func(k int) bool {
		if k >= len(iters) {
			return in.runLoopBody(body, sl)
		}
		it := iters[k]
		if it.open {
			for v := it.lo; ; v += it.step {
				in.sv(it.name, IntV(v))
				if rec(k + 1) {
					return true
				}
			}
		}
		for _, v := range it.values() {
			in.sv(it.name, v)
			if rec(k + 1) {
				return true
			}
		}
		return false
	}
	rec(0)
}

func (in *Interp) whileCmd(p *P) {
	p.i++
	if !p.is("(") {
		gpErr(p.tok().Pos, "expecting (expression)")
	}
	ci := p.i
	in.constExpr(p)
	if !p.is("{") {
		gpErr(p.tok().Pos, "expecting {<command list>}")
	}
	bi := p.i
	body, sl := in.findBlock(p)
	end := p.i
	for {
		p.i = ci
		c := truthy(numify(in.constExpr(p)))
		if !c {
			break
		}
		p.i = bi
		if in.runLoopBody(body, sl) {
			break
		}
	}
	p.i = end
}

func readFileLines(name string) ([]string, bool) {
	data, err := os.ReadFile(name)
	if err != nil {
		return nil, false
	}
	s := string(data)
	s = strings.TrimSuffix(s, "\n")
	if s == "" && len(data) == 0 {
		return []string{}, true
	}
	lines := strings.Split(s, "\n")
	for i, l := range lines {
		lines[i] = strings.TrimSuffix(l, "\r")
	}
	return lines, true
}

func (in *Interp) loadFile(name string, args []string, isCall bool) {
	lines, ok := readFileLines(name)
	if !ok {
		gpErrNC("Cannot load input from '" + name + "'")
	}
	src := &Source{lines: lines, name: name, kind: 1}
	var saved map[string]Value
	if isCall {
		saved = map[string]Value{}
		for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
			if v, ok := in.vars[k]; ok {
				saved[k] = v
			}
		}
		in.setCallArgs(name, args)
	}
	saveBody := in.inBody
	in.inBody = 0
	defer func() {
		in.inBody = saveBody
		if isCall {
			for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
				in.delVar(k)
			}
			for k, v := range saved {
				in.sv(k, v)
			}
		}
	}()
	in.srcStack = append(in.srcStack, src)
	defer func() { in.srcStack = in.srcStack[:len(in.srcStack)-1] }()
	for {
		line, ok := in.readLogical(src)
		if !ok {
			return
		}
		in.execLineRaw(line)
	}
}

func (in *Interp) setCallArgs(name string, args []string) {
	in.sv("ARGC", IntV(int64(len(args))))
	in.sv("ARG0", StrV(name))
	arr := []Value{{}}
	for _, a := range args {
		arr = append(arr, StrV(a))
	}
	in.sv("ARGV", Value{K: KArr, Arr: &arr})
	for i := 1; i <= 9; i++ {
		if i <= len(args) {
			in.sv("ARG"+strconv.Itoa(i), StrV(args[i-1]))
		} else {
			in.sv("ARG"+strconv.Itoa(i), StrV(""))
		}
	}
}

func (in *Interp) readDatablock(name string, term string) {
	src := in.curSrc()
	var lines []string
	if src != nil {
		for {
			l, ok := src.next()
			if !ok {
				break
			}
			if in.inBody > 0 {
				in.bodyLine++
			}
			if strings.TrimRight(l, " \t\r") == term || strings.HasPrefix(l, term) && strings.TrimSpace(l[len(term):]) == "" {
				break
			}
			lines = append(lines, l)
		}
	}
	if _, ok := in.datablocks[name]; !ok {
		in.dbOrder = append(in.dbOrder, name)
	}
	in.datablocks[name] = lines
}

func (in *Interp) command(p *P) {
	t := p.tok()
	if t.K == TOp && t.Text == "!" {
		// shell command
		cmd := p.line[t.End:]
		semi := len(p.line)
		_ = semi
		in.flushOut()
		builtins["system"](in, &Env{}, []Value{StrV(cmd)})
		p.i = len(p.toks) - 1
		return
	}
	if t.K != TIdent {
		gpErr(t.Pos, "invalid command")
	}
	name := t.Text
	// datablock definition
	if strings.HasPrefix(name, "$") && p.peek(1).K == TOp && p.peek(1).Text == "<<" {
		p.i += 2
		term := p.tok()
		if term.K != TIdent {
			gpErr(term.Pos, "Expecting the name of the end-of-data marker")
		}
		p.i++
		in.readDatablock(name, term.Text)
		return
	}
	// assignment
	if p.peek(1).K == TOp && p.peek(1).Text == "=" {
		if strings.HasPrefix(name, "$") {
			p.i += 2
			v := in.constExpr(p)
			_ = v
			return
		}
		p.i += 2
		v := in.constExpr(p)
		if v.K == KArr {
			// copy array
			na := append([]Value{}, (*v.Arr)...)
			v = Value{K: KArr, Arr: &na}
		}
		in.setVar(name, v)
		return
	}
	if p.peek(1).K == TOp && p.peek(1).Text == "[" {
		// maybe array element assignment
		if av, ok := in.vars[name]; ok && av.K == KArr {
			save := p.i
			p.i += 2
			idx := in.evalInt(p)
			if p.is("]") && p.peek(1).Text == "=" {
				p.i += 2
				v := in.constExpr(p)
				arr := *av.Arr
				if idx < 1 || idx >= int64(len(arr)) {
					gpErrNC("array index out of range")
				}
				arr[idx] = v
				return
			}
			p.i = save
		}
	}
	if p.peek(1).K == TOp && p.peek(1).Text == "(" && !isCommandWord(name) {
		// function definition?
		j := p.i + 2
		var params []string
		okdef := true
		for {
			tt := p.toks[j]
			if tt.K != TIdent {
				okdef = false
				break
			}
			params = append(params, tt.Text)
			j++
			if p.toks[j].K == TOp && p.toks[j].Text == "," {
				j++
				continue
			}
			if p.toks[j].K == TOp && p.toks[j].Text == ")" {
				j++
				break
			}
			okdef = false
			break
		}
		if okdef && p.toks[j].K == TOp && p.toks[j].Text == "=" {
			p.i = j + 1
			start := p.tok().Pos
			if p.atEnd() {
				gpErr(p.tok().Pos, "function definition expected")
			}
			body := p.parseExpr()
			text := strings.TrimSpace(p.line[t.Pos:p.tok().Pos])
			_ = start
			if _, ok := in.funcs[name]; !ok {
				in.seq++
				in.funcSeq[name] = in.seq
			}
			in.funcs[name] = &UserFunc{Name: name, Params: params, Body: body, Text: text}
			return
		}
	}
	switch {
	case abbrev(name, "pr$int"):
		p.i++
		in.printCmd(p, in.printOut)
	case name == "printerr":
		p.i++
		in.flushOut()
		in.printCmd(p, os.Stderr)
	case name == "if":
		in.ifCmd(p)
	case name == "else":
		gpErr(t.Pos, "else without if")
	case name == "do":
		in.doCmd(p)
	case name == "while":
		in.whileCmd(p)
	case name == "break":
		p.i++
		if in.inBody == 0 {
			gpErr(t.Pos, "break or continue outside of a loop")
		}
		panic(&loopSignal{1})
	case name == "continue":
		p.i++
		panic(&loopSignal{2})
	case abbrev(name, "ex$it") || abbrev(name, "q$uit"):
		p.i++
		code := 0
		if p.isAbbr("status") || p.isAbbr("error") {
			iserr := p.isAbbr("error")
			p.i++
			if iserr {
				msg := in.evalStr(p)
				in.flushOut()
				gpErrNC(msg)
			}
			code = int(in.evalInt(p))
		}
		panic(&exitSignal{code})
	case abbrev(name, "l$oad"):
		p.i++
		f := in.evalStr(p)
		in.loadFile(f, nil, false)
	case abbrev(name, "cal$l"):
		p.i++
		f := in.evalStr(p)
		var args []string
		for !p.atEnd() {
			tt := p.tok()
			if tt.K == TStr {
				args = append(args, tt.Str)
				p.i++
			} else if tt.K == TOp && tt.Text == "(" {
				v := in.constExpr(p)
				if v.K == KStr {
					args = append(args, v.S)
				} else {
					args = append(args, v.PrintString())
				}
			} else if tt.K == TIdent {
				if v, ok := in.vars[tt.Text]; ok && p.peek(1).Text != "(" {
					if v.K == KStr {
						args = append(args, v.S)
					} else if v.K == KInt {
						args = append(args, strconv.FormatInt(v.I, 10))
					} else {
						args = append(args, cfmt("%g", v.Re))
					}
					p.i++
				} else {
					args = append(args, tt.Text)
					p.i++
				}
			} else {
				// raw token text up to whitespace
				st := tt.Pos
				for !p.atEnd() && (p.i == 0 || p.tok().Pos == p.toks[p.i-1].End || p.tok().Pos == st) {
					p.i++
				}
				args = append(args, p.line[st:p.toks[p.i-1].End])
			}
		}
		in.loadFile(f, args, true)
	case abbrev(name, "ev$aluate"):
		p.i++
		s := in.evalStr(p)
		in.evalString(s)
	case abbrev(name, "und$efine"):
		p.i++
		for !p.atEnd() {
			tt := p.tok()
			n := tt.Text
			p.i++
			if strings.HasSuffix(n, "*") {
				continue
			}
			if p.is("*") && p.tok().Pos == tt.End {
				p.i++
				for k := range in.vars {
					if strings.HasPrefix(k, n) {
						in.delVar(k)
					}
				}
				continue
			}
			if strings.HasPrefix(n, "GPVAL_") {
				continue
			}
			if strings.HasPrefix(n, "$") {
				delete(in.datablocks, n)
				continue
			}
			in.delVar(n)
		}
	case name == "array":
		in.arrayCmd(p)
	case abbrev(name, "se$t"):
		p.i++
		in.setCmd(p, false)
	case abbrev(name, "uns$et"):
		p.i++
		in.setCmd(p, true)
	case abbrev(name, "sh$ow"):
		p.i++
		in.showCmd(p)
	case abbrev(name, "res$et"):
		p.i++
		if p.isAbbr("err$ors") {
			p.i++
			in.sv("GPVAL_ERRNO", IntV(0))
			in.sv("GPVAL_ERRMSG", StrV(""))
			return
		}
		if p.isAbbr("bind") || p.isAbbr("session") {
			p.i++
		}
		in.resetSettings()
	case abbrev(name, "p$lot"):
		p.i++
		in.plotCmd(p, false)
	case abbrev(name, "sp$lot"):
		p.i++
		in.plotCmd(p, true)
	case abbrev(name, "rep$lot"):
		p.i++
		in.replotCmd(p)
	case abbrev(name, "st$ats"):
		p.i++
		in.statsCmd(p)
	case name == "fit":
		p.i++
		in.fitCmd(p)
	case abbrev(name, "cl$ear"):
		p.i++
		in.clearCmd()
	case abbrev(name, "pa$use"):
		p.i++
		v := in.constExpr(p)
		if p.tok().K == TStr || (!p.atEnd()) {
			if !p.atEnd() {
				s := in.constExpr(p)
				in.flushOut()
				if s.K == KStr {
					os.Stderr.WriteString(s.S + "\n")
				}
			}
		}
		_ = v
	case name == "cd":
		p.i++
		d := in.evalStr(p)
		if err := os.Chdir(d); err != nil {
			gpErrNC("Can't change to this directory")
		}
		in.sv("GPVAL_PWD", StrV(cwd()))
	case name == "pwd":
		p.i++
		in.flushOut()
		fmt.Fprintln(os.Stderr, cwd())
	case abbrev(name, "sy$stem"):
		p.i++
		s := in.evalStr(p)
		in.flushOut()
		v := builtins["system"](in, &Env{}, []Value{StrV(s)})
		_ = v
		// system command output goes to stdout directly
		os.Stdout.WriteString(v.S)
		if v.S != "" {
			os.Stdout.WriteString("\n")
		}
	case abbrev(name, "up$date"):
		p.i++
		in.evalStr(p)
		if !p.atEnd() {
			in.evalStr(p)
		}
	case abbrev(name, "te$st"), abbrev(name, "ref$resh"), abbrev(name, "ra$ise"), abbrev(name, "low$er"), abbrev(name, "his$tory"), abbrev(name, "h$elp"), name == "?":
		p.i = len(p.toks) - 1
	default:
		gpErr(t.Pos, "invalid command")
	}
}

func isCommandWord(n string) bool {
	switch n {
	case "if", "while", "print", "pr", "pri", "prin", "printerr", "call", "load", "eval", "evaluate":
		return true
	}
	return false
}

func (in *Interp) evalString(s string) {
	saveBody := in.inBody
	lines := strings.Split(s, "\n")
	for _, l := range lines {
		in.execLineRaw(l)
	}
	in.inBody = saveBody
}

func (in *Interp) arrayCmd(p *P) {
	p.i++
	t := p.tok()
	if t.K != TIdent {
		gpErr(t.Pos, "illegal variable name")
	}
	name := t.Text
	p.i++
	if p.is("=") {
		p.i++
		v := in.arrayLiteral(p)
		in.sv(name, v)
		return
	}
	if !p.is("[") {
		gpErr(p.tok().Pos, "expecting array[size>0]")
	}
	p.i++
	n := in.evalInt(p)
	p.expect("]")
	if n <= 0 {
		gpErrNC("expecting array[size>0]")
	}
	arr := make([]Value, n+1)
	if p.is("=") {
		p.i++
		v := in.arrayLiteral(p)
		src := *v.Arr
		for k := 1; k < len(src) && k <= int(n); k++ {
			arr[k] = src[k]
		}
	}
	in.sv(name, Value{K: KArr, Arr: &arr})
}

func (in *Interp) arrayLiteral(p *P) Value {
	if !p.is("[") {
		v := in.constExpr(p)
		if v.K != KArr {
			gpErrNC("expecting array")
		}
		na := append([]Value{}, (*v.Arr)...)
		return Value{K: KArr, Arr: &na}
	}
	p.i++
	arr := []Value{{}}
	if !p.is("]") {
		for {
			if p.is(",") {
				arr = append(arr, Value{})
				p.i++
				continue
			}
			arr = append(arr, in.constExpr(p))
			if p.is(",") {
				p.i++
				continue
			}
			break
		}
	}
	p.expect("]")
	return Value{K: KArr, Arr: &arr}
}
