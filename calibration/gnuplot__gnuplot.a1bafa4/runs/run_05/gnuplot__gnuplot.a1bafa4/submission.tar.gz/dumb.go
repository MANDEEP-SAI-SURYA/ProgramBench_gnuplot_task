package main

import (
	"math"
	"strings"
)

func ticStep(r float64) float64 {
	if r <= 0 {
		return 1
	}
	power := math.Pow(10, math.Floor(math.Log10(r)))
	xnorm := r / power
	posns := 20 / xnorm
	var t float64
	switch {
	case posns > 40:
		t = 0.05
	case posns > 20:
		t = 0.1
	case posns > 10:
		t = 0.2
	case posns > 4:
		t = 0.5
	case posns > 2:
		t = 1
	case posns > 0.5:
		t = 2
	default:
		t = math.Ceil(xnorm)
	}
	return t * power
}

type axisInfo struct {
	min, max float64
	step     float64
}

func (in *Interp) computeAxis(ax string, dmin, dmax float64) axisInfo {
	r := in.S.Ranges[ax]
	lo, hi := dmin, dmax
	if !r.AutoMin {
		lo = r.Min
	}
	if !r.AutoMax {
		hi = r.Max
	}
	if math.IsInf(lo, 0) || math.IsInf(hi, 0) {
		lo, hi = -10, 10
	}
	if lo == hi {
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			lo, hi = lo-math.Abs(lo)*0.01, hi+math.Abs(hi)*0.01
		}
	}
	rev := false
	if lo > hi {
		lo, hi = hi, lo
		rev = true
	}
	step := ticStep(hi - lo)
	ts := in.S.Tics[ax]
	if ts != nil && !ts.Auto && ts.Step > 0 {
		step = ts.Step
	}
	if r.AutoMin {
		lo = math.Floor(lo/step+1e-9) * step
	}
	if r.AutoMax {
		hi = math.Ceil(hi/step-1e-9) * step
	}
	if rev {
		lo, hi = hi, lo
	}
	r.CurMin, r.CurMax = lo, hi
	return axisInfo{min: lo, max: hi, step: step}
}

type canvas struct {
	w, h int
	g    [][]byte
}

func newCanvas(w, h int) *canvas {
	c := &canvas{w: w, h: h}
	c.g = make([][]byte, h)
	for i := range c.g {
		c.g[i] = []byte(strings.Repeat(" ", w))
	}
	return c
}

// set at terminal coords (x right, y up)
func (c *canvas) set(x, y int, ch byte) {
	row := c.h - 1 - y
	if x < 0 || x >= c.w || row < 0 || row >= c.h {
		return
	}
	c.g[row][x] = ch
}

func (c *canvas) text(x, y int, s string) {
	for i := 0; i < len(s); i++ {
		c.set(x+i, y, s[i])
	}
}

func isign(a int) int {
	if a < 0 {
		return -1
	}
	if a > 0 {
		return 1
	}
	return 0
}

func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}

func (c *canvas) line(x1, y1, x2, y2 int, pen, pen1 byte, vpen byte) {
	dx, dy := x2-x1, y2-y1
	if iabs(dy) > iabs(dx) {
		p := vpen
		c.set(x1, y1, pen1)
		for d := 1; d < iabs(dy); d++ {
			c.set(x1+int(float64(dx)*float64(d)/float64(iabs(dy))+0.5), y1+d*isign(dy), p)
		}
		c.set(x2, y2, pen1)
	} else if iabs(dx) > 0 {
		c.set(x1, y1, pen1)
		for d := 1; d < iabs(dx); d++ {
			c.set(x1+d*isign(dx), y1+int(float64(dy)*float64(d)/float64(iabs(dx))+0.5), pen)
		}
		c.set(x2, y2, pen1)
	} else {
		c.set(x1, y1, pen1)
	}
}

var lineChars = []byte("*#$%@&=")

func ticLabel(f string, v float64, in *Interp) string {
	if math.Abs(v) < 1e-12*1 {
		v = 0
	}
	if strings.Contains(f, "%h") || strings.Contains(f, "% h") {
		f = strings.Replace(f, "h", "g", 1)
	}
	return gprintf(f, v, in)
}

func (in *Interp) renderPlot(elems []*PlotElem, is3d bool) {
	S := in.S
	if S.Term == "unknown" {
		return
	}
	if S.Term != "dumb" {
		in.renderOther(elems)
		return
	}
	W, H := S.TermW, S.TermH
	cv := newCanvas(W, H)
	// data extents
	xmin, xmax := math.Inf(1), math.Inf(-1)
	ymin, ymax := math.Inf(1), math.Inf(-1)
	for _, el := range elems {
		for _, p := range el.Pts {
			if p.Brk || p.Typ == 'u' {
				continue
			}
			if !el.IsFunc || S.Parametric {
				xmin = math.Min(xmin, p.X)
				xmax = math.Max(xmax, p.X)
			}
			if p.Typ == 'o' && !in.inRange("y", p.Y) {
				continue
			}
			ymin = math.Min(ymin, p.Y)
			ymax = math.Max(ymax, p.Y)
		}
	}
	xr := S.Ranges["x"]
	if math.IsInf(xmin, 0) {
		// functions only: use sampling range
		for _, el := range elems {
			if len(el.Pts) > 0 {
				xmin = math.Min(xmin, el.Pts[0].X)
				xmax = math.Max(xmax, el.Pts[len(el.Pts)-1].X)
			}
		}
	}
	xa := in.computeAxis("x", xmin, xmax)
	if xr.AutoMin && xr.AutoMax && allFuncs(elems) {
		xa.min, xa.max = xmin, xmax
	}
	ya := in.computeAxis("y", ymin, ymax)
	// layout
	top := H - 2 // terminal y of top border
	if S.Title.Text != "" {
		top = H - 4
	}
	bot := 2
	if S.Labels["x"].Text != "" {
		bot = 3
	}
	// y tic labels
	var yt []float64
	for v := math.Ceil(math.Min(ya.min, ya.max)/ya.step-1e-9) * ya.step; v <= math.Max(ya.min, ya.max)+ya.step*1e-9; v += ya.step {
		yt = append(yt, v)
	}
	maxw := 0
	ylabs := map[int]string{}
	for i, v := range yt {
		s := ticLabel(S.Format["y"], v, in)
		ylabs[i] = s
		if len(s) > maxw {
			maxw = len(s)
		}
	}
	left := maxw + 2
	if S.Labels["y"].Text != "" {
		left += len(S.Labels["y"].Text) + 1
	}
	right := W - 4
	mapx := func(x float64) float64 {
		return float64(left) + (x-xa.min)*float64(right-left)/(xa.max-xa.min)
	}
	mapy := func(y float64) float64 {
		return float64(bot) + (y-ya.min)*float64(top-bot)/(ya.max-ya.min)
	}
	rnd := func(f float64) int { return int(math.Floor(f + 0.5)) }
	// tics
	if S.Tics["y"].On {
		for i, v := range yt {
			y := rnd(mapy(v))
			if y != bot && y != top {
				cv.line(left, y, left+2, y, '-', '+', '|')
				if S.Tics["y"].Mirror {
					cv.line(right, y, right-2, y, '-', '+', '|')
				}
			}
			s := ylabs[i]
			cv.text(left-1-len(s), y, s)
		}
	}
	if S.Tics["x"].On {
		lo, hi := math.Min(xa.min, xa.max), math.Max(xa.min, xa.max)
		for v := math.Ceil(lo/xa.step-1e-9) * xa.step; v <= hi+xa.step*1e-9; v += xa.step {
			x := rnd(mapx(v))
			if x != left && x != right {
				cv.line(x, bot, x, bot+1, '-', '+', '|')
				if S.Tics["x"].Mirror {
					cv.line(x, top, x, top-1, '-', '+', '|')
				}
			}
			s := ticLabel(S.Format["x"], v, in)
			cv.text(x-len(s)/2, bot-1, s)
		}
	}
	// title, labels
	cx := (left + right) / 2
	if S.Title.Text != "" {
		cv.text(cx-len(S.Title.Text)/2, H-3, S.Title.Text)
	}
	if t := S.Labels["x"].Text; t != "" {
		cv.text(cx-len(t)/2, 1, t)
	}
	if t := S.Labels["y"].Text; t != "" {
		cv.text(1, (top+bot)/2, t)
	}
	// plots
	keyRow := top - 2
	keyRight := right - 6
	if S.KeyHoriz == "left" {
		keyRight = 0
	}
	for k, el := range elems {
		lt := k
		if el.LT >= 0 {
			lt = el.LT
		}
		pen := lineChars[lt%len(lineChars)]
		pt := byte('A' + (lt % 26))
		if el.PtType > 0 {
			pt = byte('A' + ((el.PtType - 1) % 26))
		}
		if el.PointChar != 0 {
			pt = el.PointChar
		}
		style := el.Style
		// key entry
		title := in.elemTitle(el)
		if S.KeyOn && !el.NoTitle && title != "" {
			var tx, sx int
			if S.KeyHoriz == "left" {
				ml := 0
				for _, e2 := range elems {
					if t2 := in.elemTitle(e2); !e2.NoTitle && len(t2) > ml {
						ml = len(t2)
					}
				}
				sx = left + 1 + ml + 1
				tx = sx - 1 - len(title)
				_ = keyRight
			} else {
				sx = right - 8
				tx = sx - 1 - len(title)
			}
			cv.text(tx, keyRow, title)
			if style == "lines" || style == "linespoints" || style == "impulses" || style == "steps" || style == "fsteps" || style == "histeps" || strings.Contains(style, "errorlines") {
				cv.line(sx, keyRow, sx+6, keyRow, pen, pen, pen)
			}
			if style == "points" || style == "linespoints" {
				cv.set(sx+3, keyRow, pt)
			}
			keyRow--
		}
		// curve
		var prev *Pt
		inside := func(p Pt) bool {
			return p.X >= math.Min(xa.min, xa.max) && p.X <= math.Max(xa.min, xa.max) && p.Y >= math.Min(ya.min, ya.max) && p.Y <= math.Max(ya.min, ya.max)
		}
		for i := range el.Pts {
			p := el.Pts[i]
			if p.Brk || p.Typ == 'u' {
				prev = nil
				continue
			}
			switch style {
			case "lines", "linespoints", "steps", "fsteps", "histeps", "errorlines", "yerrorlines", "xerrorlines":
				if prev != nil {
					x1, y1, x2, y2, ok := clipSeg(prev.X, prev.Y, p.X, p.Y, xa, ya)
					if ok {
						cv.line(rnd(mapx(x1)), rnd(mapy(y1)), rnd(mapx(x2)), rnd(mapy(y2)), pen, pen, pen)
					}
				}
			case "impulses":
				if inside(p) {
					y0 := math.Max(math.Min(0, math.Max(ya.min, ya.max)), math.Min(ya.min, ya.max))
					cv.line(rnd(mapx(p.X)), rnd(mapy(y0)), rnd(mapx(p.X)), rnd(mapy(p.Y)), pen, pen, pen)
				}
			}
			prev = &el.Pts[i]
		}
		if style == "points" || style == "linespoints" || strings.Contains(style, "errorbars") {
			for _, p := range el.Pts {
				if p.Brk || p.Typ == 'u' || !inside(p) {
					continue
				}
				cv.set(rnd(mapx(p.X)), rnd(mapy(p.Y)), pt)
			}
		}
	}
	// border
	if S.Border != 0 {
		cv.line(left, bot, right, bot, '-', '+', '|')
		cv.line(right, bot, right, top, '-', '+', '|')
		cv.line(right, top, left, top, '-', '+', '|')
		cv.line(left, top, left, bot, '-', '+', '|')
	}
	// output
	var b strings.Builder
	if S.DumbFeed {
		b.WriteString("\f")
	}
	for i, row := range cv.g {
		b.Write(row)
		if i < len(cv.g)-1 || true {
			b.WriteString("\n")
		}
	}
	in.writeOutput(b.String())
}

func allFuncs(elems []*PlotElem) bool {
	for _, e := range elems {
		if !e.IsFunc {
			return false
		}
	}
	return true
}

func clipSeg(x1, y1, x2, y2 float64, xa, ya axisInfo) (float64, float64, float64, float64, bool) {
	xmin, xmax := math.Min(xa.min, xa.max), math.Max(xa.min, xa.max)
	ymin, ymax := math.Min(ya.min, ya.max), math.Max(ya.min, ya.max)
	t0, t1 := 0.0, 1.0
	dx, dy := x2-x1, y2-y1
	clip := func(p, q float64) bool {
		if p == 0 {
			return q >= 0
		}
		r := q / p
		if p < 0 {
			if r > t1 {
				return false
			}
			if r > t0 {
				t0 = r
			}
		} else {
			if r < t0 {
				return false
			}
			if r < t1 {
				t1 = r
			}
		}
		return true
	}
	if !clip(-dx, x1-xmin) || !clip(dx, xmax-x1) || !clip(-dy, y1-ymin) || !clip(dy, ymax-y1) {
		return 0, 0, 0, 0, false
	}
	return x1 + t0*dx, y1 + t0*dy, x1 + t1*dx, y1 + t1*dy, true
}

func (in *Interp) writeOutput(s string) {
	if in.S.Output == "" {
		in.stdout.WriteString(s)
		in.stdout.Flush()
		return
	}
	if in.outFile == nil {
		f, err := createFile(in.S.Output)
		if err != nil {
			gpErrNC("cannot open file; output not changed")
		}
		in.outFile = f
	}
	in.outFile.WriteString(s)
}

func (in *Interp) renderOther(elems []*PlotElem) {}
