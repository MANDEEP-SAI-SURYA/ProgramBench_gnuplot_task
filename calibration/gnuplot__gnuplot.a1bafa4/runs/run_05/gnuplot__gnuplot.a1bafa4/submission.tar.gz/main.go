package main

import (
	"fmt"
	"io"
	"math"
	"os"
	"strings"
)

func nanVal() float64 { return math.NaN() }

func main() {
	in := NewInterp()
	code := run(in, os.Args[1:])
	in.flushOut()
	in.closeAll()
	os.Exit(code)
}

func usage() string {
	return "Usage: gnuplot [OPTION] ... [FILE]\n" +
		"  -V, --version\n" +
		"  -h, --help\n" +
		"  -p  --persist\n" +
		"  -s  --slow\n" +
		"  -d  --default-settings\n" +
		"  -c  scriptfile ARG1 ARG2 ... \n" +
		"  -e  \"command1; command2; ...\"\n" +
		"gnuplot 5.4 patchlevel 9\n"
}

func run(in *Interp, args []string) (code int) {
	defer func() {
		if r := recover(); r != nil {
			if es, ok := r.(*exitSignal); ok {
				code = es.code
				return
			}
			if _, ok := r.(*loopSignal); ok {
				code = 0
				return
			}
			panic(r)
		}
	}()
	// pre-scan for version/help
	for _, a := range args {
		if a == "-V" || a == "--version" {
			fmt.Println("gnuplot 5.4 patchlevel 9")
			return 0
		}
		if a == "-h" || a == "--help" {
			fmt.Print(usage())
			return 0
		}
		if a == "-e" || a == "-c" {
			break
		}
	}
	didSomething := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-e":
			if i+1 >= len(args) {
				in.flushOut()
				fmt.Fprintln(os.Stderr, "gnuplot: option requires an argument -- 'e'")
				fmt.Fprint(os.Stdout, usage())
				return 1
			}
			i++
			didSomething = true
			in.noInteractive = true
			src := &Source{lines: []string{args[i]}, kind: 0}
			in.srcStack = append(in.srcStack, src)
			lines := strings.Split(args[i], "\n")
			src.lines = lines
			for {
				l, ok := in.readLogical(src)
				if !ok {
					break
				}
				src.lineNo = 0
				in.execLine(l)
			}
			in.srcStack = in.srcStack[:0]
		case a == "-c":
			if i+1 >= len(args) {
				return 1
			}
			didSomething = true
			f := args[i+1]
			rest := args[i+2:]
			in.callTop(f, rest)
			return exitCode(in)
		case a == "-":
			didSomething = true
			in.runStdin()
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings" || a == "-persist" || a == "-slow" || a == "-default":
		case a == "-V" || a == "--version" || a == "-h" || a == "--help":
		case strings.HasPrefix(a, "-") && len(a) > 1:
			in.flushOut()
			fmt.Fprintf(os.Stderr, "unrecognized option %s\n", a)
		default:
			didSomething = true
			in.loadTop(a)
		}
	}
	if !didSomething {
		in.runStdin()
	}
	return exitCode(in)
}

func exitCode(in *Interp) int {
	if in.hadError {
		return 1
	}
	return 0
}

func (in *Interp) loadTop(name string) {
	lines, ok := readFileLines(name)
	if !ok {
		in.flushOut()
		fmt.Fprintf(os.Stderr, "line 0: Cannot load input from '%s'\n\n", name)
		in.closeAll()
		os.Exit(1)
	}
	in.setCallArgs(name, nil)
	src := &Source{lines: lines, name: name, kind: 1}
	in.runSource(src)
}

func (in *Interp) callTop(name string, args []string) {
	lines, ok := readFileLines(name)
	if !ok {
		in.flushOut()
		fmt.Fprintf(os.Stderr, "line 0: Cannot load input from '%s'\n\n", name)
		in.closeAll()
		os.Exit(1)
	}
	in.setCallArgs(name, args)
	src := &Source{lines: lines, name: name, kind: 1}
	in.runSource(src)
}

func (in *Interp) runStdin() {
	data, _ := io.ReadAll(os.Stdin)
	s := string(data)
	s = strings.TrimSuffix(s, "\n")
	var lines []string
	if len(data) > 0 {
		lines = strings.Split(s, "\n")
	}
	src := &Source{lines: lines, kind: 2}
	old := in.interactive
	in.interactive = true
	in.runSource(src)
	in.interactive = old
}
