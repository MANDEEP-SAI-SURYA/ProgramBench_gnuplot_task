package main

import (
	"fmt"
	"math"
	"os"
	"strings"
)

func (in *Interp) fitCmd(p *P) {
	S := in.S
	var rng []*Range
	for p.is("[") {
		r := &Range{AutoMin: true, AutoMax: true}
		in.parseRange(p, r)
		rng = append(rng, r)
	}
	fn := p.parseExpr()
	el := &PlotElem{Every: defaultEvery(), Index: -1, IndexEnd: -1, IndexStep: 1, Style: "points"}
	t := p.tok()
	if t.K == TStr {
		el.DataName = t.Str
		p.i++
	} else if t.K == TIdent && strings.HasPrefix(t.Text, "$") {
		el.DataName = t.Text
		p.i++
	} else {
		el.DataName = in.evalStr(p)
	}
	for !p.atEnd() && !p.isAbbr("via") {
		switch {
		case p.isAbbr("i$ndex"):
			p.i++
			el.Index = int(in.evalInt(p))
		case p.isAbbr("ev$ery"):
			p.i++
			for !p.atEnd() && !p.isAbbr("u$sing") && !p.isAbbr("via") {
				p.i++
			}
		case p.isAbbr("u$sing"):
			p.i++
			in.parseUsing(p, el)
		case p.isAbbr("yerr$ors") || p.isAbbr("xyerr$ors") || p.isAbbr("err$ors") || p.isAbbr("zerr$ors") || p.isAbbr("unitw$eights"):
			p.i++
			for !p.atEnd() && p.is(",") || p.tok().K == TIdent && len(p.tok().Text) == 1 {
				p.i++
			}
		default:
			gpErr(p.tok().Pos, "Need via and either parameter list or file")
		}
	}
	if !p.isAbbr("via") {
		gpErr(p.tok().Pos, "Need via and either parameter list or file")
	}
	p.i++
	var params []string
	for {
		tt := p.tok()
		if tt.K != TIdent {
			gpErr(tt.Pos, "no parameter specified")
		}
		params = append(params, tt.Text)
		p.i++
		if p.is(",") {
			p.i++
			continue
		}
		break
	}
	// read data
	lines := in.dataLines(el.DataName)
	recs, _ := in.scanData(lines, el.Index, el.IndexEnd, el.IndexStep, el.Every)
	using := el.Using
	raw := el.UsingRaw
	if len(using) == 0 {
		for k := 1; k <= 2; k++ {
			kk := k
			using = append(using, func(e *Env) Value { return columnValue(e, kk, in) })
			raw = append(raw, kk)
		}
	}
	var xs, ys, ws []float64
	hasErr := len(using) >= 3
	for _, r := range recs {
		if r.Fields == nil {
			continue
		}
		row := &DataRow{cols: r.Fields, line: r.Line, index: r.Index}
		vals := make([]float64, len(using))
		bad := false
		for k, f := range using {
			if raw[k] > 0 {
				if raw[k] > len(r.Fields) {
					bad = true
					break
				}
				v, ok := parseField(r.Fields[raw[k]-1])
				if !ok {
					bad = true
					break
				}
				vals[k] = v
				continue
			}
			e := &Env{row: row}
			v := f(e)
			if e.undef {
				bad = true
				break
			}
			vals[k] = numify(v).Real()
		}
		if bad {
			continue
		}
		if len(rng) > 0 {
			r0 := rng[0]
			if (!r0.AutoMin && vals[0] < r0.Min) || (!r0.AutoMax && vals[0] > r0.Max) {
				continue
			}
		}
		xs = append(xs, vals[0])
		ys = append(ys, vals[1])
		if hasErr {
			ws = append(ws, vals[2])
		} else {
			ws = append(ws, 1)
		}
	}
	n := len(xs)
	np := len(params)
	if n == 0 {
		gpErrNC("No data to fit")
	}
	// init params
	pv := make([]float64, np)
	for i, nm := range params {
		v, ok := in.vars[nm]
		if !ok {
			pv[i] = 1
		} else {
			pv[i] = numify(v).Real()
		}
	}
	scale := make([]float64, np)
	for i := range pv {
		if S.FitPrescale && pv[i] != 0 {
			scale[i] = math.Abs(pv[i])
		} else {
			scale[i] = 1
		}
	}
	dummy := S.Dummy[0]
	model := func(par []float64, x float64) (float64, bool) {
		for i, nm := range params {
			in.vars[nm] = FltV(par[i])
		}
		e := &Env{locals: map[string]Value{dummy: FltV(x)}}
		v := fn(e)
		if e.undef {
			return 0, false
		}
		return numify(v).Real(), true
	}
	for i, nm := range params {
		in.sv(nm, FltV(pv[i]))
	}
	chisqOf := func(par []float64) float64 {
		s := 0.0
		for k := 0; k < n; k++ {
			y, ok := model(par, xs[k])
			if !ok {
				return math.Inf(1)
			}
			d := (ys[k] - y) / ws[k]
			s += d * d
		}
		return s
	}
	jac := func(par []float64) ([][]float64, []float64) {
		J := make([][]float64, n)
		r := make([]float64, n)
		base := make([]float64, n)
		for k := 0; k < n; k++ {
			y, _ := model(par, xs[k])
			base[k] = y
			r[k] = (ys[k] - y) / ws[k]
			J[k] = make([]float64, np)
		}
		for i := 0; i < np; i++ {
			pp := append([]float64{}, par...)
			h := math.Abs(par[i]) * 1e-5
			if h == 0 {
				h = 1e-30
			}
			h = fitDelta * par[i]
			if h == 0 {
				h = fitDelta
			}
			pp[i] = par[i] + h
			for k := 0; k < n; k++ {
				y, _ := model(pp, xs[k])
				J[k][i] = (y - base[k]) / h * scale[i] / ws[k]
			}
		}
		return J, r
	}
	quiet := S.FitQuiet
	var out strings.Builder
	w := &out
	header := "iter      chisq       delta/lim  lambda  "
	for _, nm := range params {
		header += fmt.Sprintf(" %-13s", nm)
	}
	row := func(it string, c, delta, lam float64, par []float64) {
		s := fmt.Sprintf("%4s %-17.10e%10.2e%10.2e ", it, c, delta, lam)
		for _, v := range par {
			s += fmt.Sprintf("%15.6e", v)
		}
		fmt.Fprintln(w, s)
	}
	flush := func() {
		if !quiet {
			in.flushOut()
			os.Stderr.WriteString(out.String())
		}
		out.Reset()
	}
	c := chisqOf(pv)
	J, _ := jac(pv)
	ss := 0.0
	for _, rr := range J {
		for _, v := range rr {
			ss += v * v
		}
	}
	lam := math.Sqrt(ss / float64(n*np))
	fmt.Fprintln(w, header)
	row("0", c, 0, lam, pv)
	flush()
	iter := 0
	lastDelta := 0.0
	converged := false
	maxIter := S.FitMaxIter
	for {
		J, r := jac(pv)
		A := make([][]float64, np)
		b := make([]float64, np)
		for i := 0; i < np; i++ {
			A[i] = make([]float64, np)
			for j := 0; j < np; j++ {
				s := 0.0
				for k := 0; k < n; k++ {
					s += J[k][i] * J[k][j]
				}
				A[i][j] = s
			}
			A[i][i] += lam * lam
			s := 0.0
			for k := 0; k < n; k++ {
				s += J[k][i] * r[k]
			}
			b[i] = s
		}
		da, ok := solveLin(A, b)
		if !ok {
			break
		}
		npv := make([]float64, np)
		for i := range pv {
			npv[i] = pv[i] + da[i]*scale[i]
		}
		c2 := chisqOf(npv)
		delta := (c2 - c) / c2
		if c2 < c {
			lam /= 10
			iter++
			pv = npv
			lastDelta = delta
			cOld := c
			c = c2
			row(fmt.Sprint(iter), c, delta/S.FitLimit, lam, pv)
			flush()
			if math.Abs(cOld-c2) < S.FitLimit*c2 || c2 == 0 {
				converged = true
				break
			}
			if maxIter > 0 && iter >= maxIter {
				break
			}
		} else {
			lam *= 10
			if math.IsInf(c2, 0) || math.IsNaN(c2) {
				row("*", c2, 0, lam, npv)
			} else {
				row("*", c2, delta/S.FitLimit, lam, npv)
			}
			flush()
			if lam > 1e20 {
				break
			}
			if c2 == c {
				converged = true
				break
			}
		}
	}
	fmt.Fprintln(w, header)
	fmt.Fprintln(w)
	if converged {
		fmt.Fprintf(w, "After %d iterations the fit converged.\n", iter)
	} else {
		fmt.Fprintf(w, "After %d iterations the fit did not converge.\n", iter)
	}
	fmt.Fprintf(w, "final sum of squares of residuals : %s\n", cfmt("%g", c))
	fmt.Fprintf(w, "rel. change during last iteration : %s\n\n", cfmt("%g", lastDelta))
	ndf := n - np
	stdfit := math.Sqrt(c / float64(ndf))
	fmt.Fprintf(w, "degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	fmt.Fprintf(w, "rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", cfmt("%g", stdfit))
	fmt.Fprintf(w, "variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n", cfmt("%g", c/float64(ndf)))
	pval := 1 - igamma(float64(ndf)/2, c/2)
	if hasErr {
		fmt.Fprintf(w, "p-value of the Chisq distribution (FIT_P)              : %s\n", cfmt("%g", pval))
	}
	fmt.Fprintln(w)
	// covariance
	J2, _ := jac(pv)
	A := make([][]float64, np)
	for i := 0; i < np; i++ {
		A[i] = make([]float64, np)
		for j := 0; j < np; j++ {
			s := 0.0
			for k := 0; k < n; k++ {
				s += J2[k][i] * J2[k][j]
			}
			A[i][j] = s
		}
	}
	cov := invert(A)
	errs := make([]float64, np)
	fac := c / float64(ndf)
	if hasErr {
		fac = c / float64(ndf)
	}
	for i := 0; i < np; i++ {
		errs[i] = math.Sqrt(cov[i][i]*fac) * scale[i]
	}
	fmt.Fprintf(w, "Final set of parameters            Asymptotic Standard Error\n")
	fmt.Fprintf(w, "=======================            ==========================\n")
	for i, nm := range params {
		pct := ""
		if pv[i] != 0 {
			pct = fmt.Sprintf("(%s%%)", cfmt("%.4g", math.Abs(errs[i]/pv[i]*100)))
		}
		fmt.Fprintf(w, "%-15s = %-15s  +/- %-12s %s\n", nm, cfmt("%g", pv[i]), cfmt("%.4g", errs[i]), pct)
	}
	if np > 1 {
		fmt.Fprintf(w, "\ncorrelation matrix of the fit parameters:\n")
		s := "                "
		for _, nm := range params {
			s += fmt.Sprintf("%-7s", nm)
		}
		fmt.Fprintln(w, s)
		for i, nm := range params {
			s := fmt.Sprintf("%-15s", nm)
			for j := 0; j <= i; j++ {
				s += fmt.Sprintf("%6.3f ", cov[i][j]/math.Sqrt(cov[i][i]*cov[j][j]))
			}
			fmt.Fprintln(w, s)
		}
	}
	flush()
	for i, nm := range params {
		in.sv(nm, FltV(pv[i]))
	}
	in.sv("FIT_CONVERGED", IntV(boolI(converged)))
	in.sv("FIT_NDF", IntV(int64(ndf)))
	in.sv("FIT_STDFIT", FltV(stdfit))
	in.sv("FIT_WSSR", FltV(c))
	in.sv("FIT_P", FltV(pval))
	in.sv("FIT_NITER", IntV(int64(iter)))
	if S.FitErrVars {
		for i, nm := range params {
			in.sv(nm+"_err", FltV(errs[i]))
		}
	}
}

var fitDelta = func() float64 {
	if v := os.Getenv("FITD"); v != "" {
		var f float64
		fmt.Sscanf(v, "%g", &f)
		return f
	}
	return 1e-3
}()

func boolI(b bool) int64 {
	if b {
		return 1
	}
	return 0
}

func solveLin(A [][]float64, b []float64) ([]float64, bool) {
	n := len(b)
	M := make([][]float64, n)
	for i := range A {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for i := 0; i < n; i++ {
		piv := i
		for r := i + 1; r < n; r++ {
			if math.Abs(M[r][i]) > math.Abs(M[piv][i]) {
				piv = r
			}
		}
		M[i], M[piv] = M[piv], M[i]
		if M[i][i] == 0 {
			return nil, false
		}
		for r := 0; r < n; r++ {
			if r != i {
				f := M[r][i] / M[i][i]
				for c := i; c <= n; c++ {
					M[r][c] -= f * M[i][c]
				}
			}
		}
	}
	x := make([]float64, n)
	for i := 0; i < n; i++ {
		x[i] = M[i][n] / M[i][i]
	}
	return x, true
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	M := make([][]float64, n)
	for i := range A {
		M[i] = make([]float64, 2*n)
		copy(M[i], A[i])
		M[i][n+i] = 1
	}
	for i := 0; i < n; i++ {
		piv := i
		for r := i + 1; r < n; r++ {
			if math.Abs(M[r][i]) > math.Abs(M[piv][i]) {
				piv = r
			}
		}
		M[i], M[piv] = M[piv], M[i]
		d := M[i][i]
		if d == 0 {
			d = 1e-300
		}
		for c := 0; c < 2*n; c++ {
			M[i][c] /= d
		}
		for r := 0; r < n; r++ {
			if r != i {
				f := M[r][i]
				for c := 0; c < 2*n; c++ {
					M[r][c] -= f * M[i][c]
				}
			}
		}
	}
	out := make([][]float64, n)
	for i := range out {
		out[i] = M[i][n:]
	}
	return out
}
