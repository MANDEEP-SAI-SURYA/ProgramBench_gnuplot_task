package main

import (
	"strconv"
	"strings"
)

type TokKind int

const (
	TEnd TokKind = iota
	TNum
	TStr
	TIdent
	TOp
)

type Token struct {
	K     TokKind
	Text  string // raw text (identifiers, ops)
	Str   string // processed string value
	Num   Value
	Pos   int
	End   int
	Quote byte
}

func isIdentStart(c byte) bool {
	return c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}
func isIdentChar(c byte) bool { return isIdentStart(c) || (c >= '0' && c <= '9') }

var ops3 = []string{"**=", "<<=", ">>="}
var ops2 = []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "=~", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", ".="}

func tokenize(line string) []Token {
	var toks []Token
	i := 0
	n := len(line)
	for {
		for i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r' || line[i] == '\n') {
			i++
		}
		if i >= n {
			break
		}
		c := line[i]
		start := i
		if c == '#' {
			// comment to end of line (but within braces blocks newline separated)
			for i < n && line[i] != '\n' {
				i++
			}
			continue
		}
		if c >= '0' && c <= '9' || (c == '.' && i+1 < n && line[i+1] >= '0' && line[i+1] <= '9') {
			// number
			if c == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
				toks = append(toks, Token{K: TNum, Text: line[i:j], Num: IntV(int64(v)), Pos: start, End: j})
				i = j
				continue
			}
			j := i
			isf := false
			for j < n && line[j] >= '0' && line[j] <= '9' {
				j++
			}
			if j < n && line[j] == '.' {
				isf = true
				j++
				for j < n && line[j] >= '0' && line[j] <= '9' {
					j++
				}
			}
			if j < n && (line[j] == 'e' || line[j] == 'E') {
				k := j + 1
				if k < n && (line[k] == '+' || line[k] == '-') {
					k++
				}
				if k < n && line[k] >= '0' && line[k] <= '9' {
					for k < n && line[k] >= '0' && line[k] <= '9' {
						k++
					}
					j = k
					isf = true
				}
			}
			txt := line[i:j]
			var v Value
			if isf {
				f, _ := strconv.ParseFloat(txt, 64)
				v = FltV(f)
			} else {
				if len(txt) > 1 && txt[0] == '0' {
					iv, err := strconv.ParseInt(txt, 8, 64)
					if err == nil {
						v = IntV(iv)
					} else {
						f, _ := strconv.ParseFloat(txt, 64)
						v = FltV(f)
					}
				} else {
					iv, err := strconv.ParseInt(txt, 10, 64)
					if err == nil {
						v = IntV(iv)
					} else {
						f, _ := strconv.ParseFloat(txt, 64)
						v = FltV(f)
					}
				}
			}
			toks = append(toks, Token{K: TNum, Text: txt, Num: v, Pos: start, End: j})
			i = j
			continue
		}
		if c == '"' {
			j := i + 1
			var b strings.Builder
			for j < n && line[j] != '"' {
				if line[j] == '\\' && j+1 < n {
					j++
					switch line[j] {
					case 'n':
						b.WriteByte('\n')
					case 't':
						b.WriteByte('\t')
					case 'r':
						b.WriteByte('\r')
					case 'a':
						b.WriteByte('\a')
					case 'b':
						b.WriteByte('\b')
					case 'f':
						b.WriteByte('\f')
					case 'v':
						b.WriteByte('\v')
					case '\\':
						b.WriteByte('\\')
					case '"':
						b.WriteByte('"')
					case '\n':
					default:
						if line[j] >= '0' && line[j] <= '7' {
							k := j
							v := 0
							for k < n && k < j+3 && line[k] >= '0' && line[k] <= '7' {
								v = v*8 + int(line[k]-'0')
								k++
							}
							b.WriteByte(byte(v))
							j = k - 1
						} else {
							b.WriteByte(line[j])
						}
					}
					j++
					continue
				}
				b.WriteByte(line[j])
				j++
			}
			end := j
			if j < n {
				end = j + 1
			}
			toks = append(toks, Token{K: TStr, Text: line[i:end], Str: b.String(), Pos: start, End: end, Quote: '"'})
			i = end
			continue
		}
		if c == '\'' {
			j := i + 1
			var b strings.Builder
			for j < n {
				if line[j] == '\'' {
					if j+1 < n && line[j+1] == '\'' {
						b.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				b.WriteByte(line[j])
				j++
			}
			end := j
			if j < n {
				end = j + 1
			}
			toks = append(toks, Token{K: TStr, Text: line[i:end], Str: b.String(), Pos: start, End: end, Quote: '\''})
			i = end
			continue
		}
		if isIdentStart(c) {
			j := i
			for j < n && isIdentChar(line[j]) {
				j++
			}
			toks = append(toks, Token{K: TIdent, Text: line[i:j], Pos: start, End: j})
			i = j
			continue
		}
		if c == '$' {
			j := i + 1
			for j < n && isIdentChar(line[j]) {
				j++
			}
			toks = append(toks, Token{K: TIdent, Text: line[i:j], Pos: start, End: j})
			i = j
			continue
		}
		matched := false
		for _, o := range ops3 {
			if strings.HasPrefix(line[i:], o) {
				toks = append(toks, Token{K: TOp, Text: o, Pos: start, End: i + 3})
				i += 3
				matched = true
				break
			}
		}
		if !matched {
			for _, o := range ops2 {
				if strings.HasPrefix(line[i:], o) {
					toks = append(toks, Token{K: TOp, Text: o, Pos: start, End: i + 2})
					i += 2
					matched = true
					break
				}
			}
		}
		if !matched {
			toks = append(toks, Token{K: TOp, Text: string(c), Pos: start, End: i + 1})
			i++
		}
	}
	toks = append(toks, Token{K: TEnd, Pos: n, End: n})
	return toks
}
