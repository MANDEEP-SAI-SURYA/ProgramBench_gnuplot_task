package main

import (
	"math"
	"strconv"
	"strings"
)

// parseField parses a numeric data field like strtod; ok=false if not numeric
func parseField(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	n := scanNumberPrefix(s)
	if n == 0 {
		// inf / nan
		ls := strings.ToLower(s)
		if strings.HasPrefix(ls, "nan") || strings.HasPrefix(ls, "-nan") {
			return math.NaN(), true
		}
		if strings.HasPrefix(ls, "inf") {
			return math.Inf(1), true
		}
		if strings.HasPrefix(ls, "-inf") {
			return math.Inf(-1), true
		}
		return 0, false
	}
	f, err := strconv.ParseFloat(s[:n], 64)
	if err != nil {
		if ne, ok := err.(*strconv.NumError); ok && ne.Err == strconv.ErrRange {
			return f, true
		}
		return 0, false
	}
	return f, true
}

func (in *Interp) splitFields(line string) []string {
	sep := in.S.DFSep
	var out []string
	if sep == "" {
		i := 0
		n := len(line)
		for {
			for i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
				i++
			}
			if i >= n {
				break
			}
			if line[i] == '"' {
				j := i + 1
				for j < n && line[j] != '"' {
					j++
				}
				out = append(out, line[i+1:min(j, n)])
				i = j + 1
				continue
			}
			j := i
			for j < n && line[j] != ' ' && line[j] != '\t' && line[j] != '\r' {
				j++
			}
			out = append(out, line[i:j])
			i = j
		}
		return out
	}
	// explicit separator
	cur := ""
	inq := false
	for i := 0; i < len(line); i++ {
		c := line[i]
		if c == '"' {
			inq = !inq
			continue
		}
		if !inq && strings.IndexByte(sep, c) >= 0 {
			out = append(out, strings.TrimSpace(cur))
			cur = ""
			continue
		}
		cur += string(c)
	}
	out = append(out, strings.TrimSpace(strings.TrimRight(cur, "\r")))
	return out
}

func (in *Interp) isComment(line string) bool {
	t := strings.TrimLeft(line, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(in.S.DFComment, t[0]) >= 0
}

func isBlank(line string) bool {
	return strings.TrimSpace(line) == ""
}

func (in *Interp) dataLines(name string) []string {
	if strings.HasPrefix(name, "$") {
		db, ok := in.datablocks[name]
		if !ok {
			gpErrNC("undefined datablock " + name)
		}
		return db
	}
	lines, ok := readFileLines(name)
	if !ok {
		gpErrNC("Cannot find or open file \"" + name + "\"")
	}
	return lines
}

func columnValue(e *Env, n int, in *Interp) Value {
	r := e.row
	if r == nil {
		gpErrNC("column() called from invalid context")
	}
	if n == 0 {
		return FltV(float64(r.line))
	}
	if n == -2 {
		return FltV(float64(r.index))
	}
	if n < 0 || n > len(r.cols) {
		e.undef = true
		return FltV(math.NaN())
	}
	s := r.cols[n-1]
	if in.S.DFMissing != "" && s == in.S.DFMissing {
		e.undef = true
		return FltV(math.NaN())
	}
	f, ok := parseField(s)
	if !ok {
		e.undef = true
		return FltV(math.NaN())
	}
	return FltV(f)
}

func columnByName(e *Env, name string, in *Interp) Value {
	r := e.row
	if r == nil {
		gpErrNC("column() called from invalid context")
	}
	for i, h := range r.headers {
		if h == name {
			return columnValue(e, i+1, in)
		}
	}
	e.undef = true
	return FltV(math.NaN())
}

func stringColumn(e *Env, a Value, in *Interp) Value {
	r := e.row
	if r == nil {
		gpErrNC("column() called from invalid context")
	}
	n := 0
	if a.K == KStr {
		for i, h := range r.headers {
			if h == a.S {
				n = i + 1
			}
		}
	} else {
		n = int(numToInt(numify(a)))
	}
	if n < 1 || n > len(r.cols) {
		e.undef = true
		return StrV("")
	}
	return StrV(r.cols[n-1])
}

type EverySpec struct {
	PInc, BInc, PStart, BStart, PEnd, BEnd int
}

func defaultEvery() EverySpec {
	return EverySpec{1, 1, 0, 0, -1, -1}
}

// DataRec is a record produced by scanning a data source
type DataRec struct {
	Fields []string
	Line   int // $0
	Index  int
	Block  int
	Break  bool // blank line before this record (single)
	NewIdx bool // double blank before this
}

// scanData returns records; markers for blank lines are encoded with Fields==nil
func (in *Interp) scanData(lines []string, index int, indexEnd int, indexStep int, every EverySpec) ([]*DataRec, []string) {
	var recs []*DataRec
	var headers []string
	idx := 0
	block := 0
	lineNo := 0
	blanks := 0
	pt := 0 // point index within block
	firstData := true
	for _, l := range lines {
		if in.isComment(l) {
			continue
		}
		if isBlank(l) {
			blanks++
			if blanks == 1 {
				block++
				pt = 0
				if inIndex(idx, index, indexEnd, indexStep) {
					recs = append(recs, &DataRec{Fields: nil, Index: idx, Block: block})
				}
			} else if blanks == 2 {
				idx++
				block = 0
				lineNo = 0
				if len(recs) > 0 && recs[len(recs)-1].Fields == nil {
					recs[len(recs)-1].NewIdx = true
				}
			}
			continue
		}
		blanks = 0
		f := in.splitFields(l)
		if firstData {
			headers = f
			firstData = false
		}
		if !inIndex(idx, index, indexEnd, indexStep) {
			lineNo++
			pt++
			continue
		}
		// every
		ok := true
		if pt < every.PStart || (every.PEnd >= 0 && pt > every.PEnd) || (pt-every.PStart)%every.PInc != 0 {
			ok = false
		}
		if block < every.BStart || (every.BEnd >= 0 && block > every.BEnd) || (block-every.BStart)%every.BInc != 0 {
			ok = false
		}
		if ok {
			recs = append(recs, &DataRec{Fields: f, Line: lineNo, Index: idx, Block: block})
		}
		lineNo++
		pt++
	}
	// trim trailing break markers
	for len(recs) > 0 && recs[len(recs)-1].Fields == nil {
		recs = recs[:len(recs)-1]
	}
	// remove leading markers
	for len(recs) > 0 && recs[0].Fields == nil {
		recs = recs[1:]
	}
	// collapse consecutive markers and drop markers for excluded blocks
	var out []*DataRec
	for _, r := range recs {
		if r.Fields == nil && len(out) > 0 && out[len(out)-1].Fields == nil {
			continue
		}
		out = append(out, r)
	}
	return out, headers
}

func inIndex(idx, start, end, step int) bool {
	if start < 0 {
		return true
	}
	if idx < start {
		return false
	}
	if end >= 0 && idx > end {
		return false
	}
	if end < 0 && idx != start {
		return false
	}
	if step > 1 && (idx-start)%step != 0 {
		return false
	}
	return true
}
