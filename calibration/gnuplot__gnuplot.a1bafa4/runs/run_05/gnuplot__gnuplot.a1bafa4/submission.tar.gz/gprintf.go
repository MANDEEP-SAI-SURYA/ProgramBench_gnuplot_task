package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

func mantExp(x float64, base float64, prec int, eng bool) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	p := int(math.Floor(math.Log(ax) / math.Log(base)))
	if eng {
		p = int(math.Floor(float64(p)/3)) * 3
	}
	m := x / math.Pow(base, float64(p))
	// rounding check
	if prec >= 0 {
		s := fmt.Sprintf("%.*f", prec, math.Abs(m))
		rv, _ := strconv.ParseFloat(s, 64)
		lim := base
		if eng {
			lim = 1000
		}
		if rv >= lim {
			if eng {
				p += 3
			} else {
				p++
			}
			m = x / math.Pow(base, float64(p))
		}
	}
	return m, p
}

func specPrec(spec string) int {
	i := strings.IndexByte(spec, '.')
	if i < 0 {
		return 6
	}
	j := i + 1
	for j < len(spec) && spec[j] >= '0' && spec[j] <= '9' {
		j++
	}
	n, _ := strconv.Atoi(spec[i+1 : j])
	return n
}

func gprintf(format string, x float64, in *Interp) string {
	return gprintfBase(format, x, in, 0)
}

func gprintfBase(format string, x float64, in *Interp, logbase float64) string {
	var b strings.Builder
	// find precision for mantissa
	prec := 6
	for _, pc := range splitFormatG(format) {
		if pc.spec != "" {
			c := pc.spec[len(pc.spec)-1]
			if c == 't' || c == 's' || c == 'l' || c == 'b' {
				prec = specPrec(pc.spec)
				break
			}
		}
	}
	for _, pc := range splitFormatG(format) {
		if pc.spec == "" {
			b.WriteString(pc.lit)
			continue
		}
		spec := pc.spec
		c := spec[len(spec)-1]
		body := spec[:len(spec)-1]
		switch c {
		case 't':
			m, _ := mantExp(x, 10, prec, false)
			b.WriteString(cfmt(body+"f", m))
		case 'T':
			_, p := mantExp(x, 10, prec, false)
			b.WriteString(cfmt(body+"d", int64(p)))
		case 'l':
			if logbase > 1 {
				m, _ := mantExp(x, logbase, prec, false)
				b.WriteString(cfmt(body+"f", m))
			} else {
				b.WriteString(cfmt(body+"f", x))
			}
		case 'L':
			if logbase > 1 {
				_, p := mantExp(x, logbase, prec, false)
				b.WriteString(cfmt(body+"d", int64(p)))
			} else {
				b.WriteString(cfmt(body+"d", int64(0)))
			}
		case 's':
			m, _ := mantExp(x, 10, prec, true)
			b.WriteString(cfmt(body+"f", m))
		case 'S':
			_, p := mantExp(x, 10, prec, true)
			b.WriteString(cfmt(body+"d", int64(p)))
		case 'c':
			_, p := mantExp(x, 10, prec, true)
			pre := "yzafpnum kMGTPEZY"
			idx := p/3 + 8
			if idx >= 0 && idx < len(pre) {
				if pre[idx] != ' ' {
					b.WriteString(cfmt(body+"c", int64(pre[idx])))
				}
			} else {
				b.WriteString(fmt.Sprintf("e%d", p))
			}
		case 'b':
			m, _ := mantExp(x, 1024, prec, false)
			b.WriteString(cfmt(body+"f", m))
		case 'B':
			_, p := mantExp(x, 1024, prec, false)
			pre := []string{"", "ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"}
			if p >= 0 && p < len(pre) {
				b.WriteString(pre[p])
			}
		case 'P':
			b.WriteString(cfmt(body+"f", x/math.Pi))
		case 'h', 'H':
			s := cfmt(body+"g", x)
			b.WriteString(s)
		case 'd', 'i', 'o', 'x', 'X':
			b.WriteString(cfmt(spec, int64(math.Floor(x+0.5))))
		case 'f', 'F', 'e', 'E', 'g', 'G':
			b.WriteString(cfmt(spec, x))
		default:
			b.WriteString(spec)
		}
	}
	return b.String()
}

func splitFormatG(f string) []fmtPiece {
	var out []fmtPiece
	var lit strings.Builder
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' {
			lit.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			lit.WriteByte('%')
			i += 2
			continue
		}
		j := i + 1
		for j < len(f) && strings.IndexByte("-+ #0", f[j]) >= 0 {
			j++
		}
		for j < len(f) && f[j] >= '0' && f[j] <= '9' {
			j++
		}
		if j < len(f) && f[j] == '.' {
			j++
			for j < len(f) && f[j] >= '0' && f[j] <= '9' {
				j++
			}
		}
		for j < len(f) && (f[j] == 'l' && j+1 < len(f) && strings.IndexByte("dfegxio", f[j+1]) >= 0) {
			j++
		}
		if j >= len(f) {
			lit.WriteString(f[i:])
			break
		}
		if lit.Len() > 0 {
			out = append(out, fmtPiece{lit: lit.String()})
			lit.Reset()
		}
		out = append(out, fmtPiece{spec: f[i : j+1]})
		i = j + 1
	}
	if lit.Len() > 0 {
		out = append(out, fmtPiece{lit: lit.String()})
	}
	return out
}

var monNames = []string{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
var monFull = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}
var dayFull = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, t float64) string {
	sec := math.Floor(t)
	frac := t - sec
	tm := time.Unix(int64(sec), 0).UTC()
	var b strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			b.WriteByte(c)
			continue
		}
		i++
		// optional width/precision for %S etc
		pad := ""
		for i < len(f) && (f[i] == '0' || f[i] == '.' || (f[i] >= '1' && f[i] <= '9')) {
			pad += string(f[i])
			i++
		}
		if i >= len(f) {
			break
		}
		switch f[i] {
		case 'a':
			b.WriteString(dayNames[tm.Weekday()])
		case 'A':
			b.WriteString(dayFull[tm.Weekday()])
		case 'b', 'h':
			b.WriteString(monNames[tm.Month()-1])
		case 'B':
			b.WriteString(monFull[tm.Month()-1])
		case 'd':
			fmt.Fprintf(&b, "%02d", tm.Day())
		case 'e':
			fmt.Fprintf(&b, "%2d", tm.Day())
		case 'D':
			fmt.Fprintf(&b, "%02d/%02d/%02d", tm.Month(), tm.Day(), tm.Year()%100)
		case 'F':
			fmt.Fprintf(&b, "%04d-%02d-%02d", tm.Year(), tm.Month(), tm.Day())
		case 'H':
			fmt.Fprintf(&b, "%02d", tm.Hour())
		case 'k':
			fmt.Fprintf(&b, "%2d", tm.Hour())
		case 'I':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%02d", h)
		case 'l':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%2d", h)
		case 'j':
			fmt.Fprintf(&b, "%03d", tm.YearDay())
		case 'm':
			fmt.Fprintf(&b, "%02d", tm.Month())
		case 'M':
			fmt.Fprintf(&b, "%02d", tm.Minute())
		case 'p':
			if tm.Hour() < 12 {
				b.WriteString("am")
			} else {
				b.WriteString("pm")
			}
		case 'P':
			if tm.Hour() < 12 {
				b.WriteString("am")
			} else {
				b.WriteString("pm")
			}
		case 'r':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			ap := "AM"
			if tm.Hour() >= 12 {
				ap = "PM"
			}
			fmt.Fprintf(&b, "%02d:%02d:%02d %s", h, tm.Minute(), tm.Second(), ap)
		case 'R':
			fmt.Fprintf(&b, "%02d:%02d", tm.Hour(), tm.Minute())
		case 'S':
			if strings.Contains(pad, ".") {
				pr, _ := strconv.Atoi(pad[strings.Index(pad, ".")+1:])
				s := fmt.Sprintf("%0*.*f", pr+3, pr, float64(tm.Second())+frac)
				b.WriteString(s)
			} else {
				fmt.Fprintf(&b, "%02d", tm.Second())
			}
		case 's':
			fmt.Fprintf(&b, "%d", int64(sec))
		case 'T':
			fmt.Fprintf(&b, "%02d:%02d:%02d", tm.Hour(), tm.Minute(), tm.Second())
		case 'y':
			fmt.Fprintf(&b, "%02d", tm.Year()%100)
		case 'Y':
			fmt.Fprintf(&b, "%d", tm.Year())
		case 'w':
			fmt.Fprintf(&b, "%d", tm.Weekday())
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case '%':
			b.WriteByte('%')
		default:
			b.WriteByte('%')
			b.WriteByte(f[i])
		}
	}
	return b.String()
}

func gpStrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	secf := 0.0
	yday := -1
	pm := -1
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		neg := false
		if si < len(s) && s[si] == '-' {
			neg = true
			si++
		}
		st := si
		for si < len(s) && si-st < maxd && s[si] >= '0' && s[si] <= '9' {
			si++
		}
		if si == st {
			return 0, false
		}
		v, _ := strconv.Atoi(s[st:si])
		if neg {
			v = -v
		}
		return v, true
	}
	epoch := false
	var epochv float64
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == c {
				si++
				continue
			}
			return 0, false
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			year, ok = readInt(2)
			if year < 69 {
				year += 2000
			} else {
				year += 1900
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			for si < len(s) && s[si] == ' ' {
				si++
			}
			st := si
			for si < len(s) && (s[si] >= '0' && s[si] <= '9' || s[si] == '.') {
				si++
			}
			secf, _ = strconv.ParseFloat(s[st:si], 64)
			ok = si > st
		case 's':
			st := si
			for si < len(s) && (s[si] >= '0' && s[si] <= '9' || s[si] == '.' || s[si] == '-') {
				si++
			}
			epochv, _ = strconv.ParseFloat(s[st:si], 64)
			epoch = true
			ok = si > st
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m) {
					mon = k + 1
					si += 3
					if f[i] == 'B' {
						rest := monFull[k][3:]
						if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(rest)) {
							si += len(rest)
						}
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			ok = true
			for si < len(s) && s[si] != ' ' {
				si++
			}
		case 'p':
			ok = true
			if len(s)-si >= 2 {
				if strings.EqualFold(s[si:si+2], "pm") {
					pm = 1
				} else {
					pm = 0
				}
				si += 2
			}
		case 'T':
			hour, ok = readInt(2)
			if ok && si < len(s) && s[si] == ':' {
				si++
				min, ok = readInt(2)
				if ok && si < len(s) && s[si] == ':' {
					si++
					var sc int
					sc, ok = readInt(2)
					secf = float64(sc)
				}
			}
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if epoch {
		return epochv, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + secf, true
}
