package main

import (
	"fmt"
	"io"
	"os"
	"sort"
	"strings"
)

type Range struct {
	Min, Max       float64
	AutoMin, AutoMax bool
	Reverse        bool
	Writeback      bool
	Set            bool
	CurMin, CurMax float64
}

type TextLabel struct {
	Text   string
	OffX, OffY float64
}

type Settings struct {
	Samples1, Samples2 int
	Iso1, Iso2         int
	Ranges             map[string]*Range
	Title              TextLabel
	Labels             map[string]*TextLabel // xlabel etc
	StyleData          string
	StyleFunc          string
	Log                map[string]float64
	Format             map[string]string
	Grid               bool
	Dummy              [2]string
	View               [4]float64
	Zero               float64
	Parametric         bool
	Polar              bool
	BoxWidth           float64
	BoxAbs             bool
	Timefmt            string
	TimeAxis           map[string]bool
	TableOn            bool
	TableFile          string
	Output             string
	KeyOn              bool
	KeyVert            string
	KeyHoriz           string
	KeyBox             bool
	KeyOutside         bool
	KeyLeftJust        bool
	KeyReverse         bool
	KeyTitle           string
	KeyHorizontal      bool
	Offsets            [4]float64
	SizeX, SizeY       float64
	SizeSquare         bool
	OriginX, OriginY   float64
	Margins            [4]float64
	MarginSet          [4]bool
	PointSize          float64
	Term               string
	TermW, TermH       int
	DFSep              string
	DFMissing          string
	DFComment          string
	FitLog             string
	FitQuiet           bool
	FitErrVars         bool
	FitCovVars         bool
	FitLimit           float64
	FitMaxIter         int
	FitPrescale        bool
	FitNoLog           bool
	Tics               map[string]*TicSpec
	Border             int
	Clip               bool
	Encoding           string
	Smooth             string
	Contour            bool
	Surface            bool
	Hidden3d           bool
	Ticslevel          float64
	XyPlane            bool
	Mxtics             map[string]int
	DecimalSign        string
	LabelsList         []*UserLabel
	Arrows             []*UserArrow
	Multiplot          bool
	BarSize            float64
	Isosamples         int
	SvgW, SvgH         int
	CanvasW, CanvasH   int
	DumbFeed           bool
	DumbAspect         [2]int
	Enhanced           bool
	Bins               int
	StyleFillSolid     float64
	StyleFill          string
	KeySamplen         float64
	KeySpacing         float64
	KeyColHead         bool
}

type TicSpec struct {
	On       bool
	Mirror   bool
	Step     float64
	Start    float64
	End      float64
	HasStart bool
	HasEnd   bool
	Auto     bool
	Out      bool
	Manual   []ManualTic
	AddMode  bool
	Rotate   bool
	Scale    float64
}

type ManualTic struct {
	Pos   float64
	Label string
	HasLabel bool
	Minor bool
}

type UserLabel struct {
	Tag  int
	Text string
	X, Y float64
	Coord string
	Just string
	Point bool
	Front bool
}

type UserArrow struct {
	Tag            int
	X1, Y1, X2, Y2 float64
	Head           bool
	Rel            bool
	Coord1, Coord2 string
}

var axisNames = []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"}

func defaultSettings() *Settings {
	s := &Settings{
		Samples1: 100, Samples2: 100, Iso1: 10, Iso2: 10,
		Ranges:    map[string]*Range{},
		Labels:    map[string]*TextLabel{},
		StyleData: "points", StyleFunc: "lines",
		Log:      map[string]float64{},
		Format:   map[string]string{},
		Dummy:    [2]string{"x", "y"},
		View:     [4]float64{60, 30, 1, 1},
		Zero:     1e-8,
		BoxWidth: -1,
		Timefmt:  "%d/%m/%y,%H:%M",
		TimeAxis: map[string]bool{},
		KeyOn:    true, KeyVert: "top", KeyHoriz: "right",
		SizeX: 1, SizeY: 1,
		Margins:   [4]float64{-1, -1, -1, -1},
		PointSize: 1,
		Term:      "unknown",
		TermW:     79, TermH: 24,
		DFComment: "#",
		FitLimit:  1e-5,
		FitPrescale: true,
		FitErrVars: true,
		Tics:      map[string]*TicSpec{},
		Border:    31,
		Surface:   true,
		Ticslevel: 0.5,
		Mxtics:    map[string]int{},
		SvgW: 600, SvgH: 480, CanvasW: 600, CanvasH: 400,
		DumbFeed: true, DumbAspect: [2]int{2, 1},
		Enhanced: true,
		KeySamplen: 4, KeySpacing: 1,
		StyleFill: "empty",
	}
	for _, a := range axisNames {
		r := &Range{AutoMin: true, AutoMax: true, Min: -10, Max: 10, CurMin: -10, CurMax: 10}
		switch a {
		case "t":
			r.AutoMin, r.AutoMax = false, false
			r.Min, r.Max = -5, 5
		case "u", "v":
			r.AutoMin, r.AutoMax = false, false
			r.Min, r.Max = -10, 10
		case "r":
			r.AutoMin = false
			r.Min = 0
		}
		s.Ranges[a] = r
		s.Format[a] = "% h"
	}
	for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
		s.Labels[a] = &TextLabel{}
		t := &TicSpec{On: true, Mirror: true, Auto: true, Scale: 1}
		if a == "x2" || a == "y2" {
			t.On = false
		}
		if a == "z" {
			t.Mirror = false
		}
		s.Tics[a] = t
	}
	return s
}

func (in *Interp) resetSettings() {
	term, tw, th := in.S.Term, in.S.TermW, in.S.TermH
	out := in.S.Output
	ns := defaultSettings()
	ns.Term, ns.TermW, ns.TermH = term, tw, th
	ns.Output = out
	ns.SvgW, ns.SvgH, ns.CanvasW, ns.CanvasH = in.S.SvgW, in.S.SvgH, in.S.CanvasW, in.S.CanvasH
	in.S = ns
	in.degrees = false
}

func (in *Interp) skipToEnd(p *P) {
	for !p.atEnd() {
		p.i++
	}
}

func (in *Interp) parseRange(p *P, r *Range) {
	// p at '['
	p.expect("[")
	if p.is("]") {
		p.i++
		return
	}
	// optional dummy=  e.g. [t=0:1]
	if p.tok().K == TIdent && p.peek(1).Text == "=" {
		p.i += 2
	}
	if !p.is(":") {
		if p.is("*") {
			p.i++
			r.AutoMin = true
		} else {
			r.Min = in.rangeVal(p)
			r.AutoMin = false
		}
	}
	if p.is("]") {
		p.i++
		return
	}
	if !p.is(":") {
		gpErr(p.tok().Pos, "':' expected")
	}
	p.i++
	if !p.is("]") {
		if p.is("*") {
			p.i++
			r.AutoMax = true
		} else {
			r.Max = in.rangeVal(p)
			r.AutoMax = false
		}
	}
	if !p.is("]") {
		gpErr(p.tok().Pos, "']' expected")
	}
	p.i++
}

func (in *Interp) rangeVal(p *P) float64 {
	v := in.constExpr(p)
	if v.K == KStr {
		t, ok := gpStrptime(in.S.Timefmt, v.S)
		if ok {
			return t
		}
		return 0
	}
	return numify(v).Real()
}

func axisOf(word string) (string, string) {
	// returns axis and suffix kind
	for _, suf := range []string{"range", "label", "tics", "data", "zeroaxis", "mtics"} {
		if strings.HasSuffix(word, suf) {
			a := strings.TrimSuffix(word, suf)
			for _, an := range axisNames {
				if a == an {
					return a, suf
				}
			}
		}
	}
	return "", ""
}

func (in *Interp) setCmd(p *P, unset bool) {
	S := in.S
	t := p.tok()
	if t.K != TIdent {
		if unset {
			gpErr(t.Pos, "unrecognized option - see 'help unset'.")
		}
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
	w := t.Text
	p.i++
	if ax, kind := axisOf(w); ax != "" {
		switch kind {
		case "range":
			r := S.Ranges[ax]
			if unset {
				*r = Range{AutoMin: true, AutoMax: true, Min: -10, Max: 10, CurMin: r.CurMin, CurMax: r.CurMax}
				return
			}
			if p.is("[") {
				in.parseRange(p, r)
			}
			for !p.atEnd() {
				switch {
				case p.isAbbr("rev$erse"):
					r.Reverse = true
				case p.isAbbr("norev$erse"):
					r.Reverse = false
				case p.isAbbr("wr$iteback"):
					r.Writeback = true
				case p.isAbbr("nowr$iteback"):
					r.Writeback = false
				case p.isAbbr("res$tore"):
				}
				p.i++
			}
			return
		case "label":
			l := S.Labels[ax]
			if l == nil {
				l = &TextLabel{}
				S.Labels[ax] = l
			}
			if unset {
				*l = TextLabel{}
				return
			}
			if !p.atEnd() && !p.isAbbr("off$set") {
				l.Text = in.evalStr(p)
			}
			in.parseOffset(p, &l.OffX, &l.OffY)
			in.skipToEnd(p)
			return
		case "tics":
			in.setTics(p, ax, unset)
			return
		case "data":
			if unset {
				S.TimeAxis[ax] = false
				return
			}
			if p.isAbbr("t$ime") {
				S.TimeAxis[ax] = true
				p.i++
			} else {
				S.TimeAxis[ax] = false
			}
			return
		case "mtics":
			if unset {
				S.Mxtics[ax] = 0
			} else {
				S.Mxtics[ax] = -1
				if !p.atEnd() {
					S.Mxtics[ax] = int(in.evalInt(p))
				}
			}
			return
		default:
			in.skipToEnd(p)
			return
		}
	}
	switch {
	case abbrev(w, "sa$mples"):
		if unset {
			S.Samples1, S.Samples2 = 100, 100
			return
		}
		pos := p.tok().Pos
		_ = pos
		n := in.evalInt(p)
		m := n
		if p.is(",") {
			p.i++
			m = in.evalInt(p)
		}
		if n < 2 || m < 2 {
			gpErr(p.tok().Pos, "sampling rate must be > 1; sampling unchanged")
		}
		S.Samples1, S.Samples2 = int(n), int(m)
	case abbrev(w, "iso$samples"):
		if unset {
			S.Iso1, S.Iso2 = 10, 10
			return
		}
		n := in.evalInt(p)
		m := n
		if p.is(",") {
			p.i++
			m = in.evalInt(p)
		}
		if n < 2 || m < 2 {
			gpErr(p.tok().Pos, "sampling rate must be > 1; sampling unchanged")
		}
		S.Iso1, S.Iso2 = int(n), int(m)
	case abbrev(w, "t$itle"):
		if unset {
			S.Title = TextLabel{}
			return
		}
		if !p.atEnd() && !p.isAbbr("off$set") {
			S.Title.Text = in.evalStr(p)
		}
		in.parseOffset(p, &S.Title.OffX, &S.Title.OffY)
		in.skipToEnd(p)
	case abbrev(w, "st$yle"):
		if p.isAbbr("d$ata") {
			p.i++
			if unset {
				S.StyleData = "points"
				return
			}
			S.StyleData = in.parseStyleName(p)
		} else if p.isAbbr("f$unction") {
			p.i++
			if unset {
				S.StyleFunc = "lines"
				return
			}
			S.StyleFunc = in.parseStyleName(p)
		} else if p.isAbbr("fill") {
			p.i++
			for !p.atEnd() {
				if p.isAbbr("s$olid") {
					S.StyleFill = "solid"
					p.i++
					if !p.atEnd() && p.tok().K == TNum {
						S.StyleFillSolid = in.evalNum(p)
					}
					continue
				}
				if p.isAbbr("e$mpty") {
					S.StyleFill = "empty"
				}
				p.i++
			}
		} else {
			in.skipToEnd(p)
		}
	case abbrev(w, "lo$gscale"):
		axes := "x y z x2 y2 cb"
		if unset {
			if p.atEnd() {
				S.Log = map[string]float64{}
				return
			}
			axes = p.tok().Text
			p.i++
			for _, a := range parseAxesWord(axes) {
				delete(S.Log, a)
			}
			return
		}
		base := 10.0
		if !p.atEnd() {
			axes = p.tok().Text
			p.i++
			if !p.atEnd() {
				base = in.evalNum(p)
			}
		} else {
			axes = "xyzx2y2cb"
		}
		for _, a := range parseAxesWord(axes) {
			S.Log[a] = base
		}
	case abbrev(w, "form$at"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb", "r"}
		if !p.atEnd() && p.tok().K == TIdent && !p.isStringStart() {
			axes = parseAxesWord(p.tok().Text)
			p.i++
		}
		f := "% h"
		if !unset && !p.atEnd() {
			f = in.evalStr(p)
		}
		for _, a := range axes {
			S.Format[a] = f
		}
		in.skipToEnd(p)
	case abbrev(w, "g$rid"):
		S.Grid = !unset
		in.skipToEnd(p)
	case abbrev(w, "an$gles"):
		if unset {
			in.degrees = false
			return
		}
		if p.isAbbr("d$egrees") {
			in.degrees = true
		} else {
			in.degrees = false
		}
		p.i++
	case abbrev(w, "du$mmy"):
		if unset {
			S.Dummy = [2]string{"x", "y"}
			return
		}
		if !p.is(",") {
			S.Dummy[0] = p.tok().Text
			p.i++
		}
		if p.is(",") {
			p.i++
			S.Dummy[1] = p.tok().Text
			p.i++
		}
	case abbrev(w, "vi$ew"):
		if unset {
			S.View = [4]float64{60, 30, 1, 1}
			return
		}
		if p.isAbbr("map") {
			S.View = [4]float64{0, 0, S.View[2], S.View[3]}
			p.i++
			return
		}
		k := 0
		for !p.atEnd() && k < 4 {
			if p.is(",") {
				p.i++
				k++
				continue
			}
			if p.tok().K == TIdent && !p.in.isVarOrFunc(p) {
				in.skipToEnd(p)
				break
			}
			S.View[k] = in.evalNum(p)
		}
	case abbrev(w, "ze$ro"):
		if unset {
			S.Zero = 1e-8
			return
		}
		S.Zero = in.evalNum(p)
	case abbrev(w, "pa$rametric"):
		S.Parametric = !unset
		if !unset {
			S.Dummy = [2]string{"t", "y"}
			if S.Dummy[0] == "x" {
			}
		} else {
			S.Dummy = [2]string{"x", "y"}
		}
	case abbrev(w, "pol$ar"):
		S.Polar = !unset
		if !unset {
			S.Dummy[0] = "t"
		} else {
			S.Dummy[0] = "x"
		}
	case abbrev(w, "box$width"):
		if unset {
			S.BoxWidth = -1
			return
		}
		S.BoxWidth = -1
		if !p.atEnd() && !p.isAbbr("abs$olute") && !p.isAbbr("rel$ative") {
			S.BoxWidth = in.evalNum(p)
		}
		S.BoxAbs = true
		if p.isAbbr("rel$ative") {
			S.BoxAbs = false
			p.i++
		} else if p.isAbbr("abs$olute") {
			p.i++
		}
	case abbrev(w, "timef$mt"):
		if unset {
			S.Timefmt = "%d/%m/%y,%H:%M"
			return
		}
		S.Timefmt = in.evalStr(p)
	case abbrev(w, "xd$ata"):
		S.TimeAxis["x"] = !unset && p.isAbbr("t$ime")
		in.skipToEnd(p)
	case abbrev(w, "yd$ata"):
		S.TimeAxis["y"] = !unset && p.isAbbr("t$ime")
		in.skipToEnd(p)
	case abbrev(w, "tab$le"):
		in.closeTable()
		if unset {
			S.TableOn = false
			S.TableFile = ""
			return
		}
		S.TableOn = true
		S.TableFile = ""
		if !p.atEnd() && !p.isAbbr("sep$arator") && !p.isAbbr("app$end") {
			t := p.tok()
			if t.K == TIdent && strings.HasPrefix(t.Text, "$") {
				S.TableFile = t.Text
				p.i++
				in.datablocks[t.Text] = []string{}
				in.dbOrder = append(in.dbOrder, t.Text)
			} else {
				S.TableFile = in.evalStr(p)
			}
		}
		in.skipToEnd(p)
		in.openTable()
	case abbrev(w, "o$utput"):
		in.closeOutput()
		if unset || p.atEnd() {
			S.Output = ""
			return
		}
		S.Output = in.evalStr(p)
	case abbrev(w, "pr$int"):
		if in.printFile != nil {
			in.printFile.Close()
			in.printFile = nil
		}
		in.printOut = os.Stderr
		in.printName = ""
		if unset || p.atEnd() {
			return
		}
		name := ""
		if p.tok().K == TIdent && strings.HasPrefix(p.tok().Text, "$") {
			name = p.tok().Text
			p.i++
		} else {
			name = in.evalStr(p)
		}
		app := false
		if p.isAbbr("app$end") {
			app = true
			p.i++
		}
		in.printName = name
		if name == "-" {
			in.printOut = in.stdout
			return
		}
		if strings.HasPrefix(name, "$") {
			if !app || in.datablocks[name] == nil {
				in.datablocks[name] = []string{}
				in.dbOrder = append(in.dbOrder, name)
			}
			in.printOut = &dbWriter{in: in, name: name}
			return
		}
		flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(name, flags, 0644)
		if err != nil {
			gpErrNC("cannot open print file")
		}
		in.printFile = f
		in.printOut = f
	case abbrev(w, "k$ey"):
		if unset {
			S.KeyOn = false
			return
		}
		S.KeyOn = true
		for !p.atEnd() {
			switch {
			case p.isAbbr("t$op"):
				S.KeyVert = "top"
			case p.isAbbr("b$ottom"):
				S.KeyVert = "bottom"
			case p.isAbbr("l$eft"):
				S.KeyHoriz = "left"
			case p.isAbbr("r$ight"):
				S.KeyHoriz = "right"
			case p.isAbbr("c$enter"):
				S.KeyVert = "center"
				S.KeyHoriz = "center"
			case p.isAbbr("on"):
				S.KeyOn = true
			case p.isAbbr("off"):
				S.KeyOn = false
			case p.isAbbr("box"):
				S.KeyBox = true
			case p.isAbbr("nobox"):
				S.KeyBox = false
			case p.isAbbr("out$side"):
				S.KeyOutside = true
			case p.isAbbr("ins$ide"):
				S.KeyOutside = false
			case p.isAbbr("Left"):
				S.KeyLeftJust = true
			case p.isAbbr("Right"):
				S.KeyLeftJust = false
			case p.isAbbr("rev$erse"):
				S.KeyReverse = true
			case p.isAbbr("norev$erse"):
				S.KeyReverse = false
			case p.isAbbr("hor$izontal"):
				S.KeyHorizontal = true
			case p.isAbbr("ver$tical"):
				S.KeyHorizontal = false
			case p.isAbbr("autot$itle"):
				p.i++
				if p.isAbbr("col$umnheader") || p.isAbbr("columnhead") {
					S.KeyColHead = true
					p.i++
				}
				continue
			case p.isAbbr("noautot$itle"):
				S.KeyColHead = false
			case p.isAbbr("tit$le"):
				p.i++
				if !p.atEnd() && p.isStringStart() {
					S.KeyTitle = in.evalStr(p)
				}
				continue
			case p.isAbbr("sam$plen"):
				p.i++
				S.KeySamplen = in.evalNum(p)
				continue
			case p.isAbbr("spa$cing"):
				p.i++
				S.KeySpacing = in.evalNum(p)
				continue
			}
			p.i++
		}
	case abbrev(w, "offset$s"):
		if unset {
			S.Offsets = [4]float64{}
			return
		}
		k := 0
		for !p.atEnd() && k < 4 {
			if p.is(",") {
				p.i++
				k++
				continue
			}
			if p.isAbbr("gr$aph") || p.isAbbr("first") {
				p.i++
			}
			S.Offsets[k] = in.evalNum(p)
		}
	case abbrev(w, "si$ze"):
		if unset {
			S.SizeX, S.SizeY, S.SizeSquare = 1, 1, false
			return
		}
		for !p.atEnd() {
			if p.isAbbr("sq$uare") {
				S.SizeSquare = true
				p.i++
				continue
			}
			if p.isAbbr("nosq$uare") {
				S.SizeSquare = false
				p.i++
				continue
			}
			if p.isAbbr("ra$tio") || p.isAbbr("nora$tio") {
				in.skipToEnd(p)
				break
			}
			S.SizeX = in.evalNum(p)
			if p.is(",") {
				p.i++
				S.SizeY = in.evalNum(p)
			}
		}
	case abbrev(w, "or$igin"):
		if unset {
			S.OriginX, S.OriginY = 0, 0
			return
		}
		S.OriginX = in.evalNum(p)
		p.expect(",")
		S.OriginY = in.evalNum(p)
	case abbrev(w, "mar$gins"):
		if unset {
			S.Margins = [4]float64{-1, -1, -1, -1}
			S.MarginSet = [4]bool{}
			return
		}
		k := 0
		for !p.atEnd() && k < 4 {
			if p.is(",") {
				p.i++
				k++
				continue
			}
			S.Margins[k] = in.evalNum(p)
			S.MarginSet[k] = true
		}
	case w == "lmargin" || w == "rmargin" || w == "bmargin" || w == "tmargin":
		k := map[string]int{"lmargin": 0, "rmargin": 1, "bmargin": 2, "tmargin": 3}[w]
		if unset || p.atEnd() {
			S.Margins[k] = -1
			S.MarginSet[k] = false
			return
		}
		if p.isAbbr("at") {
			p.i++
			if p.isAbbr("sc$reen") {
				p.i++
			}
		}
		S.Margins[k] = in.evalNum(p)
		S.MarginSet[k] = true
	case abbrev(w, "poi$ntsize"), w == "ps":
		if unset {
			S.PointSize = 1
			return
		}
		S.PointSize = in.evalNum(p)
	case abbrev(w, "t$erminal"):
		if unset {
			S.Term = "unknown"
			return
		}
		in.setTerm(p)
	case abbrev(w, "dataf$ile"):
		if unset {
			S.DFSep, S.DFMissing, S.DFComment = "", "", "#"
			in.skipToEnd(p)
			return
		}
		for !p.atEnd() {
			if p.isAbbr("sep$arator") {
				p.i++
				if p.isAbbr("white$space") || p.atEnd() {
					S.DFSep = ""
					if !p.atEnd() {
						p.i++
					}
				} else if p.isAbbr("tab") {
					S.DFSep = "\t"
					p.i++
				} else if p.isAbbr("comma") {
					S.DFSep = ","
					p.i++
				} else {
					S.DFSep = in.evalStr(p)
				}
				continue
			}
			if p.isAbbr("miss$ing") {
				p.i++
				if p.atEnd() {
					S.DFMissing = ""
				} else {
					S.DFMissing = in.evalStr(p)
				}
				continue
			}
			if p.isAbbr("com$mentschars") {
				p.i++
				if p.atEnd() {
					S.DFComment = "#"
				} else {
					S.DFComment = in.evalStr(p)
				}
				continue
			}
			p.i++
		}
	case w == "fit":
		for !p.atEnd() {
			switch {
			case p.isAbbr("nolog"):
				S.FitNoLog = true
			case p.isAbbr("log$file"):
				p.i++
				S.FitNoLog = false
				if !p.atEnd() && p.isStringStart() {
					S.FitLog = in.evalStr(p)
				}
				continue
			case p.isAbbr("q$uiet"):
				S.FitQuiet = true
			case p.isAbbr("noq$uiet"):
				S.FitQuiet = false
			case p.isAbbr("err$orvariables"):
				S.FitErrVars = true
			case p.isAbbr("noerr$orvariables"):
				S.FitErrVars = false
			case p.isAbbr("cov$ariancevariables"):
				S.FitCovVars = true
			case p.isAbbr("nocov$ariancevariables"):
				S.FitCovVars = false
			case p.isAbbr("lim$it"):
				p.i++
				S.FitLimit = in.evalNum(p)
				continue
			case p.isAbbr("maxiter"):
				p.i++
				S.FitMaxIter = int(in.evalInt(p))
				continue
			case p.isAbbr("pre$scale"):
				S.FitPrescale = true
			case p.isAbbr("nopre$scale"):
				S.FitPrescale = false
			}
			p.i++
		}
	case abbrev(w, "tic$s"):
		for _, a := range []string{"x", "y", "z", "cb"} {
			_ = a
		}
		in.skipToEnd(p)
	case abbrev(w, "bor$der"):
		if unset {
			S.Border = 0
			return
		}
		S.Border = 31
		if !p.atEnd() && (p.tok().K == TNum || p.tok().K == TIdent && !isBorderOpt(p.tok().Text)) {
			S.Border = int(in.evalInt(p))
		}
		in.skipToEnd(p)
	case abbrev(w, "cl$ip"):
		in.skipToEnd(p)
	case abbrev(w, "enc$oding"):
		in.skipToEnd(p)
	case abbrev(w, "cont$ours"):
		S.Contour = !unset
		in.skipToEnd(p)
	case abbrev(w, "surf$ace"):
		S.Surface = !unset
		in.skipToEnd(p)
	case abbrev(w, "hid$den3d"):
		S.Hidden3d = !unset
		in.skipToEnd(p)
	case abbrev(w, "ticsl$evel") || abbrev(w, "xyp$lane"):
		if !unset && !p.atEnd() {
			if p.isAbbr("at") || p.isAbbr("rel$ative") {
				p.i++
			}
			S.Ticslevel = in.evalNum(p)
		}
	case abbrev(w, "lab$el"):
		in.setLabel(p, unset)
	case abbrev(w, "arr$ow"):
		in.setArrow(p, unset)
	case abbrev(w, "mu$ltiplot"):
		in.setMultiplot(p, unset)
	case abbrev(w, "bar$s") || abbrev(w, "errorbars"):
		in.skipToEnd(p)
	case abbrev(w, "dec$imalsign"), abbrev(w, "loc$ale"), abbrev(w, "mou$se"), abbrev(w, "obj$ect"), abbrev(w, "pal$ette"), abbrev(w, "colorb$ox"), abbrev(w, "cbr$ange"), abbrev(w, "linetype"), abbrev(w, "mapping"), abbrev(w, "sty$le"), abbrev(w, "auto$scale"), abbrev(w, "fontpath"), abbrev(w, "historysize"), abbrev(w, "termopt$ion"), abbrev(w, "jitter"), abbrev(w, "pm3d"), abbrev(w, "dgrid3d"), abbrev(w, "cntrp$aram"), abbrev(w, "cntrl$abel"), abbrev(w, "rr$ange"), abbrev(w, "load$path"), abbrev(w, "psdir"), abbrev(w, "minussign"), abbrev(w, "micro"), abbrev(w, "overflow"), abbrev(w, "walls"), abbrev(w, "theta"), abbrev(w, "rgbmax"), abbrev(w, "colorseq$uence"), abbrev(w, "x2zeroaxis"), abbrev(w, "zeroa$xis"), abbrev(w, "raxis"), abbrev(w, "fill"), abbrev(w, "key"), abbrev(w, "for$mat"), abbrev(w, "nonlinear"), abbrev(w, "link"), abbrev(w, "vxrange"), abbrev(w, "vyrange"), abbrev(w, "vzrange"), abbrev(w, "isosurface"), abbrev(w, "spiderplot"), abbrev(w, "paxis"), abbrev(w, "polar"), abbrev(w, "c$olor"), abbrev(w, "monochrome"), abbrev(w, "isotropic"), abbrev(w, "debug"):
		in.skipToEnd(p)
	default:
		if unset {
			gpErr(t.Pos, "Unrecognized option.  See 'help unset'.")
		}
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

func isBorderOpt(s string) bool {
	switch s {
	case "front", "back", "behind", "lt", "linetype", "lw", "linewidth", "lc", "linecolor", "dt", "dashtype", "ls", "linestyle", "polar":
		return true
	}
	return false
}

func (in *Interp) isVarOrFunc(p *P) bool {
	t := p.tok()
	if _, ok := in.vars[t.Text]; ok {
		return true
	}
	if p.peek(1).Text == "(" {
		return true
	}
	return false
}

func parseAxesWord(w string) []string {
	var out []string
	for len(w) > 0 {
		switch {
		case strings.HasPrefix(w, "x2"):
			out = append(out, "x2")
			w = w[2:]
		case strings.HasPrefix(w, "y2"):
			out = append(out, "y2")
			w = w[2:]
		case strings.HasPrefix(w, "cb"):
			out = append(out, "cb")
			w = w[2:]
		case w[0] == 'x' || w[0] == 'y' || w[0] == 'z' || w[0] == 'r':
			out = append(out, w[:1])
			w = w[1:]
		default:
			w = w[1:]
		}
	}
	return out
}

func (in *Interp) parseStyleName(p *P) string {
	t := p.tok()
	styles := []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "xerr$orbars", "yerr$orbars", "xyerr$orbars", "errorl$ines", "xerrorl$ines", "yerrorl$ines", "xyerrorl$ines", "boxes", "boxer$rorbars", "boxxy$errorbars", "fillst$eps", "filledc$urves", "labels", "vec$tors", "financebars", "candlesticks", "histograms", "image", "rgbimage", "pm3d", "circles", "ellipses", "surface", "boxplot", "zerrorfill", "parallelaxes", "table", "arrows"}
	for _, s := range styles {
		if t.K == TIdent && abbrev(t.Text, s) {
			p.i++
			n := strings.Replace(s, "$", "", 1)
			if n == "lp" {
				n = "linespoints"
			}
			return n
		}
	}
	gpErr(t.Pos, "unrecognized plot type")
	return ""
}

func (in *Interp) parseOffset(p *P, x, y *float64) {
	if p.isAbbr("off$set") {
		p.i++
		for p.isAbbr("char$acter") || p.isAbbr("gr$aph") || p.isAbbr("sc$reen") || p.isAbbr("first") {
			p.i++
		}
		*x = in.evalNum(p)
		if p.is(",") {
			p.i++
			for p.isAbbr("char$acter") || p.isAbbr("gr$aph") || p.isAbbr("sc$reen") || p.isAbbr("first") {
				p.i++
			}
			*y = in.evalNum(p)
		}
		if p.is(",") {
			p.i++
			in.evalNum(p)
		}
	}
}

func (in *Interp) setTics(p *P, ax string, unset bool) {
	ts := in.S.Tics[ax]
	if ts == nil {
		ts = &TicSpec{Scale: 1}
		in.S.Tics[ax] = ts
	}
	if unset {
		ts.On = false
		return
	}
	ts.On = true
	for !p.atEnd() {
		switch {
		case p.isAbbr("mi$rror"):
			ts.Mirror = true
			p.i++
		case p.isAbbr("nomi$rror"):
			ts.Mirror = false
			p.i++
		case p.isAbbr("out$wards"):
			ts.Out = true
			p.i++
		case p.isAbbr("in$wards"):
			ts.Out = false
			p.i++
		case p.isAbbr("rot$ate"):
			ts.Rotate = true
			p.i++
			if p.isAbbr("by") {
				p.i++
				in.evalNum(p)
			}
		case p.isAbbr("norot$ate"):
			ts.Rotate = false
			p.i++
		case p.isAbbr("auto$freq"):
			ts.Auto = true
			ts.Manual = nil
			p.i++
		case p.isAbbr("add"):
			ts.AddMode = true
			p.i++
		case p.isAbbr("sc$ale"):
			p.i++
			ts.Scale = in.evalNum(p)
			if p.is(",") {
				p.i++
				in.evalNum(p)
			}
		case p.isAbbr("form$at"):
			p.i++
			in.S.Format[ax] = in.evalStr(p)
		case p.isAbbr("off$set"):
			var a, b float64
			in.parseOffset(p, &a, &b)
		case p.isAbbr("font") || p.isAbbr("tc") || p.isAbbr("textc$olor"):
			p.i++
			for !p.atEnd() && !p.is(",") && p.tok().K != TNum {
				p.i++
			}
		case p.isAbbr("bor$der") || p.isAbbr("axis") || p.isAbbr("nobor$der") || p.isAbbr("enh$anced") || p.isAbbr("noenh$anced") || p.isAbbr("front") || p.isAbbr("back") || p.isAbbr("l$eft") || p.isAbbr("r$ight") || p.isAbbr("c$enter") || p.isAbbr("numeric") || p.isAbbr("timedate") || p.isAbbr("geographic") || p.isAbbr("nolog$scale") || p.isAbbr("log$scale"):
			p.i++
		case p.is("("):
			p.i++
			if !ts.AddMode {
				ts.Manual = nil
			}
			ts.Auto = false
			for !p.is(")") {
				mt := ManualTic{}
				if p.isStringStart() {
					mt.Label = in.evalStr(p)
					mt.HasLabel = true
				}
				mt.Pos = in.rangeVal(p)
				if !p.is(",") && !p.is(")") {
					l := in.evalInt(p)
					mt.Minor = l == 1
				}
				ts.Manual = append(ts.Manual, mt)
				if p.is(",") {
					p.i++
				}
				if p.atEnd() {
					gpErr(p.tok().Pos, "')' expected")
				}
			}
			p.i++
		default:
			// start, incr, end
			a := in.rangeVal(p)
			ts.Auto = false
			if !ts.AddMode {
				ts.Manual = nil
			}
			if p.is(",") {
				p.i++
				b := in.rangeVal(p)
				ts.Start, ts.HasStart = a, true
				ts.Step = b
				if p.is(",") {
					p.i++
					ts.End, ts.HasEnd = in.rangeVal(p), true
				} else {
					ts.HasEnd = false
				}
			} else {
				ts.Step = a
				ts.HasStart, ts.HasEnd = false, false
			}
		}
	}
	ts.AddMode = false
}

func (in *Interp) setLabel(p *P, unset bool) {
	S := in.S
	tag := 0
	if !p.atEnd() && p.tok().K == TNum {
		tag = int(in.evalInt(p))
	}
	if unset {
		if tag == 0 {
			S.LabelsList = nil
			return
		}
		for i, l := range S.LabelsList {
			if l.Tag == tag {
				S.LabelsList = append(S.LabelsList[:i], S.LabelsList[i+1:]...)
				break
			}
		}
		return
	}
	var lab *UserLabel
	if tag != 0 {
		for _, l := range S.LabelsList {
			if l.Tag == tag {
				lab = l
			}
		}
	} else {
		tag = 1
		for _, l := range S.LabelsList {
			if l.Tag >= tag {
				tag = l.Tag + 1
			}
		}
	}
	if lab == nil {
		lab = &UserLabel{Tag: tag, Just: "left", Coord: "first"}
		S.LabelsList = append(S.LabelsList, lab)
		sort.Slice(S.LabelsList, func(i, j int) bool { return S.LabelsList[i].Tag < S.LabelsList[j].Tag })
	}
	if !p.atEnd() && p.isStringStart() {
		lab.Text = in.evalStr(p)
	}
	for !p.atEnd() {
		switch {
		case p.isAbbr("at"):
			p.i++
			lab.Coord = "first"
			if p.isAbbr("gr$aph") || p.isAbbr("sc$reen") || p.isAbbr("first") || p.isAbbr("char$acter") {
				lab.Coord = strings.TrimSuffix(p.tok().Text, "")
				if abbrev(p.tok().Text, "gr$aph") {
					lab.Coord = "graph"
				} else if abbrev(p.tok().Text, "sc$reen") {
					lab.Coord = "screen"
				}
				p.i++
			}
			lab.X = in.rangeVal(p)
			p.expect(",")
			if p.isAbbr("gr$aph") || p.isAbbr("sc$reen") || p.isAbbr("first") {
				p.i++
			}
			lab.Y = in.rangeVal(p)
			if p.is(",") {
				p.i++
				in.evalNum(p)
			}
		case p.isAbbr("l$eft"):
			lab.Just = "left"
			p.i++
		case p.isAbbr("r$ight"):
			lab.Just = "right"
			p.i++
		case p.isAbbr("c$entre") || p.isAbbr("c$enter"):
			lab.Just = "center"
			p.i++
		case p.isAbbr("po$int"):
			lab.Point = true
			p.i++
		case p.isAbbr("front"):
			lab.Front = true
			p.i++
		default:
			p.i++
		}
	}
}

func (in *Interp) setArrow(p *P, unset bool) {
	S := in.S
	tag := 0
	if !p.atEnd() && p.tok().K == TNum {
		tag = int(in.evalInt(p))
	}
	if unset {
		if tag == 0 {
			S.Arrows = nil
		}
		for i, a := range S.Arrows {
			if a.Tag == tag {
				S.Arrows = append(S.Arrows[:i], S.Arrows[i+1:]...)
				break
			}
		}
		return
	}
	if tag == 0 {
		tag = 1
		for _, a := range S.Arrows {
			if a.Tag >= tag {
				tag = a.Tag + 1
			}
		}
	}
	ar := &UserArrow{Tag: tag, Head: true}
	for !p.atEnd() {
		switch {
		case p.isAbbr("fr$om"):
			p.i++
			ar.Coord1 = in.coordSys(p)
			ar.X1 = in.rangeVal(p)
			p.expect(",")
			in.coordSys(p)
			ar.Y1 = in.rangeVal(p)
		case p.isAbbr("to") || p.isAbbr("rto"):
			ar.Rel = p.tok().Text == "rto"
			p.i++
			ar.Coord2 = in.coordSys(p)
			ar.X2 = in.rangeVal(p)
			p.expect(",")
			in.coordSys(p)
			ar.Y2 = in.rangeVal(p)
		case p.isAbbr("noh$ead"):
			ar.Head = false
			p.i++
		default:
			p.i++
		}
	}
	S.Arrows = append(S.Arrows, ar)
}

func (in *Interp) coordSys(p *P) string {
	for _, c := range []string{"first", "second", "gr$aph", "sc$reen", "char$acter"} {
		if p.isAbbr(c) {
			p.i++
			return strings.Replace(c, "$", "", 1)
		}
	}
	return "first"
}

func (in *Interp) setTerm(p *P) {
	S := in.S
	if p.atEnd() {
		return
	}
	t := p.tok()
	switch {
	case abbrev(t.Text, "du$mb"):
		p.i++
		S.Term = "dumb"
		for !p.atEnd() {
			if p.isAbbr("si$ze") {
				p.i++
				S.TermW = int(in.evalInt(p))
				if p.is(",") {
					p.i++
					S.TermH = int(in.evalInt(p))
				}
				continue
			}
			if p.isAbbr("feed") {
				S.DumbFeed = true
			} else if p.isAbbr("nofeed") {
				S.DumbFeed = false
			} else if p.tok().K == TNum {
				S.TermW = int(in.evalInt(p))
				if p.is(",") {
					p.i++
					S.TermH = int(in.evalInt(p))
				}
				continue
			} else if p.isAbbr("aspect") {
				p.i++
				S.DumbAspect[0] = int(in.evalInt(p))
				if p.is(",") {
					p.i++
					S.DumbAspect[1] = int(in.evalInt(p))
				}
				continue
			}
			p.i++
		}
	case abbrev(t.Text, "svg"):
		p.i++
		S.Term = "svg"
		for !p.atEnd() {
			if p.isAbbr("si$ze") {
				p.i++
				S.SvgW = int(in.evalInt(p))
				p.expect(",")
				S.SvgH = int(in.evalInt(p))
				continue
			}
			p.i++
		}
	case abbrev(t.Text, "canvas"):
		p.i++
		S.Term = "canvas"
		for !p.atEnd() {
			if p.isAbbr("si$ze") {
				p.i++
				S.CanvasW = int(in.evalInt(p))
				p.expect(",")
				S.CanvasH = int(in.evalInt(p))
				continue
			}
			p.i++
		}
	case abbrev(t.Text, "unknown"), abbrev(t.Text, "push"), abbrev(t.Text, "pop"):
		p.i++
		if abbrev(t.Text, "unknown") {
			S.Term = "unknown"
		}
	default:
		gpErr(t.Pos, "unknown or ambiguous terminal type; type just 'set terminal' for a list")
	}
	in.sv("GPVAL_TERM", StrV(S.Term))
}

// --- show ---

func fmtRangeVal(v float64) string {
	return cfmt("%#g", v)
}

func (in *Interp) showRange(w io.Writer, ax string) {
	r := in.S.Ranges[ax]
	lo, hi := "*", "*"
	if !r.AutoMin {
		lo = fmtRangeVal(r.Min)
	}
	if !r.AutoMax {
		hi = fmtRangeVal(r.Max)
	}
	rev := "noreverse"
	if r.Reverse {
		rev = "reverse"
	}
	wb := "nowriteback"
	if r.Writeback {
		wb = "writeback"
	}
	fmt.Fprintf(w, "\tset %srange [ %s : %s ] %s %s", ax, lo, hi, rev, wb)
	if r.AutoMin || r.AutoMax {
		fmt.Fprintf(w, "  # (currently [%s:%s] )", fmtRangeVal(r.CurMin), fmtRangeVal(r.CurMax))
	}
	fmt.Fprintf(w, "\n")
}

func (in *Interp) showCmd(p *P) {
	S := in.S
	var b strings.Builder
	w := &b
	defer func() {
		in.flushOut()
		os.Stderr.WriteString(b.String())
	}()
	t := p.tok()
	if t.K != TIdent {
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
	word := t.Text
	p.i++
	if ax, kind := axisOf(word); ax != "" {
		switch kind {
		case "range":
			fmt.Fprintln(w)
			in.showRange(w, ax)
			fmt.Fprintln(w)
			return
		case "label":
			l := S.Labels[ax]
			fmt.Fprintln(w)
			fmt.Fprintf(w, "\t%slabel is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", ax, l.Text, fmtG(l.OffX), fmtG(l.OffY))
			return
		case "data":
			fmt.Fprintln(w)
			if S.TimeAxis[ax] {
				fmt.Fprintf(w, "\t%s is set to time\n", ax)
			} else {
				fmt.Fprintf(w, "\t%s is set to numerical\n", ax)
			}
			fmt.Fprintln(w)
			return
		}
	}
	switch {
	case abbrev(word, "sa$mples"):
		fmt.Fprintf(w, "\n\tsampling rate is %d, %d\n\n", S.Samples1, S.Samples2)
	case abbrev(word, "iso$samples"):
		fmt.Fprintf(w, "\n\tiso sampling rate is %d, %d\n\n", S.Iso1, S.Iso2)
	case abbrev(word, "t$itle"):
		fmt.Fprintf(w, "\n\ttitle is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", S.Title.Text, fmtG(S.Title.OffX), fmtG(S.Title.OffY))
	case abbrev(word, "st$yle"):
		if p.isAbbr("d$ata") {
			p.i++
			fmt.Fprintf(w, "\n\tData are plotted with %s\n\n", S.StyleData)
		} else if p.isAbbr("f$unction") {
			p.i++
			fmt.Fprintf(w, "\n\tFunctions are plotted with %s\n\n", S.StyleFunc)
		} else {
			in.skipToEnd(p)
			fmt.Fprintf(w, "\n\tData are plotted with %s\n\n\tFunctions are plotted with %s\n\n", S.StyleData, S.StyleFunc)
		}
	case abbrev(word, "lo$gscale"):
		fmt.Fprintf(w, "\n\tlogscaling on ")
		any := false
		for _, a := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			if base, ok := S.Log[a]; ok {
				any = true
				if base == 10 {
					fmt.Fprintf(w, " %s", a)
				} else {
					fmt.Fprintf(w, " %s (base %s)", a, fmtG(base))
				}
			}
		}
		if !any {
			fmt.Fprintf(w, "none")
		}
		fmt.Fprintf(w, "\n\n")
	case abbrev(word, "form$at"):
		fmt.Fprintf(w, "\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			fmt.Fprintf(w, "\t  %s-axis: \"%s\"\n", a, S.Format[a])
		}
		fmt.Fprintln(w)
	case abbrev(word, "g$rid"):
		if !S.Grid {
			fmt.Fprintf(w, "\n\tgrid is OFF\n\n")
		} else {
			fmt.Fprintf(w, "\n\tRectangular grid drawn at x y tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case abbrev(word, "an$gles"):
		if in.degrees {
			fmt.Fprintf(w, "\n\tAngles are in degrees\n\n")
		} else {
			fmt.Fprintf(w, "\n\tAngles are in radians\n\n")
		}
	case abbrev(word, "du$mmy"):
		fmt.Fprintf(w, "\n\tdummy variables are %s %s \n\n", S.Dummy[0], S.Dummy[1])
	case abbrev(word, "vi$ew"):
		fmt.Fprintf(w, "\n\tview is %s rot_x, %s rot_z, %s scale, %s scale_z\n\t\t axes are independently scaled\n\t\t azimuth 0\n\n", fmtG(S.View[0]), fmtG(S.View[1]), fmtG(S.View[2]), fmtG(S.View[3]))
	case abbrev(word, "ze$ro"):
		fmt.Fprintf(w, "\n\tzero is %s\n\n", fmtG(S.Zero))
	case abbrev(word, "pa$rametric"):
		fmt.Fprintf(w, "\n\tparametric is %s\n\n", onoff(S.Parametric))
	case abbrev(word, "pol$ar"):
		fmt.Fprintf(w, "\n\tpolar is %s\n\n", onoff(S.Polar))
	case abbrev(word, "box$width"):
		if S.BoxWidth < 0 {
			fmt.Fprintf(w, "\n\tboxwidth is auto\n\tboxdepth is 0\n\n")
		} else if S.BoxAbs {
			fmt.Fprintf(w, "\n\tboxwidth is %s absolute\n\tboxdepth is 0\n\n", fmtG(S.BoxWidth))
		} else {
			fmt.Fprintf(w, "\n\tboxwidth is %s relative\n\tboxdepth is 0\n\n", fmtG(S.BoxWidth))
		}
	case abbrev(word, "timef$mt"):
		fmt.Fprintf(w, "\n\tDefault format for reading time data is \"%s\"\n\n", S.Timefmt)
	case abbrev(word, "tab$le"):
		if S.TableOn {
			fmt.Fprintf(w, "\n\ttable mode is on, field separator tab\n\n")
		} else {
			fmt.Fprintf(w, "\n\ttable mode is off\n\n")
		}
	case abbrev(word, "o$utput"):
		if S.Output == "" {
			fmt.Fprintf(w, "\n\toutput is sent to STDOUT\n\n")
		} else {
			fmt.Fprintf(w, "\n\toutput is sent to '%s'\n\n", S.Output)
		}
	case abbrev(word, "pr$int"):
		n := in.printName
		if n == "" {
			n = "<stderr>"
		} else if n == "-" {
			n = "<stdout>"
		}
		fmt.Fprintf(w, "\n\tprint output is sent to '%s'\n\n", n)
	case abbrev(word, "k$ey"):
		if !S.KeyOn {
			fmt.Fprintf(w, "\n\tkey is OFF\n\n")
			return
		}
		pos := S.KeyVert + " " + S.KeyHoriz
		if S.KeyVert == "center" && S.KeyHoriz == "center" {
			pos = "center"
		}
		dir := "vertical"
		if S.KeyHorizontal {
			dir = "horizontal"
		}
		fmt.Fprintf(w, "\n\tkey is ON, position: %s %s fixed  offset: (character 0, 0)\n", pos, dir)
		just := "right"
		if S.KeyLeftJust {
			just = "left"
		}
		rev := "not reversed"
		if S.KeyReverse {
			rev = "reversed"
		}
		box := "not boxed"
		if S.KeyBox {
			box = "boxed\n\twith  lt black linewidth 1.000 dashtype solid"
		}
		fmt.Fprintf(w, "\tkey is %s justified, %s, not inverted, enhanced and %s\n", just, rev, box)
		fmt.Fprintf(w, "\tsample length is %s characters\n\tvertical spacing is %s characters\n\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n\n\tkey title is \"%s\" center justified \n\n", fmtG(S.KeySamplen), fmtG(S.KeySpacing), S.KeyTitle)
	case abbrev(word, "offset$s"):
		fmt.Fprintf(w, "\n\toffsets are %s, %s, %s, %s\n\n", fmtG(S.Offsets[0]), fmtG(S.Offsets[1]), fmtG(S.Offsets[2]), fmtG(S.Offsets[3]))
	case abbrev(word, "si$ze"):
		fmt.Fprintf(w, "\n\tsize is scaled by %s,%s\n", fmtG(S.SizeX), fmtG(S.SizeY))
		if S.SizeSquare {
			fmt.Fprintf(w, "\tTry to set aspect ratio to 1:1.0\n\n")
		} else {
			fmt.Fprintf(w, "\tNo attempt to control aspect ratio\n\n")
		}
	case abbrev(word, "or$igin"):
		fmt.Fprintf(w, "\n\torigin is set to %s,%s\n\n", fmtG(S.OriginX), fmtG(S.OriginY))
	case abbrev(word, "mar$gins"):
		fmt.Fprintln(w)
		for k, n := range []string{"lmargin", "rmargin", "bmargin", "tmargin"} {
			if S.MarginSet[k] {
				fmt.Fprintf(w, "\t%s is set to %s\n", n, fmtG(S.Margins[k]))
			} else {
				fmt.Fprintf(w, "\t%s is computed automatically\n", n)
			}
		}
		fmt.Fprintln(w)
	case abbrev(word, "poi$ntsize"):
		fmt.Fprintf(w, "\n\tpointsize is %s\n\n", fmtG(S.PointSize))
	case abbrev(word, "t$erminal"):
		fmt.Fprintf(w, "\n   terminal type is %s\n\n", in.termDesc())
	case abbrev(word, "dataf$ile"):
		fmt.Fprintln(w)
		if S.DFMissing == "" {
			fmt.Fprintf(w, "\tNo missing data string set for datafile\n")
		} else {
			fmt.Fprintf(w, "\t\"%s\" in datafile is interpreted as missing value\n", S.DFMissing)
		}
		if S.DFSep == "" {
			fmt.Fprintf(w, "\tdatafile fields separated by whitespace\n")
		} else {
			fmt.Fprintf(w, "\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.DFSep), S.DFSep)
		}
		fmt.Fprintf(w, "\tComments chars are \"%s\"\n", S.DFComment)
		fmt.Fprintf(w, "\tFirst line is treated as headers only if accessed explicitly\n\n")
	case abbrev(word, "v$ariables"):
		all := false
		if p.isAbbr("all") {
			all = true
			p.i++
		}
		in.showVariables(w, all)
	case abbrev(word, "fu$nctions"):
		fmt.Fprintf(w, "\n\tUser-Defined Functions:\n")
		for _, n := range in.funcOrder() {
			fmt.Fprintf(w, "\t%s\n", in.funcs[n].Text)
		}
		fmt.Fprintln(w)
	case abbrev(word, "ver$sion"):
		fmt.Fprintf(w, "\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		in.skipToEnd(p)
	case abbrev(word, "cont$ours"):
		if S.Contour {
			fmt.Fprintf(w, "\n\tcontour for surfaces are drawn\n\n")
		} else {
			fmt.Fprintf(w, "\n\tcontour for surfaces are not drawn\n\n")
		}
	case abbrev(word, "surf$ace"):
		if S.Surface {
			fmt.Fprintf(w, "\n\tsurface is drawn \n\n")
		} else {
			fmt.Fprintf(w, "\n\tsurface is not drawn\n\n")
		}
	case abbrev(word, "map$ping"):
		fmt.Fprintf(w, "\n\tmapping for 3-d data is cartesian\n\n")
	case abbrev(word, "enc$oding"):
		fmt.Fprintf(w, "\n\tnominal character encoding is utf8\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case abbrev(word, "mxt$ics"):
		fmt.Fprintf(w, "\tminor xtics are off for linear scales\n\tminor xtics are computed automatically for log scales\n")
	case abbrev(word, "bor$der"):
		if S.Border == 0 {
			fmt.Fprintf(w, "\n\tborder is not drawn\n\n")
		} else {
			fmt.Fprintf(w, "\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.Border, S.Border)
		}
	case abbrev(word, "fit"):
		fmt.Fprintln(w)
		if S.FitQuiet {
			fmt.Fprintf(w, "\tfit will not output results to console.\n")
		} else {
			fmt.Fprintf(w, "\tfit will output brief results to console and log-file.\n")
		}
		fmt.Fprintf(w, "\tfit can handle up to 12 independent variables\n")
		if S.FitPrescale {
			fmt.Fprintf(w, "\tfit will prescale parameters by their initial values\n")
		} else {
			fmt.Fprintf(w, "\tfit will not prescale parameters by their initial values\n")
		}
		if S.FitErrVars {
			fmt.Fprintf(w, "\tfit will place parameter errors in variables\n")
		} else {
			fmt.Fprintf(w, "\tfit will not place parameter errors in variables\n")
		}
		if S.FitCovVars {
			fmt.Fprintf(w, "\tfit will place covariances in variables\n")
		} else {
			fmt.Fprintf(w, "\tfit will not place covariances in variables\n")
		}
		fmt.Fprintf(w, "\tfit will scale parameter errors with the reduced chi square\n")
		if S.FitNoLog {
			fmt.Fprintf(w, "\tfit will not create a log file\n")
		} else if S.FitLog != "" {
			fmt.Fprintf(w, "\tlog-file for fits was set by the user to \n\t'%s'\n", S.FitLog)
		} else {
			fmt.Fprintf(w, "\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
		}
		fmt.Fprintf(w, "\tfits will be considered to have converged if  delta chisq < chisq * %s\n", fmtG(S.FitLimit))
		if S.FitMaxIter > 0 {
			fmt.Fprintf(w, "\tfit will stop after a maximum of %d iterations\n", S.FitMaxIter)
		} else {
			fmt.Fprintf(w, "\tfit has no limit in the number of iterations\n")
		}
		fmt.Fprintf(w, "\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
	case abbrev(word, "auto$scale"):
		fmt.Fprintf(w, "\n\tautoscaling is \tx: %s, \ty: %s, \n\t               \tx2: %s, \ty2: %s, \n\t               \tz: %s, \tcb: %s, \n", autoS(S.Ranges["x"]), autoS(S.Ranges["y"]), autoS(S.Ranges["x2"]), autoS(S.Ranges["y2"]), autoS(S.Ranges["z"]), autoS(S.Ranges["cb"]))
	case abbrev(word, "cl$ip"):
		fmt.Fprintf(w, "\n\tpoint clip is OFF\n\tclipping lines with one end out of range (clip one)\n\tnot drawing lines with both ends out of range (clip two)\n\tnot clipping lines on polar plot at maximum radius\n\n")
	case abbrev(word, "lab$el"):
		fmt.Fprintln(w)
		for _, l := range S.LabelsList {
			fmt.Fprintf(w, "\tlabel %d \"%s\" at %s %s, %s %s, %s %s %s not rotated back lt black norotate\n", l.Tag, l.Text, l.Coord, fmtG(l.X), l.Coord, fmtG(l.Y), l.Coord, "0", l.Just)
		}
		fmt.Fprintln(w)
	case abbrev(word, "arr$ow"), abbrev(word, "obj$ect"):
		fmt.Fprintln(w)
		fmt.Fprintln(w)
	case abbrev(word, "pal$ette"):
		fmt.Fprintf(w, "\tpalette is COLOR\n\trgb color mapping by rgbformulae are 7,5,15\n\tfigure is POSITIVE\n\tall color formulae ARE NOT written into output postscript file\n\tallocating ALL remaining color positions for discrete palette terminals\n\tColor-Model: RGB\n\tgamma is 1.5\n")
	case abbrev(word, "hid$den3d"):
		fmt.Fprintf(w, "\n\thidden surface is drawn\n\t  Hidden3d elements will be drawn in back of non-hidden3d elements\n\t  Back side of surfaces has linestyle offset of 1\n\t  Bit-Mask of Lines to draw in each triangle is 3\n\t  1: Outranged and undefined datapoints are omitted from the surface.\n\t  Will use other diagonal if it gives a less jaggy outline\n\t  Will draw diagonal visibly if quadrangle is 'bent over'\n\n")
	case abbrev(word, "loc$ale"):
		fmt.Fprintf(w, "\n\tgnuplot LC_CTYPE   C.UTF-8\n\tgnuplot encoding   utf8\n\tgnuplot LC_TIME    C.UTF-8\n\tgnuplot LC_NUMERIC C\n\n")
	case abbrev(word, "dec$imalsign"):
		fmt.Fprintf(w, "\n\tdecimalsign for input is  . \n\tdecimalsign for output has default value (normally '.')\n\tdegree sign for output is ° \n\n")
	case abbrev(word, "bar$s"):
		fmt.Fprintf(w, "set errorbars front 1.000000 \n")
	case abbrev(word, "colorb$ox"):
		fmt.Fprintf(w, "\tcolor box with border, DEFAULT line type is drawn front\n\tat DEFAULT position\n\tcolor gradient is vertical \n")
	case abbrev(word, "rax$is"):
		fmt.Fprintf(w, "\traxis is not drawn\n")
	case abbrev(word, "load$path"):
		fmt.Fprintf(w, "\n\tloadpath is empty\n\tgnuplotrc is read from /usr/local/share/gnuplot/5.4\n\n")
	case abbrev(word, "mu$ltiplot"):
		fmt.Fprintf(w, "\n\tmultiplot mode is %s\n\n", map[bool]string{true: "on", false: "off"}[S.Multiplot])
	case abbrev(word, "all"):
		in.skipToEnd(p)
	default:
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
}

func autoS(r *Range) string {
	if r.AutoMin && r.AutoMax {
		return "ON"
	}
	if r.AutoMin {
		return "Min"
	}
	if r.AutoMax {
		return "Max"
	}
	return "OFF"
}

func onoff(b bool) string {
	if b {
		return "ON"
	}
	return "OFF"
}

func fmtG(f float64) string {
	return cfmt("%g", f)
}

func (in *Interp) termDesc() string {
	S := in.S
	switch S.Term {
	case "dumb":
		feed := "feed"
		if !S.DumbFeed {
			feed = "nofeed"
		}
		return fmt.Sprintf("dumb %s  size %d, %d aspect %d, %d mono", feed, S.TermW, S.TermH, S.DumbAspect[0], S.DumbAspect[1])
	case "svg":
		return fmt.Sprintf("svg size %d,%d fixed enhanced font 'Arial,12' butt dashlength 1.0 ", S.SvgW, S.SvgH)
	case "canvas":
		return fmt.Sprintf("canvas  rounded size %d,%d enhanced fsize 10 lw 1 fontscale 1 standalone", S.CanvasW, S.CanvasH)
	}
	return "unknown "
}

func (in *Interp) funcOrder() []string {
	var names []string
	for n := range in.funcs {
		names = append(names, n)
	}
	sort.Slice(names, func(i, j int) bool { return in.funcSeq[names[i]] < in.funcSeq[names[j]] })
	return names
}

func (in *Interp) showVariables(w io.Writer, all bool) {
	if all {
		fmt.Fprintf(w, "\n\tAll available variables:\n")
	} else {
		fmt.Fprintf(w, "\n\tUser and default variables:\n")
	}
	for _, n := range in.varOrderList() {
		if !all && strings.HasPrefix(n, "GPVAL_") {
			continue
		}
		v := in.vars[n]
		var s string
		switch v.K {
		case KStr:
			s = "\"" + v.S + "\""
		case KArr:
			s = fmt.Sprintf("<%d element array>", len(*v.Arr)-1)
		default:
			s = v.PrintString()
		}
		fmt.Fprintf(w, "\t%s = %s\n", n, s)
	}
	fmt.Fprintln(w)
}

type dbWriter struct {
	in   *Interp
	name string
	buf  string
}

func (d *dbWriter) Write(b []byte) (int, error) {
	d.buf += string(b)
	for {
		i := strings.IndexByte(d.buf, '\n')
		if i < 0 {
			break
		}
		d.in.datablocks[d.name] = append(d.in.datablocks[d.name], d.buf[:i])
		d.buf = d.buf[i+1:]
	}
	return len(b), nil
}
