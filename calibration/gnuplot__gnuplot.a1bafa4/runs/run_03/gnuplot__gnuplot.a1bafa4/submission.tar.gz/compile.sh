#!/bin/sh
cd "$(dirname "$0")"
export GOFLAGS=-mod=mod GOPROXY=off GOTOOLCHAIN=local CGO_ENABLED=0
[ -f go.mod ] || printf 'module gp\n\ngo 1.24\n' > go.mod
go build -o executable . 
