package main

import (
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strings"
	"time"
)

type Builtin struct {
	nargs int // -1 variadic
	fn    func(in *Interp, a []Value) Value
}

var builtins map[string]Builtin

func angIn(in *Interp, x float64) float64 {
	if in.degrees {
		return x * math.Pi / 180
	}
	return x
}
func angOut(in *Interp, x float64) float64 {
	if in.degrees {
		return x * 180 / math.Pi
	}
	return x
}

func checkF(in *Interp, r float64) Value {
	if math.IsInf(r, 0) || math.IsNaN(r) {
		in.undef = true
	}
	return FloatV(r)
}

func mathF(f func(float64) float64) Builtin {
	return Builtin{1, func(in *Interp, a []Value) Value {
		x := a[0].num()
		return checkF(in, f(x.Float()))
	}}
}

func cplxRes(in *Interp, c complex128) Value {
	if imag(c) == 0 {
		return checkF(in, real(c))
	}
	if cmplx.IsInf(c) || cmplx.IsNaN(c) {
		in.undef = true
	}
	return CmplxV(real(c), imag(c))
}

func argStr(a Value, fname string) string {
	if a.K != KStr {
		gpErrNC(fname + " needs string argument")
	}
	return a.S
}

func init() {
	builtins = map[string]Builtin{
		"sin": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx {
				return cplxRes(in, cmplx.Sin(complex(x.Re, x.Im)))
			}
			return checkF(in, math.Sin(angIn(in, x.Float())))
		}},
		"cos": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx {
				return cplxRes(in, cmplx.Cos(complex(x.Re, x.Im)))
			}
			return checkF(in, math.Cos(angIn(in, x.Float())))
		}},
		"tan": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			return checkF(in, math.Tan(angIn(in, x.Float())))
		}},
		"asin": {1, func(in *Interp, a []Value) Value {
			x := a[0].num().Float()
			if x > 1 || x < -1 {
				return cplxRes(in, cmplx.Asin(complex(x, 0)))
			}
			return checkF(in, angOut(in, math.Asin(x)))
		}},
		"acos": {1, func(in *Interp, a []Value) Value {
			x := a[0].num().Float()
			if x > 1 || x < -1 {
				return cplxRes(in, cmplx.Acos(complex(x, 0)))
			}
			return checkF(in, angOut(in, math.Acos(x)))
		}},
		"atan": {1, func(in *Interp, a []Value) Value {
			return checkF(in, angOut(in, math.Atan(a[0].num().Float())))
		}},
		"atan2": {2, func(in *Interp, a []Value) Value {
			return checkF(in, angOut(in, math.Atan2(a[0].num().Float(), a[1].num().Float())))
		}},
		"sinh":  mathF(math.Sinh),
		"cosh":  mathF(math.Cosh),
		"tanh":  mathF(math.Tanh),
		"asinh": mathF(math.Asinh),
		"acosh": mathF(math.Acosh),
		"atanh": mathF(math.Atanh),
		"exp": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx {
				return cplxRes(in, cmplx.Exp(complex(x.Re, x.Im)))
			}
			return checkF(in, math.Exp(x.Float()))
		}},
		"log": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx || x.Float() < 0 {
				return cplxRes(in, cmplx.Log(complex(x.Float(), x.Imag())))
			}
			return checkF(in, math.Log(x.Float()))
		}},
		"log10": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx || x.Float() < 0 {
				return cplxRes(in, cmplx.Log10(complex(x.Float(), x.Imag())))
			}
			return checkF(in, math.Log10(x.Float()))
		}},
		"sqrt": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KCmplx || x.Float() < 0 {
				return CmplxV(real(cmplx.Sqrt(complex(x.Float(), x.Imag()))), imag(cmplx.Sqrt(complex(x.Float(), x.Imag()))))
			}
			return checkF(in, math.Sqrt(x.Float()))
		}},
		"abs": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			switch x.K {
			case KInt:
				if x.I < 0 {
					return IntV(-x.I)
				}
				return x
			case KCmplx:
				return FloatV(math.Hypot(x.Re, x.Im))
			}
			return FloatV(math.Abs(x.Re))
		}},
		"sgn": {1, func(in *Interp, a []Value) Value {
			x := a[0].num().Float()
			if x > 0 {
				return IntV(1)
			} else if x < 0 {
				return IntV(-1)
			}
			return IntV(0)
		}},
		"int": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KInt {
				return x
			}
			f := x.Float()
			if math.IsNaN(f) || math.IsInf(f, 0) || math.Abs(f) >= 9.2233720368547758e18 {
				in.undef = true
				return FloatV(math.NaN())
			}
			return IntV(int64(f))
		}},
		"floor": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KInt {
				return x
			}
			f := math.Floor(x.Float())
			if math.Abs(f) >= 9.2233720368547758e18 || math.IsNaN(f) {
				return FloatV(f)
			}
			return IntV(int64(f))
		}},
		"ceil": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KInt {
				return x
			}
			f := math.Ceil(x.Float())
			if math.Abs(f) >= 9.2233720368547758e18 || math.IsNaN(f) {
				return FloatV(f)
			}
			return IntV(int64(f))
		}},
		"round": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			if x.K == KInt {
				return x
			}
			return IntV(int64(math.Round(x.Float())))
		}},
		"real": {1, func(in *Interp, a []Value) Value { return FloatV(a[0].num().Float()) }},
		"imag": {1, func(in *Interp, a []Value) Value { return FloatV(a[0].num().Imag()) }},
		"arg": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			return FloatV(angOut(in, math.Atan2(x.Imag(), x.Float())))
		}},
		"conj": {1, func(in *Interp, a []Value) Value {
			x := a[0].num()
			return CmplxV(x.Float(), -x.Imag())
		}},
		"gamma": mathF(math.Gamma),
		"lgamma": mathF(func(x float64) float64 {
			r, _ := math.Lgamma(x)
			return r
		}),
		"erf":  mathF(math.Erf),
		"erfc": mathF(math.Erfc),
		"inverf": mathF(func(x float64) float64 {
			return math.Erfinv(x)
		}),
		"norm": mathF(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": mathF(func(x float64) float64 {
			if x <= 0 || x >= 1 {
				return math.NaN()
			}
			return -math.Sqrt2 * math.Erfcinv(2*x)
		}),
		"besj0": mathF(math.J0),
		"besj1": mathF(math.J1),
		"besy0": mathF(math.Y0),
		"besy1": mathF(math.Y1),
		"besjn": {2, func(in *Interp, a []Value) Value {
			return checkF(in, math.Jn(int(toInt(a[0])), a[1].num().Float()))
		}},
		"besyn": {2, func(in *Interp, a []Value) Value {
			return checkF(in, math.Yn(int(toInt(a[0])), a[1].num().Float()))
		}},
		"lambertw": mathF(lambertw),
		"igamma": {2, func(in *Interp, a []Value) Value {
			return checkF(in, igamma(a[0].num().Float(), a[1].num().Float()))
		}},
		"ibeta": {3, func(in *Interp, a []Value) Value {
			return checkF(in, ibeta(a[0].num().Float(), a[1].num().Float(), a[2].num().Float()))
		}},
		"rand": {1, func(in *Interp, a []Value) Value {
			x := toInt(a[0])
			if x < 0 {
				in.rngSeed(1)
			} else if x > 0 {
				in.rngSeed(x)
			}
			return FloatV(in.rngNext())
		}},
		"strlen": {1, func(in *Interp, a []Value) Value {
			return IntV(int64(len([]rune(argStr(a[0], "strlen")))))
		}},
		"strstrt": {2, func(in *Interp, a []Value) Value {
			s := argStr(a[0], "strstrt")
			t := argStr(a[1], "strstrt")
			i := strings.Index(s, t)
			if i < 0 {
				return IntV(0)
			}
			return IntV(int64(len([]rune(s[:i])) + 1))
		}},
		"substr": {3, func(in *Interp, a []Value) Value {
			s := []rune(argStr(a[0], "substr"))
			b := toInt(a[1])
			e := toInt(a[2])
			if b < 1 {
				b = 1
			}
			if e > int64(len(s)) {
				e = int64(len(s))
			}
			if b > e {
				return StrV("")
			}
			return StrV(string(s[b-1 : e]))
		}},
		"words": {1, func(in *Interp, a []Value) Value {
			return IntV(int64(len(gpWords(argStr(a[0], "words")))))
		}},
		"word": {2, func(in *Interp, a []Value) Value {
			w := gpWords(argStr(a[0], "word"))
			i := toInt(a[1])
			if i < 1 || i > int64(len(w)) {
				return StrV("")
			}
			return StrV(w[i-1])
		}},
		"trim": {1, func(in *Interp, a []Value) Value {
			return StrV(strings.Trim(argStr(a[0], "trim"), " \t\n\r\f\v"))
		}},
		"strftime": {2, func(in *Interp, a []Value) Value {
			f := argStr(a[0], "strftime")
			return StrV(gpStrftime(f, a[1].num().Float()))
		}},
		"strptime": {2, func(in *Interp, a []Value) Value {
			f := argStr(a[0], "strptime")
			s := argStr(a[1], "strptime")
			t, ok := gpStrptime(f, s)
			if !ok {
				in.undef = true
				return FloatV(math.NaN())
			}
			return FloatV(t)
		}},
		"time": {1, func(in *Interp, a []Value) Value {
			now := float64(time.Now().UnixNano()) / 1e9
			if a[0].K == KStr {
				return StrV(gpStrftime(a[0].S, now))
			}
			if a[0].K == KInt {
				return IntV(int64(now))
			}
			return FloatV(now)
		}},
		"tm_sec":  tmF(func(t time.Time) int64 { return int64(t.Second()) }),
		"tm_min":  tmF(func(t time.Time) int64 { return int64(t.Minute()) }),
		"tm_hour": tmF(func(t time.Time) int64 { return int64(t.Hour()) }),
		"tm_mday": tmF(func(t time.Time) int64 { return int64(t.Day()) }),
		"tm_mon":  tmF(func(t time.Time) int64 { return int64(t.Month()) - 1 }),
		"tm_year": tmF(func(t time.Time) int64 { return int64(t.Year()) }),
		"tm_wday": tmF(func(t time.Time) int64 { return int64(t.Weekday()) }),
		"tm_yday": tmF(func(t time.Time) int64 { return int64(t.YearDay()) - 1 }),
		"sprintf": {-1, func(in *Interp, a []Value) Value {
			if len(a) == 0 {
				gpErrNC("sprintf: no format")
			}
			return StrV(gpSprintf(argStr(a[0], "sprintf"), a[1:]))
		}},
		"gprintf": {2, func(in *Interp, a []Value) Value {
			return StrV(gprintf(in, argStr(a[0], "gprintf"), a[1].num().Float()))
		}},
		"system": {1, func(in *Interp, a []Value) Value {
			s := argStr(a[0], "system")
			out, _ := runShell(s)
			out = strings.TrimSuffix(out, "\n")
			return StrV(out)
		}},
		"exists": {1, func(in *Interp, a []Value) Value {
			s := argStr(a[0], "exists")
			v, ok := in.vars[s]
			return BoolV(ok && v.K != KUndef)
		}},
		"value": {1, func(in *Interp, a []Value) Value {
			s := argStr(a[0], "value")
			v, ok := in.vars[s]
			if !ok {
				in.undef = true
				return FloatV(math.NaN())
			}
			return v
		}},
		"column": {1, func(in *Interp, a []Value) Value {
			return in.columnValue(a[0], -1)
		}},
		"stringcolumn": {1, func(in *Interp, a []Value) Value { return in.stringColumn(a[0]) }},
		"strcol":       {1, func(in *Interp, a []Value) Value { return in.stringColumn(a[0]) }},
		"columnhead":   {1, func(in *Interp, a []Value) Value { return in.columnHead(a[0]) }},
		"columnheader": {1, func(in *Interp, a []Value) Value { return in.columnHead(a[0]) }},
		"valid": {1, func(in *Interp, a []Value) Value {
			return BoolV(in.validColumn(a[0]))
		}},
		"timecolumn": {2, func(in *Interp, a []Value) Value {
			s := in.stringColumn(a[0])
			t, ok := gpStrptime(argStr(a[1], "timecolumn"), s.S)
			if !ok {
				in.undef = true
				return FloatV(math.NaN())
			}
			return FloatV(t)
		}},
	}
}

func runShell(cmd string) (string, error) {
	c := exec.Command("/bin/sh", "-c", cmd)
	c.Stderr = os.Stderr
	out, err := c.Output()
	return string(out), err
}

func tmF(f func(time.Time) int64) Builtin {
	return Builtin{1, func(in *Interp, a []Value) Value {
		x := a[0].num().Float()
		t := gpTime(x)
		return IntV(f(t))
	}}
}

func gpTime(x float64) time.Time {
	sec := math.Floor(x)
	ns := (x - sec) * 1e9
	return time.Unix(int64(sec), int64(ns)).UTC()
}

func gpWords(s string) []string {
	return strings.Fields(s)
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1)
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		if x == 0 {
			return 0
		}
		return math.NaN()
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		sum := 1.0 / a
		del := sum
		ap := a
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1.0 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m < 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x < 0 || x > 1 || a <= 0 || b <= 0 {
		return math.NaN()
	}
	if x == 0 || x == 1 {
		return x
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

// gnuplot sprintf
func gpSprintf(format string, args []Value) string {
	var b strings.Builder
	ai := 0
	for i := 0; i < len(format); i++ {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i++
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0'", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.') {
			j++
		}
		for j < len(format) && strings.IndexByte("hlLqjzt", format[j]) >= 0 {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		if ai >= len(args) {
			b.WriteString(format[i:])
			break
		}
		spec := strings.TrimRight(format[i:j], "hlLqjzt")
		conv := format[j]
		a := args[ai]
		ai++
		switch conv {
		case 's':
			if a.K != KStr {
				gpErrNC("f_sprintf: attempt to print numeric value with string format")
			}
			b.WriteString(cconv(spec, 's', a.S))
		case 'd', 'i', 'x', 'X', 'o', 'c', 'u':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			a = a.num()
			if a.K == KInt {
				b.WriteString(cconv(spec, conv, a.I))
			} else {
				b.WriteString(cconv(spec, conv, a.Float()))
			}
		case 'f', 'F', 'e', 'E', 'g', 'G', 'a', 'A':
			if a.K == KStr {
				gpErrNC("f_sprintf: attempt to print string value with numeric format")
			}
			b.WriteString(cconv(spec, conv, a.num().Float()))
		default:
			gpErrNC("unrecognized format specifier")
		}
		i = j
	}
	return b.String()
}

var siPrefix = "yzafpnum kMGTPEZY"

func gprintf(in *Interp, format string, x float64) string {
	var b strings.Builder
	for i := 0; i < len(format); i++ {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i++
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.') {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		spec := format[i:j]
		conv := format[j]
		prec := 6
		if k := strings.IndexByte(spec, '.'); k >= 0 {
			prec = 0
			for _, ch := range spec[k+1:] {
				prec = prec*10 + int(ch-'0')
			}
		}
		switch conv {
		case 't', 'T':
			m, p := mantExp(x, 10, prec, 1)
			if conv == 't' {
				b.WriteString(cconv(spec, 'f', m))
			} else {
				b.WriteString(cconv(spec, 'd', int64(p)))
			}
		case 'l', 'L':
			base := in.logbaseForFmt
			if base <= 1 {
				if conv == 'l' {
					b.WriteString(cconv(spec, 'f', x))
				} else {
					b.WriteString(cconv(spec, 'd', int64(0)))
				}
				break
			}
			m, p := mantExp(x, base, prec, 1)
			if conv == 'l' {
				b.WriteString(cconv(spec, 'f', m))
			} else {
				b.WriteString(cconv(spec, 'd', int64(p)))
			}
		case 's', 'S', 'c':
			m, p := mantExp(x, 10, prec, 3)
			if conv == 's' {
				b.WriteString(cconv(spec, 'f', m))
			} else if conv == 'S' {
				b.WriteString(cconv(spec, 'd', int64(p)))
			} else {
				k := p/3 + 8
				if k >= 0 && k < len(siPrefix) {
					if siPrefix[k] != ' ' {
						b.WriteByte(siPrefix[k])
					}
				} else {
					b.WriteString(cfmt("e%+.2d", int64(p)))
				}
			}
		case 'P':
			b.WriteString(cconv(spec, 'f', x/math.Pi))
		case 'h', 'H':
			s := cconv(spec, 'g', x)
			if k := strings.IndexByte(s, 'e'); k >= 0 {
				exp := 0
				sign := 1
				e := s[k+1:]
				if e[0] == '-' {
					sign = -1
				}
				for _, ch := range e[1:] {
					exp = exp*10 + int(ch-'0')
				}
				if conv == 'h' {
					s = s[:k] + "x10^{" + cfmt("%d", int64(sign*exp)) + "}"
				} else {
					s = s[:k] + "x10^{" + cfmt("%d", int64(sign*exp)) + "}"
				}
			}
			b.WriteString(s)
		case 'd', 'i', 'x', 'X', 'o', 'c' + 100:
			b.WriteString(cconv(spec, conv, x))
		case 'f', 'F', 'e', 'E', 'g', 'G':
			b.WriteString(cconv(spec, conv, x))
		default:
			b.WriteString(spec + string(conv))
		}
		i = j
	}
	return b.String()
}

// mantissa / exponent for gprintf; step = 1 (any power) or 3 (engineering)
func mantExp(x, base float64, prec int, step int) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	p := int(math.Floor(math.Log(ax) / math.Log(base)))
	if step == 3 {
		p = int(math.Floor(float64(p)/3)) * 3
	}
	m := x / math.Pow(base, float64(p))
	// rounding check
	lim := math.Pow(base, float64(step))
	r := math.Abs(roundTo(m, prec))
	if r >= lim {
		p += step
		m = x / math.Pow(base, float64(p))
	}
	return m, p
}

func roundTo(x float64, prec int) float64 {
	s := cfmt("%."+itoa(prec)+"f", x)
	f, _ := parseFloatPrefix(s)
	return f
}

func itoa(i int) string {
	return cfmt("%d", int64(i))
}
