package main

import (
	"fmt"
	"os"
	"strings"
)

// abbreviation matching: pattern like "pr$int"
func almostEquals(word, pat string) bool {
	i := strings.IndexByte(pat, '$')
	if i < 0 {
		return word == pat
	}
	full := pat[:i] + pat[i+1:]
	if len(word) < i || len(word) > len(full) {
		return false
	}
	return strings.HasPrefix(full, word)
}

func (in *Interp) execCommand(ps *Parser) {
	t := ps.peek()
	if t.Kind == TOp && t.Text == "!" {
		// shell command
		rest := in.curText[t.Pos+1:]
		out, _ := runShell(rest)
		in.flush()
		fmt.Fprint(os.Stdout, out)
		for ps.peek().Kind != TEnd {
			ps.next()
		}
		return
	}
	if t.Kind == TOp && t.Text == "{" {
		txt := in.grabBlock(ps)
		in.runBlock(txt)
		return
	}
	if t.Kind != TName {
		gpErr(t.Pos, "invalid command")
	}
	n1 := ps.toks[ps.p+1]
	// datablock definition
	if strings.HasPrefix(t.Text, "$") {
		if n1.Kind == TOp && n1.Text == "<<" {
			ps.p += 2
			eod := ps.next()
			in.readHeredoc(t.Text, eod.Text)
			return
		}
		if n1.Kind == TOp && n1.Text == "=" {
			gpErr(t.Pos, "invalid command")
		}
		gpErr(t.Pos, "invalid command")
	}
	// assignment
	if n1.Kind == TOp && (n1.Text == "=" ) {
		ps.p += 2
		pos := ps.peek().Pos
		x := ps.parseExpr()
		in.undef = false
		v := x.Eval(in)
		if in.undef {
			in.undef = false
			gpErr(pos, "undefined value")
		}
		if v.K == KArr {
			if t.Text != "" {
				in.setVar(t.Text, v)
				return
			}
		}
		if v.K == KDatablock {
			v = StrV(v.S)
		}
		in.setVar(t.Text, v)
		return
	}
	if n1.Kind == TOp && (n1.Text == "+=" || n1.Text == "-=" || n1.Text == "*=" || n1.Text == "/=") {
		gpErr(t.Pos, "invalid command")
	}
	if n1.Kind == TOp && n1.Text == "(" {
		// function definition?
		j := ps.p + 2
		var params []string
		okdef := false
		for {
			tk := ps.toks[j]
			if tk.Kind != TName {
				break
			}
			params = append(params, tk.Text)
			j++
			if ps.toks[j].Kind == TOp && ps.toks[j].Text == "," {
				j++
				continue
			}
			if ps.toks[j].Kind == TOp && ps.toks[j].Text == ")" && ps.toks[j+1].Kind == TOp && ps.toks[j+1].Text == "=" {
				okdef = true
			}
			break
		}
		if okdef {
			ps.p = j + 2
			start := ps.peek().Pos
			saved := in.parseOnly
			in.parseOnly = true
			body := ps.parseExpr()
			in.parseOnly = saved
			end := ps.peek().Pos
			text := strings.TrimSpace(in.curText[t.Pos:end])
			_ = start
			if _, ok := in.funcs[t.Text]; !ok {
				in.funcOrder = append(in.funcOrder, t.Text)
			}
			in.funcs[t.Text] = &UserFunc{name: t.Text, params: params, body: body, text: text}
			return
		}
	}
	if n1.Kind == TOp && n1.Text == "[" {
		// array element assignment?
		save := ps.p
		ps.p += 2
		idx := ps.parseExpr()
		if ps.atOp("]") && ps.toks[ps.p+1].Kind == TOp && ps.toks[ps.p+1].Text == "=" {
			ps.p += 2
			pos := ps.peek().Pos
			x := ps.parseExpr()
			in.undef = false
			node := &arrAssignNode{name: t.Text, idx: idx, x: x}
			node.Eval(in)
			if in.undef {
				in.undef = false
				gpErr(pos, "undefined value")
			}
			return
		}
		ps.p = save
	}
	w := t.Text
	switch {
	case almostEquals(w, "pr$int"):
		ps.next()
		in.cmdPrint(ps)
	case almostEquals(w, "printerr$or"):
		ps.next()
		saved := in.printOut
		in.printOut = in.stderr
		in.cmdPrint(ps)
		in.printOut = saved
	case almostEquals(w, "if"):
		ps.next()
		in.cmdIf(ps)
	case almostEquals(w, "do"):
		ps.next()
		in.cmdDo(ps)
	case almostEquals(w, "wh$ile"):
		ps.next()
		in.cmdWhile(ps)
	case almostEquals(w, "ev$aluate"):
		ps.next()
		v := in.evalExpr(ps)
		if v.K != KStr {
			gpErrNC("expected string argument")
		}
		in.execLine(v.S)
	case almostEquals(w, "l$oad"):
		ps.next()
		in.cmdLoad(ps, false)
	case almostEquals(w, "cal$l"):
		ps.next()
		in.cmdLoad(ps, true)
	case almostEquals(w, "ex$it") || almostEquals(w, "q$uit"):
		ps.next()
		in.cmdExit(ps)
	case almostEquals(w, "arr$ay"):
		ps.next()
		in.cmdArray(ps)
	case almostEquals(w, "und$efine"):
		ps.next()
		in.cmdUndefine(ps)
	case almostEquals(w, "se$t"):
		ps.next()
		in.cmdSet(ps)
	case almostEquals(w, "uns$et"):
		ps.next()
		in.cmdUnset(ps)
	case almostEquals(w, "sh$ow"):
		ps.next()
		in.cmdShow(ps)
	case almostEquals(w, "p$lot"):
		ps.next()
		in.cmdPlot(ps, false)
	case almostEquals(w, "sp$lot"):
		ps.next()
		in.cmdPlot(ps, true)
	case almostEquals(w, "rep$lot"):
		ps.next()
		in.cmdReplot(ps)
	case almostEquals(w, "st$ats"):
		ps.next()
		in.cmdStats(ps)
	case almostEquals(w, "fit"):
		ps.next()
		in.cmdFit(ps)
	case almostEquals(w, "res$et"):
		ps.next()
		in.cmdReset(ps)
	case almostEquals(w, "cl$ear"):
		ps.next()
		in.cmdClear()
	case almostEquals(w, "pa$use"):
		ps.next()
		in.cmdPause(ps)
	case almostEquals(w, "bre$ak"):
		ps.next()
		if in.loopDepth == 0 {
			gpErr(t.Pos, "break command not in a loop")
		}
		in.breakFlag = true
	case almostEquals(w, "con$tinue"):
		ps.next()
		if in.loopDepth == 0 {
			gpErr(t.Pos, "continue command not in a loop")
		}
		in.continueFlag = true
	case almostEquals(w, "sy$stem"):
		ps.next()
		v := in.evalExpr(ps)
		out, _ := runShell(v.S)
		in.flush()
		fmt.Fprint(os.Stdout, out)
	case almostEquals(w, "cd"):
		ps.next()
		v := in.evalExpr(ps)
		if err := os.Chdir(v.S); err != nil {
			gpErrNC("Can't change to this directory")
		}
	case almostEquals(w, "pwd"):
		ps.next()
		d, _ := os.Getwd()
		fmt.Fprintln(in.stderr, d)
	case almostEquals(w, "test"):
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "up$date"):
		ps.next()
		in.cmdUpdate(ps)
	case almostEquals(w, "sa$ve"):
		ps.next()
		in.cmdSave(ps)
	case almostEquals(w, "ref$resh"):
		ps.next()
		in.cmdReplot(ps)
	case almostEquals(w, "bi$nd"), almostEquals(w, "low$er"), almostEquals(w, "ra$ise"), almostEquals(w, "hi$story"):
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "he$lp") || w == "?":
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "else"):
		gpErr(t.Pos, "invalid command")
	default:
		gpErr(t.Pos, "invalid command")
	}
}

func (in *Interp) cmdPrint(ps *Parser) {
	w := in.printOut
	if in.printDB != "" {
		var b strings.Builder
		in.printItems(ps, &b)
		s := b.String()
		lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
		in.datablocks[in.printDB] = append(in.datablocks[in.printDB], lines...)
		return
	}
	in.printItems(ps, w)
}

type strWriter interface {
	WriteString(s string) (int, error)
}

func (in *Interp) printItems(ps *Parser, w interface{ Write([]byte) (int, error) }) {
	first := true
	if ps.atEnd() {
		gpErr(ps.peek().Pos, "constant expression required")
	}
	for {
		if !first {
			if !ps.atOp(",") {
				break
			}
			ps.next()
			w.Write([]byte(" "))
		}
		pos := ps.peek().Pos
		x := ps.parseExpr()
		in.undef = false
		v := x.Eval(in)
		if in.undef {
			in.undef = false
			gpErr(pos, "undefined value")
		}
		first = false
		if v.K == KDatablock {
			for _, l := range in.datablocks[v.S] {
				w.Write([]byte(l + "\n"))
			}
			continue
		}
		if v.K == KArr {
			w.Write([]byte(v.String() + "\n"))
			continue
		}
		w.Write([]byte(v.String()))
	}
	w.Write([]byte("\n"))
}

func (in *Interp) parseCond(ps *Parser) bool {
	if !ps.atOp("(") {
		gpErr(ps.peek().Pos, "expecting '('")
	}
	pos := ps.peek().Pos
	_ = pos
	v := in.evalExpr(ps)
	return isTrue(v.num())
}

func (in *Interp) cmdIf(ps *Parser) {
	cond := in.parseCond(ps)
	if ps.atOp("{") {
		body := in.grabBlock(ps)
		if cond {
			in.runBlock(body)
			// skip else branches
			for ps.at("else") {
				ps.next()
				if ps.at("if") {
					ps.next()
					// skip condition
					depth := 0
					for {
						t := ps.next()
						if t.Kind == TOp && t.Text == "(" {
							depth++
						} else if t.Kind == TOp && t.Text == ")" {
							depth--
							if depth == 0 {
								break
							}
						} else if t.Kind == TEnd {
							break
						}
					}
				}
				if ps.atOp("{") {
					in.grabBlock(ps)
				}
			}
			return
		}
		if ps.at("else") {
			ps.next()
			if ps.at("if") {
				ps.next()
				in.cmdIf(ps)
				return
			}
			body2 := in.grabBlock(ps)
			in.runBlock(body2)
		}
		return
	}
	// old style: rest of line
	if cond {
		// execute commands until 'else' or end
		for {
			for ps.atOp(";") {
				ps.next()
			}
			if ps.peek().Kind == TEnd {
				return
			}
			if ps.at("else") {
				for ps.peek().Kind != TEnd {
					ps.next()
				}
				return
			}
			in.execCommand(ps)
			if !ps.atEnd() {
				t := ps.peek()
				gpErr(t.Pos, "unexpected or unrecognized token: "+t.Text)
			}
		}
	}
	// skip to else
	for ps.peek().Kind != TEnd {
		if ps.at("else") {
			ps.next()
			for {
				for ps.atOp(";") {
					ps.next()
				}
				if ps.peek().Kind == TEnd {
					return
				}
				in.execCommand(ps)
			}
		}
		ps.next()
	}
}

type iterSpec struct {
	varName string
	isStr   bool
	words   []string
	lo, hi  int64
	step    int64
	hiInf   bool
}

func (in *Interp) parseIter(ps *Parser) *iterSpec {
	// at '['
	ps.expect("[", "expecting '['")
	vt := ps.next()
	if vt.Kind != TName {
		gpErr(vt.Pos, "Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	it := &iterSpec{varName: vt.Text, step: 1}
	if ps.at("in") {
		ps.next()
		v := in.evalExpr(ps)
		if v.K != KStr {
			gpErrNC("Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
		}
		it.isStr = true
		it.words = gpWords(v.S)
		ps.expect("]", "expecting ']'")
		return it
	}
	ps.expect("=", "Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	it.lo = toInt(in.evalExpr(ps))
	ps.expect(":", "expecting ':'")
	if ps.atOp("*") {
		ps.next()
		it.hiInf = true
	} else {
		it.hi = toInt(in.evalExpr(ps))
	}
	if ps.atOp(":") {
		ps.next()
		it.step = toInt(in.evalExpr(ps))
		if it.step == 0 {
			gpErrNC("Iteration with zero step")
		}
	}
	ps.expect("]", "expecting ']'")
	return it
}

func (it *iterSpec) values() []Value {
	var vs []Value
	if it.isStr {
		for _, w := range it.words {
			vs = append(vs, StrV(w))
		}
		return vs
	}
	if it.step > 0 {
		for i := it.lo; i <= it.hi; i += it.step {
			vs = append(vs, IntV(i))
		}
	} else {
		for i := it.lo; i >= it.hi; i += it.step {
			vs = append(vs, IntV(i))
		}
	}
	return vs
}

func (in *Interp) cmdDo(ps *Parser) {
	if !ps.at("for") {
		gpErr(ps.peek().Pos, "invalid command")
	}
	ps.next()
	var iters []*iterSpec
	for ps.atOp("[") {
		iters = append(iters, in.parseIter(ps))
		if ps.at("for") {
			ps.next()
		}
	}
	body := in.grabBlock(ps)
	in.loopDepth++
	defer func() { in.loopDepth-- }()
	var rec func(k int) bool
	rec = func(k int) bool {
		if k == len(iters) {
			in.runBlock(body)
			if in.breakFlag {
				in.breakFlag = false
				return false
			}
			in.continueFlag = false
			return true
		}
		it := iters[k]
		for _, v := range it.values() {
			in.setVar(it.varName, v)
			if !rec(k + 1) {
				return false
			}
		}
		return true
	}
	rec(0)
}

func (in *Interp) cmdWhile(ps *Parser) {
	condStart := ps.p
	in.parseCond(ps)
	body := in.grabBlock(ps)
	end := ps.p
	in.loopDepth++
	defer func() { in.loopDepth-- }()
	for {
		ps.p = condStart
		c := in.parseCond(ps)
		if !c {
			break
		}
		in.runBlock(body)
		if in.breakFlag {
			in.breakFlag = false
			break
		}
		in.continueFlag = false
	}
	ps.p = end
}

func (in *Interp) cmdLoad(ps *Parser, isCall bool) {
	v := in.evalExpr(ps)
	if v.K != KStr {
		gpErrNC("expecting filename")
	}
	fname := v.S
	var args []string
	if isCall {
		for !ps.atEnd() {
			t := ps.peek()
			if t.Kind == TStr {
				ps.next()
				args = append(args, t.Str)
				continue
			}
			a := in.evalExpr(ps)
			if a.K == KStr {
				args = append(args, a.S)
			} else {
				args = append(args, a.String())
			}
		}
	}
	var lines []string
	if strings.HasPrefix(fname, "$") {
		db, ok := in.datablocks[fname]
		if !ok {
			gpErrNC("Cannot load input from '" + fname + "'")
		}
		lines = append(lines, db...)
	} else if fname == "-" {
		gpErrNC("Cannot load input from '-'")
	} else {
		data, err := os.ReadFile(fname)
		if err != nil {
			gpErrNC("Cannot load input from '" + fname + "'")
		}
		lines = splitLines(string(data))
	}
	src := &Source{lines: lines, name: fname}
	if isCall {
		oldArgs := map[string]Value{}
		for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
			if ov, ok := in.vars[k]; ok {
				oldArgs[k] = ov
			}
		}
		in.setCallArgs(fname, args)
		defer func() {
			for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
				if ov, ok := oldArgs[k]; ok {
					in.vars[k] = ov
				}
			}
		}()
	}
	savedDepth := in.blockDepth
	in.blockDepth = 0
	defer func() { in.blockDepth = savedDepth }()
	in.runSource(src)
}

func (in *Interp) setCallArgs(name string, args []string) {
	in.setVar("ARGC", IntV(int64(len(args))))
	in.setVar("ARG0", StrV(name))
	arr := &Array{}
	for _, a := range args {
		arr.vals = append(arr.vals, StrV(a))
	}
	in.setVar("ARGV", Value{K: KArr, Arr: arr})
	for i := 1; i <= 9; i++ {
		if i <= len(args) {
			in.setVar(fmt.Sprintf("ARG%d", i), StrV(args[i-1]))
		} else {
			in.setVar(fmt.Sprintf("ARG%d", i), StrV(""))
		}
	}
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	s = strings.TrimSuffix(s, "\n")
	ls := strings.Split(s, "\n")
	for i := range ls {
		ls[i] = strings.TrimSuffix(ls[i], "\r")
	}
	return ls
}

func (in *Interp) cmdExit(ps *Parser) {
	code := 0
	if ps.at("status") {
		ps.next()
		if !ps.atEnd() {
			code = int(toInt(in.evalExpr(ps)))
		}
	} else if ps.at("error") {
		ps.next()
		v := in.evalExpr(ps)
		gpErrNC(v.S)
	} else if !ps.atEnd() {
		code = int(toInt(in.evalExpr(ps)))
	}
	panic(&ExitReq{code})
}

func (in *Interp) cmdArray(ps *Parser) {
	nt := ps.next()
	if nt.Kind != TName {
		gpErr(nt.Pos, "illegal array name")
	}
	arr := &Array{}
	if ps.atOp("[") {
		ps.next()
		n := toInt(in.evalExpr(ps))
		ps.expect("]", "expecting ']'")
		if n < 0 {
			gpErrNC("array size must be positive")
		}
		arr.vals = make([]Value, n)
		for i := range arr.vals {
			arr.vals[i] = Value{K: KUndef}
		}
		if ps.atOp("=") {
			ps.next()
			in.arrayInit(ps, arr, true)
		}
	} else if ps.atOp("=") {
		ps.next()
		in.arrayInit(ps, arr, false)
	} else {
		gpErr(ps.peek().Pos, "expecting array size or initializer")
	}
	in.setVar(nt.Text, Value{K: KArr, Arr: arr})
}

func (in *Interp) arrayInit(ps *Parser, arr *Array, sized bool) {
	if !ps.atOp("[") {
		v := in.evalExpr(ps)
		if v.K == KArr {
			arr.vals = append([]Value{}, v.Arr.vals...)
			return
		}
		for i := range arr.vals {
			arr.vals[i] = v
		}
		return
	}
	ps.next()
	i := 0
	for !ps.atOp("]") {
		if ps.atOp(",") {
			ps.next()
			i++
			continue
		}
		v := in.evalExpr(ps)
		if sized {
			if i < len(arr.vals) {
				arr.vals[i] = v
			}
		} else {
			for len(arr.vals) <= i {
				arr.vals = append(arr.vals, Value{K: KUndef})
			}
			arr.vals[i] = v
		}
		if ps.atOp(",") {
			ps.next()
			i++
			if !sized && ps.atOp("]") {
				arr.vals = append(arr.vals, Value{K: KUndef})
			}
		} else if !ps.atOp("]") {
			gpErr(ps.peek().Pos, "expecting ']'")
		}
	}
	ps.next()
}

func (in *Interp) cmdUndefine(ps *Parser) {
	for !ps.atEnd() {
		t := ps.next()
		name := t.Text
		if strings.HasSuffix(name, "*") {
			continue
		}
		if ps.atOp("*") {
			ps.next()
			for k := range in.vars {
				if strings.HasPrefix(k, name) && !strings.HasPrefix(k, "GPVAL") {
					delete(in.vars, k)
				}
			}
			continue
		}
		if strings.HasPrefix(name, "$") {
			delete(in.datablocks, name)
			continue
		}
		delete(in.vars, name)
	}
}

func (in *Interp) readHeredoc(name, eod string) {
	var lines []string
	src := in.src
	for src != nil && src.idx < len(src.lines) {
		l := src.lines[src.idx]
		src.idx++
		src.lineno++
		if strings.TrimRight(l, "\r") == eod {
			break
		}
		lines = append(lines, strings.TrimRight(l, "\r"))
	}
	if _, ok := in.datablocks[name]; !ok {
		in.dbOrder = append(in.dbOrder, name)
	}
	in.datablocks[name] = lines
}

func (in *Interp) cmdPause(ps *Parser) {
	if ps.atEnd() {
		gpErr(ps.peek().Pos, "expecting pause time")
	}
	v := in.evalExpr(ps)
	if !ps.atEnd() {
		m := in.evalExpr(ps)
		if m.K == KStr {
			in.flush()
			fmt.Fprintln(os.Stderr, m.S)
		}
	}
	_ = v
}

func (in *Interp) cmdClear() {
	if in.multiplot != nil {
		return
	}
}
