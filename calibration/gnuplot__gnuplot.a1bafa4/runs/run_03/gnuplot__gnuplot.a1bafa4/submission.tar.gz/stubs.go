package main

func (in *Interp) cmdUpdate(ps *Parser) { in.skipToEnd(ps) }
func (in *Interp) cmdSave(ps *Parser)   { in.skipToEnd(ps) }
func (in *Interp) renderVector(items []*PlotItem, is3D bool) { in.updateRanges(items, is3D) }
