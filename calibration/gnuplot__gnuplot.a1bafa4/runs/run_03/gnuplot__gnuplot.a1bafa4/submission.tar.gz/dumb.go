package main

import (
	"math"
	"strings"
)

type Canvas struct {
	w, h  int
	cells [][]byte
}

func newCanvas(w, h int) *Canvas {
	c := &Canvas{w: w, h: h}
	c.cells = make([][]byte, h)
	for i := range c.cells {
		c.cells[i] = []byte(strings.Repeat(" ", w))
	}
	return c
}

func (c *Canvas) set(x, y int, ch byte) {
	if x >= 0 && x < c.w && y >= 0 && y < c.h {
		c.cells[y][x] = ch
	}
}

func (c *Canvas) text(x, y int, s string) {
	for i := 0; i < len(s); i++ {
		c.set(x+i, y, s[i])
	}
}

// line in row coordinates (y down)
func (c *Canvas) line(x1, y1, x2, y2 int, ch byte, clip func(x, y int) bool) {
	dx := x2 - x1
	dy := y2 - y1
	adx, ady := abs(dx), abs(dy)
	put := func(x, y int) {
		if clip == nil || clip(x, y) {
			c.set(x, y, ch)
		}
	}
	if adx == 0 && ady == 0 {
		put(x1, y1)
		return
	}
	if ady > adx {
		for k := 0; k <= ady; k++ {
			x := x1 + int(math.Floor(float64(dx)*float64(k)/float64(ady)+0.5))
			y := y1 + k*sgnI(dy)
			put(x, y)
		}
	} else {
		for k := 0; k <= adx; k++ {
			y := y1 + int(math.Floor(float64(dy)*float64(k)/float64(adx)+0.5))
			x := x1 + k*sgnI(dx)
			put(x, y)
		}
	}
}

func abs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}
func sgnI(a int) int {
	if a < 0 {
		return -1
	}
	if a > 0 {
		return 1
	}
	return 0
}

var dumbLineChars = "*#$%@&="

// tic step computation
func ticStep(rng float64, guide float64) float64 {
	if rng <= 0 {
		return 1
	}
	power := math.Pow(10, math.Floor(math.Log10(rng)))
	xnorm := rng / power
	posns := guide / xnorm
	var t float64
	switch {
	case posns > 40:
		t = 0.05
	case posns > 20:
		t = 0.1
	case posns > 10:
		t = 0.2
	case posns > 4:
		t = 0.5
	case posns > 2:
		t = 1
	case posns > 0.5:
		t = 2
	default:
		t = math.Ceil(xnorm)
	}
	return t * power
}

type axisLayout struct {
	min, max float64
	step     float64
	log      bool
	base     float64
}

func (in *Interp) autoscaleAxis(a *Axis, dmin, dmax float64, guide float64, extend bool) axisLayout {
	lo, hi := a.min, a.max
	if a.autoMin {
		lo = dmin
	}
	if a.autoMax {
		hi = dmax
	}
	if math.IsInf(lo, 0) || math.IsNaN(lo) {
		lo = -10
	}
	if math.IsInf(hi, 0) || math.IsNaN(hi) {
		hi = 10
	}
	if lo == hi {
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			d := math.Abs(lo) * 0.01
			lo, hi = lo-d, hi+d
		}
	}
	rev := false
	if lo > hi {
		lo, hi = hi, lo
		rev = true
	}
	_ = rev
	if a.log {
		// log axis: extend to powers of base
		b := a.base
		if a.autoMin && lo > 0 {
			lo = math.Pow(b, math.Floor(math.Log(lo)/math.Log(b)+1e-9))
		}
		if a.autoMax && hi > 0 {
			hi = math.Pow(b, math.Ceil(math.Log(hi)/math.Log(b)-1e-9))
		}
		return axisLayout{min: lo, max: hi, log: true, base: b, step: 1}
	}
	step := ticStep(hi-lo, guide)
	if a.ticStep > 0 {
		step = a.ticStep
	}
	if extend {
		if a.autoMin {
			lo = math.Floor(lo/step+1e-9) * step
		}
		if a.autoMax {
			hi = math.Ceil(hi/step-1e-9) * step
		}
	}
	return axisLayout{min: lo, max: hi, step: step}
}

type ticMark struct {
	v     float64
	label string
}

func (in *Interp) ticsFor(a *Axis, L axisLayout) []ticMark {
	var res []ticMark
	if a.ticList != nil {
		for _, t := range a.ticList {
			lbl := t.label
			if lbl == "\x00" {
				lbl = gprintf(in, a.format, t.pos)
			}
			res = append(res, ticMark{t.pos, lbl})
		}
		if a.ticListOnly {
			return res
		}
	}
	if L.log {
		b := L.base
		e0 := math.Ceil(math.Log(L.min)/math.Log(b) - 1e-9)
		e1 := math.Floor(math.Log(L.max)/math.Log(b) + 1e-9)
		for e := e0; e <= e1; e++ {
			v := math.Pow(b, e)
			res = append(res, ticMark{v, gprintf(in, a.format, v)})
		}
		return res
	}
	step := L.step
	k0 := math.Ceil(L.min/step - 1e-9)
	start := k0 * step
	if a.ticStartSet {
		start = a.ticStart
	}
	for i := 0; i < 1000; i++ {
		v := start + float64(i)*step
		if !a.ticStartSet {
			v = (k0 + float64(i)) * step
		}
		if v > L.max+step*1e-9 {
			break
		}
		if a.ticStartSet && v > a.ticEnd+step*1e-9 {
			break
		}
		if v < L.min-step*1e-9 {
			continue
		}
		if math.Abs(v) < step*1e-9 {
			v = 0
		}
		res = append(res, ticMark{v, gprintf(in, a.format, v)})
	}
	return res
}

func (in *Interp) renderDumb(items []*PlotItem, is3D bool) {
	S := in.S
	W, H := S.termW, S.termH
	c := newCanvas(W, H)
	if is3D {
		in.render3DDumb(c, items)
		in.emitCanvas(c)
		return
	}
	xa := in.plotAxes["x"]
	ya := in.plotAxes["y"]
	// data ranges
	dxmin, dxmax := math.Inf(1), math.Inf(-1)
	dymin, dymax := math.Inf(1), math.Inf(-1)
	for _, it := range items {
		for _, p := range it.points {
			if p.brk || p.typ == 'u' {
				continue
			}
			if p.typ == 'o' {
				continue
			}
			dxmin = math.Min(dxmin, p.x)
			dxmax = math.Max(dxmax, p.x)
			ys := []float64{p.y}
			if it.style == "yerrorbars" || it.style == "yerrorlines" {
				if len(p.ex) == 1 {
					ys = append(ys, p.y-p.ex[0], p.y+p.ex[0])
				} else if len(p.ex) >= 2 {
					ys = append(ys, p.ex[0], p.ex[1])
				}
			}
			if it.style == "boxes" || it.style == "impulses" {
				ys = append(ys, 0)
			}
			for _, y := range ys {
				dymin = math.Min(dymin, y)
				dymax = math.Max(dymax, y)
			}
		}
	}
	// layout
	top := 1
	if S.title != "" {
		top = 3
	}
	bottom := H - 3
	if xa.label != "" {
		bottom = H - 4
	}
	right := W - 4
	plotRows := bottom - top
	// provisional y layout to get label widths
	yL := in.autoscaleAxis(ya, dymin, dymax, 20, true)
	yt := in.ticsFor(ya, yL)
	maxw := 0
	for _, t := range yt {
		if len(t.label) > maxw {
			maxw = len(t.label)
		}
	}
	left := maxw + 2
	if ya.label != "" {
		left += len(ya.label) + 1
	}
	plotCols := right - left
	xL := in.autoscaleAxis(xa, dxmin, dxmax, 20, true)
	if xa.autoMin && xa.autoMax && math.IsInf(dxmin, 0) {
		xL.min, xL.max = xa.min, xa.max
	}
	if !xa.autoMin {
		xL.min = math.Min(xa.min, xa.max)
	}
	if !xa.autoMax {
		xL.max = math.Max(xa.min, xa.max)
	}
	xt := in.ticsFor(xa, xL)
	// record ranges
	in.recordRange("x", xL.min, xL.max)
	in.recordRange("y", yL.min, yL.max)
	mapX := func(x float64) float64 {
		if xL.log {
			return float64(left) + (math.Log(x)-math.Log(xL.min))/(math.Log(xL.max)-math.Log(xL.min))*float64(plotCols)
		}
		if xa.reverse {
			return float64(left) + (xL.max-x)*(float64(plotCols)/(xL.max-xL.min))
		}
		return float64(left) + (x-xL.min)*(float64(plotCols)/(xL.max-xL.min))
	}
	mapY := func(y float64) float64 {
		if yL.log {
			f := (math.Log(y) - math.Log(yL.min)) / (math.Log(yL.max) - math.Log(yL.min))
			return float64(H-1-bottom) + f*float64(plotRows)
		}
		if ya.reverse {
			return float64(H-1-bottom) + (yL.max-y)*(float64(plotRows)/(yL.max-yL.min))
		}
		return float64(H-1-bottom) + (y-yL.min)*(float64(plotRows)/(yL.max-yL.min))
	}
	cx := func(x float64) int { return int(math.Floor(mapX(x) + XROUND)) }
	cy := func(y float64) int { return H - 1 - int(math.Floor(mapY(y)+YROUND)) }
	// title
	if S.title != "" {
		c.text((left+right)/2-len(S.title)/2, 2, S.title)
	}
	// grid
	if S.grid {
		for _, t := range yt {
			r := cy(t.v)
			if r <= top || r >= bottom {
				continue
			}
			for x := left + 1; x < right; x++ {
				c.set(x, r, '.')
			}
		}
		for _, t := range xt {
			col := cx(t.v)
			if col <= left || col >= right {
				continue
			}
			for y := top + 1; y < bottom; y++ {
				c.set(col, y, ':')
			}
		}
	}
	// tics
	if ya.ticsOn {
		for _, t := range yt {
			r := cy(t.v)
			if r < top || r > bottom {
				continue
			}
			c.set(left+1, r, '-')
			c.set(left+2, r, '+')
			if ya.mirror {
				c.set(right-1, r, '-')
				c.set(right-2, r, '+')
			}
			c.text(left-1-len(t.label), r, t.label)
		}
	}
	if xa.ticsOn {
		for _, t := range xt {
			col := cx(t.v)
			if col < left || col > right {
				continue
			}
			c.set(col, bottom-1, '+')
			if xa.mirror {
				c.set(col, top+1, '+')
			}
			lbl := t.label
			c.text(col-len(lbl)/2, bottom+1, lbl)
		}
	}
	// labels
	if xa.label != "" {
		c.text((left+right)/2-len(xa.label)/2, bottom+2, xa.label)
	}
	if ya.label != "" {
		c.text(1, (top+bottom+1)/2, ya.label)
	}
	clip := func(x, y int) bool { return x > left && x < right && y > top && y < bottom }
	// key
	nkey := 0
	maxt := 0
	for _, it := range items {
		if !it.notitle && it.title != "" {
			nkey++
			if len(it.title) > maxt {
				maxt = len(it.title)
			}
		}
	}
	keyRow := top + 2
	if S.keyVert == "bottom" {
		keyRow = bottom - nkey
	}
	ki := 0
	for idx, it := range items {
		lt := idx
		if it.lt >= 0 {
			lt = it.lt
		}
		lch := dumbLineChars[lt%len(dumbLineChars)]
		pt := lt + 1
		if it.ptSet {
			pt = it.pt
		}
		pch := byte('A' + (pt-1)%26)
		if pt < -100 {
			pch = byte(-(pt + 100))
		}
		if S.keyOn && !it.notitle && it.title != "" {
			r := keyRow + ki
			ki++
			var sx, tx int
			if S.keyHoriz == "left" {
				tx = left + 1 + maxt - len(it.title)
				sx = left + 1 + maxt + 1
			} else {
				sx = right - 8
				tx = sx - 1 - len(it.title)
			}
			c.text(tx, r, it.title)
			switch it.style {
			case "points", "dots":
				ch := pch
				if it.style == "dots" {
					ch = '.'
				}
				c.set(sx+3, r, ch)
			case "linespoints":
				for k := 0; k < 7; k++ {
					c.set(sx+k, r, lch)
				}
				c.set(sx+3, r, pch)
			default:
				for k := 0; k < 7; k++ {
					c.set(sx+k, r, lch)
				}
			}
		}
		// curve
		var prev *Point
		var px, py int
		for i := range it.points {
			p := &it.points[i]
			if p.brk || p.typ == 'u' {
				prev = nil
				continue
			}
			x, y := cx(p.x), cy(p.y)
			switch it.style {
			case "points":
				if p.typ == 'i' && clip(x, y) {
					c.set(x, y, pch)
				}
			case "dots":
				if p.typ == 'i' && clip(x, y) {
					c.set(x, y, '.')
				}
			case "impulses":
				y0 := cy(math.Max(yL.min, math.Min(0, yL.max)))
				c.line(x, y0, x, y, lch, clip)
			case "boxes":
				y0 := cy(math.Max(yL.min, math.Min(0, yL.max)))
				c.line(x, y0, x, y, lch, clip)
			case "steps":
				if prev != nil {
					c.line(px, py, x, py, lch, clip)
					c.line(x, py, x, y, lch, clip)
				}
			case "yerrorbars":
				lo, hi := p.y, p.y
				if len(p.ex) == 1 {
					lo, hi = p.y-p.ex[0], p.y+p.ex[0]
				} else if len(p.ex) >= 2 {
					lo, hi = p.ex[0], p.ex[1]
				}
				c.line(x, cy(lo), x, cy(hi), lch, clip)
				if clip(x, y) {
					c.set(x, y, pch)
				}
			default:
				if prev != nil {
					c.line(px, py, x, y, lch, clip)
				} else if clip(x, y) && i+1 < len(it.points) && (it.points[i+1].brk || it.points[i+1].typ == 'u') {
					c.set(x, y, lch)
				}
				if it.style == "linespoints" && clip(x, y) {
					// points drawn after
				}
			}
			prev = p
			px, py = x, y
		}
		if it.style == "linespoints" {
			for _, p := range it.points {
				if p.brk || p.typ != 'i' {
					continue
				}
				x, y := cx(p.x), cy(p.y)
				if clip(x, y) {
					c.set(x, y, pch)
				}
			}
		}
	}
	// labels
	for _, l := range S.labels {
		var x, y int
		switch l.coord {
		case "graph":
			x = left + int(math.Floor(l.x*float64(plotCols)+0.5))
			y = bottom - int(math.Floor(l.y*float64(plotRows)+0.5))
		case "screen":
			x = int(math.Floor(l.x*float64(W-1) + 0.5))
			y = H - 1 - int(math.Floor(l.y*float64(H-1)+0.5))
		default:
			x, y = cx(l.x), cy(l.y)
		}
		switch l.just {
		case "right":
			x -= len(l.text)
		case "center", "centre":
			x -= len(l.text) / 2
		}
		c.text(x, y, l.text)
	}
	// border
	if S.border&1 != 0 {
		c.line(left, bottom, right, bottom, '-', nil)
	}
	if S.border&4 != 0 {
		c.line(left, top, right, top, '-', nil)
	}
	if S.border&2 != 0 {
		c.line(left, top, left, bottom, '|', nil)
	}
	if S.border&8 != 0 {
		c.line(right, top, right, bottom, '|', nil)
	}
	if S.border != 0 {
		corner := func(x, y int, a, b bool) {
			if a || b {
				c.set(x, y, '+')
			}
		}
		corner(left, bottom, S.border&1 != 0, S.border&2 != 0)
		corner(right, bottom, S.border&1 != 0, S.border&8 != 0)
		corner(left, top, S.border&4 != 0, S.border&2 != 0)
		corner(right, top, S.border&4 != 0, S.border&8 != 0)
	}
	in.emitCanvas(c)
}

func (in *Interp) recordRange(ax string, lo, hi float64) {
	a := in.S.axes[ax]
	a.curMin, a.curMax = lo, hi
	a.everSet = true
	in.setVar("GPVAL_"+strings.ToUpper(ax)+"_MIN", FloatV(lo))
	in.setVar("GPVAL_"+strings.ToUpper(ax)+"_MAX", FloatV(hi))
}

func (in *Interp) updateRanges(items []*PlotItem, is3D bool) {
	dxmin, dxmax := math.Inf(1), math.Inf(-1)
	dymin, dymax := math.Inf(1), math.Inf(-1)
	for _, it := range items {
		for _, p := range it.points {
			if p.brk || p.typ != 'i' {
				continue
			}
			dxmin = math.Min(dxmin, p.x)
			dxmax = math.Max(dxmax, p.x)
			dymin = math.Min(dymin, p.y)
			dymax = math.Max(dymax, p.y)
		}
	}
	xL := in.autoscaleAxis(in.plotAxes["x"], dxmin, dxmax, 20, true)
	yL := in.autoscaleAxis(in.plotAxes["y"], dymin, dymax, 20, true)
	in.recordRange("x", xL.min, xL.max)
	in.recordRange("y", yL.min, yL.max)
}

func (in *Interp) emitCanvas(c *Canvas) {
	if in.multiplot != nil {
		in.multiplot.canvas = mergeCanvas(in.multiplot.canvas, c)
		return
	}
	w := in.outWriter()
	var b strings.Builder
	if in.S.termFeed {
		b.WriteString("\f")
	}
	for i, row := range c.cells {
		b.Write(row)
		if i < len(c.cells)-1 || true {
			b.WriteString("\n")
		}
	}
	w.WriteString(b.String())
}

func mergeCanvas(a, b *Canvas) *Canvas {
	if a == nil {
		return b
	}
	for y := 0; y < b.h && y < a.h; y++ {
		for x := 0; x < b.w && x < a.w; x++ {
			if b.cells[y][x] != ' ' {
				a.cells[y][x] = b.cells[y][x]
			}
		}
	}
	return a
}

type MultiplotState struct {
	canvas *Canvas
}

func (in *Interp) setMultiplot(ps *Parser) {
	in.skipToEnd(ps)
	in.multiplot = &MultiplotState{}
}

func (in *Interp) endMultiplot() {
	if in.multiplot == nil {
		return
	}
	m := in.multiplot
	in.multiplot = nil
	if m.canvas != nil {
		in.emitCanvas(m.canvas)
	}
}

func (in *Interp) render3DDumb(c *Canvas, items []*PlotItem) {
	// simple projection rendering
	S := in.S
	W, H := S.termW, S.termH
	xmin, xmax := math.Inf(1), math.Inf(-1)
	ymin, ymax := math.Inf(1), math.Inf(-1)
	zmin, zmax := math.Inf(1), math.Inf(-1)
	for _, it := range items {
		for _, p := range it.points {
			if p.brk || p.typ == 'u' {
				continue
			}
			xmin, xmax = math.Min(xmin, p.x), math.Max(xmax, p.x)
			ymin, ymax = math.Min(ymin, p.y), math.Max(ymax, p.y)
			zmin, zmax = math.Min(zmin, p.z), math.Max(zmax, p.z)
		}
	}
	if math.IsInf(xmin, 0) {
		return
	}
	rx := S.view[0] * math.Pi / 180
	rz := S.view[1] * math.Pi / 180
	proj := func(x, y, z float64) (int, int) {
		nx := (x-xmin)/nz(xmax-xmin) - 0.5
		ny := (y-ymin)/nz(ymax-ymin) - 0.5
		nzv := (z-zmin)/nz(zmax-zmin) - 0.5
		x1 := nx*math.Cos(rz) - ny*math.Sin(rz)
		y1 := nx*math.Sin(rz) + ny*math.Cos(rz)
		y2 := y1*math.Cos(rx) - nzv*math.Sin(rx)
		z2 := y1*math.Sin(rx) + nzv*math.Cos(rx)
		_ = y2
		sx := float64(W)/2 + x1*float64(W)*0.6
		sy := float64(H)/2 - z2*float64(H)*0.6
		return int(math.Floor(sx + 0.5)), int(math.Floor(sy + 0.5))
	}
	for idx, it := range items {
		lch := dumbLineChars[idx%len(dumbLineChars)]
		var px, py int
		have := false
		for _, p := range it.points {
			if p.brk || p.typ == 'u' {
				have = false
				continue
			}
			x, y := proj(p.x, p.y, p.z)
			if have {
				c.line(px, py, x, y, lch, nil)
			}
			px, py, have = x, y, true
		}
	}
}

func nz(v float64) float64 {
	if v == 0 {
		return 1
	}
	return v
}






const XROUND = 0.5
const YROUND = 0.5
