package main

import (
	"strconv"
	"strings"
)

type TokKind int

const (
	TNum TokKind = iota
	TName
	TStr
	TOp
	TEnd
)

type Token struct {
	Kind  TokKind
	Text  string // raw text
	Pos   int    // byte position in line
	Str   string // decoded string for TStr
	IsInt bool
	IVal  int64
	FVal  float64
	Quote byte
}

func isDigit(c byte) bool  { return c >= '0' && c <= '9' }
func isLetter(c byte) bool { return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_' || c >= 0x80 }

// decode a double-quoted string body
func decodeDQ(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c != '\\' || i+1 >= len(s) {
			b.WriteByte(c)
			continue
		}
		i++
		switch s[i] {
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case 'r':
			b.WriteByte('\r')
		case 'a':
			b.WriteByte('\a')
		case 'b':
			b.WriteByte('\b')
		case 'f':
			b.WriteByte('\f')
		case 'v':
			b.WriteByte('\v')
		case '\\':
			b.WriteByte('\\')
		case '"':
			b.WriteByte('"')
		case '\'':
			b.WriteByte('\'')
		case '0', '1', '2', '3', '4', '5', '6', '7':
			v := 0
			j := 0
			for j < 3 && i < len(s) && s[i] >= '0' && s[i] <= '7' {
				v = v*8 + int(s[i]-'0')
				i++
				j++
			}
			i--
			b.WriteByte(byte(v))
		default:
			b.WriteByte(s[i])
		}
	}
	return b.String()
}

var ops3 = []string{"<=>"}
var ops2 = []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "+=", "-=", "*=", "/=", "%=", "=~"}

// tokenize a line. Returns tokens with TEnd at end.
func tokenize(line string) ([]Token, *GPError) {
	var toks []Token
	i := 0
	n := len(line)
	for {
		for i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r' || line[i] == '\n') {
			i++
		}
		if i >= n {
			break
		}
		c := line[i]
		start := i
		if c == '#' {
			n = i
			break
		}
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])) {
			// number
			if c == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
				toks = append(toks, Token{Kind: TNum, Text: line[i:j], Pos: start, IsInt: true, IVal: int64(v)})
				i = j
				continue
			}
			j := i
			isInt := true
			for j < n && isDigit(line[j]) {
				j++
			}
			if j < n && line[j] == '.' {
				isInt = false
				j++
				for j < n && isDigit(line[j]) {
					j++
				}
			}
			if j < n && (line[j] == 'e' || line[j] == 'E') {
				k := j + 1
				if k < n && (line[k] == '+' || line[k] == '-') {
					k++
				}
				if k < n && isDigit(line[k]) {
					isInt = false
					for k < n && isDigit(line[k]) {
						k++
					}
					j = k
				}
			}
			txt := line[i:j]
			t := Token{Kind: TNum, Text: txt, Pos: start}
			if isInt {
				if len(txt) > 1 && txt[0] == '0' {
					v, err := strconv.ParseInt(txt, 8, 64)
					if err == nil {
						t.IsInt = true
						t.IVal = v
					} else {
						f, _ := strconv.ParseFloat(txt, 64)
						t.FVal = f
					}
				} else {
					v, err := strconv.ParseInt(txt, 10, 64)
					if err == nil {
						t.IsInt = true
						t.IVal = v
					} else {
						f, _ := strconv.ParseFloat(txt, 64)
						t.FVal = f
					}
				}
			} else {
				f, _ := strconv.ParseFloat(txt, 64)
				t.FVal = f
			}
			toks = append(toks, t)
			i = j
			continue
		}
		if isLetter(c) || (c == '$' && i+1 < n && isLetter(line[i+1])) {
			j := i + 1
			for j < n && (isLetter(line[j]) || isDigit(line[j])) {
				j++
			}
			toks = append(toks, Token{Kind: TName, Text: line[i:j], Pos: start})
			i = j
			continue
		}
		if c == '"' {
			j := i + 1
			for j < n && line[j] != '"' {
				if line[j] == '\\' && j+1 < n {
					j++
				}
				j++
			}
			body := line[i+1 : min(j, n)]
			if j < n {
				j++
			}
			toks = append(toks, Token{Kind: TStr, Text: line[i:j], Pos: start, Str: decodeDQ(body), Quote: '"'})
			i = j
			continue
		}
		if c == '\'' {
			j := i + 1
			var b strings.Builder
			for j < n {
				if line[j] == '\'' {
					if j+1 < n && line[j+1] == '\'' {
						b.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				b.WriteByte(line[j])
				j++
			}
			if j < n {
				j++
			}
			toks = append(toks, Token{Kind: TStr, Text: line[i:j], Pos: start, Str: b.String(), Quote: '\''})
			i = j
			continue
		}
		if c == '`' {
			j := i + 1
			for j < n && line[j] != '`' {
				j++
			}
			if j < n {
				j++
			}
			toks = append(toks, Token{Kind: TOp, Text: line[i:j], Pos: start})
			i = j
			continue
		}
		matched := false
		for _, o := range ops3 {
			if strings.HasPrefix(line[i:], o) {
				toks = append(toks, Token{Kind: TOp, Text: o, Pos: start})
				i += len(o)
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		for _, o := range ops2 {
			if strings.HasPrefix(line[i:], o) {
				toks = append(toks, Token{Kind: TOp, Text: o, Pos: start})
				i += len(o)
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		toks = append(toks, Token{Kind: TOp, Text: string(c), Pos: start})
		i++
	}
	toks = append(toks, Token{Kind: TEnd, Text: "", Pos: n})
	return toks, nil
}
