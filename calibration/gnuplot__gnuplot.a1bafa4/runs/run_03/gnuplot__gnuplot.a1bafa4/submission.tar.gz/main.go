package main

import (
	"fmt"
	"io"
	"os"
	"strings"
)

func main() {
	in := NewInterp()
	code := run(in, os.Args[1:])
	in.finish()
	os.Exit(code)
}

func (in *Interp) finish() {
	in.closeOutput()
	if in.printFile != nil {
		in.printFile.Close()
	}
	in.flush()
}

func run(in *Interp, args []string) (code int) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*ExitReq); ok {
				code = e.code
				return
			}
			if e, ok := r.(*GPError); ok {
				in.reportError(e)
				code = 1
				return
			}
			panic(r)
		}
	}()
	type action struct {
		kind string
		arg  string
		args []string
	}
	var acts []action
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			in.flush()
			fmt.Println("gnuplot 5.4 patchlevel 9")
			return 0
		case a == "-h" || a == "--help":
			in.flush()
			fmt.Print("Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\ngnuplot 5.4 patchlevel 9\n")
			return 0
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings" || a == "--default":
		case a == "-e":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "syntax:  gnuplot -e \"commands\"\n")
				return 0
			}
			i++
			acts = append(acts, action{kind: "e", arg: args[i]})
		case a == "-c":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "syntax:  gnuplot -c scriptname args\n")
				return 0
			}
			acts = append(acts, action{kind: "c", arg: args[i+1], args: args[i+2:]})
			i = len(args)
		case a == "-":
			acts = append(acts, action{kind: "stdin"})
		case strings.HasPrefix(a, "-") && len(a) > 1:
			fmt.Fprintf(os.Stderr, "unrecognized option %s\n", a)
		default:
			acts = append(acts, action{kind: "f", arg: a})
		}
	}
	if len(acts) == 0 {
		acts = append(acts, action{kind: "stdin"})
	}
	for _, act := range acts {
		switch act.kind {
		case "e":
			src := &Source{lines: []string{act.arg}, name: ""}
			in.runSourceTop(src, 0)
		case "f", "c":
			data, err := os.ReadFile(act.arg)
			if err != nil {
				in.src = &Source{name: ""}
				gpErrNC("Cannot load input from '" + act.arg + "'")
			}
			in.setCallArgs(act.arg, act.args)
			src := &Source{lines: splitLines(string(data)), name: act.arg}
			in.runSourceTop(src, -1)
		case "stdin":
			data, _ := io.ReadAll(os.Stdin)
			src := &Source{lines: splitLines(string(data)), name: "", isStdin: true}
			in.interactive = true
			in.runSourceTop(src, 0)
			if in.hadError {
				return 1
			}
		}
	}
	return 0
}

func (in *Interp) runSourceTop(src *Source, fixedLine int) {
	if fixedLine == 0 {
		src.lineno = 0
		src.fixedLine = true
	}
	in.runSource(src)
}
