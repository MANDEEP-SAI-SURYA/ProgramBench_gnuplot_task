package main

import (
	"fmt"
	"math"
	"os"
	"strings"
)

type Axis struct {
	name               string
	min, max           float64
	autoMin, autoMax   bool
	reverse            bool
	log                bool
	base               float64
	format             string
	label              string
	ticsOn             bool
	mirror             bool
	ticStep            float64 // 0 auto
	ticStart           float64
	ticEnd             float64
	ticStartSet        bool
	ticList            []TicDef
	ticListOnly        bool
	minor              int
	isTime             bool
	curMin, curMax     float64
	everSet            bool
}

type TicDef struct {
	label string
	pos   float64
	level int
}

type Label struct {
	tag   int
	text  string
	x, y  float64
	coord string
	just  string
}

type Settings struct {
	axes        map[string]*Axis
	title       string
	samples     int
	samples2    int
	iso1, iso2  int
	dataStyle   string
	funcStyle   string
	keyOn       bool
	keyPos      string
	keyHoriz    string
	keyVert     string
	keyBox      bool
	keyLeftJust bool
	keyReverse  bool
	keyOutside  bool
	keyTitle    string
	table       bool
	tableDB     string
	tableFile   string
	termName    string
	termW, termH int
	termFeed    bool
	output      string
	grid        bool
	angles      string
	dummy1, dummy2 string
	sep         string
	missing     string
	comments    string
	timefmt     string
	border      int
	zero        float64
	boxwidth    float64
	boxwidthSet bool
	labels      []*Label
	fitLog      string
	fitQuiet    bool
	fitErrVars  bool
	fitLimit    float64
	fitMaxIter  int
	fitLambdaFactor float64
	fitStartLambda float64
	fitPrescale bool
	offsets     [4]float64
	xzeroaxis   bool
	yzeroaxis   bool
	view        [4]float64
	clipTwo     bool
	parametric  bool
	polar       bool
	pointsize   float64
	xyplane     float64
	ticslevel   float64
	hidden3d    bool
	surface     bool
	contour     bool
	decimalsign string
	minusSign   bool
	fillStyle   string
	fillDensity float64
	histStyle   string
	encoding    string
	headerAuto  bool
	bins        int
	sizeX, sizeY float64
	originX, originY float64
	lmargin, rmargin, tmargin, bmargin float64
}

func newAxis(name string) *Axis {
	return &Axis{name: name, autoMin: true, autoMax: true, min: -10, max: 10, base: 10, format: "% h", ticsOn: name == "x" || name == "y" || name == "z" || name == "cb", mirror: true}
}

func NewSettings() *Settings {
	s := &Settings{}
	s.reset()
	return s
}

func (s *Settings) reset() {
	*s = Settings{}
	s.axes = map[string]*Axis{}
	for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"} {
		s.axes[n] = newAxis(n)
	}
	s.axes["t"].min, s.axes["t"].max = -5, 5
	s.axes["u"].min, s.axes["u"].max = -5, 5
	s.axes["v"].min, s.axes["v"].max = -5, 5
	s.samples, s.samples2 = 100, 100
	s.iso1, s.iso2 = 10, 10
	s.dataStyle = "points"
	s.funcStyle = "lines"
	s.keyOn = true
	s.keyHoriz = "right"
	s.keyVert = "top"
	s.termName = "unknown"
	s.termW, s.termH = 79, 24
	s.termFeed = true
	s.angles = "radians"
	s.dummy1, s.dummy2 = "x", "y"
	s.comments = "#"
	s.timefmt = "%d/%m/%y,%H:%M"
	s.border = 31
	s.zero = 1e-8
	s.fitLog = "fit.log"
	s.fitLimit = 1e-5
	s.fitLambdaFactor = 10
	s.view = [4]float64{60, 30, 1, 1}
	s.pointsize = 1
	s.ticslevel = 0.5
	s.surface = true
	s.fillStyle = "empty"
	s.fillDensity = 1
	s.sizeX, s.sizeY = 1, 1
	s.lmargin, s.rmargin, s.tmargin, s.bmargin = -1, -1, -1, -1
}

func (in *Interp) cmdReset(ps *Parser) {
	if ps.at("session") || ps.at("errors") || ps.at("bind") {
		ps.next()
		return
	}
	term, tw, th, out := in.S.termName, in.S.termW, in.S.termH, in.S.output
	in.S.reset()
	in.S.termName, in.S.termW, in.S.termH, in.S.output = term, tw, th, out
	in.degrees = false
}

func axisFromPrefix(w string) (string, string) {
	for _, a := range []string{"x2", "y2", "cb", "x", "y", "z", "r", "t", "u", "v"} {
		if strings.HasPrefix(w, a) {
			return a, w[len(a):]
		}
	}
	return "", w
}

// parse a string-valued expression (string constant or expression)
func (in *Interp) parseStringArg(ps *Parser) string {
	v := in.evalExpr(ps)
	if v.K != KStr {
		return v.String()
	}
	return v.S
}

func (in *Interp) isStringStart(ps *Parser) bool {
	t := ps.peek()
	if t.Kind == TStr {
		return true
	}
	if t.Kind == TName {
		if v, ok := in.lookupVar(t.Text); ok && v.K == KStr {
			return true
		}
		if t.Text == "sprintf" || t.Text == "gprintf" || t.Text == "strftime" {
			return true
		}
	}
	return false
}

// parse range [a:b]; returns whether min/max set (nil means '*')
func (in *Interp) parseRange(ps *Parser, ax *Axis) {
	ps.expect("[", "expecting '['")
	if ps.atOp("]") {
		ps.next()
		return
	}
	// optional dummy var assignment  [t=a:b]
	if ps.peek().Kind == TName && ps.toks[ps.p+1].Kind == TOp && ps.toks[ps.p+1].Text == "=" {
		ps.p += 2
	}
	if ps.atOp("*") {
		ps.next()
		ax.autoMin = true
	} else if !ps.atOp(":") {
		ax.min = in.parseAxisValue(ps, ax)
		ax.autoMin = false
	}
	if ps.atOp(":") {
		ps.next()
		if ps.atOp("*") {
			ps.next()
			ax.autoMax = true
		} else if !ps.atOp("]") {
			ax.max = in.parseAxisValue(ps, ax)
			ax.autoMax = false
		}
	}
	if !ps.atOp("]") {
		gpErr(ps.peek().Pos, "expecting ']'")
	}
	ps.next()
}

func (in *Interp) parseAxisValue(ps *Parser, ax *Axis) float64 {
	v := in.evalExpr(ps)
	if v.K == KStr && ax.isTime {
		t, _ := gpStrptime(in.S.timefmt, v.S)
		return t
	}
	return v.Float()
}

func (in *Interp) skipToEnd(ps *Parser) {
	for !ps.atEnd() {
		ps.next()
	}
}

func (in *Interp) cmdSet(ps *Parser) {
	S := in.S
	t := ps.peek()
	if t.Kind != TName {
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
	w := t.Text
	ps.next()
	ax, rest := axisFromPrefix(w)
	switch {
	case ax != "" && (rest == "range" || rest == "r"):
		a := S.axes[ax]
		if ps.atOp("[") {
			in.parseRange(ps, a)
		}
		for !ps.atEnd() {
			tk := ps.peek()
			switch {
			case tk.Text == "reverse":
				a.reverse = true
			case tk.Text == "noreverse":
				a.reverse = false
			case tk.Text == "writeback" || tk.Text == "nowriteback" || tk.Text == "noextend" || tk.Text == "extend":
			case tk.Text == "restore":
			default:
				gpErr(tk.Pos, "unrecognized option")
			}
			ps.next()
		}
		return
	case ax != "" && (rest == "label" || rest == "lab"):
		a := S.axes[ax]
		if ps.atEnd() {
			a.label = ""
			return
		}
		a.label = in.parseStringArg(ps)
		in.skipToEnd(ps)
		return
	case ax != "" && rest == "tics":
		in.setTics(ps, S.axes[ax])
		return
	case ax != "" && rest == "data":
		a := S.axes[ax]
		if ps.at("time") {
			ps.next()
			a.isTime = true
		} else {
			a.isTime = false
		}
		return
	case ax != "" && rest == "zeroaxis":
		if ax == "x" {
			S.xzeroaxis = true
		} else if ax == "y" {
			S.yzeroaxis = true
		}
		in.skipToEnd(ps)
		return
	case ax != "" && rest == "mtics" || (strings.HasPrefix(w, "m") && strings.HasSuffix(w, "tics")):
		an, _ := axisFromPrefix(w[1:])
		if an != "" {
			if !ps.atEnd() {
				S.axes[an].minor = int(toInt(in.evalExpr(ps)))
			} else {
				S.axes[an].minor = -1
			}
		}
		return
	}
	if ax != "" && (rest == "format" || rest == "") && w != "x" {
	}
	switch {
	case almostEquals(w, "tit$le"):
		if ps.atEnd() {
			S.title = ""
			return
		}
		S.title = in.parseStringArg(ps)
		in.skipToEnd(ps)
	case almostEquals(w, "sa$mples"):
		S.samples = int(toInt(in.evalExpr(ps)))
		S.samples2 = S.samples
		if ps.atOp(",") {
			ps.next()
			S.samples2 = int(toInt(in.evalExpr(ps)))
		}
	case almostEquals(w, "iso$samples"):
		S.iso1 = int(toInt(in.evalExpr(ps)))
		S.iso2 = S.iso1
		if ps.atOp(",") {
			ps.next()
			S.iso2 = int(toInt(in.evalExpr(ps)))
		}
	case almostEquals(w, "log$scale"):
		axes := "xyzx2y2cb"
		if !ps.atEnd() && ps.peek().Kind == TName {
			axes = ps.next().Text
		}
		base := 10.0
		if !ps.atEnd() {
			base = in.evalExpr(ps).Float()
		}
		for _, a := range parseAxisList(axes) {
			S.axes[a].log = true
			S.axes[a].base = base
		}
	case almostEquals(w, "st$yle"):
		in.setStyle(ps)
	case almostEquals(w, "form$at"):
		axes := "xyzx2y2cb"
		if ps.peek().Kind == TName {
			axes = ps.next().Text
		}
		f := "% h"
		if !ps.atEnd() {
			f = in.parseStringArg(ps)
		}
		in.skipToEnd(ps)
		for _, a := range parseAxisList(axes) {
			S.axes[a].format = f
		}
	case almostEquals(w, "k$ey"):
		in.setKey(ps)
	case almostEquals(w, "g$rid"):
		S.grid = true
		in.skipToEnd(ps)
	case almostEquals(w, "an$gles"):
		if ps.at("degrees") || ps.at("d") || ps.at("deg") {
			S.angles = "degrees"
			in.degrees = true
		} else {
			S.angles = "radians"
			in.degrees = false
		}
		ps.next()
	case almostEquals(w, "t$erminal"):
		in.setTerminal(ps)
	case almostEquals(w, "o$utput"):
		in.closeOutput()
		if ps.atEnd() {
			S.output = ""
		} else {
			S.output = in.parseStringArg(ps)
		}
	case almostEquals(w, "tab$le"):
		S.table = true
		S.tableDB = ""
		S.tableFile = ""
		if !ps.atEnd() {
			t := ps.peek()
			if t.Kind == TName && strings.HasPrefix(t.Text, "$") {
				ps.next()
				S.tableDB = t.Text
			} else {
				S.tableFile = in.parseStringArg(ps)
			}
		}
		in.skipToEnd(ps)
	case almostEquals(w, "pr$int"):
		in.setPrint(ps)
	case almostEquals(w, "dum$my"):
		if !ps.atEnd() && !ps.atOp(",") {
			S.dummy1 = ps.next().Text
		}
		if ps.atOp(",") {
			ps.next()
			S.dummy2 = ps.next().Text
		}
	case almostEquals(w, "dataf$ile"):
		in.setDatafile(ps)
	case almostEquals(w, "timef$mt"):
		S.timefmt = in.parseStringArg(ps)
	case almostEquals(w, "bor$der"):
		if !ps.atEnd() && ps.peek().Kind == TNum {
			S.border = int(toInt(in.evalExpr(ps)))
		}
		in.skipToEnd(ps)
	case almostEquals(w, "ze$ro"):
		S.zero = in.evalExpr(ps).Float()
	case almostEquals(w, "boxw$idth"):
		if !ps.atEnd() {
			S.boxwidth = in.evalExpr(ps).Float()
			S.boxwidthSet = true
		}
		in.skipToEnd(ps)
	case almostEquals(w, "lab$el"):
		in.setLabel(ps)
	case almostEquals(w, "fit"):
		in.setFit(ps)
	case almostEquals(w, "par$ametric"):
		S.parametric = true
	case almostEquals(w, "pol$ar"):
		S.polar = true
	case almostEquals(w, "vi$ew"):
		i := 0
		for !ps.atEnd() && i < 4 {
			if ps.atOp(",") {
				ps.next()
				i++
				continue
			}
			if ps.peek().Kind == TName {
				ps.next()
				continue
			}
			S.view[i] = in.evalExpr(ps).Float()
		}
	case almostEquals(w, "ticsl$evel"):
		S.ticslevel = in.evalExpr(ps).Float()
	case almostEquals(w, "xyp$lane"):
		if ps.at("at") {
			ps.next()
		}
		if ps.at("relative") {
			ps.next()
			S.ticslevel = in.evalExpr(ps).Float()
		} else {
			in.skipToEnd(ps)
		}
	case almostEquals(w, "hid$den3d"):
		S.hidden3d = true
		in.skipToEnd(ps)
	case almostEquals(w, "dec$imalsign"):
		in.skipToEnd(ps)
	case almostEquals(w, "mul$tiplot"):
		in.setMultiplot(ps)
	case almostEquals(w, "si$ze"):
		for !ps.atEnd() {
			if ps.peek().Kind == TName {
				ps.next()
				continue
			}
			S.sizeX = in.evalExpr(ps).Float()
			if ps.atOp(",") {
				ps.next()
				S.sizeY = in.evalExpr(ps).Float()
			}
		}
	case almostEquals(w, "or$igin"):
		S.originX = in.evalExpr(ps).Float()
		if ps.atOp(",") {
			ps.next()
			S.originY = in.evalExpr(ps).Float()
		}
	case almostEquals(w, "tic$s"):
		in.skipToEnd(ps)
	case almostEquals(w, "mxt$ics"):
		in.skipToEnd(ps)
	case almostEquals(w, "poi$ntsize"):
		S.pointsize = in.evalExpr(ps).Float()
	case almostEquals(w, "enc$oding"):
		in.skipToEnd(ps)
	case almostEquals(w, "sur$face"):
		S.surface = true
		in.skipToEnd(ps)
	case almostEquals(w, "cont$ours"):
		S.contour = true
		in.skipToEnd(ps)
	case almostEquals(w, "lmar$gin"), almostEquals(w, "rmar$gin"), almostEquals(w, "tmar$gin"), almostEquals(w, "bmar$gin"):
		var v float64 = -1
		if ps.at("at") {
			ps.next()
			if ps.at("screen") {
				ps.next()
			}
		}
		if !ps.atEnd() {
			v = in.evalExpr(ps).Float()
		}
		switch w[0] {
		case 'l':
			S.lmargin = v
		case 'r':
			S.rmargin = v
		case 't':
			S.tmargin = v
		case 'b':
			S.bmargin = v
		}
	case almostEquals(w, "mar$gins"):
		in.skipToEnd(ps)
	case almostEquals(w, "off$sets"):
		i := 0
		for !ps.atEnd() && i < 4 {
			if ps.atOp(",") {
				ps.next()
				i++
				continue
			}
			if ps.at("graph") || ps.at("first") {
				ps.next()
			}
			S.offsets[i] = in.evalExpr(ps).Float()
		}
	case almostEquals(w, "mac$ros"), almostEquals(w, "loa$dpath"), almostEquals(w, "colorseq$uence"), almostEquals(w, "cl$ip"),
		almostEquals(w, "pal$ette"), almostEquals(w, "colorb$ox"), almostEquals(w, "obj$ect"), almostEquals(w, "arr$ow"),
		almostEquals(w, "linet$ype"), almostEquals(w, "mou$se"), almostEquals(w, "termopt$ion"), almostEquals(w, "ps$dir"),
		almostEquals(w, "his$torysize"), almostEquals(w, "loc$ale"), almostEquals(w, "fontp$ath"), almostEquals(w, "mi$nussign"),
		almostEquals(w, "pm3d"), almostEquals(w, "map$ping"), almostEquals(w, "ra$xis"), almostEquals(w, "rt$ics"),
		almostEquals(w, "ttics"), almostEquals(w, "ji$tter"), almostEquals(w, "theta"), almostEquals(w, "view"),
		almostEquals(w, "cntrp$aram"), almostEquals(w, "cntrl$abel"), almostEquals(w, "dg$rid3d"), almostEquals(w, "isosurface"),
		almostEquals(w, "walls"), almostEquals(w, "link"), almostEquals(w, "nonlinear"), almostEquals(w, "debug"),
		almostEquals(w, "ov$erflow"), almostEquals(w, "auto$scale"), almostEquals(w, "bar$s"), almostEquals(w, "spid$erplot"),
		almostEquals(w, "vxr$ange"), almostEquals(w, "vyr$ange"), almostEquals(w, "vzr$ange"), almostEquals(w, "co$lor"), almostEquals(w, "monochrome"):
		in.skipToEnd(ps)
	default:
		if ax != "" && (rest == "tic" || rest == "tics") {
			in.skipToEnd(ps)
			return
		}
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

func parseAxisList(s string) []string {
	var r []string
	for len(s) > 0 {
		switch {
		case strings.HasPrefix(s, "x2"):
			r = append(r, "x2")
			s = s[2:]
		case strings.HasPrefix(s, "y2"):
			r = append(r, "y2")
			s = s[2:]
		case strings.HasPrefix(s, "cb"):
			r = append(r, "cb")
			s = s[2:]
		case s[0] == 'x' || s[0] == 'y' || s[0] == 'z' || s[0] == 'r':
			r = append(r, s[:1])
			s = s[1:]
		default:
			s = s[1:]
		}
	}
	return r
}

func (in *Interp) setTics(ps *Parser, a *Axis) {
	a.ticsOn = true
	for !ps.atEnd() {
		t := ps.peek()
		switch {
		case t.Text == "nomirror":
			a.mirror = false
			ps.next()
		case t.Text == "mirror":
			a.mirror = true
			ps.next()
		case t.Text == "format":
			ps.next()
			a.format = in.parseStringArg(ps)
		case t.Text == "rotate" || t.Text == "norotate" || t.Text == "border" || t.Text == "axis" || t.Text == "in" || t.Text == "out" || t.Text == "nooffset" || t.Text == "autojustify" || t.Text == "front" || t.Text == "back" || t.Text == "numeric" || t.Text == "timedate":
			ps.next()
			if t.Text == "rotate" && ps.at("by") {
				ps.next()
				in.evalExpr(ps)
			}
		case t.Text == "scale":
			ps.next()
			in.evalExpr(ps)
			if ps.atOp(",") {
				ps.next()
				in.evalExpr(ps)
			}
		case t.Text == "offset":
			ps.next()
			in.evalExpr(ps)
			for ps.atOp(",") {
				ps.next()
				in.evalExpr(ps)
			}
		case t.Text == "font" || t.Text == "textcolor" || t.Text == "tc":
			ps.next()
			in.evalExpr(ps)
		case t.Text == "add":
			ps.next()
		case t.Text == "auto" || t.Text == "autofreq":
			ps.next()
			a.ticStep = 0
			a.ticList = nil
			a.ticListOnly = false
		case t.Kind == TOp && t.Text == "(":
			ps.next()
			a.ticList = nil
			a.ticListOnly = true
			for !ps.atOp(")") && !ps.atEnd() {
				var lbl string
				hasLabel := false
				if in.isStringStart(ps) {
					lbl = in.parseStringArg(ps)
					hasLabel = true
				}
				pos := in.evalExpr(ps).Float()
				lv := 0
				if !ps.atOp(",") && !ps.atOp(")") {
					lv = int(toInt(in.evalExpr(ps)))
				}
				td := TicDef{label: lbl, pos: pos, level: lv}
				if !hasLabel {
					td.label = "\x00"
				}
				a.ticList = append(a.ticList, td)
				if ps.atOp(",") {
					ps.next()
				}
			}
			ps.next()
		default:
			v := in.evalExpr(ps).Float()
			if ps.atOp(",") {
				ps.next()
				a.ticStart = v
				a.ticStartSet = true
				a.ticStep = in.evalExpr(ps).Float()
				a.ticEnd = math.Inf(1)
				if ps.atOp(",") {
					ps.next()
					a.ticEnd = in.evalExpr(ps).Float()
				}
			} else {
				a.ticStep = v
				a.ticStartSet = false
			}
			a.ticListOnly = false
			a.ticList = nil
		}
	}
}

func (in *Interp) setStyle(ps *Parser) {
	S := in.S
	t := ps.next()
	switch {
	case almostEquals(t.Text, "d$ata"):
		S.dataStyle = in.parseStyleName(ps)
		in.skipToEnd(ps)
	case almostEquals(t.Text, "f$unction"):
		S.funcStyle = in.parseStyleName(ps)
		in.skipToEnd(ps)
	case almostEquals(t.Text, "fill"):
		for !ps.atEnd() {
			tk := ps.next()
			switch tk.Text {
			case "solid":
				S.fillStyle = "solid"
				if ps.peek().Kind == TNum {
					S.fillDensity = in.evalExpr(ps).Float()
				}
			case "empty":
				S.fillStyle = "empty"
			case "pattern":
				S.fillStyle = "pattern"
			}
		}
	case almostEquals(t.Text, "hist$ogram"):
		for !ps.atEnd() {
			tk := ps.next()
			if tk.Text == "clustered" || tk.Text == "rowstacked" || tk.Text == "columnstacked" || tk.Text == "errorbars" {
				S.histStyle = tk.Text
			}
		}
	default:
		in.skipToEnd(ps)
	}
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "i$mpulses", "d$ots", "s$teps", "fs$teps", "his$teps", "fillst$eps", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xyerrorb$ars", "errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "b$oxes", "boxerrorbars", "boxxyerror$bars", "boxplot", "candle$sticks", "financebars", "vec$tors", "fillc$urves", "filledc$urves", "his$tograms", "lab$els", "pm3d", "image", "rgbimage", "circles", "ellipses", "surface", "table", "zerror$fill", "arrows", "parallelaxes", "polygons", "spiderplot", "sectors", "rgba$lpha", "yerrorlines"}

func (in *Interp) parseStyleName(ps *Parser) string {
	t := ps.peek()
	if t.Kind != TName {
		gpErr(t.Pos, "expecting style name")
	}
	for _, sn := range styleNames {
		if almostEquals(t.Text, sn) {
			ps.next()
			full := strings.Replace(sn, "$", "", 1)
			if full == "lp" {
				full = "linespoints"
			}
			if full == "errorbars" {
				full = "yerrorbars"
			}
			if full == "errorlines" {
				full = "yerrorlines"
			}
			if full == "filledcurves" {
				full = "filledcurves"
			}
			return full
		}
	}
	gpErr(t.Pos, "unrecognized plot type")
	return ""
}

func (in *Interp) setKey(ps *Parser) {
	S := in.S
	S.keyOn = true
	for !ps.atEnd() {
		t := ps.next()
		switch t.Text {
		case "off":
			S.keyOn = false
		case "on":
			S.keyOn = true
		case "left", "right":
			S.keyHoriz = t.Text
		case "center":
			S.keyHoriz = "center"
		case "top", "bottom":
			S.keyVert = t.Text
		case "box":
			S.keyBox = true
		case "nobox":
			S.keyBox = false
		case "reverse":
			S.keyReverse = true
		case "noreverse":
			S.keyReverse = false
		case "Left":
			S.keyLeftJust = true
		case "Right":
			S.keyLeftJust = false
		case "outside":
			S.keyOutside = true
		case "inside":
			S.keyOutside = false
		case "title":
			if !ps.atEnd() && in.isStringStart(ps) {
				S.keyTitle = in.parseStringArg(ps)
			}
		case "default":
			S.keyHoriz, S.keyVert, S.keyBox, S.keyReverse, S.keyLeftJust, S.keyOutside = "right", "top", false, false, false, false
		case "at", "width", "height", "spacing", "samplen", "maxrows", "maxcols", "font", "textcolor", "tc", "lw", "linewidth", "lt", "linetype", "lc", "linecolor":
			if !ps.atEnd() {
				in.evalExpr(ps)
				for ps.atOp(",") {
					ps.next()
					in.evalExpr(ps)
				}
			}
		}
	}
}

func (in *Interp) setTerminal(ps *Parser) {
	S := in.S
	if ps.atEnd() {
		return
	}
	t := ps.next()
	name := t.Text
	switch {
	case almostEquals(name, "du$mb"):
		S.termName = "dumb"
		for !ps.atEnd() {
			tk := ps.peek()
			if tk.Text == "size" {
				ps.next()
				S.termW = int(toInt(in.evalExpr(ps)))
				if ps.atOp(",") {
					ps.next()
					S.termH = int(toInt(in.evalExpr(ps)))
				}
				continue
			}
			if tk.Text == "feed" {
				S.termFeed = true
			} else if tk.Text == "nofeed" {
				S.termFeed = false
			} else if tk.Kind == TNum {
				S.termW = int(toInt(in.evalExpr(ps)))
				if ps.atOp(",") {
					ps.next()
					S.termH = int(toInt(in.evalExpr(ps)))
				}
				continue
			}
			ps.next()
		}
	case almostEquals(name, "svg"):
		S.termName = "svg"
		S.termW, S.termH = 640, 480
		in.parseSizeOpts(ps)
	case almostEquals(name, "canvas"):
		S.termName = "canvas"
		S.termW, S.termH = 600, 400
		in.parseSizeOpts(ps)
	case name == "push" || name == "pop":
	case almostEquals(name, "unknown"):
		S.termName = "unknown"
	case almostEquals(name, "table"):
		S.termName = "table"
	default:
		S.termName = name
		in.skipToEnd(ps)
	}
}

func (in *Interp) parseSizeOpts(ps *Parser) {
	S := in.S
	for !ps.atEnd() {
		tk := ps.peek()
		if tk.Text == "size" {
			ps.next()
			S.termW = int(toInt(in.evalExpr(ps)))
			if ps.atOp(",") {
				ps.next()
				S.termH = int(toInt(in.evalExpr(ps)))
			}
			continue
		}
		ps.next()
	}
}

func (in *Interp) setPrint(ps *Parser) {
	if in.printFile != nil {
		in.printFile.Close()
		in.printFile = nil
	}
	in.printDB = ""
	if ps.atEnd() {
		in.printOut = in.stderr
		in.printName = ""
		return
	}
	t := ps.peek()
	if t.Kind == TName && strings.HasPrefix(t.Text, "$") {
		ps.next()
		in.printDB = t.Text
		appendMode := false
		if ps.at("append") {
			ps.next()
			appendMode = true
		}
		if _, ok := in.datablocks[t.Text]; !ok || !appendMode {
			if !ok {
				in.dbOrder = append(in.dbOrder, t.Text)
			}
			in.datablocks[t.Text] = nil
		}
		return
	}
	name := in.parseStringArg(ps)
	appendMode := false
	if ps.at("append") {
		ps.next()
		appendMode = true
	}
	in.printName = name
	if name == "-" {
		in.printOut = in.stdout
		return
	}
	in.flush()
	flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
	if appendMode {
		flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
	}
	f, err := os.OpenFile(name, flags, 0644)
	if err != nil {
		gpErrNC("cannot open print output file")
	}
	in.printFile = f
	in.printOut = f
}

func (in *Interp) setDatafile(ps *Parser) {
	S := in.S
	t := ps.next()
	switch {
	case almostEquals(t.Text, "sep$arators"):
		if ps.atEnd() {
			S.sep = ""
			return
		}
		if ps.at("whitespace") {
			ps.next()
			S.sep = ""
			return
		}
		if ps.at("tab") {
			ps.next()
			S.sep = "\t"
			return
		}
		if ps.at("comma") {
			ps.next()
			S.sep = ","
			return
		}
		S.sep = in.parseStringArg(ps)
	case almostEquals(t.Text, "miss$ing"):
		if ps.atEnd() {
			S.missing = ""
			return
		}
		S.missing = in.parseStringArg(ps)
	case almostEquals(t.Text, "com$mentschars"):
		if ps.atEnd() {
			S.comments = "#"
			return
		}
		S.comments = in.parseStringArg(ps)
	case almostEquals(t.Text, "columnhead$ers"):
		S.headerAuto = true
	case almostEquals(t.Text, "nocolumnhead$ers"):
		S.headerAuto = false
	default:
		in.skipToEnd(ps)
	}
}

func (in *Interp) setLabel(ps *Parser) {
	S := in.S
	tag := 0
	if ps.peek().Kind == TNum {
		tag = int(toInt(in.evalExpr(ps)))
	}
	if tag == 0 {
		tag = 1
		for _, l := range S.labels {
			if l.tag >= tag {
				tag = l.tag + 1
			}
		}
	}
	var lbl *Label
	for _, l := range S.labels {
		if l.tag == tag {
			lbl = l
		}
	}
	if lbl == nil {
		lbl = &Label{tag: tag, just: "left"}
		// insert sorted
		idx := len(S.labels)
		for i, l := range S.labels {
			if l.tag > tag {
				idx = i
				break
			}
		}
		S.labels = append(S.labels, nil)
		copy(S.labels[idx+1:], S.labels[idx:])
		S.labels[idx] = lbl
	}
	if !ps.atEnd() && in.isStringStart(ps) {
		lbl.text = in.parseStringArg(ps)
	}
	for !ps.atEnd() {
		t := ps.next()
		switch t.Text {
		case "at":
			lbl.coord = "first"
			if ps.at("first") || ps.at("graph") || ps.at("screen") || ps.at("character") {
				lbl.coord = ps.next().Text
			}
			lbl.x = in.evalExpr(ps).Float()
			ps.expect(",", "expecting ','")
			if ps.at("first") || ps.at("graph") || ps.at("screen") || ps.at("character") {
				ps.next()
			}
			lbl.y = in.evalExpr(ps).Float()
			if ps.atOp(",") {
				ps.next()
				in.evalExpr(ps)
			}
		case "left", "right", "center", "centre":
			lbl.just = t.Text
		case "font", "textcolor", "tc", "offset", "rotate", "point", "pt", "lt", "lc":
			if t.Text == "offset" {
				if ps.at("character") || ps.at("graph") {
					ps.next()
				}
				in.evalExpr(ps)
				for ps.atOp(",") {
					ps.next()
					in.evalExpr(ps)
				}
			} else if !ps.atEnd() && ps.peek().Kind != TName {
				in.evalExpr(ps)
			}
		}
	}
}

func (in *Interp) setFit(ps *Parser) {
	S := in.S
	for !ps.atEnd() {
		t := ps.next()
		switch t.Text {
		case "nolog":
			S.fitLog = ""
		case "logfile":
			if !ps.atEnd() && in.isStringStart(ps) {
				S.fitLog = in.parseStringArg(ps)
			} else {
				S.fitLog = "fit.log"
			}
		case "quiet":
			S.fitQuiet = true
		case "noquiet":
			S.fitQuiet = false
		case "errorvariables":
			S.fitErrVars = true
		case "noerrorvariables":
			S.fitErrVars = false
		case "limit":
			S.fitLimit = in.evalExpr(ps).Float()
		case "maxiter":
			S.fitMaxIter = int(toInt(in.evalExpr(ps)))
		case "prescale":
			S.fitPrescale = true
		case "noprescale":
			S.fitPrescale = false
		case "verbose", "brief", "results", "covariancevariables", "nocovariancevariables":
		case "lambda_factor":
			S.fitLambdaFactor = in.evalExpr(ps).Float()
		case "start_lambda":
			S.fitStartLambda = in.evalExpr(ps).Float()
		}
	}
}

func (in *Interp) cmdUnset(ps *Parser) {
	S := in.S
	t := ps.peek()
	if t.Kind != TName {
		gpErr(t.Pos, "unrecognized option - see 'help unset'.")
	}
	w := t.Text
	ps.next()
	ax, rest := axisFromPrefix(w)
	switch {
	case ax != "" && rest == "range":
		a := S.axes[ax]
		a.autoMin, a.autoMax = true, true
		return
	case ax != "" && rest == "label":
		S.axes[ax].label = ""
		return
	case ax != "" && rest == "tics":
		S.axes[ax].ticsOn = false
		return
	case ax != "" && rest == "data":
		S.axes[ax].isTime = false
		return
	case ax != "" && rest == "zeroaxis":
		return
	}
	switch {
	case almostEquals(w, "tit$le"):
		S.title = ""
	case almostEquals(w, "k$ey"):
		S.keyOn = false
	case almostEquals(w, "log$scale"):
		axes := "xyzx2y2cbr"
		if !ps.atEnd() {
			axes = ps.next().Text
		}
		for _, a := range parseAxisList(axes) {
			S.axes[a].log = false
		}
	case almostEquals(w, "tab$le"):
		S.table = false
	case almostEquals(w, "pr$int"):
		in.setPrint(ps)
	case almostEquals(w, "g$rid"):
		S.grid = false
	case almostEquals(w, "bor$der"):
		S.border = 0
	case almostEquals(w, "lab$el"):
		if ps.atEnd() {
			S.labels = nil
		} else {
			tag := int(toInt(in.evalExpr(ps)))
			for i, l := range S.labels {
				if l.tag == tag {
					S.labels = append(S.labels[:i], S.labels[i+1:]...)
					break
				}
			}
		}
	case almostEquals(w, "tic$s"):
		for _, a := range S.axes {
			a.ticsOn = false
		}
	case almostEquals(w, "par$ametric"):
		S.parametric = false
	case almostEquals(w, "pol$ar"):
		S.polar = false
	case almostEquals(w, "mul$tiplot"):
		in.endMultiplot()
	case almostEquals(w, "o$utput"):
		in.closeOutput()
		S.output = ""
	case almostEquals(w, "hid$den3d"):
		S.hidden3d = false
	case almostEquals(w, "sur$face"):
		S.surface = false
	case almostEquals(w, "cont$ours"):
		S.contour = false
	case almostEquals(w, "t$erminal"):
		S.termName = "unknown"
	default:
		in.skipToEnd(ps)
	}
	in.skipToEnd(ps)
}

func fmtShowNum(f float64) string {
	return cfmt("%g", f)
}

func (in *Interp) cmdShow(ps *Parser) {
	S := in.S
	w := in.stderr
	t := ps.peek()
	if t.Kind != TName {
		gpErr(t.Pos, "unrecognized option - see 'help show'.")
	}
	name := t.Text
	ps.next()
	ax, rest := axisFromPrefix(name)
	if ax != "" && rest == "range" {
		a := S.axes[ax]
		fmt.Fprintf(w, "\n\tset %srange [ %s : %s ] %s nowriteback", ax, rangeEnd(a.min, a.autoMin), rangeEnd(a.max, a.autoMax), map[bool]string{true: "reverse", false: "noreverse"}[a.reverse])
		if a.autoMin || a.autoMax {
			cmin, cmax := a.min, a.max
			if a.everSet {
				cmin, cmax = a.curMin, a.curMax
			}
			fmt.Fprintf(w, "  # (currently [%s:%s] )", cfmt("%#g", cmin), cfmt("%#g", cmax))
		}
		fmt.Fprintf(w, "\n\n")
		return
	}
	if ax != "" && rest == "label" {
		fmt.Fprintf(w, "\n\t%slabel is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", ax, S.axes[ax].label)
		return
	}
	switch {
	case almostEquals(name, "v$ariables"):
		in.showVariables(ps)
	case almostEquals(name, "f$unctions"):
		fmt.Fprintf(w, "\n\tUser-Defined Functions:\n")
		for _, n := range in.funcOrder {
			if f, ok := in.funcs[n]; ok {
				fmt.Fprintf(w, "\t%s\n", f.text)
			}
		}
		fmt.Fprintf(w, "\n")
	case almostEquals(name, "sa$mples"):
		fmt.Fprintf(w, "\n\tsampling rate is %d, %d\n\n", S.samples, S.samples2)
	case almostEquals(name, "iso$samples"):
		fmt.Fprintf(w, "\n\tiso sampling rate is %d, %d\n\n", S.iso1, S.iso2)
	case almostEquals(name, "tit$le"):
		fmt.Fprintf(w, "\n\ttitle is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", S.title)
	case almostEquals(name, "log$scale"):
		s := ""
		for _, a := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			ax := S.axes[a]
			if ax.log {
				if ax.base == 10 {
					s += " " + a
				} else {
					s += fmt.Sprintf(" %s (base %s)", a, cfmt("%g", ax.base))
				}
			}
		}
		if s == "" {
			s = "none"
		}
		fmt.Fprintf(w, "\n\tlogscaling on %s\n\n", s)
	case almostEquals(name, "st$yle"):
		if ps.at("data") {
			ps.next()
			fmt.Fprintf(w, "\n\tData are plotted with %s\n\n", S.dataStyle)
		} else if ps.at("function") {
			ps.next()
			fmt.Fprintf(w, "\n\tFunctions are plotted with %s\n\n", S.funcStyle)
		} else {
			in.skipToEnd(ps)
		}
	case almostEquals(name, "an$gles"):
		fmt.Fprintf(w, "\n\tAngles are in %s\n\n", S.angles)
	case almostEquals(name, "form$at"):
		fmt.Fprintf(w, "\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			fmt.Fprintf(w, "\t  %s-axis: \"%s\"\n", a, S.axes[a].format)
		}
		fmt.Fprintf(w, "\n")
	case almostEquals(name, "g$rid"):
		if !S.grid {
			fmt.Fprintf(w, "\n\tgrid is OFF\n\n")
		} else {
			fmt.Fprintf(w, "\n\tRectangular grid drawn at x y tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case almostEquals(name, "dum$my"):
		fmt.Fprintf(w, "\n\tdummy variables are %s %s \n\n", S.dummy1, S.dummy2)
	case almostEquals(name, "t$erminal"):
		if S.termName == "dumb" {
			feed := "feed"
			if !S.termFeed {
				feed = "nofeed"
			}
			fmt.Fprintf(w, "\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", feed, S.termW, S.termH)
		} else {
			fmt.Fprintf(w, "\n   terminal type is %s \n\n", S.termName)
		}
	case almostEquals(name, "o$utput"):
		if S.output == "" {
			fmt.Fprintf(w, "\n\toutput is sent to STDOUT\n\n")
		} else {
			fmt.Fprintf(w, "\n\toutput is sent to '%s'\n\n", S.output)
		}
	case almostEquals(name, "ze$ro"):
		fmt.Fprintf(w, "\n\tzero is %s\n\n", cfmt("%g", S.zero))
	case almostEquals(name, "timef$mt"):
		fmt.Fprintf(w, "\n\tDefault format for reading time data is \"%s\"\n\n", S.timefmt)
	case almostEquals(name, "ver$sion"):
		fmt.Fprintf(w, "\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		in.skipToEnd(ps)
	case almostEquals(name, "bor$der"):
		fmt.Fprintf(w, "\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.border, S.border)
	case almostEquals(name, "si$ze"):
		fmt.Fprintf(w, "\n\tsize is scaled by %s,%s\n\tNo attempt to control aspect ratio\n\n", cfmt("%g", S.sizeX), cfmt("%g", S.sizeY))
	case almostEquals(name, "or$igin"):
		fmt.Fprintf(w, "\n\torigin is set to %s,%s\n\n", cfmt("%g", S.originX), cfmt("%g", S.originY))
	case almostEquals(name, "dataf$ile"):
		in.skipToEnd(ps)
		fmt.Fprintf(w, "\n")
		if S.missing == "" {
			fmt.Fprintf(w, "\tNo missing data string set for datafile\n")
		} else {
			fmt.Fprintf(w, "\t\"%s\" in datafile is interpreted as missing value\n", S.missing)
		}
		if S.sep == "" {
			fmt.Fprintf(w, "\tdatafile fields separated by whitespace\n")
		} else {
			fmt.Fprintf(w, "\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.sep), S.sep)
		}
		fmt.Fprintf(w, "\tComments chars are \"%s\"\n", S.comments)
		if S.headerAuto {
			fmt.Fprintf(w, "\tFirst line is treated as headers\n")
		} else {
			fmt.Fprintf(w, "\tFirst line is treated as headers only if accessed explicitly\n")
		}
		fmt.Fprintf(w, "\n")
	case almostEquals(name, "k$ey"):
		in.showKey()
	case almostEquals(name, "lab$el"):
		for _, l := range S.labels {
			fmt.Fprintf(w, "\tlabel %d \"%s\" at %s %s, %s %s, %s %s %s not rotated back lt black norotate\n", l.tag, l.text, l.coord, cfmt("%g", l.x), l.coord, cfmt("%g", l.y), l.coord, "0", l.just)
		}
		fmt.Fprintf(w, "\n")
	default:
		in.skipToEnd(ps)
	}
	in.skipToEnd(ps)
}

func (in *Interp) showKey() {
	S := in.S
	w := in.stderr
	if !S.keyOn {
		fmt.Fprintf(w, "\n\tkey is OFF\n\n")
		return
	}
	box := "not boxed"
	if S.keyBox {
		box = "boxed\n\twith  lt black linewidth 1.000 dashtype solid"
	}
	just := "right"
	if S.keyLeftJust {
		just = "left"
	}
	rev := "not reversed"
	if S.keyReverse {
		rev = "reversed"
	}
	fmt.Fprintf(w, "\n\tkey is ON, position: %s %s vertical fixed  offset: (character 0, 0)\n", S.keyVert, S.keyHoriz)
	fmt.Fprintf(w, "\tkey is %s justified, %s, not inverted, enhanced and %s\n", just, rev, box)
	fmt.Fprintf(w, "\tsample length is 4 characters\n\tvertical spacing is 1 characters\n\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n\n")
	fmt.Fprintf(w, "\tkey title is \"%s\" center justified \n\n", S.keyTitle)
}

func rangeEnd(v float64, auto bool) string {
	if auto {
		return "*"
	}
	return cfmt("%#g", v)
}

func (in *Interp) showVariables(ps *Parser) {
	w := in.stderr
	all := false
	prefix := ""
	if ps.at("all") {
		ps.next()
		all = true
	} else if !ps.atEnd() {
		prefix = ps.next().Text
	}
	if prefix != "" {
		fmt.Fprintf(w, "\n\tVariables beginning with %s:\n", prefix)
	} else {
		fmt.Fprintf(w, "\n\tUser and default variables:\n")
	}
	for _, n := range in.varOrder {
		v, ok := in.vars[n]
		if !ok {
			continue
		}
		if prefix != "" && !strings.HasPrefix(n, prefix) {
			continue
		}
		if !all && prefix == "" && strings.HasPrefix(n, "GPVAL_") {
			continue
		}
		if prefix == "" && (n == "GNUTERM") && !all {
			continue
		}
		switch v.K {
		case KArr:
			fmt.Fprintf(w, "\t%s = <%d element array>\n", n, len(v.Arr.vals))
		case KUndef:
		default:
			fmt.Fprintf(w, "\t%s = %s\n", n, v.Repr())
		}
	}
	fmt.Fprintf(w, "\n")
}
