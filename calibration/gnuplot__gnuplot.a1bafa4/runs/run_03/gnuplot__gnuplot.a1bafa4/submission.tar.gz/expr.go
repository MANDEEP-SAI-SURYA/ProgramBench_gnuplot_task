package main

import (
	"math"
	"math/cmplx"
	"strings"
)

type Node interface {
	Eval(in *Interp) Value
}

type Parser struct {
	toks []Token
	p    int
	in   *Interp
}

func (ps *Parser) peek() *Token { return &ps.toks[ps.p] }
func (ps *Parser) at(s string) bool {
	t := &ps.toks[ps.p]
	return (t.Kind == TOp || t.Kind == TName) && t.Text == s
}
func (ps *Parser) atOp(s string) bool {
	t := &ps.toks[ps.p]
	return t.Kind == TOp && t.Text == s
}
func (ps *Parser) next() *Token {
	t := &ps.toks[ps.p]
	if t.Kind != TEnd {
		ps.p++
	}
	return t
}
func (ps *Parser) atEnd() bool {
	t := ps.peek()
	return t.Kind == TEnd || (t.Kind == TOp && t.Text == ";")
}
func (ps *Parser) expect(s string, msg string) {
	if !ps.at(s) {
		gpErr(ps.peek().Pos, msg)
	}
	ps.next()
}

// ---------- nodes -----------
type constNode struct{ v Value }

func (n *constNode) Eval(in *Interp) Value { return n.v }

type varNode struct {
	name string
	pos  int
}

func (n *varNode) Eval(in *Interp) Value {
	if v, ok := in.lookupVar(n.name); ok {
		if v.K == KUndef {
			gpErrNC("undefined variable: " + n.name)
		}
		return v
	}
	if strings.HasPrefix(n.name, "$") {
		if db, ok := in.datablocks[n.name]; ok {
			_ = db
			return Value{K: KDatablock, S: n.name}
		}
	}
	gpErrNC("undefined variable: " + n.name)
	return Value{}
}

type colNode struct {
	col int
	pos int
}

func (n *colNode) Eval(in *Interp) Value { return in.columnValue(IntV(int64(n.col)), n.pos) }

type callNode struct {
	name string
	args []Node
	pos  int
}

type binNode struct {
	op   string
	l, r Node
	pos  int
}

type unNode struct {
	op string
	x  Node
}

type ternNode struct{ c, a, b Node }
type assignNode struct {
	name string
	op   string
	x    Node
}
type arrAssignNode struct {
	name string
	idx  Node
	x    Node
}
type indexNode struct {
	x, idx Node
	pos    int
}
type substrNode struct {
	x, a, b Node
}
type cardNode struct {
	x   Node
	pos int
}
type sumNode struct {
	v      string
	lo, hi Node
	body   Node
}
type cmplxNode struct{ re, im Node }
type seqNode struct{ a, b Node }
type factNode struct{ x Node }

func (n *cmplxNode) Eval(in *Interp) Value {
	re := n.re.Eval(in).num()
	im := n.im.Eval(in).num()
	return CmplxV(re.Float(), im.Float())
}

func (n *seqNode) Eval(in *Interp) Value {
	n.a.Eval(in)
	return n.b.Eval(in)
}

func (n *factNode) Eval(in *Interp) Value {
	v := n.x.Eval(in).num()
	if v.K != KInt {
		gpErrNC("factorial (!) argument must be an integer")
	}
	r := 1.0
	for i := int64(2); i <= v.I; i++ {
		r *= float64(i)
	}
	if v.I <= 20 {
		ri := int64(1)
		for i := int64(2); i <= v.I; i++ {
			ri *= i
		}
		return IntV(ri)
	}
	return FloatV(r)
}

func (n *ternNode) Eval(in *Interp) Value {
	c := n.c.Eval(in).num()
	if isTrue(c) {
		return n.a.Eval(in)
	}
	return n.b.Eval(in)
}

func isTrue(v Value) bool {
	switch v.K {
	case KInt:
		return v.I != 0
	case KFloat:
		return v.Re != 0
	case KCmplx:
		return v.Re != 0 || v.Im != 0
	}
	return false
}

func (n *assignNode) Eval(in *Interp) Value {
	v := n.x.Eval(in)
	if n.op != "=" {
		old, ok := in.lookupVar(n.name)
		if !ok {
			gpErrNC("undefined variable: " + n.name)
		}
		v = arith(in, n.op[:1], old, v, -1)
	}
	if v.K == KDatablock {
		v = StrV(v.S)
	}
	in.setVar(n.name, v)
	return v
}

func (n *arrAssignNode) Eval(in *Interp) Value {
	av, ok := in.vars[n.name]
	if !ok || av.K != KArr {
		gpErrNC("undefined variable: " + n.name)
	}
	idx := n.idx.Eval(in).num()
	i := int(idx.Float())
	if idx.K == KInt {
		i = int(idx.I)
	}
	v := n.x.Eval(in)
	if i < 1 || i > len(av.Arr.vals) {
		gpErrNC("array index out of range")
	}
	if v.K == KArr {
		gpErrNC("Cannot nest arrays")
	}
	av.Arr.vals[i-1] = v
	return v
}

func (n *indexNode) Eval(in *Interp) Value {
	a := n.x.Eval(in)
	if a.K != KArr {
		gpErrNC("internal error: substring range operator applied to non-STRING type")
	}
	idx := n.idx.Eval(in).num()
	var i int64
	if idx.K == KInt {
		i = idx.I
	} else {
		i = int64(idx.Float())
	}
	if i < 1 || i > int64(len(a.Arr.vals)) {
		gpErrNC("array index out of range")
	}
	v := a.Arr.vals[i-1]
	if v.K == KUndef {
		gpErrNC("undefined array element")
	}
	return v
}

func (n *substrNode) Eval(in *Interp) Value {
	s := n.x.Eval(in)
	if s.K == KArr {
		// array slice
		l := int64(len(s.Arr.vals))
		a := int64(1)
		b := l
		if n.a != nil {
			a = toInt(n.a.Eval(in))
		}
		if n.b != nil {
			b = toInt(n.b.Eval(in))
		}
		if a < 1 {
			a = 1
		}
		if b > l {
			b = l
		}
		na := &Array{}
		for i := a; i <= b; i++ {
			na.vals = append(na.vals, s.Arr.vals[i-1])
		}
		return Value{K: KArr, Arr: na}
	}
	if s.K != KStr {
		gpErrNC("internal error: substring range operator applied to non-STRING type")
	}
	l := int64(len([]rune(s.S)))
	a := int64(1)
	b := l
	if n.a != nil {
		a = toInt(n.a.Eval(in))
	}
	if n.b != nil {
		b = toInt(n.b.Eval(in))
	}
	if a < 1 {
		a = 1
	}
	if b > l {
		b = l
	}
	r := []rune(s.S)
	if a > b {
		return StrV("")
	}
	return StrV(string(r[a-1 : b]))
}

func toInt(v Value) int64 {
	v = v.num()
	if v.K == KInt {
		return v.I
	}
	return int64(v.Float())
}

func (n *cardNode) Eval(in *Interp) Value {
	v := n.x.Eval(in)
	if v.K == KArr {
		return IntV(int64(len(v.Arr.vals)))
	}
	if v.K == KDatablock {
		return IntV(int64(len(in.datablocks[v.S])))
	}
	gpErr(n.pos, "not an array")
	return Value{}
}

func (n *sumNode) Eval(in *Interp) Value {
	lo := toInt(n.lo.Eval(in))
	hi := toInt(n.hi.Eval(in))
	var acc Value = IntV(0)
	old, had := in.vars[n.v]
	for i := lo; i <= hi; i++ {
		in.vars[n.v] = IntV(i)
		acc = arith(in, "+", acc, n.body.Eval(in), -1)
	}
	if had {
		in.vars[n.v] = old
	} else {
		in.vars[n.v] = IntV(hi + 1)
		if hi < lo {
			in.vars[n.v] = IntV(lo)
		}
	}
	return acc
}

func (n *unNode) Eval(in *Interp) Value {
	v := n.x.Eval(in)
	switch n.op {
	case "-":
		v = v.num()
		switch v.K {
		case KInt:
			return IntV(-v.I)
		case KFloat:
			return FloatV(-v.Re)
		case KCmplx:
			return CmplxV(-v.Re, -v.Im)
		}
	case "+":
		return v.num()
	case "!":
		v = v.num()
		return BoolV(!isTrue(v))
	case "~":
		v = v.num()
		if v.K != KInt {
			gpErrNC("~ only defined for integers")
		}
		return IntV(^v.I)
	}
	return v
}

func (n *binNode) Eval(in *Interp) Value {
	switch n.op {
	case "&&":
		l := n.l.Eval(in).num()
		if !isTrue(l) {
			return IntV(0)
		}
		r := n.r.Eval(in).num()
		return BoolV(isTrue(r))
	case "||":
		l := n.l.Eval(in).num()
		if isTrue(l) {
			return IntV(1)
		}
		r := n.r.Eval(in).num()
		return BoolV(isTrue(r))
	}
	l := n.l.Eval(in)
	r := n.r.Eval(in)
	return arith(in, n.op, l, r, n.pos)
}

func toStrOp(v Value) string {
	if v.K != KStr {
		gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable")
	}
	return v.S
}

func arith(in *Interp, op string, l, r Value, pos int) Value {
	switch op {
	case ".":
		ls := toStrOp(l)
		if r.K == KInt {
			return StrV(ls + r.String())
		}
		return StrV(ls + toStrOp(r))
	case "eq":
		return BoolV(toStrOp(l) == toStrOp(r))
	case "ne":
		return BoolV(toStrOp(l) != toStrOp(r))
	}
	l = l.num()
	r = r.num()
	if l.K == KInt && r.K == KInt {
		a, b := l.I, r.I
		switch op {
		case "+":
			s := a + b
			if (a >= 0) == (b >= 0) && (s >= 0) != (a >= 0) {
				return FloatV(float64(a) + float64(b))
			}
			return IntV(s)
		case "-":
			s := a - b
			if (a >= 0) != (b >= 0) && (s >= 0) != (a >= 0) {
				return FloatV(float64(a) - float64(b))
			}
			return IntV(s)
		case "*":
			if a != 0 && b != 0 {
				p := a * b
				if p/b != a || (a == -1 && b == math.MinInt64) || (b == -1 && a == math.MinInt64) {
					return FloatV(float64(a) * float64(b))
				}
				return IntV(p)
			}
			return IntV(0)
		case "/":
			if b == 0 {
				in.undef = true
				return IntV(0)
			}
			return IntV(a / b)
		case "%":
			if b == 0 {
				in.undef = true
				return IntV(0)
			}
			return IntV(a % b)
		case "**":
			if b < 0 {
				if a == 1 {
					return IntV(1)
				}
				if a == -1 {
					if b%2 == 0 {
						return IntV(1)
					}
					return IntV(-1)
				}
				if a == 0 {
					in.undef = true
					return IntV(0)
				}
				return FloatV(math.Pow(float64(a), float64(b)))
			}
			res := int64(1)
			overflow := false
			for i := int64(0); i < b; i++ {
				nr := res * a
				if a != 0 && nr/a != res {
					overflow = true
					break
				}
				res = nr
			}
			if overflow {
				return FloatV(math.Pow(float64(a), float64(b)))
			}
			return IntV(res)
		case "==":
			return BoolV(a == b)
		case "!=":
			return BoolV(a != b)
		case "<":
			return BoolV(a < b)
		case ">":
			return BoolV(a > b)
		case "<=":
			return BoolV(a <= b)
		case ">=":
			return BoolV(a >= b)
		case "&":
			return IntV(a & b)
		case "|":
			return IntV(a | b)
		case "^":
			return IntV(a ^ b)
		case "<<":
			return IntV(a << uint64(b))
		case ">>":
			return IntV(a >> uint64(b))
		}
	}
	switch op {
	case "%":
		gpErrNC("non-integer operand for %")
	case "&", "|", "^", "<<", ">>":
		gpErrNC("non-integer operand for " + op)
	}
	if l.K == KCmplx || r.K == KCmplx {
		a := complex(l.Float(), l.Imag())
		b := complex(r.Float(), r.Imag())
		var c complex128
		switch op {
		case "+":
			c = a + b
		case "-":
			c = a - b
		case "*":
			c = a * b
		case "/":
			if b == 0 {
				in.undef = true
				return IntV(0)
			}
			c = a / b
		case "**":
			if a == 0 {
				return FloatV(0)
			}
			c = cmplx.Pow(a, b)
		case "==":
			return BoolV(a == b)
		case "!=":
			return BoolV(a != b)
		case "<":
			return BoolV(real(a) < real(b))
		case ">":
			return BoolV(real(a) > real(b))
		case "<=":
			return BoolV(real(a) <= real(b))
		case ">=":
			return BoolV(real(a) >= real(b))
		}
		return CmplxV(real(c), imag(c))
	}
	a := l.Float()
	b := r.Float()
	switch op {
	case "+":
		return FloatV(a + b)
	case "-":
		return FloatV(a - b)
	case "*":
		return FloatV(a * b)
	case "/":
		if b == 0 {
			in.undef = true
			return FloatV(0)
		}
		return FloatV(a / b)
	case "**":
		if a < 0 && b != math.Floor(b) {
			c := cmplx.Pow(complex(a, 0), complex(b, 0))
			return CmplxV(real(c), imag(c))
		}
		if a == 0 && b < 0 {
			in.undef = true
			return FloatV(0)
		}
		return FloatV(math.Pow(a, b))
	case "==":
		return BoolV(a == b)
	case "!=":
		return BoolV(a != b)
	case "<":
		return BoolV(a < b)
	case ">":
		return BoolV(a > b)
	case "<=":
		return BoolV(a <= b)
	case ">=":
		return BoolV(a >= b)
	}
	return IntV(0)
}

// ---------- parser -----------

func (ps *Parser) parseExpr() Node {
	t := ps.peek()
	if t.Kind == TEnd || (t.Kind == TOp && t.Text == ";") {
		gpErr(t.Pos, "constant expression required")
	}
	return ps.parseAssign()
}

func (ps *Parser) parseAssign() Node {
	t := ps.peek()
	if t.Kind == TName && !strings.HasPrefix(t.Text, "$") {
		nt := ps.toks[ps.p+1]
		if nt.Kind == TOp && (nt.Text == "=" || nt.Text == "+=" || nt.Text == "-=" || nt.Text == "*=" || nt.Text == "/=") {
			if nt.Text != "=" {
				// gnuplot 5.4 does not support these operators in expressions
				gpErr(nt.Pos, "invalid expression ")
			}
			ps.p += 2
			x := ps.parseAssign()
			return &assignNode{name: t.Text, op: nt.Text, x: x}
		}
	}
	return ps.parseTernary()
}

func (ps *Parser) parseTernary() Node {
	c := ps.parseBin(0)
	if ps.atOp("?") {
		ps.next()
		a := ps.parseTernary()
		if !ps.atOp(":") {
			gpErr(ps.peek().Pos, "expecting ':'")
		}
		ps.next()
		b := ps.parseTernary()
		return &ternNode{c, a, b}
	}
	return c
}

var binLevels = [][]string{
	{"||"},
	{"&&"},
	{"|"},
	{"^"},
	{"&"},
	{"==", "!=", "eq", "ne"},
	{"<", "<=", ">", ">="},
	{"<<", ">>"},
	{"+", "-", "."},
	{"*", "/", "%"},
}

func (ps *Parser) parseBin(level int) Node {
	if level >= len(binLevels) {
		return ps.parseUnary()
	}
	l := ps.parseBin(level + 1)
	for {
		t := ps.peek()
		if t.Kind != TOp && t.Kind != TName {
			return l
		}
		found := false
		for _, o := range binLevels[level] {
			if t.Text == o {
				found = true
				break
			}
		}
		if !found {
			return l
		}
		ps.next()
		if level <= 1 {
			r := ps.parseBin(level + 1)
			l = &binNode{op: t.Text, l: l, r: r, pos: t.Pos}
			continue
		}
		r := ps.parseBin(level + 1)
		l = &binNode{op: t.Text, l: l, r: r, pos: t.Pos}
	}
}

func (ps *Parser) parseUnary() Node {
	t := ps.peek()
	if t.Kind == TOp && (t.Text == "-" || t.Text == "+" || t.Text == "!" || t.Text == "~") {
		ps.next()
		x := ps.parseUnary()
		return &unNode{op: t.Text, x: x}
	}
	return ps.parsePow()
}

func (ps *Parser) parsePow() Node {
	b := ps.parsePostfix()
	if ps.atOp("**") {
		t := ps.next()
		e := ps.parseUnary()
		return &binNode{op: "**", l: b, r: e, pos: t.Pos}
	}
	return b
}

func (ps *Parser) parsePostfix() Node {
	x := ps.parsePrimary()
	for {
		if ps.atOp("!") && !(ps.toks[ps.p+1].Kind == TOp && ps.toks[ps.p+1].Text == "=") {
			ps.next()
			x = &factNode{x}
			continue
		}
		if ps.atOp("[") {
			lb := ps.next()
			var a, b Node
			if !ps.atOp(":") {
				a = ps.parseExpr()
			}
			if ps.atOp("]") {
				ps.next()
				if a == nil {
					gpErr(ps.peek().Pos, "invalid expression ")
				}
				x = &indexNode{x: x, idx: a, pos: lb.Pos}
				continue
			}
			if !ps.atOp(":") {
				gpErr(ps.peek().Pos, "':' expected")
			}
			ps.next()
			if !ps.atOp("]") {
				b = ps.parseExpr()
			}
			if !ps.atOp("]") {
				gpErr(ps.peek().Pos, "']' expected")
			}
			ps.next()
			x = &substrNode{x: x, a: a, b: b}
			continue
		}
		return x
	}
}

func (ps *Parser) parsePrimary() Node {
	t := ps.peek()
	switch t.Kind {
	case TNum:
		ps.next()
		if t.IsInt {
			return &constNode{IntV(t.IVal)}
		}
		return &constNode{FloatV(t.FVal)}
	case TStr:
		ps.next()
		return &constNode{StrV(t.Str)}
	case TName:
		name := t.Text
		if name == "sum" && ps.toks[ps.p+1].Kind == TOp && ps.toks[ps.p+1].Text == "[" {
			ps.p += 2
			vt := ps.next()
			if vt.Kind != TName {
				gpErr(vt.Pos, "Expecting a variable name")
			}
			ps.expect("=", "Expecting '='")
			lo := ps.parseExpr()
			ps.expect(":", "Expecting ':'")
			hi := ps.parseExpr()
			ps.expect("]", "Expecting ']'")
			body := ps.parseUnaryForSum()
			return &sumNode{v: vt.Text, lo: lo, hi: hi, body: body}
		}
		ps.next()
		if ps.atOp("(") {
			ps.next()
			var args []Node
			if !ps.atOp(")") {
				for {
					args = append(args, ps.parseExpr())
					if ps.atOp(",") {
						ps.next()
						continue
					}
					break
				}
			}
			if !ps.atOp(")") {
				gpErr(ps.peek().Pos, "')' expected")
			}
			ps.next()
			if _, ok := builtins[name]; !ok {
				if _, ok2 := ps.in.funcs[name]; !ok2 {
					if ps.in.parseOnly {
						return &callNode{name: name, args: args, pos: t.Pos}
					}
					gpErrNC("undefined function: " + name)
				}
			}
			return &callNode{name: name, args: args, pos: t.Pos}
		}
		return &varNode{name: name, pos: t.Pos}
	case TOp:
		switch t.Text {
		case "(":
			ps.next()
			x := ps.parseExpr()
			for ps.atOp(",") {
				ps.next()
				y := ps.parseExpr()
				x = &seqNode{x, y}
			}
			if !ps.atOp(")") {
				gpErr(ps.peek().Pos, "')' expected")
			}
			ps.next()
			return x
		case "{":
			ps.next()
			re := ps.parseExpr()
			if !ps.atOp(",") {
				gpErr(ps.peek().Pos, "',' expected")
			}
			ps.next()
			im := ps.parseExpr()
			if !ps.atOp("}") {
				gpErr(ps.peek().Pos, "'}' expected")
			}
			ps.next()
			return &cmplxNode{re, im}
		case "$":
			ps.next()
			nt := ps.peek()
			if nt.Kind == TNum && nt.IsInt {
				ps.next()
				return &colNode{col: int(nt.IVal), pos: t.Pos}
			}
			if nt.Kind == TOp && nt.Text == "(" {
				// $(expr)
				ps.next()
				x := ps.parseExpr()
				ps.expect(")", "')' expected")
				return &callNode{name: "column", args: []Node{x}, pos: t.Pos}
			}
			gpErr(nt.Pos, "Column number expected")
		case "|":
			ps.next()
			ipos := ps.peek().Pos
			x := ps.parsePrimary()
			if !ps.atOp("|") {
				gpErr(ps.peek().Pos, "'|' expected")
			}
			ps.next()
			return &cardNode{x: x, pos: ipos}
		}
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (ps *Parser) parsePostfixNoPipe() Node {
	t := ps.peek()
	if t.Kind == TName {
		ps.next()
		return &varNode{name: t.Text, pos: t.Pos}
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (ps *Parser) parseUnaryForSum() Node {
	return ps.parseBin(8)
}
