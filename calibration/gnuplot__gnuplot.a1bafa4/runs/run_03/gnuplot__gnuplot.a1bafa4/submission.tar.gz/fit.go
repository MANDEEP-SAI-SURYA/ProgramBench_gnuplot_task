package main

import (
	"fmt"
	"math"
	"strings"
)

type FitState struct{}

func (in *Interp) cmdFit(ps *Parser) {
	S := in.S
	in.plotAxes = map[string]*Axis{}
	for k, a := range S.axes {
		c := *a
		in.plotAxes[k] = &c
	}
	ri := 0
	for ps.atOp("[") {
		if ri == 0 {
			in.parseRange(ps, in.plotAxes["x"])
		} else {
			in.parseRange(ps, in.plotAxes["y"])
		}
		ri++
	}
	saved := in.parseOnly
	in.parseOnly = true
	fn := ps.parseExpr()
	in.parseOnly = saved
	in.statsMode = true
	it := in.parsePlotItem(ps, false, false)
	in.statsMode = false
	if !ps.at("via") {
		gpErr(ps.peek().Pos, "Need via and either parameter list or file")
	}
	ps.next()
	var params []string
	for {
		t := ps.next()
		if t.Kind != TName {
			gpErr(t.Pos, "no parameter specified")
		}
		params = append(params, t.Text)
		if ps.atOp(",") {
			ps.next()
			continue
		}
		break
	}
	ncols := 2
	if it.usingSet {
		ncols = len(it.using)
	}
	in.readData(it, ncols, false)
	var xs, ys, ws []float64
	xa := in.plotAxes["x"]
	for _, p := range it.points {
		if p.brk || p.typ == 'u' {
			continue
		}
		if (!xa.autoMin && p.x < xa.min) || (!xa.autoMax && p.x > xa.max) {
			continue
		}
		xs = append(xs, p.x)
		ys = append(ys, p.y)
		if len(p.ex) > 0 {
			ws = append(ws, 1/p.ex[0])
		} else {
			ws = append(ws, 1)
		}
	}
	np := len(params)
	n := len(xs)
	if n == 0 {
		gpErrNC("No data to fit")
	}
	p := make([]float64, np)
	for i, name := range params {
		v, ok := in.vars[name]
		if !ok {
			v = FloatV(1)
			in.setVar(name, v)
		}
		p[i] = v.Float()
	}
	dummy := S.dummy1
	oldX, hadX := in.vars[dummy]
	eval := func(pp []float64) []float64 {
		for i, name := range params {
			in.vars[name] = FloatV(pp[i])
		}
		r := make([]float64, n)
		for k := 0; k < n; k++ {
			in.vars[dummy] = FloatV(xs[k])
			in.undef = false
			v := fn.Eval(in).Float()
			r[k] = (ys[k] - v) * ws[k]
		}
		return r
	}
	chisq := func(r []float64) float64 {
		s := 0.0
		for _, v := range r {
			s += v * v
		}
		return s
	}
	jac := func(pp []float64, r0 []float64) [][]float64 {
		J := make([][]float64, n)
		for k := range J {
			J[k] = make([]float64, np)
		}
		for j := 0; j < np; j++ {
			h := math.Abs(pp[j]) * 1e-3
			if h == 0 {
				h = 1e-3
			}
			q := append([]float64{}, pp...)
			q[j] += h
			r1 := eval(q)
			for k := 0; k < n; k++ {
				J[k][j] = -(r1[k] - r0[k]) / h
			}
		}
		return J
	}
	w := in.stderr
	limit := S.fitLimit
	if v, ok := in.vars["FIT_LIMIT"]; ok {
		limit = v.Float()
	}
	maxIter := S.fitMaxIter
	if maxIter == 0 {
		maxIter = 100
	}
	header := "iter      chisq       delta/lim  lambda  "
	for _, name := range params {
		header += fmt.Sprintf(" %-13s", name)
	}
	r := eval(p)
	cs := chisq(r)
	J := jac(p, r)
	sumJ := 0.0
	for k := 0; k < n; k++ {
		for j := 0; j < np; j++ {
			sumJ += J[k][j] * J[k][j]
		}
	}
	lambda := math.Sqrt(sumJ / float64(n*np))
	if S.fitStartLambda > 0 {
		lambda = S.fitStartLambda
	}
	printIter := func(iter int, cs, delta, lambda float64) {
		if S.fitQuiet {
			return
		}
		s := fmt.Sprintf("%4d %-16s %10s %9s ", iter, cfmt("%.10e", cs), cfmt("%.2e", delta), cfmt("%.2e", lambda))
		for _, v := range p {
			s += cfmt("%15.6e", v)
		}
		fmt.Fprintln(w, s)
	}
	if !S.fitQuiet {
		fmt.Fprintln(w, header)
	}
	printIter(0, cs, 0, lambda)
	iter := 0
	lastDelta := 0.0
	converged := false
	for iter < maxIter {
		// build normal equations
		A := make([][]float64, np)
		g := make([]float64, np)
		for i := 0; i < np; i++ {
			A[i] = make([]float64, np)
			for j := 0; j < np; j++ {
				s := 0.0
				for k := 0; k < n; k++ {
					s += J[k][i] * J[k][j]
				}
				A[i][j] = s
			}
			s := 0.0
			for k := 0; k < n; k++ {
				s += J[k][i] * r[k]
			}
			g[i] = s
		}
		accepted := false
		var newP []float64
		var newR []float64
		var newCs float64
		for tries := 0; tries < 30; tries++ {
			M := make([][]float64, np)
			for i := range M {
				M[i] = append([]float64{}, A[i]...)
				M[i][i] += lambda * lambda
			}
			d := solveLin(M, g)
			if d == nil {
				break
			}
			newP = make([]float64, np)
			for i := range p {
				newP[i] = p[i] + d[i]
			}
			newR = eval(newP)
			newCs = chisq(newR)
			if newCs <= cs {
				accepted = true
				break
			}
			lambda *= S.fitLambdaFactor
		}
		iter++
		if !accepted {
			break
		}
		delta := (newCs - cs) / newCs
		if newCs == 0 {
			delta = 0
		}
		lastDelta = delta
		lambda /= S.fitLambdaFactor
		p = newP
		r = newR
		cs = newCs
		printIter(iter, cs, delta/limit, lambda)
		if math.Abs(delta) < limit {
			converged = true
			break
		}
		J = jac(p, r)
	}
	for i, name := range params {
		in.setVar(name, FloatV(p[i]))
	}
	if hadX {
		in.vars[dummy] = oldX
	} else {
		delete(in.vars, dummy)
	}
	// covariance
	J = jac(p, r)
	for i, name := range params {
		in.vars[name] = FloatV(p[i])
	}
	if hadX {
		in.vars[dummy] = oldX
	} else {
		delete(in.vars, dummy)
	}
	A := make([][]float64, np)
	for i := 0; i < np; i++ {
		A[i] = make([]float64, np)
		for j := 0; j < np; j++ {
			s := 0.0
			for k := 0; k < n; k++ {
				s += J[k][i] * J[k][j]
			}
			A[i][j] = s
		}
	}
	cov := invert(A)
	ndf := n - np
	rms := 0.0
	if ndf > 0 {
		rms = math.Sqrt(cs / float64(ndf))
	}
	var b strings.Builder
	if !S.fitQuiet {
		b.WriteString(header + "\n")
	}
	if converged {
		fmt.Fprintf(&b, "\nAfter %d iterations the fit converged.\n", iter)
	} else {
		fmt.Fprintf(&b, "\nAfter %d iterations the fit did not converge.\n", iter)
	}
	fmt.Fprintf(&b, "final sum of squares of residuals : %s\n", cfmt("%g", cs))
	if cs != 0 {
		fmt.Fprintf(&b, "rel. change during last iteration : %s\n\n", cfmt("%g", lastDelta))
	} else {
		fmt.Fprintf(&b, "\n")
	}
	fmt.Fprintf(&b, "degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	fmt.Fprintf(&b, "rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", cfmt("%g", rms))
	fmt.Fprintf(&b, "variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n\n", cfmt("%g", rms*rms))
	fmt.Fprintf(&b, "Final set of parameters            Asymptotic Standard Error\n")
	fmt.Fprintf(&b, "=======================            ==========================\n")
	errs := make([]float64, np)
	for i, name := range params {
		e := 0.0
		if cov != nil {
			e = math.Sqrt(cov[i][i]) * rms
		}
		errs[i] = e
		pct := ""
		if p[i] != 0 {
			pct = fmt.Sprintf(" (%s%%)", cfmt("%.4g", math.Abs(e/p[i]*100)))
		}
		fmt.Fprintf(&b, "%-15s = %-15s  +/- %-12s%s\n", name, cfmt("%g", p[i]), cfmt("%.4g", e), pct)
		if S.fitErrVars {
			in.setVar(name+"_err", FloatV(e))
		}
	}
	if np > 1 || true {
		fmt.Fprintf(&b, "\ncorrelation matrix of the fit parameters:\n")
		b.WriteString(strings.Repeat(" ", 16))
		for _, name := range params {
			fmt.Fprintf(&b, "%-7s", name)
		}
		b.WriteString("\n")
		for i, name := range params {
			fmt.Fprintf(&b, "%-15s", name)
			for j := 0; j <= i; j++ {
				c := 0.0
				if cov != nil {
					c = cov[i][j] / math.Sqrt(cov[i][i]*cov[j][j])
				}
				fmt.Fprintf(&b, "%s ", cfmt("%6.3f", c))
			}
			b.WriteString("\n")
		}
	}
	w.WriteString(b.String())
	in.setVar("FIT_NDF", IntV(int64(ndf)))
	in.setVar("FIT_STDFIT", FloatV(rms))
	in.setVar("FIT_WSSR", FloatV(cs))
	in.setVar("FIT_CONVERGED", BoolV(converged))
	in.setVar("FIT_NITER", IntV(int64(iter)))
}

func solveLin(A [][]float64, b []float64) []float64 {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		if M[piv][c] == 0 {
			return nil
		}
		M[c], M[piv] = M[piv], M[c]
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := range x {
		x[i] = M[i][n] / M[i][i]
	}
	return x
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for j := 0; j < n; j++ {
		e := make([]float64, n)
		e[j] = 1
		col := solveLin(A, e)
		if col == nil {
			return nil
		}
		for i := 0; i < n; i++ {
			if inv[i] == nil {
				inv[i] = make([]float64, n)
			}
			inv[i][j] = col[i]
		}
	}
	return inv
}
