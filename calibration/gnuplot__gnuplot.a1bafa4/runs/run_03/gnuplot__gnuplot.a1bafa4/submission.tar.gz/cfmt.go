package main

import (
	"fmt"
	"math"
	"strings"
)

// cfmt formats a single numeric value with a C-style format containing one conversion.
func cfmt(format string, args ...interface{}) string {
	var b strings.Builder
	ai := 0
	for i := 0; i < len(format); i++ {
		c := format[i]
		if c != '%' {
			b.WriteByte(c)
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			b.WriteByte('%')
			i++
			continue
		}
		j := i + 1
		for j < len(format) && strings.IndexByte("-+ #0", format[j]) >= 0 {
			j++
		}
		for j < len(format) && (isDigit(format[j]) || format[j] == '.' || format[j] == '*') {
			j++
		}
		for j < len(format) && strings.IndexByte("hlLqjzt", format[j]) >= 0 {
			j++
		}
		if j >= len(format) {
			b.WriteString(format[i:])
			break
		}
		spec := format[i:j]
		conv := format[j]
		// strip length modifiers
		spec = strings.TrimRight(spec, "hlLqjzt")
		var arg interface{}
		if ai < len(args) {
			arg = args[ai]
			ai++
		}
		b.WriteString(cconv(spec, conv, arg))
		i = j
	}
	return b.String()
}

func toF(a interface{}) float64 {
	switch v := a.(type) {
	case float64:
		return v
	case int64:
		return float64(v)
	case int:
		return float64(v)
	}
	return 0
}
func toI(a interface{}) int64 {
	switch v := a.(type) {
	case float64:
		if math.IsNaN(v) {
			return math.MinInt64
		}
		if v >= 9.2233720368547758e18 || v < -9.2233720368547758e18 {
			return math.MinInt64
		}
		return int64(v)
	case int64:
		return v
	case int:
		return int64(v)
	}
	return 0
}

func cconv(spec string, conv byte, arg interface{}) string {
	switch conv {
	case 'd', 'i':
		return fmt.Sprintf(spec+"d", toI(arg))
	case 'u':
		return fmt.Sprintf(spec+"d", uint64(toI(arg)))
	case 'x', 'X', 'o':
		s := fmt.Sprintf(spec+string(conv), uint64(toI(arg)))
		if conv == 'o' && strings.Contains(spec, "#") {
			// Go prints 0 prefix like C
		}
		return s
	case 'c':
		return string(rune(toI(arg)))
	case 's':
		if s, ok := arg.(string); ok {
			return fmt.Sprintf(spec+"s", s)
		}
		return fmt.Sprintf(spec+"s", fmt.Sprint(arg))
	case 'f', 'F', 'e', 'E', 'g', 'G':
		f := toF(arg)
		if math.IsInf(f, 0) || math.IsNaN(f) {
			var s string
			if math.IsNaN(f) {
				s = "nan"
				if math.Signbit(f) {
					s = "-nan"
				}
			} else if f > 0 {
				s = "inf"
				if strings.Contains(spec, "+") {
					s = "+inf"
				} else if strings.Contains(spec, " ") {
					s = " inf"
				}
			} else {
				s = "-inf"
			}
			if conv == 'E' || conv == 'G' || conv == 'F' {
				s = strings.ToUpper(s)
			}
			// width
			w := 0
			ss := strings.TrimLeft(spec[1:], "-+ #0")
			if k := strings.IndexByte(ss, '.'); k >= 0 {
				ss = ss[:k]
			}
			fmt.Sscanf(ss, "%d", &w)
			for len(s) < w {
				if strings.Contains(spec, "-") {
					s = s + " "
				} else {
					s = " " + s
				}
			}
			return s
		}
		if conv == 'g' || conv == 'G' {
			return cfmtG(spec, conv, f)
		}
		return fmt.Sprintf(spec+string(conv), f)
	}
	return spec + string(conv)
}

// C %g semantics (Go's %g differs for default precision and '#').
func cfmtG(spec string, conv byte, f float64) string {
	// parse flags/width/prec
	flags := ""
	k := 1
	for k < len(spec) && strings.IndexByte("-+ #0", spec[k]) >= 0 {
		flags += string(spec[k])
		k++
	}
	rest := spec[k:]
	width := ""
	prec := -1
	if d := strings.IndexByte(rest, '.'); d >= 0 {
		width = rest[:d]
		p := 0
		fmt.Sscanf(rest[d+1:]+" ", "%d", &p)
		prec = p
	} else {
		width = rest
	}
	if prec < 0 {
		prec = 6
	}
	if prec == 0 {
		prec = 1
	}
	alt := strings.Contains(flags, "#")
	var body string
	if f == 0 {
		x := 0
		_ = x
		if alt {
			body = "0." + strings.Repeat("0", prec-1)
		} else {
			body = "0"
		}
		if math.Signbit(f) {
			body = "-" + body
		}
	} else {
		es := fmt.Sprintf("%.*e", prec-1, f)
		// exponent
		ei := strings.LastIndexByte(es, 'e')
		var exp int
		fmt.Sscanf(es[ei+1:], "%d", &exp)
		if exp < -4 || exp >= prec {
			mant := es[:ei]
			if !alt && strings.Contains(mant, ".") {
				mant = strings.TrimRight(mant, "0")
				mant = strings.TrimSuffix(mant, ".")
			}
			sign := "+"
			if exp < 0 {
				sign = "-"
				exp = -exp
			}
			body = fmt.Sprintf("%s%c%s%02d", mant, 'e', sign, exp)
		} else {
			body = fmt.Sprintf("%.*f", prec-1-exp, f)
			if !alt && strings.Contains(body, ".") {
				body = strings.TrimRight(body, "0")
				body = strings.TrimSuffix(body, ".")
			}
		}
	}
	if conv == 'G' {
		body = strings.ToUpper(body)
	}
	if body[0] != '-' {
		if strings.Contains(flags, "+") {
			body = "+" + body
		} else if strings.Contains(flags, " ") {
			body = " " + body
		}
	}
	w := 0
	fmt.Sscanf(width, "%d", &w)
	if len(body) < w {
		if strings.Contains(flags, "-") {
			body = body + strings.Repeat(" ", w-len(body))
		} else if strings.Contains(flags, "0") {
			sign := ""
			if body[0] == '-' || body[0] == '+' || body[0] == ' ' {
				sign = body[:1]
				body = body[1:]
			}
			body = sign + strings.Repeat("0", w-len(body)-len(sign)) + body
		} else {
			body = strings.Repeat(" ", w-len(body)) + body
		}
	}
	return body
}
