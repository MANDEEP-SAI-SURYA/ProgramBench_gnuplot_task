package main

import (
	"math"
	"strconv"
	"strings"
)

type Kind int

const (
	KInt Kind = iota
	KFloat
	KCmplx
	KStr
	KArr
	KUndef
	KDatablock
)

type Array struct {
	vals []Value
}

type Value struct {
	K   Kind
	I   int64
	Re  float64
	Im  float64
	S   string
	Arr *Array
}

func IntV(i int64) Value     { return Value{K: KInt, I: i} }
func FloatV(f float64) Value { return Value{K: KFloat, Re: f} }
func StrV(s string) Value    { return Value{K: KStr, S: s} }
func CmplxV(re, im float64) Value {
	return Value{K: KCmplx, Re: re, Im: im}
}
func BoolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

type GPError struct {
	Msg   string
	Pos   int // -1 => no caret
	Bare  bool
	ctx   bool
	text  string
	loc   string
	block bool
}

func gpErr(pos int, format string) {
	panic(&GPError{Msg: format, Pos: pos})
}
func gpErrNC(msg string) {
	panic(&GPError{Msg: msg, Pos: -1})
}

// convert string to number if possible
func strToNum(s string) (Value, bool) {
	t := strings.TrimSpace(s)
	if t == "" {
		return Value{}, false
	}
	if i, err := strconv.ParseInt(t, 10, 64); err == nil {
		return IntV(i), true
	}
	// gnuplot uses strtod on the string; accept leading numeric prefix
	f, n := parseFloatPrefix(t)
	if n > 0 {
		return FloatV(f), true
	}
	return Value{}, false
}

func parseFloatPrefix(s string) (float64, int) {
	i := 0
	n := len(s)
	if i < n && (s[i] == '+' || s[i] == '-') {
		i++
	}
	ds := i
	for i < n && isDigit(s[i]) {
		i++
	}
	if i < n && s[i] == '.' {
		i++
		for i < n && isDigit(s[i]) {
			i++
		}
	}
	if i == ds || (i == ds+1 && s[ds] == '.') {
		// maybe inf/nan
		low := strings.ToLower(s[ds:])
		if strings.HasPrefix(low, "inf") {
			f, _ := strconv.ParseFloat(s[:ds+3], 64)
			return f, ds + 3
		}
		if strings.HasPrefix(low, "nan") {
			return math.NaN(), ds + 3
		}
		return 0, 0
	}
	if i < n && (s[i] == 'e' || s[i] == 'E') {
		k := i + 1
		if k < n && (s[k] == '+' || s[k] == '-') {
			k++
		}
		if k < n && isDigit(s[k]) {
			for k < n && isDigit(s[k]) {
				k++
			}
			i = k
		}
	}
	f, err := strconv.ParseFloat(s[:i], 64)
	if err != nil {
		// range error: ParseFloat returns inf
		return f, i
	}
	return f, i
}

func (v Value) num() Value {
	if v.K == KStr {
		if r, ok := strToNum(v.S); ok {
			return r
		}
		gpErrNC("Non-numeric string found where a numeric expression was expected")
	}
	if v.K == KArr {
		gpErrNC("Non-numeric string found where a numeric expression was expected")
	}
	return v
}

func (v Value) Float() float64 {
	v = v.num()
	switch v.K {
	case KInt:
		return float64(v.I)
	case KFloat, KCmplx:
		return v.Re
	}
	return 0
}

func (v Value) Imag() float64 {
	v = v.num()
	if v.K == KCmplx {
		return v.Im
	}
	return 0
}

// gnuplot's %g-ish formatting for print
func fmtG15(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	return cfmt("%.15g", f)
}

func fmtNumPrint(f float64) string {
	s := fmtG15(f)
	if !strings.ContainsAny(s, ".eN") || s == "inf" || s == "-inf" {
		if s != "NaN" {
			s += ".0"
		}
	}
	return s
}

func (v Value) String() string {
	switch v.K {
	case KInt:
		return strconv.FormatInt(v.I, 10)
	case KFloat:
		return fmtNumPrint(v.Re)
	case KCmplx:
		if v.Im == 0 {
			return fmtNumPrint(v.Re)
		}
		return "{" + fmtNumPrint(v.Re) + ", " + fmtNumPrint(v.Im) + "}"
	case KStr:
		return v.S
	case KArr:
		var b strings.Builder
		b.WriteString("[")
		for i, e := range v.Arr.vals {
			if i > 0 {
				b.WriteString(",")
			}
			if e.K == KStr {
				b.WriteString("\"" + e.S + "\"")
			} else if e.K != KUndef {
				b.WriteString(e.String())
			}
		}
		b.WriteString("]")
		return b.String()
	}
	return ""
}

// representation used by show variables etc.
func (v Value) Repr() string {
	if v.K == KStr {
		return "\"" + v.S + "\""
	}
	return v.String()
}
