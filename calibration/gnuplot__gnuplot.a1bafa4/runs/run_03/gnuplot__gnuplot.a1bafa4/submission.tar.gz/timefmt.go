package main

import (
	"fmt"
	"math"
	"strings"
	"time"
)

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, t float64) string {
	tm := gpTime(t)
	var b strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			b.WriteByte(c)
			continue
		}
		i++
		switch f[i] {
		case 'Y':
			fmt.Fprintf(&b, "%d", tm.Year())
		case 'y':
			fmt.Fprintf(&b, "%02d", tm.Year()%100)
		case 'm':
			fmt.Fprintf(&b, "%02d", int(tm.Month()))
		case 'd':
			fmt.Fprintf(&b, "%02d", tm.Day())
		case 'e':
			fmt.Fprintf(&b, "%2d", tm.Day())
		case 'H':
			fmt.Fprintf(&b, "%02d", tm.Hour())
		case 'k':
			fmt.Fprintf(&b, "%2d", tm.Hour())
		case 'I':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%02d", h)
		case 'l':
			h := tm.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%2d", h)
		case 'M':
			fmt.Fprintf(&b, "%02d", tm.Minute())
		case 'S':
			fmt.Fprintf(&b, "%02d", tm.Second())
		case 'j':
			fmt.Fprintf(&b, "%03d", tm.YearDay())
		case 'b', 'h':
			b.WriteString(monNames[tm.Month()-1][:3])
		case 'B':
			b.WriteString(monNames[tm.Month()-1])
		case 'a':
			b.WriteString(dayNames[tm.Weekday()][:3])
		case 'A':
			b.WriteString(dayNames[tm.Weekday()])
		case 'p':
			if tm.Hour() < 12 {
				b.WriteString("AM")
			} else {
				b.WriteString("PM")
			}
		case 's':
			fmt.Fprintf(&b, "%d", int64(math.Floor(t)))
		case 'w':
			fmt.Fprintf(&b, "%d", int(tm.Weekday()))
		case 'D':
			fmt.Fprintf(&b, "%02d/%02d/%02d", int(tm.Month()), tm.Day(), tm.Year()%100)
		case 'F':
			fmt.Fprintf(&b, "%d-%02d-%02d", tm.Year(), int(tm.Month()), tm.Day())
		case 'T':
			fmt.Fprintf(&b, "%02d:%02d:%02d", tm.Hour(), tm.Minute(), tm.Second())
		case 'R':
			fmt.Fprintf(&b, "%02d:%02d", tm.Hour(), tm.Minute())
		case '%':
			b.WriteByte('%')
		default:
			b.WriteByte('%')
			b.WriteByte(f[i])
		}
	}
	return b.String()
}

func gpStrptime(f string, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	sec := 0.0
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		neg := false
		if si < len(s) && (s[si] == '-' || s[si] == '+') {
			neg = s[si] == '-'
			si++
		}
		st := si
		v := 0
		for si < len(s) && si-st < maxd && isDigit(s[si]) {
			v = v*10 + int(s[si]-'0')
			si++
		}
		if si == st {
			return 0, false
		}
		if neg {
			v = -v
		}
		return v, true
	}
	epoch := false
	var epochV float64
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == c {
				si++
				continue
			}
			return 0, false
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			year, ok = readInt(2)
			if year < 69 {
				year += 2000
			} else {
				year += 1900
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'S':
			var v int
			v, ok = readInt(2)
			sec = float64(v)
			if si < len(s) && s[si] == '.' {
				st := si
				si++
				for si < len(s) && isDigit(s[si]) {
					si++
				}
				var fr float64
				fmt.Sscanf(s[st:si], "%g", &fr)
				sec += fr
			}
		case 'j':
			var v int
			v, ok = readInt(3)
			mon = 1
			day = v
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m[:3]) {
					mon = k + 1
					si += 3
					if f[i] == 'B' && len(s)-si >= len(m)-3 && strings.EqualFold(s[si:si+len(m)-3], m[3:]) {
						si += len(m) - 3
					}
					ok = true
					break
				}
			}
		case 's':
			for si < len(s) && s[si] == ' ' {
				si++
			}
			v, n := parseFloatPrefix(s[si:])
			ok = n > 0
			si += n
			epoch = true
			epochV = v
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if epoch {
		return epochV, true
	}
	t := time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	return float64(t.Unix()) + sec, true
}
