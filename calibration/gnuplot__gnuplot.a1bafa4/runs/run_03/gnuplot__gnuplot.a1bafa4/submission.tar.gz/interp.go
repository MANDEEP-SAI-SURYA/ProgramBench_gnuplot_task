package main

import (
	"bufio"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strings"
)

type UserFunc struct {
	name   string
	params []string
	body   Node
	text   string
}

type Source struct {
	lines []string
	idx   int
	name  string // "" for -e / stdin
	isStdin bool
	lineno int
	fixedLine bool
}

type ExitReq struct{ code int }

type Interp struct {
	vars       map[string]Value
	varOrder   []string
	funcs      map[string]*UserFunc
	funcOrder  []string
	datablocks map[string][]string
	dbOrder    []string
	locals     []map[string]Value
	undef      bool
	degrees    bool
	parseOnly  bool

	src        *Source
	curText    string
	blockDepth int
	interactive bool
	hadError   bool

	printOut   io.Writer
	printFile  *os.File
	printName  string
	printDB    string
	printAppend bool
	stdout     *bufio.Writer
	stderr     *bufio.Writer

	seed1, seed2 int64

	logbaseForFmt float64

	data *DataCtx
	S    *Settings
	lastPlot string
	lastPlotCmd []Token
	lastPlotText string
	lastPlotIs3D bool
	multiplot *MultiplotState
	fitState  *FitState
	breakFlag, continueFlag bool
	loopDepth int
	curBase int
	plotAxes map[string]*Axis
	lastDataFile string
	outFile *os.File
	statsMode bool
}

func NewInterp() *Interp {
	in := &Interp{
		vars:       map[string]Value{},
		funcs:      map[string]*UserFunc{},
		datablocks: map[string][]string{},
	}
	in.stdout = bufio.NewWriterSize(os.Stdout, 65536)
	in.stderr = bufio.NewWriterSize(os.Stderr, 65536)
	in.printOut = in.stderr
	in.setVar("pi", FloatV(math.Pi))
	in.setVar("I", CmplxV(0, 1))
	in.setVar("NaN", FloatV(math.NaN()))
	in.setVar("VoxelDistance", FloatV(0))
	in.setVar("GPVAL_VERSION", FloatV(5.4))
	in.setVar("GPVAL_PATCHLEVEL", StrV("9"))
	in.setVar("GPVAL_COMPILE_OPTIONS", StrV(""))
	in.setVar("I", CmplxV(0, 1))
	in.vars["I"] = CmplxV(0, 1)
	in.rngSeed(0)
	in.S = NewSettings()
	in.fitState = &FitState{}
	return in
}

func (in *Interp) flush() {
	in.stdout.Flush()
	in.stderr.Flush()
}

func (in *Interp) setVar(name string, v Value) {
	if len(in.locals) > 0 {
		if _, ok := in.locals[len(in.locals)-1][name]; ok {
			in.locals[len(in.locals)-1][name] = v
			return
		}
	}
	if _, ok := in.vars[name]; !ok {
		in.varOrder = append(in.varOrder, name)
	}
	in.vars[name] = v
}

func (in *Interp) lookupVar(name string) (Value, bool) {
	if len(in.locals) > 0 {
		if v, ok := in.locals[len(in.locals)-1][name]; ok {
			return v, true
		}
	}
	v, ok := in.vars[name]
	return v, ok
}

// --- RNG (simple L'Ecuyer combined generator) ---
func (in *Interp) rngSeed(s int64) {
	if s == 0 {
		in.seed1, in.seed2 = 1, 1
		return
	}
	in.seed1 = s
	in.seed2 = s
}
func (in *Interp) rngNext() float64 {
	const m1, m2 = 2147483563, 2147483399
	const a1, a2 = 40014, 40692
	const q1, q2 = 53668, 52774
	const r1, r2 = 12211, 3791
	k := in.seed1 / q1
	in.seed1 = a1*(in.seed1-k*q1) - k*r1
	if in.seed1 < 0 {
		in.seed1 += m1
	}
	k = in.seed2 / q2
	in.seed2 = a2*(in.seed2-k*q2) - k*r2
	if in.seed2 < 0 {
		in.seed2 += m2
	}
	z := in.seed1 - in.seed2
	if z < 1 {
		z += m1 - 1
	}
	return float64(z) / m1
}

func (n *callNode) Eval(in *Interp) Value {
	if b, ok := builtins[n.name]; ok {
		if b.nargs >= 0 && len(n.args) != b.nargs {
			if len(n.args) < b.nargs {
				gpErr(n.pos, "Not enough parameters")
			}
		}
		args := make([]Value, len(n.args))
		for i, a := range n.args {
			args[i] = a.Eval(in)
		}
		if b.nargs >= 0 && len(args) > b.nargs {
			args = args[:b.nargs]
		}
		return b.fn(in, args)
	}
	f, ok := in.funcs[n.name]
	if !ok {
		gpErrNC("undefined function: " + n.name)
	}
	if len(n.args) != len(f.params) {
		if len(f.params) == 1 {
			gpErrNC(fmt.Sprintf("function %s requires %d variable", n.name, len(f.params)))
		}
		gpErrNC(fmt.Sprintf("function %s requires %d variables", n.name, len(f.params)))
	}
	frame := map[string]Value{}
	for i, a := range n.args {
		frame[f.params[i]] = a.Eval(in)
	}
	in.locals = append(in.locals, frame)
	defer func() { in.locals = in.locals[:len(in.locals)-1] }()
	if len(in.locals) > 250 {
		gpErrNC("recursion depth limit exceeded")
	}
	return f.body.Eval(in)
}

// evaluate an expression at the parser position; checks undefined
func (in *Interp) evalExpr(ps *Parser) Value {
	pos := ps.peek().Pos
	n := ps.parseExpr()
	in.undef = false
	v := n.Eval(in)
	if in.undef {
		in.undef = false
		gpErr(pos, "undefined value")
	}
	return v
}

func (in *Interp) evalNum(ps *Parser) float64 {
	v := in.evalExpr(ps)
	return v.Float()
}

func (in *Interp) newParser(toks []Token) *Parser {
	return &Parser{toks: toks, in: in}
}

// ------------- error reporting -------------
func (in *Interp) locString() string {
	loc := ""
	if in.src != nil {
		if in.src.name != "" {
			loc = fmt.Sprintf("\"%s\" line %d: ", in.src.name, in.src.lineno)
		} else {
			loc = fmt.Sprintf("line %d: ", in.src.lineno)
		}
	}
	return loc
}

func (in *Interp) reportError(e *GPError) {
	in.stdout.Flush()
	w := in.stderr
	if !e.ctx {
		e.ctx = true
		e.text = in.curText
		e.loc = in.locString()
		e.block = in.blockDepth > 0
	}
	loc := e.loc
	if in.interactive {
		if e.Pos >= 0 && !e.block {
			fmt.Fprintf(w, "\ngnuplot> %s\n%s^\n", e.text, strings.Repeat(" ", e.Pos+9))
		}
		fmt.Fprintf(w, "         %s%s\n\n", loc, e.Msg)
	} else {
		if e.Pos >= 0 && !e.block {
			fmt.Fprintf(w, "\n%s\n%s^\n", e.text, strings.Repeat(" ", e.Pos))
		}
		fmt.Fprintf(w, "%s%s\n\n", loc, e.Msg)
	}
	w.Flush()
}

func (in *Interp) warn(msg string) {
	in.stdout.Flush()
	loc := ""
	if in.src != nil {
		if in.src.name != "" {
			loc = fmt.Sprintf("\"%s\" line %d: ", in.src.name, in.src.lineno)
		} else {
			loc = fmt.Sprintf("line %d: ", in.src.lineno)
		}
	}
	if in.interactive {
		loc = "         " + loc
	}
	fmt.Fprintf(in.stderr, "%swarning: %s\n", loc, msg)
}

func (in *Interp) warnCaret(pos int, msg string) {
	in.stdout.Flush()
	loc := ""
	if in.src != nil {
		if in.src.name != "" {
			loc = fmt.Sprintf("\"%s\" line %d: ", in.src.name, in.src.lineno)
		} else {
			loc = fmt.Sprintf("line %d: ", in.src.lineno)
		}
	}
	if in.blockDepth == 0 && pos >= 0 {
		if in.interactive {
			fmt.Fprintf(in.stderr, "\ngnuplot> %s\n%s^\n", in.curText, strings.Repeat(" ", pos+9))
			loc = "         " + loc
		} else {
			fmt.Fprintf(in.stderr, "\n%s\n%s^\n", in.curText, strings.Repeat(" ", pos))
		}
	}
	fmt.Fprintf(in.stderr, "%swarning: %s\n", loc, msg)
}

// ------------- source handling -------------

// read next logical line from source (handles continuation). ok=false at EOF
func (src *Source) nextLine() (string, bool) {
	if src.idx >= len(src.lines) {
		return "", false
	}
	l := src.lines[src.idx]
	src.idx++
	if !src.fixedLine {
		src.lineno++
	}
	for strings.HasSuffix(l, "\\") && src.idx < len(src.lines) {
		l = l[:len(l)-1] + src.lines[src.idx]
		src.idx++
		if !src.fixedLine {
			src.lineno++
		}
	}
	return l, true
}

func braceBalance(l string) int {
	bal := 0
	inq := byte(0)
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inq != 0 {
			if c == '\\' && inq == '"' {
				i++
				continue
			}
			if c == inq {
				inq = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			inq = c
			continue
		}
		if c == '#' {
			break
		}
		if c == '{' {
			bal++
		} else if c == '}' {
			bal--
		}
	}
	return bal
}

// run all lines of a source. Returns error-out flag.
func (in *Interp) runSource(src *Source) {
	saved := in.src
	in.src = src
	defer func() { in.src = saved }()
	for {
		line, ok := src.nextLine()
		if !ok {
			return
		}
		startLine := src.lineno
		// gather braces
		for braceBalance(line) > 0 {
			more, ok2 := src.nextLine()
			if !ok2 {
				break
			}
			line += "\n" + more
		}
		endLine := src.lineno
		in.curBase = startLine
		if src.isStdin {
			func() {
				defer func() {
					if r := recover(); r != nil {
						if e, ok := r.(*GPError); ok {
							in.hadError = true
							in.reportError(e)
							in.blockDepth = 0
							in.locals = nil
							return
						}
						panic(r)
					}
				}()
				in.execLine(line)
			}()
		} else {
			in.execLine(line)
		}
		if !src.fixedLine && src.lineno < endLine {
			src.lineno = endLine
		}
	}
}

func (in *Interp) expandMacros(line string) string {
	if !strings.Contains(line, "@") {
		return line
	}
	var b strings.Builder
	inq := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if inq != 0 {
			if c == '\\' && inq == '"' && i+1 < len(line) {
				b.WriteByte(c)
				b.WriteByte(line[i+1])
				i++
				continue
			}
			if c == inq {
				inq = 0
			}
			b.WriteByte(c)
			continue
		}
		if c == '"' || c == '\'' {
			inq = c
			b.WriteByte(c)
			continue
		}
		if c == '@' && i+1 < len(line) && isLetter(line[i+1]) {
			j := i + 1
			for j < len(line) && (isLetter(line[j]) || isDigit(line[j])) {
				j++
			}
			name := line[i+1 : j]
			v, ok := in.lookupVar(name)
			if ok && v.K == KStr {
				b.WriteString(v.S)
				i = j - 1
				continue
			}
			gpErrNC("macro substitution: " + name + " is not a string variable")
		}
		b.WriteByte(c)
	}
	return b.String()
}

// execute one logical line (possibly multiple commands)
func (in *Interp) execLine(line string) {
	line = strings.TrimRight(line, "\r")
	if strings.Contains(line, "@") {
		line = in.expandMacros(line)
	}
	saved := in.curText
	in.curText = line
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GPError); ok && !e.ctx {
				e.ctx = true
				e.text = in.curText
				e.loc = in.locString()
				e.block = in.blockDepth > 0
			}
			in.curText = saved
			panic(r)
		}
		in.curText = saved
	}()
	toks, _ := tokenize(line)
	in.execTokens(toks)
}

func (in *Interp) execTokens(toks []Token) {
	ps := in.newParser(toks)
	for {
		for ps.atOp(";") {
			ps.next()
		}
		if ps.peek().Kind == TEnd {
			return
		}
		in.execCommand(ps)
		if !ps.atEnd() {
			t := ps.peek()
			gpErr(t.Pos, "unexpected or unrecognized token: "+t.Text)
		}
	}
}

// text between braces starting at token index of '{'. Returns content text and moves parser after '}'.
type Block struct {
	text string
	base int
}

func (in *Interp) grabBlock(ps *Parser) Block {
	t := ps.peek()
	if !(t.Kind == TOp && t.Text == "{") {
		gpErr(t.Pos, "expecting '{'")
	}
	start := t.Pos + 1
	depth := 0
	for {
		t = ps.peek()
		if t.Kind == TEnd {
			gpErr(t.Pos, "Unmatched '{'")
		}
		if t.Kind == TOp && t.Text == "{" {
			depth++
		} else if t.Kind == TOp && t.Text == "}" {
			depth--
			if depth == 0 {
				end := t.Pos
				ps.next()
				return Block{in.curText[start:end], in.curBase + strings.Count(in.curText[:start], "\n")}
			}
		}
		ps.next()
	}
}

func (in *Interp) runBlock(blk Block) {
	in.blockDepth++
	savedBase := in.curBase
	savedLine := 0
	if in.src != nil {
		savedLine = in.src.lineno
	}
	defer func() {
		in.blockDepth--
		in.curBase = savedBase
		if in.src != nil && !in.src.fixedLine {
			in.src.lineno = savedLine
		}
	}()
	text := blk.text
	lines := strings.Split(text, "\n")
	// execute line by line (joined lines with braces)
	i := 0
	for i < len(lines) {
		l := lines[i]
		in.curBase = blk.base + i
		if in.src != nil && !in.src.fixedLine {
			in.src.lineno = blk.base + i
		}
		i++
		for braceBalance(l) > 0 && i < len(lines) {
			l += "\n" + lines[i]
			i++
		}
		in.execLine(l)
		if in.breakFlag || in.continueFlag {
			return
		}
	}
}

func (in *Interp) sortedVarNames() []string {
	names := make([]string, 0, len(in.vars))
	for k := range in.vars {
		names = append(names, k)
	}
	sort.Strings(names)
	return names
}
