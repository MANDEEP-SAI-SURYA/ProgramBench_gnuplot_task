package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                   int
	mean, sd, ssd, skew, kurt, adev     float64
	sum, sumsq, min, max                float64
	imin, imax                          int
	q1, med, q3                         float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min, s.imin = x, i
		}
		if x > s.max {
			s.max, s.imax = x, i
		}
	}
	s.mean = s.sum / float64(n)
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	m2 /= float64(n)
	m3 /= float64(n)
	m4 /= float64(n)
	s.sd = math.Sqrt(m2)
	if n > 1 {
		s.ssd = math.Sqrt(m2 * float64(n) / float64(n-1))
	}
	s.skew = m3 / (s.sd * s.sd * s.sd)
	s.kurt = m4 / (m2 * m2)
	if m2 == 0 {
		s.skew, s.kurt = math.NaN(), math.NaN()
	}
	s.adev = ad / float64(n)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	med := func(a []float64) float64 {
		k := len(a)
		if k == 0 {
			return math.NaN()
		}
		if k%2 == 1 {
			return a[k/2]
		}
		return (a[k/2-1] + a[k/2]) / 2
	}
	s.med = med(sv)
	if n%2 == 1 {
		s.q1 = med(sv[:n/2])
		s.q3 = med(sv[n/2+1:])
		if n == 1 {
			s.q1, s.q3 = sv[0], sv[0]
		}
	} else {
		s.q1 = med(sv[:n/2])
		s.q3 = med(sv[n/2:])
	}
	return s
}

func (in *Interp) cmdStats(ps *Parser) {
	S := in.S
	in.plotAxes = map[string]*Axis{}
	for k, a := range S.axes {
		c := *a
		in.plotAxes[k] = &c
	}
	ri := 0
	for ps.atOp("[") {
		if ri == 0 {
			in.parseRange(ps, in.plotAxes["x"])
		} else {
			in.parseRange(ps, in.plotAxes["y"])
		}
		ri++
	}
	it := in.parsePlotItemStats(ps)
	prefix := "STATS"
	quiet := false
	for !ps.atEnd() {
		t := ps.next()
		switch {
		case almostEquals(t.Text, "name"), t.Text == "prefix":
			prefix = in.parseStringArg(ps)
		case almostEquals(t.Text, "q$uiet"):
			quiet = true
		case almostEquals(t.Text, "nooutput"):
			quiet = true
		case t.Text == "output":
		}
	}
	if it.isFunc {
		gpErrNC("Stats command not available for functions")
	}
	ncols := 2
	if it.usingSet {
		ncols = len(it.using)
	}
	in.readData(it, ncols, false)
	// count records
	var xs, ys []float64
	invalid := 0
	blank := 0
	outr := 0
	xa, ya := in.plotAxes["x"], in.plotAxes["y"]
	oneCol := false
	if it.usingSet && len(it.using) == 1 {
		oneCol = true
	}
	lines := []string{}
	if it.src != "" {
		lines = in.getDataLines(it.src)
	}
	singleColData := true
	for _, l := range lines {
		if strings.TrimSpace(l) == "" || in.isComment(l) {
			continue
		}
		if len(in.splitFields(l)) > 1 {
			singleColData = false
		}
	}
	if !it.usingSet && singleColData {
		oneCol = true
	}
	for _, p := range it.points {
		if p.brk {
			blank++
			continue
		}
		if p.typ == 'u' {
			invalid++
			continue
		}
		if oneCol {
			v := p.y
			if !xa.autoMin && v < xa.min || !xa.autoMax && v > xa.max {
				outr++
				continue
			}
			xs = append(xs, v)
		} else {
			if (!xa.autoMin && p.x < xa.min) || (!xa.autoMax && p.x > xa.max) || (!ya.autoMin && p.y < ya.min) || (!ya.autoMax && p.y > ya.max) {
				outr++
				continue
			}
			xs = append(xs, p.x)
			ys = append(ys, p.y)
		}
	}
	// blank lines count from raw data
	blank = 0
	blocks := 1
	prevBlank := 0
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
			prevBlank++
			continue
		}
		if prevBlank >= 2 {
			blocks++
		}
		prevBlank = 0
	}
	if len(xs) == 0 {
		gpErrNC("All points out of range")
	}
	sx := computeStats(xs)
	var sy colStats
	if !oneCol {
		sy = computeStats(ys)
	}
	set := func(name string, v Value) {
		in.setVar(prefix+"_"+name, v)
	}
	w := in.printOut
	if !quiet {
		var b strings.Builder
		b.WriteString("\n* FILE: \n")
		fmt.Fprintf(&b, "  Records:           %d\n", len(xs))
		fmt.Fprintf(&b, "  Out of range:      %d\n", outr)
		fmt.Fprintf(&b, "  Invalid:           %d\n", invalid)
		fmt.Fprintf(&b, "  Header records:    %d\n", 0)
		fmt.Fprintf(&b, "  Blank:             %d\n", blank)
		fmt.Fprintf(&b, "  Data Blocks:       %d\n", blocks)
		f4 := func(v float64) string { return cfmt("%.4f", v) }
		_ = f4
		if oneCol {
			b.WriteString("\n* COLUMN: \n")
			row := func(lbl string, v float64) {
				fmt.Fprintf(&b, "  %-14s%12s\n", lbl, cfmt("%.4f", v))
			}
			row("Mean:", sx.mean)
			row("Std Dev:", sx.sd)
			row("Sample StdDev:", sx.ssd)
			row("Skewness:", sx.skew)
			row("Kurtosis:", sx.kurt)
			row("Avg Dev:", sx.adev)
			row("Sum:", sx.sum)
			row("Sum Sq.:", sx.sumsq)
			b.WriteString("\n")
			n := float64(sx.n)
			row("Mean Err.:", sx.sd/math.Sqrt(n))
			row("Std Dev Err.:", sx.sd/math.Sqrt(2*n))
			row("Skewness Err.:", math.Sqrt(6/n))
			row("Kurtosis Err.:", math.Sqrt(24/n))
			b.WriteString("\n")
			fmt.Fprintf(&b, "  %-14s%12s [%d]\n", "Minimum:", cfmt("%.4f", sx.min), sx.imin)
			fmt.Fprintf(&b, "  %-14s%12s [%d]\n", "Maximum:", cfmt("%.4f", sx.max), sx.imax)
			fmt.Fprintf(&b, "  %-14s%12s \n", "Quartile:", cfmt("%.4f", sx.q1))
			fmt.Fprintf(&b, "  %-14s%12s \n", "Median:", cfmt("%.4f", sx.med))
			fmt.Fprintf(&b, "  %-14s%12s \n", "Quartile:", cfmt("%.4f", sx.q3))
			b.WriteString("\n")
		} else {
			b.WriteString("\n* COLUMNS:\n")
			row := func(lbl string, v1, v2 float64) {
				fmt.Fprintf(&b, "  %-14s%12s %17s\n", lbl, cfmt("%.4f", v1), cfmt("%.4f", v2))
			}
			row("Mean:", sx.mean, sy.mean)
			row("Std Dev:", sx.sd, sy.sd)
			row("Sample StdDev:", sx.ssd, sy.ssd)
			row("Skewness:", sx.skew, sy.skew)
			row("Kurtosis:", sx.kurt, sy.kurt)
			row("Avg Dev:", sx.adev, sy.adev)
			row("Sum:", sx.sum, sy.sum)
			row("Sum Sq.:", sx.sumsq, sy.sumsq)
			b.WriteString("\n")
			n := float64(sx.n)
			row("Mean Err.:", sx.sd/math.Sqrt(n), sy.sd/math.Sqrt(n))
			row("Std Dev Err.:", sx.sd/math.Sqrt(2*n), sy.sd/math.Sqrt(2*n))
			row("Skewness Err.:", math.Sqrt(6/n), math.Sqrt(6/n))
			row("Kurtosis Err.:", math.Sqrt(24/n), math.Sqrt(24/n))
			b.WriteString("\n")
			fmt.Fprintf(&b, "  %-14s%12s %-4s %12s [%d]\n", "Minimum:", cfmt("%.4f", sx.min), fmt.Sprintf("[%d]", sx.imin), cfmt("%.4f", sy.min), sy.imin)
			fmt.Fprintf(&b, "  %-14s%12s %-4s %12s [%d]\n", "Maximum:", cfmt("%.4f", sx.max), fmt.Sprintf("[%d]", sx.imax), cfmt("%.4f", sy.max), sy.imax)
			row("Quartile:", sx.q1, sy.q1)
			row("Median:", sx.med, sy.med)
			row("Quartile:", sx.q3, sy.q3)
			b.WriteString("\n")
			slope, icpt, serr, ierr, r, sxy := linreg(xs, ys)
			sign := "+"
			if icpt < 0 {
				sign = "-"
			}
			fmt.Fprintf(&b, "  Linear Model:       y = %s x %s %s\n", cfmt("%.4g", slope), sign, cfmt("%.4g", math.Abs(icpt)))
			fmt.Fprintf(&b, "  Slope:              %s +- %s\n", cfmt("%.4g", slope), cfmt("%.4g", serr))
			fmt.Fprintf(&b, "  Intercept:          %s +- %s\n", cfmt("%.4g", icpt), cfmt("%.4g", ierr))
			fmt.Fprintf(&b, "  Correlation:        r = %s\n", cfmt("%.4g", r))
			fmt.Fprintf(&b, "  Sum xy:             %s\n", cfmt("%.4g", sxy))
			b.WriteString("\n")
		}
		w.Write([]byte(b.String()))
	}
	set("records", IntV(int64(len(xs))))
	set("invalid", IntV(int64(invalid)))
	set("headers", IntV(0))
	set("blank", IntV(int64(blank)))
	set("blocks", IntV(int64(blocks)))
	set("outofrange", IntV(int64(outr)))
	if oneCol {
		set("columns", IntV(1))
		setCol(set, "", sx)
	} else {
		set("columns", IntV(2))
		setCol(set, "_x", sx)
		setCol(set, "_y", sy)
		slope, icpt, serr, ierr, r, sxy := linreg(xs, ys)
		set("slope", FloatV(slope))
		set("intercept", FloatV(icpt))
		set("slope_err", FloatV(serr))
		set("intercept_err", FloatV(ierr))
		set("correlation", FloatV(r))
		set("sumxy", FloatV(sxy))
		set("pos_min_y", FloatV(xs[sy.imin]))
		set("pos_max_y", FloatV(xs[sy.imax]))
	}
}

func setCol(set func(string, Value), suf string, s colStats) {
	n := float64(s.n)
	set("mean"+suf, FloatV(s.mean))
	set("stddev"+suf, FloatV(s.sd))
	set("ssd"+suf, FloatV(s.ssd))
	set("skewness"+suf, FloatV(s.skew))
	set("kurtosis"+suf, FloatV(s.kurt))
	set("adev"+suf, FloatV(s.adev))
	set("mean_err"+suf, FloatV(s.sd/math.Sqrt(n)))
	set("stddev_err"+suf, FloatV(s.sd/math.Sqrt(2*n)))
	set("skewness_err"+suf, FloatV(math.Sqrt(6/n)))
	set("kurtosis_err"+suf, FloatV(math.Sqrt(24/n)))
	set("sum"+suf, FloatV(s.sum))
	set("sumsq"+suf, FloatV(s.sumsq))
	set("min"+suf, FloatV(s.min))
	set("max"+suf, FloatV(s.max))
	set("median"+suf, FloatV(s.med))
	set("lo_quartile"+suf, FloatV(s.q1))
	set("up_quartile"+suf, FloatV(s.q3))
	set("index_min"+suf, IntV(int64(s.imin)))
	set("index_max"+suf, IntV(int64(s.imax)))
}

func linreg(xs, ys []float64) (slope, icpt, serr, ierr, r, sxy float64) {
	n := float64(len(xs))
	var mx, my float64
	for i := range xs {
		mx += xs[i]
		my += ys[i]
		sxy += xs[i] * ys[i]
	}
	mx /= n
	my /= n
	var sxx, syy, cxy float64
	for i := range xs {
		sxx += (xs[i] - mx) * (xs[i] - mx)
		syy += (ys[i] - my) * (ys[i] - my)
		cxy += (xs[i] - mx) * (ys[i] - my)
	}
	slope = cxy / sxx
	icpt = my - slope*mx
	r = cxy / math.Sqrt(sxx*syy)
	var ssr float64
	for i := range xs {
		d := ys[i] - (slope*xs[i] + icpt)
		ssr += d * d
	}
	s2 := ssr / (n - 2)
	serr = math.Sqrt(s2 / sxx)
	ierr = math.Sqrt(s2 * (1/n + mx*mx/sxx))
	return
}

func (in *Interp) parsePlotItemStats(ps *Parser) *PlotItem {
	in.statsMode = true
	defer func() { in.statsMode = false }()
	return in.parsePlotItem(ps, false, false)
}
