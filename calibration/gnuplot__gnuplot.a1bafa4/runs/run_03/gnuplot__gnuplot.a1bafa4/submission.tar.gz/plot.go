package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Point struct {
	x, y, z float64
	ex      []float64
	typ     byte // 'i','o','u'
	brk     bool
	label   string
}

type UsingSpec struct {
	col  int  // >0 column, 0 = $0 (row index), -1 expression
	expr Node
	isStr bool
	str  string
}

type PlotItem struct {
	isFunc   bool
	fn       Node
	src      string // datablock name or file name
	title    string
	notitle  bool
	style    string
	using    []UsingSpec
	usingSet bool
	index    [3]int // start,end,step ; -1 none
	indexSet bool
	every    [6]int
	everySet bool
	smooth   string
	bins     int
	binsSet  bool
	points   []Point
	lt       int
	pt       int
	ptSet    bool
	axesY2   bool
	nCols    int
	colhead  bool
	titleCol int
}

type DataCtx struct {
	cols   []string
	vals   []float64
	ok     []bool
	row    int
	header []string
}

func (in *Interp) columnValue(v Value, pos int) Value {
	d := in.data
	if d == nil {
		gpErrNC("column() called from invalid context")
	}
	v = v.num()
	c := int(toInt(v))
	if c == 0 {
		return FloatV(float64(d.row))
	}
	if c == -2 {
		return FloatV(0)
	}
	if c < 1 || c > len(d.cols) {
		in.undef = true
		return FloatV(math.NaN())
	}
	if !d.ok[c-1] {
		in.undef = true
		return FloatV(math.NaN())
	}
	return FloatV(d.vals[c-1])
}

func (in *Interp) stringColumn(v Value) Value {
	d := in.data
	if d == nil {
		gpErrNC("column() called from invalid context")
	}
	c := int(toInt(v))
	if c < 1 || c > len(d.cols) {
		in.undef = true
		return StrV("")
	}
	return StrV(d.cols[c-1])
}

func (in *Interp) columnHead(v Value) Value {
	d := in.data
	c := int(toInt(v))
	if d == nil || c < 1 || c > len(d.header) {
		return StrV("")
	}
	return StrV(d.header[c-1])
}

func (in *Interp) validColumn(v Value) bool {
	d := in.data
	if d == nil {
		return false
	}
	c := int(toInt(v))
	if c < 1 || c > len(d.cols) {
		return false
	}
	return d.ok[c-1]
}

// split a data line into fields
func (in *Interp) splitFields(line string) []string {
	S := in.S
	if S.sep != "" && S.sep != " " {
		parts := strings.FieldsFunc(line, func(r rune) bool { return strings.ContainsRune(S.sep, r) })
		if !strings.Contains(S.sep, " ") {
			parts = splitKeepEmpty(line, S.sep)
		}
		for i := range parts {
			parts[i] = strings.TrimSpace(parts[i])
			if len(parts[i]) >= 2 && parts[i][0] == '"' && parts[i][len(parts[i])-1] == '"' {
				parts[i] = parts[i][1 : len(parts[i])-1]
			}
		}
		return parts
	}
	var f []string
	i := 0
	n := len(line)
	for i < n {
		for i < n && (line[i] == ' ' || line[i] == '\t') {
			i++
		}
		if i >= n {
			break
		}
		if line[i] == '"' {
			j := i + 1
			for j < n && line[j] != '"' {
				j++
			}
			f = append(f, line[i+1:min(j, n)])
			i = j + 1
			continue
		}
		j := i
		for j < n && line[j] != ' ' && line[j] != '\t' {
			j++
		}
		f = append(f, line[i:j])
		i = j
	}
	return f
}

func splitKeepEmpty(line, seps string) []string {
	var r []string
	start := 0
	for i := 0; i < len(line); i++ {
		if strings.IndexByte(seps, line[i]) >= 0 {
			r = append(r, line[start:i])
			start = i + 1
		}
	}
	r = append(r, line[start:])
	return r
}

func parseDataNum(s string) (float64, bool) {
	t := strings.TrimSpace(s)
	if t == "" {
		return 0, false
	}
	f, n := parseFloatPrefix(t)
	if n == 0 {
		return 0, false
	}
	// accept Fortran D exponent? keep simple
	if n < len(t) {
		// trailing garbage: gnuplot accepts prefix
		return f, true
	}
	return f, true
}

func (in *Interp) getDataLines(src string) []string {
	if strings.HasPrefix(src, "$") {
		lines, ok := in.datablocks[src]
		if !ok {
			gpErrNC("undefined data block: " + src)
		}
		return lines
	}
	if strings.HasPrefix(src, "<") {
		out, _ := runShell(src[1:])
		return splitLines(out)
	}
	data, err := os.ReadFile(src)
	if err != nil {
		gpErrNC("Cannot find or open file \"" + src + "\"")
	}
	return splitLines(string(data))
}

func (in *Interp) isComment(line string) bool {
	t := strings.TrimLeft(line, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(in.S.comments, t[0]) >= 0
}

// readData fills item.points according to using/index/every.
func (in *Interp) readData(it *PlotItem, ncolsDefault int, is3D bool) {
	S := in.S
	var lines []string
	special := it.src == "+" || it.src == "++"
	if special {
		in.readSpecial(it, is3D)
		return
	}
	lines = in.getDataLines(it.src)
	// iterate datasets/blocks
	dataset := 0
	block := 0
	lineInBlock := 0
	blankRun := 0
	row := 0
	var header []string
	headerDone := false
	needHeader := it.colhead || S.headerAuto
	saved := in.data
	defer func() { in.data = saved }()
	maxDirect := 0
	for _, u := range it.using {
		if u.col > maxDirect {
			maxDirect = u.col
		}
		if u.col == -1 && u.expr != nil {
			if m := maxDollar(u.expr); m > maxDirect {
				maxDirect = m
			}
		}
	}
	var pts []Point
	pendingBreak := false
	inIndex := func(ds int) bool {
		if !it.indexSet {
			return true
		}
		if ds < it.index[0] || ds > it.index[1] {
			return false
		}
		return (ds-it.index[0])%it.index[2] == 0
	}
	for _, raw := range lines {
		line := strings.TrimRight(raw, "\r")
		if strings.TrimSpace(line) == "" {
			blankRun++
			if blankRun == 1 {
				if inIndex(dataset) && lineInBlock > 0 {
					pendingBreak = true
				}
				block++
				lineInBlock = 0
			} else if blankRun == 2 {
				dataset++
				block = 0
				row = 0
			}
			continue
		}
		if in.isComment(line) {
			continue
		}
		blankRun = 0
		if !inIndex(dataset) {
			continue
		}
		fields := in.splitFields(line)
		if needHeader && !headerDone {
			header = fields
			headerDone = true
			continue
		}
		if pendingBreak {
			pendingBreak = false
			if len(pts) > 0 || true {
				pts = append(pts, Point{brk: true})
			}
		}
		// every filtering
		li := lineInBlock
		lineInBlock++
		curRow := row
		row++
		if it.everySet {
			e := it.every
			if li < e[2] || (e[4] >= 0 && li > e[4]) || (li-e[2])%e[0] != 0 {
				continue
			}
			if block < e[3] || (e[5] >= 0 && block > e[5]) || (block-e[3])%e[1] != 0 {
				continue
			}
		}
		d := &DataCtx{cols: fields, row: curRow, header: header}
		d.vals = make([]float64, len(fields))
		d.ok = make([]bool, len(fields))
		for i, f := range fields {
			if S.missing != "" && f == S.missing {
				continue
			}
			d.vals[i], d.ok[i] = parseDataNum(f)
		}
		in.data = d
		var using []UsingSpec
		if it.usingSet {
			using = it.using
		} else {
			nc := ncolsDefault
			if len(fields) == 1 && !is3D {
				using = []UsingSpec{{col: 0}, {col: 1}}
			} else {
				for i := 1; i <= nc; i++ {
					using = append(using, UsingSpec{col: i})
				}
				if len(fields) < nc && is3D && len(fields) <= 1 {
				}
			}
		}
		if maxDirect > len(fields) {
			continue
		}
		vals := make([]float64, len(using))
		p := Point{typ: 'i'}
		skip := false
		for k, u := range using {
			if u.col > 0 {
				if u.col > len(fields) {
					skip = true
					break
				}
				if !d.ok[u.col-1] {
					if S.missing != "" && fields[u.col-1] == S.missing {
						skip = true
						break
					}
					skip = true
					break
				}
				vals[k] = d.vals[u.col-1]
				if strings.EqualFold(fields[u.col-1], "nan") {
					p.typ = 'u'
				}
			} else if u.col == 0 {
				vals[k] = float64(curRow)
			} else if u.col == -2 {
				vals[k] = float64(block)
			} else {
				in.undef = false
				v := u.expr.Eval(in)
				if v.K == KStr {
					p.label = v.S
					if k < len(using)-1 || it.style != "labels" {
						if f, ok := strToNum(v.S); ok {
							vals[k] = f.Float()
						} else {
							vals[k] = math.NaN()
						}
					}
				} else {
					vals[k] = v.Float()
				}
				if in.undef || math.IsNaN(vals[k]) {
					p.typ = 'u'
					vals[k] = math.NaN()
				}
				in.undef = false
			}
		}
		if skip {
			continue
		}
		if it.style == "labels" && len(using) >= 3 {
			u := using[len(using)-1]
			if u.col > 0 {
				p.label = fields[u.col-1]
			}
		}
		in.assignPoint(&p, vals, is3D, it)
		pts = append(pts, p)
	}
	it.points = pts
	if it.colhead && it.titleCol > 0 && it.titleCol <= len(header) && !it.notitle {
		it.title = header[it.titleCol-1]
	}
}

func maxDollar(n Node) int {
	m := 0
	var walk func(n Node)
	walk = func(n Node) {
		switch x := n.(type) {
		case *colNode:
			if x.col > m {
				m = x.col
			}
		case *binNode:
			walk(x.l)
			walk(x.r)
		case *unNode:
			walk(x.x)
		case *ternNode:
			walk(x.c)
			walk(x.a)
			walk(x.b)
		case *callNode:
			for _, a := range x.args {
				walk(a)
			}
		}
	}
	walk(n)
	return m
}

func (in *Interp) assignPoint(p *Point, vals []float64, is3D bool, it *PlotItem) {
	if is3D {
		switch len(vals) {
		case 1:
			p.z = vals[0]
		case 2:
			p.x, p.z = vals[0], vals[1]
		default:
			p.x, p.y, p.z = vals[0], vals[1], vals[2]
			if len(vals) > 3 {
				p.ex = vals[3:]
			}
		}
		return
	}
	switch len(vals) {
	case 1:
		p.x = float64(0)
		p.y = vals[0]
	default:
		p.x, p.y = vals[0], vals[1]
		if len(vals) > 2 {
			p.ex = vals[2:]
		}
	}
	for _, v := range vals {
		if math.IsNaN(v) {
			p.typ = 'u'
		}
	}
}

func (in *Interp) readSpecial(it *PlotItem, is3D bool) {
	S := in.S
	xa := in.plotAxes["x"]
	xmin, xmax := xa.min, xa.max
	n := S.samples
	saved := in.data
	defer func() { in.data = saved }()
	var pts []Point
	for i := 0; i < n; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(n-1)
		if xa.log {
			x = math.Pow(xa.base, math.Log(xmin)/math.Log(xa.base)+float64(i)*(math.Log(xmax)-math.Log(xmin))/math.Log(xa.base)/float64(n-1))
		}
		d := &DataCtx{cols: []string{fmtG(x)}, vals: []float64{x}, ok: []bool{true}, row: i}
		in.data = d
		using := it.using
		if !it.usingSet {
			using = []UsingSpec{{col: 1}, {col: 1}}
		}
		vals := make([]float64, len(using))
		p := Point{typ: 'i'}
		for k, u := range using {
			if u.col > 0 {
				vals[k] = x
			} else if u.col == 0 {
				vals[k] = float64(i)
			} else {
				in.undef = false
				v := u.expr.Eval(in)
				vals[k] = v.Float()
				if in.undef {
					p.typ = 'u'
					vals[k] = math.NaN()
				}
				in.undef = false
			}
		}
		in.assignPoint(&p, vals, is3D, it)
		pts = append(pts, p)
	}
	it.points = pts
}

func fmtG(x float64) string { return cfmt("%g", x) }

// --------- plot command parsing --------------

func (in *Interp) cmdReplot(ps *Parser) {
	if in.lastPlotText == "" {
		gpErrNC("no previous plot")
	}
	saved := in.curText
	in.curText = in.lastPlotText
	toks, _ := tokenize(in.lastPlotText)
	p2 := in.newParser(toks)
	p2.next()
	in.cmdPlot(p2, in.lastPlotIs3D)
	in.curText = saved
}

func (in *Interp) cmdPlot(ps *Parser, is3D bool) {
	S := in.S
	startTok := ps.p
	// copy axes for this plot
	in.plotAxes = map[string]*Axis{}
	for k, a := range S.axes {
		c := *a
		in.plotAxes[k] = &c
	}
	order := []string{"x", "y"}
	if is3D {
		order = []string{"x", "y", "z"}
	}
	if S.parametric && !is3D {
		order = []string{"t", "x", "y"}
	}
	ri := 0
	for ps.atOp("[") {
		if ri < len(order) {
			in.parseRange(ps, in.plotAxes[order[ri]])
		} else {
			in.parseRange(ps, &Axis{})
		}
		ri++
	}
	var items []*PlotItem
	for {
		items = append(items, in.parsePlotItems(ps, is3D)...)
		if ps.atOp(",") {
			ps.next()
			continue
		}
		break
	}
	// record for replot
	if !ps.atEnd() {
		t := ps.peek()
		gpErr(t.Pos, "unexpected or unrecognized token: "+t.Text)
	}
	endPos := ps.peek().Pos
	in.lastPlotText = "plot " + in.curText[ps.toks[startTok].Pos:endPos]
	if is3D {
		in.lastPlotText = "splot " + in.curText[ps.toks[startTok].Pos:endPos]
	}
	in.lastPlotIs3D = is3D
	in.generatePlot(items, is3D)
}

func (in *Interp) parsePlotItems(ps *Parser, is3D bool) []*PlotItem {
	if ps.at("for") {
		ps.next()
		it := in.parseIter(ps)
		start := ps.p
		var res []*PlotItem
		vals := it.values()
		if len(vals) == 0 {
			// skip the item tokens
			in.parsePlotItem(ps, is3D, true)
			return nil
		}
		for _, v := range vals {
			in.setVar(it.varName, v)
			ps.p = start
			res = append(res, in.parsePlotItems(ps, is3D)...)
		}
		return res
	}
	return []*PlotItem{in.parsePlotItem(ps, is3D, false)}
}

func (in *Interp) parsePlotItem(ps *Parser, is3D bool, dry bool) *PlotItem {
	S := in.S
	it := &PlotItem{lt: -1}
	startPos := ps.peek().Pos
	titleEnd := -1
	t := ps.peek()
	if t.Kind == TName && strings.HasPrefix(t.Text, "$") && !(ps.toks[ps.p+1].Kind == TOp && ps.toks[ps.p+1].Text == "[") {
		ps.next()
		it.src = t.Text
		if !dry {
			if _, ok := in.datablocks[t.Text]; !ok {
				gpErr(t.Pos, "undefined datablock "+t.Text)
			}
		}
	} else if in.isStringStart(ps) {
		v := in.evalExpr(ps)
		it.src = v.S
		if v.S == "" {
			it.src = in.lastDataFile
		}
		in.lastDataFile = it.src
	} else {
		it.isFunc = true
		saved := in.parseOnly
		in.parseOnly = true
		x := ps.parseExpr()
		in.parseOnly = saved
		it.fn = x
	}
	titleEnd = ps.peek().Pos
	it.index = [3]int{0, -1, 1}
	it.every = [6]int{1, 1, 0, 0, -1, -1}
itemLoop:
	for !ps.atEnd() && !ps.atOp(",") {
		tk := ps.peek()
		w := tk.Text
		if in.statsMode && (w == "via" || w == "name" || w == "prefix" || almostEquals(w, "q$uiet") || w == "nooutput" || w == "output") {
			break itemLoop
		}
		switch {
		case !it.isFunc && almostEquals(w, "i$ndex"):
			ps.next()
			it.indexSet = true
			a := int(toInt(in.evalExpr(ps)))
			it.index = [3]int{a, a, 1}
			if ps.atOp(":") {
				ps.next()
				it.index[1] = int(toInt(in.evalExpr(ps)))
				if ps.atOp(":") {
					ps.next()
					it.index[2] = int(toInt(in.evalExpr(ps)))
				}
			}
			titleEnd = ps.peek().Pos
		case !it.isFunc && almostEquals(w, "ev$ery"):
			ps.next()
			it.everySet = true
			for k := 0; k < 6; k++ {
				if ps.atOp(":") {
					ps.next()
					continue
				}
				if ps.atEnd() || ps.atOp(",") || ps.peek().Kind == TName && !isNumVar(in, ps.peek().Text) {
					break
				}
				it.every[k] = int(toInt(in.evalExpr(ps)))
				if !ps.atOp(":") {
					break
				}
				ps.next()
			}
			titleEnd = ps.peek().Pos
		case almostEquals(w, "u$sing"):
			ps.next()
			it.usingSet = true
			for {
				if ps.atOp("(") {
					x := ps.parsePrimary()
					it.using = append(it.using, UsingSpec{col: -1, expr: x})
				} else if ps.peek().Kind == TNum {
					n := ps.next()
					it.using = append(it.using, UsingSpec{col: int(n.IVal)})
				} else if ps.atOp("$") {
					x := ps.parsePrimary()
					it.using = append(it.using, UsingSpec{col: -1, expr: x})
				} else if ps.peek().Kind == TStr {
					s := ps.next()
					it.using = append(it.using, UsingSpec{col: -1, expr: &constNode{StrV(s.Str)}, isStr: true})
				} else {
					x := ps.parsePrimary()
					if !dry {
						v := x.Eval(in)
						it.using = append(it.using, UsingSpec{col: int(toInt(v))})
					}
				}
				if ps.atOp(":") {
					ps.next()
					continue
				}
				break
			}
			titleEnd = ps.peek().Pos
		case almostEquals(w, "s$mooth"):
			ps.next()
			it.smooth = ps.next().Text
		case w == "bins" || strings.HasPrefix(w, "bins"):
			ps.next()
			it.binsSet = true
			it.bins = S.samples
			if ps.atOp("=") {
				ps.next()
				it.bins = int(toInt(in.evalExpr(ps)))
			}
		case almostEquals(w, "t$itle"):
			ps.next()
			if ps.at("columnheader") || ps.at("columnhead") || ps.at("col") {
				ps.next()
				it.colhead = true
				it.titleCol = 0
				if ps.atOp("(") {
					ps.next()
					it.titleCol = int(toInt(in.evalExpr(ps)))
					ps.expect(")", "')' expected")
				}
			} else {
				v := in.evalExpr(ps)
				if v.K == KStr {
					it.title = v.S
				} else {
					it.title = v.String()
				}
				titleEnd = -2
			}
		case almostEquals(w, "not$itle"):
			ps.next()
			it.notitle = true
			if !ps.atEnd() && ps.peek().Kind == TStr {
				ps.next()
			}
		case almostEquals(w, "w$ith"):
			ps.next()
			it.style = in.parseStyleName(ps)
		case almostEquals(w, "ax$es"), almostEquals(w, "ax$is"):
			ps.next()
			a := ps.next().Text
			it.axesY2 = strings.HasSuffix(a, "y2")
		case w == "lt" || w == "linetype" || w == "lc" || w == "linecolor" || w == "ls" || w == "linestyle":
			ps.next()
			if ps.at("rgb") || ps.at("rgbcolor") {
				ps.next()
				in.evalExpr(ps)
			} else if ps.at("palette") || ps.at("variable") || ps.at("black") || ps.at("bgnd") {
				ps.next()
			} else {
				v := int(toInt(in.evalExpr(ps)))
				if w == "lt" || w == "linetype" || w == "lc" || w == "linecolor" || w == "ls" || w == "linestyle" {
					it.lt = v - 1
				}
			}
		case w == "pt" || w == "pointtype":
			ps.next()
			if ps.peek().Kind == TStr {
				s := ps.next().Str
				it.pt = -100 - int(s[0])
			} else {
				it.pt = int(toInt(in.evalExpr(ps)))
			}
			it.ptSet = true
		case w == "lw" || w == "linewidth" || w == "ps" || w == "pointsize" || w == "dt" || w == "dashtype" || w == "pi" || w == "pointinterval" || w == "fs" || w == "fillstyle" || w == "fc" || w == "fillcolor" || w == "font" || w == "tc" || w == "textcolor" || w == "offset" || w == "arrowstyle" || w == "as":
			ps.next()
			if w == "fs" || w == "fillstyle" {
				for ps.at("solid") || ps.at("empty") || ps.at("pattern") || ps.at("border") || ps.at("noborder") || ps.at("transparent") || ps.peek().Kind == TNum {
					if ps.peek().Kind == TNum {
						in.evalExpr(ps)
					} else {
						ps.next()
					}
				}
			} else if ps.at("variable") || ps.at("palette") {
				ps.next()
			} else {
				if (w == "tc" || w == "textcolor" || w == "fc" || w == "fillcolor") && (ps.at("rgb") || ps.at("lt")) {
					ps.next()
				}
				in.evalExpr(ps)
				for ps.atOp(",") && (w == "offset") {
					ps.next()
					in.evalExpr(ps)
				}
			}
		case w == "nohidden3d" || w == "nocontours" || w == "nosurface" || w == "notitle" || w == "point" || w == "nopoint" || w == "left" || w == "right" || w == "center" || w == "boxed" || w == "heads" || w == "nohead" || w == "head" || w == "filled" || w == "empty" || w == "nofilled" || w == "noenhanced" || w == "enhanced" || w == "rotate" || w == "x1y1" || w == "x1y2" || w == "above" || w == "below" || w == "closed" || w == "x1" || w == "x2" || w == "y1" || w == "y2" || w == "binwidth" || w == "binrange" || w == "binvalue" || w == "matrix" || w == "nonuniform" || w == "volatile":
			ps.next()
			if w == "binwidth" || w == "binvalue" {
				if ps.atOp("=") {
					ps.next()
				}
				in.evalExpr(ps)
			}
			if w == "binrange" {
				ps.next()
				for !ps.atOp("]") {
					ps.next()
				}
				ps.next()
			}
		default:
			gpErr(tk.Pos, "unexpected or unrecognized token: "+w)
		}
	}
	if it.style == "" {
		if it.isFunc {
			it.style = S.funcStyle
		} else {
			it.style = S.dataStyle
		}
	}
	if titleEnd >= 0 && it.title == "" && !it.colhead {
		it.title = strings.TrimSpace(in.curText[startPos:titleEnd])
	}
	if it.colhead && it.titleCol == 0 {
		if len(it.using) > 0 {
			it.titleCol = it.using[len(it.using)-1].col
			if len(it.using) >= 2 && !is3D {
				it.titleCol = it.using[1].col
			}
		} else {
			it.titleCol = 2
		}
	}
	return it
}

func isNumVar(in *Interp, name string) bool {
	_, ok := in.lookupVar(name)
	return ok
}

// --------- plot generation --------------

func (in *Interp) generatePlot(items []*PlotItem, is3D bool) {
	S := in.S
	xa := in.plotAxes["x"]
	ya := in.plotAxes["y"]
	// read data first
	for _, it := range items {
		if !it.isFunc && it.src != "+" && it.src != "++" {
			ncols := 2
			if is3D {
				ncols = 3
			}
			if it.colhead || S.headerAuto {
				it.colhead = true
			}
			in.readData(it, ncols, is3D)
			if it.binsSet {
				in.applyBins(it)
			} else if it.smooth != "" {
				in.applySmooth(it)
			}
		}
	}
	// x autoscale from data
	if !is3D {
		dxmin, dxmax := math.Inf(1), math.Inf(-1)
		for _, it := range items {
			if it.isFunc {
				continue
			}
			for _, p := range it.points {
				if p.brk || p.typ == 'u' {
					continue
				}
				if p.x < dxmin {
					dxmin = p.x
				}
				if p.x > dxmax {
					dxmax = p.x
				}
				if it.style == "xerrorbars" || it.style == "xyerrorbars" || it.style == "boxxyerror" {
				}
			}
		}
		if xa.autoMin {
			if !math.IsInf(dxmin, 0) {
				xa.min = dxmin
			} else if !S.axes["x"].everSet {
				xa.min = -10
			}
		}
		if xa.autoMax {
			if !math.IsInf(dxmax, 0) {
				xa.max = dxmax
			} else {
				xa.max = 10
			}
		}
		if xa.autoMin && math.IsInf(dxmin, 0) {
			xa.min = -10
		}
	}
	// functions
	for _, it := range items {
		if it.isFunc {
			if is3D {
				in.sampleFunc3D(it)
			} else {
				in.sampleFunc(it, xa, ya)
			}
		} else if it.src == "+" || it.src == "++" {
			in.readData(it, 2, is3D)
		}
	}
	// mark out-of-range
	for _, it := range items {
		for i := range it.points {
			p := &it.points[i]
			if p.brk || p.typ == 'u' {
				continue
			}
			if !is3D {
				if (!xa.autoMin && p.x < math.Min(xa.min, xa.max)) || (!xa.autoMax && p.x > math.Max(xa.min, xa.max)) {
					p.typ = 'o'
				}
				if (!ya.autoMin && p.y < math.Min(ya.min, ya.max)) || (!ya.autoMax && p.y > math.Max(ya.min, ya.max)) {
					p.typ = 'o'
				}
			} else {
				za := in.plotAxes["z"]
				if (!xa.autoMin && p.x < xa.min) || (!xa.autoMax && p.x > xa.max) || (!ya.autoMin && p.y < ya.min) || (!ya.autoMax && p.y > ya.max) || (!za.autoMin && p.z < za.min) || (!za.autoMax && p.z > za.max) {
					p.typ = 'o'
				}
			}
		}
	}
	if S.table {
		in.writeTable(items, is3D)
		return
	}
	switch S.termName {
	case "dumb":
		in.renderDumb(items, is3D)
	case "svg", "canvas":
		in.renderVector(items, is3D)
	default:
		in.updateRanges(items, is3D)
	}
}

func (in *Interp) sampleFunc(it *PlotItem, xa, ya *Axis) {
	S := in.S
	n := S.samples
	xmin, xmax := xa.min, xa.max
	dummy := S.dummy1
	old, had := in.vars[dummy]
	defer func() {
		if had {
			in.vars[dummy] = old
		} else {
			delete(in.vars, dummy)
		}
	}()
	var pts []Point
	for i := 0; i < n; i++ {
		var x float64
		if xa.log {
			lmin := math.Log(xmin)
			lmax := math.Log(xmax)
			x = math.Exp(lmin + float64(i)*(lmax-lmin)/float64(n-1))
		} else {
			x = xmin + float64(i)*(xmax-xmin)/float64(n-1)
		}
		in.vars[dummy] = FloatV(x)
		in.undef = false
		p := Point{x: x, typ: 'i'}
		func() {
			defer func() {
				if r := recover(); r != nil {
					panic(r)
				}
			}()
			v := it.fn.Eval(in)
			if v.K == KCmplx && math.Abs(v.Im) > 1e-15*math.Abs(v.Re) && v.Im != 0 {
				p.typ = 'u'
				p.y = v.Re
				return
			}
			p.y = v.Float()
		}()
		if in.undef || math.IsNaN(p.y) || math.IsInf(p.y, 0) {
			p.typ = 'u'
			if in.undef {
				p.y = math.NaN()
			}
			if math.IsInf(p.y, 0) {
				p.y = math.NaN()
			}
		}
		in.undef = false
		pts = append(pts, p)
	}
	it.points = pts
}

func (in *Interp) sampleFunc3D(it *PlotItem) {
	S := in.S
	xa := in.plotAxes["x"]
	ya := in.plotAxes["y"]
	xmin, xmax := xa.min, xa.max
	ymin, ymax := ya.min, ya.max
	n1, n2 := S.iso1, S.iso2
	if S.samples > n1 && false {
	}
	var pts []Point
	saveX, hadX := in.vars[S.dummy1]
	saveY, hadY := in.vars[S.dummy2]
	defer func() {
		if hadX {
			in.vars[S.dummy1] = saveX
		} else {
			delete(in.vars, S.dummy1)
		}
		if hadY {
			in.vars[S.dummy2] = saveY
		} else {
			delete(in.vars, S.dummy2)
		}
	}()
	for j := 0; j < n2; j++ {
		y := ymin + float64(j)*(ymax-ymin)/float64(n2-1)
		if j > 0 {
			pts = append(pts, Point{brk: true})
		}
		for i := 0; i < n1; i++ {
			x := xmin + float64(i)*(xmax-xmin)/float64(n1-1)
			in.vars[S.dummy1] = FloatV(x)
			in.vars[S.dummy2] = FloatV(y)
			in.undef = false
			v := it.fn.Eval(in)
			p := Point{x: x, y: y, z: v.Float(), typ: 'i'}
			if in.undef || math.IsNaN(p.z) {
				p.typ = 'u'
			}
			in.undef = false
			pts = append(pts, p)
		}
	}
	it.points = pts
}

func gfmt(x float64) string {
	return cfmt("% g", x)
}

func (in *Interp) tableWriter() (func(string), func()) {
	S := in.S
	if S.tableDB != "" {
		var b strings.Builder
		return func(s string) { b.WriteString(s) }, func() {
			s := b.String()
			lines := strings.Split(s, "\n")
			if len(lines) > 0 && lines[len(lines)-1] == "" {
				lines = lines[:len(lines)-1]
			}
			if _, ok := in.datablocks[S.tableDB]; !ok {
				in.dbOrder = append(in.dbOrder, S.tableDB)
			}
			in.datablocks[S.tableDB] = append(in.datablocks[S.tableDB], lines...)
		}
	}
	if S.tableFile != "" {
		var b strings.Builder
		return func(s string) { b.WriteString(s) }, func() {
			f, err := os.OpenFile(S.tableFile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
			if err == nil {
				f.WriteString(b.String())
				f.Close()
			}
		}
	}
	w := in.outWriter()
	return func(s string) { w.WriteString(s) }, func() {}
}

func (in *Interp) writeTable(items []*PlotItem, is3D bool) {
	write, done := in.tableWriter()
	defer done()
	for ci, it := range items {
		if is3D {
			in.writeTable3D(write, it, ci, len(items))
			continue
		}
		write(fmt.Sprintf("\n# Curve %d of %d, %d points\n", ci, len(items), len(it.points)))
		write(fmt.Sprintf("# Curve title: \"%s\"\n", it.title))
		cols := "x y"
		switch it.style {
		case "yerrorbars", "yerrorlines":
			cols = "x y ylow yhigh"
		case "xerrorbars", "xerrorlines":
			cols = "x y xlow xhigh"
		case "xyerrorbars", "xyerrorlines":
			cols = "x y xlow xhigh ylow yhigh"
		case "boxes":
			cols = "x y xlow xhigh"
		case "labels":
			cols = "x y label"
		}
		if it.binsSet {
			write("# x y  N type\n")
		} else {
			write("# " + cols + " type\n")
		}
		for _, p := range it.points {
			if p.brk {
				write("\n")
				continue
			}
			x, y := gfmt(p.x), gfmt(p.y)
			if math.IsNaN(p.x) {
				x = " NaN"
			}
			if math.IsNaN(p.y) {
				y = " NaN"
			}
			if it.binsSet {
				n := 0.0
				if len(p.ex) > 0 {
					n = p.ex[0]
				}
				write(fmt.Sprintf("%s %s  %4s %c\n", x, y, cfmt("%g", n), p.typ))
				continue
			}
			switch it.style {
			case "yerrorbars", "yerrorlines":
				lo, hi := p.y, p.y
				if len(p.ex) == 1 {
					lo, hi = p.y-p.ex[0], p.y+p.ex[0]
				} else if len(p.ex) >= 2 {
					lo, hi = p.ex[0], p.ex[1]
				}
				if len(p.ex) == 0 {
					lo, hi = 0, 0
				}
				write(fmt.Sprintf("%s %s %s %s  %c\n", x, y, gfmt(lo), gfmt(hi), p.typ))
			case "xerrorbars", "xerrorlines":
				lo, hi := p.x, p.x
				if len(p.ex) == 1 {
					lo, hi = p.x-p.ex[0], p.x+p.ex[0]
				} else if len(p.ex) >= 2 {
					lo, hi = p.ex[0], p.ex[1]
				}
				write(fmt.Sprintf("%s %s %s %s  %c\n", x, y, gfmt(lo), gfmt(hi), p.typ))
			case "boxes":
				lo, hi := p.x, p.x
				if len(p.ex) >= 1 {
					lo, hi = p.x-p.ex[0]/2, p.x+p.ex[0]/2
				}
				write(fmt.Sprintf("%s %s %s %s  %c\n", x, y, gfmt(lo), gfmt(hi), p.typ))
			case "labels":
				write(fmt.Sprintf("%s %s \"%s\"\n", x, y, p.label))
			default:
				write(fmt.Sprintf("%s %s  %c\n", x, y, p.typ))
			}
		}
		write("\n")
		if it.smooth == "frequency" || it.smooth == "cnormal" || it.smooth == "cumulative" || it.smooth == "fnormal" {
			write("\n")
		}
	}
}

func (in *Interp) writeTable3D(write func(string), it *PlotItem, ci, n int) {
	np := 0
	for _, p := range it.points {
		if !p.brk {
			np++
		}
	}
	write(fmt.Sprintf("\n# Surface %d of %d surfaces\n", ci, n))
	if it.isFunc {
		write(fmt.Sprintf("\n# IsoCurve 0, %d points\n", in.S.iso1))
	} else {
		write(fmt.Sprintf("\n# Curve title: \"%s\"\n", it.title))
	}
	write("# x y z type\n")
	iso := 0
	for _, p := range it.points {
		if p.brk {
			iso++
			if it.isFunc {
				write(fmt.Sprintf("\n\n# IsoCurve %d, %d points\n# x y z type\n", iso, in.S.iso1))
			} else {
				write("\n")
			}
			continue
		}
		write(fmt.Sprintf("%s %s %s %c\n", gfmt(p.x), gfmt(p.y), gfmt(p.z), p.typ))
	}
	write("\n")
}

// ---------- smoothing ------------
func (in *Interp) applySmooth(it *PlotItem) {
	// split into segments separated by breaks or undefined
	var segs [][]Point
	var cur []Point
	for _, p := range it.points {
		if p.brk || p.typ == 'u' {
			if len(cur) > 0 {
				segs = append(segs, cur)
			}
			cur = nil
			continue
		}
		cur = append(cur, p)
	}
	if len(cur) > 0 {
		segs = append(segs, cur)
	}
	var out []Point
	sm := it.smooth
	switch {
	case almostEquals(sm, "u$nique"):
		sm = "unique"
	case almostEquals(sm, "f$requency"):
		sm = "frequency"
	case almostEquals(sm, "cum$ulative"):
		sm = "cumulative"
	case almostEquals(sm, "cn$ormal"):
		sm = "cnormal"
	case almostEquals(sm, "cs$plines"):
		sm = "csplines"
	case almostEquals(sm, "acs$plines"):
		sm = "acsplines"
	case almostEquals(sm, "mcs$plines"):
		sm = "mcsplines"
	case almostEquals(sm, "b$ezier"):
		sm = "bezier"
	case almostEquals(sm, "sb$ezier"):
		sm = "sbezier"
	case almostEquals(sm, "k$density"):
		sm = "kdensity"
	case almostEquals(sm, "fn$ormal"):
		sm = "fnormal"
	}
	it.smooth = sm
	if sm == "frequency" || sm == "cnormal" || sm == "cumulative" || sm == "fnormal" || sm == "kdensity" {
		// whole set at once
		var all []Point
		for _, s := range segs {
			all = append(all, s...)
		}
		segs = [][]Point{all}
	}
	for si, s := range segs {
		if si > 0 {
			out = append(out, Point{brk: true})
		}
		sort.SliceStable(s, func(i, j int) bool { return s[i].x < s[j].x })
		switch sm {
		case "unique", "frequency", "cumulative", "cnormal", "fnormal":
			var u []Point
			cnt := []int{}
			for _, p := range s {
				if len(u) > 0 && u[len(u)-1].x == p.x {
					u[len(u)-1].y += p.y
					cnt[len(cnt)-1]++
				} else {
					u = append(u, Point{x: p.x, y: p.y, typ: 'i'})
					cnt = append(cnt, 1)
				}
			}
			if sm == "unique" {
				for i := range u {
					u[i].y /= float64(cnt[i])
				}
			}
			if sm == "cumulative" || sm == "cnormal" {
				acc := 0.0
				for i := range u {
					acc += u[i].y
					u[i].y = acc
				}
				if sm == "cnormal" && acc != 0 {
					for i := range u {
						u[i].y /= acc
					}
				}
			}
			if sm == "fnormal" {
				tot := 0.0
				for i := range u {
					tot += u[i].y
				}
				for i := range u {
					u[i].y /= tot
				}
			}
			out = append(out, u...)
		case "csplines", "acsplines", "mcsplines", "bezier", "sbezier":
			out = append(out, in.splineSmooth(s, sm)...)
		case "kdensity":
			out = append(out, in.kdensity(s)...)
		default:
			out = append(out, s...)
		}
	}
	it.points = out
}

func (in *Interp) kdensity(s []Point) []Point {
	n := len(s)
	if n == 0 {
		return nil
	}
	// default bandwidth
	mean, sd := 0.0, 0.0
	tw := 0.0
	for _, p := range s {
		mean += p.x
		tw += p.y
	}
	mean /= float64(n)
	for _, p := range s {
		sd += (p.x - mean) * (p.x - mean)
	}
	sd = math.Sqrt(sd / float64(n))
	bw := 1.06 * sd * math.Pow(float64(n), -0.2)
	if bw == 0 {
		bw = 1
	}
	xa := in.plotAxes["x"]
	xmin, xmax := s[0].x, s[n-1].x
	if !xa.autoMin {
		xmin = xa.min
	}
	if !xa.autoMax {
		xmax = xa.max
	}
	ns := in.S.samples
	var out []Point
	for i := 0; i < ns; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(ns-1)
		y := 0.0
		for _, p := range s {
			z := (x - p.x) / bw
			y += p.y * math.Exp(-0.5*z*z) / (bw * math.Sqrt(2*math.Pi))
		}
		out = append(out, Point{x: x, y: y, typ: 'i'})
	}
	return out
}

func (in *Interp) splineSmooth(s []Point, kind string) []Point {
	// merge equal x (average)
	var u []Point
	cnt := []int{}
	for _, p := range s {
		if len(u) > 0 && u[len(u)-1].x == p.x {
			u[len(u)-1].y += p.y
			cnt[len(cnt)-1]++
		} else {
			u = append(u, Point{x: p.x, y: p.y, typ: 'i'})
			cnt = append(cnt, 1)
		}
	}
	for i := range u {
		u[i].y /= float64(cnt[i])
	}
	n := len(u)
	ns := in.S.samples
	var out []Point
	if n < 2 {
		return u
	}
	xmin, xmax := u[0].x, u[n-1].x
	switch kind {
	case "bezier", "sbezier":
		pts := u
		if kind == "sbezier" {
			pts = s
		}
		m := len(pts)
		for i := 0; i < ns; i++ {
			t := float64(i) / float64(ns-1)
			x, y := 0.0, 0.0
			for k := 0; k < m; k++ {
				b := binom(m-1, k) * math.Pow(t, float64(k)) * math.Pow(1-t, float64(m-1-k))
				x += b * pts[k].x
				y += b * pts[k].y
			}
			out = append(out, Point{x: x, y: y, typ: 'i'})
		}
		return out
	case "mcsplines":
		// monotone cubic (Fritsch-Carlson)
		d := make([]float64, n-1)
		for i := 0; i < n-1; i++ {
			d[i] = (u[i+1].y - u[i].y) / (u[i+1].x - u[i].x)
		}
		m := make([]float64, n)
		m[0] = d[0]
		m[n-1] = d[n-2]
		for i := 1; i < n-1; i++ {
			if d[i-1]*d[i] <= 0 {
				m[i] = 0
			} else {
				m[i] = (d[i-1] + d[i]) / 2
			}
		}
		for i := 0; i < n-1; i++ {
			if d[i] == 0 {
				m[i], m[i+1] = 0, 0
				continue
			}
			a := m[i] / d[i]
			b := m[i+1] / d[i]
			h := a*a + b*b
			if h > 9 {
				t := 3 / math.Sqrt(h)
				m[i] = t * a * d[i]
				m[i+1] = t * b * d[i]
			}
		}
		for i := 0; i < ns; i++ {
			x := xmin + float64(i)*(xmax-xmin)/float64(ns-1)
			k := 0
			for k < n-2 && x > u[k+1].x {
				k++
			}
			h := u[k+1].x - u[k].x
			t := (x - u[k].x) / h
			h00 := 2*t*t*t - 3*t*t + 1
			h10 := t*t*t - 2*t*t + t
			h01 := -2*t*t*t + 3*t*t
			h11 := t*t*t - t*t
			y := h00*u[k].y + h10*h*m[k] + h01*u[k+1].y + h11*h*m[k+1]
			out = append(out, Point{x: x, y: y, typ: 'i'})
		}
		return out
	}
	// natural cubic spline
	h := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		h[i] = u[i+1].x - u[i].x
	}
	M := make([]float64, n)
	if n > 2 {
		a := make([]float64, n)
		b := make([]float64, n)
		c := make([]float64, n)
		r := make([]float64, n)
		for i := 1; i < n-1; i++ {
			a[i] = h[i-1]
			b[i] = 2 * (h[i-1] + h[i])
			c[i] = h[i]
			r[i] = 6 * ((u[i+1].y-u[i].y)/h[i] - (u[i].y-u[i-1].y)/h[i-1])
		}
		for i := 2; i < n-1; i++ {
			w := a[i] / b[i-1]
			b[i] -= w * c[i-1]
			r[i] -= w * r[i-1]
		}
		M[n-2] = r[n-2] / b[n-2]
		for i := n - 3; i >= 1; i-- {
			M[i] = (r[i] - c[i]*M[i+1]) / b[i]
		}
	}
	for i := 0; i < ns; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(ns-1)
		k := 0
		for k < n-2 && x > u[k+1].x {
			k++
		}
		hk := h[k]
		A := (u[k+1].x - x) / hk
		B := (x - u[k].x) / hk
		y := A*u[k].y + B*u[k+1].y + ((A*A*A-A)*M[k]+(B*B*B-B)*M[k+1])*hk*hk/6
		out = append(out, Point{x: x, y: y, typ: 'i'})
	}
	return out
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func (in *Interp) applyBins(it *PlotItem) {
	var xs, ys []float64
	for _, p := range it.points {
		if p.brk || p.typ == 'u' {
			continue
		}
		xs = append(xs, p.x)
		ys = append(ys, p.y)
	}
	if len(xs) == 0 {
		it.points = nil
		return
	}
	xmin, xmax := xs[0], xs[0]
	for _, x := range xs {
		xmin = math.Min(xmin, x)
		xmax = math.Max(xmax, x)
	}
	nb := it.bins
	width := (xmax - xmin) / float64(nb)
	if width == 0 {
		width = 1
	}
	sum := make([]float64, nb)
	cnt := make([]float64, nb)
	for i, x := range xs {
		b := int(math.Floor((x - xmin) / width))
		if b >= nb {
			b = nb - 1
		}
		if b < 0 {
			b = 0
		}
		sum[b] += ys[i]
		cnt[b]++
	}
	var out []Point
	for b := 0; b < nb; b++ {
		out = append(out, Point{x: xmin + (float64(b)+0.5)*width - width/2 + width/2*0, y: sum[b], ex: []float64{cnt[b]}, typ: 'i'})
	}
	// gnuplot reports bin centers: xmin + b*width when binrange spans exactly
	for b := range out {
		out[b].x = xmin + float64(b)*(xmax-xmin)/float64(nb-1)
		if nb == 1 {
			out[b].x = xmin
		}
	}
	it.points = out
}

func (in *Interp) outWriter() strWriterI {
	if in.S.output == "" {
		return in.stdout
	}
	if in.outFile == nil {
		in.flush()
		f, err := os.Create(in.S.output)
		if err != nil {
			gpErrNC("cannot open file; output not changed")
		}
		in.outFile = f
	}
	return in.outFile
}

type strWriterI interface {
	WriteString(s string) (int, error)
}

func (in *Interp) closeOutput() {
	if in.outFile != nil {
		in.outFile.Close()
		in.outFile = nil
	}
}

var _ = strconv.Itoa
