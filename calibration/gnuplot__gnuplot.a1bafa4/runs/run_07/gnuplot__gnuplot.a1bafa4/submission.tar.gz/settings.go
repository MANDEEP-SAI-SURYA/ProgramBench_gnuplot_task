package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

type Axis struct {
	name             string
	min, max         float64
	autoMin, autoMax bool
	reverse          bool
	log              bool
	base             float64
	label            string
	labelOffX, labelOffY float64
	format           string
	tics             bool
	mirror           bool
	ticStep          float64
	ticStart         float64
	ticEnd           float64
	ticHasStart      bool
	ticHasEnd        bool
	ticList          []ticItem
	ticAdd           bool
	minor            int // 0 = off; -1 auto
	timeData         bool
	rangeSet         bool
	ticsOut          bool
	rotate           bool
	grid, mgrid      bool
	zeroAxis         bool
	lastSet          bool
	lastMin, lastMax float64
}

type ticItem struct {
	label string
	pos   float64
	level int
}

type Label struct {
	tag      int
	text     string
	x, y     float64
	coordSys string
	just     string // left/right/center
	front    bool
	pointOn  bool
}

type Arrow struct {
	tag            int
	x1, y1, x2, y2 float64
	sys1, sys2     string
	relative       bool
	head           int // 0 none, 1 head, 2 backhead, 3 heads
}

type Settings struct {
	term        string
	termW, termH int
	termFeed    bool
	termOpts    string
	output      string
	outFile     *os.File
	outW        *bufio.Writer
	table       bool
	tableFile   string
	tableDB     string
	samples1    int
	samples2    int
	iso1, iso2  int
	axes        map[string]*Axis
	title       string
	key         Key
	styleData   string
	styleFunc   string
	dfSep       string
	dfMissing   string
	dfComment   string
	parametric  bool
	polar       bool
	timefmt     string
	boxwidth    float64
	boxwidthRel bool
	fillStyle   string
	fillDensity float64
	fillBorder  bool
	dummy1      string
	dummy2      string
	zero        float64
	labels      []*Label
	arrows      []*Arrow
	border      int
	grid        bool
	pointsize   float64
	clipTwo     bool
	logscaleSet map[string]bool
	fitLog      bool
	fitLogFile  string
	fitQuiet    bool
	fitErrVars  bool
	fitCovVars  bool
	fitPrescale bool
	fitLimit    float64
	fitMaxIter  int
	fitScaleErr bool
	view        [4]float64
	surface     bool
	hidden3d    bool
	contour     bool
	tmargin, bmargin, lmargin, rmargin float64
	mxtics      bool
	decimalsign string
	encoding    string
	angles      string
	multiplot   bool
	ticscale    float64
	ticsFront   bool
	xyplane     float64
	xyplaneRel  bool
	minusSign   bool
	fontscale   float64
	sizeX, sizeY float64
	originX, originY float64
	offsets     [4]float64
	histGap     float64
	bars        float64
	jitter      bool
	linestyles  map[int]map[string]string
	clipOne     bool
	svgW, svgH  int
	nolog       bool
}

type Key struct {
	on        bool
	vert      string // top/bottom/center
	horiz     string // left/right/center
	inside    bool
	outsideP  bool
	box       bool
	reverse   bool
	invert    bool
	just      string // Right / Left
	title     string
	sampleLen float64
	spacing   float64
	width     float64
	height    float64
	vertical  bool
	enhanced  bool
	autotitle bool
	columnhead bool
	opaque    bool
	maxcols   int
	maxrows   int
	atSet     bool
	atX, atY  float64
	under     bool
	above     bool
	fixed     bool
}

func newAxis(name string) *Axis {
	a := &Axis{name: name, autoMin: true, autoMax: true, min: -10, max: 10, base: 10, format: "% h", tics: true, mirror: true, minor: 0}
	if name == "x2" || name == "y2" {
		a.tics = false
	}
	if name == "t" {
		a.min, a.max = -5, 5
		a.autoMin, a.autoMax = false, false
	}
	if name == "u" || name == "v" {
		a.min, a.max = -10, 10
		a.autoMin, a.autoMax = false, false
	}
	if name == "r" {
		a.autoMin = false
		a.min = 0
	}
	return a
}

func newSettings() *Settings {
	s := &Settings{}
	s.term = "unknown"
	s.termW, s.termH = 79, 24
	s.termFeed = true
	s.resetAll()
	return s
}

func (s *Settings) resetAll() {
	s.samples1, s.samples2 = 100, 100
	s.iso1, s.iso2 = 10, 10
	s.axes = map[string]*Axis{}
	for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "t", "u", "v", "r"} {
		s.axes[n] = newAxis(n)
	}
	s.title = ""
	s.key = Key{on: true, vert: "top", horiz: "right", inside: true, just: "Right", sampleLen: 4, spacing: 1, vertical: true, enhanced: true, autotitle: true}
	s.styleData = "points"
	s.styleFunc = "lines"
	s.dfSep = ""
	s.dfMissing = ""
	s.dfComment = "#"
	s.parametric = false
	s.polar = false
	s.timefmt = "%d/%m/%y,%H:%M"
	s.boxwidth = -1
	s.fillStyle = "empty"
	s.fillDensity = 1
	s.fillBorder = true
	s.dummy1, s.dummy2 = "x", "y"
	s.zero = 1e-8
	s.labels = nil
	s.arrows = nil
	s.border = 31
	s.pointsize = 1
	s.fitLog = true
	s.fitLogFile = ""
	s.fitErrVars = true
	s.fitPrescale = true
	s.fitLimit = 1e-5
	s.fitScaleErr = true
	s.view = [4]float64{60, 30, 1, 1}
	s.surface = true
	s.tmargin, s.bmargin, s.lmargin, s.rmargin = -1, -1, -1, -1
	s.angles = "radians"
	s.ticscale = 1
	s.xyplane = 0.5
	s.xyplaneRel = true
	s.fontscale = 1
	s.sizeX, s.sizeY = 1, 1
	s.histGap = 2
	s.bars = 1
	s.linestyles = map[int]map[string]string{}
	s.clipOne = true
	s.svgW, s.svgH = 600, 480
	G.degrees = false
}

func resetSettings() {
	term, w, h, feed, out, of, ow := G.S.term, G.S.termW, G.S.termH, G.S.termFeed, G.S.output, G.S.outFile, G.S.outW
	table, tf := G.S.table, G.S.tableFile
	opts := G.S.termOpts
	svgW, svgH := G.S.svgW, G.S.svgH
	G.S.resetAll()
	G.S.term, G.S.termW, G.S.termH, G.S.termFeed, G.S.output, G.S.outFile, G.S.outW = term, w, h, feed, out, of, ow
	G.S.table, G.S.tableFile = table, tf
	G.S.termOpts = opts
	G.S.svgW, G.S.svgH = svgW, svgH
	G.S.table = false
}

func (ps *Parser) evalNum() float64 {
	st := ps.peek().Start
	e := ps.parseExpr()
	return evalTop(e, st).Real()
}
func (ps *Parser) evalStr() string {
	st := ps.peek().Start
	e := ps.parseExpr()
	v := evalTop(e, st)
	if v.K != KStr {
		panic(gpErrAt(st, "expecting string"))
	}
	return v.S
}
func (ps *Parser) evalAny() Value {
	st := ps.peek().Start
	e := ps.parseExpr()
	return evalTop(e, st)
}

func (ps *Parser) isStringStart() bool {
	t := ps.peek()
	if t.K == TStr {
		return true
	}
	if t.K == TIdent {
		if v, ok := G.vars[t.Text]; ok && v.K == KStr {
			return true
		}
		if t.Text == "sprintf" || t.Text == "gprintf" || t.Text == "strftime" {
			return true
		}
	}
	return false
}

func skipToEnd(ps *Parser) {
	for !ps.atEnd() {
		ps.p++
	}
}

var axisNames = []string{"x", "y", "z", "x2", "y2", "cb", "t", "u", "v", "r"}

func axisPrefix(word string, suffix string) (string, bool) {
	for _, a := range []string{"x2", "y2", "cb", "x", "y", "z", "t", "u", "v", "r"} {
		if word == a+suffix {
			return a, true
		}
	}
	return "", false
}

// parse range [a:b]
func parseRange(ps *Parser, ax *Axis) {
	ps.expect("[")
	if ps.isOp(":") {
		ps.p++
	} else if ps.isOp("*") {
		ps.p++
		ax.autoMin = true
		ps.expect(":")
	} else if ps.isOp("]") {
		ps.p++
		return
	} else {
		v := ps.evalAny()
		if ax.timeData && v.K == KStr {
			t, _ := strptime(G.S.timefmt, v.S)
			ax.min = t
		} else {
			ax.min = v.Real()
		}
		ax.autoMin = false
		if ps.isOp(":") {
			ps.p++
		}
	}
	if ps.isOp("]") {
		ps.p++
		return
	}
	if ps.atEnd() {
		panic(ps.errHere("constant expression required"))
	}
	if ps.isOp("*") {
		ps.p++
		ax.autoMax = true
	} else {
		v := ps.evalAny()
		if ax.timeData && v.K == KStr {
			t, _ := strptime(G.S.timefmt, v.S)
			ax.max = t
		} else {
			ax.max = v.Real()
		}
		ax.autoMax = false
	}
	if !ps.isOp("]") {
		panic(ps.errHere("unfinished range"))
	}
	ps.p++
}

func cmdSet(ps *Parser) {
	t := ps.peek()
	if t.K != TIdent {
		panic(ps.errHere("unrecognized option - see 'help set'."))
	}
	w := t.Text
	s := G.S
	ps.p++
	if a, ok := axisPrefix(w, "range"); ok {
		ax := s.axes[a]
		parseRange(ps, ax)
		ax.rangeSet = true
		for !ps.atEnd() {
			if ps.is("reverse") {
				ax.reverse = true
			} else if ps.is("noreverse") {
				ax.reverse = false
			}
			ps.p++
		}
		return
	}
	if a, ok := axisPrefix(w, "label"); ok {
		ax := s.axes[a]
		if ps.atEnd() {
			ax.label = ""
			return
		}
		ax.label = ps.evalStr()
		for !ps.atEnd() {
			if ps.is("offset") {
				ps.p++
				ax.labelOffX, ax.labelOffY = parseCoordPair(ps)
				continue
			}
			ps.p++
		}
		return
	}
	if a, ok := axisPrefix(w, "tics"); ok {
		setTics(ps, s.axes[a])
		return
	}
	if a, ok := axisPrefix(w, "data"); ok {
		ax := s.axes[a]
		if ps.is("time") {
			ps.p++
			ax.timeData = true
		} else {
			ax.timeData = false
		}
		return
	}
	if a, ok := axisPrefix(w, "zeroaxis"); ok {
		s.axes[a].zeroAxis = true
		skipToEnd(ps)
		return
	}
	if strings.HasPrefix(w, "m") {
		if a, ok := axisPrefix(w[1:], "tics"); ok {
			ax := s.axes[a]
			if ps.atEnd() {
				ax.minor = -1
			} else {
				ax.minor = int(ps.evalNum())
			}
			return
		}
	}
	if strings.HasPrefix(w, "no") {
		if a, ok := axisPrefix(w[2:], "tics"); ok {
			s.axes[a].tics = false
			return
		}
	}
	switch {
	case w == "tics":
		for _, a := range []string{"x", "y", "z", "cb"} {
			_ = a
		}
		// handle simple options
		for !ps.atEnd() {
			if ps.is("out") {
				for _, a := range s.axes {
					a.ticsOut = true
				}
			} else if ps.is("in") {
				for _, a := range s.axes {
					a.ticsOut = false
				}
			} else if ps.is("front") {
				s.ticsFront = true
			} else if ps.is("back") {
				s.ticsFront = false
			} else if ps.is("scale") {
				ps.p++
				s.ticscale = ps.evalNum()
				if ps.isOp(",") {
					ps.p++
					ps.evalNum()
				}
				continue
			}
			ps.p++
		}
	case identIs(t, "terminal", 1):
		setTerminal(ps)
	case identIs(t, "output", 1):
		closeOutput()
		if ps.atEnd() {
			s.output = ""
			return
		}
		s.output = ps.evalStr()
		f, err := os.Create(s.output)
		if err != nil {
			panic(gpErrNC("cannot open file; output not changed"))
		}
		s.outFile = f
		s.outW = bufio.NewWriter(f)
	case identIs(t, "table", 2):
		s.table = true
		s.tableFile = ""
		s.tableDB = ""
		if !ps.atEnd() {
			if ps.peek().K == TIdent && strings.HasPrefix(ps.peek().Text, "$") {
				s.tableDB = ps.next().Text
				G.datablocks[s.tableDB] = nil
			} else {
				s.tableFile = ps.evalStr()
				os.WriteFile(s.tableFile, nil, 0644)
			}
		}
		skipToEnd(ps)
	case identIs(t, "print", 2):
		closePrint()
		if ps.atEnd() {
			return
		}
		if ps.peek().K == TIdent && strings.HasPrefix(ps.peek().Text, "$") {
			G.printDB = ps.next().Text
			if ps.is("append") {
				ps.p++
			} else {
				G.datablocks[G.printDB] = nil
			}
			return
		}
		name := ps.evalStr()
		app := false
		if ps.is("append") {
			ps.p++
			app = true
		}
		G.printName = name
		if name == "-" {
			return
		}
		flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(name, flags, 0644)
		if err != nil {
			panic(gpErrNC("cannot open print file"))
		}
		G.printOsFile = f
		G.printFile = bufio.NewWriter(f)
	case identIs(t, "samples", 2):
		s.samples1 = int(ps.evalNum())
		s.samples2 = s.samples1
		if ps.isOp(",") {
			ps.p++
			s.samples2 = int(ps.evalNum())
		}
		if s.samples1 < 2 || s.samples2 < 2 {
			panic(gpErrAt(ps.peek().Start, "sampling rate must be > 1; sampling unchanged"))
		}
	case identIs(t, "isosamples", 3):
		s.iso1 = int(ps.evalNum())
		s.iso2 = s.iso1
		if ps.isOp(",") {
			ps.p++
			s.iso2 = int(ps.evalNum())
		}
	case identIs(t, "title", 2):
		if ps.atEnd() {
			s.title = ""
			return
		}
		s.title = ps.evalStr()
		skipToEnd(ps)
	case identIs(t, "key", 1):
		setKey(ps)
	case identIs(t, "style", 2):
		setStyle(ps)
	case identIs(t, "datafile", 3):
		if identIs(ps.peek(), "separator", 3) {
			ps.p++
			if ps.atEnd() || ps.is("whitespace") {
				if !ps.atEnd() {
					ps.p++
				}
				s.dfSep = ""
			} else if ps.is("comma") {
				ps.p++
				s.dfSep = ","
			} else if ps.is("tab") {
				ps.p++
				s.dfSep = "\t"
			} else {
				s.dfSep = ps.evalStr()
			}
		} else if identIs(ps.peek(), "missing", 3) {
			ps.p++
			if ps.atEnd() {
				s.dfMissing = ""
			} else {
				s.dfMissing = ps.evalStr()
			}
		} else if identIs(ps.peek(), "commentschars", 3) {
			ps.p++
			if ps.atEnd() {
				s.dfComment = "#"
			} else {
				s.dfComment = ps.evalStr()
			}
		} else {
			skipToEnd(ps)
		}
	case identIs(t, "parametric", 2):
		s.parametric = true
		s.dummy1 = "t"
	case identIs(t, "polar", 2):
		s.polar = true
		s.dummy1 = "t"
	case identIs(t, "angles", 2):
		if identIs(ps.peek(), "degrees", 1) {
			G.degrees = true
		} else {
			G.degrees = false
		}
		ps.p++
	case identIs(t, "logscale", 2):
		base := 10.0
		axes := "xyzx2y2cb"
		explicit := false
		if !ps.atEnd() && ps.peek().K == TIdent {
			axes = ps.next().Text
			explicit = true
		}
		_ = explicit
		if !ps.atEnd() {
			base = ps.evalNum()
		}
		for _, a := range parseAxisList(axes) {
			s.axes[a].log = true
			s.axes[a].base = base
		}
	case identIs(t, "format", 2):
		axes := "xyzx2y2cb"
		if ps.peek().K == TIdent {
			axes = ps.next().Text
		}
		f := "% h"
		if !ps.atEnd() {
			f = ps.evalStr()
		}
		for _, a := range parseAxisList(axes) {
			s.axes[a].format = f
		}
	case identIs(t, "timefmt", 2):
		s.timefmt = ps.evalStr()
	case identIs(t, "boxwidth", 3):
		if ps.atEnd() {
			s.boxwidth = -1
			return
		}
		s.boxwidth = ps.evalNum()
		s.boxwidthRel = false
		if ps.is("relative") {
			ps.p++
			s.boxwidthRel = true
		} else if ps.is("absolute") {
			ps.p++
		}
	case identIs(t, "dummy", 2):
		s.dummy1 = ps.next().Text
		if ps.isOp(",") {
			ps.p++
			s.dummy2 = ps.next().Text
		}
	case identIs(t, "zero", 1):
		s.zero = ps.evalNum()
	case identIs(t, "label", 3):
		setLabel(ps)
	case identIs(t, "arrow", 3):
		setArrow(ps)
	case identIs(t, "border", 3):
		if !ps.atEnd() && ps.peek().K == TNum {
			s.border = int(ps.evalNum())
		} else {
			s.border = 31
		}
		skipToEnd(ps)
	case identIs(t, "grid", 1):
		s.grid = true
		if ps.atEnd() {
			s.axes["x"].grid = true
			s.axes["y"].grid = true
		}
		for !ps.atEnd() {
			w := ps.peek().Text
			if a, ok := axisPrefix(w, "tics"); ok {
				s.axes[a].grid = true
			}
			ps.p++
		}
	case identIs(t, "pointsize", 2):
		s.pointsize = ps.evalNum()
	case identIs(t, "fit", 1):
		for !ps.atEnd() {
			if ps.is("nolog") {
				s.fitLog = false
			} else if ps.is("logfile") {
				ps.p++
				s.fitLog = true
				s.fitLogFile = ps.evalStr()
				continue
			} else if ps.is("quiet") {
				s.fitQuiet = true
			} else if ps.is("noquiet") {
				s.fitQuiet = false
			} else if ps.is("errorvariables") {
				s.fitErrVars = true
			} else if ps.is("noerrorvariables") {
				s.fitErrVars = false
			} else if ps.is("covariancevariables") {
				s.fitCovVars = true
			} else if ps.is("nocovariancevariables") {
				s.fitCovVars = false
			} else if ps.is("prescale") {
				s.fitPrescale = true
			} else if ps.is("noprescale") {
				s.fitPrescale = false
			} else if ps.is("limit") {
				ps.p++
				s.fitLimit = ps.evalNum()
				continue
			} else if ps.is("maxiter") {
				ps.p++
				s.fitMaxIter = int(ps.evalNum())
				continue
			} else if ps.is("errorscaling") {
				s.fitScaleErr = true
			} else if ps.is("noerrorscaling") {
				s.fitScaleErr = false
			}
			ps.p++
		}
	case identIs(t, "view", 2):
		if ps.is("map") {
			ps.p++
			s.view = [4]float64{0, 0, 1, 1}
			return
		}
		i := 0
		for !ps.atEnd() && i < 4 {
			if ps.isOp(",") {
				ps.p++
				i++
				continue
			}
			s.view[i] = ps.evalNum()
		}
	case identIs(t, "surface", 2):
		s.surface = true
	case identIs(t, "hidden3d", 3):
		s.hidden3d = true
		skipToEnd(ps)
	case identIs(t, "multiplot", 3):
		s.multiplot = true
		startMultiplot(ps)
	case identIs(t, "tmargin", 2), identIs(t, "bmargin", 2), identIs(t, "lmargin", 2), identIs(t, "rmargin", 2):
		v := -1.0
		if ps.is("at") {
			ps.p++
			if ps.is("screen") {
				ps.p++
			}
		}
		if !ps.atEnd() {
			v = ps.evalNum()
		}
		switch t.Text[0] {
		case 't':
			s.tmargin = v
		case 'b':
			s.bmargin = v
		case 'l':
			s.lmargin = v
		case 'r':
			s.rmargin = v
		}
	case identIs(t, "margins", 4):
		vals := []float64{}
		for !ps.atEnd() {
			if ps.isOp(",") {
				ps.p++
				continue
			}
			vals = append(vals, ps.evalNum())
		}
		for len(vals) < 4 {
			vals = append(vals, -1)
		}
		s.lmargin, s.rmargin, s.bmargin, s.tmargin = vals[0], vals[1], vals[2], vals[3]
	case identIs(t, "size", 2):
		for !ps.atEnd() {
			if ps.is("square") || ps.is("nosquare") || ps.is("noratio") || ps.is("ratio") {
				ps.p++
				continue
			}
			s.sizeX = ps.evalNum()
			if ps.isOp(",") {
				ps.p++
				s.sizeY = ps.evalNum()
			}
		}
	case identIs(t, "origin", 2):
		s.originX = ps.evalNum()
		ps.expect(",")
		s.originY = ps.evalNum()
	case identIs(t, "offsets", 3):
		i := 0
		for !ps.atEnd() && i < 4 {
			if ps.isOp(",") {
				ps.p++
				i++
				continue
			}
			s.offsets[i] = ps.evalNum()
		}
	case identIs(t, "decimalsign", 3):
		skipToEnd(ps)
	case identIs(t, "encoding", 3):
		skipToEnd(ps)
	case identIs(t, "bars", 2):
		skipToEnd(ps)
	case identIs(t, "clip", 2):
		skipToEnd(ps)
	case identIs(t, "contour", 1):
		s.contour = true
		skipToEnd(ps)
	case identIs(t, "autoscale", 2):
		if ps.atEnd() {
			for _, a := range s.axes {
				if a.name != "t" && a.name != "u" && a.name != "v" {
					a.autoMin, a.autoMax = true, true
				}
			}
			return
		}
		w := ps.next().Text
		for _, a := range axisNames {
			if w == a || w == a+"fix" {
				s.axes[a].autoMin, s.axes[a].autoMax = true, true
			}
			if w == a+"min" {
				s.axes[a].autoMin = true
			}
			if w == a+"max" {
				s.axes[a].autoMax = true
			}
		}
		skipToEnd(ps)
	case identIs(t, "linestyle", 6) || w == "ls":
		skipToEnd(ps)
	case identIs(t, "loadpath", 5), identIs(t, "fontpath", 5), identIs(t, "colorbox", 4), identIs(t, "palette", 3), identIs(t, "pm3d", 3), identIs(t, "object", 3), identIs(t, "rtics", 2), identIs(t, "lmargin", 2), identIs(t, "mouse", 2), identIs(t, "termoption", 5), identIs(t, "colorsequence", 6), identIs(t, "xyplane", 3), identIs(t, "ticslevel", 5), identIs(t, "cntrparam", 5), identIs(t, "cntrlabel", 5), identIs(t, "dgrid3d", 2), identIs(t, "historysize", 5), identIs(t, "history", 5), identIs(t, "jitter", 3), identIs(t, "minussign", 5), identIs(t, "micro", 4), identIs(t, "overflow", 4), identIs(t, "psdir", 3), identIs(t, "theta", 3), identIs(t, "walls", 4), identIs(t, "pixmap", 3), identIs(t, "locale", 3), identIs(t, "colorspec", 6), identIs(t, "macros", 3), identIs(t, "raxis", 3), identIs(t, "rgbmax", 4), identIs(t, "link", 2), identIs(t, "nonlinear", 3), identIs(t, "isosurface", 4), identIs(t, "vgrid", 3), identIs(t, "debug", 3), identIs(t, "errorbars", 4), identIs(t, "pointintervalbox", 6), identIs(t, "mapping", 3), identIs(t, "spiderplot", 3), identIs(t, "paxis", 3):
		skipToEnd(ps)
	default:
		panic(gpErrAt(t.Start, "unrecognized option - see 'help set'."))
	}
}

func parseAxisList(s string) []string {
	var out []string
	for len(s) > 0 {
		if strings.HasPrefix(s, "x2") || strings.HasPrefix(s, "y2") || strings.HasPrefix(s, "cb") {
			out = append(out, s[:2])
			s = s[2:]
		} else {
			out = append(out, s[:1])
			s = s[1:]
		}
	}
	return out
}

func parseCoordPair(ps *Parser) (float64, float64) {
	for ps.is("character") || ps.is("graph") || ps.is("screen") || ps.is("first") || ps.is("second") {
		ps.p++
	}
	x := ps.evalNum()
	y := 0.0
	if ps.isOp(",") {
		ps.p++
		for ps.is("character") || ps.is("graph") || ps.is("screen") || ps.is("first") || ps.is("second") {
			ps.p++
		}
		y = ps.evalNum()
	}
	if ps.isOp(",") {
		ps.p++
		ps.evalNum()
	}
	return x, y
}

func setTics(ps *Parser, ax *Axis) {
	ax.tics = true
	for !ps.atEnd() {
		if ps.is("mirror") {
			ax.mirror = true
			ps.p++
		} else if ps.is("nomirror") {
			ax.mirror = false
			ps.p++
		} else if ps.is("out") || ps.is("outside") {
			ax.ticsOut = true
			ps.p++
		} else if ps.is("in") {
			ax.ticsOut = false
			ps.p++
		} else if ps.is("rotate") {
			ps.p++
			ax.rotate = true
			if ps.is("by") {
				ps.p++
				ps.evalNum()
			}
		} else if ps.is("norotate") || ps.is("border") || ps.is("axis") || ps.is("nologscale") || ps.is("logscale") || ps.is("front") || ps.is("back") || ps.is("enhanced") || ps.is("noenhanced") {
			ps.p++
		} else if ps.is("scale") {
			ps.p++
			ps.evalNum()
			if ps.isOp(",") {
				ps.p++
				ps.evalNum()
			}
		} else if ps.is("format") {
			ps.p++
			ax.format = ps.evalStr()
		} else if ps.is("offset") {
			ps.p++
			parseCoordPair(ps)
		} else if ps.is("autofreq") {
			ps.p++
			ax.ticStep = 0
			ax.ticList = nil
		} else if ps.is("add") {
			ps.p++
			ax.ticAdd = true
		} else if ps.is("font") || ps.is("textcolor") || ps.is("tc") {
			ps.p++
			ps.evalAny()
		} else if ps.isOp("(") {
			ps.p++
			if !ax.ticAdd {
				ax.ticList = nil
				ax.ticStep = 0
			}
			for !ps.isOp(")") {
				var lbl string
				hasLbl := false
				if ps.isStringStart() {
					lbl = ps.evalStr()
					hasLbl = true
				}
				pos := ps.evalNum()
				lvl := 0
				if !ps.isOp(",") && !ps.isOp(")") {
					lvl = int(ps.evalNum())
				}
				if !hasLbl {
					lbl = "\x00"
				}
				ax.ticList = append(ax.ticList, ticItem{lbl, pos, lvl})
				if ps.isOp(",") {
					ps.p++
				}
			}
			ps.p++
			ax.ticAdd = false
		} else {
			v1 := ps.evalNum()
			if ps.isOp(",") {
				ps.p++
				v2 := ps.evalNum()
				ax.ticStart = v1
				ax.ticHasStart = true
				ax.ticStep = v2
				ax.ticHasEnd = false
				if ps.isOp(",") {
					ps.p++
					ax.ticEnd = ps.evalNum()
					ax.ticHasEnd = true
				}
			} else {
				ax.ticStep = v1
				ax.ticHasStart = false
				ax.ticHasEnd = false
			}
			ax.ticList = nil
		}
	}
}

func setKey(ps *Parser) {
	k := &G.S.key
	k.on = true
	for !ps.atEnd() {
		t := ps.peek()
		w := t.Text
		switch {
		case w == "on":
			k.on = true
		case w == "off":
			k.on = false
		case identIs(t, "left", 1):
			k.horiz = "left"
		case identIs(t, "right", 1):
			k.horiz = "right"
		case identIs(t, "top", 1):
			k.vert = "top"
		case identIs(t, "bottom", 1):
			k.vert = "bottom"
		case identIs(t, "center", 1):
			if k.vert == "top" && k.horiz == "right" {
				k.vert = "center"
				k.horiz = "center"
			} else {
				k.vert = "center"
			}
		case identIs(t, "box", 1):
			k.box = true
		case identIs(t, "nobox", 3):
			k.box = false
		case identIs(t, "reverse", 3):
			k.reverse = true
		case identIs(t, "noreverse", 5):
			k.reverse = false
		case identIs(t, "invert", 3):
			k.invert = true
		case identIs(t, "noinvert", 5):
			k.invert = false
		case identIs(t, "Left", 1):
			k.just = "Left"
		case identIs(t, "Right", 1):
			k.just = "Right"
		case identIs(t, "inside", 2):
			k.inside = true
		case identIs(t, "outside", 3):
			k.inside = false
		case identIs(t, "horizontal", 3):
			k.vertical = false
		case identIs(t, "vertical", 3):
			k.vertical = true
		case identIs(t, "opaque", 3):
			k.opaque = true
		case identIs(t, "noopaque", 5):
			k.opaque = false
		case identIs(t, "noautotitles", 6):
			k.autotitle = false
		case identIs(t, "autotitles", 4):
			k.autotitle = true
			if ps.peekN(1).Text == "columnheader" || ps.peekN(1).Text == "columnhead" {
				ps.p++
				k.columnhead = true
			}
		case identIs(t, "enhanced", 3):
			k.enhanced = true
		case identIs(t, "noenhanced", 5):
			k.enhanced = false
		case identIs(t, "samplen", 3):
			ps.p++
			k.sampleLen = ps.evalNum()
			continue
		case identIs(t, "spacing", 3):
			ps.p++
			k.spacing = ps.evalNum()
			continue
		case identIs(t, "width", 1):
			ps.p++
			k.width = ps.evalNum()
			continue
		case identIs(t, "height", 1):
			ps.p++
			k.height = ps.evalNum()
			continue
		case identIs(t, "title", 3):
			ps.p++
			if ps.isStringStart() {
				k.title = ps.evalStr()
			} else {
				k.title = ""
			}
			continue
		case identIs(t, "notitle", 3):
			k.title = ""
		case identIs(t, "at", 2):
			ps.p++
			k.atSet = true
			k.atX, k.atY = parseCoordPair(ps)
			continue
		case identIs(t, "maxcols", 4):
			ps.p++
			if ps.is("auto") {
				ps.p++
			} else {
				k.maxcols = int(ps.evalNum())
			}
			continue
		case identIs(t, "maxrows", 4):
			ps.p++
			if ps.is("auto") {
				ps.p++
			} else {
				k.maxrows = int(ps.evalNum())
			}
			continue
		case identIs(t, "default", 3):
			*k = Key{on: true, vert: "top", horiz: "right", inside: true, just: "Right", sampleLen: 4, spacing: 1, vertical: true, enhanced: true, autotitle: true}
		case identIs(t, "font", 1), identIs(t, "textcolor", 2), w == "tc":
			ps.p++
			ps.evalAny()
			continue
		case identIs(t, "lmargin", 1), identIs(t, "rmargin", 1), identIs(t, "tmargin", 1), identIs(t, "bmargin", 1):
			k.inside = false
			if w[0] == 'l' {
				k.horiz = "left"
			} else if w[0] == 'r' {
				k.horiz = "right"
			} else if w[0] == 't' {
				k.vert = "top"
			} else {
				k.vert = "bottom"
			}
		case identIs(t, "fixed", 2), identIs(t, "above", 2), identIs(t, "over", 2), identIs(t, "below", 2), identIs(t, "under", 2), identIs(t, "nobox", 3), identIs(t, "front", 2), identIs(t, "noopaque", 3):
		case w == "linetype" || w == "lt" || w == "linewidth" || w == "lw" || w == "linecolor" || w == "lc" || w == "dashtype" || w == "dt":
			ps.p++
			ps.evalAny()
			continue
		default:
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+w))
		}
		ps.p++
	}
}

func setStyle(ps *Parser) {
	t := ps.next()
	switch {
	case identIs(t, "data", 1):
		G.S.styleData = parseStyleName(ps)
		skipToEnd(ps)
	case identIs(t, "function", 1):
		G.S.styleFunc = parseStyleName(ps)
		skipToEnd(ps)
	case identIs(t, "fill", 2):
		for !ps.atEnd() {
			if ps.is("solid") {
				G.S.fillStyle = "solid"
				ps.p++
				if !ps.atEnd() && ps.peek().K == TNum {
					G.S.fillDensity = ps.evalNum()
				}
				continue
			} else if ps.is("empty") {
				G.S.fillStyle = "empty"
			} else if ps.is("pattern") {
				G.S.fillStyle = "pattern"
			} else if ps.is("noborder") {
				G.S.fillBorder = false
			} else if ps.is("border") {
				G.S.fillBorder = true
			}
			ps.p++
		}
	case identIs(t, "histogram", 2):
		skipToEnd(ps)
	default:
		skipToEnd(ps)
	}
}

var styleNames = []struct {
	full string
	min  int
}{
	{"lines", 1}, {"points", 1}, {"linespoints", 6}, {"impulses", 1}, {"dots", 1}, {"steps", 2}, {"fsteps", 2}, {"histeps", 2}, {"errorbars", 3}, {"yerrorbars", 2}, {"xerrorbars", 2}, {"xyerrorbars", 3}, {"errorlines", 6}, {"yerrorlines", 7}, {"xerrorlines", 7}, {"xyerrorlines", 8}, {"boxes", 3}, {"boxerrorbars", 4}, {"boxxyerrorbars", 4}, {"financebars", 3}, {"candlesticks", 3}, {"vectors", 3}, {"labels", 3}, {"filledcurves", 3}, {"histograms", 4}, {"circles", 3}, {"ellipses", 3}, {"pm3d", 3}, {"image", 3}, {"rgbimage", 4}, {"surface", 2}, {"table", 3}, {"zerrorfill", 3}, {"boxplot", 4}, {"parallelaxes", 3}, {"fillsteps", 5}, {"arrows", 3}, {"cubes", 3}, {"polygons", 3}, {"spiderplot", 3}, {"rgbalpha", 4},
}

func parseStyleName(ps *Parser) string {
	t := ps.peek()
	if t.Text == "lp" {
		ps.p++
		return "linespoints"
	}
	if t.Text == "l" {
		ps.p++
		return "lines"
	}
	if t.Text == "p" {
		ps.p++
		return "points"
	}
	for _, sn := range styleNames {
		if identIs(t, sn.full, sn.min) {
			ps.p++
			if sn.full == "errorbars" {
				return "yerrorbars"
			}
			if sn.full == "errorlines" {
				return "yerrorlines"
			}
			return sn.full
		}
	}
	panic(gpErrAt(ps.peek().End, "unrecognized plot type"))
}

func setLabel(ps *Parser) {
	l := &Label{just: "left", coordSys: "first"}
	if !ps.atEnd() && ps.peek().K == TNum {
		l.tag = int(ps.evalNum())
	} else {
		l.tag = 1
		for _, o := range G.S.labels {
			if o.tag >= l.tag {
				l.tag = o.tag + 1
			}
		}
	}
	if ps.isStringStart() {
		l.text = ps.evalStr()
	}
	for !ps.atEnd() {
		if ps.is("at") {
			ps.p++
			if ps.is("graph") || ps.is("screen") || ps.is("first") || ps.is("character") {
				l.coordSys = ps.next().Text
			}
			l.x = ps.evalNum()
			ps.expect(",")
			if ps.is("graph") || ps.is("screen") || ps.is("first") || ps.is("character") {
				ps.p++
			}
			l.y = ps.evalNum()
			if ps.isOp(",") {
				ps.p++
				ps.evalNum()
			}
			continue
		}
		if ps.is("left") || ps.is("right") || ps.is("center") || ps.is("centre") {
			l.just = ps.next().Text
			if l.just == "centre" {
				l.just = "center"
			}
			continue
		}
		if ps.is("point") {
			l.pointOn = true
		}
		if ps.is("font") || ps.is("offset") || ps.is("tc") || ps.is("textcolor") {
			ps.p++
			if ps.is("offset") {
			}
			continue
		}
		ps.p++
	}
	// replace tag
	for i, o := range G.S.labels {
		if o.tag == l.tag {
			G.S.labels[i] = l
			return
		}
	}
	G.S.labels = append(G.S.labels, l)
}

func setArrow(ps *Parser) {
	a := &Arrow{head: 1, sys1: "first", sys2: "first"}
	if !ps.atEnd() && ps.peek().K == TNum {
		a.tag = int(ps.evalNum())
	} else {
		a.tag = 1
		for _, o := range G.S.arrows {
			if o.tag >= a.tag {
				a.tag = o.tag + 1
			}
		}
	}
	for !ps.atEnd() {
		if ps.is("from") {
			ps.p++
			if ps.is("graph") || ps.is("screen") || ps.is("first") {
				a.sys1 = ps.next().Text
			}
			a.x1 = ps.evalNum()
			ps.expect(",")
			if ps.is("graph") || ps.is("screen") || ps.is("first") {
				ps.p++
			}
			a.y1 = ps.evalNum()
			continue
		}
		if ps.is("to") || ps.is("rto") {
			a.relative = ps.is("rto")
			ps.p++
			if ps.is("graph") || ps.is("screen") || ps.is("first") {
				a.sys2 = ps.next().Text
			}
			a.x2 = ps.evalNum()
			ps.expect(",")
			if ps.is("graph") || ps.is("screen") || ps.is("first") {
				ps.p++
			}
			a.y2 = ps.evalNum()
			continue
		}
		if ps.is("nohead") {
			a.head = 0
		} else if ps.is("head") {
			a.head = 1
		} else if ps.is("backhead") {
			a.head = 2
		} else if ps.is("heads") {
			a.head = 3
		}
		ps.p++
	}
	G.S.arrows = append(G.S.arrows, a)
}

func cmdUnset(ps *Parser) {
	t := ps.peek()
	if t.K != TIdent {
		panic(ps.errHere("Unrecognized option.  See 'help unset'."))
	}
	w := t.Text
	s := G.S
	ps.p++
	if a, ok := axisPrefix(w, "tics"); ok {
		s.axes[a].tics = false
		return
	}
	if a, ok := axisPrefix(w, "label"); ok {
		s.axes[a].label = ""
		return
	}
	if a, ok := axisPrefix(w, "range"); ok {
		ax := s.axes[a]
		ax.autoMin, ax.autoMax = true, true
		return
	}
	if a, ok := axisPrefix(w, "zeroaxis"); ok {
		s.axes[a].zeroAxis = false
		return
	}
	if a, ok := axisPrefix(w, "data"); ok {
		s.axes[a].timeData = false
		return
	}
	if strings.HasPrefix(w, "m") {
		if a, ok := axisPrefix(w[1:], "tics"); ok {
			s.axes[a].minor = 0
			return
		}
	}
	switch {
	case w == "tics":
		for _, a := range s.axes {
			a.tics = false
		}
	case identIs(t, "key", 1):
		s.key.on = false
	case identIs(t, "title", 2):
		s.title = ""
	case identIs(t, "table", 2):
		closeTable()
	case identIs(t, "logscale", 2):
		axes := "xyzx2y2cbr"
		if !ps.atEnd() {
			axes = ps.next().Text
		}
		for _, a := range parseAxisList(axes) {
			if ax, ok := s.axes[a]; ok {
				ax.log = false
			}
		}
	case identIs(t, "parametric", 2):
		s.parametric = false
		s.dummy1 = "x"
	case identIs(t, "polar", 2):
		s.polar = false
		s.dummy1 = "x"
	case identIs(t, "label", 3):
		if ps.atEnd() {
			s.labels = nil
		} else {
			tag := int(ps.evalNum())
			var nl []*Label
			for _, l := range s.labels {
				if l.tag != tag {
					nl = append(nl, l)
				}
			}
			s.labels = nl
		}
	case identIs(t, "arrow", 3):
		if ps.atEnd() {
			s.arrows = nil
		} else {
			tag := int(ps.evalNum())
			var nl []*Arrow
			for _, l := range s.arrows {
				if l.tag != tag {
					nl = append(nl, l)
				}
			}
			s.arrows = nl
		}
	case identIs(t, "grid", 1):
		s.grid = false
		for _, a := range s.axes {
			a.grid = false
		}
	case identIs(t, "border", 3):
		s.border = 0
	case identIs(t, "output", 1):
		closeOutput()
		s.output = ""
	case identIs(t, "print", 2):
		closePrint()
	case identIs(t, "multiplot", 3):
		endMultiplot()
	case identIs(t, "surface", 2):
		s.surface = false
	case identIs(t, "hidden3d", 3):
		s.hidden3d = false
	case identIs(t, "contour", 1):
		s.contour = false
	case identIs(t, "format", 2):
		for _, a := range s.axes {
			a.format = "% h"
		}
	case identIs(t, "datafile", 3):
		skipToEnd(ps)
	case identIs(t, "autoscale", 2), identIs(t, "colorbox", 4), identIs(t, "mouse", 2), identIs(t, "object", 3), identIs(t, "style", 2), identIs(t, "clip", 2), identIs(t, "timestamp", 4), identIs(t, "xyplane", 3), identIs(t, "dgrid3d", 2), identIs(t, "pm3d", 3), identIs(t, "linestyle", 6), identIs(t, "bars", 2), identIs(t, "margins", 4), identIs(t, "historysize", 5):
		skipToEnd(ps)
	case identIs(t, "tmargin", 2):
		s.tmargin = -1
	case identIs(t, "bmargin", 2):
		s.bmargin = -1
	case identIs(t, "lmargin", 2):
		s.lmargin = -1
	case identIs(t, "rmargin", 2):
		s.rmargin = -1
	default:
		panic(gpErrAt(t.Start, "Unrecognized option.  See 'help unset'."))
	}
}

func closePrint() {
	if G.printFile != nil {
		G.printFile.Flush()
		G.printOsFile.Close()
		G.printFile = nil
	}
	G.printName = ""
	G.printDB = ""
}

func closeOutput() {
	finishOutput()
	if G.S.outW != nil {
		G.S.outW.Flush()
		G.S.outFile.Close()
		G.S.outW = nil
		G.S.outFile = nil
	}
}

func outWriter() *bufio.Writer {
	if G.S.outW != nil {
		return G.S.outW
	}
	return stdout
}

func fmtShowNum(f float64) string {
	return cfmtFloat(f, 'g', 6, false, false, false, false, 0, false)
}

func cmdShow(ps *Parser) {
	t := ps.peek()
	if t.K != TIdent {
		panic(ps.errHere("Unrecognized option. See 'help show'."))
	}
	w := t.Text
	s := G.S
	ps.p++
	var b strings.Builder
	if a, ok := axisPrefix(w, "range"); ok {
		ax := s.axes[a]
		lo, hi := "*", "*"
		if !ax.autoMin {
			lo = cfmtFloat(ax.min, 'g', 6, false, false, false, true, 0, false)
		}
		if !ax.autoMax {
			hi = cfmtFloat(ax.max, 'g', 6, false, false, false, true, 0, false)
		}
		rev := "noreverse"
		if ax.reverse {
			rev = "reverse"
		}
		wb := "nowriteback"
		if ax.lastSet {
			wb = "writeback"
		}
		fmt.Fprintf(&b, "\n\tset %srange [ %s : %s ] %s %s", a, lo, hi, rev, wb)
		if (a == "x" || a == "y" || a == "x2" || a == "y2" || a == "z" || a == "cb") && (ax.autoMin || ax.autoMax) {
			cmin, cmax := -10.0, 10.0
			if ax.lastSet {
				cmin, cmax = ax.lastMin, ax.lastMax
			}
			fmt.Fprintf(&b, "  # (currently [%s:%s] )", cfmtFloat(cmin, 'g', 6, false, false, false, true, 0, false), cfmtFloat(cmax, 'g', 6, false, false, false, true, 0, false))
		}
		b.WriteString("\n\n")
		writeErr(b.String())
		return
	}
	if a, ok := axisPrefix(w, "label"); ok {
		ax := s.axes[a]
		fmt.Fprintf(&b, "\n\t%slabel is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", a, ax.label, fmtShowNum(ax.labelOffX), fmtShowNum(ax.labelOffY))
		writeErr(b.String())
		return
	}
	switch {
	case identIs(t, "samples", 3):
		fmt.Fprintf(&b, "\n\tsampling rate is %d, %d\n\n", s.samples1, s.samples2)
	case identIs(t, "isosamples", 3):
		fmt.Fprintf(&b, "\n\tiso sampling rate is %d, %d\n\n", s.iso1, s.iso2)
	case identIs(t, "title", 2):
		fmt.Fprintf(&b, "\n\ttitle is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", s.title)
	case identIs(t, "angles", 2):
		if G.degrees {
			b.WriteString("\n\tAngles are in degrees\n\n")
		} else {
			b.WriteString("\n\tAngles are in radians\n\n")
		}
	case identIs(t, "style", 2):
		if ps.peek().K == TIdent && identIs(ps.peek(), "data", 1) {
			ps.p++
			fmt.Fprintf(&b, "\n\tData are plotted with %s\n\n", s.styleData)
		} else if ps.peek().K == TIdent && identIs(ps.peek(), "function", 1) {
			ps.p++
			fmt.Fprintf(&b, "\n\tFunctions are plotted with %s\n\n", s.styleFunc)
		} else {
			skipToEnd(ps)
			fmt.Fprintf(&b, "\n\tData are plotted with %s\n\n\tFunctions are plotted with %s\n\n", s.styleData, s.styleFunc)
		}
	case identIs(t, "format", 2):
		b.WriteString("\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			fmt.Fprintf(&b, "\t  %s-axis: \"%s\"\n", a, s.axes[a].format)
		}
		b.WriteString("\n")
	case identIs(t, "logscale", 2):
		var parts []string
		for _, a := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			ax := s.axes[a]
			if ax.log {
				if ax.base == 10 {
					parts = append(parts, " "+a)
				} else {
					parts = append(parts, fmt.Sprintf(" %s (base %s)", a, fmtShowNum(ax.base)))
				}
			}
		}
		if len(parts) == 0 {
			b.WriteString("\n\tlogscaling on none\n\n")
		} else {
			b.WriteString("\n\tlogscaling on " + strings.Join(parts, "") + "\n\n")
		}
	case identIs(t, "grid", 1):
		if !s.grid {
			b.WriteString("\n\tgrid is OFF\n\n")
		} else {
			b.WriteString("\n\tgrid is ON\n\n")
		}
	case identIs(t, "variables", 1):
		all := ps.is("all")
		if all {
			ps.p++
		}
		prefixV := ""
		if !ps.atEnd() && ps.peek().K == TIdent {
			prefixV = ps.next().Text
			fmt.Fprintf(&b, "\n\tVariables beginning with %s:\n", prefixV)
		} else {
			b.WriteString("\n\tUser and default variables:\n")
		}
		for _, k := range G.varOrder() {
			if !all && strings.HasPrefix(k, "GPVAL_") && prefixV == "" {
				continue
			}
			if !strings.HasPrefix(k, prefixV) {
				continue
			}
			v := G.vars[k]
			if v.K == KArr {
				fmt.Fprintf(&b, "\t%s = <%d element array>\n", k, len(*v.A))
				continue
			}
			fmt.Fprintf(&b, "\t%s = %s\n", k, v.ShowString())
		}
		b.WriteString("\n")
	case identIs(t, "functions", 1):
		b.WriteString("\n\tUser-Defined Functions:\n")
		for _, k := range G.funcOrder {
			if f, ok := G.funcs[k]; ok {
				fmt.Fprintf(&b, "\t%s\n", f.Text)
			}
		}
		b.WriteString("\n")
	case identIs(t, "output", 2):
		if s.output == "" {
			b.WriteString("\n\toutput is sent to STDOUT\n\n")
		} else {
			fmt.Fprintf(&b, "\n\toutput is sent to '%s'\n\n", s.output)
		}
	case identIs(t, "terminal", 1):
		b.WriteString(termShow())
	case identIs(t, "parametric", 2):
		if s.parametric {
			b.WriteString("\n\tparametric is ON\n\n")
		} else {
			b.WriteString("\n\tparametric is OFF\n\n")
		}
	case identIs(t, "polar", 2):
		if s.polar {
			b.WriteString("\n\tpolar is ON\n\n")
		} else {
			b.WriteString("\n\tpolar is OFF\n\n")
		}
	case identIs(t, "zero", 1):
		fmt.Fprintf(&b, "\n\tzero is %s\n\n", fmtShowNum(s.zero))
	case identIs(t, "dummy", 2):
		fmt.Fprintf(&b, "\n\tdummy variables are %s %s \n\n", s.dummy1, s.dummy2)
	case identIs(t, "timefmt", 3):
		fmt.Fprintf(&b, "\n\tDefault format for reading time data is \"%s\"\n\n", s.timefmt)
	case identIs(t, "boxwidth", 3):
		if s.boxwidth < 0 {
			b.WriteString("\n\tboxwidth is auto\n\tboxdepth is 0\n\n")
		} else if s.boxwidthRel {
			fmt.Fprintf(&b, "\n\tboxwidth is %s relative\n\tboxdepth is 0\n\n", fmtShowNum(s.boxwidth))
		} else {
			fmt.Fprintf(&b, "\n\tboxwidth is %s absolute\n\tboxdepth is 0\n\n", fmtShowNum(s.boxwidth))
		}
	case identIs(t, "pointsize", 2):
		fmt.Fprintf(&b, "\n\tpointsize is %s\n\n", fmtShowNum(s.pointsize))
	case identIs(t, "table", 2):
		if s.table {
			b.WriteString("\n\ttable mode is on\n\n")
		} else {
			b.WriteString("\n\ttable mode is off\n\n")
		}
	case identIs(t, "print", 2):
		if G.printDB != "" {
			fmt.Fprintf(&b, "\n\tprint output is saved to datablock %s\n\n", G.printDB)
		} else if G.printName == "" {
			b.WriteString("\n\tprint output is sent to '<stderr>'\n\n")
		} else if G.printName == "-" {
			b.WriteString("\n\tprint output is sent to '<stdout>'\n\n")
		} else {
			fmt.Fprintf(&b, "\n\tprint output is sent to '%s'\n\n", G.printName)
		}
	case identIs(t, "datafile", 3):
		if ps.is("separator") {
			ps.p++
			if s.dfSep == "" {
				b.WriteString("\n\tdatafile fields separated by whitespace\n\n")
			} else {
				fmt.Fprintf(&b, "\n\tdatafile fields separated by \"%s\"\n\n", s.dfSep)
			}
		} else if ps.is("missing") {
			ps.p++
			if s.dfMissing == "" {
				b.WriteString("\n\tNo missing data string set for datafile\n\n")
			} else {
				fmt.Fprintf(&b, "\n\tMissing data string is \"%s\"\n\n", s.dfMissing)
			}
		} else {
			skipToEnd(ps)
		}
	case identIs(t, "key", 1):
		b.WriteString(showKey())
	case identIs(t, "border", 3):
		fmt.Fprintf(&b, "\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", s.border, s.border)
	case identIs(t, "version", 2):
		skipToEnd(ps)
		b.WriteString("\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
	case identIs(t, "size", 2):
		fmt.Fprintf(&b, "\n\tsize is scaled by %s,%s\n\tNo attempt to control aspect ratio\n\n", fmtShowNum(s.sizeX), fmtShowNum(s.sizeY))
	case identIs(t, "origin", 2):
		fmt.Fprintf(&b, "\n\torigin is set to %s,%s\n\n", fmtShowNum(s.originX), fmtShowNum(s.originY))
	case identIs(t, "offsets", 3):
		fmt.Fprintf(&b, "\n\toffsets are %s, %s, %s, %s\n\n", fmtShowNum(s.offsets[0]), fmtShowNum(s.offsets[1]), fmtShowNum(s.offsets[2]), fmtShowNum(s.offsets[3]))
	case identIs(t, "fit", 2):
		b.WriteString(showFit())
	case identIs(t, "surface", 2):
		if s.surface {
			b.WriteString("\n\tsurface is drawn \n\n")
		} else {
			b.WriteString("\n\tsurface is not drawn\n\n")
		}
	case identIs(t, "view", 2):
		fmt.Fprintf(&b, "\n\tview is %s rot_x, %s rot_z, %s scale, %s scale_z\n\t\t axes are independently scaled\n\t\t azimuth 0\n\n", fmtShowNum(s.view[0]), fmtShowNum(s.view[1]), fmtShowNum(s.view[2]), fmtShowNum(s.view[3]))
	case identIs(t, "label", 3):
		b.WriteString("\n")
		for _, l := range s.labels {
			fmt.Fprintf(&b, "\tlabel %d \"%s\" at %s %s, %s %s, 0 %s %s norotate back nopoint\n", l.tag, l.text, l.coordSys, fmtShowNum(l.x), l.coordSys, fmtShowNum(l.y), l.coordSys, l.just)
		}
		b.WriteString("\n")
	case identIs(t, "margin", 3):
		for _, m := range []struct {
			n string
			v float64
		}{{"lmargin", s.lmargin}, {"rmargin", s.rmargin}, {"bmargin", s.bmargin}, {"tmargin", s.tmargin}} {
			if m.v < 0 {
				fmt.Fprintf(&b, "\t%s is computed automatically\n", m.n)
			} else {
				fmt.Fprintf(&b, "\t%s is set to %s\n", m.n, fmtShowNum(m.v))
			}
		}
		b.WriteString("\n")
		writeErr("\n" + b.String())
		return
	default:
		if a, ok := axisPrefix(w, "data"); ok {
			if s.axes[a].timeData {
				fmt.Fprintf(&b, "\n\t%s is set to time\n\n", a)
			} else {
				fmt.Fprintf(&b, "\n\t%s is set to numerical\n\n", a)
			}
			break
		}
		skipToEnd(ps)
		if identIs(t, "all", 1) || identIs(t, "plot", 1) || identIs(t, "tics", 3) || identIs(t, "xtics", 3) || identIs(t, "ytics", 3) || identIs(t, "colorbox", 3) || identIs(t, "palette", 3) || identIs(t, "style", 2) || identIs(t, "encoding", 3) || identIs(t, "decimalsign", 3) || identIs(t, "clip", 2) || identIs(t, "autoscale", 2) || identIs(t, "arrow", 3) || identIs(t, "loadpath", 3) {
			return
		}
		panic(gpErrAt(t.Start, "Unrecognized option. See 'help show'."))
	}
	if s := b.String(); s != "" {
		writeErr(s)
	}
}

func showKey() string {
	k := G.S.key
	var b strings.Builder
	if !k.on {
		return "\n\tkey is OFF\n\n"
	}
	pos := "top right"
	if k.vert != "top" || k.horiz != "right" {
		pos = k.vert + " " + k.horiz
		if k.vert == "center" && k.horiz == "center" {
			pos = "center center"
		}
	}
	orient := "vertical"
	if !k.vertical {
		orient = "horizontal"
	}
	if k.inside {
		fmt.Fprintf(&b, "\n\tkey is ON, position: %s %s fixed  offset: (character 0, 0)\n", pos, orient)
	} else {
		fmt.Fprintf(&b, "\n\tkey is ON, position: outside %s %s fixed  offset: (character 0, 0)\n", pos, orient)
	}
	just := "right"
	if k.just == "Left" {
		just = "left"
	}
	rev := "not reversed"
	if k.reverse {
		rev = "reversed"
	}
	inv := "not inverted"
	if k.invert {
		inv = "inverted"
	}
	enh := "enhanced"
	if !k.enhanced {
		enh = "noenhanced"
	}
	box := "not boxed"
	if k.box {
		box = "boxed\n\twith  lt black linewidth 1.000 dashtype solid"
	}
	fmt.Fprintf(&b, "\tkey is %s justified, %s, %s, %s and %s\n", just, rev, inv, enh, box)
	if k.opaque {
		b.WriteString("\tkey box is opaque and drawn in front of the graph\n")
	}
	fmt.Fprintf(&b, "\tsample length is %s characters\n", fmtShowNum(k.sampleLen))
	fmt.Fprintf(&b, "\tvertical spacing is %s characters\n", fmtShowNum(k.spacing))
	fmt.Fprintf(&b, "\twidth adjustment is %s characters\n", fmtShowNum(k.width))
	fmt.Fprintf(&b, "\theight adjustment is %s characters\n", fmtShowNum(k.height))
	if k.autotitle {
		b.WriteString("\tcurves are automatically titled with filename\n")
	} else {
		b.WriteString("\tcurves are not automatically titled\n")
	}
	b.WriteString("\tmaximum number of columns is calculated automatically\n")
	b.WriteString("\tmaximum number of rows is calculated automatically\n")
	fmt.Fprintf(&b, "\n\tkey title is \"%s\" center justified \n\n", k.title)
	return b.String()
}

func showFit() string {
	s := G.S
	var b strings.Builder
	if s.fitQuiet {
		b.WriteString("\n\tfit will not output results to console.\n")
	} else {
		b.WriteString("\n\tfit will output brief results to console and log-file.\n")
	}
	b.WriteString("\tfit can handle up to 12 independent variables\n")
	if s.fitPrescale {
		b.WriteString("\tfit will prescale parameters by their initial values\n")
	} else {
		b.WriteString("\tfit will not prescale parameters by their initial values\n")
	}
	if s.fitErrVars {
		b.WriteString("\tfit will place parameter errors in variables\n")
	} else {
		b.WriteString("\tfit will not place parameter errors in variables\n")
	}
	if s.fitCovVars {
		b.WriteString("\tfit will place covariances in variables\n")
	} else {
		b.WriteString("\tfit will not place covariances in variables\n")
	}
	if s.fitScaleErr {
		b.WriteString("\tfit will scale parameter errors with the reduced chi square\n")
	} else {
		b.WriteString("\tfit will not scale parameter errors with the reduced chi square\n")
	}
	if !s.fitLog {
		b.WriteString("\tfit will not create a log file\n")
	} else if s.fitLogFile != "" {
		fmt.Fprintf(&b, "\tlog-file for fits was set by the user to \n\t'%s'\n", s.fitLogFile)
	} else {
		b.WriteString("\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
	}
	fmt.Fprintf(&b, "\tfits will be considered to have converged if  delta chisq < chisq * %s\n", fmtShowNum(s.fitLimit))
	if s.fitMaxIter > 0 {
		fmt.Fprintf(&b, "\tfit will stop after a maximum of %d iterations\n", s.fitMaxIter)
	} else {
		b.WriteString("\tfit has no limit in the number of iterations\n")
	}
	b.WriteString("\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n")
	b.WriteString("\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
	return b.String()
}

var _ = math.Pi
var _ = strconv.Itoa
