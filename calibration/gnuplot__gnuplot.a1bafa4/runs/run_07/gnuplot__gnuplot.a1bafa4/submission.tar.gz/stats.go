package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                          int
	mean, sd, ssd, skew, kurt, adev, sum, sumsq float64
	min, max                                   float64
	imin, imax                                 int
	q1, med, q3                                float64
}

func computeColStats(v []float64) colStats {
	var c colStats
	n := len(v)
	c.n = n
	if n == 0 {
		return c
	}
	c.min, c.max = v[0], v[0]
	for i, x := range v {
		c.sum += x
		c.sumsq += x * x
		if x < c.min {
			c.min, c.imin = x, i
		}
		if x > c.max {
			c.max, c.imax = x, i
		}
	}
	c.mean = c.sum / float64(n)
	var m2, m3, m4 float64
	for _, x := range v {
		d := x - c.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		c.adev += math.Abs(d)
	}
	c.adev /= float64(n)
	c.sd = math.Sqrt(m2 / float64(n))
	if n > 1 {
		c.ssd = math.Sqrt(m2 / float64(n-1))
	}
	if c.sd > 0 {
		c.skew = (m3 / float64(n)) / (c.sd * c.sd * c.sd)
		c.kurt = (m4 / float64(n)) / (c.sd * c.sd * c.sd * c.sd)
	}
	s := append([]float64(nil), v...)
	sort.Float64s(s)
	q := func(p float64) float64 {
		pos := p * float64(n)
		ip := int(pos)
		if float64(ip) == pos && ip > 0 {
			return (s[ip-1] + s[ip]) / 2
		}
		if ip >= n {
			ip = n - 1
		}
		return s[ip]
	}
	c.q1, c.med, c.q3 = q(0.25), q(0.5), q(0.75)
	return c
}

func cmdStats(ps *Parser) {
	t := ps.peek()
	var fname string
	if t.K == TStr {
		fname = t.S
		ps.p++
	} else if t.K == TIdent && strings.HasPrefix(t.Text, "$") {
		fname = t.Text
		ps.p++
	} else {
		// expression?
		fname = ps.evalStr()
	}
	e := &PlotElem{fname: fname, indexB: -1, indexStep: 1}
	prefix := "STATS"
	output := true
	for !ps.atEnd() {
		t := ps.peek()
		switch {
		case identIs(t, "using", 1):
			ps.p++
			e.hasUsing = true
			parseUsing(ps, e)
		case identIs(t, "index", 1):
			ps.p++
			e.hasIndex = true
			e.indexA = int(ps.evalNum())
			e.indexB = e.indexA
			if ps.isOp(":") {
				ps.p++
				e.indexB = int(ps.evalNum())
			}
		case identIs(t, "every", 2):
			ps.p++
			e.hasEvery = true
			for i := 0; i < 6; i++ {
				if ps.isOp(":") {
					ps.p++
					continue
				}
				if ps.atEnd() || ps.peek().K == TIdent {
					break
				}
				e.every[i] = int(ps.evalNum())
				e.everySet[i] = true
				if ps.isOp(":") {
					ps.p++
				} else {
					break
				}
			}
		case identIs(t, "name", 2) || identIs(t, "prefix", 3):
			ps.p++
			prefix = ps.evalStr()
		case identIs(t, "nooutput", 3):
			ps.p++
			output = false
		case identIs(t, "output", 3):
			ps.p++
			output = true
		case identIs(t, "matrix", 3):
			ps.p++
		default:
			panic(gpErrAt(t.Start, "unrecognized option"))
		}
	}
	lines, err := readDataLines(fname)
	if err != nil {
		if ge, ok := err.(*GPError); ok {
			panic(ge)
		}
		warn("Cannot find or open file \"" + fname + "\"")
		warn("Can't read data file")
		return
	}
	// count blanks and rows
	blank := 0
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
		}
	}
	df := parseDataFile(lines)
	ncols := 0
	if e.hasUsing {
		ncols = len(e.usingNodes)
	} else {
		// determine from first row
		for _, idx := range df.indexes {
			for _, b := range idx {
				if len(b) > 0 {
					ncols = len(b[0].fields)
					break
				}
			}
			if ncols > 0 {
				break
			}
		}
		if ncols > 2 {
			ncols = 2
		}
	}
	var xs, ys []float64
	invalid := 0
	records := 0
	headers := 0
	firstRow := true
	blocks := len(df.indexes)
	for ii, idx := range df.indexes {
		if e.hasIndex && (ii < e.indexA || ii > e.indexB) {
			continue
		}
		curIndex = ii
		for _, blk := range idx {
			for ri, row := range blk {
				r := row
				if firstRow {
					firstRow = false
					if rowLooksHeader(row, e) {
						_ = headers
						hs := make([]string, len(row.fields))
						for i, f := range row.fields {
							hs[i] = strings.Trim(f, "\"")
						}
						curHeader = hs
						continue
					}
				}
				curRow = &r
				curRowNum = ri
				vals := []float64{}
				bad := false
				for k := 0; k < ncols; k++ {
					var v float64
					if e.hasUsing {
						undefFlag = false
						x := safeEval(e.usingNodes[k])
						if undefFlag || x.K == KUndef {
							bad = true
						} else if x.K == KStr {
							f, ok := parseNumField(x.S)
							if !ok {
								bad = true
							}
							v = f
						} else {
							v = realPart(x)
						}
						undefFlag = false
					} else {
						if k >= len(row.fields) {
							bad = true
							break
						}
						f, st := parseField(row.fields[k])
						if st != 1 {
							bad = true
						}
						v = f
					}
					if math.IsNaN(v) {
						bad = true
					}
					vals = append(vals, v)
				}
				if bad {
					invalid++
					continue
				}
				records++
				if ncols >= 1 {
					xs = append(xs, vals[0])
				}
				if ncols >= 2 {
					ys = append(ys, vals[1])
				}
			}
		}
	}
	curRow = nil
	if records == 0 {
		panic(gpErrNC("All points out of range"))
	}
	setV := func(name string, v float64) {
		setVar(prefix+"_"+name, FltV(v))
	}
	setI := func(name string, v int) {
		setVar(prefix+"_"+name, IntV(int64(v)))
	}
	setI("records", records)
	setI("headers", headers)
	setI("outofrange", 0)
	setI("invalid", invalid)
	setI("blank", blank)
	setI("blocks", blocks)
	setI("columns", ncols)
	var b strings.Builder
	b.WriteString("\n* FILE: \n")
	fmt.Fprintf(&b, "  Records:           %d\n", records)
	fmt.Fprintf(&b, "  Out of range:      %d\n", 0)
	fmt.Fprintf(&b, "  Invalid:           %d\n", invalid)
	fmt.Fprintf(&b, "  Header records:    %d\n", headers)
	fmt.Fprintf(&b, "  Blank:             %d\n", blank)
	fmt.Fprintf(&b, "  Data Blocks:       %d\n", blocks)
	n := float64(records)
	if ncols == 1 {
		c := computeColStats(xs)
		b.WriteString("\n* COLUMN: \n")
		row := func(lbl string, v float64) {
			fmt.Fprintf(&b, "  %-16s%10.4f\n", lbl, v)
		}
		row("Mean:", c.mean)
		row("Std Dev:", c.sd)
		row("Sample StdDev:", c.ssd)
		row("Skewness:", c.skew)
		row("Kurtosis:", c.kurt)
		row("Avg Dev:", c.adev)
		row("Sum:", c.sum)
		row("Sum Sq.:", c.sumsq)
		b.WriteString("\n")
		row("Mean Err.:", c.sd/math.Sqrt(n))
		row("Std Dev Err.:", c.sd/math.Sqrt(2*n))
		row("Skewness Err.:", math.Sqrt(6/n))
		row("Kurtosis Err.:", math.Sqrt(24/n))
		b.WriteString("\n")
		fmt.Fprintf(&b, "  %-16s%10.4f [%d]\n", "Minimum:", c.min, c.imin)
		fmt.Fprintf(&b, "  %-16s%10.4f [%d]\n", "Maximum:", c.max, c.imax)
		fmt.Fprintf(&b, "  %-16s%10.4f \n", "Quartile:", c.q1)
		fmt.Fprintf(&b, "  %-16s%10.4f \n", "Median:", c.med)
		fmt.Fprintf(&b, "  %-16s%10.4f \n", "Quartile:", c.q3)
		b.WriteString("\n")
		setColVars(setV, setI, c, "", n)
	} else {
		cx := computeColStats(xs)
		cy := computeColStats(ys)
		b.WriteString("\n* COLUMNS:\n")
		row := func(lbl string, v1, v2 float64) {
			fmt.Fprintf(&b, "  %-16s%10.4f %17.4f\n", lbl, v1, v2)
		}
		row("Mean:", cx.mean, cy.mean)
		row("Std Dev:", cx.sd, cy.sd)
		row("Sample StdDev:", cx.ssd, cy.ssd)
		row("Skewness:", cx.skew, cy.skew)
		row("Kurtosis:", cx.kurt, cy.kurt)
		row("Avg Dev:", cx.adev, cy.adev)
		row("Sum:", cx.sum, cy.sum)
		row("Sum Sq.:", cx.sumsq, cy.sumsq)
		b.WriteString("\n")
		row("Mean Err.:", cx.sd/math.Sqrt(n), cy.sd/math.Sqrt(n))
		row("Std Dev Err.:", cx.sd/math.Sqrt(2*n), cy.sd/math.Sqrt(2*n))
		row("Skewness Err.:", math.Sqrt(6/n), math.Sqrt(6/n))
		row("Kurtosis Err.:", math.Sqrt(24/n), math.Sqrt(24/n))
		b.WriteString("\n")
		fmt.Fprintf(&b, "  %-16s%10.4f [%d] %13.4f [%d]\n", "Minimum:", cx.min, cx.imin, cy.min, cy.imin)
		fmt.Fprintf(&b, "  %-16s%10.4f [%d] %13.4f [%d]\n", "Maximum:", cx.max, cx.imax, cy.max, cy.imax)
		row("Quartile:", cx.q1, cy.q1)
		row("Median:", cx.med, cy.med)
		row("Quartile:", cx.q3, cy.q3)
		b.WriteString("\n")
		// linear model
		var sxy, sxx, syy float64
		for i := range xs {
			sxy += (xs[i] - cx.mean) * (ys[i] - cy.mean)
			sxx += (xs[i] - cx.mean) * (xs[i] - cx.mean)
			syy += (ys[i] - cy.mean) * (ys[i] - cy.mean)
		}
		slope := sxy / sxx
		icpt := cy.mean - slope*cx.mean
		var rss float64
		for i := range xs {
			r := ys[i] - (slope*xs[i] + icpt)
			rss += r * r
		}
		s2 := rss / (n - 2)
		slopeErr := math.Sqrt(s2 / sxx)
		icptErr := math.Sqrt(s2 * (1/n + cx.mean*cx.mean/sxx))
		corr := sxy / math.Sqrt(sxx*syy)
		sumxy := 0.0
		for i := range xs {
			sumxy += xs[i] * ys[i]
		}
		sign := "+"
		ai := icpt
		if icpt < 0 {
			sign = "-"
			ai = -icpt
		}
		fmt.Fprintf(&b, "  Linear Model:       y = %s x %s %s\n", fmtG(slope, 4), sign, fmtG(ai, 4))
		fmt.Fprintf(&b, "  Slope:              %s +- %s\n", fmtG(slope, 4), fmtG(slopeErr, 4))
		fmt.Fprintf(&b, "  Intercept:          %s +- %s\n", fmtG(icpt, 4), fmtG(icptErr, 4))
		fmt.Fprintf(&b, "  Correlation:        r = %.4f\n", corr)
		fmt.Fprintf(&b, "  Sum xy:             %s\n", fmtG(sumxy, 6))
		b.WriteString("\n")
		setColVars(setV, setI, cx, "_x", n)
		setColVars(setV, setI, cy, "_y", n)
		setV("slope", slope)
		setV("intercept", icpt)
		setV("slope_err", slopeErr)
		setV("intercept_err", icptErr)
		setV("correlation", corr)
		setV("sumxy", sumxy)
		setV("pos_min_y", xs[cy.imin])
		setV("pos_max_y", xs[cy.imax])
	}
	if output {
		writeErr(b.String())
	}
}

func fmtG(v float64, p int) string {
	return cfmtFloat(v, 'g', p, false, false, false, false, 0, false)
}

func setColVars(setV func(string, float64), setI func(string, int), c colStats, sfx string, n float64) {
	setV("mean"+sfx, c.mean)
	setV("stddev"+sfx, c.sd)
	setV("ssd"+sfx, c.ssd)
	setV("skewness"+sfx, c.skew)
	setV("kurtosis"+sfx, c.kurt)
	setV("adev"+sfx, c.adev)
	setV("sum"+sfx, c.sum)
	setV("sumsq"+sfx, c.sumsq)
	setV("mean_err"+sfx, c.sd/math.Sqrt(n))
	setV("stddev_err"+sfx, c.sd/math.Sqrt(2*n))
	setV("skewness_err"+sfx, math.Sqrt(6/n))
	setV("kurtosis_err"+sfx, math.Sqrt(24/n))
	setV("min"+sfx, c.min)
	setV("max"+sfx, c.max)
	setI("index_min"+sfx, c.imin)
	setI("index_max"+sfx, c.imax)
	setV("lo_quartile"+sfx, c.q1)
	setV("median"+sfx, c.med)
	setV("up_quartile"+sfx, c.q3)
}
