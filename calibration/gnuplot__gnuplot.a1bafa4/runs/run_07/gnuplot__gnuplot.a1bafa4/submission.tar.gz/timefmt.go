package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

type tmS struct {
	sec, min, hour, mday, mon, year, wday, yday int
	frac                                         float64
}

func breakTime(t float64) tmS {
	fl := math.Floor(t)
	tt := time.Unix(int64(fl), 0).UTC()
	return tmS{sec: tt.Second(), min: tt.Minute(), hour: tt.Hour(), mday: tt.Day(), mon: int(tt.Month()) - 1,
		year: tt.Year(), wday: int(tt.Weekday()), yday: tt.YearDay() - 1, frac: t - fl}
}

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func strftime(f string, t float64) string {
	tm := breakTime(t)
	var b strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			b.WriteByte(c)
			continue
		}
		i++
		// optional width/precision for %S
		spec := ""
		for i < len(f) && (f[i] == '.' || (f[i] >= '0' && f[i] <= '9')) {
			spec += string(f[i])
			i++
		}
		if i >= len(f) {
			break
		}
		switch f[i] {
		case 'Y':
			b.WriteString(strconv.Itoa(tm.year))
		case 'y':
			fmt.Fprintf(&b, "%02d", tm.year%100)
		case 'm':
			fmt.Fprintf(&b, "%02d", tm.mon+1)
		case 'd':
			fmt.Fprintf(&b, "%02d", tm.mday)
		case 'e':
			fmt.Fprintf(&b, "%2d", tm.mday)
		case 'H':
			fmt.Fprintf(&b, "%02d", tm.hour)
		case 'I':
			h := tm.hour % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%02d", h)
		case 'p':
			if tm.hour < 12 {
				b.WriteString("AM")
			} else {
				b.WriteString("PM")
			}
		case 'M':
			fmt.Fprintf(&b, "%02d", tm.min)
		case 'S':
			if strings.Contains(spec, ".") {
				p, _ := strconv.Atoi(spec[strings.Index(spec, ".")+1:])
				s := float64(tm.sec) + tm.frac
				w := 3 + p
				if p == 0 {
					w = 2
				}
				b.WriteString(fmt.Sprintf("%0*.*f", w, p, s))
			} else {
				fmt.Fprintf(&b, "%02d", tm.sec)
			}
		case 'j':
			fmt.Fprintf(&b, "%03d", tm.yday+1)
		case 'b', 'h':
			b.WriteString(monNames[tm.mon][:3])
		case 'B':
			b.WriteString(monNames[tm.mon])
		case 'a':
			b.WriteString(dayNames[tm.wday][:3])
		case 'A':
			b.WriteString(dayNames[tm.wday])
		case 's':
			b.WriteString(strconv.FormatInt(int64(t), 10))
		case 'D':
			fmt.Fprintf(&b, "%02d/%02d/%02d", tm.mon+1, tm.mday, tm.year%100)
		case 'F':
			fmt.Fprintf(&b, "%d-%02d-%02d", tm.year, tm.mon+1, tm.mday)
		case 'T':
			fmt.Fprintf(&b, "%02d:%02d:%02d", tm.hour, tm.min, tm.sec)
		case 'R':
			fmt.Fprintf(&b, "%02d:%02d", tm.hour, tm.min)
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case '%':
			b.WriteByte('%')
		default:
			b.WriteByte('%')
			b.WriteByte(f[i])
		}
	}
	return b.String()
}

func strptime(f, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	sec := 0.0
	yday := -1
	pm := -1
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		st := si
		neg := false
		if si < len(s) && (s[si] == '-' || s[si] == '+') {
			neg = s[si] == '-'
			si++
		}
		ds := si
		for si < len(s) && si-ds < maxd && s[si] >= '0' && s[si] <= '9' {
			si++
		}
		if si == ds {
			si = st
			return 0, false
		}
		v, _ := strconv.Atoi(s[ds:si])
		if neg {
			v = -v
		}
		return v, true
	}
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == c {
				si++
				continue
			}
			return 0, false
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			year, ok = readInt(2)
			if year < 69 {
				year += 2000
			} else {
				year += 1900
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			var v int
			v, ok = readInt(2)
			sec = float64(v)
			if si < len(s) && s[si] == '.' {
				st := si
				si++
				for si < len(s) && s[si] >= '0' && s[si] <= '9' {
					si++
				}
				fr, _ := strconv.ParseFloat("0"+s[st:si], 64)
				sec += fr
			}
		case 's':
			for si < len(s) && s[si] == ' ' {
				si++
			}
			st := si
			for si < len(s) && strings.IndexByte("0123456789.-+eE", s[si]) >= 0 {
				si++
			}
			v, err := strconv.ParseFloat(s[st:si], 64)
			if err != nil {
				return 0, false
			}
			return v, true
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m[:3]) {
					mon = k + 1
					if f[i] == 'B' && len(s)-si >= len(m) && strings.EqualFold(s[si:si+len(m)], m) {
						si += len(m)
					} else {
						si += 3
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			for _, m := range dayNames {
				if len(s)-si >= 3 && strings.EqualFold(s[si:si+3], m[:3]) {
					si += 3
					if f[i] == 'A' && len(s)-si >= len(m)-3 && strings.EqualFold(s[si-3:si-3+len(m)], m) {
						si += len(m) - 3
					}
					ok = true
					break
				}
			}
		case 'p':
			if len(s)-si >= 2 {
				pm = 0
				if strings.EqualFold(s[si:si+2], "PM") {
					pm = 1
				}
				si += 2
				ok = true
			}
		case '%':
			ok = si < len(s) && s[si] == '%'
			si++
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + sec, true
}
