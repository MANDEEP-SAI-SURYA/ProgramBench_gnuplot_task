package main

import (
	"math"
	"os"
	"strconv"
	"strings"
)

// a data row
type DataRow struct {
	fields []string
	line   string
}

// DataSet: blocks separated by blank lines; datasets (index) separated by double blank lines
type DataFile struct {
	indexes [][][]DataRow // index -> block -> rows
	header  []string
}

var curRow *DataRow
var curRowNum int
var curHeader []string
var curColFill []Value // numeric values cache

func splitFields(line string) []string {
	sep := G.S.dfSep
	var out []string
	if sep == "" {
		i := 0
		for i < len(line) {
			for i < len(line) && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
				i++
			}
			if i >= len(line) {
				break
			}
			if line[i] == '"' {
				j := i + 1
				for j < len(line) && line[j] != '"' {
					j++
				}
				out = append(out, line[i:min(j+1, len(line))])
				i = j + 1
				continue
			}
			j := i
			for j < len(line) && !(line[j] == ' ' || line[j] == '\t' || line[j] == '\r') {
				j++
			}
			out = append(out, line[i:j])
			i = j
		}
		return out
	}
	parts := strings.Split(line, sep)
	for _, p := range parts {
		out = append(out, strings.TrimSpace(p))
	}
	return out
}

func isCommentLine(line string) bool {
	t := strings.TrimLeft(line, " \t")
	if t == "" {
		return false
	}
	return strings.ContainsRune(G.S.dfComment, rune(t[0]))
}

func readDataLines(name string) ([]string, error) {
	if name == "-" {
		return readInlineData(), nil
	}
	if strings.HasPrefix(name, "$") {
		db, ok := G.datablocks[name]
		if !ok {
			return nil, &GPError{Msg: "no datablock named " + name, Pos: -1}
		}
		return db, nil
	}
	data, err := os.ReadFile(name)
	if err != nil {
		return nil, err
	}
	s := string(data)
	s = strings.TrimSuffix(s, "\n")
	lines := strings.Split(s, "\n")
	for i := range lines {
		lines[i] = strings.TrimRight(lines[i], "\r")
	}
	if len(data) == 0 {
		return nil, nil
	}
	return lines, nil
}

func parseDataFile(lines []string) *DataFile {
	df := &DataFile{}
	var cur [][]DataRow
	var blk []DataRow
	blank := 0
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
			if blank == 1 {
				if blk != nil || len(cur) > 0 {
					cur = append(cur, blk)
				}
				blk = nil
			} else if blank == 2 {
				if len(cur) > 0 {
					df.indexes = append(df.indexes, cur)
				}
				cur = nil
			}
			continue
		}
		if isCommentLine(l) {
			continue
		}
		blank = 0
		blk = append(blk, DataRow{fields: splitFields(l), line: l})
	}
	if blk != nil {
		cur = append(cur, blk)
	}
	if len(cur) > 0 {
		df.indexes = append(df.indexes, cur)
	}
	return df
}

func parseNumField(s string) (float64, bool) {
	if s == "" {
		return 0, false
	}
	if s[0] == '"' {
		s = strings.Trim(s, "\"")
	}
	// gnuplot accepts leading numeric part (strtod)
	f, err := strconv.ParseFloat(s, 64)
	if err == nil {
		return f, true
	}
	// try prefix
	end := 0
	for end < len(s) && strings.IndexByte("0123456789+-.eE", s[end]) >= 0 {
		end++
	}
	for end > 0 {
		f, err = strconv.ParseFloat(s[:end], 64)
		if err == nil {
			return f, true
		}
		end--
	}
	low := strings.ToLower(s)
	if low == "nan" {
		return math.NaN(), true
	}
	if low == "inf" || low == "+inf" {
		return math.Inf(1), true
	}
	if low == "-inf" {
		return math.Inf(-1), true
	}
	return 0, false
}

var missingFlag bool

func columnValue(c Value, asString bool) Value {
	if curRow == nil {
		panic(gpErrNC("column() called from invalid context"))
	}
	if c.K == KStr {
		// column by header name
		idx := -1
		for i, h := range curHeader {
			if h == c.S {
				idx = i
				break
			}
		}
		if idx < 0 {
			return undefinedV()
		}
		c = IntV(int64(idx + 1))
	}
	n := int(toIntVal(c))
	if n == 0 {
		if asString {
			return StrV(strconv.Itoa(curRowNum))
		}
		return FltV(float64(curRowNum))
	}
	if n == -2 {
		return FltV(float64(curIndex))
	}
	if n == -1 {
		return FltV(float64(curBlock))
	}
	if n < 1 || n > len(curRow.fields) {
		if asString {
			return undefinedV()
		}
		return undefinedV()
	}
	f := curRow.fields[n-1]
	if asString {
		return StrV(strings.Trim(f, "\""))
	}
	if G.S.dfMissing != "" && f == G.S.dfMissing {
		missingFlag = true
		return undefinedV()
	}
	v, ok := parseNumField(f)
	if !ok {
		return undefinedV()
	}
	return FltV(v)
}

var curIndex, curBlock int

func columnHead(n int64) string {
	if int(n) >= 1 && int(n) <= len(curHeader) {
		return curHeader[n-1]
	}
	return ""
}

func columnValid(c Value) bool {
	n := int(toIntVal(c))
	if curRow == nil || n < 1 || n > len(curRow.fields) {
		return false
	}
	f := curRow.fields[n-1]
	if G.S.dfMissing != "" && f == G.S.dfMissing {
		return false
	}
	_, ok := parseNumField(f)
	return ok
}
