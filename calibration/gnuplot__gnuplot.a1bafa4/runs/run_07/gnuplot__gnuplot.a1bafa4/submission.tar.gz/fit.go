package main

import (
	"os"
	"strconv"
	"fmt"
	"math"
	"strings"
)

func cmdFit(ps *Parser) {
	s := G.S
	// optional ranges
	xa := axisCopy(s.axes["x"])
	xa.autoMin, xa.autoMax = true, true
	for ps.isOp("[") {
		if ps.peekN(1).K == TIdent && ps.peekN(2).K == TOp && ps.peekN(2).Text == "=" {
			ps.p += 2
			ps.toks[ps.p] = Token{K: TOp, Text: "[", Start: ps.toks[ps.p].Start}
		}
		parseRange(ps, xa)
	}
	fstart := ps.peek().Start
	fexpr := ps.parseExpr()
	_ = fstart
	t := ps.peek()
	var fname string
	if t.K == TStr {
		fname = t.S
		ps.p++
	} else if t.K == TIdent && strings.HasPrefix(t.Text, "$") {
		fname = t.Text
		ps.p++
	} else {
		panic(ps.errHere("No data file name"))
	}
	e := &PlotElem{fname: fname, indexB: -1, indexStep: 1}
	var params []string
	for !ps.atEnd() {
		t := ps.peek()
		switch {
		case identIs(t, "using", 1):
			ps.p++
			e.hasUsing = true
			parseUsing(ps, e)
		case identIs(t, "index", 1):
			ps.p++
			e.hasIndex = true
			e.indexA = int(ps.evalNum())
			e.indexB = e.indexA
		case identIs(t, "every", 2):
			ps.p++
			for !ps.atEnd() && !ps.is("via") && !ps.is("using") {
				ps.p++
			}
		case identIs(t, "via", 3):
			ps.p++
			for {
				n := ps.next()
				if n.K != TIdent {
					panic(gpErrAt(n.Start, "no parameter specified"))
				}
				params = append(params, n.Text)
				if ps.isOp(",") {
					ps.p++
					continue
				}
				break
			}
		case identIs(t, "unitweights", 4), identIs(t, "errors", 3), identIs(t, "yerrors", 3), identIs(t, "xyerrors", 3), identIs(t, "zerror", 3):
			ps.p++
			for ps.peek().K == TIdent && !ps.is("via") {
				ps.p++
				if ps.isOp(",") {
					ps.p++
				}
			}
		default:
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+t.Text))
		}
	}
	if len(params) == 0 {
		panic(ps.errHere("Need via and either parameter list or file"))
	}
	lines, err := readDataLines(fname)
	if err != nil {
		if ge, ok := err.(*GPError); ok {
			panic(ge)
		}
		panic(gpErrNC("Cannot find or open file \"" + fname + "\""))
	}
	df := parseDataFile(lines)
	var X, Y, W []float64
	for ii, idx := range df.indexes {
		if e.hasIndex && ii != e.indexA {
			continue
		}
		for _, blk := range idx {
			for ri, row := range blk {
				r := row
				curRow = &r
				curRowNum = ri
				var vals []float64
				bad := false
				if e.hasUsing {
					for _, nd := range e.usingNodes {
						undefFlag = false
						v := safeEval(nd)
						if undefFlag || v.K == KUndef {
							bad = true
						}
						undefFlag = false
						vals = append(vals, realPart(v))
					}
					if len(vals) == 1 {
						vals = []float64{float64(ri), vals[0]}
					}
				} else {
					for k := 0; k < len(row.fields) && k < 2; k++ {
						f, st := parseField(row.fields[k])
						if st != 1 {
							bad = true
						}
						vals = append(vals, f)
					}
					if len(vals) == 1 {
						vals = []float64{float64(ri), vals[0]}
					}
				}
				if bad || len(vals) < 2 {
					continue
				}
				if !xa.autoMin && vals[0] < xa.min || !xa.autoMax && vals[0] > xa.max {
					continue
				}
				X = append(X, vals[0])
				Y = append(Y, vals[1])
				w := 1.0
				if len(vals) >= 3 {
					w = vals[2]
				}
				W = append(W, w)
			}
		}
	}
	curRow = nil
	N := len(X)
	P := len(params)
	if N == 0 {
		panic(gpErrNC("No data to fit"))
	}
	// initial values
	pv := make([]float64, P)
	for i, p := range params {
		v, ok := G.vars[p]
		if !ok {
			pv[i] = 1
			setVar(p, FltV(1))
		} else {
			pv[i] = realPart(v)
		}
	}
	scale := make([]float64, P)
	for i := range pv {
		scale[i] = 1
		if s.fitPrescale && pv[i] != 0 {
			scale[i] = math.Abs(pv[i])
		}
	}
	fr := Frame{}
	frames = append(frames, fr)
	evalF := func(p []float64, x float64) float64 {
		for i, n := range params {
			G.vars[n] = FltV(p[i])
		}
		fr[s.dummy1] = FltV(x)
		undefFlag = false
		v := safeEval(fexpr)
		undefFlag = false
		return realPart(v)
	}
	chisqOf := func(p []float64) float64 {
		c := 0.0
		for i := range X {
			r := (Y[i] - evalF(p, X[i])) / W[i]
			c += r * r
		}
		return c
	}
	jac := func(p []float64) ([][]float64, []float64) {
		J := make([][]float64, N)
		res := make([]float64, N)
		for i := range X {
			f0 := evalF(p, X[i])
			res[i] = (Y[i] - f0) / W[i]
			J[i] = make([]float64, P)
		}
		for j := 0; j < P; j++ {
			pp := append([]float64(nil), p...)
			h := fitH * math.Abs(hbase(p[j], scale[j]))
			if h == 0 {
				h = fitH
			}
			pp[j] = p[j] + h
			for i := range X {
				f1 := evalF(pp, X[i])
				if fitCentral {
					pp[j] = p[j] - h
					f2 := evalF(pp, X[i])
					pp[j] = p[j] + h
					J[i][j] = (f1 - f2) / (2 * h) / W[i] * scale[j]
				} else {
					f2 := evalF(p, X[i])
					J[i][j] = (f1 - f2) / h / W[i] * scale[j]
				}
			}
		}
		return J, res
	}
	var b strings.Builder
	quiet := s.fitQuiet
	header := "iter      chisq       delta/lim  lambda  "
	for _, p := range params {
		header += fmt.Sprintf(" %-13s", p)
	}
	header += "\n"
	printIter := func(it int, chisq, delta, lambda float64, p []float64) {
		if quiet {
			return
		}
		fmt.Fprintf(&b, "%4d %.10e %10.2e %9.2e ", it, chisq, delta, lambda)
		for _, v := range p {
			fmt.Fprintf(&b, "%15.6e", v)
		}
		b.WriteString("\n")
	}
	p := append([]float64(nil), pv...)
	chisq := chisqOf(p)
	J, res := jac(p)
	fro := 0.0
	for i := range J {
		for j := range J[i] {
			fro += J[i][j] * J[i][j]
		}
	}
	lambda := math.Sqrt(fro) / math.Sqrt(float64(N*P))
	if !quiet {
		b.WriteString(header)
	}
	printIter(0, chisq, 0, lambda, p)
	iter := 0
	lastDelta := 0.0
	converged := false
	maxiter := s.fitMaxIter
	for {
		// solve (JtJ + lambda^2 I) d = Jt r  (scaled)
		A := make([][]float64, P)
		g := make([]float64, P)
		for j := 0; j < P; j++ {
			A[j] = make([]float64, P)
			for k := 0; k < P; k++ {
				for i := 0; i < N; i++ {
					A[j][k] += J[i][j] * J[i][k]
				}
			}
			A[j][j] += lambda * lambda
			for i := 0; i < N; i++ {
				g[j] += J[i][j] * res[i]
			}
		}
		d, ok := qrSolveAug(J, res, lambda)
		if !ok {
			break
		}
		np := make([]float64, P)
		for j := range p {
			np[j] = p[j] + d[j]*scale[j]
		}
		nchisq := chisqOf(np)
		if nchisq < chisq || nchisq == chisq {
			delta := (nchisq - chisq) / nchisq
			if nchisq == 0 {
				delta = 0
			}
			lastDelta = delta
			lambda /= 10
			iter++
			p = np
			old := chisq
			chisq = nchisq
			printIter(iter, chisq, delta/s.fitLimit, lambda, p)
			J, res = jac(p)
			if (old-nchisq)/math.Max(nchisq, 1e-300) <= s.fitLimit || nchisq == 0 {
				converged = true
				break
			}
		} else {
			lambda *= 10
			if !quiet {
				fmt.Fprintf(&b, "   * %.10e %10.2e %9.2e ", nchisq, (nchisq-chisq)/nchisq/s.fitLimit, lambda)
				for _, v := range np {
					fmt.Fprintf(&b, "%15.6e", v)
				}
				b.WriteString("\n")
			}
			if lambda > 1e20 {
				break
			}
		}
		if maxiter > 0 && iter >= maxiter {
			break
		}
	}
	frames = frames[:len(frames)-1]
	for i, n := range params {
		setVar(n, FltV(p[i]))
	}
	if !quiet {
		b.WriteString(header)
	}
	ndf := N - P
	if converged {
		fmt.Fprintf(&b, "\nAfter %d iterations the fit converged.\n", iter)
	} else {
		fmt.Fprintf(&b, "\nAfter %d iterations the fit stopped.\n", iter)
	}
	fmt.Fprintf(&b, "final sum of squares of residuals : %s\n", fmtG(chisq, 6))
	if chisq != 0 {
		fmt.Fprintf(&b, "rel. change during last iteration : %s\n\n", fmtG(lastDelta, 6))
	} else {
		b.WriteString("\n")
	}
	stdfit := 0.0
	if ndf > 0 {
		stdfit = math.Sqrt(chisq / float64(ndf))
	}
	fmt.Fprintf(&b, "degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	fmt.Fprintf(&b, "rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", fmtG(stdfit, 6))
	fmt.Fprintf(&b, "variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n\n", fmtG(stdfit*stdfit, 6))
	// covariance
	JtJ := make([][]float64, P)
	for j := 0; j < P; j++ {
		JtJ[j] = make([]float64, P)
		for k := 0; k < P; k++ {
			for i := 0; i < N; i++ {
				JtJ[j][k] += J[i][j] * J[i][k]
			}
		}
	}
	cov := invert(JtJ)
	errs := make([]float64, P)
	for j := 0; j < P; j++ {
		if cov != nil {
			v := cov[j][j] * scale[j] * scale[j]
			if s.fitScaleErr {
				v *= stdfit * stdfit
			}
			errs[j] = math.Sqrt(math.Abs(v))
		}
	}
	b.WriteString("Final set of parameters            Asymptotic Standard Error\n")
	b.WriteString("=======================            ==========================\n")
	for j, n := range params {
		pct := 0.0
		if p[j] != 0 {
			pct = math.Abs(errs[j]/p[j]) * 100
		}
		fmt.Fprintf(&b, "%-15s = %-15s  +/- %-12s (%s%%)\n", n, fmtG(p[j], 6), fmtG(errs[j], 4), fmtG(pct, 4))
	}
	if P > 1 && cov != nil {
		b.WriteString("\ncorrelation matrix of the fit parameters:\n")
		b.WriteString("                ")
		for _, n := range params {
			fmt.Fprintf(&b, "%-7s", n)
		}
		b.WriteString("\n")
		for j, n := range params {
			fmt.Fprintf(&b, "%-15s", n)
			for k := 0; k <= j; k++ {
				c := cov[j][k] / math.Sqrt(cov[j][j]*cov[k][k])
				fmt.Fprintf(&b, "%6.3f ", c)
			}
			b.WriteString("\n")
		}
	}
	if !quiet {
		writeErr(b.String())
	}
	if s.fitErrVars {
		for j, n := range params {
			setVar(n+"_err", FltV(errs[j]))
		}
	}
	setVar("FIT_NDF", IntV(int64(ndf)))
	setVar("FIT_STDFIT", FltV(stdfit))
	setVar("FIT_WSSR", FltV(chisq))
	setVar("FIT_NITER", IntV(int64(iter)))
	setVar("FIT_CONVERGED", BoolV(converged))
}

func solveLin(A [][]float64, b []float64) ([]float64, bool) {
	n := len(b)
	M := make([][]float64, n)
	for i := range A {
		M[i] = append(append([]float64(nil), A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		if M[piv][c] == 0 {
			return nil, false
		}
		M[c], M[piv] = M[piv], M[c]
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := 0; i < n; i++ {
		x[i] = M[i][n] / M[i][i]
	}
	return x, true
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for i := 0; i < n; i++ {
		e := make([]float64, n)
		e[i] = 1
		col, ok := solveLin(A, e)
		if !ok {
			return nil
		}
		inv[i] = col
	}
	// transpose (columns)
	out := make([][]float64, n)
	for i := 0; i < n; i++ {
		out[i] = make([]float64, n)
		for j := 0; j < n; j++ {
			out[i][j] = inv[j][i]
		}
	}
	return out
}

func qrSolveAug(J [][]float64, r []float64, lambda float64) ([]float64, bool) {
	N := len(J)
	P := len(J[0])
	M := N + P
	A := make([][]float64, M)
	b := make([]float64, M)
	for i := 0; i < N; i++ {
		A[i] = append([]float64(nil), J[i]...)
		b[i] = r[i]
	}
	for j := 0; j < P; j++ {
		A[N+j] = make([]float64, P)
		A[N+j][j] = lambda
	}
	// Givens rotations
	for j := 0; j < P; j++ {
		for i := j + 1; i < M; i++ {
			if A[i][j] == 0 {
				continue
			}
			a, c := A[j][j], A[i][j]
			rr := math.Hypot(a, c)
			cs, sn := a/rr, c/rr
			for k := j; k < P; k++ {
				t1, t2 := A[j][k], A[i][k]
				A[j][k] = cs*t1 + sn*t2
				A[i][k] = -sn*t1 + cs*t2
			}
			t1, t2 := b[j], b[i]
			b[j] = cs*t1 + sn*t2
			b[i] = -sn*t1 + cs*t2
		}
	}
	x := make([]float64, P)
	for j := P - 1; j >= 0; j-- {
		s := b[j]
		for k := j + 1; k < P; k++ {
			s -= A[j][k] * x[k]
		}
		if A[j][j] == 0 {
			return nil, false
		}
		x[j] = s / A[j][j]
	}
	return x, true
}

var fitH = 1e-4
var fitCentral = true

func init() {
	if v := os.Getenv("FITH"); v != "" {
		fitH, _ = strconv.ParseFloat(v, 64)
	}
	if os.Getenv("FITFWD") != "" {
		fitCentral = false
	}
}

func hbase(p, s float64) float64 {
	if os.Getenv("FITHS") != "" {
		return s
	}
	return p
}
