package main

import (
	"fmt"
	"strings"
)

func setTerminal(ps *Parser) {
	s := G.S
	if ps.atEnd() {
		return
	}
	t := ps.next()
	name := t.Text
	switch {
	case identIs(t, "dumb", 2):
		s.term = "dumb"
		for !ps.atEnd() {
			if ps.is("size") {
				ps.p++
				s.termW = int(ps.evalNum())
				if ps.isOp(",") {
					ps.p++
					s.termH = int(ps.evalNum())
				}
				continue
			}
			if ps.is("feed") {
				s.termFeed = true
			} else if ps.is("nofeed") {
				s.termFeed = false
			}
			if ps.peek().K == TNum {
				s.termW = int(ps.evalNum())
				if ps.isOp(",") {
					ps.p++
				}
				if ps.peek().K == TNum {
					s.termH = int(ps.evalNum())
				}
				continue
			}
			ps.p++
		}
	case identIs(t, "svg", 2):
		s.term = "svg"
		s.svgW, s.svgH = 600, 480
		parseSizeOpt(ps)
	case identIs(t, "canvas", 2):
		s.term = "canvas"
		s.svgW, s.svgH = 600, 400
		parseSizeOpt(ps)
	case identIs(t, "unknown", 1):
		s.term = "unknown"
		skipToEnd(ps)
	case name == "push" || name == "pop":
		skipToEnd(ps)
	default:
		s.term = name
		skipToEnd(ps)
	}
}

func parseSizeOpt(ps *Parser) {
	s := G.S
	for !ps.atEnd() {
		if ps.is("size") {
			ps.p++
			s.svgW = int(ps.evalNum())
			if ps.isOp(",") {
				ps.p++
				s.svgH = int(ps.evalNum())
			}
			continue
		}
		if ps.is("font") || ps.is("fsize") || ps.is("name") || ps.is("linewidth") || ps.is("lw") || ps.is("background") || ps.is("fontscale") || ps.is("dashlength") {
			ps.p++
			ps.evalAny()
			continue
		}
		ps.p++
	}
}

func termShow() string {
	s := G.S
	switch s.term {
	case "dumb":
		feed := "feed"
		if !s.termFeed {
			feed = "nofeed"
		}
		return fmt.Sprintf("\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", feed, s.termW, s.termH)
	case "unknown":
		return "\n   terminal type is unknown \n\n"
	}
	return fmt.Sprintf("\n   terminal type is %s \n\n", s.term)
}

func startMultiplot(ps *Parser) {
	mp.active = true
	mp.layout = false
	mp.idx = 0
	mp.title = ""
	for !ps.atEnd() {
		if ps.is("layout") {
			ps.p++
			mp.rows = int(ps.evalNum())
			ps.expect(",")
			mp.cols = int(ps.evalNum())
			mp.layout = true
			continue
		}
		if ps.is("title") {
			ps.p++
			mp.title = ps.evalStr()
			continue
		}
		ps.p++
	}
	if G.S.term == "dumb" {
		mp.cv = newCanvas(G.S.termW, G.S.termH)
		if mp.title != "" {
			mp.cv.textJ(G.S.termW/2, G.S.termH-1, mp.title, 1)
		}
	}
}

func endMultiplot() {
	if !mp.active {
		return
	}
	mp.active = false
	G.S.multiplot = false
	if G.S.term == "dumb" && mp.cv != nil {
		emitCanvas(mp.cv)
	}
	mp.cv = nil
}

func termClear() {}

func finishOutput() {
	if mp.active {
		endMultiplot()
	}
	if svgPending != "" {
		outWriter().WriteString(svgPending)
		svgPending = ""
	}
	outWriter().Flush()
}

var svgPending string

func render3D(curves []*Curve)                          {}
func renderSVG(curves []*Curve, xs, ys *AxisState)    {}
func renderCanvas(curves []*Curve, xs, ys *AxisState) {}

var _ = strings.Repeat
