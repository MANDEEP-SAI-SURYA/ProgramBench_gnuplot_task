package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

type loopCtl struct{ brk bool }
type abortErr struct{}

type Interp struct {
	vars       map[string]Value
	funcs      map[string]*UserFunc
	datablocks map[string][]string
	degrees    bool
	srcStack   []*Source
	curLine    int
	curText    string
	stdinErr   bool

	printFile   *bufio.Writer
	printOsFile *os.File
	printName   string
	printDB     string
	printBuf    []string // pending for stderr
	blockBase   int
	blockDepth  int
	loopDepth   int
	S           *Settings
	order       []string
	funcOrder   []string
}

var G *Interp

func setVar(name string, v Value) {
	if _, ok := G.vars[name]; !ok {
		G.order = append(G.order, name)
	}
	G.vars[name] = v
}

func (g *Interp) varOrder() []string {
	var out []string
	for _, k := range g.order {
		if _, ok := g.vars[k]; ok {
			out = append(out, k)
		}
	}
	return out
}

func initGlobals() {
	G = &Interp{vars: map[string]Value{}, funcs: map[string]*UserFunc{}, datablocks: map[string][]string{}}
	setVar("pi", FltV(3.14159265358979323846))
	setVar("I", CV(0, 1))
	setVar("NaN", FltV(nanVal()))
	setVar("VoxelDistance", FltV(0))
	setVar("GPVAL_VERSION", FltV(5.4))
	setVar("GPVAL_PATCHLEVEL", StrV("9"))
	G.S = newSettings()
}

func (g *Interp) flushPrint() {}

func (g *Interp) setCallArgs(fn string, args []string) {
	setVar("ARGC", IntV(int64(len(args))))
	setVar("ARG0", StrV(fn))
	setVar("ARGV", Value{K: KArr, A: &[]Value{}})
	arr := make([]Value, len(args))
	for i := 1; i <= 9; i++ {
		if i <= len(args) {
			setVar("ARG"+strconv.Itoa(i), StrV(args[i-1]))
			arr[i-1] = StrV(args[i-1])
		} else {
			setVar("ARG"+strconv.Itoa(i), StrV(""))
		}
	}
	setVar("ARGV", Value{K: KArr, A: &arr})
}

func curSrc() *Source {
	if len(G.srcStack) == 0 {
		return &Source{}
	}
	return G.srcStack[len(G.srcStack)-1]
}

// macro expansion
func expandMacros(line string) string {
	if !strings.Contains(line, "@") {
		return line
	}
	var b strings.Builder
	inS := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if inS != 0 {
			b.WriteByte(c)
			if c == '\\' && inS == '"' && i+1 < len(line) {
				i++
				b.WriteByte(line[i])
				continue
			}
			if c == inS {
				inS = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			inS = c
			b.WriteByte(c)
			continue
		}
		if c == '@' && i+1 < len(line) && isAlpha(line[i+1]) {
			j := i + 1
			for j < len(line) && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			name := line[i+1 : j]
			v, ok := G.vars[name]
			if ok && v.K == KStr {
				b.WriteString(v.S)
				i = j - 1
				continue
			}
			warn(name + " is not a string variable")
			i = j - 1
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

func execLine(line string) {
	line = expandMacros(line)
	toks := lex(line)
	G.curText = line
	execTokens(toks, line, false)
}

func execTokens(toks []Token, line string, inBlock bool) {
	ps := &Parser{toks: toks, line: line}
	defer func() {
		if inBlock {
			if r := recover(); r != nil {
				if e, ok := r.(*GPError); ok {
					e.inBlock = true
				}
				panic(r)
			}
		}
	}()
	base := G.curLine
	if inBlock {
		base = G.blockBase
	}
	for {
		for ps.isOp(";") {
			ps.p++
		}
		if ps.peek().K == TEnd {
			return
		}
		if inBlock {
			G.curLine = base + strings.Count(line[:ps.peek().Start], "\n")
		}
		execCommand(ps)
		if !ps.atEnd() {
			t := ps.peek()
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+t.Text))
		}
	}
}

// find matching close brace starting at index of '{'
func matchBrace(ps *Parser) (int, int) {
	if !ps.isOp("{") {
		panic(ps.errHere("expecting '{'"))
	}
	open := ps.p
	d := 0
	for i := ps.p; i < len(ps.toks); i++ {
		t := ps.toks[i]
		if t.K == TOp && t.Text == "{" {
			d++
		} else if t.K == TOp && t.Text == "}" {
			d--
			if d == 0 {
				return open, i
			}
		} else if t.K == TEnd {
			break
		}
	}
	panic(gpErrNC("Unmatched braces"))
}

func runBlock(ps *Parser, open, close int) {
	sub := make([]Token, 0, close-open)
	sub = append(sub, ps.toks[open+1:close]...)
	sub = append(sub, Token{K: TEnd, Start: ps.toks[close].Start})
	saved := G.blockBase
	if !G.inBlockDepth() {
		G.blockBase = G.curLine
	}
	G.blockDepth++
	defer func() { G.blockDepth--; G.blockBase = saved }()
	execTokens(sub, ps.line, true)
}

func (g *Interp) inBlockDepth() bool { return g.blockDepth > 0 }

func identIs(t Token, full string, minLen int) bool {
	if t.K != TIdent {
		return false
	}
	s := t.Text
	if len(s) < minLen || len(s) > len(full) {
		return false
	}
	return strings.HasPrefix(full, s)
}

func isFuncDef(ps *Parser) bool {
	i := ps.p
	t := ps.toks
	if t[i].K != TIdent || t[i+1].K != TOp || t[i+1].Text != "(" {
		return false
	}
	i += 2
	for {
		if t[i].K != TIdent {
			return false
		}
		i++
		if t[i].K == TOp && t[i].Text == "," {
			i++
			continue
		}
		break
	}
	if t[i].K == TOp && t[i].Text == ")" && t[i+1].K == TOp && t[i+1].Text == "=" {
		return true
	}
	return false
}

func exprText(ps *Parser, from, to int) string {
	if to <= from {
		return ""
	}
	return ps.line[ps.toks[from].Start:ps.toks[to-1].End]
}

func execCommand(ps *Parser) {
	t := ps.peek()
	if t.K == TOp && t.Text == "{" {
		o, c := matchBrace(ps)
		ps.p = c + 1
		runBlock(ps, o, c)
		return
	}
	if t.K == TOp && t.Text == "!" {
		// shell command: ignore rest
		for !ps.atEnd() {
			ps.p++
		}
		return
	}
	if t.K != TIdent {
		panic(gpErrAt(t.Start, "invalid command"))
	}
	n1 := ps.peekN(1)
	// datablock assignment / variables
	if n1.K == TOp && n1.Text == "=" {
		name := t.Text
		ps.p += 2
		st := ps.peek().Start
		if ps.atEnd() {
			panic(ps.errHere("constant expression required"))
		}
		e := ps.parseExpr()
		v := evalTop(e, st)
		if strings.HasPrefix(name, "$") {
			panic(gpErrAt(t.Start, "invalid command"))
		}
		if name == "pi" || name == "NaN" {
		}
		setVar(name, v)
		return
	}
	if isFuncDef(ps) {
		name := t.Text
		ps.p += 2
		var params []string
		for {
			params = append(params, ps.next().Text)
			if ps.isOp(",") {
				ps.p++
				continue
			}
			break
		}
		ps.p += 2 // ) =
		from := ps.p
		body := ps.parseExpr()
		if _, ok := G.funcs[name]; !ok {
			G.funcOrder = append(G.funcOrder, name)
		}
		G.funcs[name] = &UserFunc{Params: params, Body: body, Text: name + "(" + strings.Join(params, ",") + ")=" + exprText(ps, from, ps.p)}
		return
	}
	if n1.K == TOp && n1.Text == "[" {
		// array element assignment?
		save := ps.p
		ps.p += 2
		idxStart := ps.peek().Start
		idx := ps.parseExpr()
		if ps.isOp("]") && ps.peekN(1).K == TOp && ps.peekN(1).Text == "=" {
			ps.p += 2
			st := ps.peek().Start
			e := ps.parseExpr()
			arr, ok := G.vars[t.Text]
			if !ok || arr.K != KArr {
				panic(gpErrAt(t.Start, "not an array"))
			}
			iv := evalTop(idx, idxStart)
			i := toIntVal(iv)
			if i < 1 || i > int64(len(*arr.A)) {
				panic(gpErrAt(idxStart, "array index out of range"))
			}
			v := evalTop(e, st)
			(*arr.A)[i-1] = v
			return
		}
		ps.p = save
	}
	cmd := t.Text
	switch {
	case cmd == "print" || identIs(t, "print", 2):
		ps.p++
		cmdPrint(ps, false)
	case cmd == "printerr" || identIs(t, "printerr", 6):
		ps.p++
		cmdPrint(ps, true)
	case cmd == "if":
		ps.p++
		cmdIf(ps)
	case cmd == "else":
		// stray else after an executed if: skip rest
		ps.p++
		if ps.isOp("{") {
			_, c := matchBrace(ps)
			ps.p = c + 1
		} else if ps.is("if") {
			// else if after executed: skip all
			for ps.peek().K != TEnd {
				ps.p++
			}
		} else {
			for ps.peek().K != TEnd {
				ps.p++
			}
		}
	case cmd == "do":
		ps.p++
		cmdDo(ps)
	case cmd == "while":
		ps.p++
		cmdWhile(ps)
	case cmd == "break" || cmd == "continue":
		ps.p++
		if G.loopDepth > 0 {
			panic(loopCtl{brk: cmd == "break"})
		}
	case identIs(t, "load", 1):
		ps.p++
		st := ps.peek().Start
		e := ps.parseExpr()
		v := evalTop(e, st)
		if v.K != KStr {
			panic(gpErrAt(st, "expecting filename"))
		}
		loadFile(v.S, nil, false)
	case identIs(t, "call", 3):
		ps.p++
		st := ps.peek().Start
		e := ps.parsePrimary()
		v := evalTop(e, st)
		var args []string
		var argv []Value
		for !ps.atEnd() {
			at := ps.peek()
			if at.K == TStr {
				args = append(args, at.S)
				argv = append(argv, StrV(at.S))
				ps.p++
			} else {
				ex := ps.parsePrimary()
				av := evalTop(ex, at.Start)
				if av.K == KStr {
					args = append(args, av.S)
				} else {
					args = append(args, av.String())
				}
				if av.K == KInt {
					av = FltV(float64(av.I))
				}
				argv = append(argv, av)
			}
		}
		loadFile(v.S, args, true)
		_ = argv
	case cmd == "eval" || identIs(t, "eval", 4):
		ps.p++
		st := ps.peek().Start
		e := ps.parseExpr()
		v := evalTop(e, st)
		if v.K != KStr {
			panic(gpErrAt(st, "expected string"))
		}
		execNested(v.S)
	case identIs(t, "exit", 2) || identIs(t, "quit", 1):
		ps.p++
		code := 0
		if ps.is("status") {
			ps.p++
			st := ps.peek().Start
			code = int(toIntVal(evalTop(ps.parseExpr(), st)))
		} else if ps.is("error") {
			ps.p++
			st := ps.peek().Start
			msg := evalTop(ps.parseExpr(), st)
			panic(gpErrNC(msg.S))
		}
		finishOutput()
		panic(exitReq{code})
	case identIs(t, "undefine", 3):
		ps.p++
		for !ps.atEnd() {
			n := ps.next()
			name := n.Text
			if strings.HasSuffix(name, "*") {
			}
			if ps.isOp("*") {
				ps.p++
				for k := range G.vars {
					if strings.HasPrefix(k, name) {
						delete(G.vars, k)
					}
				}
				continue
			}
			delete(G.vars, name)
			delete(G.datablocks, name)
		}
	case cmd == "array":
		ps.p++
		cmdArray(ps)
	case identIs(t, "pause", 2):
		ps.p++
		for !ps.atEnd() {
			ps.p++
		}
	case identIs(t, "clear", 2):
		ps.p++
		termClear()
	case identIs(t, "reset", 3):
		ps.p++
		if ps.is("session") {
			ps.p++
			initGlobals()
		} else if ps.is("errors") {
			ps.p++
		} else {
			resetSettings()
		}
	case identIs(t, "set", 2):
		ps.p++
		cmdSet(ps)
	case identIs(t, "unset", 3):
		ps.p++
		cmdUnset(ps)
	case identIs(t, "show", 2):
		ps.p++
		cmdShow(ps)
	case identIs(t, "plot", 1):
		ps.p++
		cmdPlot(ps, false)
	case identIs(t, "splot", 2):
		ps.p++
		cmdPlot(ps, true)
	case identIs(t, "replot", 3):
		ps.p++
		cmdReplot(ps)
	case identIs(t, "stats", 4):
		ps.p++
		cmdStats(ps)
	case identIs(t, "fit", 1):
		ps.p++
		cmdFit(ps)
	case identIs(t, "test", 4), identIs(t, "history", 4), identIs(t, "bind", 2), identIs(t, "cd", 2), identIs(t, "pwd", 2), identIs(t, "lower", 3), identIs(t, "raise", 2), identIs(t, "refresh", 3), identIs(t, "system", 2), identIs(t, "update", 2), identIs(t, "help", 1), identIs(t, "toggle", 3), identIs(t, "shell", 2):
		ps.p++
		for !ps.atEnd() {
			ps.p++
		}
	default:
		panic(gpErrAt(t.Start, "invalid command"))
	}
}

func execNested(s string) {
	toks := lex(expandMacros(s))
	savedText := G.curText
	defer func() { G.curText = savedText }()
	execTokens(toks, s, G.blockDepth > 0)
}

func loadFile(fn string, args []string, isCall bool) {
	data, err := os.ReadFile(fn)
	if err != nil {
		panic(gpErrNC("Cannot load input from '" + fn + "'"))
	}
	var saved map[string]Value
	if isCall {
		saved = map[string]Value{}
		for _, k := range []string{"ARG0", "ARGC", "ARGV", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"} {
			if v, ok := G.vars[k]; ok {
				saved[k] = v
			}
		}
		G.setCallArgs(fn, args)
	}
	savedLine := G.curLine
	savedBD, savedBB := G.blockDepth, G.blockBase
	G.blockDepth = 0
	src := &Source{Name: fn, Kind: SrcFile}
	ok := runText(string(data), src)
	G.curLine = savedLine
	G.blockDepth, G.blockBase = savedBD, savedBB
	if isCall {
		for k, v := range saved {
			setVar(k, v)
		}
	}
	if !ok {
		panic(abortErr{})
	}
}

func cmdArray(ps *Parser) {
	for {
		n := ps.next()
		if n.K != TIdent {
			panic(gpErrAt(n.Start, "illegal variable name"))
		}
		if ps.isOp("[") {
			ps.p++
			st := ps.peek().Start
			sz := toIntVal(evalTop(ps.parseExpr(), st))
			ps.expect("]")
			arr := make([]Value, sz)
			if ps.isOp("=") {
				ps.p++
				st := ps.peek().Start
				v := evalTop(ps.parseExpr(), st)
				if v.K == KArr {
					copy(arr, *v.A)
				} else {
					for i := range arr {
						arr[i] = v
					}
				}
			}
			setVar(n.Text, Value{K: KArr, A: &arr})
		} else if ps.isOp("=") {
			ps.p++
			st := ps.peek().Start
			v := evalTop(ps.parseExpr(), st)
			if v.K != KArr {
				panic(gpErrAt(st, "expecting array"))
			}
			arr := make([]Value, len(*v.A))
			copy(arr, *v.A)
			setVar(n.Text, Value{K: KArr, A: &arr})
		} else {
			panic(ps.errHere("expecting array size"))
		}
		if ps.isOp(",") {
			ps.p++
			continue
		}
		break
	}
}

func cmdIf(ps *Parser) {
	ps.expect("(")
	st := ps.peek().Start
	c := ps.parseExpr()
	ps.expect(")")
	cond := truthy(evalTop(c, st))
	if ps.isOp("{") {
		o, cl := matchBrace(ps)
		ps.p = cl + 1
		taken := cond
		if cond {
			runBlock(ps, o, cl)
		}
		for ps.is("else") {
			ps.p++
			if ps.is("if") {
				panic(ps.errHere("expected {else-clause}"))
			}
			if false {
				ps.p++
				ps.expect("(")
				st := ps.peek().Start
				c2 := ps.parseExpr()
				ps.expect(")")
				o, cl := matchBrace(ps)
				ps.p = cl + 1
				if !taken && truthy(evalTop(c2, st)) {
					taken = true
					runBlock(ps, o, cl)
				}
				continue
			}
			o, cl := matchBrace(ps)
			ps.p = cl + 1
			if !taken {
				taken = true
				runBlock(ps, o, cl)
			}
			break
		}
		return
	}
	// old style: rest of line
	if cond {
		runRest(ps, true)
		return
	}
	// skip to "else" at top level or end
	for ps.peek().K != TEnd {
		if ps.is("else") && ps.p > 0 && ps.toks[ps.p-1].K == TOp && ps.toks[ps.p-1].Text == ";" {
			ps.p++
			runRest(ps, false)
			return
		}
		ps.p++
	}
}

func cmdDo(ps *Parser) {
	if !ps.is("for") {
		panic(ps.errHere("expecting for"))
	}
	ps.p++
	iter := parseIterSpec(ps)
	o, c := matchBrace(ps)
	ps.p = c + 1
	G.loopDepth++
	defer func() { G.loopDepth-- }()
	iter.run(func() bool {
		return runLoopBody(ps, o, c)
	})
}

func runLoopBody(ps *Parser, o, c int) (cont bool) {
	defer func() {
		if r := recover(); r != nil {
			if lc, ok := r.(loopCtl); ok {
				cont = !lc.brk
				return
			}
			panic(r)
		}
	}()
	runBlock(ps, o, c)
	return true
}

type IterSpec struct {
	Var        string
	isList     bool
	listExpr   Node
	start, end Node
	step       Node
	pos        int
	endStar    bool
}

func parseIterSpec(ps *Parser) *IterSpec {
	ps.expect("[")
	it := &IterSpec{}
	vt := ps.next()
	it.Var = vt.Text
	it.pos = ps.peek().Start
	if ps.is("in") {
		ps.p++
		it.isList = true
		it.listExpr = ps.parseExpr()
		ps.expect("]")
		return it
	}
	ps.expect("=")
	it.start = ps.parseExpr()
	ps.expect(":")
	if ps.isOp("*") {
		ps.p++
		it.endStar = true
	} else {
		it.end = ps.parseExpr()
	}
	if ps.isOp(":") {
		ps.p++
		it.step = ps.parseExpr()
	}
	ps.expect("]")
	return it
}

func (it *IterSpec) run(body func() bool) {
	if it.isList {
		v := evalTop(it.listExpr, it.pos)
		if v.K == KArr {
			for _, e := range *v.A {
				setVar(it.Var, e)
				if !body() {
					return
				}
			}
			return
		}
		if v.K != KStr {
			panic(gpErrNC("expecting string"))
		}
		for _, w := range splitWords(v.S) {
			setVar(it.Var, StrV(w))
			if !body() {
				return
			}
		}
		return
	}
	a := toIntVal(evalTop(it.start, it.pos))
	var b int64 = 1 << 62
	if !it.endStar {
		b = toIntVal(evalTop(it.end, it.pos))
	}
	var s int64 = 1
	if it.step != nil {
		s = toIntVal(evalTop(it.step, it.pos))
	}
	if s == 0 {
		panic(gpErrNC("increment cannot be zero"))
	}
	for i := a; (s > 0 && i <= b) || (s < 0 && i >= b); i += s {
		setVar(it.Var, IntV(i))
		if !body() {
			return
		}
	}
}

func cmdWhile(ps *Parser) {
	ps.expect("(")
	st := ps.peek().Start
	c := ps.parseExpr()
	ps.expect(")")
	o, cl := matchBrace(ps)
	ps.p = cl + 1
	G.loopDepth++
	defer func() { G.loopDepth-- }()
	for truthy(evalTop(c, st)) {
		if !runLoopBody(ps, o, cl) {
			break
		}
	}
}

// print
func printTarget(s string) {
	if G.printDB != "" {
		lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
		G.datablocks[G.printDB] = append(G.datablocks[G.printDB], lines...)
		return
	}
	if G.printFile != nil {
		G.printFile.WriteString(s)
		return
	}
	if G.printName == "-" {
		stdout.WriteString(s)
		return
	}
	stdout.Flush()
	os.Stderr.WriteString(s)
}

func cmdPrint(ps *Parser, toStderr bool) {
	var sb strings.Builder
	out := func(s string) {
		if toStderr {
			stdout.Flush()
			os.Stderr.WriteString(s)
		} else if G.printDB != "" {
			sb.WriteString(s)
		} else {
			printTarget(s)
		}
	}
	first := true
	if ps.atEnd() {
		panic(ps.errHere("constant expression required"))
	}
	for {
		if !first {
			out(" ")
		}
		first = false
		st := ps.peek().Start
		// datablock print
		if ps.peek().K == TIdent && strings.HasPrefix(ps.peek().Text, "$") && (ps.peekN(1).K == TEnd || (ps.peekN(1).K == TOp && (ps.peekN(1).Text == ";" || ps.peekN(1).Text == ","))) {
			name := ps.next().Text
			db, ok := G.datablocks[name]
			if !ok {
				panic(gpErrNC("no datablock named " + name))
			}
			for _, l := range db {
				out(l + "\n")
			}
		} else {
			e := ps.parseExpr()
			v := evalTop(e, st)
			if v.K == KArr {
				out(v.String() + "\n")
			} else {
				out(v.String())
			}
		}
		if ps.isOp(",") {
			ps.p++
			continue
		}
		break
	}
	out("\n")
	if G.printDB != "" && !toStderr {
		printTarget(sb.String())
	}
}

func warn(msg string) {
	src := curSrc()
	pre := "line 0: "
	if src.Kind == SrcFile {
		pre = "\"" + src.Name + "\" line " + strconv.Itoa(G.curLine) + ": "
	}
	if src.Kind == SrcStdin {
		pre = "         " + pre
	}
	writeErr(pre + "warning: " + msg + "\n")
}

func runRest(ps *Parser, stopAtElse bool) {
	for {
		for ps.isOp(";") {
			ps.p++
		}
		if ps.peek().K == TEnd {
			return
		}
		if stopAtElse && ps.is("else") {
			for ps.peek().K != TEnd {
				ps.p++
			}
			return
		}
		execCommand(ps)
		if !ps.atEnd() {
			t := ps.peek()
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+t.Text))
		}
	}
}
