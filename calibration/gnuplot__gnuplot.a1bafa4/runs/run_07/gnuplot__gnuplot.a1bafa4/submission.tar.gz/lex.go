package main

import (
	"strconv"
	"strings"
)

type TokKind int

const (
	TEnd TokKind = iota
	TNum
	TStr
	TIdent
	TOp
)

type Token struct {
	K     TokKind
	Text  string // raw text (for strings: raw incl quotes)
	S     string // decoded string
	V     Value  // number
	Start int
	End   int
}

func isAlpha(c byte) bool {
	return c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }

var twoOps = []string{"**", "==", "!=", "<=", ">=", "&&", "||", "<<", ">>", "+=", "-=", "*=", "/="}

func decodeDQ(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c != '\\' || i+1 >= len(s) {
			b.WriteByte(c)
			continue
		}
		i++
		c = s[i]
		switch c {
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case 'r':
			b.WriteByte('\r')
		case 'a':
			b.WriteByte(7)
		case 'b':
			b.WriteByte(8)
		case 'f':
			b.WriteByte(12)
		case 'v':
			b.WriteByte(11)
		case '\\':
			b.WriteByte('\\')
		case '"':
			b.WriteByte('"')
		case '\'':
			b.WriteString("\\'")
		case '0', '1', '2', '3', '4', '5', '6', '7':
			n := 0
			k := 0
			for k < 3 && i < len(s) && s[i] >= '0' && s[i] <= '7' {
				n = n*8 + int(s[i]-'0')
				i++
				k++
			}
			i--
			b.WriteByte(byte(n))
		default:
			b.WriteByte('\\')
			b.WriteByte(c)
		}
	}
	return b.String()
}

func lex(line string) []Token {
	var toks []Token
	i := 0
	n := len(line)
	for {
		for i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
			i++
		}
		if i >= n {
			break
		}
		c := line[i]
		st := i
		if c == '\n' {
			toks = append(toks, Token{K: TOp, Text: ";", Start: st, End: i + 1})
			i++
			continue
		}
		if c == '#' {
			// comment to end of line (rest of logical line)
			j := strings.IndexByte(line[i:], '\n')
			if j < 0 {
				break
			}
			i += j
			continue
		}
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])) {
			// number
			if c == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
				toks = append(toks, Token{K: TNum, Text: line[i:j], V: IntV(int64(v)), Start: st, End: j})
				i = j
				continue
			}
			j := i
			for j < n && isDigit(line[j]) {
				j++
			}
			isf := false
			if j < n && line[j] == '.' {
				isf = true
				j++
				for j < n && isDigit(line[j]) {
					j++
				}
			}
			if j < n && (line[j] == 'e' || line[j] == 'E') {
				k := j + 1
				if k < n && (line[k] == '+' || line[k] == '-') {
					k++
				}
				if k < n && isDigit(line[k]) {
					for k < n && isDigit(line[k]) {
						k++
					}
					j = k
					isf = true
				}
			}
			txt := line[i:j]
			var v Value
			if isf {
				f, _ := strconv.ParseFloat(txt, 64)
				v = FltV(f)
			} else if len(txt) > 1 && txt[0] == '0' {
				u, err := strconv.ParseInt(txt, 8, 64)
				if err != nil {
					f, _ := strconv.ParseFloat(txt, 64)
					v = FltV(f)
				} else {
					v = IntV(u)
				}
			} else {
				u, err := strconv.ParseInt(txt, 10, 64)
				if err != nil {
					f, _ := strconv.ParseFloat(txt, 64)
					v = FltV(f)
				} else {
					v = IntV(u)
				}
			}
			toks = append(toks, Token{K: TNum, Text: txt, V: v, Start: st, End: j})
			i = j
			continue
		}
		if isAlpha(c) || (c == '$' && i+1 < n && isAlpha(line[i+1])) {
			j := i + 1
			for j < n && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			toks = append(toks, Token{K: TIdent, Text: line[i:j], Start: st, End: j})
			i = j
			continue
		}
		if c == '"' {
			j := i + 1
			for j < n && line[j] != '"' {
				if line[j] == '\\' && j+1 < n {
					j++
				}
				j++
			}
			raw := line[i+1 : min(j, n)]
			end := j + 1
			if end > n {
				end = n
			}
			toks = append(toks, Token{K: TStr, Text: line[i:end], S: decodeDQ(raw), Start: st, End: end})
			i = end
			continue
		}
		if c == '\'' {
			j := i + 1
			var b strings.Builder
			for j < n {
				if line[j] == '\'' {
					if j+1 < n && line[j+1] == '\'' {
						b.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				b.WriteByte(line[j])
				j++
			}
			end := j + 1
			if end > n {
				end = n
			}
			toks = append(toks, Token{K: TStr, Text: line[i:end], S: b.String(), Start: st, End: end})
			i = end
			continue
		}
		matched := false
		for _, op := range twoOps {
			if strings.HasPrefix(line[i:], op) {
				toks = append(toks, Token{K: TOp, Text: op, Start: st, End: i + 2})
				i += 2
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		toks = append(toks, Token{K: TOp, Text: string(c), Start: st, End: i + 1})
		i++
	}
	toks = append(toks, Token{K: TEnd, Start: n, End: n})
	return toks
}
