package main

import (
	"fmt"
	"math"
	"strings"
)

// ---------- tics ----------

func quantizeTics(rng float64, guide float64) float64 {
	if rng <= 0 {
		return 1
	}
	power := math.Pow(10, math.Floor(math.Log10(rng)))
	xnorm := rng / power
	posns := guide / xnorm
	var t float64
	switch {
	case posns > 40:
		t = 0.05
	case posns > 20:
		t = 0.1
	case posns > 10:
		t = 0.2
	case posns > 4:
		t = 0.5
	case posns > 2:
		t = 1
	case posns > 0.5:
		t = 2
	default:
		t = math.Ceil(xnorm)
	}
	return t * power
}

type AxisState struct {
	ax       *Axis
	min, max float64 // in plot units (log applied if log)
	step     float64
	log      bool
	base     float64
	tics     []ticItem
	minors   []float64
}

func (a *AxisState) toLin(v float64) float64 {
	if a.log {
		if v <= 0 {
			return math.NaN()
		}
		return math.Log(v) / math.Log(a.base)
	}
	return v
}

// computeAxis determines the range and tics for an axis given data extents
func computeAxis(ax *Axis, dmin, dmax float64, hasData bool, name string) *AxisState {
	st := &AxisState{ax: ax, log: ax.log, base: ax.base}
	lo, hi := ax.min, ax.max
	if ax.autoMin {
		if hasData {
			lo = dmin
		} else {
			lo = -10
			if ax.log {
				lo = 1
			}
		}
	}
	if ax.autoMax {
		if hasData {
			hi = dmax
		} else {
			hi = 10
			if ax.log {
				hi = 100
			}
		}
	}
	reversed := false
	if !ax.autoMin && !ax.autoMax && lo > hi {
		reversed = true
		lo, hi = hi, lo
	}
	if st.log {
		lo = st.toLin(lo)
		hi = st.toLin(hi)
	}
	if lo == hi && (ax.autoMin || ax.autoMax) {
		olo, ohi := lo, hi
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			lo, hi = lo-math.Abs(lo)*0.01, hi+math.Abs(hi)*0.01
		}
		if !st.log {
			warn2(fmt.Sprintf("Warning: empty %s range [%s:%s], adjusting to [%s:%s]", name, fmtShowNum(olo), fmtShowNum(ohi), fmtShowNum(lo), fmtShowNum(hi)))
		}
	}
	// tic step
	step := ax.ticStep
	if step == 0 || st.log {
		if st.log {
			step = quantizeTics(hi-lo, 20)
			if step < 1 {
				step = 1
			}
			step = math.Ceil(step)
		} else {
			step = quantizeTics(hi-lo, 20)
		}
	}
	if ax.ticStep != 0 && st.log {
		step = math.Log(ax.ticStep) / math.Log(st.base)
		if step <= 0 {
			step = 1
		}
	}
	if (ax.autoMin || ax.autoMax) && ax.tics && len(ax.ticList) == 0 {
		if ax.autoMin {
			lo = math.Floor(lo/step+1e-9) * step
		}
		if ax.autoMax {
			hi = math.Ceil(hi/step-1e-9) * step
		}
	}
	st.min, st.max = lo, hi
	if reversed || ax.reverse {
		st.min, st.max = hi, lo
	}
	st.step = step
	// generate tics
	if ax.tics {
		if len(ax.ticList) > 0 {
			for _, ti := range ax.ticList {
				st.tics = append(st.tics, ti)
			}
		} else {
			start := math.Ceil(lo/step-1e-9) * step
			end := hi
			if ax.ticHasStart {
				start = ax.ticStart
				if st.log {
					start = st.toLin(start)
				}
				for start < lo-step*1e-9 {
					start += step
				}
			}
			if ax.ticHasEnd && ax.ticEnd < end {
				end = ax.ticEnd
			}
			for i := 0; i < 1000; i++ {
				t := start + float64(i)*step
				if t > end+step*1e-9 {
					break
				}
				if math.Abs(t) < step*1e-10 {
					t = 0
				}
				v := t
				if st.log {
					v = math.Pow(st.base, t)
				}
				st.tics = append(st.tics, ticItem{label: "\x00", pos: v})
			}
		}
		// minor tics
		if st.log && ax.minor != 0 || (st.log && ax.minor == 0 && st.base == 10 && step == 1) {
			if step == 1 && st.base == 10 {
				for d := math.Floor(lo) - 1; d <= math.Ceil(hi); d++ {
					for k := 2.0; k < 10; k++ {
						v := k * math.Pow(10, d)
						lv := math.Log10(v)
						if lv > lo && lv < hi {
							st.minors = append(st.minors, v)
						}
					}
				}
			}
		} else if ax.minor > 1 || ax.minor == -1 {
			nm := ax.minor
			if nm == -1 {
				nm = 5
			}
			start := math.Floor(lo/step) * step
			for t := start; t <= hi+step*1e-9; t += step {
				for k := 1; k < nm; k++ {
					v := t + float64(k)*step/float64(nm)
					if v > lo+step*1e-9 && v < hi-step*1e-9 {
						st.minors = append(st.minors, v)
					}
				}
			}
		}
		for i := range st.tics {
			if st.tics[i].label == "\x00" {
				st.tics[i].label = formatTic(ax, st.tics[i].pos, st)
			}
		}
	}
	return st
}

func formatTic(ax *Axis, v float64, st *AxisState) string {
	f := ax.format
	if ax.timeData {
		if f == "% h" {
			f = "%H:%M"
		}
		return strftime(f, v)
	}
	if strings.Contains(f, "%h") || strings.Contains(f, "% h") {
		f = strings.ReplaceAll(f, "% h", "% g")
		f = strings.ReplaceAll(f, "%h", "%g")
	}
	base := 1.0
	if st.log {
		base = st.base
	}
	return gprintfLog(f, v, base)
}

func warn2(msg string) {
	writeErr(msg + "\n")
}

// ---------- canvas ----------

type Canvas struct {
	w, h int
	c    [][]byte
}

func newCanvas(w, h int) *Canvas {
	cv := &Canvas{w: w, h: h}
	cv.c = make([][]byte, h)
	for i := range cv.c {
		cv.c[i] = []byte(strings.Repeat(" ", w))
	}
	return cv
}

// set pixel at x (col), y (from bottom)
func (cv *Canvas) set(x, y int, ch byte) {
	if x < 0 || x >= cv.w || y < 0 || y >= cv.h {
		return
	}
	cv.c[cv.h-1-y][x] = ch
}

func (cv *Canvas) get(x, y int) byte {
	if x < 0 || x >= cv.w || y < 0 || y >= cv.h {
		return ' '
	}
	return cv.c[cv.h-1-y][x]
}

func (cv *Canvas) text(x, y int, s string) {
	for i := 0; i < len(s); i++ {
		cv.set(x+i, y, s[i])
	}
}

func (cv *Canvas) textJ(x, y int, s string, just int) {
	n := len([]rune(s))
	switch just {
	case 0: // left
	case 1: // center
		x -= n / 2
	case 2: // right
		x -= n - 1
	}
	if strings.ContainsRune(s, '\n') {
		lines := strings.Split(s, "\n")
		for i, l := range lines {
			cv.textJ(x, y-i, l, 0)
		}
		return
	}
	cv.text(x, y, s)
}

func roundI(v float64) int { return int(math.Floor(v + 0.5)) }

// line with char; border style lines (ch==0) use -,| and + at ends
func (cv *Canvas) line(x1, y1, x2, y2 int, ch byte) {
	dx := x2 - x1
	dy := y2 - y1
	n := dx
	if n < 0 {
		n = -n
	}
	ady := dy
	if ady < 0 {
		ady = -ady
	}
	if ady > n {
		n = ady
	}
	if n == 0 {
		if ch == 0 {
			cv.set(x1, y1, '+')
		} else {
			cv.set(x1, y1, ch)
		}
		return
	}
	for i := 0; i <= n; i++ {
		x := x1 + roundI(float64(i*dx)/float64(n))
		y := y1 + roundI(float64(i*dy)/float64(n))
		c := ch
		if ch == 0 {
			if i == 0 || i == n {
				c = '+'
			} else if dy == 0 {
				c = '-'
			} else if dx == 0 {
				c = '|'
			} else {
				c = '.'
			}
		}
		cv.set(x, y, c)
	}
}

var dumbLineChars = "*#$%@&=*"

func lineChar(lt int) byte {
	if lt < 0 {
		return 0
	}
	return dumbLineChars[lt%len(dumbLineChars)]
}

func pointChar(pt int) byte {
	if pt <= 0 {
		return '.'
	}
	return byte('A' + (pt-1)%26)
}

// ---------- plotting ----------

type Frame2D struct {
	xl, xr, yb, yt int
	xs, ys         *AxisState
}

func (f *Frame2D) mapX(x float64) float64 {
	xl := f.xs.toLin(x)
	return float64(f.xl) + (xl-f.xs.min)/(f.xs.max-f.xs.min)*float64(f.xr-f.xl)
}
func (f *Frame2D) mapY(y float64) float64 {
	yl := f.ys.toLin(y)
	return float64(f.yb) + (yl-f.ys.min)/(f.ys.max-f.ys.min)*float64(f.yt-f.yb)
}

func curveExtents(curves []*Curve) (xmin, xmax, ymin, ymax float64, hasX, hasY bool) {
	xmin, ymin = math.Inf(1), math.Inf(1)
	xmax, ymax = math.Inf(-1), math.Inf(-1)
	xa, ya := G.S.axes["x"], G.S.axes["y"]
	for _, c := range curves {
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				continue
			}
			xs := []float64{p.x}
			ys := []float64{p.y}
			switch c.style {
			case "boxes", "xerrorbars":
				xs = append(xs, p.ex...)
			case "yerrorbars", "yerrorlines":
				ys = append(ys, p.ex...)
			case "xyerrorbars", "xyerrorlines", "boxerrorbars":
				if len(p.ex) >= 4 {
					xs = append(xs, p.ex[0], p.ex[1])
					ys = append(ys, p.ex[2], p.ex[3])
				}
			}
			if c.style == "boxes" || c.style == "impulses" {
				ys = append(ys, 0)
			}
			// x extents only from in-range-y? use all
			xok := true
			if !xa.autoMin && p.x < math.Min(xa.min, xa.max) || !xa.autoMax && p.x > math.Max(xa.min, xa.max) {
				xok = false
			}
			for _, x := range xs {
				if xa.log && x <= 0 {
					continue
				}
				if x < xmin {
					xmin = x
				}
				if x > xmax {
					xmax = x
				}
				hasX = true
			}
			if !xok {
				continue
			}
			for _, y := range ys {
				if ya.log && y <= 0 {
					continue
				}
				if math.IsInf(y, 0) || math.IsNaN(y) {
					continue
				}
				if y < ymin {
					ymin = y
				}
				if y > ymax {
					ymax = y
				}
				hasY = true
			}
		}
	}
	return
}

var plotCount int

func renderPlot(curves []*Curve, is3D bool) {
	s := G.S
	if s.term == "unknown" {
		writeErr("WARNING: Plotting with an 'unknown' terminal.\nNo output will be generated. Please select a terminal with 'set terminal'.\n")
		return
	}
	if is3D {
		render3D(curves)
		return
	}
	xmin, xmax, ymin, ymax, hasX, hasY := curveExtents(curves)
	xa, ya := s.axes["x"], s.axes["y"]
	// functions only: x range from settings
	allFunc := true
	for _, c := range curves {
		if !c.isFunc {
			allFunc = false
		}
	}
	var xs *AxisState
	if allFunc && !s.parametric && !s.polar {
		lo, hi := xa.min, xa.max
		if xa.autoMin {
			lo = -10
		}
		if xa.autoMax {
			hi = 10
		}
		tmp := *xa
		tmp.min, tmp.max = lo, hi
		tmp.autoMin, tmp.autoMax = false, false
		xs = computeAxis(&tmp, lo, hi, true, "x")
		// autoscale extension for functions
		if xa.autoMin || xa.autoMax {
			t2 := *xa
			xs = computeAxis(&t2, lo, hi, true, "x")
		}
	} else {
		xs = computeAxis(xa, xmin, xmax, hasX, "x")
	}
	ys := computeAxis(ya, ymin, ymax, hasY, "y")
	xa.lastSet, xa.lastMin, xa.lastMax = true, xs.min, xs.max
	ya.lastSet, ya.lastMin, ya.lastMax = true, ys.min, ys.max
	if s.term == "dumb" {
		renderDumb(curves, xs, ys)
	} else if s.term == "svg" {
		renderSVG(curves, xs, ys)
	} else if s.term == "canvas" {
		renderCanvas(curves, xs, ys)
	}
}

func ticLabelWidth(st *AxisState) int {
	w := 0
	for _, t := range st.tics {
		if st.ax.min <= st.ax.max || true {
			lo, hi := math.Min(st.min, st.max), math.Max(st.min, st.max)
			p := st.toLin(t.pos)
			if p < lo-1e-9*(hi-lo) || p > hi+1e-9*(hi-lo) {
				continue
			}
		}
		n := len([]rune(t.label))
		if n > w {
			w = n
		}
	}
	return w
}

var mp struct {
	active   bool
	layout   bool
	rows     int
	cols     int
	idx      int
	cv       *Canvas
	title    string
}

func renderDumb(curves []*Curve, xs, ys *AxisState) {
	s := G.S
	W, H := s.termW, s.termH
	var cv *Canvas
	offX, offY := 0, 0
	pw, ph := W, H
	if mp.active {
		cv = mp.cv
		if mp.layout {
			r := mp.idx / mp.cols
			c := mp.idx % mp.cols
			pw = W / mp.cols
			ph = H / mp.rows
			offX = c * pw
			offY = H - (r+1)*ph
			if mp.title != "" {
				ph = (H - 2) / mp.rows
				offY = H - 2 - (r+1)*ph
			}
			mp.idx++
		} else {
			pw = int(float64(W) * s.sizeX)
			ph = int(float64(H) * s.sizeY)
			offX = int(float64(W) * s.originX)
			offY = int(float64(H) * s.originY)
		}
	} else {
		cv = newCanvas(W, H)
	}
	xmaxc := offX + pw - 1
	ymaxc := offY + ph - 1
	if !mp.active {
		xmaxc = W - 1
		ymaxc = H - 1
	}
	xa, ya := xs.ax, ys.ax
	ticsOut := xa.ticsOut
	// vertical layout
	yt := ymaxc - 1
	if s.title != "" {
		yt -= 2 * (strings.Count(s.title, "\n") + 1)
	}
	if s.tmargin >= 0 {
		yt = ymaxc - int(s.tmargin)
	}
	yb := offY + 2
	if xa.label != "" {
		d := 1 - int(xa.labelOffY)
		if d > 0 {
			yb += d
		}
	}
	if ticsOut && xa.tics {
		yb++
	}
	if s.bmargin >= 0 {
		yb = offY + int(s.bmargin)
	}
	xl := offX + 2
	if ya.tics {
		xl += ticLabelWidth(ys)
	}
	if ya.label != "" {
		xl += 3
	}
	if ticsOut && ya.tics {
		xl += 2
	}
	if s.lmargin >= 0 {
		xl = offX + int(s.lmargin)
	}
	xr := xmaxc - 3
	if ticsOut {
		xr -= 2
	}
	if s.rmargin >= 0 {
		xr = xmaxc - int(s.rmargin)
	}
	if !s.key.inside && s.key.on && s.key.horiz == "right" {
		// key outside right: reserve space
		maxlen := 0
		for _, c := range curves {
			if c.hasTitle && len(c.title) > maxlen {
				maxlen = len(c.title)
			}
		}
		xr -= maxlen + 8
	}
	fr := &Frame2D{xl: xl, xr: xr, yb: yb, yt: yt, xs: xs, ys: ys}
	// tics
	drawTicsDumb(cv, fr, xs, ys)
	// border drawn later; labels
	if xa.label != "" {
		cv.textJ((xl+xr)/2+int(xa.labelOffX), yb-2+int(xa.labelOffY), xa.label, 1)
	}
	if ya.label != "" {
		lbl := ya.label
		ymid := (yt + yb) / 2
		n := len(lbl)
		if offX+2-n/2 >= 0 {
			cv.textJ(offX+2, ymid, lbl, 1)
		}
	}
	if s.title != "" {
		lines := strings.Split(s.title, "\n")
		for i, l := range lines {
			cv.textJ((xl+xr)/2, ymaxc-2-i, l, 1)
		}
	}
	// labels
	for _, l := range s.labels {
		x, y := labelPos(fr, l.coordSys, l.x, l.y, offX, offY, pw, ph)
		j := 0
		if l.just == "center" {
			j = 1
		} else if l.just == "right" {
			j = 2
		}
		cv.textJ(roundI(x), roundI(y), l.text, j)
	}
	// plots with key
	keyEntries := 0
	for _, c := range curves {
		if c.hasTitle {
			keyEntries++
		}
	}
	maxlen := 0
	for _, c := range curves {
		if c.hasTitle && len([]rune(c.title)) > maxlen {
			maxlen = len([]rune(c.title))
		}
	}
	ki := 0
	for ci, c := range curves {
		lt := ci
		if c.lt >= 0 || c.lt == -2 {
			lt = c.lt
		}
		if c.elem != nil && c.elem.hasLT {
			lt = c.elem.lt
		}
		pt := ci + 1
		if c.pt >= 0 {
			pt = c.pt
		}
		if s.key.on && c.hasTitle {
			drawKeyEntry(cv, fr, c, ki, keyEntries, maxlen, lt, pt)
			ki++
		}
		drawCurveDumb(cv, fr, c, lt, pt)
	}
	// arrows
	for _, a := range s.arrows {
		x1, y1 := labelPos(fr, a.sys1, a.x1, a.y1, offX, offY, pw, ph)
		x2, y2 := labelPos(fr, a.sys2, a.x2, a.y2, offX, offY, pw, ph)
		if a.relative {
			x2 = fr.mapX(a.x1+a.x2)
			y2 = fr.mapY(a.y1+a.y2)
		}
		drawArrowDumb(cv, int(x1), int(y1), int(x2), int(y2), a.head)
	}
	// border
	if s.border&1 != 0 {
		cv.line(xl, yb, xr, yb, 0)
	}
	if s.border&2 != 0 {
		cv.line(xl, yb, xl, yt, 0)
	}
	if s.border&4 != 0 {
		cv.line(xl, yt, xr, yt, 0)
	}
	if s.border&8 != 0 {
		cv.line(xr, yb, xr, yt, 0)
	}
	if mp.active {
		return
	}
	emitCanvas(cv)
}

func emitCanvas(cv *Canvas) {
	w := outWriter()
	w.WriteString("\f")
	for i, row := range cv.c {
		w.Write(row)
		if i < len(cv.c)-1 || G.S.termFeed {
			w.WriteString("\n")
		}
	}
	w.Flush()
}

func labelPos(fr *Frame2D, sys string, x, y float64, offX, offY, pw, ph int) (float64, float64) {
	switch sys {
	case "graph":
		return float64(fr.xl) + x*float64(fr.xr-fr.xl), float64(fr.yb) + y*float64(fr.yt-fr.yb)
	case "screen":
		return float64(offX) + x*float64(pw-1), float64(offY) + y*float64(ph-1)
	case "character":
		return float64(offX) + x - 1, float64(offY) + y - 1
	}
	return fr.mapX(x), fr.mapY(y)
}

func drawArrowDumb(cv *Canvas, x1, y1, x2, y2 int, head int) {
	dx := x2 - x1
	dy := y2 - y1
	n := dx
	if n < 0 {
		n = -n
	}
	ady := dy
	if ady < 0 {
		ady = -ady
	}
	if ady > n {
		n = ady
	}
	for i := 0; i <= n; i++ {
		var x, y int
		if n == 0 {
			x, y = x1, y1
		} else {
			x = x1 + roundI(float64(i*dx)/float64(n))
			y = y1 + roundI(float64(i*dy)/float64(n))
		}
		c := byte('.')
		if dy == 0 {
			c = '-'
		} else if dx == 0 {
			c = '|'
		}
		cv.set(x, y, c)
	}
	if head&1 != 0 {
		var c byte
		switch {
		case dx == 0 && dy > 0:
			c = '^'
		case dx == 0 && dy < 0:
			c = 'v'
		case dx > 0:
			c = '>'
		default:
			c = '<'
		}
		cv.set(x2, y2, c)
	}
	if head&2 != 0 {
		var c byte
		switch {
		case dx == 0 && dy > 0:
			c = 'v'
		case dx == 0 && dy < 0:
			c = '^'
		case dx > 0:
			c = '<'
		default:
			c = '>'
		}
		cv.set(x1, y1, c)
	}
}

func inRangeLin(st *AxisState, v float64) bool {
	lo, hi := math.Min(st.min, st.max), math.Max(st.min, st.max)
	p := st.toLin(v)
	eps := 1e-9 * (hi - lo)
	return p >= lo-eps && p <= hi+eps
}

func drawTicsDumb(cv *Canvas, fr *Frame2D, xs, ys *AxisState) {
	s := G.S
	xa, ya := xs.ax, ys.ax
	ylab := fr.xl - 2
	if ya.ticsOut {
		ylab -= 2
	}
	if ya.grid {
		for _, t := range ys.tics {
			if !inRangeLin(ys, t.pos) {
				continue
			}
			y := roundI(fr.mapY(t.pos))
			for x := fr.xl + 1; x < fr.xr; x++ {
				cv.set(x, y, '.')
			}
		}
	}
	if xa.grid {
		for _, t := range xs.tics {
			if !inRangeLin(xs, t.pos) {
				continue
			}
			x := roundI(fr.mapX(t.pos))
			for y := fr.yb + 1; y < fr.yt; y++ {
				cv.set(x, y, ':')
			}
		}
	}
	for _, m := range ys.minors {
		y := roundI(fr.mapY(m))
		if ya.ticsOut {
			cv.line(fr.xl, y, fr.xl-1, y, 0)
		} else {
			cv.line(fr.xl, y, fr.xl+1, y, 0)
		}
		if ya.mirror && s.border&8 != 0 {
			if ya.ticsOut {
				cv.line(fr.xr, y, fr.xr+1, y, 0)
			} else {
				cv.line(fr.xr, y, fr.xr-1, y, 0)
			}
		}
	}
	for _, t := range ys.tics {
		if !inRangeLin(ys, t.pos) {
			continue
		}
		y := roundI(fr.mapY(t.pos))
		if ya.ticsOut {
			cv.line(fr.xl, y, fr.xl-2, y, 0)
		} else {
			cv.line(fr.xl, y, fr.xl+2, y, 0)
		}
		if ya.mirror && s.border&8 != 0 {
			if ya.ticsOut {
				cv.line(fr.xr, y, fr.xr+2, y, 0)
			} else {
				cv.line(fr.xr, y, fr.xr-2, y, 0)
			}
		}
		cv.textJ(ylab, y, t.label, 2)
	}
	xlabY := fr.yb - 1
	if xa.ticsOut {
		xlabY--
	}
	for _, t := range xs.tics {
		if !inRangeLin(xs, t.pos) {
			continue
		}
		x := roundI(fr.mapX(t.pos))
		if xa.ticsOut {
			cv.line(x, fr.yb, x, fr.yb-1, 0)
		} else {
			cv.line(x, fr.yb, x, fr.yb+1, 0)
		}
		if xa.mirror && s.border&4 != 0 {
			if xa.ticsOut {
				cv.line(x, fr.yt, x, fr.yt+1, 0)
			} else {
				cv.line(x, fr.yt, x, fr.yt-1, 0)
			}
		}
		cv.textJ(x, xlabY, t.label, 1)
	}
}

func drawKeyEntry(cv *Canvas, fr *Frame2D, c *Curve, ki, n, maxlen, lt, pt int) {
	k := G.S.key
	width := maxlen + 8
	var keyLeft int
	if k.horiz == "left" {
		keyLeft = fr.xl + 1
	} else if k.horiz == "center" {
		keyLeft = (fr.xl+fr.xr)/2 - width/2
	} else {
		keyLeft = fr.xr - 1 - width
		if !k.inside {
			keyLeft = fr.xr + 2
		}
	}
	var row int
	if k.vert == "bottom" {
		row = fr.yb + 1 + (n - 1 - ki)
	} else if k.vert == "center" {
		row = (fr.yt+fr.yb)/2 + n/2 - ki
	} else {
		row = fr.yt - 2 - ki
		if !k.inside {
			row = fr.yt - 1 - ki
		}
	}
	if k.atSet {
		x, y := labelPos(fr, "screen", k.atX, k.atY, 0, 0, G.S.termW, G.S.termH)
		keyLeft = roundI(x) - width
		row = roundI(y) - 1 - ki
	}
	var sl, sr int
	if k.reverse {
		sl = keyLeft - 7
		sr = keyLeft - 1
		cv.textJ(keyLeft, row, c.title, 0)
	} else {
		sl = keyLeft + maxlen + 1
		sr = sl + 6
		if k.just == "Left" {
			cv.textJ(keyLeft, row, c.title, 0)
		} else {
			cv.textJ(sl-2, row, c.title, 2)
		}
	}
	drawSample(cv, c, sl, sr, row, lt, pt)
}

func drawSample(cv *Canvas, c *Curve, sl, sr, row, lt, pt int) {
	switch c.style {
	case "points":
		cv.set((sl+sr)/2, row, ptCharFor(c, pt))
	case "linespoints":
		cv.line(sl, row, sr, row, lineChar(lt))
		cv.set((sl+sr)/2, row, ptCharFor(c, pt))
	case "dots":
		cv.set((sl+sr)/2, row, '.')
	case "yerrorbars", "xerrorbars", "xyerrorbars":
		cv.line(sl, row, sr, row, lineChar(lt))
	default:
		cv.line(sl, row, sr, row, lineChar(lt))
	}
}

func ptCharFor(c *Curve, pt int) byte {
	if c.ptChar != "" {
		return c.ptChar[0]
	}
	return pointChar(pt)
}

func clipSeg(x1, y1, x2, y2, xl, xr, yb, yt float64) (float64, float64, float64, float64, bool) {
	// Liang-Barsky
	dx := x2 - x1
	dy := y2 - y1
	t0, t1 := 0.0, 1.0
	p := []float64{-dx, dx, -dy, dy}
	q := []float64{x1 - xl, xr - x1, y1 - yb, yt - y1}
	for i := 0; i < 4; i++ {
		if p[i] == 0 {
			if q[i] < 0 {
				return 0, 0, 0, 0, false
			}
			continue
		}
		r := q[i] / p[i]
		if p[i] < 0 {
			if r > t1 {
				return 0, 0, 0, 0, false
			}
			if r > t0 {
				t0 = r
			}
		} else {
			if r < t0 {
				return 0, 0, 0, 0, false
			}
			if r < t1 {
				t1 = r
			}
		}
	}
	return x1 + t0*dx, y1 + t0*dy, x1 + t1*dx, y1 + t1*dy, true
}

func drawCurveDumb(cv *Canvas, fr *Frame2D, c *Curve, lt, pt int) {
	xl, xr, yb, yt := float64(fr.xl), float64(fr.xr), float64(fr.yb), float64(fr.yt)
	ch := lineChar(lt)
	inside := func(x, y float64) bool {
		return x >= xl-1e-9 && x <= xr+1e-9 && y >= yb-1e-9 && y <= yt+1e-9
	}
	drawLines := func() {
		var px, py float64
		have := false
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				have = false
				continue
			}
			x, y := fr.mapX(p.x), fr.mapY(p.y)
			if math.IsNaN(x) || math.IsNaN(y) {
				have = false
				continue
			}
			if have {
				if a, b, cc, d, ok := clipSeg(px, py, x, y, xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
			} else if inside(x, y) {
				cv.set(roundI(x), roundI(y), ch)
			}
			px, py = x, y
			have = true
		}
	}
	drawPoints := func(pc byte) {
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				continue
			}
			x, y := fr.mapX(p.x), fr.mapY(p.y)
			if inside(x, y) {
				cv.set(roundI(x), roundI(y), pc)
			}
		}
	}
	switch c.style {
	case "lines":
		drawLines()
	case "points":
		drawPoints(ptCharFor(c, pt))
	case "linespoints":
		drawLines()
		drawPoints(ptCharFor(c, pt))
	case "dots":
		drawPoints('.')
	case "impulses":
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				continue
			}
			x, y := fr.mapX(p.x), fr.mapY(p.y)
			y0 := fr.mapY(0)
			if math.IsNaN(y0) {
				y0 = yb
			}
			if a, b, cc, d, ok := clipSeg(x, y0, x, y, xl, xr, yb, yt); ok {
				cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
			}
		}
	case "steps", "fsteps", "histeps":
		var prev *Pt
		for i := range c.pts {
			p := &c.pts[i]
			if p.brk || p.typ == 'u' {
				prev = nil
				continue
			}
			if prev != nil {
				x1, y1 := fr.mapX(prev.x), fr.mapY(prev.y)
				x2, y2 := fr.mapX(p.x), fr.mapY(p.y)
				var mx, my float64
				if c.style == "steps" {
					mx, my = x2, y1
				} else {
					mx, my = x1, y2
				}
				if a, b, cc, d, ok := clipSeg(x1, y1, mx, my, xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
				if a, b, cc, d, ok := clipSeg(mx, my, x2, y2, xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
			}
			prev = p
		}
	case "boxes":
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' || len(p.ex) < 2 {
				continue
			}
			x1, x2 := fr.mapX(p.ex[0]), fr.mapX(p.ex[1])
			y0 := fr.mapY(0)
			if y0 < yb {
				y0 = yb
			}
			if y0 > yt {
				y0 = yt
			}
			y := fr.mapY(p.y)
			segs := [][4]float64{{x1, y0, x1, y}, {x1, y, x2, y}, {x2, y, x2, y0}}
			for _, sg := range segs {
				if a, b, cc, d, ok := clipSeg(sg[0], sg[1], sg[2], sg[3], xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
			}
		}
	case "yerrorbars", "xerrorbars", "xyerrorbars", "yerrorlines", "xerrorlines", "xyerrorlines":
		if strings.HasSuffix(c.style, "lines") {
			drawLines()
		}
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				continue
			}
			x, y := fr.mapX(p.x), fr.mapY(p.y)
			if strings.HasPrefix(c.style, "y") && len(p.ex) >= 2 {
				ylo, yhi := fr.mapY(p.ex[0]), fr.mapY(p.ex[1])
				if a, b, cc, d, ok := clipSeg(x, ylo, x, yhi, xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
			}
			if strings.HasPrefix(c.style, "x") && len(p.ex) >= 2 {
				xlo, xhi := fr.mapX(p.ex[0]), fr.mapX(p.ex[1])
				if a, b, cc, d, ok := clipSeg(xlo, y, xhi, y, xl, xr, yb, yt); ok {
					cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
				}
				if c.style[1] == 'y' && len(p.ex) >= 4 {
					ylo, yhi := fr.mapY(p.ex[2]), fr.mapY(p.ex[3])
					if a, b, cc, d, ok := clipSeg(x, ylo, x, yhi, xl, xr, yb, yt); ok {
						cv.line(roundI(a), roundI(b), roundI(cc), roundI(d), ch)
					}
				}
			}
			if inside(x, y) {
				cv.set(roundI(x), roundI(y), ptCharFor(c, pt))
			}
		}
	case "labels":
		for _, p := range c.pts {
			if p.brk || p.typ == 'u' {
				continue
			}
			x, y := fr.mapX(p.x), fr.mapY(p.y)
			if inside(x, y) {
				cv.textJ(roundI(x), roundI(y), p.label, 1)
			}
		}
	default:
		drawLines()
	}
}
