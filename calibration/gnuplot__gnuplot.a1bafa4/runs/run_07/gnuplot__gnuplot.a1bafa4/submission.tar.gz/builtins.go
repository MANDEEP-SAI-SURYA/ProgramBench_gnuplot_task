package main

import (
	"os/exec"
	"math"
	"strconv"
	"strings"
	"unicode/utf8"
)

type UserFunc struct {
	Params []string
	Body   Node
	Text   string
}

func argReal(v Value) float64 { return v.Real() }

func angIn(x float64) float64 {
	if G.degrees {
		return x * math.Pi / 180
	}
	return x
}
func angOut(x float64) float64 {
	if G.degrees {
		return x * 180 / math.Pi
	}
	return x
}

func realOrUndef(f float64) Value {
	if math.IsNaN(f) {
		return undefinedV()
	}
	return FltV(f)
}

func callFunc(c *NCall) Value {
	if uf, ok := G.funcs[c.Name]; ok {
		if len(c.Args) != len(uf.Params) {
			panic(gpErrAt(c.Pos, "function "+c.Name+" requires "+strconv.Itoa(len(uf.Params))+" variable"+plural(len(uf.Params))))
		}
		fr := Frame{}
		vals := make([]Value, len(c.Args))
		for i, a := range c.Args {
			vals[i] = eval(a)
		}
		for i, p := range uf.Params {
			fr[p] = vals[i]
		}
		frames = append(frames, fr)
		defer func() { frames = frames[:len(frames)-1] }()
		return eval(uf.Body)
	}
	args := make([]Value, 0, len(c.Args))
	lazy := c.Name == "exists" || c.Name == "__arraylit"
	_ = lazy
	for _, a := range c.Args {
		args = append(args, eval(a))
	}
	return builtin(c.Name, args, c.Pos)
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

func need(args []Value, n int, name string) {
	if len(args) != n {
		if len(args) > n {
			// gnuplot prints warning; we approximate by using last args
			return
		}
		panic(gpErrNC("stack underflow (function call with missing parameters?)"))
	}
}

func a1(args []Value) Value {
	if len(args) == 0 {
		panic(gpErrNC("not enough parameters"))
	}
	return args[len(args)-1]
}

func builtin(name string, args []Value, pos int) Value {
	switch name {
	case "__arraylit":
		arr := make([]Value, len(args))
		copy(arr, args)
		return Value{K: KArr, A: &arr}
	case "abs":
		v := a1(args)
		if v.K == KInt {
			if v.I < 0 {
				return IntV(-v.I)
			}
			return v
		}
		if v.Im != 0 {
			return FltV(math.Hypot(v.R, v.Im))
		}
		return FltV(math.Abs(v.Real()))
	case "sgn":
		v := a1(args)
		x := v.Real()
		if x > 0 {
			return IntV(1)
		} else if x < 0 {
			return IntV(-1)
		}
		return IntV(0)
	case "int":
		v := a1(args)
		if v.K == KInt {
			return v
		}
		x := v.Real()
		if math.IsNaN(x) || math.Abs(x) >= 9.2233720368547758e18 {
			return FltV(math.NaN())
		}
		return IntV(int64(x))
	case "floor", "ceil", "round":
		v := a1(args)
		if v.K == KInt {
			return v
		}
		x := v.Real()
		var r float64
		if name == "floor" {
			r = math.Floor(x)
		} else if name == "ceil" {
			r = math.Ceil(x)
		} else {
			r = math.Round(x)
		}
		if math.Abs(r) >= 9.2e18 || math.IsNaN(r) {
			return FltV(r)
		}
		return IntV(int64(r))
	case "real":
		v := a1(args)
		return FltV(v.Real())
	case "imag":
		v := a1(args)
		if v.K == KInt {
			return FltV(0)
		}
		v.Real()
		return FltV(v.Im)
	case "arg":
		v := a1(args)
		c := cmplxOf(v)
		v.Real()
		return FltV(angOut(math.Atan2(imag(c), real(c))))
	case "sqrt":
		v := a1(args)
		x := v.Real()
		if v.K == KCmplx && v.Im != 0 {
			return fromC(csqrt(cmplxOf(v)))
		}
		if x < 0 {
			return CV(0, math.Sqrt(-x))
		}
		return FltV(math.Sqrt(x))
	case "exp":
		v := a1(args)
		if v.K == KCmplx && v.Im != 0 {
			return fromC(cexp(cmplxOf(v)))
		}
		return FltV(math.Exp(v.Real()))
	case "log", "log10":
		v := a1(args)
		x := v.Real()
		var r complex128
		if v.K == KCmplx && v.Im != 0 || x < 0 {
			r = clog(cmplxOf(v))
		} else {
			if x == 0 {
				return undefinedV()
			}
			r = complex(math.Log(x), 0)
		}
		if name == "log10" {
			r /= complex(math.Ln10, 0)
		}
		return fromC(r)
	case "sin", "cos", "tan":
		v := a1(args)
		if v.K == KCmplx && v.Im != 0 {
			z := cmplxOf(v)
			iz := complex(-imag(z), real(z))
			e1 := cexp(iz)
			e2 := cexp(-iz)
			switch name {
			case "sin":
				return fromC((e1 - e2) / complex(0, 2))
			case "cos":
				return fromC((e1 + e2) / 2)
			default:
				return fromC((e1 - e2) / complex(0, 2) / ((e1 + e2) / 2))
			}
		}
		x := angIn(v.Real())
		switch name {
		case "sin":
			return FltV(math.Sin(x))
		case "cos":
			return FltV(math.Cos(x))
		}
		return FltV(math.Tan(x))
	case "asin", "acos", "atan":
		x := a1(args).Real()
		switch name {
		case "asin":
			if x > 1 || x < -1 {
				return undefinedV()
			}
			return FltV(angOut(math.Asin(x)))
		case "acos":
			if x > 1 || x < -1 {
				return undefinedV()
			}
			return FltV(angOut(math.Acos(x)))
		}
		return FltV(angOut(math.Atan(x)))
	case "atan2":
		need(args, 2, name)
		return FltV(angOut(math.Atan2(args[0].Real(), args[1].Real())))
	case "sinh":
		return FltV(math.Sinh(a1(args).Real()))
	case "cosh":
		return FltV(math.Cosh(a1(args).Real()))
	case "tanh":
		return FltV(math.Tanh(a1(args).Real()))
	case "asinh":
		return FltV(math.Asinh(a1(args).Real()))
	case "acosh":
		return realOrUndef(math.Acosh(a1(args).Real()))
	case "atanh":
		return realOrUndef(math.Atanh(a1(args).Real()))
	case "erf":
		return FltV(math.Erf(a1(args).Real()))
	case "erfc":
		return FltV(math.Erfc(a1(args).Real()))
	case "inverf":
		return FltV(math.Erfinv(a1(args).Real()))
	case "norm":
		return FltV(0.5 * math.Erfc(-a1(args).Real()/math.Sqrt2))
	case "invnorm":
		p := a1(args).Real()
		if p <= 0 || p >= 1 {
			return undefinedV()
		}
		return FltV(-math.Sqrt2 * math.Erfcinv(2*p))
	case "gamma":
		x := a1(args).Real()
		return realOrUndef(math.Gamma(x))
	case "lgamma":
		l, _ := math.Lgamma(a1(args).Real())
		return FltV(l)
	case "besj0":
		return FltV(math.J0(a1(args).Real()))
	case "besj1":
		return FltV(math.J1(a1(args).Real()))
	case "besy0":
		x := a1(args).Real()
		if x <= 0 {
			return undefinedV()
		}
		return FltV(math.Y0(x))
	case "besy1":
		x := a1(args).Real()
		if x <= 0 {
			return undefinedV()
		}
		return FltV(math.Y1(x))
	case "besjn":
		need(args, 2, name)
		return FltV(math.Jn(int(toIntVal(args[0])), args[1].Real()))
	case "besyn":
		need(args, 2, name)
		return FltV(math.Yn(int(toIntVal(args[0])), args[1].Real()))
	case "besi0":
		return FltV(besselI(0, a1(args).Real()))
	case "besi1":
		return FltV(besselI(1, a1(args).Real()))
	case "igamma":
		need(args, 2, name)
		return realOrUndef(igamma(args[0].Real(), args[1].Real()))
	case "ibeta":
		need(args, 3, name)
		return realOrUndef(ibeta(args[0].Real(), args[1].Real(), args[2].Real()))
	case "lambertw":
		return FltV(lambertw(a1(args).Real()))
	case "rand":
		return FltV(gpRand(toIntVal(a1(args))))
	case "strlen":
		v := a1(args)
		if v.K != KStr {
			panic(gpErrNC("internal error : strlen of non-STRING argument"))
		}
		return IntV(int64(utf8.RuneCountInString(v.S)))
	case "substr":
		need(args, 3, name)
		if args[0].K != KStr {
			panic(gpErrNC("internal error : substr of non-string"))
		}
		return StrV(substrRunes(args[0].S, int(toIntVal(args[1])), int(toIntVal(args[2]))))
	case "strstrt":
		need(args, 2, name)
		if args[0].K != KStr || args[1].K != KStr {
			panic(gpErrNC("internal error : non-STRING argument to strstrt"))
		}
		i := strings.Index(args[0].S, args[1].S)
		if i < 0 {
			return IntV(0)
		}
		return IntV(int64(utf8.RuneCountInString(args[0].S[:i]) + 1))
	case "words", "word":
		if args[0].K != KStr {
			panic(gpErrNC("internal error : non-STRING argument"))
		}
		ws := splitWords(args[0].S)
		if name == "words" {
			return IntV(int64(len(ws)))
		}
		need(args, 2, name)
		n := int(toIntVal(args[1]))
		if n < 1 || n > len(ws) {
			return StrV("")
		}
		return StrV(ws[n-1])
	case "trim":
		v := a1(args)
		if v.K != KStr {
			panic(gpErrNC("internal error : non-STRING argument"))
		}
		return StrV(strings.Trim(v.S, " \t\n\r"))
	case "sprintf":
		return StrV(gpSprintf(args))
	case "gprintf":
		need(args, 2, name)
		if args[0].K != KStr {
			panic(gpErrNC("First parameter to gprintf must be a format string"))
		}
		return StrV(gprintf(args[0].S, args[1].Real()))
	case "exists":
		v := a1(args)
		if v.K != KStr {
			panic(gpErrNC("Argument to exists() must be a string"))
		}
		_, ok := G.vars[v.S]
		if !ok {
			_, ok = G.datablocks[v.S]
		}
		return BoolV(ok)
	case "value":
		v := a1(args)
		if v.K != KStr {
			panic(gpErrNC("Argument to value() must be a string"))
		}
		if x, ok := G.vars[v.S]; ok {
			return x
		}
		return undefinedV()
	case "column", "stringcolumn", "strcol", "valid", "columnhead", "timecolumn":
		if name == "columnhead" {
			return StrV(columnHead(toIntVal(a1(args))))
		}
		if name == "valid" {
			return BoolV(columnValid(a1(args)))
		}
		if name == "timecolumn" {
			if len(args) >= 2 && args[1].K == KStr {
				s := columnValue(args[0], true)
				t, ok := strptime(args[1].S, s.S)
				if !ok {
					return undefinedV()
				}
				return FltV(t)
			}
			return columnValue(args[0], false)
		}
		return columnValue(a1(args), name != "column")
	case "strftime":
		need(args, 2, name)
		if args[0].K != KStr {
			panic(gpErrNC("First parameter to strftime must be a format string"))
		}
		return StrV(strftime(args[0].S, args[1].Real()))
	case "strptime":
		need(args, 2, name)
		if args[0].K != KStr || args[1].K != KStr {
			panic(gpErrNC("Both parameters to strptime must be strings"))
		}
		t, ok := strptime(args[0].S, args[1].S)
		if !ok {
			return undefinedV()
		}
		return FltV(t)
	case "time":
		return IntV(int64(0))
	case "tm_sec", "tm_min", "tm_hour", "tm_mday", "tm_mon", "tm_year", "tm_wday", "tm_yday":
		t := a1(args).Real()
		tm := breakTime(t)
		switch name {
		case "tm_sec":
			return FltV(float64(tm.sec) + tm.frac)
		case "tm_min":
			return FltV(float64(tm.min))
		case "tm_hour":
			return FltV(float64(tm.hour))
		case "tm_mday":
			return FltV(float64(tm.mday))
		case "tm_mon":
			return FltV(float64(tm.mon))
		case "tm_year":
			return FltV(float64(tm.year))
		case "tm_wday":
			return FltV(float64(tm.wday))
		case "tm_yday":
			return FltV(float64(tm.yday))
		}
	case "system":
		v := a1(args)
		if v.K != KStr {
			panic(gpErrNC("non-string argument to system()"))
		}
		flushAll()
		out, _ := exec.Command("/bin/sh", "-c", v.S).Output()
		return StrV(strings.TrimSuffix(string(out), "\n"))
	}
	panic(gpErrNC("undefined function: " + name))
}

func isBuiltin(name string) bool {
	switch name {
	case "abs", "sgn", "int", "floor", "ceil", "real", "imag", "arg", "conj", "sqrt", "exp", "log", "log10", "sin", "cos", "tan", "asin", "acos", "atan", "atan2", "sinh", "cosh", "tanh", "asinh", "acosh", "atanh", "erf", "erfc", "inverf", "norm", "invnorm", "gamma", "lgamma", "besj0", "besj1", "besy0", "besy1", "besjn", "besyn", "besi0", "besi1", "igamma", "ibeta", "lambertw", "rand", "strlen", "substr", "strstrt", "words", "word", "trim", "sprintf", "gprintf", "exists", "value", "column", "stringcolumn", "strcol", "valid", "columnhead", "timecolumn", "strftime", "strptime", "time", "tm_sec", "tm_min", "tm_hour", "tm_mday", "tm_mon", "tm_year", "tm_wday", "tm_yday", "system":
		return true
	}
	return false
}

func splitWords(s string) []string {
	var out []string
	i := 0
	for i < len(s) {
		for i < len(s) && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]
			j := i + 1
			for j < len(s) && s[j] != q {
				j++
			}
			out = append(out, s[i+1:min(j, len(s))])
			i = j + 1
			continue
		}
		j := i
		for j < len(s) && !(s[j] == ' ' || s[j] == '\t' || s[j] == '\n') {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

func csqrt(z complex128) complex128 {
	r := math.Hypot(real(z), imag(z))
	a := math.Sqrt((r + real(z)) / 2)
	b := math.Sqrt((r - real(z)) / 2)
	if imag(z) < 0 {
		b = -b
	}
	return complex(a, b)
}

func besselI(n int, x float64) float64 {
	sum := 0.0
	term := 1.0
	half := x / 2
	for k := 0; k < n; k++ {
		term *= half / float64(k+1)
	}
	for k := 0; k < 500; k++ {
		sum += term
		term *= half * half / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func igamma(a, x float64) float64 {
	if x < 0 || a <= 0 {
		return math.NaN()
	}
	if x == 0 {
		return 0
	}
	gln, _ := math.Lgamma(a)
	if x < a+1 {
		ap := a
		sum := 1.0 / a
		del := sum
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-gln)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-gln)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m < 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x < 0 || x > 1 || a <= 0 || b <= 0 {
		return math.NaN()
	}
	if x == 0 || x == 1 {
		return x
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1)
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		nw := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(nw-w) < 1e-15*(1+math.Abs(nw)) {
			w = nw
			break
		}
		w = nw
	}
	return w
}

// L'Ecuyer combined generator (approximation of gnuplot's)
var rngS1, rngS2 int64 = 1234567890, 123456789

func gpRand(seed int64) float64 {
	if seed < 0 {
		rngS1, rngS2 = 1234567890, 123456789
		return 0
	}
	if seed > 0 {
		rngS1 = seed
		rngS2 = seed
		return 0
	}
	k := rngS1 / 53668
	rngS1 = 40014*(rngS1-k*53668) - k*12211
	if rngS1 < 0 {
		rngS1 += 2147483563
	}
	k = rngS2 / 52774
	rngS2 = 40692*(rngS2-k*52774) - k*3791
	if rngS2 < 0 {
		rngS2 += 2147483399
	}
	z := rngS1 - rngS2
	if z < 1 {
		z += 2147483562
	}
	return float64(z) * 4.656613057391769e-10
}
