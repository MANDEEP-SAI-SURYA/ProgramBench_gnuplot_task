package main

import (
	"strconv"
	"math"
	"strings"
)

type GPError struct {
	Msg     string
	Pos     int // column, -1 = no caret
	HasPos  bool
	IsWarn  bool
	srcName string
	line    int
	inBlock bool
	filled  bool
}

func (e *GPError) Error() string { return e.Msg }

func gpErrNC(msg string) *GPError { return &GPError{Msg: msg, Pos: -1} }
func gpErrAt(pos int, msg string) *GPError {
	return &GPError{Msg: msg, Pos: pos, HasPos: true}
}

// Parser over tokens
type Parser struct {
	toks      []Token
	p         int
	line      string
	exprStart int
	depth     int
}

func (ps *Parser) peek() Token     { return ps.toks[ps.p] }
func (ps *Parser) peekN(n int) Token {
	if ps.p+n < len(ps.toks) {
		return ps.toks[ps.p+n]
	}
	return ps.toks[len(ps.toks)-1]
}
func (ps *Parser) next() Token {
	t := ps.toks[ps.p]
	if t.K != TEnd {
		ps.p++
	}
	return t
}
func (ps *Parser) is(s string) bool {
	t := ps.toks[ps.p]
	return (t.K == TOp || t.K == TIdent) && t.Text == s
}
func (ps *Parser) isOp(s string) bool {
	t := ps.toks[ps.p]
	return t.K == TOp && t.Text == s
}
func (ps *Parser) atEnd() bool {
	t := ps.toks[ps.p]
	return t.K == TEnd || (t.K == TOp && t.Text == ";")
}
func (ps *Parser) errHere(msg string) *GPError {
	return gpErrAt(ps.toks[ps.p].Start, msg)
}
func (ps *Parser) expect(s string) {
	if !ps.isOp(s) {
		panic(ps.errHere("'" + s + "' expected"))
	}
	ps.p++
}

// AST
type Node interface{}

type NConst struct{ V Value }
type NVar struct {
	Name string
	Pos  int
}
type NBin struct {
	Op   string
	L, R Node
}
type NUn struct {
	Op string
	X  Node
}
type NTern struct{ C, A, B Node }
type NCall struct {
	Name string
	Args []Node
	Pos  int
}
type NIndex struct {
	X    Node
	I    Node
	Pos  int
}
type NSlice struct {
	X    Node
	A, B Node
}
type NCard struct {
	Name string
}
type NSum struct {
	Var  string
	A, B Node
	X    Node
}
type NColumn struct{ X Node } // $N
type NAssign struct {
	Name string
	Idx  Node
	X    Node
}
type NComplex struct{ Re, Im Node }
type NSeq struct{ A, B Node }

func (ps *Parser) parseExpr() Node {
	saved := ps.exprStart
	ps.exprStart = ps.p
	ps.depth++
	if ps.depth > 1 {
		ps.exprStart = -1
	}
	defer func() { ps.exprStart = saved; ps.depth-- }()
	return ps.parseTernary()
}

func (ps *Parser) parseTernary() Node {
	c := ps.parseBin(0)
	if ps.isOp("?") {
		ps.p++
		a := ps.parseTernary()
		if !ps.isOp(":") {
			panic(ps.errHere("expecting ':'"))
		}
		ps.p++
		b := ps.parseTernary()
		return &NTern{c, a, b}
	}
	return c
}

var binLevels = [][]string{
	{"||"}, {"&&"}, {"|"}, {"^"}, {"&"}, {"==", "!=", "eq", "ne"}, {"<", "<=", ">", ">="}, {"<<", ">>"}, {"+", "-", "."}, {"*", "/", "%"},
}

func (ps *Parser) parseBin(level int) Node {
	if level >= len(binLevels) {
		return ps.parseUnary()
	}
	l := ps.parseBin(level + 1)
	for {
		t := ps.peek()
		found := ""
		for _, op := range binLevels[level] {
			if (t.K == TOp || (t.K == TIdent && (op == "eq" || op == "ne"))) && t.Text == op {
				found = op
				break
			}
		}
		if found == "" {
			return l
		}
		ps.p++
		r := ps.parseBin(level + 1)
		l = &NBin{found, l, r}
	}
}

func (ps *Parser) parseUnary() Node {
	t := ps.peek()
	if t.K == TOp && (t.Text == "-" || t.Text == "+" || t.Text == "!" || t.Text == "~") {
		ps.p++
		x := ps.parseUnary()
		if t.Text == "-" {
			if c, ok := x.(*NConst); ok && c.V.IsNum() {
				// keep as op for semantics
				_ = c
			}
		}
		return &NUn{t.Text, x}
	}
	return ps.parsePow()
}

func (ps *Parser) parsePow() Node {
	b := ps.parsePostfix()
	if ps.isOp("**") {
		ps.p++
		e := ps.parseUnary()
		return &NBin{"**", b, e}
	}
	return b
}

func (ps *Parser) parsePostfix() Node {
	x := ps.parsePrimary()
	for {
		if ps.isOp("!") && !(ps.peekN(1).K == TOp && ps.peekN(1).Text == "=") {
			ps.p++
			x = &NUn{"fact", x}
			continue
		}
		if ps.isOp("[") {
			pos := ps.peek().Start
			ps.p++
			var a, b Node
			if !ps.isOp(":") {
				a = ps.parseExpr()
			}
			if ps.isOp(":") {
				ps.p++
				if !ps.isOp("]") {
					b = ps.parseExpr()
				}
				ps.expect("]")
				x = &NSlice{x, a, b}
				continue
			}
			ps.expect("]")
			x = &NIndex{x, a, pos}
			continue
		}
		return x
	}
}

func (ps *Parser) parsePrimary() Node {
	t := ps.peek()
	switch t.K {
	case TNum:
		ps.p++
		return &NConst{t.V}
	case TStr:
		ps.p++
		return &NConst{StrV(t.S)}
	case TIdent:
		if t.Text == "sum" && ps.peekN(1).K == TOp && ps.peekN(1).Text == "[" {
			ps.p += 2
			vt := ps.next()
			if vt.K != TIdent {
				panic(gpErrAt(vt.Start, "Expecting dummy variable name"))
			}
			ps.expect("=")
			a := ps.parseExpr()
			ps.expect(":")
			b := ps.parseExpr()
			ps.expect("]")
			x := ps.parseExpr()
			return &NSum{vt.Text, a, b, x}
		}
		ps.p++
		if ps.isOp("(") {
			ps.p++
			var args []Node
			if !ps.isOp(")") {
				for {
					args = append(args, ps.parseExpr())
					if ps.isOp(",") {
						ps.p++
						continue
					}
					break
				}
			}
			ps.expect(")")
			return &NCall{t.Text, args, t.Start}
		}
		return &NVar{t.Text, t.Start}
	case TOp:
		switch t.Text {
		case "(":
			ps.p++
			x := ps.parseExpr()
			for ps.isOp(",") {
				ps.p++
				y := ps.parseExpr()
				x = &NSeq{x, y}
			}
			ps.expect(")")
			return x
		case "{":
			ps.p++
			re := ps.parseExpr()
			ps.expect(",")
			im := ps.parseExpr()
			ps.expect("}")
			return &NComplex{re, im}
		case "$":
			ps.p++
			n := ps.peek()
			if n.K == TNum {
				ps.p++
				return &NColumn{&NConst{n.V}}
			}
			if n.K == TOp && n.Text == "(" {
				x := ps.parsePrimary()
				return &NColumn{x}
			}
			panic(ps.errHere("Column number or datablock name expected"))
		case "|":
			ps.p++
			n := ps.next()
			if n.K != TIdent {
				panic(gpErrAt(n.Start, "invalid expression "))
			}
			ps.expect("|")
			return &NCard{n.Text}
		case "[":
			ps.p++
			var elems []Node
			for !ps.isOp("]") {
				elems = append(elems, ps.parseExpr())
				if ps.isOp(",") {
					ps.p++
				} else {
					break
				}
			}
			ps.expect("]")
			return &NCall{"__arraylit", elems, t.Start}
		}
	}
	if ps.atEnd() && ps.p == ps.exprStart {
		panic(ps.errHere("constant expression required"))
	}
	panic(ps.errHere("invalid expression "))
}

// ---------- evaluation -------------

var undefFlag bool

func undefinedV() Value {
	undefFlag = true
	return FltV(math.NaN())
}

type Frame map[string]Value

var frames []Frame

func lookupVar(name string) (Value, bool) {
	for i := len(frames) - 1; i >= 0; i-- {
		if v, ok := frames[i][name]; ok {
			return v, true
		}
	}
	v, ok := G.vars[name]
	return v, ok
}

func eval(n Node) Value {
	switch x := n.(type) {
	case *NConst:
		return x.V
	case *NVar:
		v, ok := lookupVar(x.Name)
		if !ok || v.K == KUndef {
			panic(gpErrNC("undefined variable: " + x.Name))
		}
		return v
	case *NComplex:
		re := eval(x.Re).Real()
		im := eval(x.Im).Real()
		return CV(re, im)
	case *NSeq:
		eval(x.A)
		return eval(x.B)
	case *NTern:
		c := eval(x.C)
		if truthy(c) {
			return eval(x.A)
		}
		return eval(x.B)
	case *NUn:
		v := eval(x.X)
		return unop(x.Op, v)
	case *NBin:
		if x.Op == "&&" {
			l := eval(x.L)
			if !truthy(l) {
				return IntV(0)
			}
			return BoolV(truthy(eval(x.R)))
		}
		if x.Op == "||" {
			l := eval(x.L)
			if truthy(l) {
				return IntV(1)
			}
			return BoolV(truthy(eval(x.R)))
		}
		l := eval(x.L)
		r := eval(x.R)
		return binop(x.Op, l, r)
	case *NCall:
		return callFunc(x)
	case *NIndex:
		v := eval(x.X)
		idx := eval(x.I)
		if v.K == KArr {
			i := int(toIntVal(idx))
			if i < 1 || i > len(*v.A) {
				panic(gpErrNC("array index out of range"))
			}
			e := (*v.A)[i-1]
			if e.K == KUndef {
				return undefinedV()
			}
			return e
		}
		panic(gpErrNC("internal error: attempt to index a scalar variable"))
	case *NSlice:
		v := eval(x.X)
		var a, b int64 = 1, math.MaxInt32
		if x.A != nil {
			a = toIntVal(eval(x.A))
		}
		if x.B != nil {
			b = toIntVal(eval(x.B))
		}
		if v.K == KArr && false {
			arr := *v.A
			if a < 1 {
				a = 1
			}
			if b > int64(len(arr)) {
				b = int64(len(arr))
			}
			var out []Value
			for i := a; i <= b; i++ {
				out = append(out, arr[i-1])
			}
			return Value{K: KArr, A: &out}
		}
		if v.K != KStr {
			panic(gpErrNC("internal error: substring range operator applied to non-STRING type"))
		}
		return StrV(substrRunes(v.S, int(a), int(b)))
	case *NCard:
		if db, ok := G.datablocks[x.Name]; ok {
			return IntV(int64(len(db)))
		}
		v, ok := lookupVar(x.Name)
		if !ok {
			panic(gpErrNC("undefined variable: " + x.Name))
		}
		if v.K == KArr {
			return IntV(int64(len(*v.A)))
		}
		if db, ok := G.datablocks[x.Name]; ok {
			return IntV(int64(len(db)))
		}
		panic(gpErrNC("cardinality of non-array"))
	case *NSum:
		a := toIntVal(eval(x.A))
		b := toIntVal(eval(x.B))
		var acc Value = IntV(0)
		fr := Frame{}
		frames = append(frames, fr)
		defer func() { frames = frames[:len(frames)-1] }()
		for i := a; i <= b; i++ {
			fr[x.Var] = IntV(i)
			acc = binop("+", acc, eval(x.X))
		}
		return acc
	case *NColumn:
		c := eval(x.X)
		return columnValue(c, false)
	}
	panic(gpErrNC("bad node"))
}

func substrRunes(s string, a, b int) string {
	r := []rune(s)
	if a < 1 {
		a = 1
	}
	if b > len(r) {
		b = len(r)
	}
	if a > b {
		return ""
	}
	return string(r[a-1 : b])
}

func toIntVal(v Value) int64 {
	switch v.K {
	case KInt:
		return v.I
	case KCmplx:
		return int64(v.R)
	case KStr:
		panic(nonNumErr())
	}
	panic(gpErrNC("undefined value"))
}

func truthy(v Value) bool {
	switch v.K {
	case KInt:
		return v.I != 0
	case KCmplx:
		return v.R != 0 || v.Im != 0
	case KStr:
		panic(nonNumErr())
	}
	return false
}

func unop(op string, v Value) Value {
	if v.K == KStr {
		panic(nonNumErr())
	}
	switch op {
	case "-":
		if v.K == KInt {
			return IntV(-v.I)
		}
		return CV(-v.R, -v.Im)
	case "+":
		return v
	case "!":
		return BoolV(!truthy(v))
	case "~":
		if v.K != KInt {
			panic(gpErrNC("~ operator requires integer operand"))
		}
		return IntV(^v.I)
	case "fact":
		if v.K != KInt {
			panic(gpErrNC("factorial (!) argument must be an integer"))
		}
		r := 1.0
		ri := int64(1)
		ok := true
		for i := int64(2); i <= v.I; i++ {
			r *= float64(i)
			if ok {
				if ri > math.MaxInt64/i {
					ok = false
				} else {
					ri *= i
				}
			}
		}
		if ok {
			return IntV(ri)
		}
		return FltV(r)
	}
	panic(gpErrNC("bad unary"))
}

func cmplxOf(v Value) complex128 {
	if v.K == KInt {
		return complex(float64(v.I), 0)
	}
	return complex(v.R, v.Im)
}
func fromC(c complex128) Value { return CV(real(c), imag(c)) }

func binop(op string, l, r Value) Value {
	if op == "." {
		if l.K != KStr || r.K != KStr {
			// numbers get converted? gnuplot errors
			ls, rs := l, r
			if ls.K != KStr && ls.IsNum() {
				ls = StrV(l.String())
			}
			if rs.K != KStr && rs.IsNum() {
				rs = StrV(r.String())
			}
			if ls.K != KStr || rs.K != KStr {
				panic(gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable"))
			}
			return StrV(ls.S + rs.S)
		}
		return StrV(l.S + r.S)
	}
	if op == "eq" || op == "ne" {
		if l.K != KStr || r.K != KStr {
			panic(gpErrNC("internal error : STRING operator applied to undefined or non-STRING variable"))
		}
		if op == "eq" {
			return BoolV(l.S == r.S)
		}
		return BoolV(l.S != r.S)
	}
	if (op == "==" || op == "!=") && l.K == KStr && r.K == KStr {
		if op == "==" {
			return BoolV(l.S == r.S)
		}
		return BoolV(l.S != r.S)
	}
	if l.K == KStr {
		l = strToNum(l)
	}
	if r.K == KStr {
		r = strToNum(r)
	}
	if l.K == KArr || r.K == KArr {
		panic(gpErrNC("non-scalar argument"))
	}
	if l.K == KInt && r.K == KInt {
		a, b := l.I, r.I
		switch op {
		case "+":
			s := a + b
			if (a >= 0) == (b >= 0) && (s >= 0) != (a >= 0) {
				return FltV(float64(a) + float64(b))
			}
			return IntV(s)
		case "-":
			s := a - b
			if (a >= 0) != (b >= 0) && (s >= 0) != (a >= 0) {
				return FltV(float64(a) - float64(b))
			}
			return IntV(s)
		case "*":
			if a != 0 && b != 0 {
				p := a * b
				if p/b != a || (a == -1 && b == math.MinInt64) || (b == -1 && a == math.MinInt64) {
					return FltV(float64(a) * float64(b))
				}
				return IntV(p)
			}
			return IntV(0)
		case "/":
			if b == 0 {
				return undefinedV()
			}
			return IntV(a / b)
		case "%":
			if b == 0 {
				return undefinedV()
			}
			return IntV(a % b)
		case "**":
			if b < 0 {
				if a == 0 {
					return undefinedV()
				}
				return FltV(math.Pow(float64(a), float64(b)))
			}
			res := int64(1)
			ok := true
			for i := int64(0); i < b; i++ {
				nr := res * a
				if a != 0 && nr/a != res {
					ok = false
					break
				}
				res = nr
			}
			if !ok {
				return FltV(math.Pow(float64(a), float64(b)))
			}
			return IntV(res)
		case "&":
			return IntV(a & b)
		case "|":
			return IntV(a | b)
		case "^":
			return IntV(a ^ b)
		case "<<":
			return IntV(int64(uint64(a) << uint64(b)))
		case ">>":
			return IntV(int64(uint64(a) >> uint64(b)))
		case "==":
			return BoolV(a == b)
		case "!=":
			return BoolV(a != b)
		case "<":
			return BoolV(a < b)
		case "<=":
			return BoolV(a <= b)
		case ">":
			return BoolV(a > b)
		case ">=":
			return BoolV(a >= b)
		}
	}
	switch op {
	case "&", "|", "^", "<<", ">>", "%":
		if op == "%" {
			// gnuplot: % requires integers; converts?
			a := toIntVal(l)
			b := toIntVal(r)
			if b == 0 {
				return undefinedV()
			}
			return IntV(a % b)
		}
		panic(gpErrNC("bitwise operator requires integer operands"))
	}
	if l.Im == 0 && r.Im == 0 {
		a := l.Real()
		b := r.Real()
		switch op {
		case "+":
			return FltV(a + b)
		case "-":
			return FltV(a - b)
		case "*":
			return FltV(a * b)
		case "/":
			if b == 0 {
				return undefinedV()
			}
			return FltV(a / b)
		case "**":
			if a == 0 && b < 0 {
				return undefinedV()
			}
			if a < 0 && b != math.Floor(b) {
				return fromC(cpow(complex(a, 0), complex(b, 0)))
			}
			if r.K == KInt {
				return FltV(math.Pow(a, b))
			}
			return FltV(math.Pow(a, b))
		case "==":
			return BoolV(a == b)
		case "!=":
			return BoolV(a != b)
		case "<":
			return BoolV(a < b)
		case "<=":
			return BoolV(a <= b)
		case ">":
			return BoolV(a > b)
		case ">=":
			return BoolV(a >= b)
		}
	}
	a := cmplxOf(l)
	b := cmplxOf(r)
	switch op {
	case "+":
		return fromC(a + b)
	case "-":
		return fromC(a - b)
	case "*":
		return fromC(a * b)
	case "/":
		if b == 0 {
			return undefinedV()
		}
		return fromC(a / b)
	case "**":
		return fromC(cpow(a, b))
	case "==":
		return BoolV(a == b)
	case "!=":
		return BoolV(a != b)
	case "<":
		return BoolV(real(a) < real(b))
	case "<=":
		return BoolV(real(a) <= real(b))
	case ">":
		return BoolV(real(a) > real(b))
	case ">=":
		return BoolV(real(a) >= real(b))
	}
	panic(gpErrNC("bad operator " + op))
}

func cpow(a, b complex128) complex128 {
	if a == 0 {
		return 0
	}
	return cexp(b * clog(a))
}

func clog(a complex128) complex128 {
	return complex(math.Log(math.Hypot(real(a), imag(a))), math.Atan2(imag(a), real(a)))
}
func cexp(a complex128) complex128 {
	e := math.Exp(real(a))
	return complex(e*math.Cos(imag(a)), e*math.Sin(imag(a)))
}

// evalTop evaluates an expression for a command; checks undefined flag.
func evalTop(n Node, pos int) Value {
	undefFlag = false
	v := eval(n)
	if undefFlag {
		undefFlag = false
		panic(gpErrAt(pos, "undefined value"))
	}
	return v
}

func lowerIdent(s string) string { return strings.ToLower(s) }

func strToNum(v Value) Value {
	t := strings.TrimSpace(v.S)
	if t != "" {
		if i, err := strconv.ParseInt(t, 10, 64); err == nil {
			return IntV(i)
		}
		if f, err := strconv.ParseFloat(t, 64); err == nil {
			return FltV(f)
		}
	}
	panic(nonNumErr())
}
