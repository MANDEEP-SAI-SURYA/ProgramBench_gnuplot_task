package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
)

type Pt struct {
	x, y, z float64
	ex      []float64
	typ     byte // 'i','o','u'
	brk     bool // marks start of new segment
	label   string
}

type Curve struct {
	title    string
	hasTitle bool
	style    string
	pts      []Pt
	isFunc   bool
	lt       int
	pt       int
	ptChar   string
	smooth   string
	cols     string
	is3D     bool
	x2, y2   bool
	fillSolid bool
	lineWidth float64
	dataBlocks [][]Pt // for 3D grids
	colHeads []string
	failed   bool
	elem     *PlotElem
}

type PlotElem struct {
	isFunc     bool
	funcExpr   Node
	funcExpr2  Node // parametric second
	fname      string
	usingNodes []Node
	usingRaw   []string
	usingStrIdx []int
	hasUsing   bool
	indexA, indexB, indexStep int
	hasIndex   bool
	indexName  string
	every      [6]int
	everySet   [6]bool
	hasEvery   bool
	title      string
	hasTitle   bool
	noTitle    bool
	titleColHead int
	style      string
	smooth     string
	lt, pt     int
	ptChar     string
	axesX2, axesY2 bool
	rangeX     *Axis
	text       string
	bins       int
	binwidth   float64
	fillSolid  bool
	lw         float64
	hasLT      bool
	xticCol    Node
	iterVar    string
	iterVal    Value
	hasRange   bool
	rmin, rmax float64
}

var lastPlotLine string
var lastPlotIs3D bool
var lastPlotToks []Token
var lastPlotStart int

func cmdReplot(ps *Parser) {
	if lastPlotToks == nil {
		panic(gpErrNC("no previous plot"))
	}
	// replot extra elements are appended
	if !ps.atEnd() {
		st := ps.peek().Start
		en := st
		for !ps.atEnd() {
			en = ps.next().End
		}
		extra := ps.line[st:en]
		base := ""
		if len(lastPlotToks) > 1 {
			base = lastPlotLine[lastPlotToks[0].Start:lastPlotToks[len(lastPlotToks)-2].End]
		}
		nl := base + ", " + extra
		toks := lex(nl)
		lastPlotToks = toks
		lastPlotLine = nl
	}
	sub := &Parser{toks: lastPlotToks, line: lastPlotLine, p: lastPlotStart}
	doPlot(sub, lastPlotIs3D)
}

func cmdPlot(ps *Parser, is3D bool) {
	// save tokens for replot
	start := ps.p
	end := ps.p
	for end < len(ps.toks) && !(ps.toks[end].K == TEnd || (ps.toks[end].K == TOp && ps.toks[end].Text == ";")) {
		end++
	}
	toks := make([]Token, 0, end-start+1)
	toks = append(toks, ps.toks[start:end]...)
	toks = append(toks, Token{K: TEnd, Start: len(ps.line)})
	lastPlotToks = toks
	lastPlotLine = ps.line
	lastPlotIs3D = is3D
	lastPlotStart = 0
	sub := &Parser{toks: toks, line: ps.line}
	ps.p = end
	doPlot(sub, is3D)
}

func axisCopy(a *Axis) *Axis {
	b := *a
	return &b
}

func doPlot(ps *Parser, is3D bool) {
	s := G.S
	// work on copies of axes (ranges given in plot cmd are temporary)
	saved := map[string]*Axis{}
	for k, v := range s.axes {
		saved[k] = axisCopy(v)
	}
	defer func() {
		for k, v := range saved {
			cur := s.axes[k]
			v.lastSet, v.lastMin, v.lastMax = cur.lastSet, cur.lastMin, cur.lastMax
			s.axes[k] = v
		}
	}()
	// leading ranges
	rangeAxes := []string{"x", "y"}
	if is3D {
		rangeAxes = []string{"x", "y", "z"}
	}
	if s.parametric && !is3D {
		rangeAxes = []string{"t", "x", "y"}
	}
	if s.parametric && is3D {
		rangeAxes = []string{"u", "v", "x", "y", "z"}
	}
	ri := 0
	for ps.isOp("[") {
		if ri >= len(rangeAxes) {
			break
		}
		ax := s.axes[rangeAxes[ri]]
		// dummy var assignment [t=a:b]
		if ps.peekN(1).K == TIdent && ps.peekN(2).K == TOp && ps.peekN(2).Text == "=" {
			ps.p++
			ps.p += 2
			ps.p--
			// rewrite: treat as range
			ps.toks[ps.p] = Token{K: TOp, Text: "[", Start: ps.toks[ps.p].Start}
		}
		parseRange(ps, ax)
		ri++
	}
	if ps.atEnd() {
		panic(ps.errHere("function to plot expected"))
	}
	var elems []*PlotElem
	for {
		if ps.is("for") {
			ps.p++
			it := parseIterSpec(ps)
			st := ps.p
			var endp int
			it.run(func() bool {
				ps.p = st
				e := parsePlotElem(ps, is3D)
				e.iterVar = it.Var
				e.iterVal = G.vars[it.Var]
				elems = append(elems, e)
				endp = ps.p
				return true
			})
			if endp == 0 {
				// empty iteration: skip element
				ps.p = st
				parsePlotElemSkip(ps, is3D)
			} else {
				ps.p = endp
			}
		} else {
			elems = append(elems, parsePlotElem(ps, is3D))
		}
		if ps.isOp(",") {
			ps.p++
			continue
		}
		break
	}
	if !ps.atEnd() {
		t := ps.peek()
		panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+t.Text))
	}
	curves := buildCurves(elems, is3D)
	if s.table {
		writeTable(curves, is3D)
		return
	}
	renderPlot(curves, is3D)
}

func parsePlotElemSkip(ps *Parser, is3D bool) {
	d := 0
	for !ps.atEnd() {
		if ps.isOp("(") || ps.isOp("[") || ps.isOp("{") {
			d++
		} else if ps.isOp(")") || ps.isOp("]") || ps.isOp("}") {
			d--
		} else if ps.isOp(",") && d == 0 {
			return
		}
		ps.p++
	}
}

func parsePlotElem(ps *Parser, is3D bool) *PlotElem {
	e := &PlotElem{lt: -1, pt: -1, indexB: -1, indexStep: 1}
	startTok := ps.p
	// local range for this element (parametric etc.)
	if ps.isOp("[") && !G.S.parametric {
		ax := newAxis("x")
		save := ps.p
		func() {
			defer func() {
				if r := recover(); r != nil {
					ps.p = save
				}
			}()
			parseRange(ps, ax)
			if !ax.autoMin && !ax.autoMax {
				e.hasRange = true
				e.rmin, e.rmax = ax.min, ax.max
			}
		}()
		startTok = ps.p
	}
	for ps.isOp("[") {
		// skip per-element ranges
		d := 0
		for {
			if ps.isOp("[") {
				d++
			} else if ps.isOp("]") {
				d--
				if d == 0 {
					ps.p++
					break
				}
			}
			ps.p++
		}
		startTok = ps.p
	}
	t := ps.peek()
	textEnd := 0
	if t.K == TStr || (t.K == TIdent && strings.HasPrefix(t.Text, "$") && !(ps.peekN(1).K == TOp && ps.peekN(1).Text == "[")) {
		ps.p++
		if t.K == TStr {
			e.fname = t.S
			if e.fname == "" {
				e.fname = lastDataFile
				e.text = "''"
			} else if e.fname == "-" {
				e.text = t.Text
			} else {
				e.text = t.Text
				if strings.HasPrefix(t.Text, "\"") {
					e.text = "'" + t.S + "'"
				}
			}
			lastDataFile = e.fname
		} else {
			e.fname = t.Text
			e.text = t.Text
		}
		textEnd = t.End
	} else if t.K == TIdent && isFuncDef(ps) {
		// inline function definition in plot
		execCommand(ps)
		if ps.isOp(",") {
			ps.p++
		}
		return parsePlotElem(ps, is3D)
	} else {
		e.isFunc = true
		e.funcExpr = ps.parseExpr()
		if G.S.parametric && !is3D && ps.isOp(",") {
			ps.p++
			e.funcExpr2 = ps.parseExpr()
		}
		e.text = ps.line[ps.toks[startTok].Start:ps.toks[ps.p-1].End]
	}
	for !ps.atEnd() && !ps.isOp(",") {
		t := ps.peek()
		w := t.Text
		if t.K != TIdent {
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+w))
		}
		switch {
		case identIs(t, "using", 1):
			ps.p++
			e.hasUsing = true
			parseUsing(ps, e)
			textEnd = ps.toks[ps.p-1].End
		case identIs(t, "index", 1):
			ps.p++
			e.hasIndex = true
			if ps.peek().K == TStr {
				e.indexName = ps.next().S
			} else {
				e.indexA = int(ps.evalNum())
				e.indexB = e.indexA
				if ps.isOp(":") {
					ps.p++
					e.indexB = int(ps.evalNum())
					if ps.isOp(":") {
						ps.p++
						e.indexStep = int(ps.evalNum())
					}
				}
			}
			textEnd = ps.toks[ps.p-1].End
		case identIs(t, "every", 2):
			ps.p++
			e.hasEvery = true
			for i := 0; i < 6; i++ {
				if ps.isOp(":") {
					ps.p++
					continue
				}
				if ps.atEnd() || ps.peek().K == TIdent || ps.isOp(",") {
					break
				}
				e.every[i] = int(ps.evalNum())
				e.everySet[i] = true
				if ps.isOp(":") {
					ps.p++
				} else {
					break
				}
			}
			textEnd = ps.toks[ps.p-1].End
		case identIs(t, "title", 1):
			ps.p++
			if ps.is("columnheader") || ps.is("columnhead") || ps.is("col") {
				ps.p++
				e.titleColHead = -1
				if ps.isOp("(") {
					ps.p++
					e.titleColHead = int(ps.evalNum())
					ps.expect(")")
				}
				break
			}
			if ps.atEnd() || ps.isOp(",") {
				panic(ps.errHere("invalid expression "))
			}
			e.title = ps.evalAny().String()
			e.hasTitle = true
		case identIs(t, "notitle", 3):
			ps.p++
			e.noTitle = true
			if ps.isStringStart() {
				ps.evalAny()
			}
		case identIs(t, "with", 1):
			ps.p++
			e.style = parseStyleName(ps)
			parseStyleOpts(ps, e)
		case identIs(t, "smooth", 1):
			ps.p++
			e.smooth = ps.next().Text
			for _, sm := range []string{"unique", "frequency", "fnormal", "cumulative", "cnormal", "csplines", "acsplines", "mcsplines", "bezier", "sbezier", "kdensity", "unwrap", "path", "zsort"} {
				if strings.HasPrefix(sm, e.smooth) {
					e.smooth = sm
					break
				}
			}
			if e.smooth == "kdensity" {
				for ps.is("bandwidth") || ps.is("period") {
					ps.p++
					ps.evalNum()
				}
			}
		case identIs(t, "axes", 2) || identIs(t, "axis", 4):
			ps.p++
			a := ps.next().Text
			e.axesX2 = strings.HasPrefix(a, "x2")
			e.axesY2 = strings.HasSuffix(a, "y2")
		case identIs(t, "bins", 3):
			ps.p++
			e.bins = G.S.samples1
			if ps.isOp("=") {
				ps.p++
				e.bins = int(ps.evalNum())
			}
			for ps.is("binrange") || ps.is("binwidth") {
				if ps.is("binwidth") {
					ps.p++
					ps.expect("=")
					e.binwidth = ps.evalNum()
				} else {
					ps.p++
					r := newAxis("bin")
					parseRange(ps, r)
				}
			}
		default:
			if parseLineOpt(ps, e) {
				continue
			}
			panic(gpErrAt(t.Start, "unexpected or unrecognized token: "+w))
		}
	}
	if !e.isFunc && textEnd > 0 {
		st := ps.toks[startTok].Start
		raw := ps.line[st:textEnd]

		e.text = raw
		if ps.toks[startTok].K == TStr && ps.toks[startTok].S == "" {
			e.text = raw
		}
	}
	return e
}

var lastDataFile string

func parseLineOpt(ps *Parser, e *PlotElem) bool {
	t := ps.peek()
	w := t.Text
	switch {
	case w == "lt" || identIs(t, "linetype", 5):
		ps.p++
		e.lt = int(ps.evalNum()) - 1
		e.hasLT = true
	case w == "ls" || identIs(t, "linestyle", 6):
		ps.p++
		e.lt = int(ps.evalNum()) - 1
		e.hasLT = true
	case w == "lw" || identIs(t, "linewidth", 5):
		ps.p++
		e.lw = ps.evalNum()
	case w == "lc" || identIs(t, "linecolor", 5) || w == "tc" || identIs(t, "textcolor", 5) || w == "fc" || identIs(t, "fillcolor", 5):
		ps.p++
		if ps.is("rgb") || ps.is("rgbcolor") {
			ps.p++
			if ps.is("variable") {
				ps.p++
			} else {
				ps.evalAny()
			}
		} else if ps.is("variable") || ps.is("palette") || ps.is("black") || ps.is("bgnd") {
			ps.p++
			if ps.is("z") || ps.is("cb") || ps.is("frac") {
				ps.p++
				if !ps.atEnd() && ps.peek().K == TNum {
					ps.evalNum()
				}
			}
		} else if ps.is("lt") || ps.is("linetype") {
			ps.p++
			ps.evalNum()
		} else {
			ps.evalAny()
		}
	case w == "pt" || identIs(t, "pointtype", 6):
		ps.p++
		if ps.peek().K == TStr {
			e.ptChar = ps.next().S
		} else {
			e.pt = int(ps.evalNum())
		}
	case w == "ps" || identIs(t, "pointsize", 6) || w == "pi" || identIs(t, "pointinterval", 6) || w == "pn" || identIs(t, "pointnumber", 6):
		ps.p++
		if ps.is("variable") {
			ps.p++
		} else {
			ps.evalNum()
		}
	case w == "dt" || identIs(t, "dashtype", 2):
		ps.p++
		if ps.isOp("(") {
			for !ps.isOp(")") {
				ps.p++
			}
			ps.p++
		} else {
			ps.evalAny()
		}
	case w == "fs" || identIs(t, "fillstyle", 4):
		ps.p++
		for !ps.atEnd() && !ps.isOp(",") {
			if ps.is("solid") {
				e.fillSolid = true
				ps.p++
				if !ps.atEnd() && ps.peek().K == TNum {
					ps.evalNum()
				}
				continue
			}
			if ps.is("empty") || ps.is("transparent") || ps.is("noborder") {
				ps.p++
				continue
			}
			if ps.is("pattern") {
				ps.p++
				if !ps.atEnd() && ps.peek().K == TNum {
					ps.evalNum()
				}
				continue
			}
			if ps.is("border") {
				ps.p++
				if ps.is("lc") || ps.is("linecolor") {
					parseLineOpt(ps, e)
				} else if !ps.atEnd() && ps.peek().K == TNum {
					ps.evalNum()
				}
				continue
			}
			break
		}
	case w == "nohidden3d" || w == "nocontours" || w == "nosurface" || w == "palette" || w == "notitle" || w == "noenhanced" || w == "enhanced" || w == "point" || w == "nopoint" || w == "left" || w == "right" || w == "center" || w == "heads" || w == "nohead" || w == "head" || w == "backhead" || w == "filled" || w == "empty" || w == "nofilled" || w == "boxed":
		ps.p++
		if w == "notitle" {
			e.noTitle = true
		}
	case w == "offset" || w == "font" || w == "rotate" || w == "size" || w == "fixed":
		ps.p++
		if w == "offset" {
			parseCoordPair(ps)
		} else if w == "rotate" {
			if ps.is("by") {
				ps.p++
				ps.evalNum()
			}
		} else if w != "fixed" {
			ps.evalAny()
		}
	default:
		return false
	}
	return true
}

func parseStyleOpts(ps *Parser, e *PlotElem) {
	if e.style == "filledcurves" {
		for ps.is("closed") || ps.is("above") || ps.is("below") || ps.is("x1") || ps.is("x2") || ps.is("y1") || ps.is("y2") || ps.is("y") || ps.is("xy") {
			ps.p++
			if ps.isOp("=") {
				ps.p++
				ps.evalNum()
			}
		}
	}
	for !ps.atEnd() && !ps.isOp(",") {
		if !parseLineOpt(ps, e) {
			return
		}
	}
}

func parseUsing(ps *Parser, e *PlotElem) {
	for {
		t := ps.peek()
		st := ps.p
		if t.K == TNum {
			ps.p++
			e.usingNodes = append(e.usingNodes, &NColumn{&NConst{t.V}})
		} else if t.K == TOp && t.Text == "(" {
			x := ps.parsePrimary()
			e.usingNodes = append(e.usingNodes, x)
		} else if t.K == TStr {
			ps.p++
			e.usingNodes = append(e.usingNodes, &NCall{"column", []Node{&NConst{StrV(t.S)}}, t.Start})
		} else if t.K == TOp && t.Text == "$" {
			x := ps.parsePrimary()
			e.usingNodes = append(e.usingNodes, x)
		} else if t.K == TIdent {
			// function call like xtic(1) or stringcolumn
			x := ps.parsePostfix()
			if c, ok := x.(*NCall); ok && (c.Name == "xticlabels" || c.Name == "xtic" || c.Name == "ytic" || c.Name == "yticlabels" || c.Name == "x2tic" || c.Name == "key" || c.Name == "x2ticlabels") {
				e.xticCol = c
				if ps.isOp(":") {
					ps.p++
					continue
				}
				break
			}
			e.usingNodes = append(e.usingNodes, x)
		} else {
			panic(ps.errHere("invalid expression "))
		}
		e.usingRaw = append(e.usingRaw, ps.line[ps.toks[st].Start:ps.toks[ps.p-1].End])
		if ps.isOp(":") {
			ps.p++
			continue
		}
		break
	}
}

// how many columns each style needs: min, max
func styleCols(style string) (int, int) {
	switch style {
	case "yerrorbars", "xerrorbars", "yerrorlines", "xerrorlines":
		return 3, 4
	case "xyerrorbars", "xyerrorlines":
		return 4, 6
	case "boxes":
		return 1, 3
	case "boxerrorbars":
		return 3, 5
	case "vectors":
		return 4, 4
	case "labels":
		return 3, 3
	case "candlesticks", "financebars":
		return 5, 6
	case "filledcurves":
		return 1, 3
	case "circles":
		return 2, 3
	}
	return 1, 2
}

func tableCols(style string, n int) string {
	switch style {
	case "yerrorbars", "yerrorlines":
		return "x y ylow yhigh"
	case "xerrorbars", "xerrorlines":
		return "x y xlow xhigh"
	case "xyerrorbars", "xyerrorlines":
		return "x y xlow xhigh ylow yhigh"
	case "boxes":
		return "x y xlow xhigh"
	case "boxerrorbars":
		return "x y xlow xhigh ylow yhigh"
	case "vectors":
		return "x y xdelta ydelta"
	case "labels":
		return "x y label"
	case "candlesticks", "financebars":
		return "x open ylow yhigh yclose"
	case "filledcurves":
		return "x y1 y2"
	case "circles":
		return "x y radius"
	}
	return "x y"
}

func buildCurves(elems []*PlotElem, is3D bool) []*Curve {
	s := G.S
	var curves []*Curve
	xa := s.axes["x"]
	// first pass: data curves
	dataXmin, dataXmax := math.Inf(1), math.Inf(-1)
	d3Has = false
	for _, e := range elems {
		c := &Curve{lt: e.lt, pt: e.pt, ptChar: e.ptChar, smooth: e.smooth, is3D: is3D, x2: e.axesX2, y2: e.axesY2, fillSolid: e.fillSolid}
		if e.style == "" {
			if e.isFunc {
				c.style = s.styleFunc
			} else {
				c.style = s.styleData
			}
		} else {
			c.style = e.style
		}
		c.isFunc = e.isFunc
		if !e.noTitle {
			if e.hasTitle {
				c.title = e.title
				c.hasTitle = e.title != ""
			} else if s.key.autotitle {
				c.title = e.text
				c.hasTitle = true
			}
		}
		if !e.isFunc {
			if e.iterVar != "" {
				frames = append(frames, Frame{e.iterVar: e.iterVal})
			}
			loadDataCurve(c, e, is3D)
			if e.iterVar != "" {
				frames = frames[:len(frames)-1]
			}
			if !is3D && (e.titleColHead != 0 || (s.key.columnhead && !e.hasTitle && !e.noTitle)) {
				col := e.titleColHead
				if col <= 0 {
					col = 2
					if len(e.usingNodes) >= 2 {
						if cc, ok := e.usingNodes[1].(*NColumn); ok {
							if k, ok := cc.X.(*NConst); ok {
								col = int(toIntVal(k.V))
							}
						}
					}
				}
				if col-1 < len(c.colHeads) && col >= 1 {
					c.title = c.colHeads[col-1]
					c.hasTitle = true
				}
			}
			for _, p := range c.pts {
				if p.typ == 'u' || p.brk && math.IsNaN(p.x) {
					continue
				}
				if p.x < dataXmin {
					dataXmin = p.x
				}
				if is3D {
					if !d3Has || p.y < d3Ymin {
						d3Ymin = p.y
					}
					if !d3Has || p.y > d3Ymax {
						d3Ymax = p.y
					}
					d3Has = true
				}
				if p.x > dataXmax {
					dataXmax = p.x
				}
				for _, ex := range c.extraX(p) {
					if ex < dataXmin {
						dataXmin = ex
					}
					if ex > dataXmax {
						dataXmax = ex
					}
				}
			}
		}
		c.elem = e
		curves = append(curves, c)
	}
	anyOK := false
	for _, c := range curves {
		if !c.failed {
			anyOK = true
		}
	}
	if !anyOK {
		panic(gpErrNC("No data in plot"))
	}
	{
		var nc []*Curve
		for _, c := range curves {
			if !c.failed {
				nc = append(nc, c)
			}
		}
		curves = nc
	}
	// determine x range for functions
	xmin, xmax := xa.min, xa.max
	if xa.autoMin {
		if dataXmin <= dataXmax {
			xmin = dataXmin
		} else {
			xmin = -10
		}
	}
	if xa.autoMax {
		if dataXmin <= dataXmax {
			xmax = dataXmax
		} else {
			xmax = 10
		}
	}
	if !xa.autoMin && !xa.autoMax && xmin > xmax {
		// reversed range given
	}
	if xa.autoMin && xa.autoMax && dataXmin > dataXmax {
		// functions only: extend to tics later
	}
	d3Xmin, d3Xmax = dataXmin, dataXmax
	for _, c := range curves {
		if c.isFunc {
			if c.elem.iterVar != "" {
				frames = append(frames, Frame{c.elem.iterVar: c.elem.iterVal})
			}
			if c.elem.hasRange {
				sampleFunction(c, c.elem, c.elem.rmin, c.elem.rmax, is3D)
			} else {
				sampleFunction(c, c.elem, xmin, xmax, is3D)
			}
			if c.elem.iterVar != "" {
				frames = frames[:len(frames)-1]
			}
		}
	}
	// apply smoothing
	for _, c := range curves {
		if c.smooth != "" && !c.isFunc {
			applySmooth(c)
		}
	}
	// mark out of range
	markRanges(curves, is3D)
	return curves
}

func (c *Curve) extraX(p Pt) []float64 {
	switch c.style {
	case "boxes", "xerrorbars", "xyerrorbars", "boxerrorbars", "xerrorlines", "xyerrorlines":
		if len(p.ex) >= 2 {
			return p.ex[:2]
		}
	}
	return nil
}

func sampleFunction(c *Curve, e *PlotElem, xmin, xmax float64, is3D bool) {
	s := G.S
	if is3D {
		sampleFunction3D(c, e)
		return
	}
	n := s.samples1
	xa := s.axes["x"]
	dummy := s.dummy1
	if s.parametric || s.polar {
		ta := s.axes["t"]
		xmin, xmax = ta.min, ta.max
		dummy = "t"
		if s.polar && ta.autoMin {
			xmin, xmax = 0, 2*math.Pi
		}
	}
	fr := Frame{}
	frames = append(frames, fr)
	defer func() { frames = frames[:len(frames)-1] }()
	logx := xa.log && !s.parametric && !s.polar
	for i := 0; i < n; i++ {
		var x float64
		if logx {
			lmin := math.Log(xmin) / math.Log(xa.base)
			lmax := math.Log(xmax) / math.Log(xa.base)
			x = math.Pow(xa.base, lmin+float64(i)*(lmax-lmin)/float64(n-1))
		} else {
			x = xmin + float64(i)*(xmax-xmin)/float64(n-1)
		}
		fr[dummy] = FltV(x)
		undefFlag = false
		v := safeEval(e.funcExpr)
		p := Pt{x: x, typ: 'i'}
		if e.funcExpr2 != nil {
			v2 := safeEval(e.funcExpr2)
			p.x = realPart(v)
			p.y = realPart(v2)
			if undefFlag || v.K == KUndef || v2.K == KUndef {
				p.typ = 'u'
			}
		} else if s.polar {
			r := realPart(v)
			th := angIn(x)
			p.x = r * math.Cos(th)
			p.y = r * math.Sin(th)
			if undefFlag || v.K == KUndef {
				p.typ = 'u'
			}
		} else {
			if v.K == KStr {
				panic(nonNumErr())
			}
			p.y = realPart(v)
			if undefFlag || v.K == KUndef || (v.K == KCmplx && math.Abs(v.Im) > s.zero) || math.IsNaN(p.y) {
				p.typ = 'u'
			}
		}
		undefFlag = false
		c.pts = append(c.pts, p)
	}
}

func realPart(v Value) float64 {
	switch v.K {
	case KInt:
		return float64(v.I)
	case KCmplx:
		return v.R
	}
	return math.NaN()
}

func safeEval(n Node) (v Value) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GPError); ok && (e.Msg == "undefined value") {
				v = Value{K: KUndef}
				return
			}
			panic(r)
		}
	}()
	return eval(n)
}

func loadDataCurve(c *Curve, e *PlotElem, is3D bool) {
	lines, err := readDataLines(e.fname)
	if err != nil {
		if ge, ok := err.(*GPError); ok {
			panic(ge)
		}
		warn("Cannot find or open file \"" + e.fname + "\"")
		c.failed = true
		return
	}
	df := parseDataFile(lines)
	minC, maxC := styleCols(c.style)
	if is3D {
		minC, maxC = 1, 3
	}
	_ = maxC
	if e.hasUsing && len(e.usingNodes) < minC && !(minC == 1) {
		panic(gpErrNC("Not enough columns for this style"))
	}
	ncols := len(e.usingNodes)
	// header handling for columnheader
	headerUsed := e.titleColHead != 0 || G.S.key.columnhead
	first := true
	rowNum := 0
	for ii, idx := range df.indexes {
		if e.hasIndex {
			if e.indexName != "" {
				continue
			}
			if ii < e.indexA || (e.indexB >= 0 && ii > e.indexB) || (ii-e.indexA)%e.indexStep != 0 {
				continue
			}
		}
		if len(c.pts) > 0 {
			c.pts = append(c.pts, Pt{brk: true, x: math.NaN()})
		}
		curIndex = ii
		for bi, blk := range idx {
			curBlock = bi
			if e.hasEvery {
				// block selection: every ::: startblock (3) : endpoint(4)? positions: pointinc:blockinc:startpoint:startblock:endpoint:endblock
				binc := 1
				if e.everySet[1] && e.every[1] > 0 {
					binc = e.every[1]
				}
				sb := 0
				if e.everySet[3] {
					sb = e.every[3]
				}
				if bi < sb || (bi-sb)%binc != 0 {
					continue
				}
				if e.everySet[5] && bi > e.every[5] {
					continue
				}
			}
			if bi > 0 && len(c.pts) > 0 && !c.pts[len(c.pts)-1].brk {
				c.pts = append(c.pts, Pt{brk: true, x: math.NaN(), typ: 'b'})
			}
			rowNum = 0
			for ri, row := range blk {
				if first && !headerUsed && rowLooksHeader(row, e) {
					headerUsed = true
				}
				if first && headerUsed {
					first = false
					hs := make([]string, len(row.fields))
					for i, f := range row.fields {
						hs[i] = strings.Trim(f, "\"")
					}
					c.colHeads = hs
					curHeader = hs
					continue
				}
				first = false
				if e.hasEvery {
					pinc := 1
					if e.everySet[0] && e.every[0] > 0 {
						pinc = e.every[0]
					}
					sp := 0
					if e.everySet[2] {
						sp = e.every[2]
					}
					if ri < sp || (ri-sp)%pinc != 0 {
						rowNum++
						continue
					}
					if e.everySet[4] && ri > e.every[4] {
						continue
					}
				}
				curRow = &row
				curRowNum = rowNum
				rowNum++
				var vals []float64
				undef := false
				missing := false
				label := ""
				if !e.hasUsing {
					n := len(row.fields)
					want := 2
					if is3D {
						want = 3
					}
					if minC > 2 {
						want = maxC
						if n < want {
							want = n
						}
						if want < minC {
							want = minC
						}
					}
					if c.style == "boxes" && n >= 3 {
						want = 3
					}
					if n == 1 && !is3D {
						vals = []float64{float64(curRowNum)}
						v, ok := parseField(row.fields[0])
						if ok == 2 {
							missing = true
						} else if ok == 0 {
							undef = true
						}
						vals = append(vals, v)
					} else if is3D && n <= 2 {
						vals = []float64{float64(curRowNum), float64(bi)}
						v, ok := parseField(row.fields[0])
						if ok == 2 {
							missing = true
						} else if ok == 0 {
							undef = true
						}
						vals = append(vals, v)
					} else {
						for k := 0; k < want && k < n; k++ {
							v, ok := parseField(row.fields[k])
							if ok == 2 {
								missing = true
							} else if ok == 0 {
								undef = true
							}
							vals = append(vals, v)
						}
						if n < want && minC > 2 {
							panic(gpErrNC("Not enough columns for this style"))
						}
					}
				} else {
					nodes := e.usingNodes
					if ncols == 1 && !is3D {
						vals = append(vals, float64(curRowNum))
					}
					if ncols == 1 && is3D {
						vals = append(vals, float64(curRowNum), float64(bi))
					}
					for k, nd := range nodes {
						undefFlag = false
						missingFlag = false
						v := safeEval(nd)
						if missingFlag {
							missing = true
						}
						if c.style == "labels" && k == 2 {
							label = v.String()
							vals = append(vals, 0)
							continue
						}
						if v.K == KStr {
							f, ok := parseNumField(v.S)
							if !ok {
								undef = true
							}
							vals = append(vals, f)
							continue
						}
						if undefFlag || v.K == KUndef {
							undef = true
							vals = append(vals, math.NaN())
							continue
						}
						vals = append(vals, realPart(v))
					}
					undefFlag = false
				}
				if missing {
					// missing data: skip point
					continue
				}
				p := Pt{typ: 'i', label: label}
				if undef || len(vals) < 2 {
					p.typ = 'u'
				}
				if len(vals) >= 1 {
					p.x = vals[0]
				}
				if len(vals) >= 2 {
					p.y = vals[1]
				}
				if is3D {
					if len(vals) >= 3 {
						p.z = vals[2]
					}
					if len(vals) > 3 {
						p.ex = vals[3:]
					}
				} else if len(vals) > 2 {
					p.ex = vals[2:]
				}
				if G.S.axes["x"].timeData && len(row.fields) > 0 && !is3D {
					fi := 0
					if e.hasUsing {
						if cc, ok := e.usingNodes[0].(*NColumn); ok {
							if k, ok := cc.X.(*NConst); ok {
								fi = int(toIntVal(k.V)) - 1
							}
						}
					}
					if fi >= 0 && fi < len(row.fields) {
						if tv, ok := strptime(G.S.timefmt, strings.Trim(row.fields[fi], "\"")); ok {
							p.x = tv
							if p.typ == 'u' && len(vals) >= 2 && !math.IsNaN(vals[1]) {
								p.typ = 'i'
							}
						}
					}
				}
				for k, v := range vals {
					if k == 0 && G.S.axes["x"].timeData {
						continue
					}
					if math.IsNaN(v) && c.style != "labels" {
						p.typ = 'u'
					}
				}
				computeExtras(c, &p)
				c.pts = append(c.pts, p)
			}
		}
	}
	curRow = nil
	if e.hasIndex && e.indexName == "" && e.indexA >= len(df.indexes) {
		panic(gpErrNC(fmt.Sprintf("index %d is out of range", e.indexA)))
	}
}

// parseField: returns value and status 1=ok 0=invalid 2=missing
func parseField(f string) (float64, int) {
	if G.S.dfMissing != "" && f == G.S.dfMissing {
		return 0, 2
	}
	v, ok := parseNumField(f)
	if !ok {
		return math.NaN(), 0
	}
	return v, 1
}

func computeExtras(c *Curve, p *Pt) {
	ex := p.ex
	switch c.style {
	case "yerrorbars", "yerrorlines":
		if len(ex) == 1 {
			p.ex = []float64{p.y - ex[0], p.y + ex[0]}
		} else if len(ex) >= 2 {
			p.ex = []float64{ex[0], ex[1]}
		}
	case "xerrorbars", "xerrorlines":
		if len(ex) == 1 {
			p.ex = []float64{p.x - ex[0], p.x + ex[0]}
		} else if len(ex) >= 2 {
			p.ex = []float64{ex[0], ex[1]}
		}
	case "xyerrorbars", "xyerrorlines":
		if len(ex) == 2 {
			p.ex = []float64{p.x - ex[0], p.x + ex[0], p.y - ex[1], p.y + ex[1]}
		} else if len(ex) >= 4 {
			p.ex = []float64{ex[0], ex[1], ex[2], ex[3]}
		}
	case "boxes":
		if len(ex) >= 1 {
			p.ex = []float64{p.x - ex[0]/2, p.x + ex[0]/2}
		} else {
			p.ex = nil // computed later
		}
	}
}

func markRanges(curves []*Curve, is3D bool) {
	s := G.S
	xa, ya := s.axes["x"], s.axes["y"]
	// boxes default widths
	for _, c := range curves {
		if c.style == "boxes" {
			fixBoxWidths(c)
		}
	}
	for _, c := range curves {
		for i := range c.pts {
			p := &c.pts[i]
			if p.brk || p.typ == 'u' {
				continue
			}
			out := false
			if !xa.autoMin || !xa.autoMax {
				lo, hi := xa.min, xa.max
				if lo > hi {
					lo, hi = hi, lo
				}
				if (!xa.autoMin && p.x < lo && !xa.reverse) || (!xa.autoMax && p.x > hi && !xa.reverse) {
					out = true
				}
				if xa.reverse || xa.min > xa.max {
					if (!xa.autoMin && !xa.autoMax) && (p.x < lo || p.x > hi) {
						out = true
					}
				}
			}
			if !ya.autoMin || !ya.autoMax {
				lo, hi := ya.min, ya.max
				if lo > hi {
					lo, hi = hi, lo
				}
				if (!ya.autoMin && p.y < lo) || (!ya.autoMax && p.y > hi) {
					out = true
				}
			}
			if is3D {
				za := s.axes["z"]
				if (!za.autoMin && p.z < za.min) || (!za.autoMax && p.z > za.max) {
					out = true
				}
			}
			if out {
				p.typ = 'o'
			}
		}
	}
}

func fixBoxWidths(c *Curve) {
	s := G.S
	n := len(c.pts)
	for i := range c.pts {
		p := &c.pts[i]
		if p.brk || len(p.ex) >= 2 {
			continue
		}
		var w float64
		if s.boxwidth > 0 && !s.boxwidthRel {
			w = s.boxwidth
		} else {
			// auto: half distance to neighbours
			var dl, dr float64 = -1, -1
			if i > 0 && !c.pts[i-1].brk {
				dl = p.x - c.pts[i-1].x
			}
			if i+1 < n && !c.pts[i+1].brk {
				dr = c.pts[i+1].x - p.x
			}
			if dl < 0 && dr < 0 {
				w = 1
			} else if dl < 0 {
				w = dr
			} else if dr < 0 {
				w = dl
			} else {
				w = (dl + dr) / 2
			}
			if s.boxwidth > 0 && s.boxwidthRel {
				w *= s.boxwidth
			}
		}
		p.ex = []float64{p.x - w/2, p.x + w/2}
	}
}

func fmtTab(v float64) string {
	return cfmtFloat(v, 'g', 6, false, false, true, false, 0, false)
}

func writeTable(curves []*Curve, is3D bool) {
	var b strings.Builder
	for ci, c := range curves {
		npts := len(c.pts)
		if is3D {
			fmt.Fprintf(&b, "\n# Surface %d of %d surfaces\n", ci, len(curves))
			_ = npts
			writeTable3D(&b, c)
			continue
		}
		fmt.Fprintf(&b, "\n# Curve %d of %d, %d points\n", ci, len(curves), npts)
		if c.hasTitle {
			fmt.Fprintf(&b, "# Curve title: \"%s\"\n", c.title)
		}
		cols := tableCols(c.style, 0)
		fmt.Fprintf(&b, "# %s type\n", cols)
		for _, p := range c.pts {
			if p.brk {
				b.WriteString("\n")
				continue
			}
			x, y := p.x, p.y
			if p.typ == 'u' {
				x, y = 0, 0
			}
			if c.style == "labels" {
				fmt.Fprintf(&b, "%s %s %s\n", fmtTab(x), fmtTab(y), p.label)
				continue
			}
			if G.S.axes["x"].timeData {
				b.WriteString("\"" + strftime(G.S.timefmt, x) + "\"")
			} else {
				b.WriteString(fmtTab(x))
			}
			b.WriteString(" ")
			b.WriteString(fmtTab(y))
			b.WriteString(" ")
			ncol := strings.Count(cols, " ") - 1
			for k := 0; k < ncol; k++ {
				v := 0.0
				if k < len(p.ex) {
					v = p.ex[k]
				}
				b.WriteString(fmtTab(v))
				b.WriteString(" ")
			}
			b.WriteString(" ")
			b.WriteByte(p.typ)
			b.WriteString("\n")
		}
		b.WriteString("\n")
	}
	tableOut(b.String())
}

func tableOut(s string) {
	if G.S.tableDB != "" {
		lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
		G.datablocks[G.S.tableDB] = append(G.datablocks[G.S.tableDB], lines...)
		return
	}
	if G.S.tableFile != "" {
		f, err := os.OpenFile(G.S.tableFile, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
		if err == nil {
			f.WriteString(s)
			f.Close()
		}
		return
	}
	outWriter().WriteString(s)
}

func closeTable() {
	G.S.table = false
	G.S.tableFile = ""
	G.S.tableDB = ""
}

// ---------- smoothing -------------

func splitSegments(pts []Pt) [][]Pt {
	var out [][]Pt
	var cur []Pt
	for _, p := range pts {
		if p.brk {
			if len(cur) > 0 {
				out = append(out, cur)
			}
			cur = nil
			continue
		}
		if p.typ == 'u' {
			continue
		}
		cur = append(cur, p)
	}
	if len(cur) > 0 {
		out = append(out, cur)
	}
	return out
}

func applySmooth(c *Curve) {
	segs := splitSegments(c.pts)
	var out []Pt
	for si, seg := range segs {
		if si > 0 {
			out = append(out, Pt{brk: true})
		}
		sort.SliceStable(seg, func(i, j int) bool { return seg[i].x < seg[j].x })
		var res []Pt
		switch c.smooth {
		case "unique", "frequency", "fnormal", "cumulative", "cnormal":
			// merge equal x
			var xs, ys []float64
			var cnt []int
			for _, p := range seg {
				if len(xs) > 0 && xs[len(xs)-1] == p.x {
					ys[len(ys)-1] += p.y
					cnt[len(cnt)-1]++
				} else {
					xs = append(xs, p.x)
					ys = append(ys, p.y)
					cnt = append(cnt, 1)
				}
			}
			if c.smooth == "unique" {
				for i := range xs {
					ys[i] /= float64(cnt[i])
				}
			}
			total := 0.0
			for _, y := range ys {
				total += y
			}
			acc := 0.0
			for i := range xs {
				y := ys[i]
				switch c.smooth {
				case "cumulative":
					acc += y
					y = acc
				case "cnormal":
					acc += y
					y = acc / total
				case "fnormal":
					y = y / total
				}
				res = append(res, Pt{x: xs[i], y: y, typ: 'i'})
			}
		case "csplines", "acsplines", "mcsplines", "bezier", "sbezier":
			res = smoothCurve(c.smooth, seg)
		case "kdensity":
			res = kdensity(seg)
		default:
			res = seg
		}
		out = append(out, res...)
	}
	c.pts = out
}

func uniqueXY(seg []Pt) ([]float64, []float64, []float64) {
	var xs, ys, ws []float64
	cnt := []float64{}
	for _, p := range seg {
		w := 1.0
		if len(p.ex) > 0 {
			w = p.ex[0]
		}
		if len(xs) > 0 && xs[len(xs)-1] == p.x {
			ys[len(ys)-1] += p.y
			cnt[len(cnt)-1]++
			ws[len(ws)-1] += w
		} else {
			xs = append(xs, p.x)
			ys = append(ys, p.y)
			cnt = append(cnt, 1)
			ws = append(ws, w)
		}
	}
	for i := range ys {
		ys[i] /= cnt[i]
	}
	return xs, ys, ws
}

func smoothCurve(kind string, seg []Pt) []Pt {
	n := G.S.samples1
	xs, ys, _ := uniqueXY(seg)
	if kind == "bezier" || kind == "sbezier" {
		xs = nil
		ys = nil
		for _, p := range seg {
			xs = append(xs, p.x)
			ys = append(ys, p.y)
		}
		if kind == "sbezier" {
			xs, ys, _ = uniqueXY(seg)
		}
	}
	m := len(xs)
	if m == 0 {
		return nil
	}
	var res []Pt
	xmin, xmax := xs[0], xs[m-1]
	switch kind {
	case "csplines", "acsplines":
		if m < 3 {
			return seg
		}
		y2 := naturalSpline(xs, ys)
		for i := 0; i < n; i++ {
			x := xmin + float64(i)*(xmax-xmin)/float64(n-1)
			res = append(res, Pt{x: x, y: splineEval(xs, ys, y2, x), typ: 'i'})
		}
	case "mcsplines":
		res = mcspline(xs, ys, n)
	case "bezier", "sbezier":
		for i := 0; i < n; i++ {
			t := float64(i) / float64(n-1)
			bx, by := bezier(xs, ys, t)
			res = append(res, Pt{x: bx, y: by, typ: 'i'})
		}
	}
	return res
}

func naturalSpline(x, y []float64) []float64 {
	n := len(x)
	y2 := make([]float64, n)
	u := make([]float64, n)
	for i := 1; i < n-1; i++ {
		sig := (x[i] - x[i-1]) / (x[i+1] - x[i-1])
		p := sig*y2[i-1] + 2
		y2[i] = (sig - 1) / p
		u[i] = (y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1])
		u[i] = (6*u[i]/(x[i+1]-x[i-1]) - sig*u[i-1]) / p
	}
	y2[n-1] = 0
	for k := n - 2; k >= 0; k-- {
		y2[k] = y2[k]*y2[k+1] + u[k]
	}
	return y2
}

func splineEval(xa, ya, y2a []float64, x float64) float64 {
	n := len(xa)
	klo, khi := 0, n-1
	for khi-klo > 1 {
		k := (khi + klo) >> 1
		if xa[k] > x {
			khi = k
		} else {
			klo = k
		}
	}
	h := xa[khi] - xa[klo]
	a := (xa[khi] - x) / h
	b := (x - xa[klo]) / h
	return a*ya[klo] + b*ya[khi] + ((a*a*a-a)*y2a[klo]+(b*b*b-b)*y2a[khi])*(h*h)/6
}

func mcspline(xs, ys []float64, n int) []Pt {
	m := len(xs)
	if m < 2 {
		return nil
	}
	d := make([]float64, m-1)
	for i := 0; i < m-1; i++ {
		d[i] = (ys[i+1] - ys[i]) / (xs[i+1] - xs[i])
	}
	t := make([]float64, m)
	t[0] = d[0]
	t[m-1] = d[m-2]
	for i := 1; i < m-1; i++ {
		if d[i-1]*d[i] <= 0 {
			t[i] = 0
		} else {
			t[i] = (d[i-1] + d[i]) / 2
		}
	}
	for i := 0; i < m-1; i++ {
		if d[i] == 0 {
			t[i], t[i+1] = 0, 0
			continue
		}
		a := t[i] / d[i]
		b := t[i+1] / d[i]
		if a*a+b*b > 9 {
			tau := 3 / math.Sqrt(a*a+b*b)
			t[i] = tau * a * d[i]
			t[i+1] = tau * b * d[i]
		}
	}
	var res []Pt
	xmin, xmax := xs[0], xs[m-1]
	for k := 0; k < n; k++ {
		x := xmin + float64(k)*(xmax-xmin)/float64(n-1)
		i := 0
		for i < m-2 && x > xs[i+1] {
			i++
		}
		h := xs[i+1] - xs[i]
		s := (x - xs[i]) / h
		h00 := 2*s*s*s - 3*s*s + 1
		h10 := s*s*s - 2*s*s + s
		h01 := -2*s*s*s + 3*s*s
		h11 := s*s*s - s*s
		y := h00*ys[i] + h10*h*t[i] + h01*ys[i+1] + h11*h*t[i+1]
		res = append(res, Pt{x: x, y: y, typ: 'i'})
	}
	return res
}

func bezier(xs, ys []float64, t float64) (float64, float64) {
	n := len(xs) - 1
	bx, by := 0.0, 0.0
	for i := 0; i <= n; i++ {
		c := binom(n, i) * math.Pow(t, float64(i)) * math.Pow(1-t, float64(n-i))
		bx += c * xs[i]
		by += c * ys[i]
	}
	return bx, by
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func kdensity(seg []Pt) []Pt {
	n := G.S.samples1
	m := len(seg)
	if m == 0 {
		return nil
	}
	// bandwidth: default from gnuplot doc: sigma * (4/3N)^(1/5)
	mean, sum2 := 0.0, 0.0
	wsum := 0.0
	for _, p := range seg {
		mean += p.x
	}
	mean /= float64(m)
	for _, p := range seg {
		sum2 += (p.x - mean) * (p.x - mean)
		wsum += p.y
	}
	sigma := math.Sqrt(sum2 / float64(m-1))
	bw := sigma * math.Pow(4.0/(3.0*float64(m)), 0.2)
	if bw == 0 {
		bw = 1
	}
	xmin, xmax := seg[0].x, seg[m-1].x
	var res []Pt
	for i := 0; i < n; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(n-1)
		y := 0.0
		for _, p := range seg {
			z := (x - p.x) / bw
			y += p.y * math.Exp(-0.5*z*z) / (bw * math.Sqrt(2*math.Pi))
		}
		res = append(res, Pt{x: x, y: y, typ: 'i'})
	}
	return res
}

var d3Has bool
var d3Ymin, d3Ymax, d3Xmin, d3Xmax float64

func sampleFunction3D(c *Curve, e *PlotElem) {
	s := G.S
	xa, ya := s.axes["x"], s.axes["y"]
	xmin, xmax := xa.min, xa.max
	if xa.autoMin {
		xmin = -10
		if d3Has {
			xmin = d3Xmin
		}
	}
	if xa.autoMax {
		xmax = 10
		if d3Has {
			xmax = d3Xmax
		}
	}
	ymin, ymax := ya.min, ya.max
	if ya.autoMin {
		ymin = -10
		if d3Has {
			ymin = d3Ymin
		}
	}
	if ya.autoMax {
		ymax = 10
		if d3Has {
			ymax = d3Ymax
		}
	}
	fr := Frame{}
	frames = append(frames, fr)
	defer func() { frames = frames[:len(frames)-1] }()
	n1 := s.samples1
	n2 := s.iso2
	for iy := 0; iy < n2; iy++ {
		y := ymin + float64(iy)*(ymax-ymin)/float64(n2-1)
		var blk []Pt
		for ix := 0; ix < n1; ix++ {
			x := xmin + float64(ix)*(xmax-xmin)/float64(n1-1)
			fr[s.dummy1] = FltV(x)
			fr[s.dummy2] = FltV(y)
			undefFlag = false
			v := safeEval(e.funcExpr)
			p := Pt{x: x, y: y, z: realPart(v), typ: 'i'}
			if undefFlag || v.K == KUndef || math.IsNaN(p.z) {
				p.typ = 'u'
			}
			undefFlag = false
			blk = append(blk, p)
		}
		c.dataBlocks = append(c.dataBlocks, blk)
	}
}

func writeTable3D(b *strings.Builder, c *Curve) {
	b.WriteString("\n")
	if c.hasTitle {
		fmt.Fprintf(b, "# Curve title: \"%s\"\n", c.title)
	}
	blocks := c.dataBlocks
	if !c.isFunc {
		blocks = nil
		var cur []Pt
		for _, p := range c.pts {
			if p.brk {
				if len(cur) > 0 {
					blocks = append(blocks, cur)
				}
				cur = nil
				continue
			}
			cur = append(cur, p)
		}
		if len(cur) > 0 {
			blocks = append(blocks, cur)
		}
		for i, j := 0, len(blocks)-1; i < j; i, j = i+1, j-1 {
			blocks[i], blocks[j] = blocks[j], blocks[i]
		}
	}
	for i, blk := range blocks {
		fmt.Fprintf(b, "\n# IsoCurve %d, %d points\n# x y z type\n", i, len(blk))
		for _, p := range blk {
			x, y, z := p.x, p.y, p.z
			fmt.Fprintf(b, "%s %s %s %c\n", fmtTab(x), fmtTab(y), fmtTab(z), p.typ)
		}
	}
	b.WriteString("\n")
}

func rowLooksHeader(row DataRow, e *PlotElem) bool {
	// first row with non-numeric entries in the columns that are used
	cols := []int{}
	if e.hasUsing {
		for _, nd := range e.usingNodes {
			if cc, ok := nd.(*NColumn); ok {
				if k, ok := cc.X.(*NConst); ok {
					cols = append(cols, int(toIntVal(k.V)))
				}
			}
			if cc, ok := nd.(*NCall); ok && cc.Name == "column" && len(cc.Args) == 1 {
				if k, ok := cc.Args[0].(*NConst); ok && k.V.K == KStr {
					return true
				}
			}
		}
	} else {
		cols = []int{1, 2}
	}
	if G.S.axes["x"].timeData {
		return false
	}
	for _, c := range cols {
		if c >= 1 && c <= len(row.fields) {
			f := row.fields[c-1]
			if G.S.dfMissing != "" && f == G.S.dfMissing {
				continue
			}
			if _, ok := parseNumField(f); !ok {
				return true
			}
		}
	}
	return false
}
