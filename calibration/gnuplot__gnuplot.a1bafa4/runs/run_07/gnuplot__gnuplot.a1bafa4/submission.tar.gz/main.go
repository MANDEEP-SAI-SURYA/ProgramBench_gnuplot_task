package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
)

type Source struct {
	Name    string
	Kind    int // 0 file, 1 -e, 2 stdin
	Line    int
	inBlock int
}

const (
	SrcFile = iota
	SrcE
	SrcStdin
)

var stdout *bufio.Writer
var stderr = os.Stderr

type exitReq struct{ code int }

func flushAll() {
	stdout.Flush()
	if G != nil && G.printFile != nil {
		G.printFile.Flush()
	}
}

func writeErr(s string) {
	stdout.Flush()
	if G.printFile == nil {
		G.flushPrint()
	}
	os.Stderr.WriteString(s)
}

func main() {
	stdout = bufio.NewWriterSize(os.Stdout, 65536)
	initGlobals()
	code := run(os.Args[1:])
	finishOutput()
	flushAll()
	os.Exit(code)
}

func run(args []string) (code int) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(exitReq); ok {
				code = e.code
				return
			}
			panic(r)
		}
	}()
	didSomething := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			stdout.WriteString("gnuplot 5.4 patchlevel 9\n")
			return 0
		case a == "-h" || a == "--help":
			stdout.WriteString("Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\ngnuplot 5.4 patchlevel 9\n")
			return 0
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings" || a == "--default":
		case a == "-e":
			i++
			if i >= len(args) {
				writeErr("-e requires an argument\n")
				return 1
			}
			didSomething = true
			src := &Source{Name: "", Kind: SrcE}
			if !runString(args[i], src) {
				return 1
			}
		case a == "-c":
			i++
			if i >= len(args) {
				return 1
			}
			didSomething = true
			fn := args[i]
			callArgs := args[i+1:]
			G.setCallArgs(fn, callArgs)
			if !runFileTop(fn) {
				return 1
			}
			return 0
		case a == "-":
			didSomething = true
			runStdin()
		case strings.HasPrefix(a, "-") && len(a) > 1:
			writeErr("unrecognized option " + a + "\n")
		default:
			didSomething = true
			if !runFileTop(a) {
				return 1
			}
		}
	}
	if !didSomething {
		runStdin()
	}
	if G.stdinErr {
		return 1
	}
	return 0
}

func runFileTop(fn string) bool {
	data, err := os.ReadFile(fn)
	if err != nil {
		writeErr("line 0: Cannot load input from '" + fn + "'\n\n")
		return false
	}
	src := &Source{Name: fn, Kind: SrcFile}
	if _, ok := G.vars["ARGC"]; !ok {
		G.setCallArgs(fn, nil)
	}
	return runText(string(data), src)
}

func runStdin() {
	data, _ := io.ReadAll(os.Stdin)
	src := &Source{Name: "", Kind: SrcStdin}
	runText(string(data), src)
}

// splitLogical splits text into logical lines; returns list of (line, startLineNo, endLineNo)
type logLine struct {
	text       string
	start, end int
}

func braceDepth(s string) int {
	d := 0
	inS := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inS != 0 {
			if c == '\\' && inS == '"' {
				i++
				continue
			}
			if c == inS {
				inS = 0
			}
			continue
		}
		switch c {
		case '"', '\'':
			inS = c
		case '#':
			// comment to end of physical line
			j := strings.IndexByte(s[i:], '\n')
			if j < 0 {
				return d
			}
			i += j
		case '{':
			d++
		case '}':
			d--
		}
	}
	return d
}

func splitLogical(text string) []logLine {
	lines := strings.Split(text, "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	var out []logLine
	i := 0
	for i < len(lines) {
		start := i + 1
		cur := strings.TrimRight(lines[i], "\r")
		i++
		for {
			for strings.HasSuffix(cur, "\\") && i < len(lines) {
				cur = cur[:len(cur)-1] + strings.TrimRight(lines[i], "\r")
				i++
			}
			if braceDepth(cur) > 0 && i < len(lines) {
				cur = cur + "\n" + strings.TrimRight(lines[i], "\r")
				i++
				continue
			}
			break
		}
		out = append(out, logLine{cur, start, i})
	}
	return out
}

// runText executes text from a source. returns false on fatal error.
func runText(text string, src *Source) bool {
	ll := splitLogical(text)
	G.srcStack = append(G.srcStack, src)
	defer func() { G.srcStack = G.srcStack[:len(G.srcStack)-1] }()
	for li := 0; li < len(ll); li++ {
		l := ll[li]
		// datablock definition
		src.Line = l.start
		if name, eod, ok := isDatablockStart(l.text); ok {
			var lines []string
			j := li + 1
			for ; j < len(ll); j++ {
				if strings.TrimRight(ll[j].text, " \t") == eod {
					break
				}
				lines = append(lines, ll[j].text)
			}
			G.datablocks[name] = lines
			li = j
			continue
		}
		inlineSrc = ll
		inlineIdx = li + 1
		ok := execLineSafe(l.text, src, l.start)
		li = inlineIdx - 1
		if !ok {
			if src.Kind == SrcStdin {
				G.stdinErr = true
				continue
			}
			return false
		}
	}
	return true
}

func isDatablockStart(s string) (string, string, bool) {
	t := strings.TrimSpace(s)
	if !strings.HasPrefix(t, "$") {
		return "", "", false
	}
	i := strings.Index(t, "<<")
	if i < 0 {
		return "", "", false
	}
	name := strings.TrimSpace(t[:i])
	for _, c := range name[1:] {
		if !(c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
			return "", "", false
		}
	}
	eod := strings.TrimSpace(t[i+2:])
	if eod == "" {
		return "", "", false
	}
	return name, eod, true
}

func runString(s string, src *Source) bool {
	return runText(s, src)
}

func execLineSafe(line string, src *Source, lineNo int) (ok bool) {
	defer func() {
		if r := recover(); r != nil {
			if _, isA := r.(abortErr); isA {
				ok = false
				return
			}
			if e, isE := r.(*GPError); isE {
				if src.Kind == SrcFile {
					e.srcName = src.Name
				}
				e.line = G.curLine
				if G.curText != "" {
					line = G.curText
				}
				reportError(e, line, src)
				ok = false
				return
			}
			if _, isB := r.(loopCtl); isB {
				ok = true
				return
			}
			if _, isX := r.(exitReq); isX {
				panic(r)
			}
			e := gpErrNC(fmt.Sprint("internal error: ", r))
			if src.Kind == SrcFile {
				e.srcName = src.Name
			}
			e.line = G.curLine
			reportError(e, line, src)
			ok = false
		}
	}()
	G.curLine = lineNo
	G.curText = ""
	execLine(line)
	return true
}

func reportError(e *GPError, line string, src *Source) {
	var b strings.Builder
	prefix := ""
	if src.Kind == SrcStdin {
		prefix = "         "
	}
	showCaret := e.HasPos && e.Pos >= 0 && !e.inBlock
	if showCaret {
		b.WriteString("\n")
		if src.Kind == SrcStdin {
			b.WriteString("gnuplot> " + line + "\n")
			b.WriteString(strings.Repeat(" ", e.Pos+9) + "^\n")
		} else {
			b.WriteString(line + "\n")
			b.WriteString(strings.Repeat(" ", e.Pos) + "^\n")
		}
	}
	b.WriteString(prefix)
	if e.srcName != "" {
		fmt.Fprintf(&b, "\"%s\" line %d: ", e.srcName, e.line)
	} else {
		b.WriteString("line 0: ")
	}
	b.WriteString(e.Msg + "\n\n")
	writeErr(b.String())
}

var inlineSrc []logLine
var inlineIdx int

func readInlineData() []string {
	var out []string
	for inlineIdx < len(inlineSrc) {
		t := inlineSrc[inlineIdx].text
		inlineIdx++
		if strings.TrimSpace(t) == "e" {
			break
		}
		out = append(out, t)
	}
	return out
}
