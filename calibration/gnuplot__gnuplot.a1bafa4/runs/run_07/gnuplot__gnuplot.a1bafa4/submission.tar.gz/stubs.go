package main

import (
	"math"
)

func nanVal() float64 { return math.NaN() }

