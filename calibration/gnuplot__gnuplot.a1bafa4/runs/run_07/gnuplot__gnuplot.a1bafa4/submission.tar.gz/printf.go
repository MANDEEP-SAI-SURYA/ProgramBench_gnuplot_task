package main

import (
	"math"
	"strconv"
	"strings"
)

// cfmtFloat formats like C printf for e,f,g,E,F,G.
func cfmtFloat(f float64, verb byte, prec int, minus, plus, space, alt bool, width int, zero bool) string {
	var body string
	neg := math.Signbit(f)
	if math.IsInf(f, 0) || math.IsNaN(f) {
		if math.IsNaN(f) {
			body = "nan"
		} else {
			body = "inf"
		}
		if verb == 'E' || verb == 'F' || verb == 'G' {
			body = strings.ToUpper(body)
		}
		zero = false
	} else {
		a := math.Abs(f)
		if prec < 0 {
			prec = 6
		}
		lv := verb | 0x20
		switch lv {
		case 'f':
			body = strconv.FormatFloat(a, 'f', prec, 64)
			if alt && prec == 0 {
				body += "."
			}
		case 'e':
			body = strconv.FormatFloat(a, 'e', prec, 64)
			if alt && prec == 0 {
				i := strings.IndexByte(body, 'e')
				body = body[:i] + "." + body[i:]
			}
		case 'g':
			p := prec
			if p == 0 {
				p = 1
			}
			if a == 0 {
				if alt {
					body = "0." + strings.Repeat("0", p-1)
				} else {
					body = "0"
				}
				break
			}
			es := strconv.FormatFloat(a, 'e', p-1, 64)
			ei := strings.IndexByte(es, 'e')
			x, _ := strconv.Atoi(es[ei+1:])
			if x < -4 || x >= p {
				mant := es[:ei]
				if !alt && strings.Contains(mant, ".") {
					mant = strings.TrimRight(mant, "0")
					mant = strings.TrimSuffix(mant, ".")
				}
				body = mant + es[ei:]
			} else {
				body = strconv.FormatFloat(a, 'f', p-1-x, 64)
				if !alt && strings.Contains(body, ".") {
					body = strings.TrimRight(body, "0")
					body = strings.TrimSuffix(body, ".")
				}
			}
		}
		if verb == 'E' || verb == 'G' {
			body = strings.ToUpper(body)
		}
	}
	sign := ""
	if neg {
		sign = "-"
	} else if plus {
		sign = "+"
	} else if space {
		sign = " "
	}
	return padNum(sign, body, width, minus, zero)
}

func padNum(sign, body string, width int, minus, zero bool) string {
	n := len(sign) + len(body)
	if n >= width {
		return sign + body
	}
	if minus {
		return sign + body + strings.Repeat(" ", width-n)
	}
	if zero {
		return sign + strings.Repeat("0", width-n) + body
	}
	return strings.Repeat(" ", width-n) + sign + body
}

func padStr(s string, width int, minus bool) string {
	n := len([]rune(s))
	if n >= width {
		return s
	}
	if minus {
		return s + strings.Repeat(" ", width-n)
	}
	return strings.Repeat(" ", width-n) + s
}

type fmtSpec struct {
	minus, plus, space, alt, zero bool
	width, prec                   int
	verb                          byte
	lenmod                        string
}

// parseSpec parses a spec starting at s[i]=='%'. returns spec and end index (exclusive).
func parseSpec(s string, i int) (fmtSpec, int) {
	sp := fmtSpec{prec: -1}
	j := i + 1
	for j < len(s) {
		c := s[j]
		if c == '-' {
			sp.minus = true
		} else if c == '+' {
			sp.plus = true
		} else if c == ' ' {
			sp.space = true
		} else if c == '#' {
			sp.alt = true
		} else if c == '0' {
			sp.zero = true
		} else if c == '\'' {
		} else {
			break
		}
		j++
	}
	for j < len(s) && s[j] >= '0' && s[j] <= '9' {
		sp.width = sp.width*10 + int(s[j]-'0')
		j++
	}
	if j < len(s) && s[j] == '.' {
		j++
		sp.prec = 0
		for j < len(s) && s[j] >= '0' && s[j] <= '9' {
			sp.prec = sp.prec*10 + int(s[j]-'0')
			j++
		}
	}
	for j+1 < len(s) && strings.IndexByte("hlqjz", s[j]) >= 0 && strings.IndexByte("hlqjzdiouxXeEfgGcs", s[j+1]) >= 0 {
		sp.lenmod += string(s[j])
		j++
	}
	if j < len(s) {
		sp.verb = s[j]
		j++
	}
	return sp, j
}

func fmtInt(sp fmtSpec, v int64) string {
	var body string
	neg := false
	switch sp.verb {
	case 'd', 'i':
		if v < 0 {
			neg = true
			body = strconv.FormatUint(uint64(-v), 10)
		} else {
			body = strconv.FormatInt(v, 10)
		}
	case 'u':
		body = strconv.FormatUint(uint64(v), 10)
	case 'x':
		body = strconv.FormatUint(uint64(v), 16)
	case 'X':
		body = strings.ToUpper(strconv.FormatUint(uint64(v), 16))
	case 'o':
		body = strconv.FormatUint(uint64(v), 8)
	}
	if sp.lenmod == "" && sp.verb != 'd' && sp.verb != 'i' {
		// C int is 32 bit
	}
	if sp.prec >= 0 {
		if len(body) < sp.prec {
			body = strings.Repeat("0", sp.prec-len(body)) + body
		}
		if sp.prec == 0 && v == 0 {
			body = ""
		}
		sp.zero = false
	}
	if sp.alt {
		if sp.verb == 'x' && v != 0 {
			body = "0x" + body
		} else if sp.verb == 'X' && v != 0 {
			body = "0X" + body
		} else if sp.verb == 'o' && !strings.HasPrefix(body, "0") {
			body = "0" + body
		}
	}
	sign := ""
	if neg {
		sign = "-"
	} else if sp.plus && (sp.verb == 'd' || sp.verb == 'i') {
		sign = "+"
	} else if sp.space && (sp.verb == 'd' || sp.verb == 'i') {
		sign = " "
	}
	return padNum(sign, body, sp.width, sp.minus, sp.zero)
}

func toInt64(f float64) int64 {
	if math.IsNaN(f) || math.IsInf(f, 0) || f >= 9.3e18 || f <= -9.3e18 {
		return math.MinInt64
	}
	return int64(f)
}

// gpSprintf implements gnuplot sprintf
func gpSprintf(args []Value) string {
	if len(args) == 0 {
		panic(gpErrNC("sprintf: no format"))
	}
	if args[0].K != KStr {
		panic(gpErrNC("First parameter to sprintf must be a format string"))
	}
	f := args[0].S
	var out strings.Builder
	ai := 1
	for i := 0; i < len(f); {
		c := f[i]
		if c != '%' {
			out.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			out.WriteByte('%')
			i += 2
			continue
		}
		sp, j := parseSpec(f, i)
		i = j
		if ai >= len(args) {
			panic(gpErrNC("not enough arguments for this format"))
		}
		a := args[ai]
		ai++
		switch sp.verb {
		case 'd', 'i', 'u', 'x', 'X', 'o', 'c':
			if a.K == KStr {
				panic(gpErrNC("f_sprintf: attempt to print string value with numeric format"))
			}
			var iv int64
			if a.K == KInt {
				iv = a.I
			} else {
				iv = toInt64(a.R)
			}
			if sp.verb == 'c' {
				out.WriteString(padStr(string(rune(byte(iv))), sp.width, sp.minus))
			} else {
				if sp.lenmod == "" {
					// gnuplot passes int64 with "l" length so full width
				}
				out.WriteString(fmtInt(sp, iv))
			}
		case 'e', 'E', 'f', 'F', 'g', 'G':
			if a.K == KStr {
				panic(gpErrNC("f_sprintf: attempt to print string value with numeric format"))
			}
			out.WriteString(cfmtFloat(a.Real(), sp.verb, sp.prec, sp.minus, sp.plus, sp.space, sp.alt, sp.width, sp.zero))
		case 's':
			if a.K != KStr {
				panic(gpErrNC("f_sprintf: attempt to print numeric value with string format"))
			}
			s := a.S
			if sp.prec >= 0 && sp.prec < len(s) {
				s = s[:sp.prec]
			}
			out.WriteString(padStr(s, sp.width, sp.minus))
		default:
			panic(gpErrNC("bad format character"))
		}
	}
	return out.String()
}

var siPrefixes = "yzafpnum kMGTPEZY"

// gprintf implements gnuplot's gprintf for a value
func gprintf(format string, x float64) string {
	return gprintfLog(format, x, 1)
}

func gprintfLog(format string, x float64, logbase float64) string {
	var out strings.Builder
	for i := 0; i < len(format); {
		c := format[i]
		if c != '%' {
			out.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			out.WriteByte('%')
			i += 2
			continue
		}
		sp, j := parseSpec(format, i)
		i = j
		switch sp.verb {
		case 'd', 'i', 'u', 'x', 'X', 'o':
			out.WriteString(fmtInt(sp, toInt64(math.Floor(x+0.5)*0+x)))
		case 'c':
			// SI prefix char
			pw := 0
			if x != 0 {
				pw = int(math.Floor(math.Log10(math.Abs(x)) / 3))
			}
			idx := pw + 8
			if idx >= 0 && idx < len(siPrefixes) && pw != 0 {
				out.WriteString(padStr(string(siPrefixes[idx]), sp.width, sp.minus))
			} else if pw == 0 {
				out.WriteString(padStr("", sp.width, sp.minus))
			}
		case 'e', 'E', 'f', 'F', 'g', 'G':
			out.WriteString(cfmtFloat(x, sp.verb, sp.prec, sp.minus, sp.plus, sp.space, sp.alt, sp.width, sp.zero))
		case 'h', 'H':
			v := 'g'
			if sp.verb == 'H' {
				v = 'G'
			}
			out.WriteString(cfmtFloat(x, byte(v), sp.prec, sp.minus, sp.plus, sp.space, sp.alt, sp.width, sp.zero))
		case 't', 'l', 's':
			base := 10.0
			if sp.verb == 'l' {
				base = logbase
			}
			m := x
			if base != 1 {
				m, _ = mantExp(x, base, sp.verb == 's', sp.prec)
			}
			out.WriteString(cfmtFloat(m, 'f', sp.prec, sp.minus, sp.plus, sp.space, sp.alt, sp.width, sp.zero))
		case 'T', 'L', 'S':
			base := 10.0
			if sp.verb == 'L' {
				base = logbase
			}
			e := 0
			if base != 1 {
				_, e = mantExp(x, base, sp.verb == 'S', sp.prec)
			}
			sp.verb = 'd'
			out.WriteString(fmtInt(sp, int64(e)))
		case 'P':
			out.WriteString(cfmtFloat(x/math.Pi, 'f', sp.prec, sp.minus, sp.plus, sp.space, sp.alt, sp.width, sp.zero))
		default:
			panic(gpErrNC("Bad format character"))
		}
	}
	return out.String()
}

func mantExp(x, base float64, scientific bool, prec int) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	ax := math.Abs(x)
	l := math.Log10(ax) / math.Log10(base)
	e := int(math.Floor(l))
	if base == 10 {
		// guard rounding
	}
	m := x / math.Pow(base, float64(e))
	if scientific {
		r := ((e % 3) + 3) % 3
		e -= r
		m = x / math.Pow(base, float64(e))
	}
	// handle rounding up to base
	p := prec
	if p < 0 {
		p = 6
	}
	if base == 10 {
		rounded, _ := strconv.ParseFloat(strconv.FormatFloat(math.Abs(m), 'f', p, 64), 64)
		lim := 10.0
		if scientific {
			lim = 1000
		}
		if rounded >= lim {
			if scientific {
				e += 3
			} else {
				e++
			}
			m = x / math.Pow(base, float64(e))
		}
	}
	return m, e
}
