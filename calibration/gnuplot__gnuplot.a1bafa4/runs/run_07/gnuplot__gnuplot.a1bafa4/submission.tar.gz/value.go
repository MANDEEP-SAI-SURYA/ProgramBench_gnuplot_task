package main

import (
	"math"
	"strconv"
	"strings"
)

type Kind int

const (
	KUndef Kind = iota
	KInt
	KCmplx
	KStr
	KArr
)

type Value struct {
	K  Kind
	I  int64
	R  float64
	Im float64
	S  string
	A  *[]Value
}

func IntV(i int64) Value     { return Value{K: KInt, I: i} }
func FltV(f float64) Value   { return Value{K: KCmplx, R: f} }
func CV(r, i float64) Value  { return Value{K: KCmplx, R: r, Im: i} }
func StrV(s string) Value    { return Value{K: KStr, S: s} }
func BoolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

func (v Value) IsNum() bool { return v.K == KInt || v.K == KCmplx }

func (v Value) Real() float64 {
	switch v.K {
	case KInt:
		return float64(v.I)
	case KCmplx:
		return v.R
	case KStr:
		panic(nonNumErr())
	case KArr:
		panic(gpErrNC("non-numeric value"))
	}
	panic(gpErrNC("undefined value"))
}

func nonNumErr() *GPError {
	return gpErrNC("Non-numeric string found where a numeric expression was expected")
}

func fmtG15(f float64) string {
	return cfmtFloat(f, 'g', 15, false, false, false, false, 0, false)
}

func fmtFloatGP(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	s := fmtG15(f)
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

func (v Value) String() string {
	switch v.K {
	case KInt:
		return strconv.FormatInt(v.I, 10)
	case KCmplx:
		if v.Im == 0 {
			return fmtFloatGP(v.R)
		}
		return "{" + fmtFloatGP(v.R) + ", " + fmtFloatGP(v.Im) + "}"
	case KStr:
		return v.S
	case KArr:
		var b strings.Builder
		b.WriteString("[")
		for i, e := range *v.A {
			if i > 0 {
				b.WriteString(",")
			}
			if e.K == KStr {
				b.WriteString("\"" + e.S + "\"")
			} else if e.K != KUndef {
				b.WriteString(e.String())
			}
		}
		b.WriteString("]")
		return b.String()
	}
	return ""
}

// value displayed by show variables
func (v Value) ShowString() string {
	if v.K == KStr {
		return "\"" + v.S + "\""
	}
	return v.String()
}
