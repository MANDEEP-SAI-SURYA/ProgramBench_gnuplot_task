package main

import (
	"math"
	"strconv"
	"strings"
)

const (
	UNDEF = iota
	INT
	CMPLX
	STR
	ARR
	DBLOCK
)

type Value struct {
	t   byte
	i   int64
	r   float64
	im  float64
	s   string
	arr *[]Value
}

func IntV(i int64) Value        { return Value{t: INT, i: i} }
func RealV(r float64) Value     { return Value{t: CMPLX, r: r} }
func CmplxV(r, i float64) Value { return Value{t: CMPLX, r: r, im: i} }
func StrV(s string) Value       { return Value{t: STR, s: s} }

type GPError struct {
	msg string
	pos int // token position, -1 = no caret
}

func gperr(pos int, msg string) {
	panic(&GPError{msg: msg, pos: pos})
}
func rterr(msg string) { panic(&GPError{msg: msg, pos: -1}) }

// numeric conversion of a value (strings promoted)
func toNum(v Value) Value {
	switch v.t {
	case INT, CMPLX:
		return v
	case STR:
		return strToNum(v.s)
	case ARR:
		rterr("non-scalar value used in scalar context")
	}
	rterr("undefined value")
	return v
}

func strToNum(str string) Value {
	s := strings.TrimLeft(str, " \t\n\r\f\v")
	n := 0
	if n < len(s) && (s[n] == '+' || s[n] == '-') {
		n++
	}
	base := 10
	st := n
	if n+1 < len(s) && s[n] == '0' && (s[n+1] == 'x' || s[n+1] == 'X') {
		base = 16
		n += 2
		st = n
		for n < len(s) && strings.IndexByte("0123456789abcdefABCDEF", s[n]) >= 0 {
			n++
		}
	} else {
		for n < len(s) && isDigit(s[n]) {
			n++
		}
	}
	var res Value
	if n == st || (n < len(s) && s[n] == '.') || (n < len(s) && (s[n] == 'e' || s[n] == 'E') && false) {
		if base == 16 && n == st {
			rterr("Non-numeric string found where a numeric expression was expected")
		}
		f, ok, m := parseLeadingFloatN(s)
		if !ok {
			rterr("Non-numeric string found where a numeric expression was expected")
		}
		res = RealV(f)
		n = m
	} else {
		x, err := strconv.ParseInt(s[st:n], base, 64)
		if err != nil {
			f, _ := strconv.ParseFloat(s[st:n], 64)
			if s[0] == '-' {
				f = -f
			}
			res = RealV(f)
		} else {
			if s[0] == '-' {
				x = -x
			}
			res = IntV(x)
		}
	}
	if strings.TrimSpace(s[n:]) != "" {
		warn("Trailing characters after numeric expression")
	}
	return res
}

func parseLeadingFloatN(s string) (float64, bool, int) {
	f, ok := parseLeadingFloat(s)
	return f, ok, lastFloatLen
}

var lastFloatLen int

func parseLeadingFloat(s string) (float64, bool) {
	s = strings.TrimLeft(s, " \t\n")
	n := 0
	if n < len(s) && (s[n] == '+' || s[n] == '-') {
		n++
	}
	digits := 0
	for n < len(s) && s[n] >= '0' && s[n] <= '9' {
		n++
		digits++
	}
	if n < len(s) && s[n] == '.' {
		n++
		for n < len(s) && s[n] >= '0' && s[n] <= '9' {
			n++
			digits++
		}
	}
	if digits == 0 {
		// inf / nan?
		ls := strings.ToLower(s)
		for _, w := range []string{"inf", "+inf", "-inf", "nan", "+nan", "-nan"} {
			if strings.HasPrefix(ls, w) {
				f, _ := strconv.ParseFloat(w, 64)
				lastFloatLen = len(w)
				return f, true
			}
		}
		return 0, false
	}
	if n < len(s) && (s[n] == 'e' || s[n] == 'E') {
		m := n + 1
		if m < len(s) && (s[m] == '+' || s[m] == '-') {
			m++
		}
		if m < len(s) && s[m] >= '0' && s[m] <= '9' {
			for m < len(s) && s[m] >= '0' && s[m] <= '9' {
				m++
			}
			n = m
		}
	}
	lastFloatLen = n
	f, err := strconv.ParseFloat(s[:n], 64)
	if err != nil {
		f, _ = strconv.ParseFloat(strings.TrimRight(s[:n], "."), 64)
	}
	return f, true
}

func realOf(v Value) float64 {
	v = toNum(v)
	if v.t == INT {
		return float64(v.i)
	}
	return v.r
}

func isZero(v Value) bool {
	v = toNum(v)
	if v.t == INT {
		return v.i == 0
	}
	return v.r == 0 && v.im == 0
}

// format a real number the way print does
func fmtReal(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	s := strconv.FormatFloat(f, 'g', 15, 64)
	s = fixExp(s)
	if !strings.ContainsAny(s, ".eE") && !strings.Contains(s, "NaN") {
		if math.IsInf(f, 0) {
			if f > 0 {
				return "inf.0"
			}
			return "-inf.0"
		}
		s += ".0"
	}
	return s
}

// Go's %g produces e+20 style already but with at least 2 exponent digits; C also uses 2.
func fixExp(s string) string {
	return s
}

func cfmtG(f float64, prec int) string {
	return cfmt("%."+strconv.Itoa(prec)+"g", f)
}

func valueToString(v Value) string {
	switch v.t {
	case INT:
		return strconv.FormatInt(v.i, 10)
	case CMPLX:
		if v.im == 0 {
			return fmtReal(v.r)
		}
		return "{" + fmtReal(v.r) + ", " + fmtReal(v.im) + "}"
	case STR:
		return v.s
	case ARR:
		var sb strings.Builder
		sb.WriteString("[")
		for k, e := range (*v.arr)[1:] {
			if k > 0 {
				sb.WriteString(",")
			}
			if e.t == STR {
				sb.WriteString("\"" + e.s + "\"")
			} else if e.t != UNDEF {
				sb.WriteString(valueToString(e))
			}
		}
		sb.WriteString("]")
		return sb.String()
	}
	return ""
}
