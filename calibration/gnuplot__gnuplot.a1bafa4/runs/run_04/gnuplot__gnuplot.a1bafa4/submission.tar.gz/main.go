package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
)

var stdout = bufio.NewWriterSize(os.Stdout, 65536)
var stderrW = os.Stderr

func flushAll() {
	stdout.Flush()
	if printFile != nil {
		printFile.Flush()
	}
}

// write to stderr preserving order with stdout
func errWrite(s string) {
	stdout.Flush()
	stderrW.WriteString(s)
}

type LineSource struct {
	name   string // file name ("" for -e / stdin)
	lines  []string
	idx    int // next line index
	kind   int // 0 file, 1 -e, 2 stdin
	reader *bufio.Reader
}

const (
	srcFile = iota
	srcCmd
	srcStdin
)

func (s *LineSource) next() (string, bool) {
	if s.reader != nil {
		l, err := s.reader.ReadString('\n')
		if err != nil && l == "" {
			return "", false
		}
		s.idx++
		return strings.TrimRight(l, "\n"), true
	}
	if s.idx >= len(s.lines) {
		return "", false
	}
	l := s.lines[s.idx]
	s.idx++
	return l, true
}

var curSrc *LineSource

// error context
type ErrCtx struct {
	text     string
	base     int
	cmdPos   int
	src      *LineSource
	isBlock  bool
	echoText string
}

type exitReq struct{ code int }

var hadError bool
var interactiveErrorsContinue bool

func braceBalance(s string) int {
	n := 0
	inS, inD := false, false
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case inD:
			if c == '\\' {
				i++
			} else if c == '"' {
				inD = false
			}
		case inS:
			if c == '\'' {
				inS = false
			}
		case c == '"':
			inD = true
		case c == '\'':
			inS = true
		case c == '#':
			return n
		case c == '{':
			n++
		case c == '}':
			n--
		}
	}
	return n
}

// read one logical line (continuations and brace blocks); returns text and starting line number
func readLogical(src *LineSource) (string, int, bool) {
	l, ok := src.next()
	if !ok {
		return "", 0, false
	}
	start := src.idx
	for strings.HasSuffix(l, "\\") {
		m, ok := src.next()
		if !ok {
			l = l[:len(l)-1]
			break
		}
		l = l[:len(l)-1] + m
		start = src.idx
	}
	if braceBalance(l) > 0 {
		for braceBalance(l) > 0 {
			m, ok := src.next()
			if !ok {
				break
			}
			for strings.HasSuffix(m, "\\") {
				m2, ok := src.next()
				if !ok {
					break
				}
				m = m[:len(m)-1] + m2
			}
			l = l + "\n" + m
		}
	}
	return l, start, true
}

func runSource(src *LineSource) {
	saved := curSrc
	curSrc = src
	defer func() { curSrc = saved }()
	for {
		l, ln, ok := readLogical(src)
		if !ok {
			return
		}
		curWarnLine = ln
		curWarnSrc = src
		l = expandMacros(l)
		if src.kind == srcStdin {
			func() {
				defer func() {
					if r := recover(); r != nil {
						if e, ok := r.(*GPError); ok {
							reportError(e, l, ln, src)
							hadError = true
							return
						}
						panic(r)
					}
				}()
				execTop(l, ln, src)
			}()
		} else {
			execTop(l, ln, src)
		}
	}
}

// executes a top-level logical line, attaching error context
func execTop(l string, ln int, src *LineSource) {
	execText(l, ln, src)
}

var curWarnLine int
var curWarnSrc *LineSource

func locPrefix(src *LineSource, line int) string {
	if src != nil && src.kind == srcFile {
		return fmt.Sprintf("\"%s\" line %d: ", src.name, line)
	}
	return "line 0: "
}

func warn(msg string) {
	errWrite(locPrefix(curWarnSrc, curWarnLine) + "warning: " + msg + "\n")
}

type ctxError struct {
	e    *GPError
	text string
	line int
	src  *LineSource
}

func reportErrorCtx(ce *ctxError) {
	e := ce.e
	var sb strings.Builder
	prefix := ""
	src := ce.src
	if src != nil && src.kind == srcFile {
		prefix = fmt.Sprintf("\"%s\" line %d: ", src.name, ce.line)
	} else {
		prefix = "line 0: "
	}
	stdin := src != nil && src.kind == srcStdin
	indent := ""
	if stdin {
		indent = "         "
	}
	if e.pos >= 0 && !strings.Contains(ce.text, "\n") {
		t := ce.text
		lead := len(t) - len(strings.TrimLeft(t, " \t"))
		t = t[lead:]
		col := e.pos - lead
		if col < 0 {
			col = 0
		}
		if stdin {
			sb.WriteString("\ngnuplot> " + t + "\n")
		} else {
			sb.WriteString("\n" + t + "\n")
		}
		sb.WriteString(indent + strings.Repeat(" ", col) + "^\n")
	}
	sb.WriteString(indent + prefix + e.msg + "\n\n")
	errWrite(sb.String())
	vars["GPVAL_ERRNO"] = IntV(1)
	vars["GPVAL_ERRMSG"] = StrV(e.msg)
}

func reportError(r interface{}, l string, ln int, src *LineSource) {
	if ce, ok := r.(*ctxError); ok {
		reportErrorCtx(ce)
		return
	}
	if e, ok := r.(*GPError); ok {
		reportErrorCtx(&ctxError{e: e, text: l, line: ln, src: src})
	}
}

func main() {
	initVars()
	args := os.Args[1:]
	code := 0
	ranSomething := false
	defer func() {
		flushAll()
	}()
	run := func(f func()) (stop bool) {
		defer func() {
			if r := recover(); r != nil {
				if ex, ok := r.(*exitReq); ok {
					code = ex.code
					stop = true
					return
				}
				if ce, ok := r.(*ctxError); ok {
					reportErrorCtx(ce)
					code = 1
					stop = true
					return
				}
				if e, ok := r.(*GPError); ok {
					reportErrorCtx(&ctxError{e: e, text: "", line: 0, src: nil})
					code = 1
					stop = true
					return
				}
				panic(r)
			}
		}()
		f()
		return false
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			stdout.WriteString("gnuplot 5.4 patchlevel 9\n")
			flushAll()
			os.Exit(0)
		case a == "-h" || a == "--help":
			stdout.WriteString(usageText)
			flushAll()
			os.Exit(0)
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings":
		case a == "-e":
			if i+1 >= len(args) {
				errWrite("syntax:  gnuplot -e \"commands\"\n")
				flushAll()
				os.Exit(0)
			}
			i++
			cmd := args[i]
			ranSomething = true
			src := &LineSource{name: "", lines: []string{cmd}, kind: srcCmd}
			if run(func() { runSource(src) }) {
				flushAll()
				os.Exit(code)
			}
		case a == "-c":
			if i+1 >= len(args) {
				errWrite("syntax:  gnuplot -c scriptname args\n")
				flushAll()
				os.Exit(1)
			}
			fn := args[i+1]
			cargs := args[i+2:]
			ranSomething = true
			if run(func() { callScript(fn, cargs, true) }) {
				flushAll()
				os.Exit(code)
			}
			i = len(args)
		case a == "-":
			ranSomething = true
			src := &LineSource{kind: srcStdin, reader: bufio.NewReader(os.Stdin)}
			if run(func() { runSource(src) }) {
				flushAll()
				os.Exit(code)
			}
		case strings.HasPrefix(a, "-") && len(a) > 1:
			errWrite("unrecognized option " + a + "\n")
			stdout.WriteString(usageText)
			flushAll()
			os.Exit(0)
		default:
			ranSomething = true
			if run(func() { callScript(a, nil, true) }) {
				flushAll()
				os.Exit(code)
			}
		}
	}
	if !ranSomething {
		src := &LineSource{kind: srcStdin, reader: bufio.NewReader(os.Stdin)}
		if run(func() { runSource(src) }) {
			flushAll()
			os.Exit(code)
		}
		if hadError {
			code = 1
		}
	}
	finishOutput()
	flushAll()
	os.Exit(code)
}

const usageText = `Usage: gnuplot [OPTION] ... [FILE]
  -V, --version
  -h, --help
  -p  --persist
  -s  --slow
  -d  --default-settings
  -c  scriptfile ARG1 ARG2 ...
  -e  "command1; command2; ..."
gnuplot 5.4 patchlevel 9
`

func readFileLines(name string) ([]string, bool) {
	var data []byte
	var err error
	if name == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(name)
	}
	if err != nil {
		return nil, false
	}
	s := string(data)
	s = strings.ReplaceAll(s, "\r\n", "\n")
	if strings.HasSuffix(s, "\n") {
		s = s[:len(s)-1]
	}
	if s == "" {
		return []string{}, true
	}
	return strings.Split(s, "\n"), true
}

func loadFile(name string, top bool) {
	lines, ok := readFileLines(name)
	if !ok {
		rterr(fmt.Sprintf("Cannot load input from '%s'", name))
	}
	src := &LineSource{name: name, lines: lines, kind: srcFile}
	runSource(src)
}

var callDepth int

func callScript(name string, cargs []string, fromCmdline bool) {
	lines, ok := readFileLines(name)
	if !ok {
		rterr(fmt.Sprintf("Cannot load input from '%s'", name))
	}
	// save ARG variables
	saved := map[string]Value{}
	had := map[string]bool{}
	names := []string{"ARGC", "ARG0", "ARGV"}
	for k := 1; k <= 9; k++ {
		names = append(names, fmt.Sprintf("ARG%d", k))
	}
	for _, n := range names {
		v, ok := vars[n]
		saved[n] = v
		had[n] = ok
	}
	setVar("ARGC", IntV(int64(len(cargs))))
	setVar("ARG0", StrV(name))
	arr := make([]Value, len(cargs)+1)
	setVar("ARGV", Value{t: ARR, arr: &arr})
	for k := 1; k <= 9; k++ {
		if k <= len(cargs) {
			setVar(fmt.Sprintf("ARG%d", k), StrV(cargs[k-1]))
		} else {
			setVar(fmt.Sprintf("ARG%d", k), StrV(""))
		}
	}
	for k, c := range cargs {
		arr[k+1] = StrV(c)
	}
	vars["ARGV"] = Value{t: ARR, arr: &arr}
	src := &LineSource{name: name, lines: lines, kind: srcFile}
	defer func() {
		if !fromCmdline {
			for _, n := range names {
				if had[n] {
					vars[n] = saved[n]
				} else {
					delete(vars, n)
				}
			}
		}
	}()
	runSource(src)
}
