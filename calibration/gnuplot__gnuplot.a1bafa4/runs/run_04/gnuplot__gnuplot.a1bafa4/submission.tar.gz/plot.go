package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

const (
	ptIn = iota
	ptOut
	ptUndef
)

type Point struct {
	x, y, z float64
	ex      []float64 // extra columns (ylow,yhigh / xlow,xhigh / etc)
	typ     int
	label   string
	blockEnd bool // a blank line follows this point
	xtic    string
	hasXtic bool
}

type Curve struct {
	title      string
	noTitle    bool
	style      string
	isFunc     bool
	points     []Point
	smooth     string
	is3d       bool
	lt         int
	pt         int
	ptChar     string
	axesX      string
	axesY      string
	isoCurves  [][]Point
	funcExpr   Expr
	fill       bool
	ncols      int
	dashtype   int
	lw         float64
}

// ---------- data file reading ----------

type DataRec struct {
	fields []string
	line   string
}

type DataSet struct {
	blocks [][]DataRec
}

func splitFields(line string) []string {
	if S.sepChar != "" && S.sepChar != " " {
		var out []string
		var cur strings.Builder
		inQ := false
		for i := 0; i < len(line); i++ {
			c := line[i]
			if c == '"' {
				inQ = !inQ
				cur.WriteByte(c)
				continue
			}
			if !inQ && strings.IndexByte(S.sepChar, c) >= 0 {
				out = append(out, strings.TrimSpace(cur.String()))
				cur.Reset()
				continue
			}
			cur.WriteByte(c)
		}
		out = append(out, strings.TrimSpace(cur.String()))
		return out
	}
	var out []string
	i := 0
	for i < len(line) {
		for i < len(line) && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r') {
			i++
		}
		if i >= len(line) {
			break
		}
		if line[i] == '"' {
			j := i + 1
			for j < len(line) && line[j] != '"' {
				j++
			}
			out = append(out, line[i:min(j+1, len(line))])
			i = j + 1
			continue
		}
		j := i
		for j < len(line) && !(line[j] == ' ' || line[j] == '\t' || line[j] == '\r') {
			j++
		}
		out = append(out, line[i:j])
		i = j
	}
	return out
}

func isCommentLine(l string) bool {
	t := strings.TrimLeft(l, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(S.commentChars, t[0]) >= 0
}

func stripComment(l string) string {
	// strip trailing comment (outside quotes)
	inQ := false
	for i := 0; i < len(l); i++ {
		if l[i] == '"' {
			inQ = !inQ
		}
		if !inQ && strings.IndexByte(S.commentChars, l[i]) >= 0 {
			return l[:i]
		}
	}
	return l
}

// read data into datasets (index) -> blocks -> records
func readData(name string) ([]*DataSet, bool) {
	var lines []string
	if strings.HasPrefix(name, "$") {
		l, ok := datablocks[name]
		if !ok {
			return nil, false
		}
		lines = l
	} else {
		b, err := os.ReadFile(name)
		if err != nil {
			return nil, false
		}
		s := strings.ReplaceAll(string(b), "\r\n", "\n")
		s = strings.TrimSuffix(s, "\n")
		if s != "" {
			lines = strings.Split(s, "\n")
		}
	}
	var sets []*DataSet
	cur := &DataSet{}
	var blk []DataRec
	blank := 0
	started := false
	flushBlock := func() {
		if len(blk) > 0 {
			cur.blocks = append(cur.blocks, blk)
			blk = nil
		}
	}
	for _, l := range lines {
		if isCommentLine(l) {
			continue
		}
		if strings.TrimSpace(l) == "" {
			blank++
			if blank == 1 {
				flushBlock()
			}
			if blank == 2 && started {
				sets = append(sets, cur)
				cur = &DataSet{}
			}
			continue
		}
		if blank >= 1 && blank < 2 && len(cur.blocks) == 0 && started {
			// nothing
		}
		blank = 0
		started = true
		f := splitFields(stripComment(l))
		blk = append(blk, DataRec{fields: f, line: l})
	}
	flushBlock()
	if len(cur.blocks) > 0 || len(sets) == 0 {
		sets = append(sets, cur)
	}
	return sets, true
}

// current row context for column() evaluation
var curRow []string
var curRowNum int
var curBlockNum int
var curIndexNum int
var curHeader []string
var colInvalid bool

func fieldValue(s string) (float64, bool) {
	if S.missing != "" && s == S.missing {
		return math.NaN(), false
	}
	if strings.HasPrefix(s, "\"") && strings.HasSuffix(s, "\"") && len(s) >= 2 {
		s = s[1 : len(s)-1]
	}
	f, ok := parseFieldNum(s)
	return f, ok
}

func parseFieldNum(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	if S.decimalsign != "" && S.decimalsign != "." {
		s = strings.Replace(s, S.decimalsign, ".", 1)
	}
	n := 0
	if n < len(s) && (s[n] == '+' || s[n] == '-') {
		n++
	}
	d := 0
	for n < len(s) && isDigit(s[n]) {
		n++
		d++
	}
	if n < len(s) && s[n] == '.' {
		n++
		for n < len(s) && isDigit(s[n]) {
			n++
			d++
		}
	}
	if d == 0 {
		ls := strings.ToLower(s)
		if ls == "inf" || ls == "+inf" || ls == "-inf" || ls == "nan" || ls == "-nan" {
			f, _ := strconv.ParseFloat(ls, 64)
			return f, true
		}
		return 0, false
	}
	if n < len(s) && (s[n] == 'e' || s[n] == 'E' || s[n] == 'd' || s[n] == 'D') {
		m := n + 1
		if m < len(s) && (s[m] == '+' || s[m] == '-') {
			m++
		}
		if m < len(s) && isDigit(s[m]) {
			for m < len(s) && isDigit(s[m]) {
				m++
			}
			n = m
		}
	}
	t := strings.Map(func(r rune) rune {
		if r == 'd' || r == 'D' {
			return 'e'
		}
		return r
	}, s[:n])
	f, err := strconv.ParseFloat(t, 64)
	if err != nil {
		return 0, false
	}
	return f, true
}

func columnValue(v Value, asString bool) Value {
	if v.t == STR {
		// column by header name
		for k, h := range curHeader {
			if h == v.s {
				v = IntV(int64(k + 1))
				break
			}
		}
		if v.t == STR {
			colInvalid = true
			undefFlag = true
			return RealV(math.NaN())
		}
	}
	n := int(realOf(v))
	if n == 0 {
		if asString {
			return StrV(strconv.Itoa(curRowNum))
		}
		return IntV(int64(curRowNum))
	}
	if n == -1 {
		return IntV(int64(curBlockNum))
	}
	if n == -2 {
		return IntV(int64(curIndexNum))
	}
	if n < 0 || n > len(curRow) {
		if asString {
			return StrV("")
		}
		undefFlag = true
		colInvalid = true
		return RealV(math.NaN())
	}
	s := curRow[n-1]
	if asString {
		if strings.HasPrefix(s, "\"") && strings.HasSuffix(s, "\"") && len(s) >= 2 {
			s = s[1 : len(s)-1]
		}
		return StrV(s)
	}
	f, ok := fieldValue(s)
	if !ok {
		undefFlag = true
		return RealV(math.NaN())
	}
	return RealV(f)
}

func columnHead(v Value) Value {
	n := int(realOf(v))
	if n >= 1 && n <= len(curHeader) {
		h := curHeader[n-1]
		if strings.HasPrefix(h, "\"") && strings.HasSuffix(h, "\"") && len(h) >= 2 {
			h = h[1 : len(h)-1]
		}
		return StrV(h)
	}
	return StrV("")
}

func validColumn(v Value) Value {
	n := int(realOf(v))
	if n < 1 || n > len(curRow) {
		return IntV(0)
	}
	_, ok := fieldValue(curRow[n-1])
	return boolV(ok)
}

// ---------- plot command ----------

type UsingCol struct {
	col     int
	expr    Expr
	isExpr  bool
	str     string
	special string // xticlabels etc
}

type PlotElem struct {
	isFunc     bool
	expr       Expr
	exprText   string
	file       string
	index      [3]int
	hasIndex   bool
	every      [6]int
	hasEvery   bool
	using      []UsingCol
	usingText  string
	title      string
	hasTitle   bool
	noTitle    bool
	titleColH  bool
	titleColN  int
	style      string
	smooth     string
	lt         int
	pt         int
	ptChar     string
	axes       string
	rawSpec    string
	sampleRange *Axis
	fill       bool
	lw         float64
	dt         int
	binsN      int
	binsOpt    bool
	binW       float64
	hasBinW    bool
	binRangeSet bool
	binLo, binHi float64
	is3d       bool
	isParam    bool
	exprY      Expr
	exprYText  string
}

var lastPlotText string
var lastPlot3d bool

func (ex *Exec) plotCmd(is3d bool) {
	p := ex.p
	startPos := p.pos()
	// find end of command
	endTok := p.i
	for !(p.toks[endTok].kind == tEOF || p.toks[endTok].kind == tNL || (p.toks[endTok].kind == tOp && p.toks[endTok].s == ";")) {
		endTok++
	}
	lastPlotText = ex.text[startPos:p.toks[endTok].pos]
	lastPlot3d = is3d
	ex.doPlot(is3d)
}

func (ex *Exec) replotCmd() {
	p := ex.p
	if lastPlotText == "" {
		rterr("no previous plot")
	}
	extra := ""
	if !p.endOfCmd() {
		st := p.pos()
		ex.skipToEnd()
		extra = ", " + ex.text[st:p.pos()]
	}
	txt := lastPlotText + extra
	sub := &Exec{p: &Parser{toks: lex(txt), text: txt}, text: txt, base: ex.base, src: ex.src}
	lastPlotText = txt
	sub.doPlot(lastPlot3d)
}

func (ex *Exec) parseUsing() ([]UsingCol, string) {
	p := ex.p
	st := p.pos()
	var cols []UsingCol
	for {
		var c UsingCol
		if p.isOp("(") {
			sp := p.i
			_ = sp
			c.expr = p.parsePrimary()
			c.isExpr = true
		} else if p.peek().kind == tNum {
			t := p.next()
			c.col = int(realOf(t.val))
		} else if p.peek().kind == tStr {
			t := p.next()
			s := t.s
			c.expr = func(f *Frame) Value { return columnValue(StrV(s), false) }
			c.isExpr = true
		} else if p.peek().kind == tIdent && p.isOpN(1, "(") {
			name := p.peek().s
			if name == "xticlabels" || name == "xtic" || name == "ytic" || name == "yticlabels" || name == "x2ticlabels" || name == "ticlabels" {
				p.next()
				p.next()
				arg := p.parseExpr()
				p.expect(")", "')' expected")
				c.special = "xtic"
				c.expr = func(f *Frame) Value {
					v := arg(f)
					if v.t == STR {
						return v
					}
					return columnValue(v, true)
				}
				cols = append(cols, c)
				if p.isOp(":") {
					p.next()
					continue
				}
				break
			}
			c.expr = p.parsePostfix()
			c.isExpr = true
		} else if p.peek().kind == tIdent && p.peek().s[0] == '$' {
			c.expr = p.parsePrimary()
			c.isExpr = true
		} else {
			e := p.parsePrimary()
			v := e(&Frame{})
			c.col = int(realOf(v))
		}
		cols = append(cols, c)
		if p.isOp(":") {
			p.next()
			continue
		}
		break
	}
	return cols, strings.TrimSpace(ex.text[st:p.pos()])
}

func (ex *Exec) doPlot(is3d bool) {
	p := ex.p
	// ranges
	xa, ya, za := S.axes["x"], S.axes["y"], S.axes["z"]
	saved := map[string]Axis{}
	for k, a := range S.axes {
		saved[k] = *a
	}
	_ = saved
	rangeAxes := []*Axis{xa, ya}
	if is3d {
		rangeAxes = []*Axis{xa, ya, za}
	}
	if S.parametric || S.polar {
		if is3d {
			rangeAxes = []*Axis{S.axes["u"], S.axes["v"], xa, ya, za}
		} else {
			rangeAxes = []*Axis{S.axes["t"], xa, ya}
		}
	}
	// plot-local range copies
	local := map[*Axis]*Axis{}
	for _, a := range S.axes {
		c := *a
		local[a] = &c
	}
	ri := 0
	for p.isOp("[") {
		// dummy variable in range [t=...]
		if ri < len(rangeAxes) {
			ex.parseRange(local[rangeAxes[ri]])
		} else {
			tmp := newAxis("tmp")
			ex.parseRange(tmp)
		}
		ri++
	}
	if p.endOfCmd() {
		gperr(p.pos(), "function to plot expected")
	}
	var elems []*PlotElem
	type iterCtx struct{}
	for {
		// iteration
		if p.isIdent("for") {
			p.next()
			it := ex.parseIter()
			elemStart := p.i
			var endI int
			it.run(func() bool {
				p.i = elemStart
				e := ex.parsePlotElem(is3d)
				elems = append(elems, e)
				endI = p.i
				return false
			})
			if endI == 0 {
				// empty iteration: skip element tokens
				p.i = elemStart
				ex.parsePlotElem(is3d)
			} else {
				p.i = endI
			}
		} else {
			e := ex.parsePlotElem(is3d)
			if e != nil {
				elems = append(elems, e)
			}
		}
		if p.isOp(",") {
			p.next()
			continue
		}
		break
	}
	// copy local ranges into working axes
	cur := map[string]*Axis{}
	for k, a := range S.axes {
		cur[k] = local[a]
	}
	if is3d {
		ex.do3d(elems, cur)
		return
	}
	curves := buildCurves2D(elems, cur)
	if S.tableOn {
		writeTable(curves)
		return
	}
	if S.termName == "unknown" {
		errWrite("WARNING: Plotting with an 'unknown' terminal.\nNo output will be generated. Please select a terminal with 'set terminal'.\n")
		return
	}
	render2D(curves, cur)
}

func (ex *Exec) parsePlotElem(is3d bool) *PlotElem {
	p := ex.p
	e := &PlotElem{lt: -1, pt: -1, lw: 1, is3d: is3d}
	st := p.pos()
	// definitions inside plot: f(x)=..., a=...
	for ex.isDefinition() {
		ex.definition()
		if p.isOp(",") {
			p.next()
		}
		st = p.pos()
	}
	if p.isOp("[") {
		// sampling range for this element
		ax := newAxis("s")
		ax.autoMin, ax.autoMax = true, true
		ex.parseRange(ax)
		e.sampleRange = ax
		st = p.pos()
	}
	if ex.isStringStart() || (p.peek().kind == tIdent && p.peek().s[0] == '$' && !p.isOpN(1, "[")) {
		if p.peek().kind == tIdent && p.peek().s[0] == '$' {
			e.file = p.next().s
			e.rawSpec = e.file
		} else {
			e.file = ex.parseStrExpr()
			e.rawSpec = "\"" + e.file + "\""
			if e.file == "" {
				e.file = lastDataFile
			}
		}
		lastDataFile = e.file
	} else {
		e.isFunc = true
		dummies := []string{S.dummy1}
		if is3d {
			dummies = []string{S.dummy1, S.dummy2}
			if S.parametric {
				dummies = []string{"u", "v"}
			}
		} else if S.parametric || S.polar {
			dummies = []string{"t"}
		}
		sp := &Parser{toks: p.toks, i: p.i, text: p.text, dummies: dummies}
		e.expr = sp.parseTernary()
		e.exprText = strings.TrimSpace(ex.text[st:sp.peek().pos])
		p.i = sp.i
		if S.parametric && !is3d && p.isOp(",") {
			p.next()
			st2 := p.pos()
			sp := &Parser{toks: p.toks, i: p.i, text: p.text, dummies: dummies}
			e.exprY = sp.parseTernary()
			e.exprYText = strings.TrimSpace(ex.text[st2:sp.peek().pos])
			p.i = sp.i
			e.isParam = true
		}
	}
	var specParts []string
	for !p.endOfCmd() && !p.isOp(",") {
		t := p.peek()
		if t.kind != tIdent {
			gperr(t.pos, "unexpected or unrecognized token: "+ex.text[t.pos:t.end])
		}
		w := t.s
		switch {
		case abbrev("i$ndex", w) && !e.isFunc:
			ps := p.pos()
			p.next()
			if ex.isStringStart() {
				ex.parseStrExpr()
			} else {
				a := int(ex.parseNumExprNoComma())
				e.index = [3]int{a, a, 1}
				if p.isOp(":") {
					p.next()
					e.index[1] = int(ex.parseNumExprNoComma())
					if p.isOp(":") {
						p.next()
						e.index[2] = int(ex.parseNumExprNoComma())
					}
				}
			}
			e.hasIndex = true
			specParts = append(specParts, strings.TrimSpace(ex.text[ps:p.pos()]))
		case abbrev("ev$ery", w) && !e.isFunc:
			ps := p.pos()
			p.next()
			e.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if p.isOp(":") {
					p.next()
					continue
				}
				if p.endOfCmd() || p.isOp(",") || p.peek().kind == tIdent {
					break
				}
				e.every[k] = int(ex.parseNumExprNoComma())
				if p.isOp(":") {
					p.next()
				} else {
					break
				}
			}
			e.hasEvery = true
			specParts = append(specParts, strings.TrimSpace(ex.text[ps:p.pos()]))
		case abbrev("u$sing", w) && !e.isFunc:
			p.next()
			cols, txt := ex.parseUsing()
			e.using = cols
			e.usingText = txt
			specParts = append(specParts, "using "+txt)
		case abbrev("s$mooth", w):
			p.next()
			if p.peek().kind == tIdent {
				e.smooth = p.next().s
				for _, sm := range []string{"uniq$ue", "freq$uency", "fnorm$al", "cum$ulative", "cnorm$al", "csp$lines", "acsp$lines", "mcsp$lines", "bez$ier", "sbez$ier", "kdens$ity", "unwrap", "path", "zsort"} {
					if abbrev(sm, e.smooth) {
						e.smooth = strings.ReplaceAll(sm, "$", "")
					}
				}
				if e.smooth == "kdensity" {
					if p.isIdent("bandwidth") {
						p.next()
						ex.parseNumExprNoComma()
					}
				}
			}
		case w == "bins":
			p.next()
			e.smooth = "bins"
			if p.isOp("=") {
				p.next()
				e.binsN = int(ex.parseNumExprNoComma())
			}
			for {
				if p.isIdent("binrange") {
					p.next()
					tmp := newAxis("b")
					ex.parseRange(tmp)
					e.binRangeSet = true
					e.binLo, e.binHi = tmp.min, tmp.max
					continue
				}
				if p.isIdent("binwidth") {
					p.next()
					p.expect("=", "'=' expected")
					e.binW = ex.parseNumExprNoComma()
					e.hasBinW = true
					continue
				}
				break
			}
		case abbrev("t$itle", w):
			p.next()
			if p.isIdent("columnheader") || p.isIdent("columnhead") {
				p.next()
				e.titleColH = true
				if p.isOp("(") {
					p.next()
					e.titleColN = int(ex.parseNumExprNoComma())
					p.expect(")", "')' expected")
				}
			} else {
				e.title = ex.parseStrExpr()
				e.hasTitle = true
			}
		case abbrev("not$itle", w):
			p.next()
			e.noTitle = true
			if ex.isStringStart() {
				ex.parseStrExpr()
			}
		case abbrev("w$ith", w):
			p.next()
			e.style = parseStyleName(p.next().s)
			if e.style == "filledcurves" {
				for p.isIdent("closed") || p.isIdent("x1") || p.isIdent("x2") || p.isIdent("y1") || p.isIdent("y2") || p.isIdent("above") || p.isIdent("below") {
					p.next()
				}
			}
		case w == "lt" || abbrev("linet$ype", w) || w == "ls" || abbrev("lines$tyle", w) || w == "lc" || abbrev("linec$olor", w):
			p.next()
			if p.isIdent("rgb") || p.isIdent("rgbcolor") {
				p.next()
				ex.parseStrExpr()
				continue
			}
			if p.isIdent("palette") || p.isIdent("variable") || p.isIdent("black") || p.isIdent("bgnd") {
				p.next()
				continue
			}
			n := int(ex.parseNumExprNoComma())
			if w == "lt" || abbrev("linet$ype", w) || w == "lc" || abbrev("linec$olor", w) || w == "ls" || abbrev("lines$tyle", w) {
				e.lt = n - 1
			}
		case w == "pt" || abbrev("pointt$ype", w):
			p.next()
			if ex.isStringStart() {
				e.ptChar = ex.parseStrExpr()
			} else {
				e.pt = int(ex.parseNumExprNoComma())
			}
		case w == "ps" || abbrev("points$ize", w) || w == "lw" || abbrev("linew$idth", w) || w == "dt" || abbrev("dasht$ype", w) || w == "pi" || w == "pn" || w == "fs" || w == "fc" || w == "fillcolor" || abbrev("fill$style", w):
			p.next()
			if p.isIdent("variable") || p.isIdent("var") || p.isIdent("solid") || p.isIdent("empty") || p.isIdent("pattern") || p.isIdent("transparent") {
				p.next()
				if !p.endOfCmd() && !p.isOp(",") && p.peek().kind == tNum {
					ex.parseNumExprNoComma()
				}
				continue
			}
			if ex.isStringStart() {
				ex.parseStrExpr()
				continue
			}
			if p.isOp("(") || p.peek().kind == tNum || p.peek().kind == tIdent && !p.isOpN(1, ",") {
				v := ex.parseNumExprNoComma()
				if w == "lw" || abbrev("linew$idth", w) {
					e.lw = v
				}
			}
		case abbrev("ax$es", w):
			p.next()
			e.axes = p.next().s
		case w == "nohidden3d", w == "nocontours", w == "nosurface", w == "palette", w == "notitle", w == "enhanced", w == "noenhanced", w == "nonuniform", w == "matrix", w == "binary", w == "volatile", w == "noautoscale", w == "nonuniformmatrix":
			p.next()
		case w == "heads" || w == "nohead" || w == "head" || w == "filled" || w == "empty" || w == "nofilled" || w == "noborder" || w == "border":
			p.next()
		default:
			gperr(t.pos, "unexpected or unrecognized token: "+w)
		}
	}
	if !e.isFunc {
		if len(specParts) > 0 {
			e.rawSpec = e.rawSpec + " " + strings.Join(specParts, " ")
		}
	}
	if e.style == "" {
		if e.isFunc {
			e.style = S.styleFunc
		} else {
			e.style = S.styleData
		}
	}
	return e
}

var lastDataFile string

func (a *Axis) inRange(v float64) bool {
	lo, hi := a.min, a.max
	if lo > hi {
		lo, hi = hi, lo
	}
	if !a.autoMin && v < lo {
		return false
	}
	if !a.autoMax && v > hi {
		return false
	}
	return true
}

func buildCurves2D(elems []*PlotElem, ax map[string]*Axis) []*Curve {
	var curves []*Curve
	xa := ax["x"]
	ya := ax["y"]
	// first data curves to establish x autoscale
	dataMin, dataMax := math.Inf(1), math.Inf(-1)
	for _, e := range elems {
		if e.isFunc {
			curves = append(curves, nil)
			continue
		}
		c := readDataCurve(e, ax)
		curves = append(curves, c)
		if c == nil {
			continue
		}
		for _, pt := range c.points {
			if pt.typ != ptUndef && !math.IsNaN(pt.x) {
				if pt.x < dataMin {
					dataMin = pt.x
				}
				if pt.x > dataMax {
					dataMax = pt.x
				}
			}
		}
	}
	// function sampling range
	fmin, fmax := xa.min, xa.max
	if xa.autoMin {
		if dataMin <= dataMax {
			fmin = dataMin
		} else {
			fmin = -10
			if xa.log {
				fmin = 0.1
			}
		}
	}
	if xa.autoMax {
		if dataMin <= dataMax {
			fmax = dataMax
		} else {
			fmax = 10
		}
	}
	if xa.autoMin && xa.autoMax && dataMin > dataMax {
		// pure functions with autoscale: use the stored range (default -10:10)
		fmin, fmax = xa.min, xa.max
		if xa.log && fmin <= 0 {
			fmin, fmax = 1, 10
		}
	}
	for k, e := range elems {
		if !e.isFunc {
			continue
		}
		c := &Curve{style: e.style, isFunc: true, lt: e.lt, pt: e.pt, ptChar: e.ptChar, lw: e.lw}
		c.title = e.exprText
		if e.isParam {
			c.title = e.exprText + ", " + e.exprYText
		}
		if e.hasTitle {
			c.title = e.title
		}
		c.noTitle = e.noTitle
		lo, hi := fmin, fmax
		ns := S.samples1
		if S.parametric || S.polar {
			ta := ax["t"]
			lo, hi = ta.min, ta.max
			if S.polar && ta.autoMin && ta.autoMax {
				lo, hi = 0, 2*math.Pi
			}
		}
		if e.sampleRange != nil {
			if !e.sampleRange.autoMin {
				lo = e.sampleRange.min
			}
			if !e.sampleRange.autoMax {
				hi = e.sampleRange.max
			}
		}
		for i := 0; i < ns; i++ {
			var x float64
			if xa.log && !(S.parametric || S.polar) {
				l1, l2 := math.Log(lo), math.Log(hi)
				x = math.Exp(l1 + float64(i)*(l2-l1)/float64(ns-1))
			} else {
				x = lo + float64(i)*(hi-lo)/float64(ns-1)
			}
			undefFlag = false
			var pt Point
			func() {
				defer func() {
					if r := recover(); r != nil {
						if _, ok := r.(*GPError); ok {
							panic(r)
						}
						panic(r)
					}
				}()
				v := e.expr(&Frame{args: []Value{RealV(x)}})
				if e.isParam {
					yv := e.exprY(&Frame{args: []Value{RealV(x)}})
					pt.x = realOf(v)
					pt.y = realOf(yv)
				} else if S.polar {
					r := realOf(v)
					t := x
					if angleDegrees {
						t = x * math.Pi / 180
					}
					pt.x = r * math.Cos(t)
					pt.y = r * math.Sin(t)
				} else {
					pt.x = x
					if v.t == CMPLX && math.Abs(v.im) > S.zero {
						pt.y = v.r
						pt.typ = ptUndef
						undefFlag = true
					} else {
						pt.y = realOf(v)
					}
				}
			}()
			if undefFlag || math.IsNaN(pt.y) {
				pt.typ = ptUndef
				undefFlag = false
			} else if math.IsInf(pt.y, 0) {
				pt.typ = ptUndef
			} else if !ya.inRange(pt.y) || (ya.log && pt.y <= 0) {
				pt.typ = ptOut
			} else if !xa.inRange(pt.x) {
				pt.typ = ptOut
			}
			c.points = append(c.points, pt)
		}
		if e.style == "boxes" || e.style == "impulses" || e.style == "steps" {
		}
		curves[k] = c
	}
	// apply smoothing
	var out []*Curve
	for k, e := range elems {
		if k >= len(curves) {
			break
		}
		if e.smooth != "" && curves[k] != nil {
			applySmooth(curves[k], e, ax)
		}
	}
	for _, c := range curves {
		if c != nil {
			out = append(out, c)
		}
	}
	if len(out) == 0 {
		rterr("No data in plot")
	}
	return out
}

func readDataCurve(e *PlotElem, ax map[string]*Axis) *Curve {
	c := &Curve{style: e.style, lt: e.lt, pt: e.pt, ptChar: e.ptChar, lw: e.lw}
	c.title = e.rawSpec
	if e.hasTitle {
		c.title = e.title
	}
	c.noTitle = e.noTitle
	xa, ya := ax["x"], ax["y"]
	var sets []*DataSet
	ok := true
	if e.file == "+" {
		lo, hi := xa.min, xa.max
		if xa.autoMin && xa.autoMax {
			lo, hi = -10, 10
		}
		if e.sampleRange != nil {
			if !e.sampleRange.autoMin {
				lo = e.sampleRange.min
			}
			if !e.sampleRange.autoMax {
				hi = e.sampleRange.max
			}
		}
		var blk []DataRec
		for i := 0; i < S.samples1; i++ {
			x := lo + float64(i)*(hi-lo)/float64(S.samples1-1)
			blk = append(blk, DataRec{fields: []string{strconv.FormatFloat(x, 'g', -1, 64)}})
		}
		sets = []*DataSet{{blocks: [][]DataRec{blk}}}
	} else {
		sets, ok = readData(e.file)
	}
	if !ok {
		if strings.HasPrefix(e.file, "$") {
			rterr("no datablock named " + e.file)
		}
		warn(fmt.Sprintf("Cannot find or open file \"%s\"", e.file))
		return nil
	}
	_ = ya
	every := e.every
	if !e.hasEvery {
		every = [6]int{1, 1, 0, 0, -1, -1}
	}
	if every[0] <= 0 {
		every[0] = 1
	}
	if every[1] <= 0 {
		every[1] = 1
	}
	idxLo, idxHi, idxStep := 0, len(sets)-1, 1
	if e.hasIndex {
		idxLo, idxHi, idxStep = e.index[0], e.index[1], e.index[2]
		if idxStep <= 0 {
			idxStep = 1
		}
		if idxLo >= len(sets) {
			rterr("index out of range")
		}
	}
	ncols := len(e.using)
	headerUsed := false
	usesHeader := e.titleColH
	for _, u := range e.using {
		_ = u
	}
	firstLine := true
	for si := idxLo; si <= idxHi && si < len(sets); si += idxStep {
		ds := sets[si]
		curIndexNum = si
		rowNum := 0
		for bi, blk := range ds.blocks {
			curBlockNum = bi
			inBlock := bi >= every[3] && (every[5] < 0 || bi <= every[5]) && (bi-every[3])%every[1] == 0
			for li, rec := range blk {
				if firstLine && usesHeader && !headerUsed {
					curHeader = rec.fields
					headerUsed = true
					firstLine = false
					if e.titleColH && !e.hasTitle {
						n := e.titleColN
						if n == 0 {
							n = 2
							if len(e.using) >= 2 && !e.using[1].isExpr {
								n = e.using[1].col
							} else if len(e.using) == 1 && !e.using[0].isExpr {
								n = e.using[0].col
							}
						}
						if n >= 1 && n <= len(rec.fields) {
							c.title = strings.Trim(rec.fields[n-1], "\"")
						}
					}
					continue
				}
				firstLine = false
				if !inBlock || li < every[2] || (every[4] >= 0 && li > every[4]) || (li-every[2])%every[0] != 0 {
					rowNum++
					continue
				}
				curRow = rec.fields
				curRowNum = rowNum
				pt, valid := evalUsing(e, rec, rowNum, ncols)
				rowNum++
				if !valid {
					continue
				}
				// range check
				if pt.typ == ptIn {
					if !xa.inRange(pt.x) || !ax["y"].inRange(pt.y) {
						pt.typ = ptOut
					}
					if (xa.log && pt.x <= 0) || (ax["y"].log && pt.y <= 0) {
						pt.typ = ptUndef
					}
				}
				c.points = append(c.points, pt)
			}
			if len(c.points) > 0 {
				c.points[len(c.points)-1].blockEnd = true
			}
		}
	}
	c.ncols = ncols
	if ncols == 0 {
		c.ncols = 2
	}
	return c
}

var lastUsingCols int

func evalUsing(e *PlotElem, rec DataRec, rowNum int, ncols int) (Point, bool) {
	var pt Point
	var vals []float64
	undef := false
	if ncols == 0 {
		// default
		f := rec.fields
		need := 2
		switch e.style {
		case "yerrorbars", "xerrorbars", "errorbars", "boxes", "yerrorlines", "xerrorlines", "errorlines", "labels":
			need = 3
		case "xyerrorbars", "xyerrorlines", "boxxyerrorbars", "vectors", "financebars", "candlesticks":
			need = 4
		}
		if len(f) == 0 {
			return pt, false
		}
		if len(f) == 1 {
			v, ok := fieldValue(f[0])
			if !ok {
				return pt, false
			}
			vals = []float64{float64(rowNum), v}
		} else {
			for k := 0; k < len(f) && k < need; k++ {
				v, ok := fieldValue(f[k])
				if !ok {
					if S.missing != "" && f[k] == S.missing {
						return pt, false
					}
					return pt, false
				}
				vals = append(vals, v)
			}
		}
	} else {
		for _, u := range e.using {
			if u.special == "xtic" {
				undefFlag = false
				v := u.expr(&Frame{})
				pt.xtic = valueToString(v)
				pt.hasXtic = true
				continue
			}
			if u.isExpr {
				undefFlag = false
				colInvalid = false
				v := u.expr(&Frame{})
				if v.t == STR {
					if e.style == "labels" {
						pt.label = v.s
						continue
					}
					f, ok := parseFieldNum(v.s)
					if !ok {
						undef = true
					}
					vals = append(vals, f)
					continue
				}
				f := realOf(v)
				if undefFlag || math.IsNaN(f) {
					undef = true
				}
				vals = append(vals, f)
				continue
			}
			if u.col == 0 {
				vals = append(vals, float64(rowNum))
				continue
			}
			if u.col == -1 {
				vals = append(vals, float64(curBlockNum))
				continue
			}
			if u.col == -2 {
				vals = append(vals, float64(curIndexNum))
				continue
			}
			if u.col > len(rec.fields) {
				return pt, false
			}
			if e.style == "labels" && len(vals) >= 2 {
				pt.label = strings.Trim(rec.fields[u.col-1], "\"")
				continue
			}
			v, ok := fieldValue(rec.fields[u.col-1])
			if !ok {
				if S.missing != "" && rec.fields[u.col-1] == S.missing {
					undef = true
					vals = append(vals, math.NaN())
					continue
				}
				return pt, false
			}
			vals = append(vals, v)
		}
		if len(vals) == 1 {
			vals = []float64{float64(rowNum), vals[0]}
		}
	}
	if len(vals) < 2 {
		if len(vals) == 1 {
			vals = append([]float64{float64(rowNum)}, vals...)
		} else {
			return pt, false
		}
	}
	pt.x, pt.y = vals[0], vals[1]
	pt.ex = vals[2:]
	if undef {
		pt.typ = ptUndef
	}
	return pt, true
}

// ---------- table output ----------

func tableWrite(s string) {
	if S.tableDB != "" {
		parts := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
		datablocks[S.tableDB] = append(datablocks[S.tableDB], parts...)
		return
	}
	if S.tableOut != nil {
		S.tableOut.WriteString(s)
		return
	}
	if S.outFile != nil {
		S.outFile.WriteString(s)
		return
	}
	stdout.WriteString(s)
}

func tfmt(v float64) string {
	if math.IsNaN(v) {
		return " NaN"
	}
	if math.IsInf(v, 1) {
		return " inf"
	}
	if math.IsInf(v, -1) {
		return "-inf"
	}
	return cfmt("% g", v)
}

func typeChar(t int) string {
	switch t {
	case ptOut:
		return "o"
	case ptUndef:
		return "u"
	}
	return "i"
}

func writeTable(curves []*Curve) {
	var sb strings.Builder
	n := len(curves)
	for k, c := range curves {
		np := len(c.points)
		for i, pt := range c.points {
			if pt.blockEnd && i < len(c.points)-1 {
				np++
			}
		}
		sb.WriteString(fmt.Sprintf("\n# Curve %d of %d, %d points\n", k, n, np))
		if !c.noTitle {
			sb.WriteString(fmt.Sprintf("# Curve title: \"%s\"\n", c.title))
		}
		hdr := "# x y type"
		switch c.style {
		case "yerrorbars", "yerrorlines", "errorbars", "errorlines":
			hdr = "# x y ylow yhigh type"
		case "xerrorbars", "xerrorlines":
			hdr = "# x y xlow xhigh type"
		case "boxes":
			hdr = "# x y xlow xhigh type"
		case "xyerrorbars", "xyerrorlines":
			hdr = "# x y xlow xhigh ylow yhigh type"
		case "labels":
			hdr = "# x y label type"
		}
		sb.WriteString(hdr + "\n")
		for i, pt := range c.points {
			line := tfmt(pt.x) + " " + tfmt(pt.y)
			switch c.style {
			case "yerrorbars", "yerrorlines", "errorbars", "errorlines":
				lo, hi := pt.y, pt.y
				if len(pt.ex) == 1 {
					lo, hi = pt.y-pt.ex[0], pt.y+pt.ex[0]
				} else if len(pt.ex) >= 2 {
					lo, hi = pt.ex[0], pt.ex[1]
				}
				line += " " + tfmt(lo) + " " + tfmt(hi)
			case "xerrorbars", "xerrorlines":
				lo, hi := pt.x, pt.x
				if len(pt.ex) == 1 {
					lo, hi = pt.x-pt.ex[0], pt.x+pt.ex[0]
				} else if len(pt.ex) >= 2 {
					lo, hi = pt.ex[0], pt.ex[1]
				}
				line += " " + tfmt(lo) + " " + tfmt(hi)
			case "xyerrorbars", "xyerrorlines":
				xl, xh, yl, yh := pt.x, pt.x, pt.y, pt.y
				if len(pt.ex) == 2 {
					xl, xh = pt.x-pt.ex[0], pt.x+pt.ex[0]
					yl, yh = pt.y-pt.ex[1], pt.y+pt.ex[1]
				} else if len(pt.ex) >= 4 {
					xl, xh, yl, yh = pt.ex[0], pt.ex[1], pt.ex[2], pt.ex[3]
				}
				line += " " + tfmt(xl) + " " + tfmt(xh) + " " + tfmt(yl) + " " + tfmt(yh)
			case "boxes":
				w := boxWidthAt(c, i)
				line += " " + tfmt(pt.x-w/2) + " " + tfmt(pt.x+w/2)
			case "labels":
				lab := pt.label
				if lab == "" && len(pt.ex) > 0 {
					lab = fmtLabelNum(pt.ex[0])
				}
				sb.WriteString(line + " \"" + lab + "\"\n")
				if pt.blockEnd && i < len(c.points)-1 {
					sb.WriteString("\n")
				}
				continue
			}
			sb.WriteString(line + "  " + typeChar(pt.typ) + "\n")
			if pt.blockEnd && i < len(c.points)-1 {
				sb.WriteString("\n")
			}
		}
		sb.WriteString("\n")
	}
	tableWrite(sb.String())
}

func fmtLabelNum(v float64) string {
	return cfmt("%g", v)
}

func boxWidthAt(c *Curve, i int) float64 {
	pt := c.points[i]
	if len(pt.ex) >= 1 {
		return pt.ex[0]
	}
	if S.boxwidthSet && S.boxwidthAbs {
		return S.boxwidth
	}
	frac := 1.0
	if S.boxwidthSet {
		frac = S.boxwidth
	}
	n := len(c.points)
	if n < 2 {
		return 1 * frac
	}
	var w float64
	if i == 0 {
		w = c.points[1].x - pt.x
	} else if i == n-1 {
		w = pt.x - c.points[i-1].x
	} else {
		w = (c.points[i+1].x - c.points[i-1].x) / 2
	}
	return math.Abs(w) * frac
}

// ---------- smoothing ----------

func applySmooth(c *Curve, e *PlotElem, ax map[string]*Axis) {
	if e.smooth == "bins" || e.smooth == "kdensity" {
		applySmooth1(c, e, ax)
		return
	}
	var blocks [][]Point
	var cur []Point
	for _, p := range c.points {
		cur = append(cur, p)
		if p.blockEnd {
			blocks = append(blocks, cur)
			cur = nil
		}
	}
	if len(cur) > 0 {
		blocks = append(blocks, cur)
	}
	var out []Point
	for bi, b := range blocks {
		cc := &Curve{points: b}
		applySmooth1(cc, e, ax)
		if len(cc.points) == 0 {
			continue
		}
		if bi > 0 && len(out) > 0 {
			if e.smooth == "bezier" {
				out = append(out, Point{typ: ptUndef})
			} else {
				out[len(out)-1].blockEnd = true
			}
		}
		out = append(out, cc.points...)
	}
	c.points = out
}

func applySmooth1(c *Curve, e *PlotElem, ax map[string]*Axis) {
	var pts []Point
	for _, p := range c.points {
		if p.typ != ptUndef {
			pts = append(pts, p)
		}
	}
	sort.SliceStable(pts, func(i, j int) bool { return pts[i].x < pts[j].x })
	switch e.smooth {
	case "unique", "frequency", "cumulative", "cnormal", "fnormal":
		var out []Point
		for i := 0; i < len(pts); {
			j := i
			sum := 0.0
			for j < len(pts) && pts[j].x == pts[i].x {
				sum += pts[j].y
				j++
			}
			y := sum
			if e.smooth == "unique" {
				y = sum / float64(j-i)
			}
			out = append(out, Point{x: pts[i].x, y: y})
			i = j
		}
		if e.smooth == "cumulative" || e.smooth == "cnormal" {
			acc := 0.0
			for k := range out {
				acc += out[k].y
				out[k].y = acc
			}
			if e.smooth == "cnormal" && acc != 0 {
				for k := range out {
					out[k].y /= acc
				}
			}
		}
		if e.smooth == "fnormal" {
			tot := 0.0
			for _, p := range out {
				tot += p.y
			}
			for k := range out {
				out[k].y /= tot
			}
		}
		for k := range out {
			if !ax["x"].inRange(out[k].x) || !ax["y"].inRange(out[k].y) {
				out[k].typ = ptOut
			}
		}
		c.points = out
	case "csplines", "acsplines", "mcsplines", "bezier", "sbezier":
		c.points = splineSmooth(pts, e.smooth, ax)
	case "kdensity":
		c.points = kdensity(pts, ax)
	case "bins":
		c.points = binData(pts, e, ax)
	}
	for k := range c.points {
		c.points[k].blockEnd = false
	}
}

func binData(pts []Point, e *PlotElem, ax map[string]*Axis) []Point {
	n := e.binsN
	if n <= 0 {
		n = S.samples1
	}
	if len(pts) == 0 {
		return nil
	}
	lo, hi := pts[0].x, pts[0].x
	for _, p := range pts {
		lo = math.Min(lo, p.x)
		hi = math.Max(hi, p.x)
	}
	if e.binRangeSet {
		lo, hi = e.binLo, e.binHi
	}
	var w float64
	if e.hasBinW {
		w = e.binW
		n = int(math.Ceil((hi - lo) / w))
		if n < 1 {
			n = 1
		}
		if !e.binRangeSet {
			// bins centered on multiples of width
			lo = math.Floor(lo/w+0.5)*w - w/2
			n = int((hi-lo)/w) + 1
		}
	} else {
		w = (hi - lo) / float64(n)
		if !e.binRangeSet {
			w = (hi - lo) / float64(n-1)
			lo -= w / 2
		}
	}
	counts := make([]float64, n)
	for _, p := range pts {
		k := int(math.Floor((p.x - lo) / w))
		if k == n && p.x == hi {
			k = n - 1
		}
		if k >= 0 && k < n {
			counts[k] += p.y
		}
	}
	var out []Point
	for k := 0; k < n; k++ {
		x := lo + (float64(k)+0.5)*w
		pt := Point{x: x, y: counts[k]}
		if !ax["x"].inRange(x) || !ax["y"].inRange(pt.y) {
			pt.typ = ptOut
		}
		out = append(out, pt)
	}
	return out
}

func kdensity(pts []Point, ax map[string]*Axis) []Point {
	n := len(pts)
	if n == 0 {
		return nil
	}
	// bandwidth: default from stddev
	mean, sq := 0.0, 0.0
	tot := 0.0
	for _, p := range pts {
		mean += p.x
		tot += p.y
	}
	mean /= float64(n)
	for _, p := range pts {
		sq += (p.x - mean) * (p.x - mean)
	}
	sigma := math.Sqrt(sq / float64(n))
	bw := 1.06 * sigma * math.Pow(float64(n), -0.2)
	lo, hi := pts[0].x, pts[n-1].x
	xa := ax["x"]
	if !xa.autoMin {
		lo = xa.min
	}
	if !xa.autoMax {
		hi = xa.max
	}
	if xa.autoMin {
		lo -= bw * 3
	}
	if xa.autoMax {
		hi += bw * 3
	}
	var out []Point
	ns := S.samples1
	for i := 0; i < ns; i++ {
		x := lo + float64(i)*(hi-lo)/float64(ns-1)
		y := 0.0
		for _, p := range pts {
			z := (x - p.x) / bw
			y += p.y * math.Exp(-0.5*z*z) / (bw * math.Sqrt(2*math.Pi))
		}
		out = append(out, Point{x: x, y: y})
	}
	return out
}

func splineSmooth(pts []Point, kind string, ax map[string]*Axis) []Point {
	// merge equal x (average) for splines
	var xs, ys, ws []float64
	for i := 0; i < len(pts); {
		j := i
		sy, sw := 0.0, 0.0
		for j < len(pts) && pts[j].x == pts[i].x {
			w := 1.0
			if kind == "acsplines" && len(pts[j].ex) > 0 {
				w = pts[j].ex[0]
			}
			sy += pts[j].y
			sw += w
			j++
		}
		xs = append(xs, pts[i].x)
		ys = append(ys, sy/float64(j-i))
		ws = append(ws, sw)
		i = j
	}
	n := len(xs)
	if n == 0 {
		return nil
	}
	ns := S.samples1
	lo, hi := xs[0], xs[n-1]
	var out []Point
	var eval func(x float64) float64
	switch kind {
	case "csplines", "acsplines":
		if kind == "acsplines" {
			ys = smoothingSpline(xs, ys, ws)
		}
		if n < 3 {
			eval = func(x float64) float64 {
				if n == 1 {
					return ys[0]
				}
				return ys[0] + (ys[1]-ys[0])*(x-xs[0])/(xs[1]-xs[0])
			}
		} else {
			m := naturalSpline(xs, ys)
			eval = func(x float64) float64 { return evalCubic(xs, ys, m, x) }
		}
	case "mcsplines":
		eval = monotoneSpline(xs, ys)
	case "bezier", "sbezier":
		bx, by := xs, ys
		if kind == "sbezier" {
			// first csplines-like smoothing via bezier of points
		}
		out = nil
		for i := 0; i < ns; i++ {
			t := float64(i) / float64(ns-1)
			x, y := bezierPoint(bx, by, t)
			pt := Point{x: x, y: y}
			if !ax["x"].inRange(x) || !ax["y"].inRange(y) {
				pt.typ = ptOut
			}
			out = append(out, pt)
		}
		return out
	}
	for i := 0; i < ns; i++ {
		x := lo + float64(i)*(hi-lo)/float64(ns-1)
		y := eval(x)
		pt := Point{x: x, y: y}
		if !ax["x"].inRange(x) || !ax["y"].inRange(y) {
			pt.typ = ptOut
		}
		out = append(out, pt)
	}
	return out
}

func bezierPoint(xs, ys []float64, t float64) (float64, float64) {
	n := len(xs) - 1
	x, y := 0.0, 0.0
	for k := 0; k <= n; k++ {
		b := binom(n, k) * math.Pow(t, float64(k)) * math.Pow(1-t, float64(n-k))
		x += b * xs[k]
		y += b * ys[k]
	}
	return x, y
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func naturalSpline(x, y []float64) []float64 {
	n := len(x)
	m := make([]float64, n)
	a := make([]float64, n)
	b := make([]float64, n)
	c := make([]float64, n)
	d := make([]float64, n)
	for i := 1; i < n-1; i++ {
		h0 := x[i] - x[i-1]
		h1 := x[i+1] - x[i]
		a[i] = h0
		b[i] = 2 * (h0 + h1)
		c[i] = h1
		d[i] = 6 * ((y[i+1]-y[i])/h1 - (y[i]-y[i-1])/h0)
	}
	// solve tridiagonal for m[1..n-2]
	for i := 2; i < n-1; i++ {
		w := a[i] / b[i-1]
		b[i] -= w * c[i-1]
		d[i] -= w * d[i-1]
	}
	for i := n - 2; i >= 1; i-- {
		m[i] = (d[i] - c[i]*m[i+1]) / b[i]
		if i == n-2 {
			m[i] = d[i] / b[i]
		}
	}
	return m
}

func evalCubic(x, y, m []float64, t float64) float64 {
	n := len(x)
	i := 0
	for i < n-2 && t > x[i+1] {
		i++
	}
	h := x[i+1] - x[i]
	A := (x[i+1] - t) / h
	B := (t - x[i]) / h
	return A*y[i] + B*y[i+1] + ((A*A*A-A)*m[i]+(B*B*B-B)*m[i+1])*h*h/6
}

func monotoneSpline(x, y []float64) func(float64) float64 {
	n := len(x)
	if n < 2 {
		return func(float64) float64 { return y[0] }
	}
	d := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		d[i] = (y[i+1] - y[i]) / (x[i+1] - x[i])
	}
	m := make([]float64, n)
	m[0] = d[0]
	m[n-1] = d[n-2]
	for i := 1; i < n-1; i++ {
		if d[i-1]*d[i] <= 0 {
			m[i] = 0
		} else {
			m[i] = (d[i-1] + d[i]) / 2
		}
	}
	for i := 0; i < n-1; i++ {
		if d[i] == 0 {
			m[i], m[i+1] = 0, 0
			continue
		}
		a := m[i] / d[i]
		b := m[i+1] / d[i]
		s := a*a + b*b
		if s > 9 {
			t := 3 / math.Sqrt(s)
			m[i] = t * a * d[i]
			m[i+1] = t * b * d[i]
		}
	}
	return func(t float64) float64 {
		i := 0
		for i < n-2 && t > x[i+1] {
			i++
		}
		h := x[i+1] - x[i]
		s := (t - x[i]) / h
		h00 := 2*s*s*s - 3*s*s + 1
		h10 := s*s*s - 2*s*s + s
		h01 := -2*s*s*s + 3*s*s
		h11 := s*s*s - s*s
		return h00*y[i] + h10*h*m[i] + h01*y[i+1] + h11*h*m[i+1]
	}
}

func smoothingSpline(x, y, w []float64) []float64 {
	return y
}
