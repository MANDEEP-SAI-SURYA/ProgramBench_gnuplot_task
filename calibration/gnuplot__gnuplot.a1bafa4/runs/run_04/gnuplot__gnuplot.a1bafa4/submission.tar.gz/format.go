package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// cfmt formats a single C-style spec with a float or int argument.
func cfmt(spec string, x float64) string {
	return cfmtV(spec, RealV(x))
}

// parse spec: %[flags][width][.prec]conv
type cspec struct {
	flags string
	width string
	prec  string
	hasP  bool
	conv  byte
}

func parseSpec(s string) (cspec, int) { return parseSpecM(s, true) }
func parseSpecM(s string, mods bool) (cspec, int) {
	// s starts at '%'; returns spec and length consumed
	var c cspec
	i := 1
	for i < len(s) && strings.IndexByte("-+ 0#'", s[i]) >= 0 {
		if s[i] != '\'' {
			c.flags += string(s[i])
		}
		i++
	}
	for i < len(s) && isDigit(s[i]) {
		c.width += string(s[i])
		i++
	}
	if i < len(s) && s[i] == '.' {
		c.hasP = true
		i++
		for i < len(s) && isDigit(s[i]) {
			c.prec += string(s[i])
			i++
		}
	}
	// length modifiers
	for mods && i < len(s) && strings.IndexByte("hlLqjzt", s[i]) >= 0 {
		i++
	}
	if i < len(s) {
		c.conv = s[i]
		i++
	}
	return c, i
}

func (c cspec) gofmt(conv string) string {
	s := "%" + c.flags + c.width
	if c.hasP {
		p := c.prec
		if p == "" {
			p = "0"
		}
		s += "." + p
	}
	return s + conv
}

func padStr(s string, c cspec) string {
	w, _ := strconv.Atoi(c.width)
	if len(s) >= w {
		return s
	}
	if strings.Contains(c.flags, "-") {
		return s + strings.Repeat(" ", w-len(s))
	}
	return strings.Repeat(" ", w-len(s)) + s
}

func cfmtV(spec string, v Value) string {
	c, _ := parseSpec(spec)
	return c.format(v)
}

func (c cspec) format(v Value) string {
	switch c.conv {
	case 'd', 'i':
		var n int64
		if v.t == INT {
			n = v.i
		} else {
			f := realOf(v)
			n = int64(f)
		}
		return fmt.Sprintf(c.gofmt("d"), n)
	case 'u':
		var n int64
		if v.t == INT {
			n = v.i
		} else {
			n = int64(realOf(v))
		}
		return fmt.Sprintf(c.gofmt("d"), uint64(n))
	case 'x', 'X', 'o':
		var n int64
		if v.t == INT {
			n = v.i
		} else {
			n = int64(realOf(v))
		}
		return fmt.Sprintf(c.gofmt(string(c.conv)), uint64(n))
	case 'c':
		var n int64
		if v.t == INT {
			n = v.i
		} else {
			n = int64(realOf(v))
		}
		return padStr(string([]byte{byte(n)}), c)
	case 'e', 'E', 'f', 'F', 'g', 'G', 'a', 'A':
		f := realOf(v)
		if math.IsNaN(f) || math.IsInf(f, 0) {
			var s string
			if math.IsNaN(f) {
				s = "nan"
			} else if f > 0 {
				s = "inf"
				if strings.Contains(c.flags, "+") {
					s = "+inf"
				} else if strings.Contains(c.flags, " ") {
					s = " inf"
				}
			} else {
				s = "-inf"
			}
			if c.conv >= 'A' && c.conv <= 'Z' {
				s = strings.ToUpper(s)
			}
			c2 := c
			c2.flags = strings.ReplaceAll(c2.flags, "0", "")
			return padStr(s, c2)
		}
		conv := string(c.conv)
		if conv == "F" {
			conv = "f"
		}
		cc := c
		if (conv == "g" || conv == "G") && !cc.hasP {
			cc.hasP = true
			cc.prec = "6"
		}
		if (conv == "g" || conv == "G") && cc.prec == "0" {
			cc.prec = "1"
		}
		s := fmt.Sprintf(cc.gofmt(conv), f)
		return s
	case 's':
		return fmt.Sprintf(c.gofmt("s"), valueToString(v))
	}
	return ""
}

func gpSprintf(a []Value) string {
	if a[0].t != STR {
		rterr("sprintf: first parameter must be a format string")
	}
	f := a[0].s
	args := a[1:]
	var sb strings.Builder
	ai := 0
	for i := 0; i < len(f); {
		if f[i] != '%' {
			sb.WriteByte(f[i])
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		c, n := parseSpec(f[i:])
		if ai >= len(args) {
			sb.WriteString(f[i : i+n])
			i += n
			continue
		}
		v := args[ai]
		ai++
		switch c.conv {
		case 's':
			if v.t != STR {
				rterr("f_sprintf: attempt to print numeric value with string format")
			}
			sb.WriteString(fmt.Sprintf(c.gofmt("s"), v.s))
		default:
			if v.t == STR {
				rterr("f_sprintf: attempt to print string value with numeric format")
			}
			sb.WriteString(c.format(v))
		}
		i += n
	}
	return sb.String()
}

// ---------------- gprintf ----------------
var logBaseForFormat = 0.0

func mantExp(x float64, base float64) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	p := int(math.Floor(math.Log(math.Abs(x)) / math.Log(base)))
	m := x / math.Pow(base, float64(p))
	return m, p
}

func gprintf(format string, x float64) string {
	var sb strings.Builder
	tprec := 6
	for i := 0; i < len(format); {
		ch := format[i]
		if ch != '%' {
			sb.WriteByte(ch)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		c, n := parseSpecM(format[i:], false)
		i += n
		switch c.conv {
		case 'f', 'F', 'e', 'E', 'g', 'G':
			sb.WriteString(c.format(RealV(x)))
		case 'x', 'X', 'o', 'O', 'd', 'i':
			if c.conv == 'O' {
				c.conv = 'o'
			}
			sb.WriteString(c.format(RealV(x)))
		case 't', 'T', 's', 'S', 'c':
			// base-10 mantissa / exponent
			step := 1
			if c.conv == 's' || c.conv == 'S' || c.conv == 'c' {
				step = 3
			}
			m, p := mantExp(x, 10)
			if step == 3 {
				pp := int(math.Floor(float64(p) / 3))
				pp *= 3
				m = x / math.Pow(10, float64(pp))
				p = pp
				if x == 0 {
					m, p = 0, 0
				}
			}
			// check rounding of mantissa
			if x != 0 {
				prec := tprec
				if c.hasP && (c.conv == 't' || c.conv == 's') {
					prec, _ = strconv.Atoi(c.prec)
					tprec = prec
				}
				ms := strconv.FormatFloat(math.Abs(m), 'f', prec, 64)
				mv, _ := strconv.ParseFloat(ms, 64)
				lim := 10.0
				if step == 3 {
					lim = 1000
				}
				if mv >= lim {
					m /= lim
					p += step
				}
			}
			switch c.conv {
			case 't', 's':
				c.conv = 'f'
				sb.WriteString(c.format(RealV(m)))
			case 'T', 'S':
				c.conv = 'd'
				sb.WriteString(c.format(IntV(int64(p))))
			case 'c':
				pre := "yzafpnum kMGTPEZY"
				idx := p/3 + 8
				if idx >= 0 && idx < len(pre) {
					if pre[idx] != ' ' {
						if pre[idx] == 'u' {
							sb.WriteString("u")
						} else {
							sb.WriteByte(pre[idx])
						}
					}
				}
			}
		case 'l', 'L':
			base := logBaseForFormat
			var m float64
			var p int
			if base <= 1 {
				m, p = x, 0
			} else {
				m, p = mantExp(x, base)
			}
			if c.conv == 'l' {
				c.conv = 'f'
				sb.WriteString(c.format(RealV(m)))
			} else {
				c.conv = 'd'
				sb.WriteString(c.format(IntV(int64(p))))
			}
		case 'b', 'B':
			m, p := x, 0
			if x != 0 {
				p = int(math.Floor(math.Log2(math.Abs(x)) / 10))
				m = x / math.Pow(1024, float64(p))
			}
			if c.conv == 'b' {
				c.conv = 'f'
				sb.WriteString(c.format(RealV(m)))
			} else {
				pre := []string{"", "ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"}
				if p >= 0 && p < len(pre) {
					sb.WriteString(pre[p])
				}
			}
		case 'P':
			c.conv = 'f'
			sb.WriteString(c.format(RealV(x / math.Pi)))
		case 'h', 'H':
			if c.conv == 'H' {
				c.conv = 'G'
			} else {
				c.conv = 'g'
			}
			sb.WriteString(c.format(RealV(x)))
		default:
			sb.WriteString(format[i-n : i])
		}
	}
	return sb.String()
}

// ---------------- time ----------------
var timefmt = "%d/%m/%y,%H:%M"

var monthNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func toTime(t float64) time.Time {
	sec := math.Floor(t)
	ns := int64((t - sec) * 1e9)
	return time.Unix(int64(sec), ns).UTC()
}

func tmField(x float64, f byte) int {
	t := toTime(x)
	switch f {
	case 's':
		return t.Second()
	case 'm':
		return t.Minute()
	case 'h':
		return t.Hour()
	case 'd':
		return t.Day()
	case 'M':
		return int(t.Month()) - 1
	case 'y':
		return t.Year()
	case 'w':
		return int(t.Weekday())
	case 'j':
		return t.YearDay() - 1
	}
	return 0
}

func gstrftime(f string, x float64) string {
	t := toTime(x)
	var sb strings.Builder
	for i := 0; i < len(f); i++ {
		if f[i] != '%' || i+1 >= len(f) {
			sb.WriteByte(f[i])
			continue
		}
		i++
		// optional precision for %S e.g. %.3S
		prec := -1
		width := ""
		for i < len(f) && (isDigit(f[i]) || f[i] == '0') {
			width += string(f[i])
			i++
		}
		if f[i] == '.' && i+1 < len(f) && isDigit(f[i+1]) {
			prec = int(f[i+1] - '0')
			i += 2
		}
		if i >= len(f) {
			break
		}
		switch f[i] {
		case 'a':
			sb.WriteString(dayNames[t.Weekday()][:3])
		case 'A':
			sb.WriteString(dayNames[t.Weekday()])
		case 'b', 'h':
			sb.WriteString(monthNames[t.Month()-1][:3])
		case 'B':
			sb.WriteString(monthNames[t.Month()-1])
		case 'd':
			sb.WriteString(fmt.Sprintf("%02d", t.Day()))
		case 'e':
			sb.WriteString(fmt.Sprintf("%2d", t.Day()))
		case 'D':
			sb.WriteString(fmt.Sprintf("%02d/%02d/%02d", t.Month(), t.Day(), t.Year()%100))
		case 'F':
			sb.WriteString(fmt.Sprintf("%d-%02d-%02d", t.Year(), t.Month(), t.Day()))
		case 'H', 'k':
			sb.WriteString(fmt.Sprintf("%02d", t.Hour()))
		case 'I', 'l':
			h := t.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(fmt.Sprintf("%02d", h))
		case 'j':
			sb.WriteString(fmt.Sprintf("%03d", t.YearDay()))
		case 'm':
			sb.WriteString(fmt.Sprintf("%02d", t.Month()))
		case 'M':
			sb.WriteString(fmt.Sprintf("%02d", t.Minute()))
		case 'n':
			sb.WriteByte('\n')
		case 't':
			sb.WriteByte('\t')
		case 'p':
			if t.Hour() < 12 {
				sb.WriteString("AM")
			} else {
				sb.WriteString("PM")
			}
		case 'r':
			h := t.Hour() % 12
			if h == 0 {
				h = 12
			}
			ap := "AM"
			if t.Hour() >= 12 {
				ap = "PM"
			}
			sb.WriteString(fmt.Sprintf("%02d:%02d:%02d %s", h, t.Minute(), t.Second(), ap))
		case 'R':
			sb.WriteString(fmt.Sprintf("%02d:%02d", t.Hour(), t.Minute()))
		case 'S':
			if prec > 0 {
				s := x - math.Floor(x/60)*60
				sb.WriteString(fmt.Sprintf("%0*.*f", prec+3, prec, s))
			} else {
				sb.WriteString(fmt.Sprintf("%02d", t.Second()))
			}
		case 's':
			sb.WriteString(fmt.Sprintf("%d", int64(math.Floor(x))))
		case 'T':
			sb.WriteString(fmt.Sprintf("%02d:%02d:%02d", t.Hour(), t.Minute(), t.Second()))
		case 'U':
			sb.WriteString(fmt.Sprintf("%02d", (t.YearDay()+6-int(t.Weekday()))/7))
		case 'w':
			sb.WriteString(fmt.Sprintf("%d", t.Weekday()))
		case 'y':
			sb.WriteString(fmt.Sprintf("%02d", t.Year()%100))
		case 'Y':
			sb.WriteString(fmt.Sprintf("%d", t.Year()))
		case '%':
			sb.WriteByte('%')
		default:
			sb.WriteByte('%')
			sb.WriteByte(f[i])
		}
	}
	return sb.String()
}

func gstrptime(s, f string) (float64, bool) {
	year, mon, day, hour, min_, sec := 1970, 1, 1, 0, 0, 0.0
	yday := -1
	epoch := math.NaN()
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		neg := false
		if si < len(s) && (s[si] == '-' || s[si] == '+') {
			neg = s[si] == '-'
			si++
		}
		st := si
		for si < len(s) && si-st < maxd && isDigit(s[si]) {
			si++
		}
		if si == st {
			return 0, false
		}
		v, _ := strconv.Atoi(s[st:si])
		if neg {
			v = -v
		}
		return v, true
	}
	pm := -1
	for fi := 0; fi < len(f); fi++ {
		if f[fi] != '%' {
			if f[fi] == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == f[fi] {
				si++
			} else {
				return 0, false
			}
			continue
		}
		fi++
		if fi >= len(f) {
			break
		}
		var ok bool
		switch f[fi] {
		case 'd', 'e':
			day, ok = readInt(2)
		case 'm':
			mon, ok = readInt(2)
		case 'y':
			var y int
			y, ok = readInt(2)
			if y < 69 {
				year = 2000 + y
			} else {
				year = 1900 + y
			}
		case 'Y':
			year, ok = readInt(4)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min_, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			for si < len(s) && s[si] == ' ' {
				si++
			}
			st := si
			for si < len(s) && (isDigit(s[si]) || s[si] == '.' || (si == st && s[si] == '-')) {
				si++
			}
			sec, _ = strconv.ParseFloat(s[st:si], 64)
			ok = si > st
		case 's':
			st := si
			for si < len(s) && (isDigit(s[si]) || s[si] == '.' || s[si] == '-') {
				si++
			}
			epoch, _ = strconv.ParseFloat(s[st:si], 64)
			ok = si > st
		case 'b', 'h', 'B':
			ok = false
			for k, mn := range monthNames {
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(mn)) && f[fi] == 'B' {
					mon = k + 1
					si += len(mn)
					ok = true
					break
				}
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(mn[:3])) {
					mon = k + 1
					si += 3
					ok = true
					break
				}
			}
		case 'p':
			if strings.HasPrefix(strings.ToUpper(s[si:]), "PM") {
				pm = 1
				si += 2
			} else if strings.HasPrefix(strings.ToUpper(s[si:]), "AM") {
				pm = 0
				si += 2
			}
			ok = true
		case 'a', 'A':
			for si < len(s) && s[si] != ' ' {
				si++
			}
			ok = true
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if !math.IsNaN(epoch) {
		return epoch, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	t := time.Date(year, time.Month(mon), day, hour, min_, 0, 0, time.UTC)
	if yday >= 0 {
		t = time.Date(year, 1, 1, hour, min_, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	}
	return float64(t.Unix()) + sec, true
}
