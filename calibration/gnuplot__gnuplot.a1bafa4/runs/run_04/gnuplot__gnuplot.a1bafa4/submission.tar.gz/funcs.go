package main

import (
	"fmt"
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

type UDF struct {
	name    string
	params  []string
	body    Expr
	defText string
}

var udfs = map[string]*UDF{}
var vars = map[string]Value{}
var datablocks = map[string][]string{}
var angleDegrees = false

type builtin struct {
	min, max int
	fn       func(a []Value) Value
}

var builtins map[string]builtin

func ang(x float64) float64 { // input angle conversion
	if angleDegrees {
		return x * math.Pi / 180
	}
	return x
}
func angOut(x float64) float64 {
	if angleDegrees {
		return x * 180 / math.Pi
	}
	return x
}

func real1(f func(float64) float64) builtin {
	return builtin{1, 1, func(a []Value) Value {
		v := toNum(a[0])
		return RealV(f(realOf(v)))
	}}
}

func cmplxOrReal(fr func(float64) (float64, bool), fc func(complex128) complex128) builtin {
	return builtin{1, 1, func(a []Value) Value {
		v := toNum(a[0])
		if v.t == INT || v.im == 0 {
			if r, ok := fr(realOf(v)); ok {
				return RealV(r)
			}
		}
		return fromC(fc(asC(v)))
	}}
}

func chkUndef(x float64) Value {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		undefFlag = true
	}
	return RealV(x)
}

func init() {
	builtins = map[string]builtin{
		"abs": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				if v.i < 0 {
					return IntV(-v.i)
				}
				return v
			}
			if v.im == 0 {
				return RealV(math.Abs(v.r))
			}
			return RealV(cmplx.Abs(asC(v)))
		}},
		"sgn": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			x := realOf(v)
			if x > 0 {
				return IntV(1)
			} else if x < 0 {
				return IntV(-1)
			}
			return IntV(0)
		}},
		"real": {1, 1, func(a []Value) Value { v := toNum(a[0]); return RealV(realOf(v)) }},
		"imag": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				return RealV(0)
			}
			return RealV(v.im)
		}},
		"arg": {1, 1, func(a []Value) Value { v := toNum(a[0]); return RealV(angOut(cmplx.Phase(asC(v)))) }},
		"conj": {1, 1, func(a []Value) Value { v := toNum(a[0]); return CmplxV(realOf(v), -v.im) }},
		"int": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				return v
			}
			if math.IsNaN(v.r) || math.Abs(v.r) >= 9.2233720368547758e18 {
				return RealV(math.NaN())
			}
			return IntV(int64(v.r))
		}},
		"floor": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				return v
			}
			return IntV(int64(math.Floor(v.r)))
		}},
		"ceil": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				return v
			}
			return IntV(int64(math.Ceil(v.r)))
		}},
		"round": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT {
				return v
			}
			return IntV(int64(math.Round(v.r)))
		}},
		"sqrt": cmplxOrReal(func(x float64) (float64, bool) { return math.Sqrt(x), x >= 0 }, cmplx.Sqrt),
		"exp": cmplxOrReal(func(x float64) (float64, bool) { return math.Exp(x), true }, cmplx.Exp),
		"log": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT || v.im == 0 {
				x := realOf(v)
				if x > 0 {
					return RealV(math.Log(x))
				}
				if x == 0 {
					undefFlag = true
					return RealV(0)
				}
			}
			return fromC(cmplx.Log(asC(v)))
		}},
		"log10": {1, 1, func(a []Value) Value {
			v := toNum(a[0])
			if v.t == INT || v.im == 0 {
				x := realOf(v)
				if x > 0 {
					return RealV(math.Log10(x))
				}
				if x == 0 {
					undefFlag = true
					return RealV(0)
				}
			}
			return fromC(cmplx.Log10(asC(v)))
		}},
		"sin": cmplxOrReal(func(x float64) (float64, bool) { return math.Sin(ang(x)), true }, cmplx.Sin),
		"cos": cmplxOrReal(func(x float64) (float64, bool) { return math.Cos(ang(x)), true }, cmplx.Cos),
		"tan": cmplxOrReal(func(x float64) (float64, bool) { return math.Tan(ang(x)), true }, cmplx.Tan),
		"sinh": cmplxOrReal(func(x float64) (float64, bool) { return math.Sinh(ang(x)), true }, cmplx.Sinh),
		"cosh": cmplxOrReal(func(x float64) (float64, bool) { return math.Cosh(ang(x)), true }, cmplx.Cosh),
		"tanh": cmplxOrReal(func(x float64) (float64, bool) { return math.Tanh(ang(x)), true }, cmplx.Tanh),
		"asin": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Asin(x)), x >= -1 && x <= 1 }, cmplx.Asin),
		"acos": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Acos(x)), x >= -1 && x <= 1 }, cmplx.Acos),
		"atan": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Atan(x)), true }, cmplx.Atan),
		"asinh": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Asinh(x)), true }, cmplx.Asinh),
		"acosh": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Acosh(x)), x >= 1 }, cmplx.Acosh),
		"atanh": cmplxOrReal(func(x float64) (float64, bool) { return angOut(math.Atanh(x)), x > -1 && x < 1 }, cmplx.Atanh),
		"atan2": {2, 2, func(a []Value) Value { return RealV(angOut(math.Atan2(realOf(a[0]), realOf(a[1])))) }},
		"besj0": real1(math.J0),
		"besj1": real1(math.J1),
		"besy0": real1(func(x float64) float64 { return math.Y0(x) }),
		"besy1": real1(func(x float64) float64 { return math.Y1(x) }),
		"besjn": {2, 2, func(a []Value) Value { return RealV(math.Jn(int(realOf(a[0])), realOf(a[1]))) }},
		"besyn": {2, 2, func(a []Value) Value { return RealV(math.Yn(int(realOf(a[0])), realOf(a[1]))) }},
		"besi0": real1(func(x float64) float64 { return besselI(0, x) }),
		"besi1": real1(func(x float64) float64 { return besselI(1, x) }),
		"besin": {2, 2, func(a []Value) Value { return RealV(besselI(int(realOf(a[0])), realOf(a[1]))) }},
		"erf":   real1(math.Erf),
		"erfc":  real1(math.Erfc),
		"inverf": real1(math.Erfinv),
		"gamma": {1, 1, func(a []Value) Value {
			x := realOf(a[0])
			if x <= 0 && x == math.Floor(x) {
				undefFlag = true
				return RealV(0)
			}
			return RealV(math.Gamma(x))
		}},
		"lgamma": real1(func(x float64) float64 { r, _ := math.Lgamma(x); return r }),
		"norm":    real1(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": real1(func(p float64) float64 { return -math.Sqrt2 * math.Erfcinv(2*p) }),
		"igamma":  {2, 2, func(a []Value) Value { return RealV(igamma(realOf(a[0]), realOf(a[1]))) }},
		"ibeta":   {3, 3, func(a []Value) Value { return RealV(ibeta(realOf(a[0]), realOf(a[1]), realOf(a[2]))) }},
		"lambertw": real1(lambertw),
		"expint": {2, 2, func(a []Value) Value { return RealV(expint(int(realOf(a[0])), realOf(a[1]))) }},
		"rand": {1, 1, func(a []Value) Value { return RealV(gpRand(int64(realOf(a[0])))) }},
		"strlen": {1, 1, func(a []Value) Value {
			if a[0].t != STR {
				rterr("internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return IntV(int64(len([]rune(a[0].s))))
		}},
		"strstrt": {2, 2, func(a []Value) Value {
			if a[0].t != STR || a[1].t != STR {
				rterr("internal error : STRING operator applied to undefined or non-STRING variable")
			}
			return IntV(int64(strings.Index(a[0].s, a[1].s) + 1))
		}},
		"substr": {3, 3, func(a []Value) Value {
			if a[0].t != STR {
				rterr("internal error : substring range operator applied to non-STRING type")
			}
			return StrV(substr(a[0].s, int64(realOf(a[1])), int64(realOf(a[2]))))
		}},
		"trim": {1, 1, func(a []Value) Value { return StrV(strings.Trim(strArg(a[0]), " \t\n\r")) }},
		"words": {1, 1, func(a []Value) Value { return IntV(int64(len(splitWords(strArg(a[0]))))) }},
		"word": {2, 2, func(a []Value) Value {
			w := splitWords(strArg(a[0]))
			n := int(realOf(a[1]))
			if n < 1 || n > len(w) {
				return StrV("")
			}
			return StrV(w[n-1])
		}},
		"exists": {1, 1, func(a []Value) Value {
			n := strArg(a[0])
			if v, ok := vars[n]; ok && v.t != UNDEF {
				return IntV(1)
			}
			if _, ok := datablocks[n]; ok {
				return IntV(1)
			}
			return IntV(0)
		}},
		"value": {1, 1, func(a []Value) Value {
			n := strArg(a[0])
			if v, ok := vars[n]; ok {
				return v
			}
			undefFlag = true
			return RealV(math.NaN())
		}},
		"system": {1, 1, func(a []Value) Value {
			out, _ := exec.Command("/bin/sh", "-c", strArg(a[0])).Output()
			s := string(out)
			s = strings.TrimSuffix(s, "\n")
			return StrV(s)
		}},
		"time": {1, 1, func(a []Value) Value {
			now := float64(time.Now().UnixNano()) / 1e9
			if a[0].t == STR {
				return StrV(gstrftime(a[0].s, now))
			}
			if a[0].t == INT {
				return IntV(int64(now))
			}
			return RealV(now)
		}},
		"strftime": {2, 2, func(a []Value) Value { return StrV(gstrftime(strArg(a[0]), realOf(a[1]))) }},
		"strptime": {2, 2, func(a []Value) Value {
			t, ok := gstrptime(strArg(a[1]), strArg(a[0]))
			if !ok {
				undefFlag = true
				return RealV(math.NaN())
			}
			return RealV(t)
		}},
		"tm_sec":  real1(func(x float64) float64 { return float64(tmField(x, 's')) }),
		"tm_min":  real1(func(x float64) float64 { return float64(tmField(x, 'm')) }),
		"tm_hour": real1(func(x float64) float64 { return float64(tmField(x, 'h')) }),
		"tm_mday": real1(func(x float64) float64 { return float64(tmField(x, 'd')) }),
		"tm_mon":  real1(func(x float64) float64 { return float64(tmField(x, 'M')) }),
		"tm_year": real1(func(x float64) float64 { return float64(tmField(x, 'y')) }),
		"tm_wday": real1(func(x float64) float64 { return float64(tmField(x, 'w')) }),
		"tm_yday": real1(func(x float64) float64 { return float64(tmField(x, 'j')) }),
		"sprintf": {1, 100, func(a []Value) Value { return StrV(gpSprintf(a)) }},
		"gprintf": {2, 2, func(a []Value) Value {
			if a[0].t != STR {
				rterr("gprintf: format must be a string")
			}
			return StrV(gprintf(a[0].s, realOf(a[1])))
		}},
		"column":       {1, 1, func(a []Value) Value { return columnValue(a[0], false) }},
		"stringcolumn": {1, 1, func(a []Value) Value { return columnValue(a[0], true) }},
		"strcol":       {1, 1, func(a []Value) Value { return columnValue(a[0], true) }},
		"columnhead":   {1, 1, func(a []Value) Value { return columnHead(a[0]) }},
		"columnheader": {1, 1, func(a []Value) Value { return columnHead(a[0]) }},
		"valid":        {1, 1, func(a []Value) Value { return validColumn(a[0]) }},
		"timecolumn": {1, 2, func(a []Value) Value {
			s := columnValue(a[0], true)
			fmtS := timefmt
			if len(a) > 1 {
				fmtS = strArg(a[1])
			}
			t, ok := gstrptime(s.s, fmtS)
			if !ok {
				undefFlag = true
				return RealV(math.NaN())
			}
			return RealV(t)
		}},
	}
}

func strArg(v Value) string {
	if v.t != STR {
		rterr("internal error : STRING operator applied to undefined or non-STRING variable")
	}
	return v.s
}

func splitWords(s string) []string {
	// gnuplot words: whitespace separated, quoted strings kept together
	var out []string
	i := 0
	for i < len(s) {
		for i < len(s) && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]
			j := i + 1
			for j < len(s) && s[j] != q {
				j++
			}
			out = append(out, s[i+1:min(j, len(s))])
			i = j + 1
			continue
		}
		j := i
		for j < len(s) && !(s[j] == ' ' || s[j] == '\t' || s[j] == '\n') {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

func (p *Parser) makeCall(name string, args []Expr, pos int) Expr {
	if b, ok := builtins[name]; ok {
		if _, isU := udfs[name]; !isU {
			return func(f *Frame) Value {
				av := make([]Value, len(args))
				for k, e := range args {
					av[k] = e(f)
				}
				if len(av) < b.min {
					rterr("not enough arguments for function " + name)
				}
				if len(av) > b.max {
					av = av[:b.max]
				}
				return b.fn(av)
			}
		}
	}
	return func(f *Frame) Value {
		u, ok := udfs[name]
		if !ok {
			rterr("undefined function: " + name)
		}
		av := make([]Value, len(args))
		for k, e := range args {
			av[k] = e(f)
		}
		if len(av) != len(u.params) {
			rterr(fmt.Sprintf("function %s requires %d variable%s", name, len(u.params), plural(len(u.params))))
		}
		return u.body(&Frame{args: av})
	}
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

func besselI(n int, x float64) float64 {
	// series expansion
	sum := 0.0
	term := math.Pow(x/2, float64(n)) / math.Gamma(float64(n)+1)
	for k := 0; k < 500; k++ {
		sum += term
		term *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		return 0
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		ap := a
		sum := 1.0 / a
		del := sum
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		undefFlag = true
		return 0
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1)
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func expint(n int, x float64) float64 {
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 1000; i++ {
			an := -float64(i) * float64(n-1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	nm1 := n - 1
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 1000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

// random generator: L'Ecuyer combined generator like the classic one
var rngS1, rngS2 int64 = 1234567890, 987654321

func gpRand(seed int64) float64 {
	if seed < 0 {
		rngS1, rngS2 = 1234567890, 987654321
		return 0
	}
	if seed > 0 {
		rngS1 = seed
		rngS2 = seed
		return 0
	}
	const m1, m2 = 2147483563, 2147483399
	const a1, a2 = 40014, 40692
	const q1, q2 = 53668, 52774
	const r1, r2 = 12211, 3791
	k := rngS1 / q1
	rngS1 = a1*(rngS1-k*q1) - k*r1
	if rngS1 < 0 {
		rngS1 += m1
	}
	k = rngS2 / q2
	rngS2 = a2*(rngS2-k*q2) - k*r2
	if rngS2 < 0 {
		rngS2 += m2
	}
	z := rngS1 - rngS2
	if z < 1 {
		z += m1 - 1
	}
	return float64(z) / m1
}

var _ = os.Stdout
var _ = strconv.Itoa
