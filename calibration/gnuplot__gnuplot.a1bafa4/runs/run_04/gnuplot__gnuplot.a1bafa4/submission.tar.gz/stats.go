package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                   int
	mean, sd, ssd, skew, kurt, adev     float64
	sum, sumsq, min, max                float64
	imin, imax                          int
	median, loq, upq                    float64
	meanErr, sdErr, skewErr, kurtErr    float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x > s.max {
			s.max = x
			s.imax = i
		}
	}
	fn := float64(n)
	s.mean = s.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	s.sd = math.Sqrt(m2 / fn)
	if n > 1 {
		s.ssd = math.Sqrt(m2 / (fn - 1))
	}
	if s.sd > 0 {
		s.skew = (m3 / fn) / (s.sd * s.sd * s.sd)
		s.kurt = (m4 / fn) / (s.sd * s.sd * s.sd * s.sd)
	}
	s.adev = ad / fn
	s.meanErr = s.sd / math.Sqrt(fn)
	s.sdErr = s.sd / math.Sqrt(2*fn)
	s.skewErr = math.Sqrt(6 / fn)
	s.kurtErr = math.Sqrt(24 / fn)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	med := func(a []float64) float64 {
		m := len(a)
		if m == 0 {
			return 0
		}
		if m%2 == 1 {
			return a[m/2]
		}
		return (a[m/2-1] + a[m/2]) / 2
	}
	s.median = med(sv)
	if n%2 == 0 {
		s.loq = med(sv[:n/2])
		s.upq = med(sv[n/2:])
	} else {
		s.loq = med(sv[:n/2])
		s.upq = med(sv[n/2+1:])
		if n == 1 {
			s.loq, s.upq = sv[0], sv[0]
		}
	}
	return s
}

func sfmt(v float64, w int) string {
	if v != 0 && (math.Abs(v) >= 1e8 || math.Abs(v) < 1e-4) {
		return fmt.Sprintf("%*.*e", w, 5, v)
	}
	return fmt.Sprintf("%*.4f", w, v)
}

func (ex *Exec) statsCmd() {
	p := ex.p
	xa := *S.axes["x"]
	ya := *S.axes["y"]
	for p.isOp("[") {
		ex.parseRange(&xa)
		if p.isOp("[") {
			ex.parseRange(&ya)
		}
	}
	st := p.pos()
	var file string
	if p.peek().kind == tIdent && p.peek().s[0] == '$' {
		file = p.next().s
		if _, ok := datablocks[file]; !ok {
			rterr("no datablock named " + file)
		}
	} else {
		file = ex.parseStrExpr()
	}
	_ = st
	e := &PlotElem{file: file, lt: -1, pt: -1}
	prefix := "STATS"
	output := true
	for !p.endOfCmd() {
		t := p.peek()
		switch {
		case abbrev("u$sing", t.s):
			p.next()
			e.using, e.usingText = ex.parseUsing()
		case abbrev("i$ndex", t.s):
			p.next()
			a := int(ex.parseNumExprNoComma())
			e.index = [3]int{a, a, 1}
			e.hasIndex = true
		case abbrev("ev$ery", t.s):
			p.next()
			e.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if p.isOp(":") {
					p.next()
					continue
				}
				if p.endOfCmd() || p.peek().kind == tIdent {
					break
				}
				e.every[k] = int(ex.parseNumExprNoComma())
				if p.isOp(":") {
					p.next()
				} else {
					break
				}
			}
			e.hasEvery = true
		case t.s == "name":
			p.next()
			prefix = ex.parseStrExpr()
		case abbrev("noout$put", t.s):
			p.next()
			output = false
		case abbrev("out$put", t.s):
			p.next()
			output = true
		case t.s == "prefix":
			p.next()
			prefix = ex.parseStrExpr()
		default:
			gperr(t.pos, "unrecognized option")
		}
	}
	if len(e.using) > 2 {
		gperr(st, "stats command needs 1 or 2 columns")
	}
	sets, ok := readData(file)
	if !ok {
		warn(fmt.Sprintf("Cannot find or open file \"%s\"", file))
		rterr("Can't read data file")
	}
	ncols := len(e.using)
	if ncols == 0 {
		ncols = 1
		// default: column 1 only if file has 1 column; gnuplot uses 1:2 if available
		if len(sets) > 0 && len(sets[0].blocks) > 0 && len(sets[0].blocks[0]) > 0 && len(sets[0].blocks[0][0].fields) >= 2 {
			ncols = 2
		}
	}
	// counts
	blank := 0
	var lines []string
	if strings.HasPrefix(file, "$") {
		lines = datablocks[file]
	} else {
		lines, _ = readFileLines(file)
	}
	for _, l := range lines {
		if strings.TrimSpace(l) == "" {
			blank++
		}
	}
	var xs, ys []float64
	invalid, outr := 0, 0
	every := e.every
	if !e.hasEvery {
		every = [6]int{1, 1, 0, 0, -1, -1}
	}
	for si, ds := range sets {
		if e.hasIndex && si != e.index[0] {
			continue
		}
		curIndexNum = si
		row := 0
		for bi, blk := range ds.blocks {
			curBlockNum = bi
			for li, rec := range blk {
				if li < every[2] || (every[4] >= 0 && li > every[4]) || (li-every[2])%max(every[0], 1) != 0 {
					row++
					continue
				}
				curRow = rec.fields
				curRowNum = row
				row++
				var pt Point
				var valid bool
				if len(e.using) == 0 {
					if ncols == 1 {
						v, ok := fieldValue(rec.fields[0])
						pt.x, valid = v, ok
					} else {
						v1, ok1 := fieldValue(rec.fields[0])
						var v2 float64
						ok2 := false
						if len(rec.fields) > 1 {
							v2, ok2 = fieldValue(rec.fields[1])
						}
						pt.x, pt.y, valid = v1, v2, ok1 && ok2
					}
				} else {
					var vals []float64
					valid = true
					for _, u := range e.using {
						var v float64
						if u.isExpr {
							undefFlag = false
							r := u.expr(&Frame{})
							v = realOf(r)
							if undefFlag || math.IsNaN(v) {
								valid = false
							}
						} else if u.col == 0 {
							v = float64(curRowNum)
						} else if u.col <= len(rec.fields) {
							var ok bool
							v, ok = fieldValue(rec.fields[u.col-1])
							if !ok {
								valid = false
							}
						} else {
							valid = false
						}
						vals = append(vals, v)
					}
					if len(vals) > 0 {
						pt.x = vals[0]
					}
					if len(vals) > 1 {
						pt.y = vals[1]
					}
				}
				if !valid {
					continue
				}
				if ncols == 1 {
					if !ya.inRange(pt.x) && false {
						outr++
						continue
					}
				} else {
					if !xa.inRange(pt.x) || !ya.inRange(pt.y) {
						outr++
						continue
					}
				}
				xs = append(xs, pt.x)
				ys = append(ys, pt.y)
			}
		}
	}
	nblocks := len(sets)
	set := func(n string, v Value) { setVar(prefix+"_"+n, v) }
	set("records", IntV(int64(len(xs))))
	set("invalid", IntV(int64(invalid)))
	set("headers", IntV(0))
	set("blank", IntV(int64(blank)))
	set("blocks", IntV(int64(nblocks)))
	set("outofrange", IntV(int64(outr)))
	set("columns", IntV(int64(ncols)))
	if len(xs) == 0 {
		rterr("All points out of range")
	}
	sx := computeStats(xs)
	var sy colStats
	setCol := func(s colStats, suf string) {
		set("mean"+suf, RealV(s.mean))
		set("stddev"+suf, RealV(s.sd))
		set("ssd"+suf, RealV(s.ssd))
		set("skewness"+suf, RealV(s.skew))
		set("kurtosis"+suf, RealV(s.kurt))
		set("adev"+suf, RealV(s.adev))
		set("mean_err"+suf, RealV(s.meanErr))
		set("stddev_err"+suf, RealV(s.sdErr))
		set("skewness_err"+suf, RealV(s.skewErr))
		set("kurtosis_err"+suf, RealV(s.kurtErr))
		set("sum"+suf, RealV(s.sum))
		set("sumsq"+suf, RealV(s.sumsq))
		set("min"+suf, RealV(s.min))
		set("max"+suf, RealV(s.max))
		set("median"+suf, RealV(s.median))
		set("lo_quartile"+suf, RealV(s.loq))
		set("up_quartile"+suf, RealV(s.upq))
		set("index_min"+suf, IntV(int64(s.imin)))
		set("index_max"+suf, IntV(int64(s.imax)))
	}
	var slope, icpt, slopeErr, icptErr, corr, sumxy float64
	if ncols == 1 {
		setCol(sx, "")
	} else {
		sy = computeStats(ys)
		setCol(sx, "_x")
		setCol(sy, "_y")
		n := float64(len(xs))
		var sxx, sxy, syy float64
		for i := range xs {
			dx := xs[i] - sx.mean
			dy := ys[i] - sy.mean
			sxx += dx * dx
			sxy += dx * dy
			syy += dy * dy
			sumxy += xs[i] * ys[i]
		}
		slope = sxy / sxx
		icpt = sy.mean - slope*sx.mean
		ssr := 0.0
		for i := range xs {
			r := ys[i] - (slope*xs[i] + icpt)
			ssr += r * r
		}
		s := math.Sqrt(ssr / (n - 2))
		slopeErr = s / math.Sqrt(sxx)
		icptErr = s * math.Sqrt(1/n+sx.mean*sx.mean/sxx)
		corr = sxy / math.Sqrt(sxx*syy)
		set("slope", RealV(slope))
		set("intercept", RealV(icpt))
		set("slope_err", RealV(slopeErr))
		set("intercept_err", RealV(icptErr))
		set("correlation", RealV(corr))
		set("sumxy", RealV(sumxy))
		set("pos_min_y", RealV(xs[sy.imin]))
		set("pos_max_y", RealV(xs[sy.imax]))
	}
	if !output {
		return
	}
	var sb strings.Builder
	sb.WriteString("\n* FILE: \n")
	fl := func(l string, v int) { sb.WriteString(fmt.Sprintf("  %s%*d\n", l, 20-len(l), v)) }
	fl("Records:", len(xs))
	fl("Out of range:", outr)
	fl("Invalid:", invalid)
	fl("Header records:", 0)
	fl("Blank:", blank)
	fl("Data Blocks:", nblocks)
	if ncols == 1 {
		sb.WriteString("\n* COLUMN: \n")
		l := func(lab string, v float64) { sb.WriteString(fmt.Sprintf("  %-14s%s\n", lab, sfmt(v, 12))) }
		l("Mean:", sx.mean)
		l("Std Dev:", sx.sd)
		l("Sample StdDev:", sx.ssd)
		l("Skewness:", sx.skew)
		l("Kurtosis:", sx.kurt)
		l("Avg Dev:", sx.adev)
		l("Sum:", sx.sum)
		l("Sum Sq.:", sx.sumsq)
		sb.WriteString("\n")
		l("Mean Err.:", sx.meanErr)
		l("Std Dev Err.:", sx.sdErr)
		l("Skewness Err.:", sx.skewErr)
		l("Kurtosis Err.:", sx.kurtErr)
		sb.WriteString("\n")
		sb.WriteString(fmt.Sprintf("  %-14s%s [%d]\n", "Minimum:", sfmt(sx.min, 12), sx.imin))
		sb.WriteString(fmt.Sprintf("  %-14s%s [%d]\n", "Maximum:", sfmt(sx.max, 12), sx.imax))
		sb.WriteString(fmt.Sprintf("  %-14s%s \n", "Quartile:", sfmt(sx.loq, 12)))
		sb.WriteString(fmt.Sprintf("  %-14s%s \n", "Median:", sfmt(sx.median, 12)))
		sb.WriteString(fmt.Sprintf("  %-14s%s \n", "Quartile:", sfmt(sx.upq, 12)))
		sb.WriteString("\n")
	} else {
		sb.WriteString("\n* COLUMNS:\n")
		l := func(lab string, a, b float64) {
			sb.WriteString(fmt.Sprintf("  %-14s%s%s\n", lab, sfmt(a, 12), sfmt(b, 18)))
		}
		l("Mean:", sx.mean, sy.mean)
		l("Std Dev:", sx.sd, sy.sd)
		l("Sample StdDev:", sx.ssd, sy.ssd)
		l("Skewness:", sx.skew, sy.skew)
		l("Kurtosis:", sx.kurt, sy.kurt)
		l("Avg Dev:", sx.adev, sy.adev)
		l("Sum:", sx.sum, sy.sum)
		l("Sum Sq.:", sx.sumsq, sy.sumsq)
		sb.WriteString("\n")
		l("Mean Err.:", sx.meanErr, sy.meanErr)
		l("Std Dev Err.:", sx.sdErr, sy.sdErr)
		l("Skewness Err.:", sx.skewErr, sy.skewErr)
		l("Kurtosis Err.:", sx.kurtErr, sy.kurtErr)
		sb.WriteString("\n")
		sb.WriteString(fmt.Sprintf("  %-14s%s [%d]%s [%d]\n", "Minimum:", sfmt(sx.min, 12), sx.imin, sfmt(sy.min, 14), sy.imin))
		sb.WriteString(fmt.Sprintf("  %-14s%s [%d]%s [%d]\n", "Maximum:", sfmt(sx.max, 12), sx.imax, sfmt(sy.max, 14), sy.imax))
		l("Quartile:", sx.loq, sy.loq)
		l("Median:", sx.median, sy.median)
		l("Quartile:", sx.upq, sy.upq)
		sb.WriteString("\n")
		sign := "+"
		ic := icpt
		if ic < 0 {
			sign = "-"
			ic = -ic
		}
		sb.WriteString(fmt.Sprintf("  %-20sy = %s x %s %s\n", "Linear Model:", g4(slope), sign, g4(ic)))
		sb.WriteString(fmt.Sprintf("  %-20s%s +- %s\n", "Slope:", g4(slope), g4(slopeErr)))
		sb.WriteString(fmt.Sprintf("  %-20s%s +- %s\n", "Intercept:", g4(icpt), g4(icptErr)))
		sb.WriteString(fmt.Sprintf("  %-20sr = %s\n", "Correlation:", g4(corr)))
		sb.WriteString(fmt.Sprintf("  %-20s%s\n", "Sum xy:", g4(sumxy)))
		sb.WriteString("\n")
	}
	printOut(sb.String())
}

func g4(v float64) string { return cfmt("%.4g", v) }
