package main

func (ex *Exec) saveCmd()           { ex.skipToEnd() }
func finishOutput()                 {}
func clearPending()                 {}
func render2D(c []*Curve, ax map[string]*Axis) {}
func (ex *Exec) do3d(e []*PlotElem, ax map[string]*Axis) {}
func flushPlotOutput() {}
func endMultiplot() {}
func (ex *Exec) startMultiplot() { ex.skipToEnd() }
