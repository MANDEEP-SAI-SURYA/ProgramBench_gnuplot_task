package main

import "math"

func initVars() {
	setVar("pi", RealV(math.Pi))
	setVar("I", CmplxV(0, 1))
	setVar("NaN", RealV(math.NaN()))
	setVar("VoxelDistance", RealV(0))
	vars["GPVAL_pi"] = RealV(math.Pi)
	vars["GPVAL_NaN"] = RealV(math.NaN())
	vars["GPVAL_VERSION"] = RealV(5.4)
	vars["GPVAL_PATCHLEVEL"] = StrV("9")
	vars["GPVAL_ERRNO"] = IntV(0)
	vars["GPVAL_ERRMSG"] = StrV("")
}
