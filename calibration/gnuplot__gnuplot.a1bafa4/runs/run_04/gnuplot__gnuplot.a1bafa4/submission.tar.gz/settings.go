package main

import (
	"fmt"
	"math"
	"os"
	"bufio"
	"strings"
)

type TicDef struct {
	on       bool
	mirror   bool
	auto     bool
	incr     float64
	start    float64
	end      float64
	hasStart bool
	hasEnd   bool
	list     []ticEntry
	addList  bool
	minor    int // 0 = off(default), -1 auto, n = subintervals
	format   string
	rotate   bool
	out      bool
	scale    float64
}

type ticEntry struct {
	label string
	pos   float64
	hasL  bool
	level int
}

type Axis struct {
	name           string
	min, max       float64
	autoMin        bool
	autoMax        bool
	reverse        bool
	log            bool
	base           float64
	label          string
	labelOffX      float64
	labelOffY      float64
	tics           TicDef
	isTime         bool
	// working range for current plot
	dmin, dmax float64
	set        bool
}

type Label struct {
	tag    int
	text   string
	x, y   float64
	coordX string
	coordY string
	just   string
	point  bool
}

type Arrow struct {
	tag            int
	x1, y1, x2, y2 float64
	nohead         bool
	heads          bool
	rto            bool
}

type Settings struct {
	axes         map[string]*Axis
	samples1     int
	samples2     int
	iso1, iso2   int
	title        string
	titleFont    string
	keyOn        bool
	keyPosV      string // top / bottom / center
	keyPosH      string // left / right / center
	keyInside    bool
	keyBox       bool
	keyReverse   bool
	keyJust      string
	keyTitle     string
	keyVertical  bool
	keyAt        bool
	styleData    string
	styleFunc    string
	grid         bool
	gridX, gridY bool
	gridMX, gridMY bool
	parametric   bool
	polar        bool
	zero         float64
	termName     string
	termW, termH int
	termFeed     bool
	output       string
	outFile      *os.File
	tableOn      bool
	tableFile    string
	tableDB      string
	tableOut     *bufio.Writer
	tableFH      *os.File
	sepChar      string
	missing      string
	commentChars string
	boxwidth     float64
	boxwidthAbs  bool
	boxwidthSet  bool
	pointsize    float64
	offsets      [4]float64
	border       int
	sizeX, sizeY float64
	sizeSquare   bool
	originX, originY float64
	margins      [4]float64 // l r b t ; -1 auto
	dummy1, dummy2 string
	viewRotX, viewRotZ, viewScale, viewScaleZ float64
	labels       []*Label
	arrows       []*Arrow
	clipOne, clipTwo bool
	decimalsign  string
	encoding     string
	fitQuiet     bool
	fitLog       string
	fitErrVars   bool
	fitCovVars   bool
	fitPrescale  bool
	fitLimit     float64
	fitMaxIter   int
	fitVerbose   bool
	fitNoLog     bool
	angleDeg     bool
	timefmt      string
	xyplane      float64
	bars         float64
	surface      bool
	contour      bool
	hidden3d     bool
	pm3d         bool
	histogramGap int
	fillStyle    string
	fillDensity  float64
	ticsLevel    float64
	fontscale    float64
	multiplot    bool
	mpRows, mpCols int
	mpIdx        int
	mpTitle      string
	ticsScaleMaj float64
}

var S *Settings

func newAxis(name string) *Axis {
	a := &Axis{name: name, autoMin: true, autoMax: true, min: -10, max: 10, base: 10}
	a.tics = TicDef{on: true, mirror: true, auto: true, format: "% h", scale: 1}
	if name == "x2" || name == "y2" {
		a.tics.on = false
	}
	if name == "z" {
		a.tics.mirror = false
	}
	return a
}

func defaultSettings() *Settings {
	s := &Settings{}
	s.axes = map[string]*Axis{}
	for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "t", "u", "v", "r"} {
		s.axes[n] = newAxis(n)
	}
	s.axes["t"].min, s.axes["t"].max = -5, 5
	s.axes["u"].min, s.axes["u"].max = -5, 5
	s.axes["v"].min, s.axes["v"].max = -5, 5
	s.samples1, s.samples2 = 100, 100
	s.iso1, s.iso2 = 10, 10
	s.keyOn = true
	s.keyPosV = "top"
	s.keyPosH = "right"
	s.keyInside = true
	s.keyJust = "right"
	s.keyVertical = true
	s.styleData = "points"
	s.styleFunc = "lines"
	s.zero = 1e-8
	s.termName = "unknown"
	s.termW, s.termH = 79, 24
	s.termFeed = true
	s.commentChars = "#"
	s.pointsize = 1
	s.border = 31
	s.sizeX, s.sizeY = 1, 1
	s.margins = [4]float64{-1, -1, -1, -1}
	s.dummy1, s.dummy2 = "x", "y"
	s.viewRotX, s.viewRotZ, s.viewScale, s.viewScaleZ = 60, 30, 1, 1
	s.clipOne = true
	s.encoding = "utf8"
	s.fitPrescale = true
	s.fitErrVars = true
	s.fitLimit = 1e-5
	s.timefmt = "%d/%m/%y,%H:%M"
	s.xyplane = 0.5
	s.bars = 1
	s.surface = true
	s.histogramGap = 2
	s.fillStyle = "empty"
	s.ticsLevel = 0.5
	s.fontscale = 1
	s.ticsScaleMaj = 1
	return s
}

func init() {
	S = defaultSettings()
}

func resetSettings() {
	old := S
	S = defaultSettings()
	// reset does not change terminal / output
	S.termName, S.termW, S.termH, S.output, S.outFile = old.termName, old.termW, old.termH, old.output, old.outFile
	S.fitLog = old.fitLog
	S.tableOn, S.tableFile, S.tableOut, S.tableFH, S.tableDB = false, "", nil, nil, ""
	angleDegrees = false
	timefmt = S.timefmt
}

func (ex *Exec) parseNumExpr() float64 {
	p := ex.p
	e := p.parseExpr()
	undefFlag = false
	v := e(&Frame{})
	return realOf(v)
}

func (ex *Exec) tryNum() (float64, bool) {
	p := ex.p
	if p.endOfCmd() || p.isOp(",") || p.isOp(":") || p.isOp("]") {
		return 0, false
	}
	return ex.parseNumExprNoComma(), true
}

func (ex *Exec) parseNumExprNoComma() float64 {
	p := ex.p
	e := p.parseTernary()
	v := e(&Frame{})
	return realOf(v)
}

func (ex *Exec) parseStrExpr() string {
	p := ex.p
	st := p.pos()
	e := p.parseTernary()
	v := e(&Frame{})
	if v.t != STR {
		gperr(st, "expecting string")
	}
	return v.s
}

func (ex *Exec) isStringStart() bool {
	p := ex.p
	t := p.peek()
	if t.kind == tStr {
		return true
	}
	if t.kind == tIdent && !p.isOpN(1, "(") {
		if v, ok := vars[t.s]; ok && v.t == STR {
			return true
		}
	}
	if t.kind == tIdent && p.isOpN(1, "(") {
		n := t.s
		if n == "sprintf" || n == "gprintf" || n == "strftime" || n == "word" || n == "substr" || n == "trim" || n == "system" || n == "columnhead" || n == "strcol" || n == "stringcolumn" {
			return true
		}
	}
	return false
}

// parse a range [a:b]; returns which parts set
func (ex *Exec) parseRange(ax *Axis) {
	p := ex.p
	p.expect("[", "expecting '['")
	// optional dummy var: [t=...]
	if p.peek().kind == tIdent && p.isOpN(1, "=") {
		p.next()
		p.next()
	}
	if p.isOp(":") {
		p.next()
	} else {
		if p.isOp("*") {
			p.next()
			ax.autoMin = true
		} else {
			v := ex.rangeValue(ax)
			ax.min = v
			ax.autoMin = false
		}
		if p.isOp("]") {
			p.next()
			return
		}
		p.expect(":", "':' expected")
	}
	if p.isOp("]") {
		p.next()
		return
	}
	if p.isOp("*") {
		p.next()
		ax.autoMax = true
	} else {
		v := ex.rangeValue(ax)
		ax.max = v
		ax.autoMax = false
	}
	p.expect("]", "']' expected")
}

func (ex *Exec) rangeValue(ax *Axis) float64 {
	p := ex.p
	if ax.isTime && p.peek().kind == tStr {
		t := p.next()
		v, ok := gstrptime(t.s, S.timefmt)
		if !ok {
			return 0
		}
		return v
	}
	return ex.parseNumExprNoComma()
}

var setOptsAxes = []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"}

func axisFromPrefix(w string, suffix string) (*Axis, bool) {
	if !strings.HasSuffix(w, suffix) {
		return nil, false
	}
	pre := strings.TrimSuffix(w, suffix)
	if a, ok := S.axes[pre]; ok {
		return a, true
	}
	return nil, false
}

func (ex *Exec) setCmd(unset bool) {
	p := ex.p
	t := p.peek()
	if t.kind != tIdent {
		if p.endOfCmd() {
			return
		}
		gperr(t.pos, "unrecognized option - see 'help set'.")
	}
	w := t.s
	p.next()
	if ax, ok := axisFromPrefix(w, "range"); ok {
		if unset {
			ax.autoMin, ax.autoMax = true, true
			return
		}
		if p.isOp("[") {
			ex.parseRange(ax)
		}
		for !p.endOfCmd() {
			tk := p.next()
			switch tk.s {
			case "reverse":
				ax.reverse = true
			case "noreverse":
				ax.reverse = false
			}
		}
		return
	}
	if ax, ok := axisFromPrefix(w, "label"); ok && w != "label" {
		if unset {
			ax.label = ""
			return
		}
		if ex.isStringStart() {
			ax.label = ex.parseStrExpr()
		}
		for !p.endOfCmd() {
			if p.isIdent("offset") {
				p.next()
				ax.labelOffX, _ = ex.tryCoord()
				if p.isOp(",") {
					p.next()
					ax.labelOffY, _ = ex.tryCoord()
				}
				continue
			}
			p.next()
		}
		return
	}
	if ax, ok := axisFromPrefix(w, "tics"); ok && w != "tics" {
		ex.setTics(ax, unset)
		return
	}
	if strings.HasPrefix(w, "m") {
		if ax, ok := axisFromPrefix(w[1:], "tics"); ok {
			if unset {
				ax.tics.minor = 0
			} else if n, ok := ex.tryNum(); ok {
				ax.tics.minor = int(n)
			} else {
				ax.tics.minor = -1
			}
			return
		}
	}
	if strings.HasPrefix(w, "no") {
		if ax, ok := axisFromPrefix(w[2:], "tics"); ok {
			ax.tics.on = false
			return
		}
	}
	if ax, ok := axisFromPrefix(w, "data"); ok && w != "data" {
		if unset {
			ax.isTime = false
			return
		}
		if p.isIdent("time") {
			p.next()
			ax.isTime = true
		} else {
			ax.isTime = false
		}
		return
	}
	switch {
	case abbrev("sa$mples", w):
		if unset {
			S.samples1, S.samples2 = 100, 100
			return
		}
		a := ex.parseNumExprNoComma()
		S.samples1 = int(a)
		S.samples2 = int(a)
		if p.isOp(",") {
			p.next()
			S.samples2 = int(ex.parseNumExprNoComma())
		}
		if S.samples1 < 2 || S.samples2 < 2 {
			rterr("sampling rate must be > 1; sampling unchanged")
		}
	case abbrev("iso$samples", w):
		if unset {
			S.iso1, S.iso2 = 10, 10
			return
		}
		a := ex.parseNumExprNoComma()
		S.iso1, S.iso2 = int(a), int(a)
		if p.isOp(",") {
			p.next()
			S.iso2 = int(ex.parseNumExprNoComma())
		}
	case abbrev("tit$le", w):
		if unset {
			S.title = ""
			return
		}
		if ex.isStringStart() {
			S.title = ex.parseStrExpr()
		}
		for !p.endOfCmd() {
			if p.isIdent("font") {
				p.next()
				S.titleFont = ex.parseStrExpr()
				continue
			}
			p.next()
		}
	case abbrev("k$ey", w):
		ex.setKey(unset)
	case w == "nokey":
		S.keyOn = false
	case abbrev("st$yle", w):
		ex.setStyle(unset)
	case abbrev("g$rid", w):
		if unset {
			S.grid = false
			S.gridX, S.gridY, S.gridMX, S.gridMY = false, false, false, false
			return
		}
		S.grid = true
		any := false
		for !p.endOfCmd() {
			tk := p.next()
			switch tk.s {
			case "xtics":
				S.gridX = true
				any = true
			case "ytics":
				S.gridY = true
				any = true
			case "mxtics":
				S.gridMX = true
				any = true
			case "mytics":
				S.gridMY = true
				any = true
			case "noxtics":
				S.gridX = false
				any = true
			case "noytics":
				S.gridY = false
				any = true
			}
		}
		if !any && !S.gridX && !S.gridY {
			S.gridX, S.gridY = true, true
		}
	case abbrev("log$scale", w) || w == "logscale":
		axesS := "xyzx2y2cb"
		if !p.endOfCmd() && p.peek().kind == tIdent {
			axesS = p.next().s
		}
		base := 10.0
		if !unset && !p.endOfCmd() {
			base = ex.parseNumExprNoComma()
		}
		for _, an := range splitAxesNames(axesS) {
			if a, ok := S.axes[an]; ok {
				a.log = !unset
				a.base = base
			}
		}
	case abbrev("form$at", w):
		axesS := "xyzx2y2cb"
		if !p.endOfCmd() && p.peek().kind == tIdent {
			axesS = p.next().s
		}
		f := "% h"
		if !unset && !p.endOfCmd() {
			f = ex.parseStrExpr()
		}
		for _, an := range splitAxesNames(axesS) {
			if a, ok := S.axes[an]; ok {
				a.tics.format = f
			}
		}
		if axesS == "xyzx2y2cb" {
			S.axes["r"].tics.format = f
		}
	case abbrev("an$gles", w):
		if unset {
			angleDegrees = false
			return
		}
		tk := p.next()
		angleDegrees = strings.HasPrefix(tk.s, "d")
	case abbrev("t$erminal", w):
		ex.setTerm(unset)
	case abbrev("o$utput", w):
		if S.outFile != nil {
			flushPlotOutput()
			S.outFile.Close()
			S.outFile = nil
		}
		S.output = ""
		if !unset && !p.endOfCmd() {
			S.output = ex.parseStrExpr()
			f, err := os.Create(S.output)
			if err != nil {
				rterr("cannot open file; output not changed")
			}
			S.outFile = f
		}
	case abbrev("pr$int", w):
		closePrint()
		if unset || p.endOfCmd() {
			return
		}
		if p.peek().kind == tIdent && p.peek().s[0] == '$' {
			name := p.next().s
			printDatablock = name
			app := p.isIdent("append")
			if !app {
				datablocks[name] = []string{}
			} else if _, ok := datablocks[name]; !ok {
				datablocks[name] = []string{}
			}
			return
		}
		name := ex.parseStrExpr()
		app := false
		if p.isIdent("append") {
			p.next()
			app = true
		}
		if name == "-" {
			printToStdout = true
			printFileName = "-"
			return
		}
		flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(name, flags, 0644)
		if err != nil {
			rterr("cannot open print output file")
		}
		printFileH = f
		printFile = bufio.NewWriter(f)
		printFileName = name
	case abbrev("tab$le", w):
		closeTable()
		if unset {
			return
		}
		S.tableOn = true
		if !p.endOfCmd() {
			if p.peek().kind == tIdent && p.peek().s[0] == '$' {
				S.tableDB = p.next().s
				datablocks[S.tableDB] = []string{}
			} else {
				S.tableFile = ex.parseStrExpr()
				f, err := os.Create(S.tableFile)
				if err == nil {
					S.tableFH = f
					S.tableOut = bufio.NewWriter(f)
				}
			}
		}
		ex.skipToEnd()
	case abbrev("dataf$ile", w):
		ex.setDatafile(unset)
	case abbrev("z$ero", w):
		S.zero = ex.parseNumExprNoComma()
	case abbrev("par$ametric", w):
		S.parametric = !unset
		if !unset {
			S.dummy1 = "t"
		} else {
			S.dummy1 = "x"
		}
	case abbrev("pol$ar", w):
		S.polar = !unset
		if !unset {
			S.dummy1 = "t"
		} else {
			S.dummy1 = "x"
		}
	case abbrev("box$width", w):
		if unset {
			S.boxwidthSet = false
			return
		}
		if n, ok := ex.tryNum(); ok {
			S.boxwidth = n
			S.boxwidthSet = true
			S.boxwidthAbs = true
		}
		if p.isIdent("relative") {
			p.next()
			S.boxwidthAbs = false
		} else if p.isIdent("absolute") {
			p.next()
		}
	case abbrev("poi$ntsize", w):
		if unset {
			S.pointsize = 1
			return
		}
		S.pointsize = ex.parseNumExprNoComma()
	case abbrev("offset$s", w):
		S.offsets = [4]float64{}
		for k := 0; k < 4 && !p.endOfCmd(); k++ {
			if p.isOp(",") {
				p.next()
			}
			S.offsets[k] = ex.parseNumExprNoComma()
		}
	case abbrev("bor$der", w):
		if unset {
			S.border = 0
			return
		}
		S.border = 31
		if n, ok := ex.tryNum(); ok {
			S.border = int(n)
		}
		ex.skipToEnd()
	case w == "size":
		if unset {
			S.sizeX, S.sizeY = 1, 1
			S.sizeSquare = false
			return
		}
		for !p.endOfCmd() {
			if p.isIdent("square") {
				p.next()
				S.sizeSquare = true
				continue
			}
			if p.isIdent("nosquare") || p.isIdent("noratio") {
				p.next()
				S.sizeSquare = false
				continue
			}
			if p.isIdent("ratio") {
				p.next()
				ex.parseNumExprNoComma()
				continue
			}
			S.sizeX = ex.parseNumExprNoComma()
			if p.isOp(",") {
				p.next()
				S.sizeY = ex.parseNumExprNoComma()
			}
		}
	case abbrev("or$igin", w):
		S.originX = ex.parseNumExprNoComma()
		p.expect(",", "',' expected")
		S.originY = ex.parseNumExprNoComma()
	case w == "lmargin" || w == "rmargin" || w == "bmargin" || w == "tmargin":
		idx := strings.Index("lrbt", w[:1])
		if unset || p.endOfCmd() {
			S.margins[idx] = -1
			return
		}
		if p.isIdent("at") {
			p.next()
			p.next()
		}
		S.margins[idx] = ex.parseNumExprNoComma()
	case abbrev("mar$gins", w):
		for k := 0; k < 4; k++ {
			S.margins[k] = -1
		}
		if !unset {
			for k := 0; k < 4 && !p.endOfCmd(); k++ {
				if p.isOp(",") {
					p.next()
				}
				S.margins[k] = ex.parseNumExprNoComma()
			}
		}
	case abbrev("du$mmy", w):
		if unset {
			S.dummy1, S.dummy2 = "x", "y"
			return
		}
		if !p.isOp(",") {
			S.dummy1 = p.next().s
		}
		if p.isOp(",") {
			p.next()
			S.dummy2 = p.next().s
		}
	case abbrev("vi$ew", w):
		if unset {
			S.viewRotX, S.viewRotZ, S.viewScale, S.viewScaleZ = 60, 30, 1, 1
			return
		}
		if p.isIdent("map") {
			p.next()
			S.viewRotX, S.viewRotZ = 0, 0
			return
		}
		vals := []*float64{&S.viewRotX, &S.viewRotZ, &S.viewScale, &S.viewScaleZ}
		for k := 0; k < 4 && !p.endOfCmd(); k++ {
			if p.isOp(",") {
				p.next()
				continue
			}
			*vals[k] = ex.parseNumExprNoComma()
			if p.isOp(",") {
				p.next()
			}
		}
	case abbrev("timef$mt", w):
		if unset {
			S.timefmt = "%d/%m/%y,%H:%M"
		} else {
			S.timefmt = ex.parseStrExpr()
		}
		timefmt = S.timefmt
	case abbrev("la$bel", w):
		ex.setLabel(unset)
	case abbrev("ar$row", w):
		ex.setArrow(unset)
	case abbrev("cl$ip", w):
		tk := ""
		if !p.endOfCmd() {
			tk = p.next().s
		}
		switch tk {
		case "one":
			S.clipOne = !unset
		case "two":
			S.clipTwo = !unset
		case "":
			if unset {
				S.clipOne, S.clipTwo = false, false
			}
		}
	case abbrev("dec$imalsign", w):
		if unset {
			S.decimalsign = ""
		} else {
			S.decimalsign = ex.parseStrExpr()
		}
	case abbrev("enc$oding", w):
		if unset || p.endOfCmd() {
			S.encoding = "default"
		} else {
			S.encoding = p.next().s
		}
	case w == "fit":
		ex.setFit(unset)
	case abbrev("tic$s", w) || w == "tics":
		for _, an := range []string{"x", "y", "z", "cb"} {
			if unset {
				S.axes[an].tics.on = false
			}
		}
		ex.skipToEnd()
	case w == "notics":
		ex.skipToEnd()
	case abbrev("multi$plot", w):
		if unset {
			endMultiplot()
			return
		}
		ex.startMultiplot()
	case abbrev("xyp$lane", w):
		ex.skipToEnd()
	case abbrev("ticsl$evel", w):
		if n, ok := ex.tryNum(); ok {
			S.ticsLevel = n
		}
	case abbrev("surf$ace", w):
		S.surface = !unset
		ex.skipToEnd()
	case abbrev("cont$ours", w):
		S.contour = !unset
		ex.skipToEnd()
	case abbrev("hid$den3d", w):
		S.hidden3d = !unset
		ex.skipToEnd()
	case w == "pm3d":
		S.pm3d = !unset
		ex.skipToEnd()
	case abbrev("bar$s", w):
		ex.skipToEnd()
	case abbrev("auto$scale", w):
		if p.endOfCmd() {
			for _, a := range S.axes {
				a.autoMin, a.autoMax = !unset, !unset
			}
			return
		}
		for !p.endOfCmd() {
			tk := p.next().s
			for _, an := range []string{"x2", "y2", "cb", "x", "y", "z"} {
				if strings.HasPrefix(tk, an) {
					a := S.axes[an]
					rest := tk[len(an):]
					switch rest {
					case "", "fix":
						a.autoMin, a.autoMax = !unset, !unset
					case "min", "fixmin":
						a.autoMin = !unset
					case "max", "fixmax":
						a.autoMax = !unset
					}
					break
				}
			}
		}
	case w == "loadpath", w == "fontpath", w == "mouse", w == "colorbox", w == "palette", w == "cbtics",
		w == "object", w == "obj", w == "linetype", w == "lt", w == "termoption", w == "macros", w == "historysize",
		w == "history", w == "locale", w == "jitter", w == "theta", w == "rtics", w == "raxis", w == "minussign", w == "micro",
		w == "overflow", w == "psdir", w == "colorsequence", w == "errorbars", w == "dgrid3d", w == "cntrparam", w == "cntrlabel",
		w == "mapping", w == "isosurface", w == "walls", w == "pixmap", w == "rgbmax", w == "nonlinear", w == "link",
		w == "zzeroaxis", w == "xzeroaxis", w == "yzeroaxis", w == "zeroaxis", w == "x2zeroaxis", w == "y2zeroaxis", w == "debug", w == "vxrange", w == "vyrange", w == "vzrange", w == "for", w == "ttics", w == "x2dtics", w == "xdtics", w == "xmtics", w == "ydtics", w == "ymtics", w == "zdtics", w == "zmtics", w == "spiderplot", w == "paxis", w == "monochrome", w == "color", w == "lmargin":
		ex.skipToEnd()
	default:
		if unset {
			gperr(t.pos, "unrecognized option - see 'help unset'.")
		}
		gperr(t.pos, "unrecognized option - see 'help set'.")
	}
}

func splitAxesNames(s string) []string {
	var out []string
	for len(s) > 0 {
		if strings.HasPrefix(s, "x2") || strings.HasPrefix(s, "y2") || strings.HasPrefix(s, "cb") {
			out = append(out, s[:2])
			s = s[2:]
			continue
		}
		out = append(out, s[:1])
		s = s[1:]
	}
	return out
}

func (ex *Exec) tryCoord() (float64, bool) {
	p := ex.p
	for p.isIdent("first") || p.isIdent("second") || p.isIdent("graph") || p.isIdent("screen") || p.isIdent("character") {
		p.next()
	}
	return ex.tryNum()
}

func (ex *Exec) setTics(ax *Axis, unset bool) {
	p := ex.p
	if unset {
		ax.tics.on = false
		return
	}
	ax.tics.on = true
	for !p.endOfCmd() {
		t := p.peek()
		if t.kind == tIdent {
			switch t.s {
			case "mirror":
				ax.tics.mirror = true
			case "nomirror":
				ax.tics.mirror = false
			case "out", "outside":
				ax.tics.out = true
			case "in":
				ax.tics.out = false
			case "rotate":
				ax.tics.rotate = true
				p.next()
				if p.isIdent("by") {
					p.next()
					ex.parseNumExprNoComma()
				}
				continue
			case "norotate":
				ax.tics.rotate = false
			case "autofreq":
				ax.tics.auto = true
				ax.tics.list = nil
			case "add":
				ax.tics.addList = true
			case "format":
				p.next()
				ax.tics.format = ex.parseStrExpr()
				continue
			case "border", "axis", "nologscale", "logscale", "front", "back", "enhanced", "noenhanced":
			case "scale":
				p.next()
				ex.parseNumExprNoComma()
				if p.isOp(",") {
					p.next()
					ex.parseNumExprNoComma()
				}
				continue
			case "offset":
				p.next()
				ex.tryCoord()
				for p.isOp(",") {
					p.next()
					ex.tryCoord()
				}
				continue
			case "font", "textcolor", "tc":
				p.next()
				if !p.endOfCmd() {
					p.next()
				}
				continue
			default:
				goto numeric
			}
			p.next()
			continue
		}
	numeric:
		if p.isOp("(") {
			p.next()
			if !ax.tics.addList {
				ax.tics.list = nil
			}
			ax.tics.auto = false
			for !p.isOp(")") {
				var e ticEntry
				if ex.isStringStart() {
					e.label = ex.parseStrExpr()
					e.hasL = true
				}
				e.pos = ex.parseNumExprNoComma()
				if !p.isOp(",") && !p.isOp(")") {
					e.level = int(ex.parseNumExprNoComma())
				}
				ax.tics.list = append(ax.tics.list, e)
				if p.isOp(",") {
					p.next()
				}
			}
			p.next()
			continue
		}
		a := ex.parseNumExprNoComma()
		ax.tics.auto = false
		ax.tics.list = nil
		if p.isOp(",") {
			p.next()
			b := ex.parseNumExprNoComma()
			ax.tics.start, ax.tics.hasStart = a, true
			ax.tics.incr = b
			if p.isOp(",") {
				p.next()
				c := ex.parseNumExprNoComma()
				ax.tics.end, ax.tics.hasEnd = c, true
			} else {
				ax.tics.hasEnd = false
			}
		} else {
			ax.tics.incr = a
			ax.tics.hasStart = false
			ax.tics.hasEnd = false
		}
	}
}

func (ex *Exec) setKey(unset bool) {
	p := ex.p
	if unset {
		S.keyOn = false
		return
	}
	S.keyOn = true
	for !p.endOfCmd() {
		t := p.next()
		switch t.s {
		case "off":
			S.keyOn = false
		case "on":
			S.keyOn = true
		case "left":
			S.keyPosH = "left"
		case "right":
			S.keyPosH = "right"
		case "center", "centre":
			S.keyPosH = "center"
		case "top":
			S.keyPosV = "top"
		case "bottom":
			S.keyPosV = "bottom"
		case "box":
			S.keyBox = true
		case "nobox":
			S.keyBox = false
		case "reverse":
			S.keyReverse = true
		case "noreverse":
			S.keyReverse = false
		case "Left":
			S.keyJust = "left"
		case "Right":
			S.keyJust = "right"
		case "inside", "ins":
			S.keyInside = true
		case "outside", "out":
			S.keyInside = false
		case "vertical":
			S.keyVertical = true
		case "horizontal":
			S.keyVertical = false
		case "title":
			if ex.isStringStart() {
				S.keyTitle = ex.parseStrExpr()
			}
		case "at":
			ex.tryCoord()
			if p.isOp(",") {
				p.next()
				ex.tryCoord()
			}
		case "default":
			on := S.keyOn
			d := defaultSettings()
			S.keyPosH, S.keyPosV, S.keyBox, S.keyReverse, S.keyJust, S.keyInside = d.keyPosH, d.keyPosV, d.keyBox, d.keyReverse, d.keyJust, d.keyInside
			S.keyOn = on
		case "font", "spacing", "width", "height", "samplen", "maxrows", "maxcols", "textcolor", "tc", "lt", "lc", "linetype", "lw", "linewidth", "opaque", "noopaque", "enhanced", "noenhanced", "invert", "noinvert", "autotitle", "noautotitle", "columnhead", "fixed":
			if t.s == "font" || t.s == "spacing" || t.s == "width" || t.s == "height" || t.s == "samplen" || t.s == "maxrows" || t.s == "maxcols" || t.s == "lw" || t.s == "linewidth" || t.s == "lt" || t.s == "lc" || t.s == "linetype" {
				if !p.endOfCmd() && !p.isOp(",") {
					p.next()
				}
			}
		}
	}
}

func (ex *Exec) setStyle(unset bool) {
	p := ex.p
	if p.endOfCmd() {
		return
	}
	t := p.next()
	switch {
	case abbrev("d$ata", t.s):
		if unset {
			S.styleData = "points"
			return
		}
		S.styleData = parseStyleName(p.next().s)
		ex.skipToEnd()
	case abbrev("f$unction", t.s):
		if unset {
			S.styleFunc = "lines"
			return
		}
		S.styleFunc = parseStyleName(p.next().s)
		ex.skipToEnd()
	case t.s == "fill":
		for !p.endOfCmd() {
			tk := p.next()
			switch tk.s {
			case "solid":
				S.fillStyle = "solid"
				if n, ok := ex.tryNum(); ok {
					S.fillDensity = n
				}
			case "empty":
				S.fillStyle = "empty"
			case "pattern":
				S.fillStyle = "pattern"
				ex.tryNum()
			}
		}
	case t.s == "histogram":
		for !p.endOfCmd() {
			tk := p.next()
			if tk.s == "gap" {
				S.histogramGap = int(ex.parseNumExprNoComma())
			}
		}
	default:
		ex.skipToEnd()
	}
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xyerrorb$ars", "errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "b$oxes", "boxerrorb$ars", "boxxy$errorbars", "box$plot", "candle$sticks", "f$inancebars", "vec$tors", "lab$els", "filledc$urves", "fillsteps", "histograms", "image", "rgbimage", "pm3d", "circles", "ellipses", "zerror$fill", "table", "surface", "parallelaxes", "arrows", "sp$iderplot", "rgba$lpha", "polygons"}

func parseStyleName(w string) string {
	if w == "lp" {
		return "linespoints"
	}
	for _, s := range styleNames {
		if abbrev(s, w) {
			return strings.ReplaceAll(s, "$", "")
		}
	}
	rterr("unrecognized plot type")
	return ""
}

func (ex *Exec) setTerm(unset bool) {
	p := ex.p
	if unset || p.endOfCmd() {
		if unset {
			S.termName = "unknown"
		}
		return
	}
	t := p.next()
	switch {
	case abbrev("du$mb", t.s):
		S.termName = "dumb"
		S.termFeed = true
		for !p.endOfCmd() {
			if p.isIdent("size") {
				p.next()
				S.termW = int(ex.parseNumExprNoComma())
				if p.isOp(",") {
					p.next()
					S.termH = int(ex.parseNumExprNoComma())
				}
				continue
			}
			tk := p.next()
			if tk.s == "nofeed" {
				S.termFeed = false
			} else if tk.s == "feed" {
				S.termFeed = true
			} else if tk.kind == tNum {
				S.termW = int(realOf(tk.val))
				if p.isOp(",") {
					p.next()
				}
				if n, ok := ex.tryNum(); ok {
					S.termH = int(n)
				}
			}
		}
	case t.s == "svg":
		S.termName = "svg"
		S.termW, S.termH = 640, 480
		ex.parseSizeOpts()
	case t.s == "canvas":
		S.termName = "canvas"
		S.termW, S.termH = 600, 400
		ex.parseSizeOpts()
	case t.s == "push" || t.s == "pop":
	default:
		S.termName = t.s
		ex.skipToEnd()
	}
}

func (ex *Exec) parseSizeOpts() {
	p := ex.p
	for !p.endOfCmd() {
		if p.isIdent("size") {
			p.next()
			S.termW = int(ex.parseNumExprNoComma())
			if p.isOp(",") {
				p.next()
				S.termH = int(ex.parseNumExprNoComma())
			}
			continue
		}
		p.next()
	}
}

func (ex *Exec) setDatafile(unset bool) {
	p := ex.p
	if p.endOfCmd() {
		return
	}
	t := p.next()
	switch {
	case abbrev("sep$arator", t.s):
		if unset || p.endOfCmd() {
			S.sepChar = ""
			return
		}
		if p.isIdent("whitespace") {
			p.next()
			S.sepChar = ""
			return
		}
		if p.isIdent("comma") {
			p.next()
			S.sepChar = ","
			return
		}
		if p.isIdent("tab") {
			p.next()
			S.sepChar = "\t"
			return
		}
		S.sepChar = ex.parseStrExpr()
	case abbrev("miss$ing", t.s):
		if unset || p.endOfCmd() {
			S.missing = ""
			return
		}
		S.missing = ex.parseStrExpr()
	case abbrev("com$mentschars", t.s):
		if unset || p.endOfCmd() {
			S.commentChars = "#"
			return
		}
		S.commentChars = ex.parseStrExpr()
	default:
		ex.skipToEnd()
	}
}

func (ex *Exec) setLabel(unset bool) {
	p := ex.p
	tag := 0
	if !p.endOfCmd() && !ex.isStringStart() && p.peek().kind != tIdent {
		tag = int(ex.parseNumExprNoComma())
	}
	if unset {
		if tag == 0 {
			S.labels = nil
			return
		}
		for k, l := range S.labels {
			if l.tag == tag {
				S.labels = append(S.labels[:k], S.labels[k+1:]...)
				return
			}
		}
		return
	}
	var lab *Label
	if tag == 0 {
		tag = 1
		for _, l := range S.labels {
			if l.tag >= tag {
				tag = l.tag + 1
			}
		}
	}
	for _, l := range S.labels {
		if l.tag == tag {
			lab = l
		}
	}
	if lab == nil {
		lab = &Label{tag: tag, just: "left"}
		S.labels = append(S.labels, lab)
		sortLabels()
	}
	if ex.isStringStart() {
		lab.text = ex.parseStrExpr()
	}
	for !p.endOfCmd() {
		t := p.next()
		switch t.s {
		case "at":
			lab.coordX = ex.coordSys()
			lab.x = ex.parseNumExprNoComma()
			if p.isOp(",") {
				p.next()
				lab.coordY = ex.coordSys()
				lab.y = ex.parseNumExprNoComma()
			}
			if p.isOp(",") {
				p.next()
				ex.coordSys()
				ex.parseNumExprNoComma()
			}
		case "left", "right", "center", "centre":
			lab.just = t.s
			if t.s == "centre" {
				lab.just = "center"
			}
		case "point":
			lab.point = true
		case "nopoint":
			lab.point = false
		case "font", "textcolor", "tc", "offset", "rotate":
			if t.s == "rotate" {
				if p.isIdent("by") {
					p.next()
					ex.parseNumExprNoComma()
				}
				continue
			}
			if t.s == "offset" {
				ex.tryCoord()
				for p.isOp(",") {
					p.next()
					ex.tryCoord()
				}
				continue
			}
			if !p.endOfCmd() {
				p.next()
			}
		}
	}
}

func sortLabels() {
	for i := 1; i < len(S.labels); i++ {
		for j := i; j > 0 && S.labels[j].tag < S.labels[j-1].tag; j-- {
			S.labels[j], S.labels[j-1] = S.labels[j-1], S.labels[j]
		}
	}
}

func (ex *Exec) coordSys() string {
	p := ex.p
	for _, c := range []string{"first", "second", "graph", "screen", "character"} {
		if p.isIdent(c) {
			p.next()
			return c
		}
	}
	return "first"
}

func (ex *Exec) setArrow(unset bool) {
	p := ex.p
	tag := 0
	if !p.endOfCmd() && p.peek().kind != tIdent {
		tag = int(ex.parseNumExprNoComma())
	}
	if unset {
		if tag == 0 {
			S.arrows = nil
		}
		for k, a := range S.arrows {
			if a.tag == tag {
				S.arrows = append(S.arrows[:k], S.arrows[k+1:]...)
				break
			}
		}
		return
	}
	if tag == 0 {
		tag = 1
		for _, a := range S.arrows {
			if a.tag >= tag {
				tag = a.tag + 1
			}
		}
	}
	var ar *Arrow
	for _, a := range S.arrows {
		if a.tag == tag {
			ar = a
		}
	}
	if ar == nil {
		ar = &Arrow{tag: tag}
		S.arrows = append(S.arrows, ar)
	}
	for !p.endOfCmd() {
		t := p.next()
		switch t.s {
		case "from":
			ex.coordSys()
			ar.x1 = ex.parseNumExprNoComma()
			p.expect(",", "',' expected")
			ex.coordSys()
			ar.y1 = ex.parseNumExprNoComma()
		case "to", "rto":
			ar.rto = t.s == "rto"
			ex.coordSys()
			ar.x2 = ex.parseNumExprNoComma()
			p.expect(",", "',' expected")
			ex.coordSys()
			ar.y2 = ex.parseNumExprNoComma()
		case "nohead":
			ar.nohead = true
		case "head":
			ar.nohead = false
		case "heads":
			ar.heads = true
		}
	}
}

func (ex *Exec) setFit(unset bool) {
	p := ex.p
	for !p.endOfCmd() {
		t := p.next()
		switch t.s {
		case "quiet":
			S.fitQuiet = true
			S.fitVerbose = false
		case "brief":
			S.fitQuiet = false
			S.fitVerbose = false
		case "verbose":
			S.fitQuiet = false
			S.fitVerbose = true
		case "nolog":
			S.fitNoLog = true
		case "logfile":
			S.fitNoLog = false
			if !p.endOfCmd() && ex.isStringStart() {
				S.fitLog = ex.parseStrExpr()
			}
		case "errorvariables":
			S.fitErrVars = true
		case "noerrorvariables":
			S.fitErrVars = false
		case "covariancevariables":
			S.fitCovVars = true
		case "nocovariancevariables":
			S.fitCovVars = false
		case "prescale":
			S.fitPrescale = true
		case "noprescale":
			S.fitPrescale = false
		case "limit":
			S.fitLimit = ex.parseNumExprNoComma()
		case "maxiter":
			if n, ok := ex.tryNum(); ok {
				S.fitMaxIter = int(n)
			}
		case "nomaxiter":
			S.fitMaxIter = 0
		}
	}
	if unset {
		S.fitQuiet = false
	}
}

func closePrint() {
	if printFile != nil {
		printFile.Flush()
		printFileH.Close()
		printFile = nil
	}
	if printDatablock != "" && printDBPartial != "" {
		datablocks[printDatablock] = append(datablocks[printDatablock], printDBPartial)
		printDBPartial = ""
	}
	printDatablock = ""
	printToStdout = false
	printFileName = ""
}

func closeTable() {
	if S.tableOut != nil {
		S.tableOut.Flush()
		S.tableFH.Close()
	}
	S.tableOn = false
	S.tableOut = nil
	S.tableFH = nil
	S.tableFile = ""
	S.tableDB = ""
}

var _ = math.Pi
var _ = fmt.Sprintf
