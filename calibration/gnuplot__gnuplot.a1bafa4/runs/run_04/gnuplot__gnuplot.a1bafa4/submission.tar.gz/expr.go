package main

import (
	"math"
	"math/cmplx"
	"strings"
)

type Frame struct {
	args []Value
}

type Expr func(f *Frame) Value

type Parser struct {
	toks    []Token
	i       int
	text    string
	dummies []string
}

var undefFlag bool

func (p *Parser) peek() *Token { return &p.toks[p.i] }
func (p *Parser) peekN(n int) *Token {
	if p.i+n < len(p.toks) {
		return &p.toks[p.i+n]
	}
	return &p.toks[len(p.toks)-1]
}
func (p *Parser) isOp(s string) bool {
	t := &p.toks[p.i]
	return t.kind == tOp && t.s == s
}
func (p *Parser) isOpN(n int, s string) bool {
	t := p.peekN(n)
	return t.kind == tOp && t.s == s
}
func (p *Parser) isIdent(s string) bool {
	t := &p.toks[p.i]
	return t.kind == tIdent && t.s == s
}
func (p *Parser) next() *Token {
	t := &p.toks[p.i]
	if t.kind != tEOF {
		p.i++
	}
	return t
}
func (p *Parser) pos() int { return p.toks[p.i].pos }

// end of command: ';', EOF, newline
func (p *Parser) endOfCmd() bool {
	t := &p.toks[p.i]
	return t.kind == tEOF || t.kind == tNL || (t.kind == tOp && t.s == ";")
}

func (p *Parser) expect(s string, msg string) {
	if !p.isOp(s) {
		gperr(p.pos(), msg)
	}
	p.next()
}

// full expression (with assignment), no serial comma
func (p *Parser) parseExpr() Expr {
	t := p.peek()
	if t.kind == tIdent && p.isOpN(1, "=") && !p.isOpN(2, "=") {
		name := t.s
		p.next()
		p.next()
		rhs := p.parseExpr()
		return func(f *Frame) Value {
			v := rhs(f)
			setVar(name, v)
			return v
		}
	}
	return p.parseTernary()
}

func (p *Parser) parseTernary() Expr {
	cond := p.parseBinary(0)
	if p.isOp("?") {
		p.next()
		a := p.parseTernary()
		if !p.isOp(":") {
			gperr(p.pos(), "expecting ':'")
		}
		p.next()
		b := p.parseTernary()
		return func(f *Frame) Value {
			c := cond(f)
			if c.t == STR {
				rterr("Non-numeric string found where a numeric expression was expected")
			}
			if !isZero(c) {
				return a(f)
			}
			return b(f)
		}
	}
	return cond
}

var binLevels = [][]string{
	{"||"},
	{"&&"},
	{"|"},
	{"^"},
	{"&"},
	{"==", "!=", "eq", "ne"},
	{"<", "<=", ">", ">="},
	{"<<", ">>"},
	{"+", "-", "."},
	{"*", "/", "%"},
}

func (p *Parser) matchLevel(level int) string {
	t := p.peek()
	if t.kind != tOp && t.kind != tIdent {
		return ""
	}
	for _, op := range binLevels[level] {
		if t.s == op {
			if t.kind == tIdent && op != "eq" && op != "ne" {
				continue
			}
			if t.kind == tOp && (op == "eq" || op == "ne") {
				continue
			}
			// avoid treating '|' closing cardinality? handled by caller context
			return op
		}
	}
	return ""
}

var noBarDepth int

func (p *Parser) parseBinary(level int) Expr {
	if level >= len(binLevels) {
		return p.parseUnary()
	}
	lhs := p.parseBinary(level + 1)
	for {
		op := p.matchLevel(level)
		if op == "" {
			return lhs
		}
		if op == "|" && noBarDepth > 0 {
			return lhs
		}
		p.next()
		if p.endOfCmd() {
			gperr(p.pos(), "invalid expression ")
		}
		rhs := p.parseBinary(level + 1)
		l := lhs
		o := op
		switch o {
		case "&&":
			lhs = func(f *Frame) Value {
				a := l(f)
				if isZero(intReq(a, "&&")) {
					return IntV(0)
				}
				if isZero(intReq(rhs(f), "&&")) {
					return IntV(0)
				}
				return IntV(1)
			}
		case "||":
			lhs = func(f *Frame) Value {
				a := l(f)
				if !isZero(intReq(a, "||")) {
					return IntV(1)
				}
				if !isZero(intReq(rhs(f), "||")) {
					return IntV(1)
				}
				return IntV(0)
			}
		default:
			lhs = func(f *Frame) Value {
				a := l(f)
				b := rhs(f)
				return binop(o, a, b)
			}
		}
	}
}

func intReq(v Value, op string) Value {
	v = toNum(v)
	if v.t != INT {
		rterr("non-integer passed to boolean operator")
	}
	return v
}

func (p *Parser) parseUnary() Expr {
	t := p.peek()
	if t.kind == tOp {
		switch t.s {
		case "-", "+", "!", "~":
			op := t.s
			p.next()
			e := p.parseUnary()
			switch op {
			case "-":
				return func(f *Frame) Value { return negate(e(f)) }
			case "+":
				return func(f *Frame) Value { return toNum(e(f)) }
			case "!":
				return func(f *Frame) Value {
					v := toNum(e(f))
					if v.t != INT {
						rterr("non-integer operand for !")
					}
					if v.i == 0 {
						return IntV(1)
					}
					return IntV(0)
				}
			case "~":
				return func(f *Frame) Value {
					v := toNum(e(f))
					if v.t != INT {
						rterr("non-integer operand for ~")
					}
					return IntV(^v.i)
				}
			}
		}
	}
	return p.parsePower()
}

func (p *Parser) parsePower() Expr {
	base := p.parsePostfix()
	if p.isOp("**") {
		p.next()
		exp := p.parseUnary()
		return func(f *Frame) Value { return power(base(f), exp(f)) }
	}
	return base
}

func (p *Parser) parsePostfix() Expr {
	e := p.parsePrimary()
	for {
		if p.isOp("!") && !p.isOpN(1, "=") {
			p.next()
			inner := e
			e = func(f *Frame) Value { return factorial(inner(f)) }
			continue
		}
		if p.isOp("[") {
			p.next()
			var a, b Expr
			if p.isOp(":") {
				a = nil
			} else {
				a = p.parseExpr()
			}
			if p.isOp("]") && a != nil {
				p.next()
				inner := e
				idx := a
				e = func(f *Frame) Value {
					v := inner(f)
					return indexValue(v, idx(f))
				}
				continue
			}
			p.expect(":", "':' expected")
			if p.isOp("]") {
				b = nil
			} else if p.isOp("*") && p.isOpN(1, "]") {
				p.next()
				b = nil
			} else {
				b = p.parseExpr()
			}
			p.expect("]", "']' expected")
			inner := e
			ea, eb := a, b
			e = func(f *Frame) Value {
				v := inner(f)
				if v.t != STR {
					rterr("internal error : substring range operator applied to non-STRING type")
				}
				beg := int64(1)
				end := int64(math.MaxInt32)
				if ea != nil {
					beg = int64(realOf(ea(f)))
				}
				if eb != nil {
					end = int64(realOf(eb(f)))
				}
				return StrV(substr(v.s, beg, end))
			}
			continue
		}
		return e
	}
}

func substr(s string, beg, end int64) string {
	n := int64(len(s))
	if beg < 1 {
		beg = 1
	}
	if end > n {
		end = n
	}
	if beg > end {
		return ""
	}
	return s[beg-1 : end]
}

func indexValue(v Value, iv Value) Value {
	if v.t == ARR {
		i := int64(realOf(iv))
		a := *v.arr
		if i < 1 || i >= int64(len(a)) {
			rterr("array index out of range")
		}
		return a[i]
	}
	if v.t == STR {
		i := int64(realOf(iv))
		return StrV(substr(v.s, i, i))
	}
	rterr("indexing a non-array")
	return v
}

func (p *Parser) dummyIndex(name string) int {
	for k, d := range p.dummies {
		if d == name {
			return k
		}
	}
	return -1
}

func (p *Parser) parsePrimary() Expr {
	t := p.peek()
	switch t.kind {
	case tNum:
		p.next()
		v := t.val
		return func(f *Frame) Value { return v }
	case tStr:
		p.next()
		v := StrV(t.s)
		return func(f *Frame) Value { return v }
	case tOp:
		switch t.s {
		case "(":
			p.next()
			saved := noBarDepth
			noBarDepth = 0
			e := p.parseExpr()
			for p.isOp(",") {
				p.next()
				e2 := p.parseExpr()
				e1 := e
				e = func(f *Frame) Value { e1(f); return e2(f) }
			}
			noBarDepth = saved
			p.expect(")", "')' expected")
			return e
		case "{":
			p.next()
			re := p.parseSignedConst()
			p.expect(",", "',' expected")
			im := p.parseSignedConst()
			p.expect("}", "'}' expected")
			v := CmplxV(re, im)
			return func(f *Frame) Value { return v }
		case "|":
			p.next()
			if p.peek().kind != tIdent {
				gperr(p.pos(), "not an array")
			}
			noBarDepth++
			e := p.parseBinary(0)
			noBarDepth--
			p.expect("|", "'|' expected")
			return func(f *Frame) Value {
				v := e(f)
				if v.t == ARR {
					return IntV(int64(len(*v.arr) - 1))
				}
				if v.t == DBLOCK {
					return IntV(int64(len(datablocks[v.s])))
				}
				rterr("cardinality of non-array")
				return v
			}
		case "$":
			p.next()
			pos := p.pos()
			_ = pos
			e := p.parsePrimary()
			return func(f *Frame) Value { return columnValue(e(f), false) }
		}
	case tIdent:
		name := t.s
		if name[0] == '$' {
			p.next()
			if len(name) > 1 && isDigit(name[1]) {
				n := int64(0)
				for _, c := range name[1:] {
					n = n*10 + int64(c-'0')
				}
				return func(f *Frame) Value { return columnValue(IntV(n), false) }
			}
			if p.isOp("[") {
				// datablock line indexing
				p.next()
				ie := p.parseExpr()
				p.expect("]", "']' expected")
				return func(f *Frame) Value {
					lines, ok := datablocks[name]
					if !ok {
						rterr("undefined variable: " + name)
					}
					i := int(realOf(ie(f)))
					if i < 1 || i > len(lines) {
						rterr("index out of range")
					}
					return StrV(lines[i-1])
				}
			}
			return func(f *Frame) Value {
				if _, ok := datablocks[name]; !ok {
					rterr("undefined variable: " + name)
				}
				return Value{t: DBLOCK, s: name}
			}
		}
		if name == "sum" && p.isOpN(1, "[") {
			p.next()
			p.next()
			vt := p.next()
			if vt.kind != tIdent {
				gperr(vt.pos, "syntax error")
			}
			p.expect("=", "'=' expected")
			a := p.parseExpr()
			p.expect(":", "':' expected")
			b := p.parseExpr()
			p.expect("]", "']' expected")
			body := p.parseTernary()
			vn := vt.s
			return func(f *Frame) Value {
				lo := toNum(a(f))
				hi := toNum(b(f))
				l, h := int64(realOf(lo)), int64(realOf(hi))
				old, had := vars[vn]
				var acc Value = IntV(0)
				for k := l; k <= h; k++ {
					setVar(vn, IntV(k))
					acc = binop("+", acc, body(f))
				}
				if had {
					vars[vn] = old
				} else {
					delete(vars, vn)
				}
				return acc
			}
		}
		if p.isOpN(1, "(") {
			p.next()
			p.next()
			var args []Expr
			if !p.isOp(")") {
				for {
					args = append(args, p.parseExpr())
					if p.isOp(",") {
						p.next()
						continue
					}
					break
				}
			}
			p.expect(")", "')' expected")
			return p.makeCall(name, args, t.pos)
		}
		p.next()
		if k := p.dummyIndex(name); k >= 0 {
			return func(f *Frame) Value { return f.args[k] }
		}
		// array element assignment
		if p.isOp("[") {
			// A[i] = expr  handled here
			save := p.i
			p.next()
			ie := p.parseExpr()
			if p.isOp("]") && p.isOpN(1, "=") && !p.isOpN(2, "=") {
				p.next()
				p.next()
				rhs := p.parseExpr()
				return func(f *Frame) Value {
					v, ok := vars[name]
					if !ok || v.t != ARR {
						gperr(t.pos, "Not a known array")
					}
					i := int64(realOf(ie(f)))
					a := *v.arr
					if i < 1 || i >= int64(len(a)) {
						rterr("array index out of range")
					}
					r := rhs(f)
					a[i] = r
					return r
				}
			}
			p.i = save
		}
		return func(f *Frame) Value {
			v, ok := vars[name]
			if !ok {
				rterr("undefined variable: " + name)
			}
			if v.t == UNDEF {
				rterr("undefined variable: " + name)
			}
			return v
		}
	}
	if t.kind == tOp && t.s == "}" {
		rterr("Unexpected }")
	}
	gperr(t.pos, "invalid expression ")
	return nil
}

func (p *Parser) parseSignedConst() float64 {
	neg := false
	if p.isOp("-") {
		neg = true
		p.next()
	} else if p.isOp("+") {
		p.next()
	}
	t := p.peek()
	if t.kind != tNum {
		gperr(t.pos, "invalid complex constant")
	}
	p.next()
	f := realOf(t.val)
	if neg {
		f = -f
	}
	return f
}

func setVar(name string, v Value) {
	if _, ok := varSeq[name]; !ok {
		varCounter++
		varSeq[name] = varCounter
	}
	vars[name] = v
}

// ---------- arithmetic -------------

func negate(v Value) Value {
	v = toNum(v)
	if v.t == INT {
		return IntV(-v.i)
	}
	return CmplxV(-v.r, -v.im)
}

func asC(v Value) complex128 {
	if v.t == INT {
		return complex(float64(v.i), 0)
	}
	return complex(v.r, v.im)
}
func fromC(c complex128) Value { return CmplxV(real(c), imag(c)) }

func binop(op string, a, b Value) Value {
	switch op {
	case ".":
		if a.t != STR || b.t != STR {
			rterr("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		return StrV(a.s + b.s)
	case "eq", "ne":
		if a.t != STR || b.t != STR {
			rterr("internal error : STRING operator applied to undefined or non-STRING variable")
		}
		r := a.s == b.s
		if op == "ne" {
			r = !r
		}
		return boolV(r)
	case "==", "!=":
		var r bool
		{
			a, b = toNum(a), toNum(b)
			if a.t == INT && b.t == INT {
				r = a.i == b.i
			} else {
				r = asC(a) == asC(b)
			}
		}
		if op == "!=" {
			r = !r
		}
		return boolV(r)
	}
	a, b = toNum(a), toNum(b)
	if a.t == INT && b.t == INT {
		x, y := a.i, b.i
		switch op {
		case "+":
			s := x + y
			if (x >= 0) == (y >= 0) && (s >= 0) != (x >= 0) {
				return RealV(float64(x) + float64(y))
			}
			return IntV(s)
		case "-":
			s := x - y
			if (x >= 0) != (y >= 0) && (s >= 0) != (x >= 0) {
				return RealV(float64(x) - float64(y))
			}
			return IntV(s)
		case "*":
			if x != 0 && y != 0 {
				s := x * y
				if s/y != x || (x == -1 && y == math.MinInt64) || (y == -1 && x == math.MinInt64) {
					return RealV(float64(x) * float64(y))
				}
				return IntV(s)
			}
			return IntV(0)
		case "/":
			if y == 0 {
				undefFlag = true
				return IntV(0)
			}
			return IntV(x / y)
		case "%":
			if y == 0 {
				undefFlag = true
				return IntV(0)
			}
			return IntV(x % y)
		case "<":
			return boolV(x < y)
		case "<=":
			return boolV(x <= y)
		case ">":
			return boolV(x > y)
		case ">=":
			return boolV(x >= y)
		case "&":
			return IntV(x & y)
		case "|":
			return IntV(x | y)
		case "^":
			return IntV(x ^ y)
		case "<<":
			return IntV(int64(uint64(x) << uint64(y)))
		case ">>":
			return IntV(int64(uint64(x) >> uint64(y)))
		}
	}
	switch op {
	case "%", "&", "|", "^", "<<", ">>":
		rterr("non-integer operand for " + op)
	}
	if a.im == 0 && b.im == 0 {
		x, y := realOf(a), realOf(b)
		switch op {
		case "+":
			return RealV(x + y)
		case "-":
			return RealV(x - y)
		case "*":
			return RealV(x * y)
		case "/":
			if y == 0 {
				undefFlag = true
				return RealV(0)
			}
			return RealV(x / y)
		case "<":
			return boolV(x < y)
		case "<=":
			return boolV(x <= y)
		case ">":
			return boolV(x > y)
		case ">=":
			return boolV(x >= y)
		}
	}
	x, y := asC(a), asC(b)
	switch op {
	case "+":
		return fromC(x + y)
	case "-":
		return fromC(x - y)
	case "*":
		return fromC(x * y)
	case "/":
		if y == 0 {
			undefFlag = true
			return RealV(0)
		}
		return fromC(x / y)
	case "<":
		return boolV(real(x) < real(y))
	case "<=":
		return boolV(real(x) <= real(y))
	case ">":
		return boolV(real(x) > real(y))
	case ">=":
		return boolV(real(x) >= real(y))
	}
	rterr("unknown operator " + op)
	return a
}

func boolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

func power(a, b Value) Value {
	a, b = toNum(a), toNum(b)
	if a.t == INT && b.t == INT {
		x, y := a.i, b.i
		if y >= 0 {
			r := int64(1)
			overflow := false
			for k := int64(0); k < y; k++ {
				nr := r * x
				if x != 0 && nr/x != r {
					overflow = true
					break
				}
				r = nr
				if r == 0 || r == 1 && x == 1 {
					break
				}
			}
			if x == -1 {
				if y%2 == 0 {
					return IntV(1)
				}
				return IntV(-1)
			}
			if !overflow && math.Abs(math.Pow(float64(x), float64(y))) < 9.2e18 {
				return IntV(r)
			}
			return RealV(math.Pow(float64(x), float64(y)))
		}
		if x == 0 {
			undefFlag = true
			return RealV(0)
		}
		return RealV(math.Pow(float64(x), float64(y)))
	}
	if a.im == 0 && b.im == 0 {
		x, y := realOf(a), realOf(b)
		if x >= 0 || y == math.Trunc(y) {
			if x == 0 && y < 0 {
				undefFlag = true
				return RealV(0)
			}
			return RealV(math.Pow(x, y))
		}
	}
	x, y := asC(a), asC(b)
	if x == 0 {
		if real(y) == 0 && imag(y) == 0 {
			return RealV(1)
		}
		return RealV(0)
	}
	return fromC(cmplx.Pow(x, y))
}

func factorial(v Value) Value {
	v = toNum(v)
	if v.t != INT {
		rterr("factorial (!) argument must be an integer")
	}
	n := v.i
	if n <= 20 {
		r := int64(1)
		for k := int64(2); k <= n; k++ {
			r *= k
		}
		return IntV(r)
	}
	return RealV(math.Gamma(float64(n) + 1))
}

// parse expression from a string (used by value(), etc.)
func parseString(s string, dummies []string) Expr {
	p := &Parser{toks: lex(s), text: s, dummies: dummies}
	e := p.parseExpr()
	return e
}

var _ = strings.TrimSpace
