package main

import (
	"strconv"
	"strings"
)

const (
	tEOF = iota
	tNum
	tStr
	tIdent
	tOp
	tNL
)

type Token struct {
	kind int
	s    string // raw text for ident/op; decoded string for tStr
	pos  int
	end  int
	val  Value
	sq   bool // single quoted
}

func isAlpha(c byte) bool {
	return c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }

func decodeDQ(s string) string {
	var sb strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == '\\' && i+1 < len(s) {
			i++
			switch s[i] {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			case 'a':
				sb.WriteByte(7)
			case 'b':
				sb.WriteByte(8)
			case 'f':
				sb.WriteByte(12)
			case 'v':
				sb.WriteByte(11)
			case '"':
				sb.WriteByte('"')
			case '\\':
				sb.WriteByte('\\')
			case '\n':
			case '0', '1', '2', '3', '4', '5', '6', '7':
				v := 0
				k := 0
				for k < 3 && i < len(s) && s[i] >= '0' && s[i] <= '7' {
					v = v*8 + int(s[i]-'0')
					i++
					k++
				}
				i--
				sb.WriteByte(byte(v))
			default:
				sb.WriteByte('\\')
				sb.WriteByte(s[i])
			}
		} else {
			sb.WriteByte(c)
		}
	}
	return sb.String()
}

// lex tokenizes a command text. Newlines become tNL tokens. Comments are skipped.
func lex(text string) []Token {
	var toks []Token
	i := 0
	n := len(text)
	for i < n {
		c := text[i]
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '\n' {
			toks = append(toks, Token{kind: tNL, s: "\n", pos: i, end: i + 1})
			i++
			continue
		}
		if c == '#' {
			for i < n && text[i] != '\n' {
				i++
			}
			continue
		}
		st := i
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(text[i+1])) {
			// number
			j := i
			isFloat := false
			if c == '0' && j+1 < n && (text[j+1] == 'x' || text[j+1] == 'X') {
				j += 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", text[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(text[i+2:j], 16, 64)
				toks = append(toks, Token{kind: tNum, s: text[i:j], pos: st, end: j, val: IntV(int64(v))})
				i = j
				continue
			}
			for j < n && isDigit(text[j]) {
				j++
			}
			if j < n && text[j] == '.' {
				isFloat = true
				j++
				for j < n && isDigit(text[j]) {
					j++
				}
			}
			if j < n && (text[j] == 'e' || text[j] == 'E') {
				k := j + 1
				if k < n && (text[k] == '+' || text[k] == '-') {
					k++
				}
				if k < n && isDigit(text[k]) {
					for k < n && isDigit(text[k]) {
						k++
					}
					j = k
					isFloat = true
				}
			}
			s := text[i:j]
			var v Value
			if isFloat {
				f, _ := strconv.ParseFloat(s, 64)
				v = RealV(f)
			} else {
				if len(s) > 1 && s[0] == '0' {
					x, err := strconv.ParseInt(s, 8, 64)
					if err != nil {
						// strtoll stops at first invalid digit
						k := 0
						for k < len(s) && s[k] >= '0' && s[k] <= '7' {
							k++
						}
						x, _ = strconv.ParseInt(s[:k], 8, 64)
					}
					v = IntV(x)
				} else {
					x, err := strconv.ParseInt(s, 10, 64)
					if err != nil {
						f, _ := strconv.ParseFloat(s, 64)
						v = RealV(f)
					} else {
						v = IntV(x)
					}
				}
			}
			toks = append(toks, Token{kind: tNum, s: s, pos: st, end: j, val: v})
			i = j
			continue
		}
		if isAlpha(c) {
			j := i
			for j < n && (isAlpha(text[j]) || isDigit(text[j])) {
				j++
			}
			toks = append(toks, Token{kind: tIdent, s: text[i:j], pos: st, end: j})
			i = j
			continue
		}
		if c == '"' {
			j := i + 1
			for j < n && text[j] != '"' {
				if text[j] == '\\' && j+1 < n {
					j++
				}
				j++
			}
			raw := text[i+1 : min(j, n)]
			if j < n {
				j++
			}
			toks = append(toks, Token{kind: tStr, s: decodeDQ(raw), pos: st, end: j})
			i = j
			continue
		}
		if c == '\'' {
			j := i + 1
			var sb strings.Builder
			for j < n {
				if text[j] == '\'' {
					if j+1 < n && text[j+1] == '\'' {
						sb.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				sb.WriteByte(text[j])
				j++
			}
			if j < n {
				j++
			}
			toks = append(toks, Token{kind: tStr, s: sb.String(), pos: st, end: j, sq: true})
			i = j
			continue
		}
		if c == '$' {
			j := i + 1
			for j < n && (isAlpha(text[j]) || isDigit(text[j])) {
				j++
			}
			if j > i+1 {
				toks = append(toks, Token{kind: tIdent, s: text[i:j], pos: st, end: j})
				i = j
				continue
			}
		}
		if i+1 < n {
			two := text[i : i+2]
			switch two {
			case "**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||":
				toks = append(toks, Token{kind: tOp, s: two, pos: st, end: i + 2})
				i += 2
				continue
			}
		}
		toks = append(toks, Token{kind: tOp, s: string(c), pos: st, end: i + 1})
		i++
	}
	toks = append(toks, Token{kind: tEOF, pos: n, end: n})
	return toks
}
