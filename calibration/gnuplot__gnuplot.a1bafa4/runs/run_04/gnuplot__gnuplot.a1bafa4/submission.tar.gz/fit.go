package main

import (
	"os"
	"strconv"
	"fmt"
	"math"
	"strings"
)

var hfac = 1e-3
var central = false
func (ex *Exec) fitCmd() {
	p := ex.p
	ranges := []*Axis{}
	for p.isOp("[") {
		a := newAxis("f")
		ex.parseRange(a)
		ranges = append(ranges, a)
	}
	// function expression with dummies x,y
	dummies := []string{S.dummy1, S.dummy2}
	fst := p.pos()
	sp := &Parser{toks: p.toks, i: p.i, text: p.text, dummies: dummies}
	fexpr := sp.parseTernary()
	fText := strings.TrimSpace(ex.text[fst:sp.peek().pos])
	p.i = sp.i
	_ = fText
	var file string
	if p.peek().kind == tIdent && p.peek().s[0] == '$' {
		file = p.next().s
	} else {
		file = ex.parseStrExpr()
	}
	e := &PlotElem{file: file, lt: -1, pt: -1, style: "points"}
	var params []string
	errKind := ""
	for !p.endOfCmd() {
		t := p.peek()
		switch {
		case abbrev("u$sing", t.s):
			p.next()
			e.using, e.usingText = ex.parseUsing()
		case abbrev("i$ndex", t.s):
			p.next()
			a := int(ex.parseNumExprNoComma())
			e.index = [3]int{a, a, 1}
			e.hasIndex = true
		case abbrev("ev$ery", t.s):
			p.next()
			e.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if p.isOp(":") {
					p.next()
					continue
				}
				if p.endOfCmd() || p.peek().kind == tIdent {
					break
				}
				e.every[k] = int(ex.parseNumExprNoComma())
				if p.isOp(":") {
					p.next()
				} else {
					break
				}
			}
			e.hasEvery = true
		case t.s == "yerror" || t.s == "yerrors" || t.s == "zerror" || t.s == "zerrors" || t.s == "xyerror" || t.s == "xyerrors" || t.s == "errors" || t.s == "error" || t.s == "unitweights":
			p.next()
			errKind = t.s
			if t.s == "errors" || t.s == "error" {
				for !p.endOfCmd() && !p.isIdent("via") {
					p.next()
				}
				errKind = "yerror"
			}
		case t.s == "via":
			p.next()
			if p.peek().kind == tStr {
				rterr("via file not supported")
			}
			for {
				pt := p.next()
				params = append(params, pt.s)
				if p.isOp(",") {
					p.next()
					continue
				}
				break
			}
		default:
			gperr(t.pos, "unexpected or unrecognized token: "+t.s)
		}
	}
	if len(params) == 0 {
		gperr(p.pos(), "Need via and either parameter list or file")
	}
	sets, ok := readData(file)
	if !ok {
		if strings.HasPrefix(file, "$") {
			rterr("undefined variable: " + file)
		}
		rterr(fmt.Sprintf("Cannot find or open file \"%s\"", file))
	}
	// collect data
	var X, Y, Z, W []float64
	ncols := len(e.using)
	for si, ds := range sets {
		if e.hasIndex && si != e.index[0] {
			continue
		}
		row := 0
		for _, blk := range ds.blocks {
			for _, rec := range blk {
				curRow = rec.fields
				curRowNum = row
				row++
				var vals []float64
				valid := true
				if ncols == 0 {
					for k := 0; k < len(rec.fields) && k < 2; k++ {
						v, ok := fieldValue(rec.fields[k])
						if !ok {
							valid = false
						}
						vals = append(vals, v)
					}
					if len(vals) == 1 {
						vals = []float64{float64(row - 1), vals[0]}
					}
				} else {
					for _, u := range e.using {
						var v float64
						if u.isExpr {
							undefFlag = false
							r := u.expr(&Frame{})
							v = realOf(r)
							if undefFlag || math.IsNaN(v) {
								valid = false
							}
						} else if u.col == 0 {
							v = float64(curRowNum)
						} else if u.col <= len(rec.fields) {
							var ok bool
							v, ok = fieldValue(rec.fields[u.col-1])
							if !ok {
								valid = false
							}
						} else {
							valid = false
						}
						vals = append(vals, v)
					}
					if len(vals) == 1 {
						vals = []float64{float64(row - 1), vals[0]}
					}
				}
				if !valid || len(vals) < 2 {
					continue
				}
				x := vals[0]
				var y, z, w float64
				w = 1
				switch {
				case len(vals) == 2:
					z = vals[1]
				case len(vals) == 3 && errKind == "yerror":
					z = vals[1]
					w = vals[2]
				case len(vals) == 3:
					y = vals[1]
					z = vals[2]
				default:
					y = vals[1]
					z = vals[2]
					if errKind != "" {
						w = vals[3]
					}
				}
				if len(ranges) > 0 && !ranges[0].inRange(x) {
					continue
				}
				X = append(X, x)
				Y = append(Y, y)
				Z = append(Z, z)
				W = append(W, w)
			}
		}
	}
	N := len(X)
	P := len(params)
	if N == 0 {
		rterr("No data to fit")
	}
	// initial values
	p0 := make([]float64, P)
	for k, n := range params {
		v, ok := vars[n]
		if !ok {
			p0[k] = 1
			vars[n] = RealV(1)
		} else {
			p0[k] = realOf(v)
		}
	}
	scale := make([]float64, P)
	for k := range p0 {
		scale[k] = 1
		if S.fitPrescale && p0[k] != 0 {
			scale[k] = p0[k]
		}
	}
	if v := os.Getenv("HF"); v != "" { hfac, _ = strconv.ParseFloat(v, 64) }
	central = os.Getenv("CD") == "1"
	if os.Getenv("SM") == "1" { for k := range scale { scale[k] = 1 } }
	model := func(par []float64) []float64 {
		for k, n := range params {
			vars[n] = RealV(par[k])
		}
		out := make([]float64, N)
		for i := 0; i < N; i++ {
			undefFlag = false
			v := fexpr(&Frame{args: []Value{RealV(X[i]), RealV(Y[i])}})
			out[i] = realOf(v)
			if undefFlag {
				rterr("Undefined value during function evaluation")
			}
		}
		return out
	}
	chisqOf := func(par []float64) (float64, []float64) {
		m := model(par)
		res := make([]float64, N)
		c := 0.0
		for i := range m {
			res[i] = (Z[i] - m[i]) / W[i]
			c += res[i] * res[i]
		}
		return c, res
	}
	jacobian := func(par []float64) [][]float64 {
		J := make([][]float64, N)
		for i := range J {
			J[i] = make([]float64, P)
		}
		base := model(par)
		for k := 0; k < P; k++ {
			h := math.Abs(par[k]) * hfac
			if h == 0 {
				h = hfac
			}
			pp := append([]float64{}, par...)
			pp[k] += h
			m2 := model(pp)
			if central {
				pm := append([]float64{}, par...)
				pm[k] -= h
				m3 := model(pm)
				for i := 0; i < N; i++ {
					J[i][k] = (m2[i] - m3[i]) / (2 * h) / W[i] * scale[k]
				}
			} else {
			for i := 0; i < N; i++ {
				J[i][k] = (m2[i] - base[i]) / h / W[i] * scale[k]
			}
			}
		}
		return J
	}
	par := append([]float64{}, p0...)
	chisq, res := chisqOf(par)
	J := jacobian(par)
	sumsq := 0.0
	for i := range J {
		for k := range J[i] {
			sumsq += J[i][k] * J[i][k]
		}
	}
	lambda := math.Sqrt(sumsq / float64(N*P))
	quiet := S.fitQuiet
	var sb strings.Builder
	hdr := "iter      chisq       delta/lim  lambda  "
	for _, n := range params {
		hdr += fmt.Sprintf(" %-13s", n)
	}
	hdr += "\n"
	iterLine := func(it int, c, d, l float64, pr []float64) string {
		s := fmt.Sprintf("%4d %-16.10e %10.2e %9.2e ", it, c, d, l)
		for _, v := range pr {
			s += fmt.Sprintf(" %14.6e", v)
		}
		return s + "\n"
	}
	sb.WriteString(hdr)
	sb.WriteString(iterLine(0, chisq, 0, lambda, par))
	if !quiet {
		errWrite(sb.String())
	}
	sb.Reset()
	iter := 0
	lastDelta := 0.0
	maxIter := S.fitMaxIter
	converged := false
	for {
		// solve (J^T J + lambda^2 I) d = J^T r
		A := make([][]float64, P)
		g := make([]float64, P)
		for a := 0; a < P; a++ {
			A[a] = make([]float64, P)
			for b := 0; b < P; b++ {
				s := 0.0
				for i := 0; i < N; i++ {
					s += J[i][a] * J[i][b]
				}
				A[a][b] = s
			}
			A[a][a] += lambda * lambda
			s := 0.0
			for i := 0; i < N; i++ {
				s += J[i][a] * res[i]
			}
			g[a] = s
		}
		d := solveLinear(A, g)
		np := make([]float64, P)
		for k := range par {
			np[k] = par[k] + d[k]*scale[k]
		}
		nchisq, nres := chisqOf(np)
		if nchisq < chisq || nchisq == chisq {
			iter++
			delta := (nchisq - chisq) / nchisq
			if nchisq == 0 {
				delta = 0
			}
			lastDelta = delta
			lambda /= 10
			par = np
			oldchisq := chisq
			chisq = nchisq
			res = nres
			if !quiet {
				errWrite(iterLine(iter, chisq, delta/S.fitLimit, lambda, par))
			}
			if math.Abs(oldchisq-nchisq) <= S.fitLimit*nchisq || nchisq == 0 {
				converged = true
				break
			}
			J = jacobian(par)
		} else {
			lambda *= 10
			if lambda > 1e20 {
				break
			}
		}
		if maxIter > 0 && iter >= maxIter {
			break
		}
	}
	for k, n := range params {
		vars[n] = RealV(par[k])
	}
	// covariance
	Jf := jacobian(par)
	for k, n := range params {
		vars[n] = RealV(par[k])
	}
	A := make([][]float64, P)
	for a := 0; a < P; a++ {
		A[a] = make([]float64, P)
		for b := 0; b < P; b++ {
			s := 0.0
			for i := 0; i < N; i++ {
				s += Jf[i][a] * Jf[i][b]
			}
			A[a][b] = s
		}
	}
	C := invertMatrix(A)
	ndf := N - P
	stdfit := 0.0
	if ndf > 0 {
		stdfit = math.Sqrt(chisq / float64(ndf))
	}
	errs := make([]float64, P)
	for k := 0; k < P; k++ {
		errs[k] = math.Sqrt(math.Abs(C[k][k])) * scale[k] * stdfit
		if ndf == 0 {
			errs[k] = math.Sqrt(math.Abs(C[k][k])) * scale[k]
		}
	}
	setVar("FIT_NDF", IntV(int64(ndf)))
	setVar("FIT_WSSR", RealV(chisq))
	setVar("FIT_STDFIT", RealV(stdfit))
	setVar("FIT_NITER", IntV(int64(iter)))
	setVar("FIT_CONVERGED", boolV(converged))
	if S.fitErrVars {
		for k, n := range params {
			setVar(n+"_err", RealV(errs[k]))
		}
	}
	if quiet {
		return
	}
	sb.WriteString(hdr)
	sb.WriteString("\n")
	if converged {
		sb.WriteString(fmt.Sprintf("After %d iterations the fit converged.\n", iter))
	} else {
		sb.WriteString(fmt.Sprintf("After %d iterations the fit did not converge.\n", iter))
	}
	sb.WriteString(fmt.Sprintf("final sum of squares of residuals : %s\n", cfmt("%g", chisq)))
	sb.WriteString(fmt.Sprintf("rel. change during last iteration : %s\n\n", cfmt("%g", lastDelta)))
	sb.WriteString(fmt.Sprintf("degrees of freedom    (FIT_NDF)                        : %d\n", ndf))
	sb.WriteString(fmt.Sprintf("rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", cfmt("%g", stdfit)))
	sb.WriteString(fmt.Sprintf("variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n\n", cfmt("%g", stdfit*stdfit)))
	sb.WriteString("Final set of parameters            Asymptotic Standard Error\n")
	sb.WriteString("=======================            ==========================\n")
	for k, n := range params {
		pct := 0.0
		if par[k] != 0 {
			pct = math.Abs(errs[k] / par[k] * 100)
		}
		sb.WriteString(fmt.Sprintf("%-15s = %-15s  +/- %-12s (%s%%)\n", n, cfmt("%.6g", par[k]), cfmt("%.4g", errs[k]), cfmt("%.4g", pct)))
	}
	sb.WriteString("\ncorrelation matrix of the fit parameters:\n")
	sb.WriteString("                ")
	for _, n := range params {
		sb.WriteString(fmt.Sprintf("%-7s", n))
	}
	sb.WriteString("\n")
	for a, n := range params {
		sb.WriteString(fmt.Sprintf("%-15s", n))
		for b := 0; b <= a; b++ {
			c := C[a][b] / math.Sqrt(C[a][a]*C[b][b])
			sb.WriteString(fmt.Sprintf("%6.3f ", c))
		}
		sb.WriteString("\n")
	}
	errWrite(sb.String())
}

func solveLinear(A [][]float64, b []float64) []float64 {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		M[c], M[piv] = M[piv], M[c]
		if M[c][c] == 0 {
			continue
		}
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := 0; i < n; i++ {
		if M[i][i] != 0 {
			x[i] = M[i][n] / M[i][i]
		}
	}
	return x
}

func invertMatrix(A [][]float64) [][]float64 {
	n := len(A)
	inv := make([][]float64, n)
	for i := 0; i < n; i++ {
		e := make([]float64, n)
		e[i] = 1
		col := solveLinear(A, e)
		for j := 0; j < n; j++ {
			if inv[j] == nil {
				inv[j] = make([]float64, n)
			}
			inv[j][i] = col[j]
		}
	}
	return inv
}
