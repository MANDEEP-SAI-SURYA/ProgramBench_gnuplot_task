package main

import (
	"fmt"
	"sort"
	"strings"
)

func rangeNum(v float64) string {
	return cfmt("%g", v)
}

func fmtRangeVal(v float64) string {
	// gnuplot uses %#g like formatting with 6 significant digits
	s := cfmt("%#g", v)
	return s
}

func showRange(name string, a *Axis) string {
	lo, hi := "*", "*"
	if !a.autoMin {
		lo = fmtRangeVal(a.min)
	}
	if !a.autoMax {
		hi = fmtRangeVal(a.max)
	}
	rev := "noreverse"
	if a.reverse {
		rev = "reverse"
	}
	s := fmt.Sprintf("\tset %srange [ %s : %s ] %s nowriteback", name, lo, hi, rev)
	if a.autoMin || a.autoMax {
		s += fmt.Sprintf("  # (currently [%s:%s] )", cfmt("%#g", a.min), cfmt("%#g", a.max))
	}
	return s + "\n"
}

func (ex *Exec) showCmd() {
	p := ex.p
	if p.endOfCmd() {
		gperr(p.pos(), "show what?")
	}
	t := p.next()
	w := t.s
	var sb strings.Builder
	sb.WriteString("\n")
	if a, ok := axisFromPrefix(w, "range"); ok {
		sb.WriteString(showRange(strings.TrimSuffix(w, "range"), a))
		sb.WriteString("\n")
		errWrite(sb.String())
		return
	}
	if a, ok := axisFromPrefix(w, "label"); ok && w != "label" {
		an := strings.TrimSuffix(w, "label")
		extra := ""
		if an == "y" {
			extra = ", rotated by -270 degrees in 2D plots"
		}
		sb.WriteString(fmt.Sprintf("\t%slabel is \"%s\", offset at (character %s, %s, 0)center justified %s textcolor lt -1\n\n", an, a.label, cfmt("%g", a.labelOffX), cfmt("%g", a.labelOffY), extra))
		errWrite(sb.String())
		return
	}
	if a, ok := axisFromPrefix(w, "data"); ok && w != "data" {
		an := strings.TrimSuffix(w, "data")
		if a.isTime {
			sb.WriteString(fmt.Sprintf("\t%s is set to time\n\n", an))
		} else {
			sb.WriteString(fmt.Sprintf("\t%s is set to numerical\n\n", an))
		}
		errWrite(sb.String())
		return
	}
	switch {
	case abbrev("sa$mples", w):
		sb.WriteString(fmt.Sprintf("\tsampling rate is %d, %d\n\n", S.samples1, S.samples2))
	case abbrev("iso$samples", w):
		sb.WriteString(fmt.Sprintf("\tiso sampling rate is %d, %d\n\n", S.iso1, S.iso2))
	case abbrev("tit$le", w):
		font := ""
		if S.titleFont != "" {
			font = fmt.Sprintf(", using font \"%s\"", S.titleFont)
		}
		sb.WriteString(fmt.Sprintf("\ttitle is \"%s\", offset at (character 0, 0, 0)center justified %s textcolor lt -1\n\n", S.title, font))
	case abbrev("k$ey", w):
		if !S.keyOn {
			sb.WriteString("\tkey is OFF\n\n")
			break
		}
		pos := S.keyPosV + " " + S.keyPosH
		if S.keyPosV == "center" && S.keyPosH == "center" {
			pos = "center"
		}
		ori := "vertical"
		if !S.keyVertical {
			ori = "horizontal"
		}
		inside := ""
		if !S.keyInside {
			inside = ""
		}
		_ = inside
		sb.WriteString(fmt.Sprintf("\tkey is ON, position: %s %s fixed  offset: (character 0, 0)\n", pos, ori))
		rev := "not reversed"
		if S.keyReverse {
			rev = "reversed"
		}
		box := "not boxed"
		if S.keyBox {
			box = "boxed\n\twith linetype -2 linewidth 1.000 dashtype solid"
		}
		sb.WriteString(fmt.Sprintf("\tkey is %s justified, %s, not inverted, enhanced and %s\n", S.keyJust, rev, box))
		sb.WriteString("\tsample length is 4 characters\n\tvertical spacing is 1 characters\n\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n\n")
		sb.WriteString(fmt.Sprintf("\tkey title is \"%s\" center justified \n\n", S.keyTitle))
	case abbrev("st$yle", w):
		if p.endOfCmd() {
			ex.skipToEnd()
			return
		}
		t2 := p.next().s
		if abbrev("d$ata", t2) {
			sb.WriteString(fmt.Sprintf("\tData are plotted with %s\n\n", S.styleData))
		} else if abbrev("f$unction", t2) {
			sb.WriteString(fmt.Sprintf("\tFunctions are plotted with %s\n\n", S.styleFunc))
		} else {
			ex.skipToEnd()
			return
		}
	case abbrev("g$rid", w):
		if !S.grid {
			sb.WriteString("\tgrid is OFF\n\n")
		} else {
			at := ""
			if S.gridX {
				at += "x "
			}
			if S.gridMX {
				at += "mx "
			}
			if S.gridY {
				at += "y "
			}
			if S.gridMY {
				at += "my "
			}
			sb.WriteString(fmt.Sprintf("\tRectangular grid drawn at %stics\n", at))
			sb.WriteString("\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n")
		}
	case abbrev("log$scale", w):
		s := ""
		for _, an := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			a := S.axes[an]
			if a.log {
				if a.base == 10 {
					s += " " + an
				} else {
					s += fmt.Sprintf(" %s (base %s)", an, cfmt("%g", a.base))
				}
			}
		}
		if s == "" {
			sb.WriteString("\tlogscaling on none\n\n")
		} else {
			sb.WriteString("\tlogscaling on " + s + "\n\n")
		}
	case abbrev("form$at", w):
		sb.WriteString("\ttic format is:\n")
		for _, an := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			sb.WriteString(fmt.Sprintf("\t  %s-axis: \"%s\"\n", an, S.axes[an].tics.format))
		}
		sb.WriteString("\n")
	case abbrev("an$gles", w):
		if angleDegrees {
			sb.WriteString("\tAngles are in degrees\n\n")
		} else {
			sb.WriteString("\tAngles are in radians\n\n")
		}
	case abbrev("t$erminal", w):
		sb.Reset()
		switch S.termName {
		case "dumb":
			feed := "feed"
			if !S.termFeed {
				feed = "nofeed"
			}
			sb.WriteString(fmt.Sprintf("\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", feed, S.termW, S.termH))
		default:
			sb.WriteString(fmt.Sprintf("\n   terminal type is %s \n\n", S.termName))
		}
	case abbrev("o$utput", w):
		if S.output == "" {
			sb.WriteString("\toutput is sent to STDOUT\n\n")
		} else {
			sb.WriteString(fmt.Sprintf("\toutput is sent to '%s'\n\n", S.output))
		}
	case abbrev("pr$int", w):
		switch {
		case printDatablock != "":
			sb.WriteString(fmt.Sprintf("\tprint output is saved to datablock %s\n\n", printDatablock))
		case printToStdout:
			sb.WriteString("\tprint output is sent to '<stdout>'\n\n")
		case printFile != nil:
			sb.WriteString(fmt.Sprintf("\tprint output is sent to '%s'\n\n", printFileName))
		default:
			sb.WriteString("\tprint output is sent to '<stderr>'\n\n")
		}
	case abbrev("dataf$ile", w):
		if S.missing == "" {
			sb.WriteString("\tNo missing data string set for datafile\n")
		} else {
			sb.WriteString(fmt.Sprintf("\t\"%s\" in datafile is interpreted as missing value\n", S.missing))
		}
		if S.sepChar == "" {
			sb.WriteString("\tdatafile fields separated by whitespace\n")
		} else {
			sb.WriteString(fmt.Sprintf("\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.sepChar), S.sepChar))
		}
		sb.WriteString(fmt.Sprintf("\tComments chars are \"%s\"\n", S.commentChars))
		sb.WriteString("\tFirst line is treated as headers only if accessed explicitly\n\n")
	case abbrev("z$ero", w):
		sb.WriteString(fmt.Sprintf("\tzero is %s\n\n", cfmt("%g", S.zero)))
	case abbrev("par$ametric", w):
		sb.WriteString(fmt.Sprintf("\tparametric is %s\n\n", onoff(S.parametric)))
	case abbrev("pol$ar", w):
		sb.WriteString(fmt.Sprintf("\tpolar is %s\n\n", onoff(S.polar)))
	case abbrev("v$ariables", w):
		all := false
		prefix := ""
		if p.isIdent("all") {
			p.next()
			all = true
		} else if !p.endOfCmd() {
			prefix = p.next().s
		}
		if prefix != "" {
			sb.WriteString(fmt.Sprintf("\tVariables beginning with %s:\n", prefix))
		} else {
			sb.WriteString("\tUser and default variables:\n")
		}
		for _, n := range varOrder() {
			if prefix != "" && !strings.HasPrefix(n, prefix) {
				continue
			}
			if !all && prefix == "" && (strings.HasPrefix(n, "GPVAL_") || strings.HasPrefix(n, "MOUSE_")) {
				continue
			}
			v := vars[n]
			sb.WriteString(fmt.Sprintf("\t%s = %s\n", n, showVal(v)))
		}
		sb.WriteString("\n")
	case abbrev("f$unctions", w):
		sb.WriteString("\tUser-Defined Functions:\n")
		for _, n := range udfOrder {
			if u, ok := udfs[n]; ok {
				sb.WriteString("\t" + u.defText + "\n")
			}
		}
		sb.WriteString("\n")
	case abbrev("ve$rsion", w):
		sb.WriteString("\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		ex.skipToEnd()
	case abbrev("du$mmy", w):
		sb.WriteString(fmt.Sprintf("\tdummy variables are %s %s \n\n", S.dummy1, S.dummy2))
	case abbrev("timef$mt", w):
		sb.WriteString(fmt.Sprintf("\tDefault format for reading time data is \"%s\"\n\n", S.timefmt))
	case abbrev("tab$le", w):
		if S.tableOn {
			sb.WriteString("\ttable mode is on, field separator tab\n\n")
		} else {
			sb.WriteString("\ttable mode is off\n\n")
		}
	case abbrev("box$width", w):
		if !S.boxwidthSet {
			sb.WriteString("\tboxwidth is auto\n")
		} else if S.boxwidthAbs {
			sb.WriteString(fmt.Sprintf("\tboxwidth is %s absolute\n", cfmt("%g", S.boxwidth)))
		} else {
			sb.WriteString(fmt.Sprintf("\tboxwidth is %s relative\n", cfmt("%g", S.boxwidth)))
		}
		sb.WriteString("\tboxdepth is 0\n\n")
	case abbrev("poi$ntsize", w):
		sb.WriteString(fmt.Sprintf("\tpointsize is %s\n\n", cfmt("%g", S.pointsize)))
	case abbrev("offset$s", w):
		sb.WriteString(fmt.Sprintf("\toffsets are %s, %s, %s, %s\n\n", cfmt("%g", S.offsets[0]), cfmt("%g", S.offsets[1]), cfmt("%g", S.offsets[2]), cfmt("%g", S.offsets[3])))
	case abbrev("bor$der", w):
		if S.border == 0 {
			sb.WriteString("\tborder is not drawn\n\n")
		} else {
			sb.WriteString(fmt.Sprintf("\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.border, S.border))
		}
	case w == "size":
		sb.WriteString(fmt.Sprintf("\tsize is scaled by %s,%s\n", cfmt("%g", S.sizeX), cfmt("%g", S.sizeY)))
		if S.sizeSquare {
			sb.WriteString("\tTry to set aspect ratio to 1:1.0\n\n")
		} else {
			sb.WriteString("\tNo attempt to control aspect ratio\n\n")
		}
	case abbrev("or$igin", w):
		sb.WriteString(fmt.Sprintf("\torigin is set to %s,%s\n\n", cfmt("%g", S.originX), cfmt("%g", S.originY)))
	case abbrev("mar$gins", w) || w == "margin":
		for k, n := range []string{"lmargin", "rmargin", "bmargin", "tmargin"} {
			if S.margins[k] < 0 {
				sb.WriteString(fmt.Sprintf("\t%s is computed automatically\n", n))
			} else {
				sb.WriteString(fmt.Sprintf("\t%s is set to %s\n", n, cfmt("%g", S.margins[k])))
			}
		}
		sb.WriteString("\n")
	case abbrev("dec$imalsign", w):
		if S.decimalsign == "" {
			sb.WriteString("\tdecimalsign for input is  . \n\tdecimalsign for output has default value (normally '.')\n\tdegree sign for output is ° \n\n")
		} else {
			sb.WriteString(fmt.Sprintf("\tdecimalsign for input is  . \n\tdecimalsign for output is %s \n\tdegree sign for output is ° \n\n", S.decimalsign))
		}
	case abbrev("cl$ip", w):
		sb.WriteString("\tpoint clip is OFF\n")
		if S.clipOne {
			sb.WriteString("\tclipping lines with one end out of range (clip one)\n")
		} else {
			sb.WriteString("\tnot clipping lines with one end out of range (clip one)\n")
		}
		if S.clipTwo {
			sb.WriteString("\tclipping lines with both ends out of range (clip two)\n")
		} else {
			sb.WriteString("\tnot drawing lines with both ends out of range (clip two)\n")
		}
		sb.WriteString("\tnot clipping lines on polar plot at maximum radius\n\n")
	case abbrev("vi$ew", w):
		sb.WriteString(fmt.Sprintf("\tview is %s rot_x, %s rot_z, %s scale, %s scale_z\n\t\t axes are independently scaled\n\t\t azimuth 0\n\n", cfmt("%g", S.viewRotX), cfmt("%g", S.viewRotZ), cfmt("%g", S.viewScale), cfmt("%g", S.viewScaleZ)))
	case abbrev("enc$oding", w):
		sb.WriteString(fmt.Sprintf("\tnominal character encoding is %s\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n", S.encoding))
	case abbrev("la$bel", w):
		for _, l := range S.labels {
			pt := "nopoint"
			if l.point {
				pt = "point with color of linetype 1 pointtype 1"
			}
			sb.WriteString(fmt.Sprintf("\tlabel %d \"%s\" at (%s, %s, %s) %s not rotated back  %s\n", l.tag, l.text, cfmt("%#g", l.x), cfmt("%#g", l.y), cfmt("%#g", 0.0), l.just, pt))
		}
		sb.WriteString("\n")
	case abbrev("ar$row", w):
		for _, a := range S.arrows {
			head := "head"
			if a.nohead {
				head = "nohead"
			} else if a.heads {
				head = "heads"
			}
			sb.WriteString(fmt.Sprintf("\tarrow %d, %s nofilled back linewidth 1.000 dashtype solid\n\t  from (%s, %s, %s) %s (%s, %s, %s)\n", a.tag, head, cfmt("%#g", a.x1), cfmt("%#g", a.y1), cfmt("%#g", 0.0), map[bool]string{true: "rto", false: "to"}[a.rto], cfmt("%#g", a.x2), cfmt("%#g", a.y2), cfmt("%#g", 0.0)))
		}
		sb.WriteString("\n")
	case abbrev("mx$tics", w) || w == "mytics" || w == "mztics":
		an := w[1:2]
		sb.Reset()
		a := S.axes[an]
		if a.tics.minor > 0 {
			sb.WriteString(fmt.Sprintf("\tminor %stics are drawn with %d subintervals between major tic marks\n", an, a.tics.minor))
		} else if a.tics.minor < 0 {
			sb.WriteString(fmt.Sprintf("\tminor %stics are computed automatically\n", an))
		} else {
			sb.WriteString(fmt.Sprintf("\tminor %stics are off for linear scales\n\tminor %stics are computed automatically for log scales\n", an, an))
		}
	case abbrev("fit", w):
		if S.fitQuiet {
			sb.WriteString("\tfit will not output results to console.\n")
		} else if S.fitVerbose {
			sb.WriteString("\tfit will output verbose results to console and log-file.\n")
		} else {
			sb.WriteString("\tfit will output brief results to console and log-file.\n")
		}
		sb.WriteString("\tfit can handle up to 12 independent variables\n")
		if S.fitPrescale {
			sb.WriteString("\tfit will prescale parameters by their initial values\n")
		} else {
			sb.WriteString("\tfit will not prescale parameters by their initial values\n")
		}
		if S.fitErrVars {
			sb.WriteString("\tfit will place parameter errors in variables\n")
		} else {
			sb.WriteString("\tfit will not place parameter errors in variables\n")
		}
		if S.fitCovVars {
			sb.WriteString("\tfit will place covariances in variables\n")
		} else {
			sb.WriteString("\tfit will not place covariances in variables\n")
		}
		sb.WriteString("\tfit will scale parameter errors with the reduced chi square\n")
		if S.fitNoLog {
			sb.WriteString("\tfit will not create a log file\n")
		} else if S.fitLog != "" {
			sb.WriteString(fmt.Sprintf("\tlog-file for fits was set by the user to \n\t'%s'\n", S.fitLog))
		} else {
			sb.WriteString("\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
		}
		sb.WriteString(fmt.Sprintf("\tfits will be considered to have converged if  delta chisq < chisq * %s\n", cfmt("%g", S.fitLimit)))
		if S.fitMaxIter > 0 {
			sb.WriteString(fmt.Sprintf("\tfit will stop after a maximum of %d iterations\n", S.fitMaxIter))
		} else {
			sb.WriteString("\tfit has no limit in the number of iterations\n")
		}
		sb.WriteString("\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n")
		sb.WriteString("\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
	case abbrev("auto$scale", w):
		sb.WriteString(fmt.Sprintf("\tautoscaling is \tx: %s, \ty: %s, \n\t               \tx2: %s, \ty2: %s, \n\t               \tz: %s, \tcb: %s, \n", aso(S.axes["x"]), aso(S.axes["y"]), aso(S.axes["x2"]), aso(S.axes["y2"]), aso(S.axes["z"]), aso(S.axes["cb"])))
	case abbrev("cont$ours", w):
		if S.contour {
			sb.WriteString("\tcontour for surfaces are drawn\n\n")
		} else {
			sb.WriteString("\tcontour for surfaces are not drawn\n\n")
		}
	case abbrev("surf$ace", w):
		if S.surface {
			sb.WriteString("\tsurface is drawn \n\n")
		} else {
			sb.WriteString("\tsurface is not drawn\n\n")
		}
	default:
		ex.skipToEnd()
		return
	}
	errWrite(sb.String())
}

func aso(a *Axis) string {
	switch {
	case a.autoMin && a.autoMax:
		return "ON"
	case a.autoMin:
		return "ON (min)"
	case a.autoMax:
		return "ON (max)"
	}
	return "OFF"
}

func onoff(b bool) string {
	if b {
		return "ON"
	}
	return "OFF"
}

func showVal(v Value) string {
	switch v.t {
	case STR:
		return "\"" + v.s + "\""
	case ARR:
		return fmt.Sprintf("<%d element array>", len(*v.arr)-1)
	}
	return valueToString(v)
}

var varSeq = map[string]int{}
var varCounter int

func varOrder() []string {
	var names []string
	for n := range vars {
		if _, ok := varSeq[n]; !ok {
			varCounter++
			varSeq[n] = varCounter
		}
		names = append(names, n)
	}
	sort.Slice(names, func(i, j int) bool { return varSeq[names[i]] < varSeq[names[j]] })
	return names
}

var udfOrder []string
