package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"os/exec"
	"strings"
)

var printFile *bufio.Writer
var printFileH *os.File
var printFileName string
var printToStdout bool
var printDatablock string

// abbreviation matching: pattern like "pr$int"
func abbrev(pat, word string) bool {
	k := strings.IndexByte(pat, '$')
	if k < 0 {
		return pat == word
	}
	full := pat[:k] + pat[k+1:]
	if len(word) < k || len(word) > len(full) {
		return false
	}
	return full[:len(word)] == word
}

func expandMacros(s string) string {
	if !strings.Contains(s, "@") {
		return s
	}
	var sb strings.Builder
	inS, inD := false, false
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inD {
			sb.WriteByte(c)
			if c == '\\' && i+1 < len(s) {
				i++
				sb.WriteByte(s[i])
			} else if c == '"' {
				inD = false
			}
			continue
		}
		if inS {
			sb.WriteByte(c)
			if c == '\'' {
				inS = false
			}
			continue
		}
		if c == '"' {
			inD = true
		} else if c == '\'' {
			inS = true
		} else if c == '#' {
			sb.WriteString(s[i:])
			break
		} else if c == '@' && i+1 < len(s) && isAlpha(s[i+1]) {
			j := i + 1
			for j < len(s) && (isAlpha(s[j]) || isDigit(s[j])) {
				j++
			}
			name := s[i+1 : j]
			v, ok := vars[name]
			if ok && v.t == STR {
				sb.WriteString(v.s)
				i = j - 1
				continue
			}
			warn(name + " is not a string variable")
			i = j - 1
			continue
		}
		sb.WriteByte(c)
	}
	return sb.String()
}

type Exec struct {
	p    *Parser
	text string
	base int
	src  *LineSource
}

func lineAt(text string, base int, pos int) int {
	if pos > len(text) {
		pos = len(text)
	}
	if pos < 0 {
		pos = 0
	}
	return base + strings.Count(text[:pos], "\n")
}

func execText(text string, base int, src *LineSource) {
	p := &Parser{toks: lex(text), text: text}
	ex := &Exec{p: p, text: text, base: base, src: src}
	cmdStart := 0
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GPError); ok {
				pos := e.pos
				lp := pos
				if lp < 0 {
					lp = cmdStart
				}
				panic(&ctxError{e: e, text: text, line: lineAt(text, base, lp), src: src})
			}
			panic(r)
		}
	}()
	for {
		for p.isOp(";") || p.peek().kind == tNL {
			p.next()
		}
		if p.peek().kind == tEOF {
			return
		}
		cmdStart = p.pos()
		curWarnLine = lineAt(text, base, cmdStart)
		curWarnSrc = src
		ex.command()
		t := p.peek()
		if t.kind == tEOF || t.kind == tNL || (t.kind == tOp && t.s == ";") {
			continue
		}
		gperr(t.pos, "unexpected or unrecognized token: "+ex.text[t.pos:t.end])
	}
}

func (ex *Exec) skipToEnd() {
	p := ex.p
	for !p.endOfCmd() {
		p.next()
	}
}

// find matching '}' token index starting at index of '{'
func (ex *Exec) blockBody() (string, int) {
	p := ex.p
	if !p.isOp("{") {
		gperr(p.pos(), "expected {")
	}
	open := p.next()
	depth := 1
	for {
		t := p.peek()
		if t.kind == tEOF {
			gperr(t.pos, "Unmatched {")
		}
		if t.kind == tOp && t.s == "{" {
			depth++
		}
		if t.kind == tOp && t.s == "}" {
			depth--
			if depth == 0 {
				body := ex.text[open.end:t.pos]
				p.next()
				return body, lineAt(ex.text, ex.base, open.end)
			}
		}
		p.next()
	}
}

func (ex *Exec) runBody(body string, line int) {
	execText(body, line, ex.src)
}

func (ex *Exec) isDefinition() bool {
	p := ex.p
	t := p.peek()
	if t.kind != tIdent {
		return false
	}
	if p.isOpN(1, "=") && !p.isOpN(2, "=") {
		return true
	}
	if p.isOpN(1, "(") {
		// ident ( ident , ... ) =
		k := 2
		for {
			if p.peekN(k).kind != tIdent {
				return false
			}
			k++
			if p.isOpN(k, ",") {
				k++
				continue
			}
			if p.isOpN(k, ")") {
				return p.isOpN(k+1, "=") && !p.isOpN(k+2, "=")
			}
			return false
		}
	}
	if p.isOpN(1, "[") {
		// A[expr] = ...  scan to matching ]
		depth := 0
		for k := 1; ; k++ {
			tk := p.peekN(k)
			if tk.kind == tEOF || tk.kind == tNL || (tk.kind == tOp && tk.s == ";") {
				return false
			}
			if tk.kind == tOp && tk.s == "[" {
				depth++
			}
			if tk.kind == tOp && tk.s == "]" {
				depth--
				if depth == 0 {
					return p.isOpN(k+1, "=") && !p.isOpN(k+2, "=")
				}
			}
		}
	}
	return false
}

func (ex *Exec) definition() {
	p := ex.p
	t := p.next()
	name := t.s
	if p.isOp("=") {
		p.next()
		if p.endOfCmd() {
			gperr(p.pos(), "constant expression required")
		}
		st := p.pos()
		e := p.parseExpr()
		undefFlag = false
		v := e(&Frame{})
		if undefFlag {
			undefFlag = false
			gperr(st, "undefined value")
		}
		if strings.HasPrefix(name, "GPVAL_") || name == "pi" && false {
			rterr("Attempt to assign to a read-only variable")
		}
		if v.t == ARR {
			// copy array
			na := append([]Value{}, (*v.arr)...)
			v = Value{t: ARR, arr: &na}
		}
		setVar(name, v)
		return
	}
	if p.isOp("(") {
		p.next()
		var params []string
		for {
			pt := p.next()
			params = append(params, pt.s)
			if p.isOp(",") {
				p.next()
				continue
			}
			break
		}
		p.expect(")", "')' expected")
		p.expect("=", "'=' expected")
		st := p.pos()
		if p.endOfCmd() {
			gperr(p.pos(), "function contains no expression")
		}
		sp := &Parser{toks: p.toks, i: p.i, text: p.text, dummies: params}
		e := sp.parseExpr()
		en := sp.peek().pos
		p.i = sp.i
		def := strings.TrimRight(ex.text[t.pos:en], " \t")
		_ = st
		if _, ok := udfs[name]; !ok {
			udfOrder = append(udfOrder, name)
		}
		udfs[name] = &UDF{name: name, params: params, body: e, defText: def}
		vars["GPFUN_"+name] = StrV(def)
		return
	}
	// array element
	if v, ok := vars[name]; !ok || v.t != ARR {
		gperr(t.pos, "Not a known array")
	}
	p.i--
	e := p.parseExpr()
	undefFlag = false
	e(&Frame{})
}

func (ex *Exec) command() {
	p := ex.p
	t := p.peek()
	if t.kind == tOp && t.s == "!" {
		// shell command
		rest := strings.TrimSpace(ex.text[t.end:])
		if k := strings.IndexByte(rest, '\n'); k >= 0 {
			rest = rest[:k]
		}
		flushAll()
		c := exec.Command("/bin/sh", "-c", rest)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
		for p.peek().kind != tEOF && p.peek().kind != tNL {
			p.next()
		}
		return
	}
	if t.kind == tIdent && t.s[0] == '$' && p.isOpN(1, "<<") {
		ex.datablockDef()
		return
	}
	if t.kind == tIdent && t.s[0] == '$' && p.isOpN(1, "=") {
		// $data = ...?  not supported
	}
	if t.kind != tIdent {
		gperr(t.pos, "invalid command")
	}
	if ex.isDefinition() {
		ex.definition()
		return
	}
	w := t.s
	switch {
	case abbrev("pr$int", w):
		p.next()
		ex.printCmd(false)
	case w == "printerr":
		p.next()
		ex.printCmd(true)
	case w == "if":
		p.next()
		ex.ifCmd()
	case w == "else":
		gperr(t.pos, "else without if")
	case w == "do":
		p.next()
		ex.doCmd()
	case w == "break":
		p.next()
		panic(breakSig{})
	case w == "continue":
		p.next()
		panic(continueSig{})
	case w == "while":
		p.next()
		ex.whileCmd()
	case abbrev("ev$al", w):
		p.next()
		st := p.pos()
		e := p.parseExpr()
		v := e(&Frame{})
		if v.t != STR {
			gperr(st, "expected string")
		}
		execText(expandMacros(v.s), lineAt(ex.text, ex.base, st), ex.src)
	case abbrev("l$oad", w):
		p.next()
		s := ex.stringArg()
		ex.skipToEnd()
		loadFile(s, false)
	case abbrev("ca$ll", w):
		p.next()
		s := ex.stringArg()
		var cargs []string
		for !p.endOfCmd() {
			tk := p.peek()
			if tk.kind == tStr {
				p.next()
				cargs = append(cargs, tk.s)
				continue
			}
			e := p.parsePrimary()
			v := e(&Frame{})
			cargs = append(cargs, valueToString(v))
		}
		callScript(s, cargs, false)
	case abbrev("ex$it", w) || abbrev("q$uit", w):
		p.next()
		code := 0
		if p.isIdent("status") {
			p.next()
			e := p.parseExpr()
			code = int(realOf(e(&Frame{})))
		} else if p.isIdent("error") {
			p.next()
			s := ex.stringArg()
			errWrite(s + "\n")
			code = 1
		}
		finishOutput()
		flushAll()
		os.Exit(code)
	case w == "undefine" || abbrev("undef$ine", w):
		p.next()
		for !p.endOfCmd() {
			tk := p.next()
			name := tk.s
			if strings.HasSuffix(name, "*") || p.isOp("*") {
				if p.isOp("*") {
					p.next()
				}
				for k := range vars {
					if strings.HasPrefix(k, name) && !strings.HasPrefix(k, "GPVAL_") {
						delete(vars, k)
					}
				}
				continue
			}
			if name[0] == '$' {
				delete(datablocks, name)
			} else {
				delete(vars, name)
			}
		}
	case w == "array":
		p.next()
		ex.arrayCmd()
	case abbrev("se$t", w):
		p.next()
		ex.setCmd(false)
	case abbrev("uns$et", w):
		p.next()
		ex.setCmd(true)
	case abbrev("sh$ow", w):
		p.next()
		ex.showCmd()
	case abbrev("res$et", w):
		p.next()
		if p.isIdent("errors") {
			p.next()
			vars["GPVAL_ERRNO"] = IntV(0)
			vars["GPVAL_ERRMSG"] = StrV("")
			return
		}
		if p.isIdent("session") {
			p.next()
		}
		resetSettings()
	case abbrev("p$lot", w):
		p.next()
		ex.plotCmd(false)
	case abbrev("sp$lot", w):
		p.next()
		ex.plotCmd(true)
	case abbrev("rep$lot", w):
		p.next()
		ex.replotCmd()
	case abbrev("st$ats", w):
		p.next()
		ex.statsCmd()
	case abbrev("f$it", w):
		p.next()
		ex.fitCmd()
	case abbrev("cl$ear", w):
		p.next()
		clearCmd()
	case abbrev("pa$use", w):
		p.next()
		ex.pauseCmd()
	case abbrev("sy$stem", w):
		p.next()
		s := ex.stringArg()
		flushAll()
		c := exec.Command("/bin/sh", "-c", s)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
	case w == "cd":
		p.next()
		s := ex.stringArg()
		if err := os.Chdir(s); err != nil {
			rterr("Can't change to this directory")
		}
	case w == "pwd":
		p.next()
		d, _ := os.Getwd()
		errWrite(d + "\n")
	case abbrev("h$elp", w) || w == "?":
		ex.skipToEnd()
	case abbrev("hi$story", w), w == "bind", abbrev("ref$resh", w), w == "raise", w == "lower", w == "test":
		ex.skipToEnd()
	case abbrev("up$date", w):
		ex.skipToEnd()
	case abbrev("sa$ve", w):
		p.next()
		ex.saveCmd()
	default:
		gperr(t.pos, "invalid command")
	}
}

func (ex *Exec) stringArg() string {
	p := ex.p
	st := p.pos()
	if p.endOfCmd() {
		gperr(st, "expecting string")
	}
	e := p.parseExpr()
	v := e(&Frame{})
	if v.t != STR {
		gperr(st, "expecting string")
	}
	return v.s
}

func (ex *Exec) datablockDef() {
	p := ex.p
	name := p.next().s
	p.next() // <<
	tk := p.next()
	eod := tk.s
	var lines []string
	for {
		l, ok := ex.src.next()
		if !ok {
			break
		}
		if strings.TrimRight(l, " \t\r") == eod {
			break
		}
		lines = append(lines, l)
	}
	datablocks[name] = lines
}

func printOut(s string) {
	if printDatablock != "" {
		// accumulate into datablock lines
		pending := printDBPartial + s
		parts := strings.Split(pending, "\n")
		datablocks[printDatablock] = append(datablocks[printDatablock], parts[:len(parts)-1]...)
		printDBPartial = parts[len(parts)-1]
		return
	}
	if printFile != nil {
		printFile.WriteString(s)
		return
	}
	if printToStdout {
		stdout.WriteString(s)
		return
	}
	errWrite(s)
}

var printDBPartial string

func (ex *Exec) printCmd(toErr bool) {
	p := ex.p
	if p.endOfCmd() {
		gperr(p.pos(), "constant expression required")
	}
	out := printOut
	if toErr {
		out = errWrite
	}
	first := true
	for {
		st := p.pos()
		if p.endOfCmd() {
			gperr(st, "constant expression required")
		}
		e := p.parseExpr()
		undefFlag = false
		v := e(&Frame{})
		if undefFlag {
			undefFlag = false
			gperr(st, "undefined value")
		}
		s := ""
		_ = first
		if v.t == ARR {
			s += valueToString(v) + "\n"
		} else if v.t == DBLOCK {
			for _, l := range datablocks[v.s] {
				s += l + "\n"
			}
		} else {
			s += valueToString(v)
		}
		if p.isOp(",") {
			p.next()
			out(s + " ")
			continue
		}
		out(s)
		break
	}
	out("\n")
}

func (ex *Exec) condition() bool {
	p := ex.p
	p.expect("(", "expecting '('")
	st := p.pos()
	e := p.parseExpr()
	p.expect(")", "expecting ')'")
	undefFlag = false
	v := e(&Frame{})
	if undefFlag {
		undefFlag = false
		gperr(st, "undefined value")
	}
	if v.t == STR {
		rterr("Non-numeric string found where a numeric expression was expected")
	}
	return !isZero(v)
}

func (ex *Exec) ifCmd() {
	p := ex.p
	c := ex.condition()
	if !p.isOp("{") {
		// old style: rest of line
		if c {
			ex.command()
			return
		}
		// skip to end of line (not just ';')
		for p.peek().kind != tEOF && p.peek().kind != tNL {
			p.next()
		}
		return
	}
	done := false
	body, line := ex.blockBody()
	if c {
		ex.runBody(body, line)
		done = true
	}
	for p.isIdent("else") {
		p.next()
		if !p.isOp("{") {
			gperr(p.pos(), "expected {else-clause}")
		}
		if p.isIdent("if") && false {
			p.next()
			c2 := false
			if !done {
				c2 = ex.condition()
			} else {
				// skip condition
				p.expect("(", "expecting '('")
				depth := 1
				for depth > 0 && p.peek().kind != tEOF {
					if p.isOp("(") {
						depth++
					} else if p.isOp(")") {
						depth--
					}
					p.next()
				}
			}
			b, l := ex.blockBody()
			if !done && c2 {
				ex.runBody(b, l)
				done = true
			}
			continue
		}
		b, l := ex.blockBody()
		if !done {
			ex.runBody(b, l)
			done = true
		}
		break
	}
}

type breakSig struct{}
type continueSig struct{}

func (ex *Exec) runLoopBody(body string, line int) (brk bool) {
	defer func() {
		if r := recover(); r != nil {
			if _, ok := r.(breakSig); ok {
				brk = true
				return
			}
			if _, ok := r.(continueSig); ok {
				return
			}
			panic(r)
		}
	}()
	ex.runBody(body, line)
	return false
}

// iteration spec: [var=a:b:c] or [var in "words"]
type iterSpec struct {
	name  string
	words []string
	isW   bool
	a     Expr
	b     Expr
	c     Expr
	bStar bool
}

func (ex *Exec) parseIter() *iterSpec {
	p := ex.p
	p.expect("[", "expecting '['")
	it := &iterSpec{}
	vt := p.next()
	if vt.kind != tIdent {
		gperr(vt.pos, "expecting iteration variable")
	}
	it.name = vt.s
	if p.isIdent("in") {
		p.next()
		e := p.parseExpr()
		v := e(&Frame{})
		it.isW = true
		it.words = splitWords(strArgPos(v))
		p.expect("]", "expecting ']'")
		return it
	}
	p.expect("=", "expecting '='")
	it.a = p.parseExpr()
	p.expect(":", "expecting ':'")
	if p.isOp("*") {
		p.next()
		it.bStar = true
	} else {
		it.b = p.parseExpr()
	}
	if p.isOp(":") {
		p.next()
		it.c = p.parseExpr()
	}
	p.expect("]", "expecting ']'")
	return it
}

func strArgPos(v Value) string {
	if v.t != STR {
		rterr("expecting string")
	}
	return v.s
}

func (it *iterSpec) run(f func() bool) {
	if it.isW {
		for _, w := range it.words {
			setVar(it.name, StrV(w))
			if f() {
				return
			}
		}
		return
	}
	a := toNum(it.a(&Frame{}))
	var b Value
	if !it.bStar {
		b = toNum(it.b(&Frame{}))
	}
	step := int64(1)
	if it.c != nil {
		step = int64(realOf(it.c(&Frame{})))
	}
	lo := int64(realOf(a))
	hi := int64(realOf(b))
	if it.bStar {
		hi = math.MaxInt64
	}
	if step == 0 {
		rterr("iteration step cannot be 0")
	}
	for k := lo; (step > 0 && k <= hi) || (step < 0 && k >= hi); k += step {
		setVar(it.name, IntV(k))
		if f() {
			return
		}
	}
}

func (ex *Exec) doCmd() {
	p := ex.p
	if !p.isIdent("for") {
		gperr(p.pos(), "expecting \"do for\"")
	}
	p.next()
	var its []*iterSpec
	for p.isOp("[") {
		its = append(its, ex.parseIter())
	}
	body, line := ex.blockBody()
	var rec func(k int) bool
	rec = func(k int) bool {
		if k == len(its) {
			return ex.runLoopBody(body, line)
		}
		stop := false
		its[k].run(func() bool {
			if rec(k + 1) {
				stop = true
				return true
			}
			return false
		})
		return stop
	}
	rec(0)
}

func (ex *Exec) whileCmd() {
	p := ex.p
	save := p.i
	ex.condition()
	condEnd := p.i
	_ = condEnd
	body, line := ex.blockBody()
	after := p.i
	for {
		p.i = save
		c := ex.condition()
		if !c {
			break
		}
		if ex.runLoopBody(body, line) {
			break
		}
	}
	p.i = after
}

func (ex *Exec) arrayCmd() {
	p := ex.p
	nt := p.next()
	name := nt.s
	var size int64 = -1
	if p.isOp("[") {
		p.next()
		if !p.isOp("]") {
			e := p.parseExpr()
			size = int64(realOf(e(&Frame{})))
		}
		p.expect("]", "expecting ']'")
	}
	var init []Value
	hasInit := false
	if p.isOp("=") {
		p.next()
		if p.isOp("[") {
			hasInit = true
			p.next()
			for !p.isOp("]") {
				if p.isOp(",") {
					init = append(init, Value{})
					p.next()
					continue
				}
				e := p.parseExpr()
				init = append(init, e(&Frame{}))
				if p.isOp(",") {
					p.next()
					if p.isOp("]") {
						init = append(init, Value{})
					}
				}
			}
			p.next()
		} else {
			e := p.parseExpr()
			v := e(&Frame{})
			if v.t == ARR {
				init = append([]Value{}, (*v.arr)[1:]...)
				hasInit = true
			}
		}
	}
	if size < 0 {
		size = int64(len(init))
	}
	arr := make([]Value, size+1)
	if hasInit {
		for k := 0; k < len(init) && int64(k) < size; k++ {
			arr[k+1] = init[k]
		}
	}
	vars[name] = Value{t: ARR, arr: &arr}
}

func (ex *Exec) pauseCmd() {
	p := ex.p
	if p.isIdent("mouse") {
		ex.skipToEnd()
		return
	}
	e := p.parseExpr()
	e(&Frame{})
	if !p.endOfCmd() {
		s := ex.stringArg()
		errWrite(s)
		_ = s
	}
}

func clearCmd() {
	clearPending()
}

var _ = fmt.Sprintf
