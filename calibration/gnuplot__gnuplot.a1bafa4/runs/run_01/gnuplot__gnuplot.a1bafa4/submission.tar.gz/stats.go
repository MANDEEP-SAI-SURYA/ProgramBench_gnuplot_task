package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
)

type colStats struct {
	n                                    int
	mean, sd, ssd, skew, kurt, adev, sum float64
	sumsq, min, max, med, q1, q3         float64
	imin, imax                           int
	meanErr, sdErr, skewErr, kurtErr     float64
}

func appendFile(name, s string) {
	f, err := os.OpenFile(name, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return
	}
	f.WriteString(s)
	f.Close()
}

func computeColStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x > s.max {
			s.max = x
			s.imax = i
		}
	}
	fn := float64(n)
	s.mean = s.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	s.sd = math.Sqrt(m2 / fn)
	if n > 1 {
		s.ssd = math.Sqrt(m2 / (fn - 1))
	}
	if s.sd != 0 {
		s.skew = m3 / fn / (s.sd * s.sd * s.sd)
		s.kurt = m4 / fn / (s.sd * s.sd * s.sd * s.sd)
	}
	s.adev = ad / fn
	s.meanErr = s.sd / math.Sqrt(fn)
	s.sdErr = s.sd / math.Sqrt(2*fn)
	s.skewErr = math.Sqrt(6 / fn)
	s.kurtErr = math.Sqrt(24 / fn)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	if n%2 == 1 {
		s.med = sv[n/2]
	} else {
		s.med = (sv[n/2-1] + sv[n/2]) / 2
	}
	if n%4 == 0 {
		s.q1 = (sv[n/4-1] + sv[n/4]) / 2
		s.q3 = (sv[n-1-n/4] + sv[n-n/4]) / 2
	} else {
		s.q1 = sv[n/4]
		s.q3 = sv[n-1-n/4]
	}
	return s
}

func statNum(v float64) string {
	return statNumW(v, 11)
}

func statNumW(v float64, w int) string {
	s := fmt.Sprintf("%.4f", v)
	if len(s) > 11 {
		s = fmt.Sprintf("%.5e", v)
	}
	return fmt.Sprintf("%*s", w, s)
}

func (ex *Exec) parseUsingList(it *plotItem) {
	for {
		if ex.isOp("(") {
			ps := &Parser{toks: ex.toks, p: ex.p}
			n := ps.parsePrimary()
			ex.p = ps.p
			it.using = append(it.using, n)
		} else if ex.peek().Kind == TNUM {
			tk := ex.next()
			it.using = append(it.using, &Node{Op: "col", Kids: []*Node{{Op: "num", Val: IntV(tk.IVal)}}})
		} else if ex.peek().Kind == TSTR {
			tk := ex.next()
			it.using = append(it.using, &Node{Op: "col", Kids: []*Node{{Op: "str", Val: StrV(tk.Text)}}})
		} else {
			ps := &Parser{toks: ex.toks, p: ex.p}
			n := ps.parsePostfix()
			ex.p = ps.p
			it.using = append(it.using, n)
		}
		if ex.isOp(":") {
			ex.p++
			continue
		}
		break
	}
}

func (ex *Exec) cmdStats() {
	xa := newAxis("x")
	ya := newAxis("y")
	if ex.isOp("[") {
		ex.parseRange(xa)
		if ex.isOp("[") {
			ex.parseRange(ya)
		}
	}
	it := &plotItem{lt: -1, pt: -1}
	t := ex.peek()
	if t.Kind == TSTR {
		it.file = ex.evalString()
	} else if t.Kind == TNAME && strings.HasPrefix(t.Text, "$") {
		ex.p++
		it.file = t.Text
	} else {
		n := ex.parseExpr()
		evalTop(n)
	}
	prefix := "STATS"
	output := true
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("u$sing"):
			ex.p++
			ex.parseUsingList(it)
		case ex.isWord("i$ndex"):
			ex.p++
			it.hasIndex = true
			a := int(toInt(ex.evalExpr()))
			it.index = [3]int{a, a, 1}
		case ex.isWord("ev$ery"):
			ex.p++
			it.hasEvery = true
			it.every = [6]int{1, 1, 0, 0, -1, -1}
			it.every[0] = int(toInt(ex.evalExpr()))
		case ex.isWord("name") || ex.isWord("pre$fix"):
			ex.p++
			prefix = ex.evalString()
		case ex.isWord("noout$put"):
			ex.p++
			output = false
		case ex.isWord("out$put"):
			ex.p++
			output = true
		case ex.isWord("matrix"):
			ex.p++
		default:
			tk := ex.peek()
			gpErr(tk.Pos, "unexpected or unrecognized token: "+ex.line[tk.Pos:tk.End])
		}
	}
	lines := readDataSource(it.file)
	inDataCtx = true
	defer func() { inDataCtx = false }()
	var xs, ys []float64
	records, invalid, blank, outr := 0, 0, 0, 0
	blocks := 0
	blankRun := 0
	firstFields := -1
	ncols := 0
	if len(it.using) > 0 {
		ncols = len(it.using)
	}
	lineInBlock := 0
	seenData := false
	for _, ln := range lines {
		tl := strings.TrimSpace(ln)
		if tl == "" {
			blank++
			blankRun++
			lineInBlock = 0
			continue
		}
		if strings.ContainsAny(tl[:1], S.datafileComments) {
			continue
		}
		if !seenData || blankRun >= 2 {
			blocks++
		}
		seenData = true
		blankRun = 0
		fields := splitFields(ln)
		if firstFields < 0 {
			firstFields = len(fields)
			if ncols == 0 {
				ncols = firstFields
				if ncols > 2 {
					ncols = 2
				}
			}
		}
		curFields = fields
		curLineNo = lineInBlock
		lineInBlock++
		var rp rawPoint
		if it.using == nil {
			rp = func() (r rawPoint) {
				defer func() {
					if x := recover(); x != nil {
						if _, ok := x.(*badPoint); ok {
							r = rawPoint{bad: true}
							return
						}
						panic(x)
					}
				}()
				var vals []float64
				for k := 1; k <= ncols; k++ {
					vals = append(vals, colValue(k).R)
				}
				return rawPoint{vals: vals}
			}()
		} else {
			rp = evalUsing(it, fields, firstFields, ncols, false)
			if !rp.bad && len(it.using) == 1 && len(rp.vals) == 2 {
				rp.vals = rp.vals[1:]
			}
		}
		if rp.bad {
			invalid++
			continue
		}
		if (len(rp.vals) >= 1 && outOfRange(xa, rp.vals[0])) || (len(rp.vals) >= 2 && outOfRange(ya, rp.vals[1])) {
			outr++
			continue
		}
		records++
		xs = append(xs, rp.vals[0])
		if ncols >= 2 && len(rp.vals) >= 2 {
			ys = append(ys, rp.vals[1])
		}
	}
	if blocks == 0 {
		blocks = 1
	}
	if records == 0 {
		gpErr(-1, "All points out of range")
	}
	two := ncols >= 2
	sx := computeColStats(xs)
	var sy colStats
	if two {
		sy = computeColStats(ys)
	}
	set := func(name string, v Value) { setVar(prefix+"_"+name, v) }
	set("records", IntV(int64(records)))
	set("invalid", IntV(int64(invalid)))
	set("headers", IntV(0))
	set("blank", IntV(int64(blank)))
	set("blocks", IntV(int64(blocks)))
	set("outofrange", IntV(int64(outr)))
	if two {
		set("columns", IntV(2))
	} else {
		set("columns", IntV(1))
	}
	setCol := func(s colStats, suf string) {
		set("mean"+suf, FltV(s.mean))
		set("stddev"+suf, FltV(s.sd))
		set("ssd"+suf, FltV(s.ssd))
		set("skewness"+suf, FltV(s.skew))
		set("kurtosis"+suf, FltV(s.kurt))
		set("adev"+suf, FltV(s.adev))
		set("mean_err"+suf, FltV(s.meanErr))
		set("stddev_err"+suf, FltV(s.sdErr))
		set("skewness_err"+suf, FltV(s.skewErr))
		set("kurtosis_err"+suf, FltV(s.kurtErr))
		set("sum"+suf, FltV(s.sum))
		set("sumsq"+suf, FltV(s.sumsq))
		set("min"+suf, FltV(s.min))
		set("max"+suf, FltV(s.max))
		set("median"+suf, FltV(s.med))
		set("lo_quartile"+suf, FltV(s.q1))
		set("up_quartile"+suf, FltV(s.q3))
		set("index_min"+suf, IntV(int64(s.imin)))
		set("index_max"+suf, IntV(int64(s.imax)))
	}
	var slope, icept, slopeErr, iceptErr, corr, sumxy float64
	if two {
		setCol(sx, "_x")
		setCol(sy, "_y")
		n := float64(records)
		var sxx, syy, sxy float64
		for i := range xs {
			dx := xs[i] - sx.mean
			dy := ys[i] - sy.mean
			sxx += dx * dx
			syy += dy * dy
			sxy += dx * dy
			sumxy += xs[i] * ys[i]
		}
		slope = sxy / sxx
		icept = sy.mean - slope*sx.mean
		corr = sxy / math.Sqrt(sxx*syy)
		if records > 2 {
			ssr := 0.0
			for i := range xs {
				r := ys[i] - (icept + slope*xs[i])
				ssr += r * r
			}
			s2 := ssr / (n - 2)
			slopeErr = math.Sqrt(s2 / sxx)
			iceptErr = math.Sqrt(s2 * (1/n + sx.mean*sx.mean/sxx))
		}
		set("slope", FltV(slope))
		set("intercept", FltV(icept))
		set("slope_err", FltV(slopeErr))
		set("intercept_err", FltV(iceptErr))
		set("correlation", FltV(corr))
		set("sumxy", FltV(sumxy))
		set("pos_min_y", FltV(xs[sy.imin]))
		set("pos_max_y", FltV(xs[sy.imax]))
	} else {
		setCol(sx, "")
	}
	if !output {
		return
	}
	var sb strings.Builder
	w := len(fmt.Sprint(records)) + 4
	if records == 2 && two {
		sb.WriteString("Warning:  Errors of slope and intercept are zero. There are as many data points as there are parameters.\n")
	}
	sb.WriteString("\n* FILE: \n")
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Records:", w, records)
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Out of range:", w, outr)
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Invalid:", w, invalid)
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Header records:", w, 0)
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Blank:", w, blank)
	fmt.Fprintf(&sb, "  %-15s%*d\n", "Data Blocks:", w, blocks)
	if !two {
		s := sx
		sb.WriteString("\n* COLUMN: \n")
		row := func(l string, v float64) { fmt.Fprintf(&sb, "  %-15s%s\n", l, statNum(v)) }
		row("Mean:", s.mean)
		row("Std Dev:", s.sd)
		row("Sample StdDev:", s.ssd)
		row("Skewness:", s.skew)
		row("Kurtosis:", s.kurt)
		row("Avg Dev:", s.adev)
		row("Sum:", s.sum)
		row("Sum Sq.:", s.sumsq)
		sb.WriteString("\n")
		row("Mean Err.:", s.meanErr)
		row("Std Dev Err.:", s.sdErr)
		row("Skewness Err.:", s.skewErr)
		row("Kurtosis Err.:", s.kurtErr)
		sb.WriteString("\n")
		fmt.Fprintf(&sb, "  %-15s%s [%d]\n", "Minimum:", statNum(s.min), s.imin)
		fmt.Fprintf(&sb, "  %-15s%s [%d]\n", "Maximum:", statNum(s.max), s.imax)
		fmt.Fprintf(&sb, "  %-15s%s \n", "Quartile:", statNum(s.q1))
		fmt.Fprintf(&sb, "  %-15s%s \n", "Median:", statNum(s.med))
		fmt.Fprintf(&sb, "  %-15s%s \n", "Quartile:", statNum(s.q3))
		sb.WriteString("\n")
	} else {
		iw := len(fmt.Sprint(max(sx.imin, sx.imax, sy.imin, sy.imax)))
		gap := iw + 3 + 14
		sb.WriteString("\n* COLUMNS:\n")
		row := func(l string, a, b float64) {
			fmt.Fprintf(&sb, "  %-15s%s%s\n", l, statNum(a), statNumW(b, gap))
		}
		row("Mean:", sx.mean, sy.mean)
		row("Std Dev:", sx.sd, sy.sd)
		row("Sample StdDev:", sx.ssd, sy.ssd)
		row("Skewness:", sx.skew, sy.skew)
		row("Kurtosis:", sx.kurt, sy.kurt)
		row("Avg Dev:", sx.adev, sy.adev)
		row("Sum:", sx.sum, sy.sum)
		row("Sum Sq.:", sx.sumsq, sy.sumsq)
		sb.WriteString("\n")
		row("Mean Err.:", sx.meanErr, sy.meanErr)
		row("Std Dev Err.:", sx.sdErr, sy.sdErr)
		row("Skewness Err.:", sx.skewErr, sy.skewErr)
		row("Kurtosis Err.:", sx.kurtErr, sy.kurtErr)
		sb.WriteString("\n")
		fmt.Fprintf(&sb, "  %-15s%s [%*d]%s [%*d]\n", "Minimum:", statNum(sx.min), iw, sx.imin, statNumW(sy.min, 14), iw, sy.imin)
		fmt.Fprintf(&sb, "  %-15s%s [%*d]%s [%*d]\n", "Maximum:", statNum(sx.max), iw, sx.imax, statNumW(sy.max, 14), iw, sy.imax)
		row("Quartile:", sx.q1, sy.q1)
		row("Median:", sx.med, sy.med)
		row("Quartile:", sx.q3, sy.q3)
		sb.WriteString("\n")
		sign := "+"
		ic := icept
		if ic < 0 {
			sign = "-"
			ic = -ic
		}
		fmt.Fprintf(&sb, "  %-20sy = %s x %s %s\n", "Linear Model:", cFormatG(slope, 4, false), sign, cFormatG(ic, 4, false))
		fmt.Fprintf(&sb, "  %-20s%s +- %s\n", "Slope:", cFormatG(slope, 4, false), cFormatG(slopeErr, 4, false))
		fmt.Fprintf(&sb, "  %-20s%s +- %s\n", "Intercept:", cFormatG(icept, 4, false), cFormatG(iceptErr, 4, false))
		fmt.Fprintf(&sb, "  %-20sr = %s\n", "Correlation:", cFormatG(corr, 4, false))
		fmt.Fprintf(&sb, "  %-20s%s\n", "Sum xy:", cFormatG(sumxy, 4, false))
		sb.WriteString("\n")
	}
	stderr.WriteString(sb.String())
}

// ---------------- fit ----------------

func (ex *Exec) cmdFit() {
	var ranges []*Axis
	for ex.isOp("[") {
		ax := newAxis("x")
		ex.parseRange(ax)
		ranges = append(ranges, ax)
	}
	fn := ex.parseExpr()
	it := &plotItem{lt: -1, pt: -1}
	t := ex.peek()
	if t.Kind == TSTR {
		it.file = ex.evalString()
	} else if t.Kind == TNAME && strings.HasPrefix(t.Text, "$") {
		ex.p++
		it.file = t.Text
	} else {
		gpErr(t.Pos, "missing data file")
	}
	var params []string
	errMode := ""
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("u$sing"):
			ex.p++
			ex.parseUsingList(it)
		case ex.isWord("i$ndex"):
			ex.p++
			it.hasIndex = true
			a := int(toInt(ex.evalExpr()))
			it.index = [3]int{a, a, 1}
		case ex.isWord("ev$ery"):
			ex.p++
			it.hasEvery = true
			it.every = [6]int{1, 1, 0, 0, -1, -1}
			it.every[0] = int(toInt(ex.evalExpr()))
		case ex.isWord("yerr$ors") || ex.isWord("xyerr$ors") || ex.isWord("err$ors") || ex.isWord("zerr$ors") || ex.isWord("xerr$ors"):
			errMode = ex.next().Text
		case ex.isWord("unitw$eights"):
			ex.p++
		case ex.isWord("via"):
			ex.p++
			for {
				tk := ex.next()
				params = append(params, tk.Text)
				if ex.isOp(",") {
					ex.p++
					continue
				}
				break
			}
		default:
			tk := ex.peek()
			gpErr(tk.Pos, "unexpected or unrecognized token: "+ex.line[tk.Pos:tk.End])
		}
	}
	if len(params) == 0 {
		gpErr(ex.peek().Pos, "Need via and either parameter list or file")
	}
	ncol := 2
	if errMode != "" {
		ncol = 3
	}
	pts, _ := readItemData(it, ncol, false)
	var xs, ys, ws []float64
	for _, p := range pts {
		if p.brk || p.bad || len(p.vals) < 2 {
			continue
		}
		if len(ranges) > 0 && outOfRange(ranges[0], p.vals[0]) {
			continue
		}
		xs = append(xs, p.vals[0])
		ys = append(ys, p.vals[1])
		w := 1.0
		if errMode != "" && len(p.vals) >= 3 && p.vals[2] != 0 {
			w = 1 / p.vals[2]
		}
		ws = append(ws, w)
	}
	N := len(xs)
	M := len(params)
	if N == 0 {
		gpErr(-1, "No data to fit")
	}
	p0 := make([]float64, M)
	for i, name := range params {
		v, ok := vars[name]
		if !ok || v.T == VUNDEF {
			v = FltV(1)
		}
		p0[i] = v.numify().Real()
	}
	scale := make([]float64, M)
	for i := range p0 {
		scale[i] = 1
		if S.fitPrescale && p0[i] != 0 {
			scale[i] = math.Abs(p0[i])
		}
	}
	dummy := S.dummy1
	scope := map[string]Value{}
	evalModel := func(p []float64) ([]float64, bool) {
		for i, name := range params {
			vars[name] = FltV(p[i])
		}
		localStack = append(localStack, scope)
		defer func() { localStack = localStack[:len(localStack)-1] }()
		out := make([]float64, N)
		for k := 0; k < N; k++ {
			scope[dummy] = FltV(xs[k])
			v, ok := safeEval(fn)
			if !ok {
				return nil, false
			}
			out[k] = v.numify().Real()
		}
		return out, true
	}
	chisqOf := func(f []float64) float64 {
		s := 0.0
		for k := range f {
			r := (ys[k] - f[k]) * ws[k]
			s += r * r
		}
		return s
	}
	jacobian := func(p []float64, f0 []float64) [][]float64 {
		J := make([][]float64, N)
		for k := range J {
			J[k] = make([]float64, M)
		}
		for i := 0; i < M; i++ {
			pp := append([]float64{}, p...)
			h := math.Abs(p[i]) * 1e-3
			if h == 0 {
				h = 1e-3
			}
			pp[i] = p[i] + h
			f1, _ := evalModel(pp)
			for k := 0; k < N; k++ {
				if f1 == nil {
					continue
				}
				J[k][i] = (f1[k] - f0[k]) / h * scale[i] * ws[k]
			}
		}
		evalModel(p)
		return J
	}
	p := append([]float64{}, p0...)
	f, ok := evalModel(p)
	if !ok {
		gpErr(-1, "Undefined value during function evaluation")
	}
	chisq := chisqOf(f)
	J := jacobian(p, f)
	lambda := S.fitStartLambda
	if lambda <= 0 {
		s := 0.0
		for k := 0; k < N; k++ {
			for i := 0; i < M; i++ {
				s += J[k][i] * J[k][i]
			}
		}
		lambda = math.Sqrt(s / float64(N*M))
	}
	factor := S.fitLambdaFactor
	if factor <= 0 {
		factor = 10
	}
	var sb strings.Builder
	hdr := "iter      chisq       delta/lim  lambda  "
	for _, n := range params {
		hdr += fmt.Sprintf(" %-13s", n)
	}
	hdr += "\n"
	line := func(iter string, chi, delta, lam float64, pv []float64) {
		sb.WriteString(fmt.Sprintf("%4s %.10e %10.2e %9.2e ", iter, chi, delta, lam))
		for _, v := range pv {
			sb.WriteString(fmt.Sprintf(" %14.6e", v))
		}
		sb.WriteString("\n")
	}
	sb.WriteString(hdr)
	line("0", chisq, 0, lambda, p)
	iter := 0
	lastRel := 0.0
	converged := false
	maxIter := S.fitMaxIter
	for {
		A := make([][]float64, M)
		g := make([]float64, M)
		for i := 0; i < M; i++ {
			A[i] = make([]float64, M)
			for j := 0; j < M; j++ {
				s := 0.0
				for k := 0; k < N; k++ {
					s += J[k][i] * J[k][j]
				}
				A[i][j] = s
			}
			A[i][i] += lambda * lambda
			s := 0.0
			for k := 0; k < N; k++ {
				s += J[k][i] * (ys[k] - f[k]) * ws[k]
			}
			g[i] = s
		}
		d := solveDense(A, g)
		np := make([]float64, M)
		for i := range p {
			np[i] = p[i] + d[i]*scale[i]
		}
		nf, ok := evalModel(np)
		nchisq := math.Inf(1)
		if ok {
			nchisq = chisqOf(nf)
		}
		rel := (nchisq - chisq) / nchisq
		if nchisq < chisq {
			lambda /= factor
			iter++
			line(fmt.Sprint(iter), nchisq, rel/S.fitLimit, lambda, np)
			p, f = np, nf
			chisq = nchisq
			lastRel = rel
			if -rel < S.fitLimit {
				converged = true
				break
			}
			J = jacobian(p, f)
		} else {
			lambda *= factor
			if math.IsInf(nchisq, 0) {
				rel = 1
			}
			line("*", nchisq, rel/S.fitLimit, lambda, np)
			if nchisq == chisq || lambda > 1e30 {
				converged = true
				lastRel = 0
				break
			}
		}
		if maxIter > 0 && iter >= maxIter {
			break
		}
	}
	evalModel(p)
	for _, name := range params {
		if !varSeen[name] {
			varSeen[name] = true
			varOrder = append(varOrder, name)
		}
	}
	sb.WriteString(hdr)
	ndf := N - M
	J = jacobian(p, f)
	JJ := make([][]float64, M)
	for i := 0; i < M; i++ {
		JJ[i] = make([]float64, M)
		for j := 0; j < M; j++ {
			s := 0.0
			for k := 0; k < N; k++ {
				s += J[k][i] * J[k][j]
			}
			JJ[i][j] = s
		}
	}
	cov := invert(JJ)
	resvar := 0.0
	if ndf > 0 {
		resvar = chisq / float64(ndf)
	}
	errs := make([]float64, M)
	for i := 0; i < M; i++ {
		for j := 0; j < M; j++ {
			cov[i][j] *= scale[i] * scale[j]
		}
	}
	for i := 0; i < M; i++ {
		errs[i] = math.Sqrt(cov[i][i] * resvar)
	}
	if converged {
		fmt.Fprintf(&sb, "\nAfter %d iterations the fit converged.\n", iter)
	} else {
		fmt.Fprintf(&sb, "\nAfter %d iterations the fit did not converge.\n", iter)
	}
	fmt.Fprintf(&sb, "final sum of squares of residuals : %s\n", cfmtg(chisq))
	fmt.Fprintf(&sb, "rel. change during last iteration : %s\n\n", cfmtg(lastRel))
	stdfit := math.Sqrt(resvar)
	fmt.Fprintf(&sb, "degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	fmt.Fprintf(&sb, "rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", cfmtg(stdfit))
	fmt.Fprintf(&sb, "variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n\n", cfmtg(resvar))
	sb.WriteString("Final set of parameters            Asymptotic Standard Error\n")
	sb.WriteString("=======================            ==========================\n")
	for i, name := range params {
		pct := ""
		if p[i] != 0 {
			pct = fmt.Sprintf("(%s%%)", cFormatG(math.Abs(errs[i]/p[i]*100), 4, false))
		}
		fmt.Fprintf(&sb, "%-15s = %-15s  +/- %-12s %s\n", name, cfmtg(p[i]), cFormatG(errs[i], 4, false), pct)
	}
	sb.WriteString("\ncorrelation matrix of the fit parameters:\n")
	sb.WriteString(strings.Repeat(" ", 16))
	for _, name := range params {
		fmt.Fprintf(&sb, "%-7s", name)
	}
	sb.WriteString("\n")
	for i, name := range params {
		fmt.Fprintf(&sb, "%-15s", name)
		for j := 0; j <= i; j++ {
			c := cov[i][j] / math.Sqrt(cov[i][i]*cov[j][j])
			fmt.Fprintf(&sb, "%6.3f ", c)
		}
		sb.WriteString("\n")
	}
	if !S.fitQuiet {
		stderr.WriteString(sb.String())
	}
	setVar("FIT_CONVERGED", IntV(int64(boolInt(converged))))
	setVar("FIT_NDF", IntV(int64(ndf)))
	setVar("FIT_STDFIT", FltV(stdfit))
	setVar("FIT_WSSR", FltV(chisq))
	pval := 0.0
	if ndf > 0 {
		pval = 1 - igamma(float64(ndf)/2, chisq/2)
	}
	setVar("FIT_P", FltV(pval))
	setVar("FIT_NITER", IntV(int64(iter)))
	if S.fitErrVars {
		for i, name := range params {
			setVar(name+"_err", FltV(errs[i]))
		}
	}
	if S.fitCovVars {
		for i, a := range params {
			for j, b := range params {
				setVar("FIT_COV_"+a+"_"+b, FltV(cov[i][j]*resvar))
			}
		}
	}
	if !S.fitNoLog {
		name := S.fitLog
		if name == "" {
			name = "fit.log"
		}
		appendFile(name, sb.String())
	}
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	M := make([][]float64, n)
	for i := range M {
		M[i] = make([]float64, 2*n)
		copy(M[i], A[i])
		M[i][n+i] = 1
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		M[c], M[piv] = M[piv], M[c]
		pv := M[c][c]
		for k := 0; k < 2*n; k++ {
			M[c][k] /= pv
		}
		for r := 0; r < n; r++ {
			if r != c {
				f := M[r][c]
				for k := 0; k < 2*n; k++ {
					M[r][k] -= f * M[c][k]
				}
			}
		}
	}
	out := make([][]float64, n)
	for i := range out {
		out[i] = M[i][n:]
	}
	return out
}
