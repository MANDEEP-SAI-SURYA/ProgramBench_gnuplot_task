package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Point struct {
	x, y, z float64
	ex      []float64
	typ     byte // 'i','o','u'
	label   string
	brk     bool // break marker (blank line)
}

type Curve struct {
	title     string
	hasTitle  bool
	style     string
	points    []Point
	isFunc    bool
	is3D      bool
	lt        int
	lc        int
	pt        int
	ps        float64
	smooth    string
	axisY     string
	origCount int
	nusing    int
	iso       [][]Point // for 3D: isolines
	ltSet     bool
	ptSet     bool
	bins      bool
	binN      int
	fill      bool
}

// data line
type dataRec struct {
	fields []string
	blank  bool
	lineno int
}

var curFields []string
var curLineNo int
var curDataIndex int
var curHeader []string
var inDataCtx bool

func columnRef(v Value, n *Node) Value {
	if !inDataCtx {
		gpErr(-1, "column() called from invalid context")
	}
	if v.T == VSTR {
		for i, h := range curHeader {
			if h == v.S {
				return colValue(i + 1)
			}
		}
		gpErr(-1, "could not find column with header \""+v.S+"\"")
	}
	k := int(toInt(v))
	return colValue(k)
}

type badPoint struct{}

func colValue(k int) Value {
	switch {
	case k == 0:
		return FltV(float64(curLineNo))
	case k == -2:
		return FltV(float64(curDataIndex))
	case k == -1:
		return FltV(0)
	}
	if k < 1 || k > len(curFields) {
		panic(&badPoint{})
	}
	s := curFields[k-1]
	if S.datafileMissing != "" && s == S.datafileMissing {
		panic(&badPoint{})
	}
	f, ok := parseDataNum(s)
	if !ok {
		panic(&badPoint{})
	}
	return FltV(f)
}

func parseDataNum(s string) (float64, bool) {
	t := strings.TrimSpace(s)
	if len(t) >= 2 && t[0] == '"' && t[len(t)-1] == '"' {
		t = t[1 : len(t)-1]
	}
	n := floatPrefixLen(t)
	if n == 0 {
		return 0, false
	}
	// gnuplot accepts trailing garbage? require full for safety-ish
	f, err := strconv.ParseFloat(strings.Replace(t[:n], "D", "e", 1), 64)
	if err != nil {
		return 0, false
	}
	return f, true
}

func columnRefSafe(v Value) (r Value) {
	defer func() {
		if x := recover(); x != nil {
			if _, ok := x.(*badPoint); ok {
				r = Value{}
				return
			}
			panic(x)
		}
	}()
	return columnRef(v, nil)
}

func stringColumn(v Value) Value {
	if !inDataCtx {
		gpErr(-1, "column() called from invalid context")
	}
	k := int(toInt(v))
	if k == 0 {
		return StrV(strconv.Itoa(curLineNo))
	}
	if k < 1 || k > len(curFields) {
		return StrV("")
	}
	s := curFields[k-1]
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		s = s[1 : len(s)-1]
	}
	return StrV(s)
}

func columnHead(v Value) Value {
	k := int(toInt(v))
	if k >= 1 && k <= len(curHeader) {
		return StrV(curHeader[k-1])
	}
	return StrV("")
}

func splitFields(line string) []string {
	if S.datafileSep != "" && S.datafileSep != " " {
		parts := strings.Split(line, S.datafileSep[:1])
		for i := range parts {
			parts[i] = strings.TrimSpace(parts[i])
		}
		return parts
	}
	var out []string
	i := 0
	n := len(line)
	for i < n {
		for i < n && (line[i] == ' ' || line[i] == '\t') {
			i++
		}
		if i >= n {
			break
		}
		if line[i] == '"' {
			j := i + 1
			for j < n && line[j] != '"' {
				j++
			}
			if j < n {
				j++
			}
			out = append(out, line[i:j])
			i = j
			continue
		}
		j := i
		for j < n && line[j] != ' ' && line[j] != '\t' {
			j++
		}
		out = append(out, line[i:j])
		i = j
	}
	return out
}

func readDataSource(name string) []string {
	if strings.HasPrefix(name, "$") {
		l, ok := datablocks[name]
		if !ok {
			gpErr(-1, "undefined data block "+name)
		}
		return l
	}
	data, err := os.ReadFile(name)
	if err != nil {
		gpErr(-1, "Cannot find or open file \""+name+"\"")
	}
	return splitLines(string(data))
}

// ------------- plot command -------------

type plotItem struct {
	isFunc     bool
	expr       *Node
	file       string
	using      []*Node
	usingRaw   []string
	usingStr   string
	title      string
	hasTitle   bool
	noTitle    bool
	style      string
	smooth     string
	index      [3]int
	hasIndex   bool
	every      [6]int
	hasEvery   bool
	lt, pt     int
	ps         float64
	axes       string
	rawText    string
	iters      []*iterSpec
	colHeadTit int
	bins       bool
	binN       int
	ltSet      bool
	ptSet      bool
	lc         int
	dummyRange *Axis
}

var lastPlotLine string
var smoothErrPos = -1
var lastPlotIs3D bool

func (ex *Exec) cmdReplot() {
	if lastPlotLine == "" {
		gpErr(-1, "no previous plot")
	}
	line := lastPlotLine
	toks := tokenize(line)
	sub := &Exec{toks: toks, line: line}
	sub.p = 1
	save := curSrc().curLine
	sub.cmdPlot(lastPlotIs3D)
	curSrc().curLine = save
}

func (ex *Exec) cmdPlot(is3D bool) {
	startTok := ex.p - 1
	// save state of ranges for this plot
	axesSave := map[string]Axis{}
	for k, a := range S.axes {
		axesSave[k] = *a
	}
	defer func() {
		for k, a := range axesSave {
			cur := S.axes[k]
			// keep computed current ranges for auto axes (show xrange "currently")
			cmin, cmax := cur.min, cur.max
			*cur = a
			if a.autoMin {
				cur.min = cmin
			}
			if a.autoMax {
				cur.max = cmax
			}
		}
	}()
	// ranges
	rangeAxes := []string{"x", "y"}
	if is3D {
		rangeAxes = []string{"x", "y", "z"}
	}
	if S.parametric {
		rangeAxes = append([]string{"t"}, rangeAxes...)
	}
	ri := 0
	dummyName := S.dummy1
	for ex.isOp("[") {
		if ri < len(rangeAxes) {
			ax := S.axes[rangeAxes[ri]]
			if ex.at(1).Kind == TNAME && ex.at(2).Kind == TOP && ex.at(2).Text == "=" {
				if ri == 0 {
					dummyName = ex.at(1).Text
				}
			}
			ex.parseRange(ax)
		} else {
			ex.parseRange(newAxis("dummy"))
		}
		ri++
	}
	var items []*plotItem
	for {
		it := ex.parsePlotItem(is3D, dummyName)
		if it != nil {
			items = append(items, it)
		}
		if ex.isOp(",") {
			ex.p++
			continue
		}
		break
	}
	ex.expectEnd()
	lastPlotLine = "plot " + ex.line[ex.toks[startTok+1].Pos:ex.peek().Pos]
	lastPlotIs3D = is3D
	if is3D {
		lastPlotLine = "s" + lastPlotLine
	}
	curves := buildCurves(items, is3D, dummyName)
	if S.tableOn {
		writeTable(curves, is3D)
		return
	}
	switch S.termName {
	case "unknown":
		stderr.WriteString("WARNING: Plotting with an 'unknown' terminal.\nNo output will be generated. Please select a terminal with 'set terminal'.\n")
	case "dumb":
		renderDumb(curves, is3D)
	case "svg":
		renderSVG(curves, is3D)
	case "canvas":
		renderCanvas(curves, is3D)
	}
}

func (ex *Exec) parsePlotItem(is3D bool, dummy string) *plotItem {
	it := &plotItem{lt: -1, pt: -1, ps: -1, axes: "x1y1", lc: -1}
	startPos := ex.peek().Pos
	for ex.isWord("for") {
		ex.p++
		it.iters = append(it.iters, ex.parseIter())
		startPos = ex.peek().Pos
	}
	t := ex.peek()
	// function definition inline: f(x)=..., skip
	if t.Kind == TNAME && ex.at(1).Kind == TOP && ex.at(1).Text == "=" {
		ex.p += 2
		v := ex.evalExpr()
		setVar(t.Text, v)
		return nil
	}
	if t.Kind == TNAME && ex.at(1).Kind == TOP && ex.at(1).Text == "(" && ex.tryFuncDef() {
		return nil
	}
	if t.Kind == TSTR || (t.Kind == TNAME && strings.HasPrefix(t.Text, "$") && !(ex.at(1).Kind == TOP && ex.at(1).Text == "[")) {
		if t.Kind == TSTR {
			// could be string expression
			v := ex.evalExpr()
			it.file = toStr(v)
		} else {
			ex.p++
			it.file = t.Text
		}
	} else {
		it.isFunc = true
		it.expr = ex.parseExpr()
	}
	exprEnd := ex.toks[ex.p-1].End
	it.rawText = ex.line[startPos:exprEnd]
	titleEnd := exprEnd
	for !ex.endOfCmd() && !ex.isOp(",") {
		switch {
		case !it.isFunc && ex.isWord("u$sing"):
			ex.p++
			ustart := ex.peek().Pos
			for {
				if ex.isOp("(") {
					ps := &Parser{toks: ex.toks, p: ex.p}
					n := ps.parsePrimary()
					ex.p = ps.p
					it.using = append(it.using, n)
				} else if ex.peek().Kind == TNUM {
					tk := ex.next()
					it.using = append(it.using, &Node{Op: "col", Kids: []*Node{{Op: "num", Val: IntV(tk.IVal)}}})
				} else if ex.peek().Kind == TSTR {
					tk := ex.next()
					it.using = append(it.using, &Node{Op: "col", Kids: []*Node{{Op: "str", Val: StrV(tk.Text)}}})
				} else if ex.isOp(":") {
					it.using = append(it.using, nil)
				} else {
					ps := &Parser{toks: ex.toks, p: ex.p}
					n := ps.parsePostfix()
					ex.p = ps.p
					it.using = append(it.using, n)
				}
				if ex.isOp(":") {
					ex.p++
					continue
				}
				break
			}
			titleEnd = ex.toks[ex.p-1].End
			smoothErrPos = ex.toks[ex.p-1].Pos
			it.usingStr = ex.line[ustart:titleEnd]
		case !it.isFunc && ex.isWord("i$ndex"):
			ex.p++
			it.hasIndex = true
			a := int(toInt(ex.evalExpr()))
			it.index = [3]int{a, a, 1}
			if ex.isOp(":") {
				ex.p++
				it.index[1] = int(toInt(ex.evalExpr()))
				if ex.isOp(":") {
					ex.p++
					it.index[2] = int(toInt(ex.evalExpr()))
				}
			}
		case !it.isFunc && ex.isWord("ev$ery"):
			ex.p++
			it.hasEvery = true
			it.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if ex.isOp(":") {
					ex.p++
					continue
				}
				if ex.endOfCmd() || ex.isOp(",") || ex.peek().Kind == TNAME && !isNumericStart(ex) {
					break
				}
				it.every[k] = int(toInt(ex.evalExpr()))
				if ex.isOp(":") {
					ex.p++
					continue
				}
				break
			}
		case ex.isWord("s$mooth"):
			ex.p++
			if ex.peek().Kind == TNAME {
				it.smooth = ex.next().Text
				for _, sm := range []string{"unique", "frequency", "fnormal", "cumulative", "cnormal", "csplines", "acsplines", "mcsplines", "bezier", "sbezier", "kdensity", "unwrap", "path", "zsort"} {
					if strings.HasPrefix(sm, it.smooth) {
						it.smooth = sm
						break
					}
				}
			}
		case ex.isWord("bins"):
			ex.p++
			it.bins = true
			if ex.isOp("=") {
				ex.p++
				it.binN = int(toInt(ex.evalExpr()))
			}
		case ex.isWord("t$itle"):
			ex.p++
			if ex.isWord("col$umnheader") || ex.isWord("columnh$ead") {
				ex.p++
				it.colHeadTit = -1
				if ex.isOp("(") {
					ex.p++
					it.colHeadTit = int(toInt(ex.evalExpr()))
					ex.p++
				}
				break
			}
			v := ex.evalExpr()
			it.title = toStr(v)
			it.hasTitle = true
		case ex.isWord("not$itle"):
			ex.p++
			it.noTitle = true
			if ex.peek().Kind == TSTR {
				ex.p++
			}
		case ex.isWord("w$ith"):
			ex.p++
			it.style = ex.parseStyleName()
		case ex.isWord("lt") || ex.isWord("linet$ype") || ex.isWord("ls") || ex.isWord("lines$tyle"):
			isLs := ex.isWord("ls") || ex.isWord("lines$tyle")
			ex.p++
			v := int(toInt(ex.evalExpr()))
			if isLs {
				if ls, ok := S.lineStyles[v]; ok {
					if ls.lt != 0 {
						it.lt = ls.lt
						it.ltSet = true
					}
					if ls.pt != 0 {
						it.pt = ls.pt
						it.ptSet = true
					}
				}
			} else {
				it.lt = v
				it.ltSet = true
			}
		case ex.isWord("lc") || ex.isWord("linec$olor"):
			ex.p++
			if ex.isWord("rgb") || ex.isWord("rgbc$olor") {
				ex.p++
				ex.evalExpr()
			} else if ex.isWord("var$iable") || ex.isWord("pal$ette") || ex.isWord("bgnd") || ex.isWord("black") {
				ex.p++
			} else {
				it.lc = int(toInt(ex.evalExpr()))
			}
		case ex.isWord("pt") || ex.isWord("pointt$ype"):
			ex.p++
			if ex.peek().Kind == TSTR {
				ex.p++
			} else {
				it.pt = int(toInt(ex.evalExpr()))
				it.ptSet = true
			}
		case ex.isWord("ps") || ex.isWord("points$ize"):
			ex.p++
			if ex.isWord("var$iable") {
				ex.p++
			} else {
				it.ps = ex.evalNum()
			}
		case ex.isWord("lw") || ex.isWord("linew$idth") || ex.isWord("dt") || ex.isWord("dasht$ype") || ex.isWord("pi") || ex.isWord("pointi$nterval") || ex.isWord("fc") || ex.isWord("fillc$olor"):
			ex.p++
			if ex.isWord("rgb") {
				ex.p++
			}
			ex.evalExpr()
		case ex.isWord("fs") || ex.isWord("fill$style"):
			ex.p++
			for ex.isWord("sol$id") || ex.isWord("tr$ansparent") || ex.isWord("pat$tern") || ex.isWord("bo$rder") || ex.isWord("nobo$rder") || ex.isWord("empty") || ex.peek().Kind == TNUM {
				ex.p++
			}
		case ex.isWord("ax$es") || ex.isWord("ax$is"):
			ex.p++
			it.axes = ex.next().Text
		case ex.isWord("nohidden3d") || ex.isWord("nocontours") || ex.isWord("nosurface") || ex.isWord("noautoscale") || ex.isWord("palette") || ex.isWord("nocon$tours"):
			ex.p++
		case ex.isWord("tc") || ex.isWord("textc$olor") || ex.isWord("font") || ex.isWord("offset"):
			ex.p++
			ex.evalExpr()
		case ex.isWord("left") || ex.isWord("right") || ex.isWord("center") || ex.isWord("point") || ex.isWord("nopoint") || ex.isWord("boxed") || ex.isWord("hypertext"):
			ex.p++
		case ex.isWord("hea$ds") || ex.isWord("noh$eads") || ex.isWord("head") || ex.isWord("filled") || ex.isWord("nofilled") || ex.isWord("empty"):
			ex.p++
		default:
			t := ex.peek()
			gpErr(t.Pos, "unexpected or unrecognized token: "+ex.line[t.Pos:t.End])
		}
	}
	if !it.hasTitle {
		raw := strings.TrimSpace(it.rawText)
		if !it.isFunc && it.usingStr != "" {
			raw = ex.line[startPos:titleEnd]
		}
		it.title = raw
		if !it.isFunc && strings.HasPrefix(it.title, "$") == false && false {
		}
	}
	if it.style == "" {
		if it.isFunc {
			it.style = S.styleFunc
		} else {
			it.style = S.styleData
		}
	}
	return it
}

func isNumericStart(ex *Exec) bool {
	return false
}

// columns expected for style (2D)
func styleCols(style string) (int, int) {
	switch style {
	case "yerrorbars", "xerrorbars", "yerrorlines", "xerrorlines":
		return 3, 4
	case "xyerrorbars", "xyerrorlines":
		return 4, 6
	case "boxes":
		return 2, 3
	case "boxerrorbars":
		return 3, 5
	case "vectors":
		return 4, 4
	case "labels":
		return 3, 3
	case "filledcurves":
		return 2, 3
	case "financebars", "candlesticks":
		return 5, 6
	case "circles":
		return 2, 3
	case "boxxyerrorbars":
		return 4, 6
	case "points", "linespoints":
		return 2, 3
	case "impulses", "lines", "steps", "fsteps", "histeps", "dots":
		return 2, 2
	}
	return 2, 2
}

type rawPoint struct {
	vals  []float64
	label string
	brk   bool
	bad   bool
}

// read data for a plot item; returns list of raw value tuples (with breaks)
func readItemData(it *plotItem, ncolDefault int, is3D bool) ([]rawPoint, int) {
	var lines []string
	if it.file == "+" || it.file == "++" {
		xa := S.axes["x"]
		n := S.samples1
		for i := 0; i < n; i++ {
			x := xa.min + float64(i)*(xa.max-xa.min)/float64(n-1)
			lines = append(lines, strconv.FormatFloat(x, 'g', 17, 64))
		}
	} else {
		lines = readDataSource(it.file)
	}
	var pts []rawPoint
	inDataCtx = true
	defer func() { inDataCtx = false }()
	dataIndex := 0
	blankRun := 0
	lineInBlock := 0
	blockNo := 0
	firstFields := -1
	curHeader = nil
	count := 0
	for _, ln := range lines {
		tl := strings.TrimSpace(ln)
		if tl == "" {
			blankRun++
			if blankRun == 1 {
				blockNo++
				if len(pts) > 0 && !pts[len(pts)-1].brk {
					if inIndex(it, dataIndex) {
						pts = append(pts, rawPoint{brk: true})
					}
				}
			}
			if blankRun == 2 {
				dataIndex++
				blockNo = 0
			}
			lineInBlock = 0
			continue
		}
		if strings.ContainsAny(tl[:1], S.datafileComments) {
			continue
		}
		blankRun = 0
		if !inIndex(it, dataIndex) {
			continue
		}
		fields := splitFields(ln)
		if firstFields < 0 {
			firstFields = len(fields)
		}
		if it.colHeadTit != 0 && curHeader == nil {
			curHeader = make([]string, len(fields))
			for i, f := range fields {
				curHeader[i] = strings.Trim(f, "\"")
			}
			continue
		}
		if it.hasEvery {
			e := it.every
			idx := lineInBlock
			if idx < e[2] || (e[4] >= 0 && idx > e[4]) || (idx-e[2])%max(e[0], 1) != 0 {
				lineInBlock++
				continue
			}
			if blockNo < e[3] || (e[5] >= 0 && blockNo > e[5]) || (blockNo-e[3])%max(e[1], 1) != 0 {
				lineInBlock++
				continue
			}
		}
		curFields = fields
		curLineNo = lineInBlock
		curDataIndex = dataIndex
		lineInBlock++
		rp := evalUsing(it, fields, firstFields, ncolDefault, is3D)
		if rp.bad {
			continue
		}
		count++
		pts = append(pts, rp)
	}
	// trim trailing break
	for len(pts) > 0 && pts[len(pts)-1].brk {
		pts = pts[:len(pts)-1]
	}
	return pts, count
}

func inIndex(it *plotItem, idx int) bool {
	if !it.hasIndex {
		return true
	}
	if idx < it.index[0] || idx > it.index[1] {
		return false
	}
	return (idx-it.index[0])%max(it.index[2], 1) == 0
}

func evalUsing(it *plotItem, fields []string, firstFields, ncol int, is3D bool) (rp rawPoint) {
	defer func() {
		if r := recover(); r != nil {
			if _, ok := r.(*badPoint); ok {
				rp = rawPoint{bad: true}
				return
			}
			panic(r)
		}
	}()
	if it.using == nil {
		// default columns
		nf := len(fields)
		if nf == 0 {
			return rawPoint{bad: true}
		}
		check := firstFields
		if check > nf {
			check = nf
		}
		vals := []float64{}
		for i := 1; i <= check; i++ {
			v := colValue(i)
			vals = append(vals, v.R)
		}
		if is3D {
			if len(vals) == 1 {
				return rawPoint{vals: []float64{float64(curDataIndex), float64(curLineNo), vals[0]}}
			}
			if len(vals) == 2 {
				return rawPoint{vals: []float64{float64(curDataIndex), vals[0], vals[1]}}
			}
			return rawPoint{vals: vals[:min(len(vals), ncol)]}
		}
		if len(vals) == 1 {
			return rawPoint{vals: []float64{float64(curLineNo), vals[0]}}
		}
		if len(vals) > ncol {
			vals = vals[:ncol]
		}
		return rawPoint{vals: vals}
	}
	var vals []float64
	label := ""
	for i, n := range it.using {
		if n == nil {
			continue
		}
		var v Value
		if it.style == "labels" && i == len(it.using)-1 {
			lv := labelEval(n)
			if lv.T == VSTR {
				label = lv.S
			}
			continue
		}
		if n.Op == "col" {
			v = eval(n)
		} else {
			v = evalTop(n)
		}
		if v.T == VSTR {
			f, ok := parseDataNum(v.S)
			if !ok {
				return rawPoint{bad: true}
			}
			vals = append(vals, f)
			continue
		}
		if v.T == VUNDEF {
			return rawPoint{bad: true}
		}
		f := v.Real()
		vals = append(vals, f)
	}
	if len(vals) == 1 && !is3D {
		vals = []float64{float64(curLineNo), vals[0]}
	}
	return rawPoint{vals: vals, label: label}
}

func trigScale() float64 {
	return 1
}

// build curves (2D or 3D)
func buildCurves(items []*plotItem, is3D bool, dummy string) []*Curve {
	var curves []*Curve
	xa := S.axes["x"]
	// expand iterations
	var expanded []*plotItem
	for _, it := range items {
		expanded = append(expanded, it)
	}
	// first pass: data
	type pending struct {
		it  *plotItem
		c   *Curve
		val map[string]Value
	}
	ltCounter := 0
	var funcs []*pending
	var all []*pending
	addCurve := func(it *plotItem) {
		ltCounter++
		c := &Curve{title: it.title, hasTitle: !it.noTitle, style: it.style, smooth: it.smooth, is3D: is3D}
		c.lt = ltCounter
		if it.ltSet {
			c.lt = it.lt
		}
		c.pt = c.lt
		if it.ptSet {
			c.pt = it.pt
		}
		c.lc = it.lc
		if it.isFunc {
			c.isFunc = true
			p := &pending{it: it, c: c}
			funcs = append(funcs, p)
			all = append(all, p)
			p.val = snapshotIterVars(it)
		} else {
			lo, hi := styleCols(it.style)
			_ = hi
			if is3D {
				lo = 3
			}
			pts, _ := readItemData(it, lo, is3D)
			if len(it.using) > hi && !is3D && it.style != "labels" {
				warn("more using specs than expected for this style")
			}
			c.nusing = len(it.using)
			if it.colHeadTit != 0 && curHeader != nil {
				k := it.colHeadTit
				if k < 0 {
					k = 2
					if len(it.using) >= 2 {
						if it.using[1] != nil && it.using[1].Op == "col" && it.using[1].Kids[0].Op == "num" {
							k = int(it.using[1].Kids[0].Val.I)
						}
					}
				}
				if k >= 1 && k <= len(curHeader) {
					c.title = curHeader[k-1]
				}
			}
			c.points = convertPoints(pts, it.style, is3D)
			c.origCount = len(c.points)
			if it.bins {
				c.points = doBins(c.points, it.binN)
				c.origCount = len(c.points)
				c.bins = true
			}
			if it.smooth != "" {
				c.points = doSmooth(c.points, it.smooth)
			}
			p := &pending{it: it, c: c}
			all = append(all, p)
		}
	}
	for _, it := range expanded {
		if len(it.iters) > 0 {
			var rec func(k int)
			rec = func(k int) {
				if k == len(it.iters) {
					cp := *it
					if !it.hasTitle {
						cp.title = it.title
					}
					if it.isFunc {
						cp.title = it.title
					}
					addCurve(&cp)
					return
				}
				it.iters[k].each(func() bool { rec(k + 1); return false })
			}
			rec(0)
			continue
		}
		addCurve(it)
	}
	_ = funcs
	// determine x range for functions
	xmin, xmax := xa.min, xa.max
	if xa.autoMin || xa.autoMax {
		dmin, dmax := math.Inf(1), math.Inf(-1)
		for _, p := range all {
			if p.c.isFunc {
				continue
			}
			for _, pt := range p.c.points {
				if pt.brk || pt.typ == 'u' {
					continue
				}
				dmin = math.Min(dmin, pt.x)
				dmax = math.Max(dmax, pt.x)
				if len(pt.ex) >= 2 && (p.c.style == "xerrorbars" || p.c.style == "xyerrorbars" || p.c.style == "boxes" || p.c.style == "boxxyerrorbars") {
					dmin = math.Min(dmin, pt.ex[0])
					dmax = math.Max(dmax, pt.ex[1])
				}
			}
		}
		if dmin <= dmax {
			if xa.autoMin {
				xmin = dmin
			}
			if xa.autoMax {
				xmax = dmax
			}
		}
	}
	xa.min, xa.max = xmin, xmax
	for _, p := range all {
		c := p.c
		if !c.isFunc {
			markRange(c, is3D)
			curves = append(curves, c)
			continue
		}
		restoreIterVars(p.val)
		if is3D {
			sample3D(c, p.it, dummy)
		} else {
			sampleFunc(c, p.it, xmin, xmax, dummy)
			markRange(c, false)
		}
		curves = append(curves, c)
	}
	// record GPVAL ranges
	return curves
}

func snapshotIterVars(it *plotItem) map[string]Value {
	m := map[string]Value{}
	for _, i := range it.iters {
		if v, ok := lookupVar(i.varName); ok {
			m[i.varName] = v
		}
	}
	return m
}
func restoreIterVars(m map[string]Value) {
	for k, v := range m {
		setVar(k, v)
	}
}

func warn(msg string) {
	s := curSrc()
	if s.kind == 0 {
		stderr.WriteString("\"" + s.name + "\" line " + strconv.Itoa(s.lineno) + ": warning: " + msg + "\n")
	} else {
		stderr.WriteString("line 0: warning: " + msg + "\n")
	}
}

func convertPoints(raw []rawPoint, style string, is3D bool) []Point {
	var pts []Point
	for _, r := range raw {
		if r.brk {
			pts = append(pts, Point{brk: true, typ: 'u'})
			continue
		}
		v := r.vals
		p := Point{typ: 'i', label: r.label}
		if is3D {
			for len(v) < 3 {
				v = append(v, 0)
			}
			p.x, p.y, p.z = v[0], v[1], v[2]
			pts = append(pts, p)
			continue
		}
		if len(v) < 2 {
			continue
		}
		p.x, p.y = v[0], v[1]
		switch style {
		case "yerrorbars", "yerrorlines":
			if len(v) >= 4 {
				p.ex = []float64{v[2], v[3]}
			} else if len(v) >= 3 {
				p.ex = []float64{p.y - v[2], p.y + v[2]}
			} else {
				p.ex = []float64{p.y, p.y}
			}
		case "xerrorbars", "xerrorlines":
			if len(v) >= 4 {
				p.ex = []float64{v[2], v[3]}
			} else if len(v) >= 3 {
				p.ex = []float64{p.x - v[2], p.x + v[2]}
			} else {
				p.ex = []float64{p.x, p.x}
			}
		case "xyerrorbars", "xyerrorlines":
			if len(v) >= 6 {
				p.ex = []float64{v[2], v[3], v[4], v[5]}
			} else if len(v) >= 4 {
				p.ex = []float64{p.x - v[2], p.x + v[2], p.y - v[3], p.y + v[3]}
			} else {
				p.ex = []float64{p.x, p.x, p.y, p.y}
			}
		case "boxes":
			w := 0.0
			if len(v) >= 3 {
				w = v[2]
				p.ex = []float64{p.x - w/2, p.x + w/2}
			} else {
				p.ex = []float64{p.x, p.x}
				p.ex = nil
			}
		case "vectors":
			if len(v) >= 4 {
				p.ex = []float64{v[2], v[3]}
			}
		case "filledcurves":
			if len(v) >= 3 {
				p.ex = []float64{v[2]}
			}
		case "boxerrorbars":
			if len(v) >= 3 {
				p.ex = []float64{p.y - v[2], p.y + v[2]}
			}
		case "candlesticks", "financebars":
			for len(v) < 5 {
				v = append(v, 0)
			}
			p.ex = []float64{v[2], v[3], v[4]}
		case "points", "linespoints":
			if len(v) >= 3 {
				p.ex = []float64{v[2]}
			}
		}
		pts = append(pts, p)
	}
	return pts
}

func sampleFunc(c *Curve, it *plotItem, xmin, xmax float64, dummy string) {
	n := S.samples1
	xa := S.axes["x"]
	if S.parametric {
		ta := S.axes["t"]
		xmin, xmax = ta.min, ta.max
	}
	var pts []Point
	scope := map[string]Value{}
	localStack = append(localStack, scope)
	defer func() { localStack = localStack[:len(localStack)-1] }()
	for i := 0; i < n; i++ {
		var x float64
		if xa.log && !S.parametric {
			lmin, lmax := math.Log(xmin), math.Log(xmax)
			x = math.Exp(lmin + float64(i)*(lmax-lmin)/float64(n-1))
		} else {
			x = xmin + float64(i)*((xmax-xmin)/float64(n-1))
		}
		scope[dummy] = FltV(x)
		v, ok := safeEval(it.expr)
		p := Point{x: x, typ: 'i'}
		if !ok || v.T == VSTR {
			p = Point{typ: 'u'}
		} else {
			if v.T == VCMPLX && v.Im != 0 && math.Abs(v.Im) > S.zero {
				p = Point{x: x, typ: 'u'}
				p.x = x
				p.y = 0
			} else {
				p.y = v.Real()
			}
			if math.IsNaN(p.y) || math.IsInf(p.y, 0) {
				p = Point{typ: 'u', x: x}
			}
		}
		pts = append(pts, p)
	}
	c.points = pts
	c.origCount = len(pts)
	if it.smooth != "" {
		c.points = doSmooth(c.points, it.smooth)
	}
}

func safeEval(n *Node) (v Value, ok bool) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok2 := r.(*GpError); ok2 {
				if e.Msg == "undefined value" {
					v, ok = Value{}, false
					return
				}
			}
			panic(r)
		}
	}()
	return evalTop(n), true
}

func markRange(c *Curve, is3D bool) {
	xa := S.axes["x"]
	ya := S.axes["y"]
	for i := range c.points {
		p := &c.points[i]
		if p.brk || p.typ == 'u' {
			continue
		}
		p.typ = 'i'
		if outOfRange(xa, p.x) || outOfRange(ya, p.y) {
			p.typ = 'o'
		}
		if is3D && outOfRange(S.axes["z"], p.z) {
			p.typ = 'o'
		}
	}
}

func outOfRange(a *Axis, v float64) bool {
	lo, hi := a.min, a.max
	if lo > hi {
		lo, hi = hi, lo
	}
	if !a.autoMin && v < lo {
		return true
	}
	if !a.autoMax && v > hi {
		return true
	}
	return false
}

func sample3D(c *Curve, it *plotItem, dummy string) {
	xa, ya := S.axes["x"], S.axes["y"]
	xmin, xmax := xa.min, xa.max
	ymin, ymax := ya.min, ya.max
	scope := map[string]Value{}
	localStack = append(localStack, scope)
	defer func() { localStack = localStack[:len(localStack)-1] }()
	nx := S.samples1
	ny := S.iso2
	if S.iso2 > 0 {
	}
	var iso [][]Point
	for j := 0; j < ny; j++ {
		y := ymin + float64(j)*(ymax-ymin)/float64(ny-1)
		var row []Point
		for i := 0; i < nx; i++ {
			x := xmin + float64(i)*(xmax-xmin)/float64(nx-1)
			scope[S.dummy1] = FltV(x)
			scope[S.dummy2] = FltV(y)
			v, ok := safeEval(it.expr)
			p := Point{x: x, y: y, typ: 'i'}
			if !ok || (v.T == VCMPLX && math.Abs(v.Im) > S.zero) {
				p.typ = 'u'
			} else {
				p.z = v.Real()
				if outOfRange(S.axes["z"], p.z) {
					p.typ = 'o'
				}
			}
			row = append(row, p)
		}
		iso = append(iso, row)
	}
	// second direction for rendering
	nx2 := S.iso1
	ny2 := S.samples2
	var iso2 [][]Point
	for i := 0; i < nx2; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(nx2-1)
		var row []Point
		for j := 0; j < ny2; j++ {
			y := ymin + float64(j)*(ymax-ymin)/float64(ny2-1)
			scope[S.dummy1] = FltV(x)
			scope[S.dummy2] = FltV(y)
			v, ok := safeEval(it.expr)
			p := Point{x: x, y: y, typ: 'i'}
			if !ok {
				p.typ = 'u'
			} else {
				p.z = v.Real()
			}
			row = append(row, p)
		}
		iso2 = append(iso2, row)
	}
	c.iso = iso
	c.iso = append(c.iso, nil)
	c.iso = append(c.iso, iso2...)
	for _, r := range iso {
		c.points = append(c.points, r...)
	}
}

// ------------- table output -------------

func fmtTbl(f float64) string {
	return fmtFloatC(fspec{conv: 'g', prec: -1, flags: " "}, f)
}

var tableBuf *strings.Builder

func writeTable(curves []*Curve, is3D bool) {
	var sb strings.Builder
	if is3D {
		writeTable3D(&sb, curves)
	} else {
		for ci, c := range curves {
			cnt := c.origCount
			if c.smooth != "" && isSplineSmooth(c.smooth) {
				cnt = len(c.points)
			}
			fmt.Fprintf(&sb, "\n# Curve %d of %d, %d points\n", ci, len(curves), cnt)
			fmt.Fprintf(&sb, "# Curve title: \"%s\"\n", c.title)
			hdr := "# x y type"
			switch c.style {
			case "yerrorbars", "yerrorlines":
				hdr = "# x y ylow yhigh type"
			case "xerrorbars", "xerrorlines":
				hdr = "# x y xlow xhigh type"
			case "xyerrorbars", "xyerrorlines":
				hdr = "# x y xlow xhigh ylow yhigh type"
			case "boxes":
				hdr = "# x y xlow xhigh type"
			case "labels":
				hdr = "# x y label type"
			case "vectors":
				hdr = "# x y delta_x delta_y type"
			case "filledcurves":
				hdr = "# x y1 y2 type"
			}
			sb.WriteString(hdr + "\n")
			for _, p := range c.points {
				if p.brk {
					sb.WriteString("\n")
					continue
				}
				x, y := p.x, p.y
				if p.typ == 'u' {
					x, y = 0, 0
					if c.isFunc {
						x = p.x
					}
				}
				if p.typ == 'u' && c.isFunc {
					x = 0
				}
				line := fmtTbl(x) + " " + fmtTbl(y)
				switch c.style {
				case "labels":
					sb.WriteString(line + " \"" + p.label + "\"\n")
					continue
				case "yerrorbars", "yerrorlines", "xerrorbars", "xerrorlines", "xyerrorbars", "xyerrorlines", "vectors":
					for _, e := range p.ex {
						line += " " + fmtTbl(e)
					}
					if len(p.ex) == 0 {
						n := 2
						if strings.HasPrefix(c.style, "xy") {
							n = 4
						}
						for k := 0; k < n; k++ {
							line += " " + fmtTbl(0)
						}
					}
				case "boxes":
					if len(p.ex) >= 2 {
						line += " " + fmtTbl(p.ex[0]) + " " + fmtTbl(p.ex[1])
					} else {
						line += " " + fmtTbl(x) + " " + fmtTbl(x)
					}
				case "filledcurves":
					if len(p.ex) >= 1 {
						line += " " + fmtTbl(p.ex[0])
					} else {
						line += " " + fmtTbl(0)
					}
				}
				sb.WriteString(line + "  " + string(p.typ) + "\n")
			}
			if c.smooth != "" && !isSplineSmooth(c.smooth) && len(c.points) < cnt {
				sb.WriteString("\n")
			}
			sb.WriteString("\n")
		}
	}
	out := sb.String()
	if S.tableBlock != "" {
		ls := splitLines(out)
		datablocks[S.tableBlock] = append(datablocks[S.tableBlock], ls...)
		return
	}
	if S.tableFile != "" {
		f, err := os.OpenFile(S.tableFile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
		if err == nil {
			f.WriteString(out)
			f.Close()
		}
		return
	}
	termOut().WriteString(out)
}

func isSplineSmooth(s string) bool {
	switch s {
	case "csplines", "acsplines", "bezier", "sbezier", "mcsplines", "kdensity":
		return true
	}
	return false
}

func writeTable3D(sb *strings.Builder, curves []*Curve) {
	for ci, c := range curves {
		fmt.Fprintf(sb, "\n# Surface %d of %d surfaces\n", ci, len(curves))
		fmt.Fprintf(sb, "\n# Curve title: \"%s\"\n", c.title)
		if c.isFunc {
			for k, row := range c.iso {
				if row == nil {
					break
				}
				fmt.Fprintf(sb, "\n# IsoCurve %d, %d points\n# x y z type\n", k, len(row))
				for _, p := range row {
					sb.WriteString(fmtTbl(p.x) + " " + fmtTbl(p.y) + " " + fmtTbl(p.z) + " " + string(p.typ) + "\n")
				}
			}
			sb.WriteString("\n")
			continue
		}
		// data: split into isocurves by breaks
		var blocks [][]Point
		var cur []Point
		for _, p := range c.points {
			if p.brk {
				blocks = append(blocks, cur)
				cur = nil
				continue
			}
			cur = append(cur, p)
		}
		blocks = append(blocks, cur)
		for k, b := range blocks {
			fmt.Fprintf(sb, "\n# IsoCurve %d, %d points\n# x y z type\n", k, len(b))
			for _, p := range b {
				sb.WriteString(fmtTbl(p.x) + " " + fmtTbl(p.y) + " " + fmtTbl(p.z) + " " + string(p.typ) + "\n")
			}
		}
		sb.WriteString("\n")
	}
}

func endTable() {
	S.tableOn = false
	S.tableFile = ""
	S.tableBlock = ""
}

// ------------- smoothing -------------

func validPts(pts []Point) []Point {
	var out []Point
	for _, p := range pts {
		if p.brk || p.typ == 'u' {
			continue
		}
		out = append(out, p)
	}
	return out
}

func uniquePts(pts []Point, mode string) []Point {
	v := validPts(pts)
	sort.SliceStable(v, func(i, j int) bool { return v[i].x < v[j].x })
	var out []Point
	for i := 0; i < len(v); {
		j := i
		sum := 0.0
		for j < len(v) && v[j].x == v[i].x {
			sum += v[j].y
			j++
		}
		y := sum / float64(j-i)
		if mode == "frequency" || mode == "cumulative" || mode == "cnormal" || mode == "fnormal" {
			y = sum
		}
		out = append(out, Point{x: v[i].x, y: y, typ: 'i'})
		i = j
	}
	return out
}

func doSmooth(pts []Point, mode string) []Point {
	switch mode {
	case "unique", "frequency":
		return uniquePts(pts, mode)
	case "cumulative", "cnormal":
		u := uniquePts(pts, mode)
		s := 0.0
		for i := range u {
			s += u[i].y
			u[i].y = s
		}
		if mode == "cnormal" && s != 0 {
			for i := range u {
				u[i].y /= s
			}
		}
		return u
	case "fnormal":
		u := uniquePts(pts, mode)
		s := 0.0
		for _, p := range u {
			s += p.y
		}
		for i := range u {
			u[i].y /= s
		}
		return u
	case "csplines":
		var out []Point
		var blk []Point
		flush := func() {
			u := uniquePts(blk, "unique")
			if len(u) < 3 {
				gpErr(smoothErrPos, "Can't calculate splines, need at least 3 points")
			}
			if len(out) > 0 {
				out = append(out, Point{brk: true, typ: 'u'})
			}
			out = append(out, evalSpline(u, naturalSpline(u))...)
			blk = nil
		}
		for _, p := range pts {
			if p.brk {
				flush()
				continue
			}
			blk = append(blk, p)
		}
		flush()
		return out
	case "acsplines":
		u := uniquePts(pts, "unique")
		if len(u) < 3 {
			gpErr(-1, "Can't calculate approximation splines, need at least 4 points")
		}
		return evalSpline(u, smoothingSpline(u))
	case "bezier":
		return bezier(validPts(pts))
	case "sbezier":
		return bezier(uniquePts(pts, "unique"))
	case "kdensity":
		return kdensity(validPts(pts))
	}
	return pts
}

type splineCoef struct{ a, b, c, d float64 }

func naturalSpline(p []Point) []splineCoef {
	n := len(p)
	h := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		h[i] = p[i+1].x - p[i].x
	}
	// solve for second derivatives M
	M := make([]float64, n)
	if n > 2 {
		a := make([]float64, n)
		b := make([]float64, n)
		c := make([]float64, n)
		d := make([]float64, n)
		for i := 1; i < n-1; i++ {
			a[i] = h[i-1]
			b[i] = 2 * (h[i-1] + h[i])
			c[i] = h[i]
			d[i] = 6 * ((p[i+1].y-p[i].y)/h[i] - (p[i].y-p[i-1].y)/h[i-1])
		}
		// thomas on 1..n-2
		for i := 2; i < n-1; i++ {
			w := a[i] / b[i-1]
			b[i] -= w * c[i-1]
			d[i] -= w * d[i-1]
		}
		M[n-2] = d[n-2] / b[n-2]
		for i := n - 3; i >= 1; i-- {
			M[i] = (d[i] - c[i]*M[i+1]) / b[i]
		}
	}
	co := make([]splineCoef, n-1)
	for i := 0; i < n-1; i++ {
		co[i].a = p[i].y
		co[i].b = (p[i+1].y-p[i].y)/h[i] - h[i]*(2*M[i]+M[i+1])/6
		co[i].c = M[i] / 2
		co[i].d = (M[i+1] - M[i]) / (6 * h[i])
	}
	return co
}

func smoothingSpline(p []Point) []splineCoef {
	// Reinsch smoothing spline with weights 1, smoothing parameter 1
	n := len(p)
	x := make([]float64, n)
	y := make([]float64, n)
	w := make([]float64, n)
	for i := range p {
		x[i], y[i] = p[i].x, p[i].y
		w[i] = 1
	}
	h := make([]float64, n-1)
	for i := 0; i < n-1; i++ {
		h[i] = x[i+1] - x[i]
	}
	m := n - 2
	// Build Q^T y and R + p Q^T W^-1 Q with lambda = 1
	// Solve (R + Q^T D^2 Q) c = Q^T y  (D = 1/sqrt(w))
	// Banded but use dense for simplicity
	A := make([][]float64, m)
	for i := range A {
		A[i] = make([]float64, m)
	}
	rhs := make([]float64, m)
	Q := func(i, j int) float64 { // i in 0..n-1, j in 0..m-1 (column for interior j+1)
		k := j + 1
		switch i {
		case k - 1:
			return 1 / h[k-1]
		case k:
			return -1/h[k-1] - 1/h[k]
		case k + 1:
			return 1 / h[k]
		}
		return 0
	}
	for i := 0; i < m; i++ {
		k := i + 1
		A[i][i] += (h[k-1] + h[k]) / 3
		if i+1 < m {
			A[i][i+1] += h[k] / 6
			A[i+1][i] += h[k] / 6
		}
		for j := 0; j < m; j++ {
			s := 0.0
			for r := 0; r < n; r++ {
				s += Q(r, i) * Q(r, j) / w[r]
			}
			A[i][j] += s
		}
		for r := 0; r < n; r++ {
			rhs[i] += Q(r, i) * y[r]
		}
	}
	cvec := solveDense(A, rhs)
	gam := make([]float64, n)
	for i := 0; i < m; i++ {
		gam[i+1] = cvec[i]
	}
	a := make([]float64, n)
	for r := 0; r < n; r++ {
		s := 0.0
		for j := 0; j < m; j++ {
			s += Q(r, j) * cvec[j]
		}
		a[r] = y[r] - s/w[r]
	}
	pts := make([]Point, n)
	for i := range pts {
		pts[i] = Point{x: x[i], y: a[i]}
	}
	co := make([]splineCoef, n-1)
	for i := 0; i < n-1; i++ {
		co[i].a = a[i]
		co[i].b = (a[i+1]-a[i])/h[i] - h[i]*(2*gam[i]+gam[i+1])/6
		co[i].c = gam[i] / 2
		co[i].d = (gam[i+1] - gam[i]) / (6 * h[i])
	}
	return co
}

func solveDense(A [][]float64, b []float64) []float64 {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		M[c], M[piv] = M[piv], M[c]
		for r := c + 1; r < n; r++ {
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for r := n - 1; r >= 0; r-- {
		s := M[r][n]
		for k := r + 1; k < n; k++ {
			s -= M[r][k] * x[k]
		}
		x[r] = s / M[r][r]
	}
	return x
}

func evalSpline(p []Point, co []splineCoef) []Point {
	n := S.samples1
	x0, x1 := p[0].x, p[len(p)-1].x
	var out []Point
	for i := 0; i < n; i++ {
		x := x0 + float64(i)*(x1-x0)/float64(n-1)
		k := 0
		for k < len(co)-1 && x > p[k+1].x {
			k++
		}
		t := x - p[k].x
		y := co[k].a + t*(co[k].b+t*(co[k].c+t*co[k].d))
		out = append(out, Point{x: x, y: y, typ: 'i'})
	}
	return out
}

func bezier(p []Point) []Point {
	n := S.samples1
	m := len(p) - 1
	var out []Point
	for i := 0; i < n; i++ {
		t := float64(i) / float64(n-1)
		var x, y float64
		for k := 0; k <= m; k++ {
			b := binom(m, k) * math.Pow(t, float64(k)) * math.Pow(1-t, float64(m-k))
			x += b * p[k].x
			y += b * p[k].y
		}
		out = append(out, Point{x: x, y: y, typ: 'i'})
	}
	return out
}

func binom(n, k int) float64 {
	a, _ := math.Lgamma(float64(n + 1))
	b, _ := math.Lgamma(float64(k + 1))
	c, _ := math.Lgamma(float64(n - k + 1))
	return math.Exp(a - b - c)
}

func kdensity(p []Point) []Point {
	n := len(p)
	if n == 0 {
		return nil
	}
	mean, sq := 0.0, 0.0
	sumw := 0.0
	for _, q := range p {
		mean += q.x
		sumw += q.y
	}
	mean /= float64(n)
	for _, q := range p {
		sq += (q.x - mean) * (q.x - mean)
	}
	sigma := math.Sqrt(sq / float64(n))
	bw := sigma * math.Pow(4.0/(3.0*float64(n)), 0.2)
	if bw == 0 {
		bw = 1
	}
	xmin, xmax := p[0].x, p[0].x
	for _, q := range p {
		xmin = math.Min(xmin, q.x)
		xmax = math.Max(xmax, q.x)
	}
	ns := S.samples1
	var out []Point
	for i := 0; i < ns; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(ns-1)
		y := 0.0
		for _, q := range p {
			z := (x - q.x) / bw
			y += q.y * math.Exp(-0.5*z*z) / (bw * math.Sqrt(2*math.Pi))
		}
		out = append(out, Point{x: x, y: y, typ: 'i'})
	}
	return out
}

func doBins(pts []Point, nbins int) []Point {
	v := validPts(pts)
	if len(v) == 0 {
		return nil
	}
	if nbins <= 0 {
		nbins = S.samples1
	}
	lo, hi := v[0].x, v[0].x
	for _, p := range v {
		lo = math.Min(lo, p.x)
		hi = math.Max(hi, p.x)
	}
	w := (hi - lo) / float64(nbins-1)
	if w == 0 {
		w = 1
	}
	start := lo - w/2
	counts := make([]float64, nbins)
	for _, p := range v {
		k := int(math.Floor((p.x - start) / w))
		if k >= nbins {
			k = nbins - 1
		}
		if k < 0 {
			k = 0
		}
		counts[k] += p.y
	}
	var out []Point
	for k := 0; k < nbins; k++ {
		out = append(out, Point{x: start + (float64(k)+0.5)*w, y: counts[k], typ: 'i'})
	}
	return out
}

func labelEval(n *Node) (v Value) {
	defer func() {
		if r := recover(); r != nil {
			if _, ok := r.(*badPoint); ok {
				v = Value{}
				return
			}
			panic(r)
		}
	}()
	if n.Op == "col" {
		k := eval(n.Kids[0])
		return stringColumn(k)
	}
	return evalTop(n)
}
