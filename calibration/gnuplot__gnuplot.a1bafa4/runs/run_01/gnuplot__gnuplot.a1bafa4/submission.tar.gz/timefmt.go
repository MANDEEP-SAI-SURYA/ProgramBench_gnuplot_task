package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

var monAbbr = []string{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
var monFull = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayAbbr = []string{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}
var dayFull = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, x float64) string {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		return ""
	}
	sec := math.Floor(x)
	frac := x - sec
	t := time.Unix(int64(sec), 0).UTC()
	var sb strings.Builder
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			sb.WriteByte(c)
			continue
		}
		i++
		// optional width/precision for %S etc
		prec := -1
		zeroPad := true
		if f[i] == '.' && i+1 < len(f) && isDigit(f[i+1]) {
			prec = int(f[i+1] - '0')
			i += 2
		}
		if i < len(f) && f[i] == '-' {
			zeroPad = false
			i++
		}
		if i >= len(f) {
			break
		}
		d2 := func(v int) string {
			if zeroPad {
				return fmt.Sprintf("%02d", v)
			}
			return strconv.Itoa(v)
		}
		switch f[i] {
		case 'Y':
			sb.WriteString(strconv.Itoa(t.Year()))
		case 'y':
			sb.WriteString(fmt.Sprintf("%02d", t.Year()%100))
		case 'm':
			sb.WriteString(d2(int(t.Month())))
		case 'd':
			sb.WriteString(d2(t.Day()))
		case 'e':
			sb.WriteString(fmt.Sprintf("%2d", t.Day()))
		case 'H':
			sb.WriteString(d2(t.Hour()))
		case 'k':
			sb.WriteString(fmt.Sprintf("%2d", t.Hour()))
		case 'I':
			h := t.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(d2(h))
		case 'l':
			h := t.Hour() % 12
			if h == 0 {
				h = 12
			}
			sb.WriteString(fmt.Sprintf("%2d", h))
		case 'M':
			sb.WriteString(d2(t.Minute()))
		case 'S':
			sb.WriteString(d2(t.Second()))
			if prec > 0 {
				s := strconv.FormatFloat(frac, 'f', prec, 64)
				sb.WriteString(s[1:])
			}
		case 'j':
			sb.WriteString(fmt.Sprintf("%03d", t.YearDay()))
		case 'b', 'h':
			sb.WriteString(monAbbr[t.Month()-1])
		case 'B':
			sb.WriteString(monFull[t.Month()-1])
		case 'a':
			sb.WriteString(dayAbbr[t.Weekday()])
		case 'A':
			sb.WriteString(dayFull[t.Weekday()])
		case 'p':
			if t.Hour() < 12 {
				sb.WriteString("AM")
			} else {
				sb.WriteString("PM")
			}
		case 'P':
			if t.Hour() < 12 {
				sb.WriteString("am")
			} else {
				sb.WriteString("pm")
			}
		case 's':
			sb.WriteString(strconv.FormatInt(int64(sec), 10))
		case 'D':
			sb.WriteString(fmt.Sprintf("%02d/%02d/%02d", t.Month(), t.Day(), t.Year()%100))
		case 'F':
			sb.WriteString(fmt.Sprintf("%d-%02d-%02d", t.Year(), t.Month(), t.Day()))
		case 'T':
			sb.WriteString(fmt.Sprintf("%02d:%02d:%02d", t.Hour(), t.Minute(), t.Second()))
		case 'R':
			sb.WriteString(fmt.Sprintf("%02d:%02d", t.Hour(), t.Minute()))
		case 'w':
			sb.WriteString(strconv.Itoa(int(t.Weekday())))
		case 'U':
			sb.WriteString(fmt.Sprintf("%02d", (t.YearDay()+6-int(t.Weekday()))/7))
		case 'n':
			sb.WriteByte('\n')
		case 't':
			sb.WriteByte('\t')
		case '%':
			sb.WriteByte('%')
		default:
			sb.WriteByte('%')
			sb.WriteByte(f[i])
		}
	}
	return sb.String()
}

func gpStrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	sec := 0.0
	yday := -1
	pm := -1
	epoch := false
	var epochV float64
	si := 0
	readInt := func(maxd int) (int, bool) {
		for si < len(s) && s[si] == ' ' {
			si++
		}
		neg := false
		if si < len(s) && (s[si] == '-' || s[si] == '+') {
			neg = s[si] == '-'
			si++
		}
		st := si
		for si < len(s) && isDigit(s[si]) && si-st < maxd {
			si++
		}
		if si == st {
			return 0, false
		}
		v, _ := strconv.Atoi(s[st:si])
		if neg {
			v = -v
		}
		return v, true
	}
	for i := 0; i < len(f); i++ {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for si < len(s) && s[si] == ' ' {
					si++
				}
				continue
			}
			if si < len(s) && s[si] == c {
				si++
			} else {
				return 0, false
			}
			continue
		}
		i++
		if i >= len(f) {
			break
		}
		var ok bool
		switch f[i] {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			var y int
			y, ok = readInt(2)
			if y < 69 {
				year = 2000 + y
			} else {
				year = 1900 + y
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			var v int
			v, ok = readInt(2)
			sec = float64(v)
			if si < len(s) && s[si] == '.' {
				st := si
				si++
				for si < len(s) && isDigit(s[si]) {
					si++
				}
				fr, _ := strconv.ParseFloat("0"+s[st:si], 64)
				sec += fr
			}
		case 's':
			for si < len(s) && s[si] == ' ' {
				si++
			}
			n := floatPrefixLen(s[si:])
			if n == 0 {
				return 0, false
			}
			epochV, _ = strconv.ParseFloat(s[si:si+n], 64)
			si += n
			epoch = true
			ok = true
		case 'b', 'h', 'B':
			ok = false
			for k := 0; k < 12; k++ {
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(monFull[k])) {
					mon = k + 1
					si += len(monFull[k])
					ok = true
					break
				}
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(monAbbr[k])) {
					mon = k + 1
					si += 3
					ok = true
					break
				}
			}
		case 'a', 'A':
			ok = false
			for k := 0; k < 7; k++ {
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(dayFull[k])) {
					si += len(dayFull[k])
					ok = true
					break
				}
				if strings.HasPrefix(strings.ToLower(s[si:]), strings.ToLower(dayAbbr[k])) {
					si += 3
					ok = true
					break
				}
			}
		case 'p':
			ok = true
			if strings.HasPrefix(strings.ToLower(s[si:]), "pm") {
				pm = 1
				si += 2
			} else if strings.HasPrefix(strings.ToLower(s[si:]), "am") {
				pm = 0
				si += 2
			} else {
				ok = false
			}
		case '%':
			ok = si < len(s) && s[si] == '%'
			si++
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if epoch {
		return epochV, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday >= 0 {
		t = time.Date(year, 1, 1, 0, 0, 0, 0, time.UTC).AddDate(0, 0, yday-1)
		t = t.Add(time.Duration(hour)*time.Hour + time.Duration(min)*time.Minute)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + sec, true
}
