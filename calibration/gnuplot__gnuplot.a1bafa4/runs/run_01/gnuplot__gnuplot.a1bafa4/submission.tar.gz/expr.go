package main

import (
	"math"
	"math/cmplx"
	"strconv"
	"strings"
)

const (
	VUNDEF = iota
	VINT
	VCMPLX
	VSTR
	VARR
)

type Value struct {
	T  byte
	I  int64
	R  float64
	Im float64
	S  string
	A  *[]Value
}

func IntV(i int64) Value        { return Value{T: VINT, I: i} }
func FltV(f float64) Value      { return Value{T: VCMPLX, R: f} }
func CplxV(r, i float64) Value  { return Value{T: VCMPLX, R: r, Im: i} }
func StrV(s string) Value       { return Value{T: VSTR, S: s} }
func BoolV(b bool) Value {
	if b {
		return IntV(1)
	}
	return IntV(0)
}

func (v Value) isNum() bool { return v.T == VINT || v.T == VCMPLX }

func (v Value) Real() float64 {
	switch v.T {
	case VINT:
		return float64(v.I)
	case VCMPLX:
		return v.R
	case VSTR:
		f, ok := strToNum(v.S)
		if !ok {
			gpErr(-1, "Non-numeric string found where a numeric expression was expected")
		}
		return f.Real()
	case VARR:
		gpErr(-1, "internal error : non-numeric type")
	}
	gpErr(-1, "undefined value")
	return 0
}

func strToNum(s string) (Value, bool) {
	t := strings.TrimSpace(s)
	if t == "" {
		return Value{}, false
	}
	// gnuplot uses strtod on leading part
	end := floatPrefixLen(t)
	if end == 0 {
		return Value{}, false
	}
	f, _ := strconv.ParseFloat(t[:end], 64)
	isInt := !strings.ContainsAny(t[:end], ".eE")
	if isInt {
		if iv, err := strconv.ParseInt(t[:end], 10, 64); err == nil {
			return IntV(iv), true
		}
	}
	return FltV(f), true
}

func floatPrefixLen(s string) int {
	i := 0
	n := len(s)
	if i < n && (s[i] == '+' || s[i] == '-') {
		i++
	}
	ds := i
	for i < n && isDigit(s[i]) {
		i++
	}
	if i < n && s[i] == '.' {
		i++
		for i < n && isDigit(s[i]) {
			i++
		}
	}
	if i == ds || (i == ds+1 && s[ds] == '.') {
		// maybe inf/nan
		low := strings.ToLower(s[ds:])
		if strings.HasPrefix(low, "inf") {
			return ds + 3
		}
		if strings.HasPrefix(low, "nan") {
			return ds + 3
		}
		return 0
	}
	if i < n && (s[i] == 'e' || s[i] == 'E') {
		j := i + 1
		if j < n && (s[j] == '+' || s[j] == '-') {
			j++
		}
		if j < n && isDigit(s[j]) {
			for j < n && isDigit(s[j]) {
				j++
			}
			i = j
		}
	}
	return i
}

func parseFloatLoose(s string) float64 {
	n := floatPrefixLen(s)
	f, _ := strconv.ParseFloat(s[:n], 64)
	return f
}

func (v Value) numify() Value {
	if v.T == VSTR {
		f, ok := strToNum(v.S)
		if !ok {
			gpErr(-1, "Non-numeric string found where a numeric expression was expected")
		}
		return f
	}
	if v.T == VUNDEF {
		gpErr(-1, "undefined value")
	}
	if v.T == VARR {
		gpErr(-1, "internal error : non-numeric type")
	}
	return v
}

// ---------------- AST ------------------

type Node struct {
	Op   string // "num","str","var","call","un","bin","?:","idx","sub","assign","comma","card","col","arrlit"
	Val  Value
	Name string
	Kids []*Node
	Pos  int
}

type Parser struct {
	toks []Token
	p    int
}

func (ps *Parser) peek() Token { return ps.toks[ps.p] }
func (ps *Parser) isOp(s string) bool {
	t := ps.toks[ps.p]
	return t.Kind == TOP && t.Text == s
}
func (ps *Parser) next() Token {
	t := ps.toks[ps.p]
	if t.Kind != TEND {
		ps.p++
	}
	return t
}
func (ps *Parser) expectOp(s string, msg string) {
	if !ps.isOp(s) {
		gpErr(ps.peek().Pos, msg)
	}
	ps.p++
}

// parseExpr parses full expression including assignment and comma? Comma only inside parens.
func (ps *Parser) parseExpr() *Node {
	return ps.parseAssign()
}

func (ps *Parser) parseAssign() *Node {
	// name = expr (but not ==)
	t := ps.peek()
	if t.Kind == TNAME && ps.toks[ps.p+1].Kind == TOP && ps.toks[ps.p+1].Text == "=" {
		ps.p += 2
		rhs := ps.parseAssign()
		return &Node{Op: "assign", Name: t.Text, Kids: []*Node{rhs}, Pos: t.Pos}
	}
	return ps.parseTernary()
}

func (ps *Parser) parseTernary() *Node {
	c := ps.parseOr()
	if ps.isOp("?") {
		pos := ps.next().Pos
		a := ps.parseTernary()
		ps.expectOp(":", "expecting ':'")
		b := ps.parseTernary()
		return &Node{Op: "?:", Kids: []*Node{c, a, b}, Pos: pos}
	}
	return c
}

func (ps *Parser) binLevel(ops []string, sub func() *Node) *Node {
	l := sub()
	for {
		t := ps.peek()
		found := ""
		if t.Kind == TOP {
			for _, o := range ops {
				if t.Text == o {
					found = o
				}
			}
		} else if t.Kind == TNAME {
			for _, o := range ops {
				if t.Text == o {
					found = o
				}
			}
		}
		if found == "" {
			return l
		}
		ps.p++
		r := sub()
		l = &Node{Op: "bin", Name: found, Kids: []*Node{l, r}, Pos: t.Pos}
	}
}

func (ps *Parser) parseOr() *Node {
	return ps.binLevel([]string{"||"}, ps.parseAnd)
}
func (ps *Parser) parseAnd() *Node {
	return ps.binLevel([]string{"&&"}, ps.parseBitOr)
}
func (ps *Parser) parseBitOr() *Node {
	return ps.binLevel([]string{"|"}, ps.parseXor)
}
func (ps *Parser) parseXor() *Node {
	return ps.binLevel([]string{"^"}, ps.parseBitAnd)
}
func (ps *Parser) parseBitAnd() *Node {
	return ps.binLevel([]string{"&"}, ps.parseEq)
}
func (ps *Parser) parseEq() *Node {
	return ps.binLevel([]string{"==", "!=", "eq", "ne"}, ps.parseRel)
}
func (ps *Parser) parseRel() *Node {
	return ps.binLevel([]string{"<", "<=", ">", ">="}, ps.parseShift)
}
func (ps *Parser) parseShift() *Node {
	return ps.binLevel([]string{"<<", ">>"}, ps.parseAdd)
}
func (ps *Parser) parseAdd() *Node {
	return ps.binLevel([]string{"+", "-", "."}, ps.parseMul)
}
func (ps *Parser) parseMul() *Node {
	return ps.binLevel([]string{"*", "/", "%"}, ps.parseUnary)
}

func (ps *Parser) parseUnary() *Node {
	t := ps.peek()
	if t.Kind == TOP && (t.Text == "-" || t.Text == "+" || t.Text == "!" || t.Text == "~") {
		ps.p++
		x := ps.parseUnary()
		return &Node{Op: "un", Name: t.Text, Kids: []*Node{x}, Pos: t.Pos}
	}
	return ps.parsePow()
}

func (ps *Parser) parsePow() *Node {
	b := ps.parsePostfix()
	if ps.isOp("**") {
		t := ps.next()
		e := ps.parseUnary()
		return &Node{Op: "bin", Name: "**", Kids: []*Node{b, e}, Pos: t.Pos}
	}
	return b
}

func (ps *Parser) parsePostfix() *Node {
	x := ps.parsePrimary()
	for {
		t := ps.peek()
		if t.Kind == TOP && t.Text == "!" && !(ps.toks[ps.p+1].Kind == TOP && ps.toks[ps.p+1].Text == "=") {
			ps.p++
			x = &Node{Op: "fact", Kids: []*Node{x}, Pos: t.Pos}
			continue
		}
		if t.Kind == TOP && t.Text == "[" {
			ps.p++
			var a, b *Node
			if ps.isOp(":") {
				ps.p++
				a = nil
				if ps.isOp("]") {
					b = nil
				} else {
					b = ps.parseExpr()
				}
				ps.expectOp("]", "missing ]")
				x = &Node{Op: "sub", Kids: []*Node{x, a, b}, Pos: t.Pos}
				continue
			}
			a = ps.parseExpr()
			if ps.isOp(":") {
				ps.p++
				if ps.isOp("]") {
					b = nil
				} else {
					b = ps.parseExpr()
				}
				ps.expectOp("]", "missing ]")
				x = &Node{Op: "sub", Kids: []*Node{x, a, b}, Pos: t.Pos}
				continue
			}
			ps.expectOp("]", "missing ]")
			x = &Node{Op: "idx", Kids: []*Node{x, a}, Pos: t.Pos}
			continue
		}
		return x
	}
}

func (ps *Parser) parsePrimary() *Node {
	t := ps.peek()
	switch t.Kind {
	case TNUM:
		ps.p++
		if t.IsInt {
			return &Node{Op: "num", Val: IntV(t.IVal), Pos: t.Pos}
		}
		return &Node{Op: "num", Val: FltV(t.FVal), Pos: t.Pos}
	case TSTR:
		ps.p++
		return &Node{Op: "str", Val: StrV(t.Text), Pos: t.Pos}
	case TNAME:
		ps.p++
		if ps.isOp("(") {
			ps.p++
			var args []*Node
			if !ps.isOp(")") {
				for {
					args = append(args, ps.parseExpr())
					if ps.isOp(",") {
						ps.p++
						continue
					}
					break
				}
			}
			ps.expectOp(")", "')' expected")
			return &Node{Op: "call", Name: t.Text, Kids: args, Pos: t.Pos}
		}
		return &Node{Op: "var", Name: t.Text, Pos: t.Pos}
	case TOP:
		switch t.Text {
		case "(":
			ps.p++
			x := ps.parseExpr()
			for ps.isOp(",") {
				ps.p++
				y := ps.parseExpr()
				x = &Node{Op: "comma", Kids: []*Node{x, y}, Pos: t.Pos}
			}
			ps.expectOp(")", "')' expected")
			return x
		case "{":
			ps.p++
			rd := func() *Node {
				neg := false
				if ps.isOp("-") || ps.isOp("+") {
					neg = ps.peek().Text == "-"
					ps.p++
				}
				nt := ps.peek()
				if nt.Kind != TNUM {
					gpErr(t.Pos, "invalid complex constant")
				}
				ps.p++
				v := nt.FVal
				if nt.IsInt {
					v = float64(nt.IVal)
				}
				if neg {
					v = -v
				}
				return &Node{Op: "num", Val: FltV(v), Pos: nt.Pos}
			}
			re := rd()
			if !ps.isOp(",") {
				gpErr(t.Pos, "invalid complex constant")
			}
			ps.p++
			im := rd()
			if !ps.isOp("}") {
				gpErr(t.Pos, "invalid complex constant")
			}
			ps.p++
			return &Node{Op: "cplx", Kids: []*Node{re, im}, Pos: t.Pos}
		case "|":
			ps.p++
			if ps.peek().Kind != TNAME {
				gpErr(ps.peek().Pos, "not an array")
			}
			x := ps.parseBitXorNoBar()
			ps.expectOp("|", "'|' expected")
			return &Node{Op: "card", Kids: []*Node{x}, Pos: t.Pos}
		case "$":
			// column reference $N or $(expr)
			ps.p++
			n := ps.peek()
			if n.Kind == TNUM && n.IsInt {
				ps.p++
				return &Node{Op: "col", Kids: []*Node{{Op: "num", Val: IntV(n.IVal), Pos: n.Pos}}, Pos: t.Pos}
			}
			if ps.isOp("(") {
				x := ps.parsePrimary()
				return &Node{Op: "col", Kids: []*Node{x}, Pos: t.Pos}
			}
			if ps.isOp("#") {
				ps.p++
				return &Node{Op: "col", Kids: []*Node{{Op: "num", Val: IntV(-3)}}, Pos: t.Pos}
			}
			gpErr(n.Pos, "Column number or datablock line expected")
		}
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (ps *Parser) parseBitXorNoBar() *Node {
	return ps.binLevel([]string{"^"}, ps.parseBitAnd)
}

// ---------------- evaluation ------------------

type UserFunc struct {
	Params []string
	Body   *Node
	Text   string
}

var vars = map[string]Value{}
var udfs = map[string]*UserFunc{}
var localStack []map[string]Value

var colFunc func(n Value) Value // set during data processing
var curExprPos = -1
var stackExtra bool

func undefinedValue() {
	gpErr(curExprPos, "undefined value")
}

func lookupVar(name string) (Value, bool) {
	for i := len(localStack) - 1; i >= 0; i-- {
		if v, ok := localStack[i][name]; ok {
			return v, true
		}
	}
	v, ok := vars[name]
	return v, ok
}

func evalTop(n *Node) Value {
	save := curExprPos
	curExprPos = n.startPos()
	v := eval(n)
	curExprPos = save
	if stackExtra {
		stackExtra = false
		stdout.Flush()
		stderr.WriteString("\nwarning:  internal error--stack not empty!\n          (function called with too many parameters?)\n")
	}
	return v
}

func (n *Node) startPos() int {
	p := n.Pos
	for _, k := range n.Kids {
		if k != nil {
			if q := k.startPos(); q < p {
				p = q
			}
		}
	}
	return p
}

func eval(n *Node) Value {
	switch n.Op {
	case "num", "str":
		return n.Val
	case "var":
		v, ok := lookupVar(n.Name)
		if !ok || v.T == VUNDEF {
			gpErr(-1, "undefined variable: "+n.Name)
		}
		return v
	case "assign":
		v := eval(n.Kids[0])
		setVar(n.Name, v)
		return v
	case "comma":
		eval(n.Kids[0])
		return eval(n.Kids[1])
	case "cplx":
		re := eval(n.Kids[0]).numify()
		im := eval(n.Kids[1]).numify()
		return CplxV(re.Real(), im.Real())
	case "card":
		v := eval(n.Kids[0])
		if v.T == VARR {
			return IntV(int64(len(*v.A)))
		}
		gpErr(-1, "not an array")
	case "?:":
		c := eval(n.Kids[0]).numify()
		if truthy(c) {
			return eval(n.Kids[1])
		}
		return eval(n.Kids[2])
	case "un":
		x := eval(n.Kids[0])
		return unop(n.Name, x)
	case "fact":
		x := eval(n.Kids[0]).numify()
		if x.T != VINT {
			gpErr(-1, "factorial (!) argument must be an integer")
		}
		r := 1.0
		ri := int64(1)
		ok := true
		for i := int64(2); i <= x.I; i++ {
			r *= float64(i)
			if ok {
				nr := ri * i
				if nr/i != ri {
					ok = false
				}
				ri = nr
			}
		}
		if ok {
			return IntV(ri)
		}
		return FltV(r)
	case "bin":
		if n.Name == "&&" {
			a := eval(n.Kids[0]).numify()
			if !truthy(a) {
				return IntV(0)
			}
			b := eval(n.Kids[1]).numify()
			return BoolV(truthy(b))
		}
		if n.Name == "||" {
			a := eval(n.Kids[0]).numify()
			if truthy(a) {
				return IntV(1)
			}
			b := eval(n.Kids[1]).numify()
			return BoolV(truthy(b))
		}
		a := eval(n.Kids[0])
		b := eval(n.Kids[1])
		return binop(n.Name, a, b)
	case "idx":
		a := eval(n.Kids[0])
		i := eval(n.Kids[1])
		if a.T == VARR {
			idx := i.numify()
			k := int64(idx.Real())
			if idx.T == VINT {
				k = idx.I
			}
			if k < 1 || k > int64(len(*a.A)) {
				gpErr(-1, "array index out of range")
			}
			return (*a.A)[k-1]
		}
		gpErr(-1, "internal error: attempt to index a scalar variable")
	case "sub":
		a := eval(n.Kids[0])
		if a.T != VSTR {
			gpErr(-1, "substring operation requires a string")
		}
		s := a.S
		beg := int64(1)
		end := int64(len(s))
		if n.Kids[1] != nil {
			beg = toInt(eval(n.Kids[1]))
		}
		if n.Kids[2] != nil {
			end = toInt(eval(n.Kids[2]))
		}
		return StrV(substrUTF(s, beg, end))
	case "call":
		return callFunc(n)
	case "col":
		if !inDataCtx {
			gpErr(n.Kids[0].Pos, "column() called from invalid context")
		}
		v := eval(n.Kids[0])
		return columnRef(v, n)
	}
	gpErr(-1, "internal error")
	return Value{}
}

func substrUTF(s string, beg, end int64) string {
	r := []rune(s)
	l := int64(len(r))
	if beg < 1 {
		beg = 1
	}
	if end > l {
		end = l
	}
	if beg > end {
		return ""
	}
	return string(r[beg-1 : end])
}

func toInt(v Value) int64 {
	v = v.numify()
	if v.T == VINT {
		return v.I
	}
	return int64(v.R)
}

func truthy(v Value) bool {
	if v.T == VINT {
		return v.I != 0
	}
	return v.R != 0 || v.Im != 0
}

func setVar(name string, v Value) {
	for i := len(localStack) - 1; i >= 0; i-- {
		if _, ok := localStack[i][name]; ok {
			localStack[i][name] = v
			return
		}
	}
	if _, ok := vars[name]; !ok && !varSeen[name] {
		varSeen[name] = true
		varOrder = append(varOrder, name)
	}
	vars[name] = v
}

func unop(op string, x Value) Value {
	switch op {
	case "-":
		x = x.numify()
		if x.T == VINT {
			return IntV(-x.I)
		}
		return CplxV(-x.R, -x.Im)
	case "+":
		return x.numify()
	case "!":
		x = x.numify()
		return BoolV(!truthy(x))
	case "~":
		x = x.numify()
		if x.T != VINT {
			gpErr(-1, "~ (bitwise complement) argument must be an integer")
		}
		return IntV(^x.I)
	}
	return x
}

func cv(v Value) complex128 {
	if v.T == VINT {
		return complex(float64(v.I), 0)
	}
	return complex(v.R, v.Im)
}
func fromC(c complex128) Value { return CplxV(real(c), imag(c)) }

func binop(op string, a, b Value) Value {
	switch op {
	case ".":
		return StrV(toStr(a) + toStr(b))
	case "eq":
		return BoolV(toStrOnly(a) == toStrOnly(b))
	case "ne":
		return BoolV(toStrOnly(a) != toStrOnly(b))
	}
	a = a.numify()
	b = b.numify()
	ints := a.T == VINT && b.T == VINT
	switch op {
	case "+":
		if ints {
			r := a.I + b.I
			if (a.I >= 0) == (b.I >= 0) && (r >= 0) != (a.I >= 0) {
				return FltV(float64(a.I) + float64(b.I))
			}
			return IntV(r)
		}
		return CplxV(a.Real()+b.Real(), a.Im+b.Im)
	case "-":
		if ints {
			r := a.I - b.I
			if (a.I >= 0) != (b.I >= 0) && (r >= 0) != (a.I >= 0) {
				return FltV(float64(a.I) - float64(b.I))
			}
			return IntV(r)
		}
		return CplxV(a.Real()-b.Real(), a.Im-b.Im)
	case "*":
		if ints {
			r := a.I * b.I
			if a.I != 0 && (r/a.I != b.I || (a.I == -1 && b.I == math.MinInt64) || (b.I == -1 && a.I == math.MinInt64)) {
				return FltV(float64(a.I) * float64(b.I))
			}
			return IntV(r)
		}
		if a.Im == 0 && b.Im == 0 {
			return FltV(a.Real() * b.Real())
		}
		return fromC(cv(a) * cv(b))
	case "/":
		if ints {
			if b.I == 0 {
				undefinedValue()
			}
			return IntV(a.I / b.I)
		}
		if b.Im == 0 && a.Im == 0 {
			if b.Real() == 0 {
				undefinedValue()
			}
			return FltV(a.Real() / b.Real())
		}
		if cv(b) == 0 {
			undefinedValue()
		}
		return fromC(cv(a) / cv(b))
	case "%":
		if !ints {
			gpErr(-1, "non-integer operand for %")
		}
		if b.I == 0 {
			undefinedValue()
		}
		return IntV(a.I % b.I)
	case "**":
		return power(a, b)
	case "==":
		return BoolV(a.Real() == b.Real() && a.Im == b.Im)
	case "!=":
		return BoolV(!(a.Real() == b.Real() && a.Im == b.Im))
	case "<":
		return BoolV(a.Real() < b.Real())
	case "<=":
		return BoolV(a.Real() <= b.Real())
	case ">":
		return BoolV(a.Real() > b.Real())
	case ">=":
		return BoolV(a.Real() >= b.Real())
	case "&", "|", "^", "<<", ">>":
		if !ints {
			gpErr(-1, "non-integer operand for "+op)
		}
		switch op {
		case "&":
			return IntV(a.I & b.I)
		case "|":
			return IntV(a.I | b.I)
		case "^":
			return IntV(a.I ^ b.I)
		case "<<":
			return IntV(a.I << uint64(b.I))
		case ">>":
			return IntV(int64(uint64(a.I) >> uint64(b.I)))
		}
	}
	gpErr(-1, "unknown operator")
	return Value{}
}

func power(a, b Value) Value {
	if a.T == VINT && b.T == VINT {
		if b.I >= 0 {
			r := int64(1)
			base := a.I
			ok := true
			for i := int64(0); i < b.I; i++ {
				nr := r * base
				if base != 0 && nr/base != r {
					ok = false
					break
				}
				r = nr
				if r == 0 || r == 1 && base == 1 {
					break
				}
			}
			if ok {
				if base == -1 {
					if b.I%2 == 0 {
						return IntV(1)
					}
					return IntV(-1)
				}
				return IntV(r)
			}
			return FltV(math.Pow(float64(a.I), float64(b.I)))
		}
		if a.I == 0 {
			undefinedValue()
		}
		return FltV(math.Pow(float64(a.I), float64(b.I)))
	}
	if a.Im == 0 && b.Im == 0 {
		x := a.Real()
		y := b.Real()
		if x == 0 && y < 0 {
			undefinedValue()
		}
		if x < 0 && y != math.Trunc(y) {
			r := math.Pow(-x, y)
			th := math.Pi * y
			return CplxV(r*math.Cos(th), r*math.Sin(th))
		}
		if b.T == VINT {
			return FltV(ipow(x, b.I))
		}
		return FltV(math.Pow(x, y))
	}
	if cv(a) == 0 {
		return FltV(0)
	}
	return fromC(cmplx.Pow(cv(a), cv(b)))
}

func ipow(x float64, n int64) float64 {
	return math.Pow(x, float64(n))
}

func toStrOnly(v Value) string {
	if v.T == VSTR {
		return v.S
	}
	gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
	return ""
}

func toStr(v Value) string {
	if v.T == VSTR {
		return v.S
	}
	if v.T == VINT {
		return strconv.FormatInt(v.I, 10)
	}
	if v.T == VCMPLX {
		return fmtG(v.R)
	}
	gpErr(-1, "internal error : STRING operator applied to undefined or non-STRING variable")
	return ""
}

func fmtNum(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	s := strconv.FormatFloat(f, 'g', 15, 64)
	s = cFormatG(f, 15, false)
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

// %g in C
func cFormatG(f float64, prec int, alt bool) string {
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	if math.IsNaN(f) {
		if math.Signbit(f) {
			return "-nan"
		}
		return "nan"
	}
	if prec == 0 {
		prec = 1
	}
	if f == 0 {
		if alt {
			s := "0." + strings.Repeat("0", prec-1)
			if math.Signbit(f) {
				return "-" + s
			}
			return s
		}
		if math.Signbit(f) {
			return "-0"
		}
		return "0"
	}
	es := strconv.FormatFloat(f, 'e', prec-1, 64)
	ei := strings.LastIndexByte(es, 'e')
	exp, _ := strconv.Atoi(es[ei+1:])
	var s string
	if exp < -4 || exp >= prec {
		mant := es[:ei]
		if !alt && strings.Contains(mant, ".") {
			mant = strings.TrimRight(mant, "0")
			mant = strings.TrimSuffix(mant, ".")
		}
		e := exp
		sign := "+"
		if e < 0 {
			sign = "-"
			e = -e
		}
		es2 := strconv.Itoa(e)
		if len(es2) < 2 {
			es2 = "0" + es2
		}
		s = mant + "e" + sign + es2
	} else {
		s = strconv.FormatFloat(f, 'f', prec-1-exp, 64)
		if !alt && strings.Contains(s, ".") {
			s = strings.TrimRight(s, "0")
			s = strings.TrimSuffix(s, ".")
		}
	}
	return s
}

func fmtG(f float64) string {
	return cFormatG(f, 6, false)
}

// value formatted as gnuplot print does
func valueString(v Value) string {
	switch v.T {
	case VINT:
		return strconv.FormatInt(v.I, 10)
	case VCMPLX:
		if v.Im == 0 {
			return fmtNum(v.R)
		}
		return "{" + fmtNum(v.R) + ", " + fmtNum(v.Im) + "}"
	case VSTR:
		return v.S
	case VARR:
		var sb strings.Builder
		sb.WriteString("[")
		for i, e := range *v.A {
			if i > 0 {
				sb.WriteString(",")
			}
			switch e.T {
			case VSTR:
				sb.WriteString("\"" + e.S + "\"")
			case VUNDEF:
			default:
				sb.WriteString(valueString(e))
			}
		}
		sb.WriteString("]")
		return sb.String()
	}
	return ""
}
