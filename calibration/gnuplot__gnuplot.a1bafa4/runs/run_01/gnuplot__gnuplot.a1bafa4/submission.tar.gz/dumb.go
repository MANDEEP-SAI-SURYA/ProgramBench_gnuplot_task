package main

import (
	"math"
	"strings"
)

type Canvas struct {
	W, H  int
	cells [][]byte
}

func newCanvas(w, h int) *Canvas {
	c := &Canvas{W: w, H: h}
	c.cells = make([][]byte, h)
	for i := range c.cells {
		c.cells[i] = []byte(strings.Repeat(" ", w))
	}
	return c
}

// y is bottom-up
func (c *Canvas) set(x, y int, ch byte) {
	if x < 0 || y < 0 || x >= c.W || y >= c.H {
		return
	}
	c.cells[c.H-1-y][x] = ch
}

func (c *Canvas) text(x, y int, s string, just int) {
	// just: 0 left, 1 center, 2 right
	rs := []rune(s)
	n := len(rs)
	switch just {
	case 1:
		x -= n / 2
	case 2:
		x -= n - 1
	}
	if y < 0 || y >= c.H {
		return
	}
	for i, r := range rs {
		if r < 128 {
			c.set(x+i, y, byte(r))
		} else {
			c.set(x+i, y, '?')
		}
	}
}

// line with border style: '+' at endpoints, '-' or '|' in between
func (c *Canvas) borderLine(x0, y0, x1, y1 int) {
	dx := x1 - x0
	dy := y1 - y0
	if iabs(dy) > iabs(dx) {
		c.set(x0, y0, '+')
		for d := 1; d < iabs(dy); d++ {
			c.set(x0+int(math.Floor(float64(dx)*float64(d)/float64(iabs(dy))+0.5)), y0+d*isign(dy), '|')
		}
		c.set(x1, y1, '+')
	} else if iabs(dx) > iabs(dy) {
		c.set(x0, y0, '+')
		for d := 1; d < iabs(dx); d++ {
			c.set(x0+d*isign(dx), y0+int(math.Floor(float64(dy)*float64(d)/float64(iabs(dx))+0.5)), '-')
		}
		c.set(x1, y1, '+')
	} else {
		for d := 0; d <= iabs(dx); d++ {
			c.set(x0+d*isign(dx), y0+d*isign(dy), '+')
		}
	}
}

func (c *Canvas) line(x0, y0, x1, y1 int, ch byte) {
	dx := x1 - x0
	dy := y1 - y0
	if iabs(dy) > iabs(dx) {
		c.set(x0, y0, ch)
		for d := 1; d < iabs(dy); d++ {
			c.set(x0+int(math.Floor(float64(dx)*float64(d)/float64(iabs(dy))+0.5)), y0+d*isign(dy), ch)
		}
		c.set(x1, y1, ch)
	} else if iabs(dx) > iabs(dy) {
		c.set(x0, y0, ch)
		for d := 1; d < iabs(dx); d++ {
			c.set(x0+d*isign(dx), y0+int(math.Floor(float64(dy)*float64(d)/float64(iabs(dx))+0.5)), ch)
		}
		c.set(x1, y1, ch)
	} else {
		for d := 0; d <= iabs(dx); d++ {
			c.set(x0+d*isign(dx), y0+d*isign(dy), ch)
		}
	}
}

func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}
func isign(a int) int {
	if a < 0 {
		return -1
	}
	if a > 0 {
		return 1
	}
	return 0
}

var lineChars = []byte("*#$%@&=")

func ltChar(lt int) byte {
	if lt < 1 {
		return '*'
	}
	return lineChars[(lt-1)%len(lineChars)]
}

func ptChar(pt int) byte {
	if pt < 1 {
		return '.'
	}
	return byte('A' + (pt-1)%26)
}

// ---------- tics ------------

func quantizeTics(rng float64) float64 {
	if rng == 0 {
		return 1
	}
	rng = math.Abs(rng)
	power := math.Pow(10, math.Floor(math.Log10(rng)))
	xnorm := rng / power
	posns := 20 / xnorm
	var t float64
	switch {
	case posns > 40:
		t = 0.05
	case posns > 20:
		t = 0.1
	case posns > 10:
		t = 0.2
	case posns > 4:
		t = 0.5
	case posns > 2:
		t = 1
	case posns > 0.5:
		t = 2
	default:
		t = math.Ceil(xnorm)
	}
	return t * power
}

type ticMark struct {
	v     float64
	label string
}

func axisTics(ax *Axis, lo, hi float64) []ticMark {
	if !ax.ticsOn {
		return nil
	}
	var out []ticMark
	if lo > hi {
		lo, hi = hi, lo
	}
	if ax.ticStep < 0 || len(ax.ticList) > 0 {
		for _, t := range ax.ticList {
			if t.pos < lo-1e-9*(hi-lo) || t.pos > hi+1e-9*(hi-lo) {
				continue
			}
			lab := t.label
			if lab == "\x00" {
				lab = gprintfAxis(ax, t.pos)
			}
			out = append(out, ticMark{t.pos, lab})
		}
		if ax.ticStep < 0 {
			return out
		}
	}
	if ax.log {
		base := ax.logBase
		l0 := math.Floor(math.Log(lo)/math.Log(base) + 1e-9)
		l1 := math.Ceil(math.Log(hi)/math.Log(base) - 1e-9)
		step := 1.0
		if l1-l0 > 10 {
			step = math.Ceil((l1 - l0) / 10)
		}
		for k := l0; k <= l1; k += step {
			v := math.Pow(base, k)
			if v < lo*(1-1e-9) || v > hi*(1+1e-9) {
				continue
			}
			out = append(out, ticMark{v, gprintfAxis(ax, v)})
		}
		return out
	}
	step := ax.ticStep
	if step == 0 {
		step = ax.autoStep
		if step == 0 {
			step = quantizeTics(hi - lo)
		}
	}
	start := math.Ceil(lo/step-1e-9) * step
	if ax.ticStartSet {
		start = ax.ticStart
		for start < lo-step*1e-9 {
			start += step
		}
	}
	end := hi
	if ax.ticEndSet && ax.ticEnd < end {
		end = ax.ticEnd
	}
	for k := 0; ; k++ {
		v := start + float64(k)*step
		if v > end+step*1e-9 {
			break
		}
		if k > 1000 {
			break
		}
		if math.Abs(v) < step*1e-9 {
			v = 0
		}
		out = append(out, ticMark{v, gprintfAxis(ax, v)})
	}
	return out
}

func gprintfAxis(ax *Axis, v float64) string {
	if ax.isTime {
		f := ax.format
		if f == "% h" {
			f = "%H:%M"
		}
		return gpStrftime(f, v)
	}
	return gprintf(ax.format, v)
}

// extend autoscaled range to tics
func extendRange(ax *Axis, lo, hi float64) (float64, float64) {
	if ax.log {
		base := ax.logBase
		if ax.autoMin {
			lo = math.Pow(base, math.Floor(math.Log(lo)/math.Log(base)+1e-9))
		}
		if ax.autoMax {
			hi = math.Pow(base, math.Ceil(math.Log(hi)/math.Log(base)-1e-9))
		}
		return lo, hi
	}
	step := ax.ticStep
	if step <= 0 {
		step = quantizeTics(hi - lo)
		ax.autoStep = step
	}
	if ax.autoMin {
		lo = math.Floor(lo/step+1e-9) * step
	}
	if ax.autoMax {
		hi = math.Ceil(hi/step-1e-9) * step
	}
	return lo, hi
}

// ---------- render ------------

type plotFrame struct {
	xl, xr, yb, yt int
	xmin, xmax     float64
	ymin, ymax     float64
	xlog, ylog     bool
}

func (f *plotFrame) mapX(x float64) float64 {
	if f.xlog {
		return float64(f.xl) + (math.Log(x)-math.Log(f.xmin))*float64(f.xr-f.xl)/(math.Log(f.xmax)-math.Log(f.xmin))
	}
	return float64(f.xl) + (x-f.xmin)*float64(f.xr-f.xl)/(f.xmax-f.xmin)
}
func (f *plotFrame) mapY(y float64) float64 {
	if f.ylog {
		return float64(f.yb) + (math.Log(y)-math.Log(f.ymin))*float64(f.yt-f.yb)/(math.Log(f.ymax)-math.Log(f.ymin))
	}
	return float64(f.yb) + (y-f.ymin)*float64(f.yt-f.yb)/(f.ymax-f.ymin)
}

var mpCanvas *Canvas

func beginMultiplot() {
	if S.termName == "dumb" {
		mpCanvas = newCanvas(S.termW, S.termH)
		if mpTitle != "" {
			mpCanvas.text(S.termW/2, S.termH-2, mpTitle, 1)
		}
	}
}

func endMultiplot() {
	if !S.multiplot {
		return
	}
	S.multiplot = false
	if mpCanvas != nil {
		emitCanvas(mpCanvas)
		mpCanvas = nil
	}
}

func finishTerminal() {
	if mpCanvas != nil {
		S.multiplot = false
		emitCanvas(mpCanvas)
		mpCanvas = nil
	}
}

func emitCanvas(c *Canvas) {
	w := termOut()
	var sb strings.Builder
	if S.termFeed {
		sb.WriteString("\f")
	}
	for r := 0; r < c.H; r++ {
		sb.WriteString(string(c.cells[r]))
		sb.WriteString("\n")
	}
	w.WriteString(sb.String())
}

func dataRange(curves []*Curve, useX bool) (float64, float64, bool) {
	lo, hi := math.Inf(1), math.Inf(-1)
	for _, c := range curves {
		for _, p := range c.points {
			if p.brk || p.typ == 'u' {
				continue
			}
			v := p.y
			if useX {
				v = p.x
			}
			if useX && S.axes["x"].log && v <= 0 {
				continue
			}
			if !useX && S.axes["y"].log && v <= 0 {
				continue
			}
			if useX && !S.axes["y"].autoMin && !S.axes["y"].autoMax && p.typ == 'o' {
			}
			lo = math.Min(lo, v)
			hi = math.Max(hi, v)
			if !useX && len(p.ex) >= 2 && (c.style == "yerrorbars" || c.style == "yerrorlines") {
				lo = math.Min(lo, p.ex[0])
				hi = math.Max(hi, p.ex[1])
			}
			if !useX && len(p.ex) >= 4 && strings.HasPrefix(c.style, "xyerror") {
				lo = math.Min(lo, p.ex[2])
				hi = math.Max(hi, p.ex[3])
			}
			if useX && len(p.ex) >= 2 && (c.style == "xerrorbars" || c.style == "xerrorlines" || strings.HasPrefix(c.style, "xyerror")) {
				lo = math.Min(lo, p.ex[0])
				hi = math.Max(hi, p.ex[1])
			}
		}
	}
	return lo, hi, lo <= hi
}

func renderDumb(curves []*Curve, is3D bool) {
	if is3D {
		renderDumb3D(curves)
		return
	}
	W, H := S.termW, S.termH
	var cv *Canvas
	if S.multiplot && mpCanvas != nil {
		cv = mpCanvas
	} else {
		cv = newCanvas(W, H)
	}
	ox, oy := 0, 0
	pw, ph := W, H
	if S.multiplot && S.mpLayout[0] > 0 {
		rows, cols := S.mpLayout[0], S.mpLayout[1]
		r := S.mpIndex / cols
		cl := S.mpIndex % cols
		pw = W / cols
		ph = H / rows
		ox = cl * pw
		oy = H - (r+1)*ph
		S.mpIndex++
	}
	xa, ya := S.axes["x"], S.axes["y"]
	xmin, xmax := xa.min, xa.max
	if xa.autoMin || xa.autoMax {
		lo, hi, ok := dataRange(curves, true)
		if ok {
			if xa.autoMin {
				xmin = lo
			}
			if xa.autoMax {
				xmax = hi
			}
		}
	}
	ymin, ymax := ya.min, ya.max
	if ya.autoMin || ya.autoMax {
		lo, hi, ok := dataRange(curves, false)
		if !ok {
			gpErr(curSrcEndPos(), "all points y value undefined!")
		}
		if ya.autoMin {
			ymin = lo
		}
		if ya.autoMax {
			ymax = hi
		}
	}
	if ymin == ymax {
		d := math.Abs(ymin) * 0.01
		if d == 0 {
			d = 1
		}
		warn("empty y range [" + cfmtg(ymin) + ":" + cfmtg(ymax) + "], adjusting to [" + cfmtg(ymin-d) + ":" + cfmtg(ymax+d) + "]")
		ymin -= d
		ymax += d
	}
	if xmin == xmax {
		d := math.Abs(xmin) * 0.01
		if d == 0 {
			d = 1
		}
		xmin -= d
		xmax += d
	}
	xmin, xmax = extendRange(xa, xmin, xmax)
	ymin, ymax = extendRange(ya, ymin, ymax)
	xa.min, xa.max = xmin, xmax
	ya.min, ya.max = ymin, ymax
	if xa.reverse {
		xmin, xmax = xmax, xmin
	}
	if ya.reverse {
		ymin, ymax = ymax, ymin
	}
	xt := axisTics(xa, xmin, xmax)
	yt := axisTics(ya, ymin, ymax)
	ytw := 0
	for _, t := range yt {
		if n := len([]rune(t.label)); n > ytw {
			ytw = n
		}
	}
	xl := ox + 2 + ytw
	if ya.label != "" {
		xl += len([]rune(ya.label)) + 1
	}
	if S.lmargin >= 0 {
		xl = ox + int(S.lmargin)
	}
	xr := ox + pw - 4
	if S.rmargin >= 0 {
		xr = ox + pw - 1 - int(S.rmargin)
	}
	yb := oy + 2
	if xa.label != "" {
		yb++
	}
	if S.bmargin >= 0 {
		yb = oy + int(S.bmargin)
	}
	ytop := oy + ph - 2
	if S.title != "" {
		ytop -= 2
	}
	if S.tmargin >= 0 {
		ytop = oy + ph - 1 - int(S.tmargin)
	}
	keyEntries := []*Curve{}
	maxTitle := 0
	if S.keyOn {
		for _, c := range curves {
			if c.hasTitle && c.title != "" {
				keyEntries = append(keyEntries, c)
				if n := len([]rune(c.title)); n > maxTitle {
					maxTitle = n
				}
			}
		}
	}
	sampW := int(S.keySampLen) + 3
	keyW := 2 + maxTitle + 1 + sampW + 1
	if S.keyOutside && len(keyEntries) > 0 && !S.keyBelow {
		xr -= keyW
	}
	if S.keyBelow && len(keyEntries) > 0 {
		yb += len(keyEntries)
	}
	f := &plotFrame{xl: xl, xr: xr, yb: yb, yt: ytop, xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax, xlog: xa.log, ylog: ya.log}
	for _, t := range xt {
		x := roundi(f.mapX(t.v))
		cv.borderLine(x, yb, x, yb+1)
		if xa.mirror {
			cv.borderLine(x, ytop, x, ytop-1)
		}
		cv.text(x, yb-1, t.label, 1)
	}
	for _, t := range yt {
		y := roundi(f.mapY(t.v))
		cv.borderLine(xl, y, xl+2, y)
		if ya.mirror {
			cv.borderLine(xr, y, xr-2, y)
		}
		cv.text(xl-2, y, t.label, 2)
	}
	if S.title != "" {
		cv.text((xl+xr)/2, oy+ph-3, S.title, 1)
	}
	if xa.label != "" {
		cv.text((xl+xr)/2, yb-2, xa.label, 1)
	}
	if ya.label != "" {
		cv.text(ox+1, (yb+ytop)/2, ya.label, 0)
	}
	for _, l := range S.labels {
		x := roundi(f.mapX(l.x))
		y := roundi(f.mapY(l.y))
		if l.coord == "graph" {
			x = roundi(float64(xl) + l.x*float64(xr-xl))
			y = roundi(float64(yb) + l.y*float64(ytop-yb))
		} else if l.coord == "screen" {
			x = roundi(l.x * float64(W-1))
			y = roundi(l.y * float64(H-1))
		}
		j := 0
		if l.just == "center" {
			j = 1
		} else if l.just == "right" {
			j = 2
		}
		cv.text(x, y, l.text, j)
	}
	for _, a := range S.arrows {
		x0 := roundi(f.mapX(a.x1))
		y0 := roundi(f.mapY(a.y1))
		x1 := roundi(f.mapX(a.x2))
		y1 := roundi(f.mapY(a.y2))
		cv.line(x0, y0, x1, y1, '-')
	}
	nk := len(keyEntries)
	var kx0, ky0 int
	spacing := int(S.keySpacing)
	if spacing < 1 {
		spacing = 1
	}
	keyH := nk * spacing
	if S.keyOutside && !S.keyBelow {
		kx0 = xr + 2
		ky0 = ytop - 1
	} else if S.keyBelow {
		kx0 = (xl+xr)/2 - keyW/2
		ky0 = yb - 3
	} else {
		switch S.keyHoriz {
		case "left":
			kx0 = xl - 1
		case "center":
			kx0 = (xl+xr)/2 - keyW/2
		default:
			kx0 = xr - 1 - (keyW - 1)
		}
		switch S.keyVert {
		case "bottom":
			ky0 = yb + 1 + keyH - 1
		case "center":
			ky0 = (yb+ytop)/2 + keyH/2
		default:
			ky0 = ytop - 2
		}
	}
	if S.keyBox && nk > 0 {
		top := ky0 + 1
		bot := top - keyH
		cv.borderLine(kx0, bot, kx0+keyW-1, bot)
		cv.borderLine(kx0+keyW-1, bot, kx0+keyW-1, top)
		cv.borderLine(kx0+keyW-1, top, kx0, top)
		cv.borderLine(kx0, top, kx0, bot)
	}
	ki := 0
	for _, c := range curves {
		if S.keyOn && c.hasTitle && c.title != "" {
			y := ky0 - ki*spacing
			ki++
			var sx0, sx1 int
			if S.keyReverse {
				sx0 = kx0 - 1
				sx1 = sx0 + sampW - 1
				cv.text(sx1+1, y, c.title, 0)
			} else {
				tend := kx0 + 1 + maxTitle
				if S.keyJustLeft {
					cv.text(kx0+2, y, c.title, 0)
				} else {
					cv.text(tend, y, c.title, 2)
				}
				sx0 = tend + 2
				sx1 = sx0 + sampW - 1
			}
			drawKeySample(cv, c, sx0, sx1, y)
		}
		drawCurve(cv, f, c)
	}
	if S.border&15 != 0 {
		if S.border&1 != 0 {
			cv.borderLine(xl, yb, xr, yb)
		}
		if S.border&8 != 0 {
			cv.borderLine(xr, yb, xr, ytop)
		}
		if S.border&4 != 0 {
			cv.borderLine(xr, ytop, xl, ytop)
		}
		if S.border&2 != 0 {
			cv.borderLine(xl, ytop, xl, yb)
		}
	}
	if !S.multiplot {
		emitCanvas(cv)
	}
}

func curSrcEndPos() int {
	return len(curSrc().curLine)
}

func drawKeySample(cv *Canvas, c *Curve, x0, x1, y int) {
	ch := ltChar(c.lt)
	switch c.style {
	case "points":
		cv.set((x0+x1)/2, y, ptChar(c.pt))
	case "linespoints":
		cv.line(x0, y, x1, y, ch)
		cv.set((x0+x1)/2, y, ptChar(c.pt))
	case "dots":
		cv.set((x0+x1)/2, y, '.')
	default:
		cv.line(x0, y, x1, y, ch)
	}
}

func roundi(f float64) int { return int(math.Floor(f + 0.5)) }

func drawCurve(cv *Canvas, f *plotFrame, c *Curve) {
	ch := ltChar(c.lt)
	inBox := func(x, y int) bool {
		return x >= f.xl && x <= f.xr && y >= f.yb && y <= f.yt
	}
	switch c.style {
	case "points", "linespoints", "dots":
		if c.style == "linespoints" {
			drawPolyline(cv, f, c.points, ch)
		}
		pc := ptChar(c.pt)
		if c.style == "dots" {
			pc = '.'
		}
		for _, p := range c.points {
			if p.brk || p.typ != 'i' {
				continue
			}
			x, y := roundi(f.mapX(p.x)), roundi(f.mapY(p.y))
			if inBox(x, y) {
				cv.set(x, y, pc)
			}
		}
	case "impulses":
		for _, p := range c.points {
			if p.brk || p.typ == 'u' {
				continue
			}
			y0 := 0.0
			if f.ymin > 0 {
				y0 = f.ymin
			}
			if f.ymax < 0 {
				y0 = f.ymax
			}
			drawClipped(cv, f, p.x, y0, p.x, p.y, ch)
		}
	case "steps", "fsteps", "histeps":
		var prev *Point
		for i := range c.points {
			p := c.points[i]
			if p.brk || p.typ == 'u' {
				prev = nil
				continue
			}
			if prev != nil {
				if c.style == "steps" {
					drawClipped(cv, f, prev.x, prev.y, p.x, prev.y, ch)
					drawClipped(cv, f, p.x, prev.y, p.x, p.y, ch)
				} else {
					drawClipped(cv, f, prev.x, prev.y, prev.x, p.y, ch)
					drawClipped(cv, f, prev.x, p.y, p.x, p.y, ch)
				}
			}
			pp := p
			prev = &pp
		}
	case "boxes":
		pts := validPts(c.points)
		for i, p := range pts {
			var w float64
			if len(p.ex) >= 2 {
				w = p.ex[1] - p.ex[0]
			} else if S.boxwidth > 0 && !S.boxwidthRel {
				w = S.boxwidth
			} else {
				if i+1 < len(pts) {
					w = pts[i+1].x - p.x
				} else if i > 0 {
					w = p.x - pts[i-1].x
				} else {
					w = 1
				}
				if S.boxwidth > 0 {
					w *= S.boxwidth
				}
			}
			x0, x1 := p.x-w/2, p.x+w/2
			drawClipped(cv, f, x0, 0, x0, p.y, ch)
			drawClipped(cv, f, x0, p.y, x1, p.y, ch)
			drawClipped(cv, f, x1, p.y, x1, 0, ch)
		}
	case "yerrorbars", "xerrorbars", "xyerrorbars", "yerrorlines", "xerrorlines", "xyerrorlines":
		if strings.HasSuffix(c.style, "lines") {
			drawPolyline(cv, f, c.points, ch)
		}
		for _, p := range c.points {
			if p.brk || p.typ == 'u' || len(p.ex) < 2 {
				continue
			}
			if c.style[0] == 'y' {
				drawClipped(cv, f, p.x, p.ex[0], p.x, p.ex[1], ch)
			} else if c.style[1] != 'y' {
				drawClipped(cv, f, p.ex[0], p.y, p.ex[1], p.y, ch)
			} else if len(p.ex) >= 4 {
				drawClipped(cv, f, p.x, p.ex[2], p.x, p.ex[3], ch)
				drawClipped(cv, f, p.ex[0], p.y, p.ex[1], p.y, ch)
			}
			x, y := roundi(f.mapX(p.x)), roundi(f.mapY(p.y))
			if p.typ == 'i' && inBox(x, y) {
				cv.set(x, y, ptChar(c.pt))
			}
		}
	case "labels":
		for _, p := range c.points {
			if p.brk || p.typ != 'i' {
				continue
			}
			x, y := roundi(f.mapX(p.x)), roundi(f.mapY(p.y))
			cv.text(x, y, p.label, 1)
		}
	case "vectors":
		for _, p := range c.points {
			if p.brk || p.typ == 'u' || len(p.ex) < 2 {
				continue
			}
			drawClipped(cv, f, p.x, p.y, p.x+p.ex[0], p.y+p.ex[1], ch)
		}
	default:
		drawPolyline(cv, f, c.points, ch)
	}
}

func drawPolyline(cv *Canvas, f *plotFrame, pts []Point, ch byte) {
	var prev *Point
	for i := range pts {
		p := pts[i]
		if p.brk || p.typ == 'u' {
			prev = nil
			continue
		}
		if prev != nil {
			drawClipped(cv, f, prev.x, prev.y, p.x, p.y, ch)
		} else if p.typ == 'i' {
			x, y := roundi(f.mapX(p.x)), roundi(f.mapY(p.y))
			if i+1 >= len(pts) || pts[i+1].brk || pts[i+1].typ == 'u' {
				if x >= f.xl && x <= f.xr && y >= f.yb && y <= f.yt {
					cv.set(x, y, ch)
				}
			}
		}
		pp := p
		prev = &pp
	}
}

func drawClipped(cv *Canvas, f *plotFrame, x0, y0, x1, y1 float64, ch byte) {
	if f.xlog && (x0 <= 0 || x1 <= 0) {
		return
	}
	if f.ylog && (y0 <= 0 || y1 <= 0) {
		return
	}
	ax, ay := f.mapX(x0), f.mapY(y0)
	bx, by := f.mapX(x1), f.mapY(y1)
	xl, xr := float64(f.xl), float64(f.xr)
	yb, yt := float64(f.yb), float64(f.yt)
	t0, t1 := 0.0, 1.0
	dx, dy := bx-ax, by-ay
	clip := func(p, q float64) bool {
		if p == 0 {
			return q >= 0
		}
		r := q / p
		if p < 0 {
			if r > t1 {
				return false
			}
			if r > t0 {
				t0 = r
			}
		} else {
			if r < t0 {
				return false
			}
			if r < t1 {
				t1 = r
			}
		}
		return true
	}
	if !clip(-dx, ax-xl) || !clip(dx, xr-ax) || !clip(-dy, ay-yb) || !clip(dy, yt-ay) {
		return
	}
	cx0, cy0 := ax+t0*dx, ay+t0*dy
	cx1, cy1 := ax+t1*dx, ay+t1*dy
	cv.line(roundi(cx0), roundi(cy0), roundi(cx1), roundi(cy1), ch)
}

func renderDumb3D(curves []*Curve) {
	cv := newCanvas(S.termW, S.termH)
	emitCanvas(cv)
}
