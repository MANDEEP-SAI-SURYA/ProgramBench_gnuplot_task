package main

import (
	"math"
	"math/cmplx"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

type builtin struct {
	nargs int // -1 variadic
	fn    func(args []Value) Value
}

var builtins map[string]builtin

func real1(f func(float64) float64) builtin {
	return builtin{1, func(a []Value) Value {
		x := a[0].numify()
		return FltV(f(x.Real()))
	}}
}

func cplx1(fr func(float64) (float64, bool), fc func(complex128) complex128) builtin {
	return builtin{1, func(a []Value) Value {
		x := a[0].numify()
		if x.T == VCMPLX && x.Im != 0 {
			return fromC(fc(cv(x)))
		}
		r, ok := fr(x.Real())
		if !ok {
			return fromC(fc(cv(x)))
		}
		return FltV(r)
	}}
}

func checkUndef(f float64) Value {
	if math.IsNaN(f) || math.IsInf(f, 0) {
		undefinedValue()
	}
	return FltV(f)
}

func init() {
	builtins = map[string]builtin{
		"sin":  cplx1(func(x float64) (float64, bool) { return math.Sin(x), true }, cmplx.Sin),
		"cos":  cplx1(func(x float64) (float64, bool) { return math.Cos(x), true }, cmplx.Cos),
		"tan":  cplx1(func(x float64) (float64, bool) { return math.Tan(x), true }, cmplx.Tan),
		"sinh": cplx1(func(x float64) (float64, bool) { return math.Sinh(x), true }, cmplx.Sinh),
		"cosh": cplx1(func(x float64) (float64, bool) { return math.Cosh(x), true }, cmplx.Cosh),
		"tanh": cplx1(func(x float64) (float64, bool) { return math.Tanh(x), true }, cmplx.Tanh),
		"asin": cplx1(func(x float64) (float64, bool) { return math.Asin(x), x >= -1 && x <= 1 }, cmplx.Asin),
		"acos": cplx1(func(x float64) (float64, bool) { return math.Acos(x), x >= -1 && x <= 1 }, cmplx.Acos),
		"atan": cplx1(func(x float64) (float64, bool) { return math.Atan(x), true }, cmplx.Atan),
		"asinh": cplx1(func(x float64) (float64, bool) { return math.Asinh(x), true }, cmplx.Asinh),
		"acosh": cplx1(func(x float64) (float64, bool) { return math.Acosh(x), x >= 1 }, cmplx.Acosh),
		"atanh": cplx1(func(x float64) (float64, bool) { return math.Atanh(x), x > -1 && x < 1 }, cmplx.Atanh),
		"exp":  cplx1(func(x float64) (float64, bool) { return math.Exp(x), true }, cmplx.Exp),
		"log": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VCMPLX && x.Im != 0 || x.Real() < 0 {
				return fromC(cmplx.Log(cv(x)))
			}
			if x.Real() == 0 {
				undefinedValue()
			}
			return FltV(math.Log(x.Real()))
		}},
		"log10": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VCMPLX && x.Im != 0 || x.Real() < 0 {
				return fromC(cmplx.Log10(cv(x)))
			}
			if x.Real() == 0 {
				undefinedValue()
			}
			return FltV(math.Log10(x.Real()))
		}},
		"sqrt": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VCMPLX && x.Im != 0 || x.Real() < 0 {
				return fromC(cmplx.Sqrt(cv(x)))
			}
			return FltV(math.Sqrt(x.Real()))
		}},
		"abs": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VINT {
				if x.I < 0 {
					return IntV(-x.I)
				}
				return x
			}
			if x.Im != 0 {
				return FltV(cmplx.Abs(cv(x)))
			}
			return FltV(math.Abs(x.R))
		}},
		"real": {1, func(a []Value) Value { x := a[0].numify(); return FltV(x.Real()) }},
		"imag": {1, func(a []Value) Value { x := a[0].numify(); return FltV(x.Im) }},
		"arg":  {1, func(a []Value) Value { x := a[0].numify(); return FltV(math.Atan2(x.Im, x.Real())) }},
		"conj": {1, func(a []Value) Value { x := a[0].numify(); return CplxV(x.Real(), -x.Im) }},
		"sgn": {1, func(a []Value) Value {
			x := a[0].numify()
			r := x.Real()
			if r > 0 {
				return IntV(1)
			} else if r < 0 {
				return IntV(-1)
			}
			return IntV(0)
		}},
		"int": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VINT {
				return x
			}
			if math.IsNaN(x.R) || math.IsInf(x.R, 0) {
				undefinedValue()
			}
			return IntV(f2i(x.R))
		}},
		"floor": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VINT {
				return x
			}
			if x.Im != 0 {
				return CplxV(math.Floor(x.R), math.Floor(x.Im))
			}
			return IntV(f2i(math.Floor(x.R)))
		}},
		"ceil": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VINT {
				return x
			}
			if x.Im != 0 {
				return CplxV(math.Ceil(x.R), math.Ceil(x.Im))
			}
			return IntV(f2i(math.Ceil(x.R)))
		}},
		"round": {1, func(a []Value) Value {
			x := a[0].numify()
			if x.T == VINT {
				return x
			}
			return FltV(math.Round(x.R))
		}},
		"atan2": {2, func(a []Value) Value {
			return FltV(math.Atan2(a[0].numify().Real(), a[1].numify().Real()))
		}},
		"besj0": real1(math.J0),
		"besj1": real1(math.J1),
		"besy0": real1(math.Y0),
		"besy1": real1(math.Y1),
		"besjn": {2, func(a []Value) Value { return FltV(math.Jn(int(toInt(a[0])), a[1].numify().Real())) }},
		"besyn": {2, func(a []Value) Value { return FltV(math.Yn(int(toInt(a[0])), a[1].numify().Real())) }},
		"besi0": real1(func(x float64) float64 { return besselI(0, x) }),
		"besi1": real1(func(x float64) float64 { return besselI(1, x) }),
		"besin": {2, func(a []Value) Value { return FltV(besselI(int(toInt(a[0])), a[1].numify().Real())) }},
		"erf":   real1(math.Erf),
		"erfc":  real1(math.Erfc),
		"inverf": real1(math.Erfinv),
		"gamma": real1(func(x float64) float64 { return math.Gamma(x) }),
		"lgamma": real1(func(x float64) float64 { r, _ := math.Lgamma(x); return r }),
		"norm":  real1(func(x float64) float64 { return 0.5 * math.Erfc(-x/math.Sqrt2) }),
		"invnorm": real1(func(x float64) float64 { return -math.Sqrt2 * math.Erfcinv(2*x) }),
		"igamma": {2, func(a []Value) Value { return FltV(igamma(a[0].numify().Real(), a[1].numify().Real())) }},
		"ibeta": {3, func(a []Value) Value {
			return FltV(ibeta(a[0].numify().Real(), a[1].numify().Real(), a[2].numify().Real()))
		}},
		"lambertw": real1(lambertw),
		"rand": {1, func(a []Value) Value { return FltV(gpRand(toInt(a[0]))) }},
		"strlen": {1, func(a []Value) Value {
			if a[0].T != VSTR {
				gpErr(-1, "internal error : strlen of non-STRING argument")
			}
			return IntV(int64(len([]rune(a[0].S))))
		}},
		"strstrt": {2, func(a []Value) Value {
			s := toStrOnly(a[0])
			t := toStrOnly(a[1])
			k := strings.Index(s, t)
			return IntV(int64(len([]rune(s[:max(k, 0)]))) + int64(boolInt(k >= 0)))
		}},
		"substr": {3, func(a []Value) Value {
			s := toStrOnly(a[0])
			return StrV(substrUTF(s, toInt(a[1]), toInt(a[2])))
		}},
		"sprintf": {-1, gpSprintf},
		"gprintf": {2, func(a []Value) Value {
			if a[0].T != VSTR {
				gpErr(-1, "First parameter to gprintf must be a format string")
			}
			return StrV(gprintf(a[0].S, a[1].numify().Real()))
		}},
		"strftime": {2, func(a []Value) Value {
			if a[0].T != VSTR {
				gpErr(-1, "First parameter to strftime must be a format string")
			}
			return StrV(gpStrftime(a[0].S, a[1].numify().Real()))
		}},
		"strptime": {2, func(a []Value) Value {
			f, ok := gpStrptime(toStrOnly(a[0]), toStrOnly(a[1]))
			if !ok {
				return FltV(math.NaN())
			}
			return FltV(f)
		}},
		"time": {1, func(a []Value) Value {
			now := float64(time.Now().UnixNano()) / 1e9
			if a[0].T == VSTR {
				return StrV(gpStrftime(a[0].S, now))
			}
			if a[0].T == VINT {
				return IntV(int64(now))
			}
			return FltV(now)
		}},
		"system": {1, func(a []Value) Value {
			cmd := exec.Command("/bin/sh", "-c", toStrOnly(a[0]))
			cmd.Stderr = os.Stderr
			out, _ := cmd.Output()
			s := string(out)
			s = strings.TrimSuffix(s, "\n")
			return StrV(s)
		}},
		"words": {1, func(a []Value) Value { return IntV(int64(len(strings.Fields(toStrOnly(a[0]))))) }},
		"word": {2, func(a []Value) Value {
			f := strings.Fields(toStrOnly(a[0]))
			k := toInt(a[1])
			if k < 1 || k > int64(len(f)) {
				return StrV("")
			}
			return StrV(f[k-1])
		}},
		"trim": {1, func(a []Value) Value { return StrV(strings.Trim(toStrOnly(a[0]), " \t\n\r\f\v")) }},
		"exists": {1, func(a []Value) Value {
			v, ok := lookupVar(toStrOnly(a[0]))
			return BoolV(ok && v.T != VUNDEF)
		}},
		"value": {1, func(a []Value) Value {
			v, ok := lookupVar(toStrOnly(a[0]))
			if !ok {
				return FltV(math.NaN())
			}
			return v
		}},
		"tm_sec":  tmf(func(t time.Time) int { return t.Second() }),
		"tm_min":  tmf(func(t time.Time) int { return t.Minute() }),
		"tm_hour": tmf(func(t time.Time) int { return t.Hour() }),
		"tm_mday": tmf(func(t time.Time) int { return t.Day() }),
		"tm_mon":  tmf(func(t time.Time) int { return int(t.Month()) - 1 }),
		"tm_year": tmf(func(t time.Time) int { return t.Year() }),
		"tm_wday": tmf(func(t time.Time) int { return int(t.Weekday()) }),
		"tm_yday": tmf(func(t time.Time) int { return t.YearDay() - 1 }),
		"column": {1, func(a []Value) Value { return columnRef(a[0], nil) }},
		"valid": {1, func(a []Value) Value {
			v := columnRefSafe(a[0])
			return BoolV(v.T != VUNDEF && !(v.T == VCMPLX && math.IsNaN(v.R)))
		}},
		"stringcolumn": {1, func(a []Value) Value { return stringColumn(a[0]) }},
		"strcol":       {1, func(a []Value) Value { return stringColumn(a[0]) }},
		"columnhead":   {1, func(a []Value) Value { return columnHead(a[0]) }},
		"timecolumn": {2, func(a []Value) Value {
			s := stringColumn(a[0])
			f, ok := gpStrptime(toStrOnly(a[1]), s.S)
			if !ok {
				return Value{}
			}
			return FltV(f)
		}},
		"voigt": {2, func(a []Value) Value { return FltV(voigt(a[0].numify().Real(), a[1].numify().Real())) }},
		"expint": {2, func(a []Value) Value { return FltV(expint(int(toInt(a[0])), a[1].numify().Real())) }},
		"airy":   real1(airy),
		"EllipticK": real1(ellipK),
		"EllipticE": real1(ellipE),
	}
}

func boolInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

func tmf(f func(time.Time) int) builtin {
	return builtin{1, func(a []Value) Value {
		x := a[0].numify().Real()
		t := time.Unix(0, 0).UTC().Add(time.Duration(math.Floor(x)) * time.Second)
		return IntV(int64(f(t)))
	}}
}

func callFunc(n *Node) Value {
	if b, ok := builtins[n.Name]; ok {
		args := make([]Value, len(n.Kids))
		for i, k := range n.Kids {
			args[i] = eval(k)
		}
		if b.nargs >= 0 && len(n.Kids) != b.nargs {
			if len(n.Kids) < b.nargs {
				gpErr(-1, "stack underflow (function call with missing parameters?)")
			}
			stackExtra = true
			args = args[len(args)-b.nargs:]
		}
		return b.fn(args)
	}
	uf, ok := udfs[n.Name]
	if !ok {
		gpErr(-1, "undefined function: "+n.Name)
	}
	if len(n.Kids) != len(uf.Params) {
		s := "s"
		if len(uf.Params) == 1 {
			s = ""
		}
		gpErr(-1, "function "+n.Name+" requires "+strconv.Itoa(len(uf.Params))+" variable"+s)
	}
	scope := map[string]Value{}
	for i, k := range n.Kids {
		scope[uf.Params[i]] = eval(k)
	}
	localStack = append(localStack, scope)
	defer func() { localStack = localStack[:len(localStack)-1] }()
	return eval(uf.Body)
}

func callUser(name string, args []Value) Value {
	uf := udfs[name]
	scope := map[string]Value{}
	for i, p := range uf.Params {
		if i < len(args) {
			scope[p] = args[i]
		}
	}
	localStack = append(localStack, scope)
	defer func() { localStack = localStack[:len(localStack)-1] }()
	return eval(uf.Body)
}

// ---- random (gnuplot uses L'Ecuyer combined generator) ----
var seed1, seed2 int64 = 1234567890, 1234567890

func gpRand(arg int64) float64 {
	if arg < 0 {
		seed1, seed2 = 1234567890, 1234567890
		return 0
	}
	if arg > 0 {
		seed1 = arg
		seed2 = arg
	}
	const m1, m2 = 2147483563, 2147483399
	const a1, a2 = 40014, 40692
	const q1, q2 = 53668, 52774
	const r1, r2 = 12211, 3791
	k := seed1 / q1
	seed1 = a1*(seed1-k*q1) - k*r1
	if seed1 < 0 {
		seed1 += m1
	}
	k = seed2 / q2
	seed2 = a2*(seed2-k*q2) - k*r2
	if seed2 < 0 {
		seed2 += m2
	}
	z := seed1 - seed2
	if z < 1 {
		z += m1 - 1
	}
	return float64(z) * 4.656613057391769e-10
}

func besselI(n int, x float64) float64 {
	// series
	sum := 0.0
	term := math.Pow(x/2, float64(n)) / math.Gamma(float64(n)+1)
	for k := 0; k < 500; k++ {
		sum += term
		term *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		return 0
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		ap := a
		sum := 1 / a
		del := sum
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1 / 1e-300
	d := 1 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	la, _ := math.Lgamma(a + b)
	lb, _ := math.Lgamma(a)
	lc, _ := math.Lgamma(b)
	bt := math.Exp(la - lb - lc + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1e-300)
		if w < 0 {
			w = 0.5
		}
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		nw := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(nw-w) < 1e-15*(1+math.Abs(nw)) {
			w = nw
			break
		}
		w = nw
	}
	return w
}

func voigt(x, y float64) float64 {
	// numerical integration
	if y <= 0 {
		return math.Exp(-x*x) / math.Sqrt(math.Pi)
	}
	n := 4000
	L := 12.0
	h := 2 * L / float64(n)
	s := 0.0
	for i := 0; i <= n; i++ {
		t := -L + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		s += w * math.Exp(-t*t) / (y*y + (x-t)*(x-t))
	}
	return s * h * y / (math.Pi * math.Sqrt(math.Pi))
}

func expint(n int, x float64) float64 {
	// E_n(x)
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 1000; i++ {
			an := -float64(i) * float64(n-1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	nm1 := n - 1
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 1000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

func airy(x float64) float64 {
	// power series for Ai
	c1 := 0.355028053887817239
	c2 := 0.258819403792806798
	if x > 5 {
		z := 2.0 / 3.0 * math.Pow(x, 1.5)
		return math.Exp(-z) / (2 * math.Sqrt(math.Pi) * math.Pow(x, 0.25))
	}
	f, g := 1.0, x
	tf, tg := 1.0, x
	x3 := x * x * x
	for k := 1; k < 200; k++ {
		fk := float64(k)
		tf *= x3 / ((3*fk - 1) * (3 * fk))
		tg *= x3 / ((3 * fk) * (3*fk + 1))
		f += tf
		g += tg
		if math.Abs(tf)+math.Abs(tg) < 1e-17 {
			break
		}
	}
	return c1*f - c2*g
}

func ellipK(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	for i := 0; i < 50; i++ {
		a, b = (a+b)/2, math.Sqrt(a*b)
	}
	return math.Pi / (2 * a)
}

func ellipE(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	sum := k * k / 2
	p := 1.0
	for i := 0; i < 50; i++ {
		c := (a - b) / 2
		a, b = (a+b)/2, math.Sqrt(a*b)
		p *= 2
		sum += p * c * c / 2
	}
	return math.Pi / (2 * a) * (1 - sum)
}
