package main

import (
	"math"
	"strconv"
	"strings"
)

type fspec struct {
	flags string
	width int
	prec  int // -1 none
	conv  byte
	raw   string
}

// parse a printf spec starting at s[i]=='%'; returns spec and next index; ok=false if invalid
func parseSpec(s string, i int) (fspec, int, bool) {
	j := i + 1
	var sp fspec
	sp.prec = -1
	for j < len(s) && strings.IndexByte("-+ #0'", s[j]) >= 0 {
		sp.flags += string(s[j])
		j++
	}
	w := 0
	for j < len(s) && isDigit(s[j]) {
		w = w*10 + int(s[j]-'0')
		j++
	}
	sp.width = w
	if j < len(s) && s[j] == '.' {
		j++
		p := 0
		for j < len(s) && isDigit(s[j]) {
			p = p*10 + int(s[j]-'0')
			j++
		}
		sp.prec = p
	}
	if j >= len(s) {
		return sp, j, false
	}
	sp.conv = s[j]
	sp.raw = s[i : j+1]
	return sp, j + 1, true
}

func pad(sp fspec, body string, numeric bool) string {
	if len(body) >= sp.width {
		return body
	}
	n := sp.width - len(body)
	if strings.Contains(sp.flags, "-") {
		return body + strings.Repeat(" ", n)
	}
	if numeric && strings.Contains(sp.flags, "0") {
		// insert zeros after sign / 0x
		k := 0
		if len(body) > 0 && (body[0] == '-' || body[0] == '+' || body[0] == ' ') {
			k = 1
		}
		if strings.HasPrefix(body[k:], "0x") || strings.HasPrefix(body[k:], "0X") {
			k += 2
		}
		low := strings.ToLower(body)
		if strings.Contains(low, "inf") || strings.Contains(low, "nan") {
			return strings.Repeat(" ", n) + body
		}
		return body[:k] + strings.Repeat("0", n) + body[k:]
	}
	return strings.Repeat(" ", n) + body
}

func signPrefix(sp fspec, neg bool) string {
	if neg {
		return "-"
	}
	if strings.Contains(sp.flags, "+") {
		return "+"
	}
	if strings.Contains(sp.flags, " ") {
		return " "
	}
	return ""
}

func fmtFloatC(sp fspec, f float64) string {
	prec := sp.prec
	if prec < 0 {
		prec = 6
	}
	alt := strings.Contains(sp.flags, "#")
	neg := math.Signbit(f) && !math.IsNaN(f)
	a := math.Abs(f)
	var body string
	if math.IsInf(a, 0) {
		body = "inf"
	} else if math.IsNaN(a) {
		body = "nan"
		neg = math.Signbit(f)
	} else {
		switch sp.conv {
		case 'f', 'F':
			body = strconv.FormatFloat(a, 'f', prec, 64)
			if alt && prec == 0 {
				body += "."
			}
		case 'e', 'E':
			body = strconv.FormatFloat(a, 'e', prec, 64)
			if alt && prec == 0 {
				k := strings.IndexByte(body, 'e')
				body = body[:k] + "." + body[k:]
			}
		case 'g', 'G':
			body = cFormatG(a, prec, alt)
		}
	}
	if sp.conv == 'E' || sp.conv == 'G' || sp.conv == 'F' {
		body = strings.ToUpper(body)
	}
	return pad(sp, signPrefix(sp, neg)+body, true)
}

func fmtIntC(sp fspec, v int64) string {
	var body string
	neg := false
	switch sp.conv {
	case 'd', 'i':
		if v < 0 {
			neg = true
			body = strconv.FormatUint(uint64(-v), 10)
			if v == math.MinInt64 {
				body = "9223372036854775808"
			}
		} else {
			body = strconv.FormatInt(v, 10)
		}
	case 'x':
		body = strconv.FormatUint(uint64(v), 16)
	case 'X':
		body = strings.ToUpper(strconv.FormatUint(uint64(v), 16))
	case 'o':
		body = strconv.FormatUint(uint64(v), 8)
	case 'u':
		body = strconv.FormatUint(uint64(v), 10)
	}
	if sp.prec >= 0 {
		for len(body) < sp.prec {
			body = "0" + body
		}
		if sp.prec == 0 && v == 0 {
			body = ""
		}
	}
	if strings.Contains(sp.flags, "#") && v != 0 {
		switch sp.conv {
		case 'x':
			body = "0x" + body
		case 'X':
			body = "0X" + body
		case 'o':
			body = "0" + body
		}
	}
	pre := ""
	if sp.conv == 'd' || sp.conv == 'i' {
		pre = signPrefix(sp, neg)
	}
	if sp.prec >= 0 {
		sp.flags = strings.ReplaceAll(sp.flags, "0", "")
	}
	return pad(sp, pre+body, true)
}

func fmtStrC(sp fspec, s string) string {
	if sp.prec >= 0 && sp.prec < len(s) {
		s = s[:sp.prec]
	}
	return pad(sp, s, false)
}

func f2i(f float64) int64 {
	if math.IsNaN(f) || f >= 9.223372036854775807e18 || f < -9.223372036854775808e18 {
		return math.MinInt64
	}
	return int64(f)
}

func gpSprintf(args []Value) Value {
	if len(args) == 0 || args[0].T != VSTR {
		gpErr(-1, "First parameter to sprintf must be a format string")
	}
	fs := args[0].S
	ai := 1
	var sb strings.Builder
	i := 0
	for i < len(fs) {
		c := fs[i]
		if c != '%' {
			sb.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(fs) && fs[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		if ai >= len(args) {
			sb.WriteString(fs[i:])
			break
		}
		sp, j, ok := parseSpec(fs, i)
		if !ok {
			gpErr(-1, "f_sprintf: unsupported or invalid format specifier")
		}
		a := args[ai]
		ai++
		switch sp.conv {
		case 'd', 'i', 'x', 'X', 'o', 'u', 'c':
			if a.T == VSTR {
				gpErr(-1, "f_sprintf: attempt to print string value with numeric format")
			}
			a = a.numify()
			var iv int64
			if a.T == VINT {
				iv = a.I
			} else {
				iv = f2i(a.R)
			}
			if sp.conv == 'c' {
				sb.WriteString(pad(sp, string([]byte{byte(iv)}), false))
			} else {
				sb.WriteString(fmtIntC(sp, iv))
			}
		case 'f', 'F', 'e', 'E', 'g', 'G':
			if a.T == VSTR {
				gpErr(-1, "f_sprintf: attempt to print string value with numeric format")
			}
			a = a.numify()
			sb.WriteString(fmtFloatC(sp, a.Real()))
		case 's':
			if a.T != VSTR {
				gpErr(-1, "f_sprintf: attempt to print numeric value with string format")
			}
			sb.WriteString(fmtStrC(sp, a.S))
		default:
			gpErr(-1, "f_sprintf: unsupported or invalid format specifier")
		}
		i = j
	}
	return StrV(sb.String())
}

var siPrefix = []string{"y", "z", "a", "f", "p", "n", "u", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"}

// gprintf: gnuplot's tic-label formatter
func gprintf(format string, x float64) string {
	var sb strings.Builder
	i := 0
	for i < len(format) {
		c := format[i]
		if c != '%' {
			sb.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(format) && format[i+1] == '%' {
			sb.WriteByte('%')
			i += 2
			continue
		}
		sp, j, ok := parseSpec(format, i)
		if !ok {
			gpErr(-1, "Bad format character")
		}
		i = j
		switch sp.conv {
		case 'f', 'F', 'e', 'E', 'g', 'G':
			sb.WriteString(fmtFloatC(sp, x))
		case 'h', 'H':
			sp.conv = 'g'
			if sp.conv == 'H' {
				sp.conv = 'G'
			}
			sb.WriteString(fmtFloatC(sp, x))
		case 'x', 'X', 'o', 'd', 'i':
			sb.WriteString(fmtIntC(sp, f2i(x)))
		case 't', 'T':
			m, p := mantExp(x, 10, 1, sp.prec)
			if sp.conv == 't' {
				sp.conv = 'f'
				sb.WriteString(fmtFloatC(sp, m))
			} else {
				sp.conv = 'd'
				sb.WriteString(fmtIntC(sp, int64(p)))
			}
		case 's', 'S', 'c':
			m, p := mantExp(x, 10, 3, sp.prec)
			switch sp.conv {
			case 's':
				sp.conv = 'f'
				sb.WriteString(fmtFloatC(sp, m))
			case 'S':
				sp.conv = 'd'
				sb.WriteString(fmtIntC(sp, int64(p)))
			case 'c':
				k := p/3 + 8
				if k >= 0 && k < len(siPrefix) {
					sb.WriteString(pad(sp, siPrefix[k], false))
				}
			}
		case 'b', 'B':
			m, p := mantExp(x, 2, 10, sp.prec)
			if sp.conv == 'b' {
				sp.conv = 'f'
				sb.WriteString(fmtFloatC(sp, m))
			} else {
				pw := []string{"", "ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"}
				k := p / 10
				if k >= 0 && k < len(pw) {
					sb.WriteString(pw[k])
				} else {
					sb.WriteString("x2^{" + strconv.Itoa(p) + "}")
				}
			}
		case 'P':
			sp.conv = 'f'
			sb.WriteString(fmtFloatC(sp, x/math.Pi))
		case 'l', 'L':
			m, p := mantExp(x, 10, 1, sp.prec)
			if sp.conv == 'l' {
				sp.conv = 'f'
				sb.WriteString(fmtFloatC(sp, m))
			} else {
				sp.conv = 'd'
				sb.WriteString(fmtIntC(sp, int64(p)))
			}
		default:
			gpErr(-1, "Bad format character")
		}
	}
	return sb.String()
}

// mantissa/exponent with exponent multiple of step in given base
func mantExp(x float64, base float64, step int, prec int) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	a := math.Abs(x)
	var p int
	if base == 10 {
		p = int(math.Floor(math.Log10(a)))
	} else {
		p = int(math.Floor(math.Log2(a)))
	}
	p = int(math.Floor(float64(p)/float64(step))) * step
	m := x / math.Pow(base, float64(p))
	if prec < 0 {
		prec = 6
	}
	// rounding check
	if base == 10 {
		lim := math.Pow(10, float64(step))
		r := math.Abs(m)
		sc := math.Pow(10, float64(prec))
		if math.Round(r*sc)/sc >= lim {
			m /= lim
			p += step
		}
	}
	return m, p
}
