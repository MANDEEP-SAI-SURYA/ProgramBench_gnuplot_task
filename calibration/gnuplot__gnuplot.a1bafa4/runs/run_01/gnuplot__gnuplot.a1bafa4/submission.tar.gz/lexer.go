package main

import (
	"strings"
)

const (
	TNAME = iota
	TNUM
	TSTR
	TOP
	TEND
)

type Token struct {
	Kind  int
	Text  string // raw text (names/ops), decoded string for TSTR
	Pos   int    // start column in line
	End   int    // end column (exclusive)
	IsInt bool
	IVal  int64
	FVal  float64
	Quote byte
}

type GpError struct {
	Msg string
	Pos int // caret column, -1 for none
}

func gpErr(pos int, msg string) {
	panic(&GpError{Msg: msg, Pos: pos})
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }
func isAlpha(c byte) bool {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c >= 0x80
}

var multiOps = []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "+=", "-=", "*=", "/=", "%=", "..."}

// tokenize a line. Comments start with '#' outside strings.
func tokenize(line string) []Token {
	var toks []Token
	i := 0
	n := len(line)
	for i < n {
		c := line[i]
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '\n' {
			toks = append(toks, Token{Kind: TOP, Text: ";", Pos: i, End: i + 1})
			i++
			continue
		}
		if c == '#' {
			// comment till end of line
			j := strings.IndexByte(line[i:], '\n')
			if j < 0 {
				break
			}
			i += j
			continue
		}
		start := i
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])) {
			t := lexNumber(line, &i)
			t.Pos = start
			t.End = i
			toks = append(toks, t)
			continue
		}
		if isAlpha(c) {
			for i < n && (isAlpha(line[i]) || isDigit(line[i])) {
				i++
			}
			toks = append(toks, Token{Kind: TNAME, Text: line[start:i], Pos: start, End: i})
			continue
		}
		if c == '"' || c == '\'' {
			s, j := lexString(line, i)
			i = j
			toks = append(toks, Token{Kind: TSTR, Text: s, Pos: start, End: i, Quote: c})
			continue
		}
		if c == '$' && i+1 < n && (isAlpha(line[i+1])) {
			i++
			for i < n && (isAlpha(line[i]) || isDigit(line[i])) {
				i++
			}
			toks = append(toks, Token{Kind: TNAME, Text: line[start:i], Pos: start, End: i})
			continue
		}
		matched := false
		for _, op := range multiOps {
			if strings.HasPrefix(line[i:], op) {
				toks = append(toks, Token{Kind: TOP, Text: op, Pos: start, End: i + len(op)})
				i += len(op)
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		toks = append(toks, Token{Kind: TOP, Text: string(c), Pos: start, End: i + 1})
		i++
	}
	toks = append(toks, Token{Kind: TEND, Text: "", Pos: n, End: n})
	return toks
}

func lexNumber(line string, ip *int) Token {
	i := *ip
	n := len(line)
	start := i
	if line[i] == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
		i += 2
		var v int64
		for i < n {
			c := line[i]
			var d int64
			if isDigit(c) {
				d = int64(c - '0')
			} else if c >= 'a' && c <= 'f' {
				d = int64(c-'a') + 10
			} else if c >= 'A' && c <= 'F' {
				d = int64(c-'A') + 10
			} else {
				break
			}
			v = v*16 + d
			i++
		}
		*ip = i
		return Token{Kind: TNUM, IsInt: true, IVal: v, Text: line[start:i]}
	}
	isFloat := false
	if line[i] == '0' && i+1 < n && isDigit(line[i+1]) {
		// octal: consume octal digits only, unless it's a float
		j := i
		for j < n && isDigit(line[j]) {
			j++
		}
		if !(j < n && (line[j] == '.' || line[j] == 'e' || line[j] == 'E')) {
			k := i
			for k < n && line[k] >= '0' && line[k] <= '7' {
				k++
			}
			var v int64
			for _, ch := range line[i:k] {
				v = v*8 + int64(ch-'0')
			}
			*ip = k
			return Token{Kind: TNUM, IsInt: true, IVal: v, Text: line[i:k]}
		}
	}
	for i < n && isDigit(line[i]) {
		i++
	}
	if i < n && line[i] == '.' {
		isFloat = true
		i++
		for i < n && isDigit(line[i]) {
			i++
		}
	}
	if i < n && (line[i] == 'e' || line[i] == 'E') {
		j := i + 1
		if j < n && (line[j] == '+' || line[j] == '-') {
			j++
		}
		if j < n && isDigit(line[j]) {
			isFloat = true
			for j < n && isDigit(line[j]) {
				j++
			}
			i = j
		} else {
			*ip = i
			gpErr(i+1, "expecting exponent")
		}
	}
	*ip = i
	txt := line[start:i]
	if !isFloat {
		// octal if leading 0
		var v int64
		overflow := false
		if len(txt) > 1 && txt[0] == '0' {
			for _, ch := range txt[1:] {
				v = v*8 + int64(ch-'0')
			}
		} else {
			for _, ch := range txt {
				nv := v*10 + int64(ch-'0')
				if nv < v {
					overflow = true
				}
				v = nv
			}
		}
		if !overflow {
			return Token{Kind: TNUM, IsInt: true, IVal: v, Text: txt}
		}
	}
	f := parseFloatLoose(txt)
	return Token{Kind: TNUM, FVal: f, Text: txt}
}

func lexString(line string, i int) (string, int) {
	q := line[i]
	i++
	var sb strings.Builder
	n := len(line)
	for i < n {
		c := line[i]
		if c == q {
			if q == '\'' && i+1 < n && line[i+1] == '\'' {
				sb.WriteByte('\'')
				i += 2
				continue
			}
			return sb.String(), i + 1
		}
		if q == '"' && c == '\\' && i+1 < n {
			i++
			e := line[i]
			switch e {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			case 'a':
				sb.WriteByte(7)
			case 'b':
				sb.WriteByte(8)
			case 'f':
				sb.WriteByte(12)
			case 'v':
				sb.WriteByte(11)
			case '\\':
				sb.WriteByte('\\')
			case '"':
				sb.WriteByte('"')
			case '\n':
			default:
				if e >= '0' && e <= '7' {
					v := 0
					k := 0
					for k < 3 && i < n && line[i] >= '0' && line[i] <= '7' {
						v = v*8 + int(line[i]-'0')
						i++
						k++
					}
					sb.WriteByte(byte(v))
					continue
				}
				sb.WriteByte(e)
			}
			i++
			continue
		}
		sb.WriteByte(c)
		i++
	}
	return sb.String(), i
}
