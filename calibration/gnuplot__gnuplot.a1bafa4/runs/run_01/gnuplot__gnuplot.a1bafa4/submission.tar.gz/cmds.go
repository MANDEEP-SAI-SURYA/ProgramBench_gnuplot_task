package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

var exitAfterError bool
var printFile *bufio.Writer
var printFileH *os.File
var printToStdout bool
var printName string = "<stderr>"

var datablocks = map[string][]string{}

type breakPanic struct{}
type continuePanic struct{}

func printOut() *bufio.Writer {
	if printFile != nil {
		return printFile
	}
	if printToStdout {
		return stdout
	}
	return stderr
}

func (ex *Exec) command() {
	t := ex.peek()
	if t.Kind == TOP && t.Text == "!" {
		// shell command: rest of line
		ex.p = len(ex.toks) - 1
		return
	}
	if t.Kind == TOP && t.Text == "{" {
		e := matchBrace(ex.toks, ex.p)
		if e < 0 {
			gpErr(t.Pos, "invalid command")
		}
		ex.subExec(ex.p+1, e).run()
		ex.p = e + 1
		return
	}
	if t.Kind != TNAME {
		gpErr(t.Pos, "invalid command")
	}
	// datablock definition handled at reader level; assignment
	nt := ex.at(1)
	if nt.Kind == TOP && nt.Text == "=" {
		if strings.HasPrefix(t.Text, "$") {
			gpErr(t.Pos, "invalid command")
		}
		ex.p += 2
		v := ex.evalExpr()
		if v.T == VARR {
			// copy array semantics: arrays assigned by reference? gnuplot disallows
		}
		setVar(t.Text, v)
		return
	}
	if nt.Kind == TOP && nt.Text == "[" && !strings.HasPrefix(t.Text, "$") {
		// array element assignment?
		save := ex.p
		ex.p += 2
		ps := &Parser{toks: ex.toks, p: ex.p}
		idxN := ps.parseExpr()
		if ps.isOp("]") && ps.toks[ps.p+1].Kind == TOP && ps.toks[ps.p+1].Text == "=" {
			ex.p = ps.p + 2
			iv := evalTop(idxN)
			v := ex.evalExpr()
			arr, ok := lookupVar(t.Text)
			if !ok || arr.T != VARR {
				gpErr(t.Pos, "undefined array")
			}
			k := toInt(iv)
			if k < 1 || k > int64(len(*arr.A)) {
				gpErr(-1, "array index out of range")
			}
			(*arr.A)[k-1] = v
			return
		}
		ex.p = save
	}
	if nt.Kind == TOP && nt.Text == "(" && ex.tryFuncDef() {
		return
	}
	w := t.Text
	switch {
	case almostEq(w, "pr$int"):
		ex.p++
		ex.cmdPrint(printOut())
	case w == "printerr":
		ex.p++
		ex.cmdPrint(stderr)
	case almostEq(w, "if"):
		ex.cmdIf()
	case almostEq(w, "el$se"):
		gpErr(t.Pos, "else without if")
	case w == "do":
		ex.cmdDo()
	case almostEq(w, "wh$ile"):
		ex.cmdWhile()
	case almostEq(w, "l$oad"):
		ex.p++
		name := ex.evalString()
		ex.loadFile(name, nil, t)
	case almostEq(w, "ca$ll"):
		ex.p++
		name := ex.evalString()
		var args []string
		for !ex.endOfCmd() {
			tk := ex.peek()
			if tk.Kind == TSTR {
				ex.p++
				args = append(args, tk.Text)
				continue
			}
			v := ex.evalExpr()
			if v.T == VSTR {
				args = append(args, v.S)
			} else if v.T == VINT {
				args = append(args, "\x01"+strconv.FormatInt(v.I, 10))
			} else {
				args = append(args, "\x01"+fmtG(v.Real()))
			}
		}
		ex.loadFile(name, args, t)
	case almostEq(w, "ev$aluate"):
		ex.p++
		s := ex.evalString()
		ex.expectEnd()
		execLine(s)
		curSrc().curLine = ex.line
	case almostEq(w, "ex$it") || almostEq(w, "q$uit"):
		ex.p++
		code := 0
		if ex.isWord("st$atus") {
			ex.p++
			code = int(toInt(ex.evalExpr()))
		} else if ex.isWord("error") {
			ex.p++
			msg := ex.evalString()
			exitAfterError = true
			gpErr(-1, msg)
		}
		panic(&exitReq{code})
	case almostEq(w, "br$eak"):
		ex.p++
		panic(&breakPanic{})
	case almostEq(w, "con$tinue"):
		ex.p++
		panic(&continuePanic{})
	case w == "array":
		ex.cmdArray()
	case almostEq(w, "und$efine"):
		ex.p++
		for !ex.endOfCmd() {
			tk := ex.next()
			name := tk.Text
			if strings.HasSuffix(name, "*") {
				name = name[:len(name)-1]
			}
			if ex.isOp("*") {
				ex.p++
				for k := range vars {
					if strings.HasPrefix(k, name) {
						delete(vars, k)
					}
				}
				continue
			}
			if strings.HasPrefix(name, "$") {
				delete(datablocks, name)
			} else {
				delete(vars, name)
			}
		}
	case almostEq(w, "se$t"):
		ex.p++
		ex.cmdSet()
	case almostEq(w, "uns$et"):
		ex.p++
		ex.cmdUnset()
	case almostEq(w, "sh$ow"):
		ex.p++
		ex.cmdShow()
	case almostEq(w, "p$lot"):
		ex.p++
		ex.cmdPlot(false)
	case almostEq(w, "sp$lot"):
		ex.p++
		ex.cmdPlot(true)
	case almostEq(w, "rep$lot"):
		ex.p++
		ex.cmdReplot()
	case almostEq(w, "stat$s"):
		ex.p++
		ex.cmdStats()
	case w == "fit":
		ex.p++
		ex.cmdFit()
	case almostEq(w, "pa$use"):
		ex.p++
		if ex.isWord("mo$use") {
			ex.p = len(ex.toks) - 1
			return
		}
		v := ex.evalExpr()
		if !ex.endOfCmd() {
			s := ex.evalExpr()
			if s.T == VSTR {
				stdout.WriteString(s.S + "\n")
			}
		}
		_ = v
	case almostEq(w, "res$et"):
		ex.p++
		if ex.isWord("b$ind") || ex.isWord("e$rrors") || ex.isWord("s$ession") {
			ex.p++
		}
		resetSettings()
	case almostEq(w, "cl$ear"):
		ex.p++
		clearScreen()
	case almostEq(w, "sy$stem"):
		ex.p++
		s := ex.evalString()
		flushAll()
		runSystem(s)
	case almostEq(w, "cd"):
		ex.p++
		s := ex.evalString()
		if err := os.Chdir(s); err != nil {
			gpErr(t.Pos+3, "Can't change to this directory")
		}
	case almostEq(w, "pwd"):
		ex.p++
		d, _ := os.Getwd()
		stderr.WriteString(d + "\n")
	case almostEq(w, "test"):
		ex.p = len(ex.toks) - 1
	case almostEq(w, "up$date"):
		ex.p++
		ex.cmdUpdate()
	case almostEq(w, "sa$ve"):
		ex.p++
		ex.cmdSave()
	case almostEq(w, "h$elp") || w == "?":
		ex.p = len(ex.toks) - 1
	case almostEq(w, "his$tory"), almostEq(w, "bi$nd"), almostEq(w, "ref$resh"), almostEq(w, "low$er"), almostEq(w, "ra$ise"), almostEq(w, "vc$lear"), almostEq(w, "vf$ill"), almostEq(w, "she$ll"):
		ex.p = len(ex.toks) - 1
	case almostEq(w, "tog$gle"):
		ex.p = len(ex.toks) - 1
	default:
		gpErr(t.Pos, "invalid command")
	}
}

func runSystem(s string) {
	cmd := newShellCmd(s)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Run()
}

func (ex *Exec) loadFile(name string, args []string, t Token) {
	var lines []string
	if strings.HasPrefix(name, "$") {
		lines = datablocks[name]
	} else {
		data, err := os.ReadFile(name)
		if err != nil {
			gpErr(ex.toks[ex.p-1].Pos, "Cannot load input from '"+name+"'")
		}
		lines = splitLines(string(data))
	}
	src := &Source{kind: 0, name: name, lines: lines, args: args}
	// set ARGC/ARGV
	var saved map[string]Value
	if args != nil {
		saved = map[string]Value{}
		for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
			if v, ok := vars[k]; ok {
				saved[k] = v
			}
		}
		setCallArgs(name, args)
	}
	ok := runSource(src)
	if args != nil {
		for _, k := range []string{"ARGC", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9", "ARGV"} {
			if v, ok := saved[k]; ok {
				vars[k] = v
			} else {
				delete(vars, k)
			}
		}
	}
	curSrc().curLine = ex.line
	if !ok {
		panic(&abortSource{})
	}
}

func setCallArgs(name string, args []string) {
	setVar("ARGC", IntV(int64(len(args))))
	setVar("ARG0", StrV(name))
	arr := make([]Value, len(args))
	for i, a := range args {
		if strings.HasPrefix(a, "\x01") {
			args[i] = a[1:]
			arr[i] = FltV(parseFloatLoose(a[1:]))
		} else {
			arr[i] = StrV(a)
		}
	}
	setVar("ARGV", Value{T: VARR, A: &arr})
	for i := 1; i <= 9; i++ {
		if i <= len(args) {
			setVar("ARG"+strconv.Itoa(i), StrV(args[i-1]))
		} else {
			setVar("ARG"+strconv.Itoa(i), StrV(""))
		}
	}
}

func (ex *Exec) cmdPrint(w *bufio.Writer) {
	first := true
	if ex.endOfCmd() {
		gpErr(ex.peek().Pos, "constant expression required")
	}
	for {
		var n *Node
		if ex.peek().Kind == TNAME && strings.HasPrefix(ex.peek().Text, "$") && (ex.at(1).Kind == TEND || (ex.at(1).Kind == TOP && (ex.at(1).Text == ";" || ex.at(1).Text == ","))) {
			name := ex.next().Text
			lines, ok := datablocks[name]
			if !ok {
				gpErr(-1, "undefined variable: "+name)
			}
			for _, l := range lines {
				w.WriteString(l + "\n")
			}
			first = false
		} else {
			n = ex.parseExpr()
			v := evalTop(n)
			first = false
			w.WriteString(valueString(v))
			if v.T == VARR {
				w.WriteString("\n")
			}
		}
		if ex.isOp(",") {
			ex.p++
			w.WriteString(" ")
			if ex.endOfCmd() {
				gpErr(ex.peek().Pos, "constant expression required")
			}
			continue
		}
		break
	}
	_ = first
	w.WriteString("\n")
	if w != stderr {
		// keep ordering sane
	}
}

func (ex *Exec) tryFuncDef() bool {
	// name ( a , b ) = expr
	i := ex.p + 2
	var params []string
	for {
		t := ex.toks[i]
		if t.Kind != TNAME {
			return false
		}
		params = append(params, t.Text)
		i++
		if ex.toks[i].Kind == TOP && ex.toks[i].Text == "," {
			i++
			continue
		}
		break
	}
	if !(ex.toks[i].Kind == TOP && ex.toks[i].Text == ")") {
		return false
	}
	i++
	if !(ex.toks[i].Kind == TOP && ex.toks[i].Text == "=") {
		return false
	}
	name := ex.peek().Text
	ex.p = i + 1
	startPos := ex.peek().Pos
	body := ex.parseExpr()
	endPos := ex.peek().Pos
	text := strings.TrimRight(ex.line[ex.toks[ex.p-0].Pos:ex.toks[ex.p].Pos], " ")
	_ = text
	udfs[name] = &UserFunc{Params: params, Body: body, Text: strings.TrimSpace(ex.line[ex.toks[ex.p0(name)].Pos:endPos])}
	_ = startPos
	return true
}

func (ex *Exec) p0(name string) int {
	// locate the function name token index preceding current
	for i := ex.p - 1; i >= 0; i-- {
		if ex.toks[i].Kind == TNAME && ex.toks[i].Text == name && i+1 < len(ex.toks) && ex.toks[i+1].Text == "(" {
			return i
		}
	}
	return 0
}

func (ex *Exec) cmdIf() {
	ex.p++
	if !ex.isOp("(") {
		gpErr(ex.peek().Pos, "expecting '('")
	}
	cond := ex.evalCond()
	if ex.isOp("{") {
		e := matchBrace(ex.toks, ex.p)
		if e < 0 {
			gpErr(ex.peek().Pos, "unmatched '{'")
		}
		body := ex.subExec(ex.p+1, e)
		ex.p = e + 1
		done := false
		if cond {
			body.run()
			done = true
		}
		for ex.isWord("el$se") {
			ex.p++
			if ex.isWord("if") {
				ex.p++
				c2 := ex.evalCond()
				e2 := matchBrace(ex.toks, ex.p)
				if e2 < 0 {
					gpErr(ex.peek().Pos, "unmatched '{'")
				}
				b2 := ex.subExec(ex.p+1, e2)
				ex.p = e2 + 1
				if !done && c2 {
					b2.run()
					done = true
				}
				continue
			}
			if !ex.isOp("{") {
				gpErr(ex.peek().Pos, "expected {else-clause}")
			}
			e2 := matchBrace(ex.toks, ex.p)
			b2 := ex.subExec(ex.p+1, e2)
			ex.p = e2 + 1
			if !done {
				b2.run()
			}
		}
		return
	}
	// old style: rest of line
	if cond {
		ex.run()
	} else {
		ex.p = len(ex.toks) - 1
	}
}

func (ex *Exec) evalCond() bool {
	// expects '(' expr ')'
	ps := &Parser{toks: ex.toks, p: ex.p}
	n := ps.parsePrimary()
	ex.p = ps.p
	v := evalTop(n).numify()
	return truthy(v)
}

func (ex *Exec) cmdWhile() {
	ex.p++
	if !ex.isOp("(") {
		gpErr(ex.peek().Pos, "expecting '('")
	}
	ps := &Parser{toks: ex.toks, p: ex.p}
	cn := ps.parsePrimary()
	ex.p = ps.p
	if !ex.isOp("{") {
		gpErr(ex.peek().Pos, "expecting {while-clause}")
	}
	e := matchBrace(ex.toks, ex.p)
	if e < 0 {
		gpErr(ex.peek().Pos, "unmatched '{'")
	}
	body := ex.subExec(ex.p+1, e)
	ex.p = e + 1
	for truthy(evalTop(cn).numify()) {
		if runBody(body) {
			break
		}
	}
}

// runs body; returns true if break
func runBody(body *Exec) (brk bool) {
	defer func() {
		if r := recover(); r != nil {
			switch r.(type) {
			case *breakPanic:
				brk = true
			case *continuePanic:
				brk = false
			default:
				panic(r)
			}
		}
	}()
	body.p = 0
	body.run()
	return false
}

type iterSpec struct {
	varName string
	isIn    bool
	words   []string
	inArr   []Value
	start   *Node
	end     *Node // nil means open '*'
	step    *Node
	startV  Value
	endV    Value
	stepV   int64
}

// parse "[i=a:b:c]" or "[s in "..."]" at current '['
func (ex *Exec) parseIter() *iterSpec {
	if !ex.isOp("[") {
		gpErr(ex.peek().Pos, "expecting '['")
	}
	ex.p++
	it := &iterSpec{}
	vt := ex.next()
	if vt.Kind != TNAME {
		gpErr(vt.Pos, "expecting iteration variable")
	}
	it.varName = vt.Text
	if ex.isWord("in") {
		ex.p++
		v := ex.evalExpr()
		it.isIn = true
		if v.T == VARR {
			it.inArr = *v.A
		} else {
			it.words = strings.Fields(toStrOnly(v))
		}
		if !ex.isOp("]") {
			gpErr(ex.peek().Pos, "expecting ']'")
		}
		ex.p++
		return it
	}
	if !ex.isOp("=") {
		gpErr(ex.peek().Pos, "expecting '=' or 'in'")
	}
	ex.p++
	it.start = ex.parseExpr()
	if !ex.isOp(":") {
		gpErr(ex.peek().Pos, "expecting ':'")
	}
	ex.p++
	if ex.isOp("*") {
		ex.p++
	} else {
		it.end = ex.parseExpr()
	}
	if ex.isOp(":") {
		ex.p++
		it.step = ex.parseExpr()
	}
	if !ex.isOp("]") {
		gpErr(ex.peek().Pos, "expecting ']'")
	}
	ex.p++
	return it
}

// iterate calls f for each iteration value; f returns true to stop
func (it *iterSpec) each(f func() bool) {
	if it.isIn {
		if it.inArr != nil {
			for _, v := range it.inArr {
				setVar(it.varName, v)
				if f() {
					return
				}
			}
			return
		}
		for _, w := range it.words {
			setVar(it.varName, StrV(w))
			if f() {
				return
			}
		}
		return
	}
	s := toInt(evalTop(it.start))
	step := int64(1)
	if it.step != nil {
		step = toInt(evalTop(it.step))
	}
	var e int64
	open := it.end == nil
	if !open {
		e = toInt(evalTop(it.end))
	}
	if step == 0 {
		gpErr(-1, "iteration step cannot be 0")
	}
	for i := s; open || (step > 0 && i <= e) || (step < 0 && i >= e); i += step {
		setVar(it.varName, IntV(i))
		if f() {
			return
		}
		// gnuplot re-reads the variable (allows modification)
		if v, ok := lookupVar(it.varName); ok && v.T == VINT {
			i = v.I
		}
	}
}

func (ex *Exec) cmdDo() {
	ex.p++
	if !ex.isWord("for") {
		gpErr(ex.peek().Pos, "invalid command")
	}
	ex.p++
	var iters []*iterSpec
	for ex.isOp("[") {
		iters = append(iters, ex.parseIter())
	}
	if !ex.isOp("{") {
		gpErr(ex.peek().Pos, "expecting {do-clause}")
	}
	e := matchBrace(ex.toks, ex.p)
	if e < 0 {
		gpErr(ex.peek().Pos, "unmatched '{'")
	}
	body := ex.subExec(ex.p+1, e)
	ex.p = e + 1
	var rec func(k int) bool
	rec = func(k int) bool {
		if k == len(iters) {
			return runBody(body)
		}
		stop := false
		iters[k].each(func() bool {
			if rec(k + 1) {
				stop = true
				return true
			}
			return false
		})
		return stop
	}
	rec(0)
}

func (ex *Exec) cmdArray() {
	ex.p++
	nt := ex.next()
	if nt.Kind != TNAME {
		gpErr(nt.Pos, "illegal array name")
	}
	if !ex.isOp("[") {
		gpErr(ex.peek().Pos, "expecting array[size>0]")
	}
	ex.p++
	n := toInt(ex.evalExpr())
	if !ex.isOp("]") {
		gpErr(ex.peek().Pos, "expecting ']'")
	}
	ex.p++
	arr := make([]Value, n)
	if ex.isOp("=") {
		ex.p++
		if !ex.isOp("[") {
			gpErr(ex.peek().Pos, "expecting Array initializer")
		}
		ex.p++
		i := 0
		for !ex.isOp("]") {
			if ex.isOp(",") {
				ex.p++
				i++
				continue
			}
			v := ex.evalExpr()
			if i < len(arr) {
				arr[i] = v
			}
			if ex.isOp(",") {
				ex.p++
				i++
				continue
			}
			if !ex.isOp("]") {
				gpErr(ex.peek().Pos, "expecting ']'")
			}
		}
		ex.p++
	}
	vars[nt.Text] = Value{T: VARR, A: &arr}
}
