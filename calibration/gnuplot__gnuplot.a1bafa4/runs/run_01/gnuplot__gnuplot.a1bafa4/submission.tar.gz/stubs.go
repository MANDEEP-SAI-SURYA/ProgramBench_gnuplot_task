package main

func renderSVG(curves []*Curve, is3D bool)    {}
func renderCanvas(curves []*Curve, is3D bool) {}
func (ex *Exec) cmdUpdate()                   { ex.skipRest() }
func (ex *Exec) cmdSave()                     { ex.skipRest() }
