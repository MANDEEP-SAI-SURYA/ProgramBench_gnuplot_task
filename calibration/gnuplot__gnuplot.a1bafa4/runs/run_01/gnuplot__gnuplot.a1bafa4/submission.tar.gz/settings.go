package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
)

type Axis struct {
	name           string
	min, max       float64
	autoMin        bool
	autoMax        bool
	setMin, setMax bool // whether explicit (for show)
	reverse        bool
	writeback      bool
	log            bool
	logBase        float64
	format         string
	label          string
	labelOffset    [2]float64
	ticsOn         bool
	mirror         bool
	ticStep        float64 // 0 = auto
	ticStart       float64
	ticEnd         float64
	ticStartSet    bool
	ticEndSet      bool
	ticList        []ticEntry
	ticAdd         bool
	minor          int // mxtics: 0 off, -1 default
	isTime         bool
	timeFmt        string
	rotate         bool
	zeroaxis       bool
	autoStep       float64
}

type ticEntry struct {
	label string
	pos   float64
	level int
}

type Settings struct {
	samples1, samples2 int
	iso1, iso2         int
	axes               map[string]*Axis
	title              string
	titleOffset        [2]float64
	titleFont          string
	keyOn              bool
	keyPos             string // "top right" etc
	keyHoriz           string // left/right/center
	keyVert            string // top/bottom/center
	keyOutside         bool
	keyBox             bool
	keyReverse         bool
	keyInvert          bool
	keyJustLeft        bool
	keyTitle           string
	keySampLen         float64
	keySpacing         float64
	keyWidth           float64
	keyHeight          float64
	keyNoAuto          bool
	keyHorizontal      bool
	keyBelow           bool
	keyAbove           bool
	keyAtCoords        bool
	termName           string
	termW, termH       int
	termFeed           bool
	termOpts           string
	output             string
	angleDeg           bool
	styleData          string
	styleFunc          string
	grid               bool
	gridX, gridY       bool
	border             int
	parametric         bool
	polar              bool
	tableOn            bool
	tableFile          string
	tableBlock         string
	datafileSep        string
	datafileMissing    string
	datafileComments   string
	timefmt            string
	zero               float64
	dummy1, dummy2     string
	boxwidth           float64
	boxwidthSet        bool
	fitLog             string
	fitQuiet           bool
	fitBrief           bool
	fitVerbose         bool
	fitErrVars         bool
	fitCovVars         bool
	fitPrescale        bool
	fitLimit           float64
	fitMaxIter         int
	fitStartLambda     float64
	fitLambdaFactor    float64
	fitNoLog           bool
	fitV4              bool
	lmargin, rmargin   float64
	tmargin, bmargin   float64
	decimalsign        string
	sizeX, sizeY       float64
	originX, originY   float64
	clipTwo            bool
	ticsLevel          float64
	view               [4]float64
	hidden3d           bool
	surface            bool
	contour            bool
	pointsize          float64
	encoding           string
	labels             []textLabel
	arrows             []arrowSpec
	minussign          bool
	fillStyle          string
	histGap            int
	offsets            [4]float64
	logscaleAny        bool
	multiplot          bool
	mpLayout           [2]int
	mpIndex            int
	bars               float64
	xyplane            float64
	xyplaneRel         bool
	key3dSampLen       float64
	colorbox           bool
	pm3d               bool
	ticScale           float64
	style              map[string]string
	lineStyles         map[int]lineStyle
	boxwidthRel        bool
	smoothSamples      int
}

type lineStyle struct {
	lt, pt int
	lw, ps float64
	set    bool
}

type textLabel struct {
	tag    int
	text   string
	x, y   float64
	coord  string
	just   string
	front  bool
}

type arrowSpec struct {
	tag            int
	x1, y1, x2, y2 float64
	coord1, coord2 string
	nohead         bool
	heads          bool
	rel            bool
}

var S *Settings

func newAxis(name string) *Axis {
	return &Axis{name: name, min: -10, max: 10, autoMin: true, autoMax: true, logBase: 10, format: "% h", ticsOn: true, mirror: true, minor: -1, timeFmt: ""}
}

func initSettings() {
	S = &Settings{}
	S.samples1, S.samples2 = 100, 100
	S.iso1, S.iso2 = 10, 10
	S.axes = map[string]*Axis{}
	for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"} {
		S.axes[n] = newAxis(n)
	}
	S.axes["x2"].ticsOn = false
	S.axes["y2"].ticsOn = false
	S.axes["z"].mirror = false
	S.axes["r"].min = 0
	S.axes["t"].min, S.axes["t"].max = -5, 5
	S.axes["u"].min, S.axes["u"].max = -5, 5
	S.axes["v"].min, S.axes["v"].max = -5, 5
	S.keyOn = true
	S.keyHoriz = "right"
	S.keyVert = "top"
	S.keySampLen = 4
	S.keySpacing = 1
	S.termName = "unknown"
	S.termW, S.termH = 79, 24
	S.termFeed = true
	S.styleData = "points"
	S.styleFunc = "lines"
	S.border = 31
	S.datafileComments = "#"
	S.timefmt = "%d/%m/%y,%H:%M"
	S.zero = 1e-8
	S.dummy1, S.dummy2 = "x", "y"
	S.fitPrescale = true
	S.fitErrVars = true
	S.fitLimit = 1e-5
	S.fitStartLambda = 0
	S.fitLambdaFactor = 10
	S.lmargin, S.rmargin, S.tmargin, S.bmargin = -1, -1, -1, -1
	S.sizeX, S.sizeY = 1, 1
	S.ticsLevel = 0.5
	S.view = [4]float64{60, 30, 1, 1}
	S.surface = true
	S.pointsize = 1
	S.clipTwo = false
	S.fillStyle = "empty"
	S.histGap = 2
	S.bars = 1
	S.xyplane = 0.5
	S.xyplaneRel = true
	S.colorbox = true
	S.ticScale = 1
	S.style = map[string]string{}
	S.lineStyles = map[int]lineStyle{}
	S.boxwidth = -1
	S.boxwidthRel = false
	S.encoding = "default"
	if _, ok := vars["pi"]; !ok {
		vars["pi"] = FltV(math.Pi)
		vars["NaN"] = FltV(math.NaN())
		vars["I"] = CplxV(0, 1)
		vars["VoxelDistance"] = FltV(0)
		vars["GNUTERM"] = StrV("unknown")
		vars["GPVAL_VERSION"] = FltV(5.4)
		vars["GPVAL_PATCHLEVEL"] = StrV("9")
		vars["GPVAL_COMPILE_OPTIONS"] = StrV("")
		vars["GPVAL_TERM"] = StrV("unknown")
		vars["GPVAL_TERMINALS"] = StrV("canvas dumb svg")
		vars["GPVAL_SYSNAME"] = StrV("Linux")
		vars["GPVAL_MACHINE"] = StrV("x86_64")
	}
}

func resetSettings() {
	termName, w, h, out := S.termName, S.termW, S.termH, S.output
	opts := S.termOpts
	initSettings()
	S.termName, S.termW, S.termH, S.output, S.termOpts = termName, w, h, out, opts
}

func clearScreen() {
	if S.multiplot {
		return
	}
}

var outFile *os.File
var outW *bufio.Writer

func termOut() *bufio.Writer {
	if outW != nil {
		return outW
	}
	return stdout
}

func closeOutput() {
	if outW != nil {
		outW.Flush()
		outFile.Close()
		outW = nil
		outFile = nil
	}
	finishTerminal()
}

func newShellCmd(s string) *exec.Cmd {
	return exec.Command("/bin/sh", "-c", s)
}

// ----------------- set / unset -----------------

func (ex *Exec) axisFromWord(w string) (string, bool) {
	for _, a := range []string{"x2", "y2", "x", "y", "z", "cb", "r", "t", "u", "v"} {
		if w == a {
			return a, true
		}
	}
	return "", false
}

func (ex *Exec) parseRange(ax *Axis) {
	// at '['
	if !ex.isOp("[") {
		return
	}
	ex.p++
	// dummy var assignment "t=..."
	if ex.peek().Kind == TNAME && ex.at(1).Kind == TOP && ex.at(1).Text == "=" {
		ex.p += 2
	}
	if ex.isOp(":") {
		ex.p++
	} else {
		if ex.isOp("*") {
			ex.p++
			ax.autoMin = true
		} else {
			v := ex.evalRangeVal(ax)
			ax.min = v
			ax.autoMin = false
		}
		if ex.isOp(":") {
			ex.p++
		} else if ex.isOp("]") {
			ex.p++
			return
		} else {
			gpErr(ex.peek().Pos, "expecting ':'")
		}
	}
	if ex.isOp("]") {
		ex.p++
		return
	}
	if ex.isOp("*") {
		ex.p++
		ax.autoMax = true
	} else {
		v := ex.evalRangeVal(ax)
		ax.max = v
		ax.autoMax = false
	}
	if !ex.isOp("]") {
		gpErr(ex.peek().Pos, "expecting ']'")
	}
	ex.p++
}

func (ex *Exec) evalRangeVal(ax *Axis) float64 {
	v := ex.evalExpr()
	if v.T == VSTR && ax.isTime {
		f, _ := gpStrptime(S.timefmt, v.S)
		return f
	}
	return v.numify().Real()
}

func (ex *Exec) skipRest() {
	for !ex.endOfCmd() {
		ex.p++
	}
}

func (ex *Exec) cmdSet() {
	t := ex.peek()
	if t.Kind != TNAME {
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
	w := t.Text
	ex.p++
	// axis-prefixed settings
	for _, a := range []string{"x2", "y2", "x", "y", "z", "cb", "r", "t", "u", "v"} {
		if strings.HasPrefix(w, a) {
			rest := w[len(a):]
			ax := S.axes[a]
			switch {
			case rest == "range" || (rest == "r" && false):
				ex.parseRangeSet(ax)
				return
			case rest == "label" || rest == "lab" || rest == "labe":
				if ex.endOfCmd() {
					ax.label = ""
				} else {
					ax.label = ex.evalString()
				}
				ex.parseTextOpts(&ax.labelOffset, nil)
				return
			case rest == "tics" || rest == "tic":
				ex.parseTics(ax)
				return
			case rest == "data":
				if ex.isWord("t$ime") {
					ex.p++
					ax.isTime = true
				} else {
					ax.isTime = false
				}
				return
			case rest == "zeroaxis":
				ax.zeroaxis = true
				ex.skipRest()
				return
			case rest == "mtics":
				if ex.endOfCmd() {
					ax.minor = -2
				} else {
					ax.minor = int(toInt(ex.evalExpr()))
				}
				return
			case rest == "format" && false:
			}
		}
	}
	switch {
	case almostEq(w, "sa$mples"):
		a := int(toInt(ex.evalExpr()))
		b := a
		if ex.isOp(",") {
			ex.p++
			b = int(toInt(ex.evalExpr()))
		}
		if a < 2 || b < 2 {
			gpErr(-1, "sampling rate must be > 1; sampling unchanged")
		}
		S.samples1, S.samples2 = a, b
	case almostEq(w, "isosam$ples"):
		a := int(toInt(ex.evalExpr()))
		b := a
		if ex.isOp(",") {
			ex.p++
			b = int(toInt(ex.evalExpr()))
		}
		S.iso1, S.iso2 = a, b
	case almostEq(w, "tit$le"):
		if ex.endOfCmd() {
			S.title = ""
			return
		}
		if !ex.isWord("off$set") && !ex.isWord("font") {
			S.title = ex.evalString()
		}
		ex.parseTextOpts(&S.titleOffset, &S.titleFont)
	case almostEq(w, "k$ey"):
		ex.parseKey()
	case almostEq(w, "t$erminal"):
		ex.setTerminal()
	case almostEq(w, "o$utput"):
		if ex.endOfCmd() {
			setOutput("")
		} else {
			setOutput(ex.evalString())
		}
	case almostEq(w, "print"):
		if printFile != nil {
			printFile.Flush()
			printFileH.Close()
			printFile = nil
		}
		printToStdout = false
		if ex.endOfCmd() {
			printName = "<stderr>"
			return
		}
		name := ex.evalString()
		app := false
		if ex.isWord("app$end") {
			ex.p++
			app = true
		}
		if name == "-" {
			printToStdout = true
			printName = "<stdout>"
			return
		}
		flag := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flag = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(name, flag, 0644)
		if err != nil {
			gpErr(-1, "cannot open print file")
		}
		printFileH = f
		printFile = bufio.NewWriter(f)
		printName = name
	case almostEq(w, "log$scale"):
		base := 10.0
		axesList := []string{"x", "y", "z", "cb", "x2", "y2"}
		if !ex.endOfCmd() {
			s := ex.next().Text
			axesList = parseAxesList(s)
			if !ex.endOfCmd() {
				base = ex.evalNum()
			}
		}
		for _, a := range axesList {
			S.axes[a].log = true
			S.axes[a].logBase = base
		}
	case almostEq(w, "form$at"):
		axl := []string{"x", "y", "z", "cb", "x2", "y2"}
		if ex.peek().Kind == TNAME {
			axl = parseAxesList(ex.next().Text)
		}
		f := "% h"
		if !ex.endOfCmd() {
			f = ex.evalString()
		}
		for _, a := range axl {
			S.axes[a].format = f
		}
	case almostEq(w, "an$gles"):
		if ex.isWord("d$egrees") {
			S.angleDeg = true
		} else {
			S.angleDeg = false
		}
		ex.p++
	case almostEq(w, "g$rid"):
		S.grid = true
		ex.skipRest()
	case almostEq(w, "bor$der"):
		if !ex.endOfCmd() && ex.peek().Kind == TNUM {
			S.border = int(toInt(ex.evalExpr()))
		} else {
			S.border = 31
		}
		ex.skipRest()
	case almostEq(w, "par$ametric"):
		S.parametric = true
		S.dummy1, S.dummy2 = "t", "y"
	case almostEq(w, "pol$ar"):
		S.polar = true
	case almostEq(w, "tab$le"):
		S.tableOn = true
		S.tableFile = ""
		S.tableBlock = ""
		if !ex.endOfCmd() {
			if ex.peek().Kind == TNAME && strings.HasPrefix(ex.peek().Text, "$") {
				S.tableBlock = ex.next().Text
			} else {
				S.tableFile = ex.evalString()
			}
		}
		if ex.isWord("app$end") {
			ex.p++
		}
	case almostEq(w, "da$tafile"):
		ex.setDatafile()
	case almostEq(w, "timef$mt"):
		S.timefmt = ex.evalString()
	case almostEq(w, "z$ero"):
		S.zero = ex.evalNum()
	case almostEq(w, "du$mmy"):
		S.dummy1 = ex.next().Text
		if ex.isOp(",") {
			ex.p++
			S.dummy2 = ex.next().Text
		}
	case almostEq(w, "st$yle"):
		ex.setStyle()
	case almostEq(w, "box$width"):
		if ex.endOfCmd() {
			S.boxwidth = -1
		} else {
			S.boxwidth = ex.evalNum()
			if ex.isWord("rel$ative") {
				ex.p++
				S.boxwidthRel = true
			} else if ex.isWord("abs$olute") {
				ex.p++
				S.boxwidthRel = false
			}
		}
	case almostEq(w, "fit"):
		ex.setFit()
	case almostEq(w, "lmar$gin"):
		S.lmargin = ex.marginVal()
	case almostEq(w, "rmar$gin"):
		S.rmargin = ex.marginVal()
	case almostEq(w, "tmar$gin"):
		S.tmargin = ex.marginVal()
	case almostEq(w, "bmar$gin"):
		S.bmargin = ex.marginVal()
	case almostEq(w, "mar$gins"):
		if ex.endOfCmd() {
			S.lmargin, S.rmargin, S.tmargin, S.bmargin = -1, -1, -1, -1
		} else {
			S.lmargin = ex.evalNum()
			ex.p++
			S.rmargin = ex.evalNum()
			ex.p++
			S.bmargin = ex.evalNum()
			ex.p++
			S.tmargin = ex.evalNum()
		}
	case almostEq(w, "si$ze"):
		if ex.isWord("sq$uare") || ex.isWord("nosq$uare") || ex.isWord("ra$tio") || ex.isWord("nora$tio") {
			ex.skipRest()
			return
		}
		if !ex.endOfCmd() {
			S.sizeX = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				S.sizeY = ex.evalNum()
			}
		} else {
			S.sizeX, S.sizeY = 1, 1
		}
	case almostEq(w, "or$igin"):
		S.originX = ex.evalNum()
		if ex.isOp(",") {
			ex.p++
			S.originY = ex.evalNum()
		}
	case almostEq(w, "tics"):
		ex.skipRest()
	case almostEq(w, "ticsl$evel"):
		S.ticsLevel = ex.evalNum()
	case almostEq(w, "xyp$lane"):
		if ex.isWord("at") {
			ex.p++
			S.xyplane = ex.evalNum()
			S.xyplaneRel = false
		} else {
			if ex.isWord("rel$ative") {
				ex.p++
			}
			S.xyplane = ex.evalNum()
			S.xyplaneRel = true
		}
	case almostEq(w, "vi$ew"):
		if ex.isWord("map") {
			ex.p++
			S.view = [4]float64{0, 0, 1, 1}
			return
		}
		for k := 0; k < 4 && !ex.endOfCmd(); k++ {
			if ex.isOp(",") {
				ex.p++
				continue
			}
			S.view[k] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
			}
		}
	case almostEq(w, "hid$den3d"):
		S.hidden3d = true
		ex.skipRest()
	case almostEq(w, "su$rface"):
		S.surface = true
		ex.skipRest()
	case almostEq(w, "cont$ours"):
		S.contour = true
		ex.skipRest()
	case almostEq(w, "poi$ntsize"):
		S.pointsize = ex.evalNum()
	case almostEq(w, "enc$oding"):
		if !ex.endOfCmd() {
			S.encoding = ex.next().Text
		}
	case almostEq(w, "dec$imalsign"):
		ex.skipRest()
	case almostEq(w, "lab$el"):
		ex.setLabel()
	case almostEq(w, "ar$row"):
		ex.setArrow()
	case almostEq(w, "mu$ltiplot"):
		ex.setMultiplot()
	case almostEq(w, "minus$sign"):
		S.minussign = true
	case almostEq(w, "off$sets"):
		for k := 0; k < 4 && !ex.endOfCmd(); k++ {
			S.offsets[k] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
			}
		}
	case almostEq(w, "bar$s"):
		if ex.isWord("sm$all") {
			ex.p++
			S.bars = 0
		} else if ex.isWord("la$rge") {
			ex.p++
			S.bars = -1
		} else if !ex.endOfCmd() {
			S.bars = ex.evalNum()
		} else {
			S.bars = 1
		}
		ex.skipRest()
	case almostEq(w, "auto$scale"):
		if ex.endOfCmd() {
			for _, a := range S.axes {
				a.autoMin, a.autoMax = true, true
			}
			return
		}
		s := ex.next().Text
		for _, a := range []string{"x2", "y2", "x", "y", "z", "cb"} {
			if strings.HasPrefix(s, a) {
				suf := s[len(a):]
				switch suf {
				case "", "fix":
					S.axes[a].autoMin, S.axes[a].autoMax = true, true
				case "min", "fixmin":
					S.axes[a].autoMin = true
				case "max", "fixmax":
					S.axes[a].autoMax = true
				}
				break
			}
		}
	case almostEq(w, "colorb$ox"):
		S.colorbox = true
		ex.skipRest()
	case almostEq(w, "pm3d"):
		S.pm3d = true
		ex.skipRest()
	case almostEq(w, "loadp$ath"), almostEq(w, "fontp$ath"), almostEq(w, "pal$ette"), almostEq(w, "obj$ect"), almostEq(w, "linet$ype"), almostEq(w, "tim$estamp"), almostEq(w, "mo$use"), almostEq(w, "termopt$ion"), almostEq(w, "jitter"), almostEq(w, "cl$ip"), almostEq(w, "cntrp$aram"), almostEq(w, "cntrl$abel"), almostEq(w, "map$ping"), almostEq(w, "histo$ry"), almostEq(w, "loc$ale"), almostEq(w, "psdir"), almostEq(w, "rgbmax"), almostEq(w, "theta"), almostEq(w, "walls"), almostEq(w, "dg$rid3d"), almostEq(w, "overflow"), almostEq(w, "micro"), almostEq(w, "sp$iderplot"), almostEq(w, "para$xis"), almostEq(w, "link"), almostEq(w, "nonlinear"), almostEq(w, "rr$ange"), almostEq(w, "vr$ange"), almostEq(w, "ur$ange"), almostEq(w, "isosurf$ace"), almostEq(w, "errorbars"), almostEq(w, "a$utoscale"), almostEq(w, "view"), almostEq(w, "pixmap"), almostEq(w, "debug"), almostEq(w, "c$olorsequence"), almostEq(w, "fontp$ath"), almostEq(w, "tr$ange"):
		ex.skipRest()
	case strings.HasPrefix(w, "no"):
		ex.p--
		ex.toks[ex.p].Text = w[2:]
		ex.cmdUnsetWord(w[2:])
	default:
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

func (ex *Exec) marginVal() float64 {
	if ex.endOfCmd() {
		return -1
	}
	if ex.isWord("at") {
		ex.p++
		if ex.isWord("sc$reen") {
			ex.p++
		}
	}
	return ex.evalNum()
}

func parseAxesList(s string) []string {
	var out []string
	for len(s) > 0 {
		switch {
		case strings.HasPrefix(s, "x2"):
			out = append(out, "x2")
			s = s[2:]
		case strings.HasPrefix(s, "y2"):
			out = append(out, "y2")
			s = s[2:]
		case strings.HasPrefix(s, "cb"):
			out = append(out, "cb")
			s = s[2:]
		case s[0] == 'x' || s[0] == 'y' || s[0] == 'z' || s[0] == 'r':
			out = append(out, s[:1])
			s = s[1:]
		default:
			s = s[1:]
		}
	}
	return out
}

func (ex *Exec) parseRangeSet(ax *Axis) {
	if ex.isWord("rest$ore") {
		ex.p++
		return
	}
	if ex.isOp("[") {
		ex.parseRange(ax)
	}
	for !ex.endOfCmd() {
		if ex.isWord("rev$erse") {
			ax.reverse = true
		} else if ex.isWord("norev$erse") {
			ax.reverse = false
		} else if ex.isWord("wr$iteback") {
			ax.writeback = true
		} else if ex.isWord("nowri$teback") {
			ax.writeback = false
		} else if ex.isWord("ext$end") || ex.isWord("noext$end") {
		} else {
			gpErr(ex.peek().Pos, "unrecognized option")
		}
		ex.p++
	}
}

func (ex *Exec) parseTextOpts(off *[2]float64, font *string) {
	for !ex.endOfCmd() {
		if ex.isWord("off$set") {
			ex.p++
			if ex.isWord("char$acter") || ex.isWord("gr$aph") || ex.isWord("sc$reen") || ex.isWord("fir$st") {
				ex.p++
			}
			off[0] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				off[1] = ex.evalNum()
			}
			continue
		}
		if ex.isWord("font") && font != nil {
			ex.p++
			*font = ex.evalString()
			continue
		}
		ex.p++
	}
}

func (ex *Exec) parseTics(ax *Axis) {
	ax.ticsOn = true
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("mi$rror"):
			ax.mirror = true
			ex.p++
		case ex.isWord("nomi$rror"):
			ax.mirror = false
			ex.p++
		case ex.isWord("in$side") || ex.isWord("o$ut") || ex.isWord("bo$rder") || ex.isWord("ax$is") || ex.isWord("nor$otate") || ex.isWord("rangel$imited") || ex.isWord("autoj$ustify") || ex.isWord("front") || ex.isWord("back") || ex.isWord("enh$anced") || ex.isWord("noenh$anced") || ex.isWord("left") || ex.isWord("right") || ex.isWord("center") || ex.isWord("centre"):
			ex.p++
		case ex.isWord("sc$ale"):
			ex.p++
			ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				ex.evalNum()
			}
		case ex.isWord("rot$ate"):
			ex.p++
			ax.rotate = true
			if ex.isWord("by") {
				ex.p++
				ex.evalNum()
			}
		case ex.isWord("off$set"):
			var o [2]float64
			ex.p++
			o[0] = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				ex.evalNum()
			}
		case ex.isWord("format"):
			ex.p++
			ax.format = ex.evalString()
		case ex.isWord("font") || ex.isWord("tc") || ex.isWord("textc$olor"):
			ex.p++
			ex.evalExpr()
		case ex.isWord("add"):
			ex.p++
			ax.ticAdd = true
		case ex.isWord("auto$freq"):
			ex.p++
			ax.ticStep = 0
			ax.ticList = nil
		case ex.isOp("("):
			ex.p++
			if !ax.ticAdd {
				ax.ticList = nil
			}
			ax.ticStep = -1
			for !ex.isOp(")") {
				var lab string
				hasLab := false
				if ex.peek().Kind == TSTR {
					lab = ex.next().Text
					hasLab = true
				}
				pos := ex.evalNum()
				lvl := 0
				if !ex.isOp(",") && !ex.isOp(")") {
					lvl = int(toInt(ex.evalExpr()))
				}
				if !hasLab {
					lab = "\x00"
				}
				ax.ticList = append(ax.ticList, ticEntry{lab, pos, lvl})
				if ex.isOp(",") {
					ex.p++
				}
			}
			ex.p++
			ax.ticAdd = false
		default:
			// start, incr, end
			a := ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				b := ex.evalNum()
				ax.ticStart = a
				ax.ticStep = b
				ax.ticStartSet = true
				ax.ticEndSet = false
				if ex.isOp(",") {
					ex.p++
					ax.ticEnd = ex.evalNum()
					ax.ticEndSet = true
				}
			} else {
				ax.ticStep = a
				ax.ticStartSet = false
				ax.ticEndSet = false
			}
			if !ax.ticAdd {
				ax.ticList = nil
			}
		}
	}
}

func (ex *Exec) parseKey() {
	S.keyOn = true
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("on"):
			S.keyOn = true
		case ex.isWord("off"):
			S.keyOn = false
		case ex.isWord("t$op"):
			S.keyVert = "top"
		case ex.isWord("b$ottom"):
			S.keyVert = "bottom"
		case ex.isWord("l$eft"):
			S.keyHoriz = "left"
		case ex.isWord("r$ight"):
			S.keyHoriz = "right"
		case ex.isWord("c$enter") || ex.isWord("cent$re"):
			if S.keyHoriz == "center" {
				S.keyVert = "center"
			}
			S.keyHoriz = "center"
			S.keyVert = "center"
		case ex.isWord("bo$x"):
			S.keyBox = true
		case ex.isWord("nobo$x"):
			S.keyBox = false
		case ex.isWord("rev$erse"):
			S.keyReverse = true
		case ex.isWord("norev$erse"):
			S.keyReverse = false
		case ex.isWord("inv$ert"):
			S.keyInvert = true
		case ex.isWord("noinv$ert"):
			S.keyInvert = false
		case ex.isWord("Left"):
			S.keyJustLeft = true
		case ex.isWord("Right"):
			S.keyJustLeft = false
		case ex.isWord("out$side"):
			S.keyOutside = true
		case ex.isWord("in$side"):
			S.keyOutside = false
		case ex.isWord("bel$ow"):
			S.keyBelow = true
		case ex.isWord("abo$ve") || ex.isWord("ov$er"):
			S.keyAbove = true
		case ex.isWord("hor$izontal"):
			S.keyHorizontal = true
		case ex.isWord("ver$tical"):
			S.keyHorizontal = false
		case ex.isWord("samp$len"):
			ex.p++
			S.keySampLen = ex.evalNum()
			continue
		case ex.isWord("spac$ing"):
			ex.p++
			S.keySpacing = ex.evalNum()
			continue
		case ex.isWord("w$idth"):
			ex.p++
			S.keyWidth = ex.evalNum()
			continue
		case ex.isWord("h$eight"):
			ex.p++
			S.keyHeight = ex.evalNum()
			continue
		case ex.isWord("tit$le"):
			ex.p++
			if !ex.endOfCmd() && ex.peek().Kind == TSTR {
				S.keyTitle = ex.evalString()
			}
			continue
		case ex.isWord("noaut$otitles"):
			S.keyNoAuto = true
		case ex.isWord("aut$otitles"):
			S.keyNoAuto = false
		case ex.isWord("at"):
			ex.p++
			ex.evalNum()
			ex.p++
			ex.evalNum()
			continue
		case ex.isWord("font") || ex.isWord("tc") || ex.isWord("textc$olor") || ex.isWord("maxc$olumns") || ex.isWord("maxr$ows") || ex.isWord("lt") || ex.isWord("lc") || ex.isWord("lw") || ex.isWord("linet$ype") || ex.isWord("linew$idth"):
			ex.p++
			if !ex.endOfCmd() {
				ex.evalExpr()
			}
			continue
		}
		ex.p++
	}
}

func setOutput(name string) {
	if outW != nil {
		finishTerminal()
		outW.Flush()
		outFile.Close()
		outW = nil
		outFile = nil
	}
	S.output = name
	if name != "" {
		f, err := os.Create(name)
		if err != nil {
			gpErr(-1, "cannot open file; output not changed")
		}
		outFile = f
		outW = bufio.NewWriter(f)
	}
}

func (ex *Exec) setTerminal() {
	if ex.endOfCmd() {
		return
	}
	t := ex.next()
	name := t.Text
	switch {
	case almostEq(name, "du$mb"):
		finishTerminal()
		S.termName = "dumb"
		S.termFeed = true
		for !ex.endOfCmd() {
			if ex.isWord("si$ze") {
				ex.p++
				S.termW = int(toInt(ex.evalExpr()))
				if ex.isOp(",") {
					ex.p++
					S.termH = int(toInt(ex.evalExpr()))
				}
				continue
			}
			if ex.isWord("nofe$ed") {
				S.termFeed = false
			} else if ex.isWord("fe$ed") {
				S.termFeed = true
			} else if ex.peek().Kind == TNUM {
				S.termW = int(toInt(ex.evalExpr()))
				if ex.isOp(",") {
					ex.p++
					S.termH = int(toInt(ex.evalExpr()))
				}
				continue
			}
			ex.p++
		}
	case almostEq(name, "svg"):
		finishTerminal()
		S.termName = "svg"
		S.termW, S.termH = 600, 480
		ex.parseSizeOpts()
	case almostEq(name, "canvas"):
		finishTerminal()
		S.termName = "canvas"
		S.termW, S.termH = 600, 400
		ex.parseSizeOpts()
	case almostEq(name, "unknown"):
		S.termName = "unknown"
	case almostEq(name, "push"), almostEq(name, "pop"):
	case almostEq(name, "table"):
		S.termName = "table"
	default:
		gpErr(t.Pos, "unknown or ambiguous terminal type; type just 'set terminal' for a list")
	}
	vars["GPVAL_TERM"] = StrV(S.termName)
}

func (ex *Exec) parseSizeOpts() {
	for !ex.endOfCmd() {
		if ex.isWord("si$ze") {
			ex.p++
			S.termW = int(ex.evalNum())
			if ex.isOp(",") {
				ex.p++
				S.termH = int(ex.evalNum())
			}
			continue
		}
		ex.p++
	}
}

func (ex *Exec) setDatafile() {
	if ex.isWord("sep$arators") {
		ex.p++
		if ex.endOfCmd() || ex.isWord("white$space") {
			S.datafileSep = ""
			if !ex.endOfCmd() {
				ex.p++
			}
			return
		}
		if ex.isWord("comma") {
			ex.p++
			S.datafileSep = ","
			return
		}
		if ex.isWord("tab") {
			ex.p++
			S.datafileSep = "\t"
			return
		}
		S.datafileSep = ex.evalString()
		return
	}
	if ex.isWord("mis$sing") {
		ex.p++
		if ex.endOfCmd() {
			S.datafileMissing = ""
			return
		}
		S.datafileMissing = ex.evalString()
		return
	}
	if ex.isWord("com$mentschars") {
		ex.p++
		if ex.endOfCmd() {
			S.datafileComments = "#"
			return
		}
		S.datafileComments = ex.evalString()
		return
	}
	ex.skipRest()
}

func (ex *Exec) setStyle() {
	if ex.isWord("d$ata") {
		ex.p++
		S.styleData = ex.parseStyleName()
		ex.skipRest()
		return
	}
	if ex.isWord("f$unction") {
		ex.p++
		S.styleFunc = ex.parseStyleName()
		ex.skipRest()
		return
	}
	if ex.isWord("l$ine") {
		ex.p++
		tag := int(toInt(ex.evalExpr()))
		ls := S.lineStyles[tag]
		ls.set = true
		for !ex.endOfCmd() {
			switch {
			case ex.isWord("lt") || ex.isWord("linet$ype") || ex.isWord("lc") || ex.isWord("linec$olor"):
				ex.p++
				if ex.isWord("rgb") {
					ex.p++
					ex.evalExpr()
					continue
				}
				if ex.peek().Kind == TNUM {
					ls.lt = int(toInt(ex.evalExpr()))
				} else {
					ex.p++
				}
			case ex.isWord("pt") || ex.isWord("pointt$ype"):
				ex.p++
				ls.pt = int(toInt(ex.evalExpr()))
			case ex.isWord("lw") || ex.isWord("linew$idth") || ex.isWord("ps") || ex.isWord("points$ize") || ex.isWord("dt") || ex.isWord("dasht$ype"):
				ex.p++
				ex.evalExpr()
			default:
				ex.p++
			}
		}
		S.lineStyles[tag] = ls
		return
	}
	if ex.isWord("fill") || ex.isWord("fs") {
		ex.p++
		var parts []string
		for !ex.endOfCmd() {
			parts = append(parts, ex.next().Text)
		}
		S.fillStyle = strings.Join(parts, " ")
		return
	}
	if ex.isWord("hist$ogram") {
		ex.p++
		ex.skipRest()
		return
	}
	ex.skipRest()
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "i$mpulses", "d$ots", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "yerr$orbars", "xerr$orbars", "xyerr$orbars", "errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "boxes", "boxer$rorbars", "boxxy$errorbars", "vec$tors", "fin$ancebars", "candle$sticks", "filledc$urves", "lab$els", "histog$rams", "imag$e", "rgbim$age", "pm3d", "fill$steps", "circ$les", "ell$ipses", "boxp$lot", "zerror$fill", "table", "parallel$axes", "sur$face", "arr$ows", "rgba$lpha", "isosurface", "polygons", "spiderplot", "mask", "lp"}

func (ex *Exec) parseStyleName() string {
	t := ex.peek()
	for _, sn := range styleNames {
		if t.Kind == TNAME && almostEq(t.Text, sn) {
			ex.p++
			full := strings.Replace(sn, "$", "", 1)
			if full == "errorbars" {
				full = "yerrorbars"
			}
			if full == "errorlines" {
				full = "yerrorlines"
			}
			if full == "lp" {
				full = "linespoints"
			}
			return full
		}
	}
	gpErr(t.Pos, "unrecognized plot type")
	return ""
}

func (ex *Exec) setFit() {
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("log$file"):
			ex.p++
			if !ex.endOfCmd() && ex.peek().Kind == TSTR {
				S.fitLog = ex.evalString()
			}
			S.fitNoLog = false
			continue
		case ex.isWord("nolog$file"):
			S.fitNoLog = true
		case ex.isWord("q$uiet"):
			S.fitQuiet = true
			S.fitBrief, S.fitVerbose = false, false
		case ex.isWord("b$rief"):
			S.fitBrief = true
			S.fitQuiet, S.fitVerbose = false, false
		case ex.isWord("v$erbose"):
			S.fitVerbose = true
			S.fitQuiet, S.fitBrief = false, false
		case ex.isWord("noq$uiet"):
			S.fitQuiet = false
		case ex.isWord("err$orvariables"):
			S.fitErrVars = true
		case ex.isWord("noerr$orvariables"):
			S.fitErrVars = false
		case ex.isWord("cov$ariancevariables"):
			S.fitCovVars = true
		case ex.isWord("nocov$ariancevariables"):
			S.fitCovVars = false
		case ex.isWord("pre$scale"):
			S.fitPrescale = true
		case ex.isWord("nopre$scale"):
			S.fitPrescale = false
		case ex.isWord("lim$it"):
			ex.p++
			S.fitLimit = ex.evalNum()
			continue
		case ex.isWord("maxit$er"):
			ex.p++
			S.fitMaxIter = int(toInt(ex.evalExpr()))
			continue
		case ex.isWord("start$-lambda"):
			ex.p++
			S.fitStartLambda = ex.evalNum()
			continue
		case ex.isWord("lambda$-factor"):
			ex.p++
			S.fitLambdaFactor = ex.evalNum()
			continue
		case ex.isWord("v4"):
			S.fitV4 = true
		case ex.isWord("v5"):
			S.fitV4 = false
		}
		ex.p++
	}
}

func (ex *Exec) setLabel() {
	tag := 0
	if ex.peek().Kind == TNUM {
		tag = int(toInt(ex.evalExpr()))
	}
	lbl := textLabel{tag: tag, just: "left"}
	if !ex.endOfCmd() && !ex.isWord("at") {
		v := ex.evalExpr()
		lbl.text = toStr(v)
	}
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("at"):
			ex.p++
			lbl.coord = "first"
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") || ex.isWord("char$acter") {
				lbl.coord = ex.next().Text
			}
			lbl.x = ex.evalNum()
			ex.p++
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") || ex.isWord("char$acter") {
				ex.p++
			}
			lbl.y = ex.evalNum()
			if ex.isOp(",") {
				ex.p++
				ex.evalNum()
			}
			continue
		case ex.isWord("l$eft"):
			lbl.just = "left"
		case ex.isWord("r$ight"):
			lbl.just = "right"
		case ex.isWord("c$enter") || ex.isWord("cent$re"):
			lbl.just = "center"
		case ex.isWord("front"):
			lbl.front = true
		}
		ex.p++
	}
	if tag == 0 {
		mx := 0
		for _, l := range S.labels {
			if l.tag > mx {
				mx = l.tag
			}
		}
		lbl.tag = mx + 1
	}
	for i, l := range S.labels {
		if l.tag == lbl.tag {
			S.labels[i] = lbl
			return
		}
	}
	S.labels = append(S.labels, lbl)
	sort.Slice(S.labels, func(i, j int) bool { return S.labels[i].tag < S.labels[j].tag })
}

func (ex *Exec) setArrow() {
	tag := 0
	if ex.peek().Kind == TNUM {
		tag = int(toInt(ex.evalExpr()))
	}
	a := arrowSpec{tag: tag}
	for !ex.endOfCmd() {
		switch {
		case ex.isWord("from"):
			ex.p++
			a.coord1 = "first"
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") {
				a.coord1 = ex.next().Text
			}
			a.x1 = ex.evalNum()
			ex.p++
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") {
				ex.p++
			}
			a.y1 = ex.evalNum()
			continue
		case ex.isWord("to") || ex.isWord("rto"):
			a.rel = ex.isWord("rto")
			ex.p++
			a.coord2 = "first"
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") {
				a.coord2 = ex.next().Text
			}
			a.x2 = ex.evalNum()
			ex.p++
			if ex.isWord("fir$st") || ex.isWord("gr$aph") || ex.isWord("sc$reen") {
				ex.p++
			}
			a.y2 = ex.evalNum()
			continue
		case ex.isWord("noh$ead"):
			a.nohead = true
		case ex.isWord("heads"):
			a.heads = true
		}
		ex.p++
	}
	if tag == 0 {
		a.tag = len(S.arrows) + 1
	}
	S.arrows = append(S.arrows, a)
}

func (ex *Exec) setMultiplot() {
	S.multiplot = true
	S.mpLayout = [2]int{0, 0}
	S.mpIndex = 0
	mpTitle = ""
	for !ex.endOfCmd() {
		if ex.isWord("lay$out") {
			ex.p++
			S.mpLayout[0] = int(toInt(ex.evalExpr()))
			ex.p++
			S.mpLayout[1] = int(toInt(ex.evalExpr()))
			continue
		}
		if ex.isWord("tit$le") {
			ex.p++
			mpTitle = ex.evalString()
			continue
		}
		ex.p++
	}
	beginMultiplot()
}

var mpTitle string

func (ex *Exec) cmdUnset() {
	t := ex.peek()
	if t.Kind != TNAME {
		gpErr(t.Pos, "unrecognized option - see 'help unset'.")
	}
	ex.p++
	ex.cmdUnsetWord(t.Text)
}

func (ex *Exec) cmdUnsetWord(w string) {
	for _, a := range []string{"x2", "y2", "x", "y", "z", "cb", "r", "t", "u", "v"} {
		if strings.HasPrefix(w, a) {
			rest := w[len(a):]
			ax := S.axes[a]
			switch rest {
			case "tics":
				ax.ticsOn = false
				return
			case "label":
				ax.label = ""
				return
			case "range":
				return
			case "mtics":
				ax.minor = 0
				return
			case "zeroaxis":
				ax.zeroaxis = false
				return
			case "data":
				ax.isTime = false
				return
			}
		}
	}
	switch {
	case almostEq(w, "k$ey"):
		S.keyOn = false
	case almostEq(w, "tit$le"):
		S.title = ""
	case almostEq(w, "log$scale"):
		axl := []string{"x", "y", "z", "cb", "x2", "y2"}
		if !ex.endOfCmd() {
			axl = parseAxesList(ex.next().Text)
		}
		for _, a := range axl {
			S.axes[a].log = false
		}
	case almostEq(w, "tab$le"):
		endTable()
	case almostEq(w, "g$rid"):
		S.grid = false
	case almostEq(w, "bor$der"):
		S.border = 0
	case almostEq(w, "par$ametric"):
		S.parametric = false
		S.dummy1 = "x"
	case almostEq(w, "pol$ar"):
		S.polar = false
	case almostEq(w, "tics"):
		for _, a := range S.axes {
			a.ticsOn = false
		}
	case almostEq(w, "o$utput"):
		setOutput("")
	case almostEq(w, "pr$int"):
		if printFile != nil {
			printFile.Flush()
			printFileH.Close()
			printFile = nil
		}
		printToStdout = false
		printName = "<stderr>"
	case almostEq(w, "mu$ltiplot"):
		endMultiplot()
	case almostEq(w, "lab$el"):
		if ex.endOfCmd() {
			S.labels = nil
		} else {
			tag := int(toInt(ex.evalExpr()))
			for i, l := range S.labels {
				if l.tag == tag {
					S.labels = append(S.labels[:i], S.labels[i+1:]...)
					break
				}
			}
		}
	case almostEq(w, "ar$row"):
		S.arrows = nil
		ex.skipRest()
	case almostEq(w, "hid$den3d"):
		S.hidden3d = false
	case almostEq(w, "su$rface"):
		S.surface = false
	case almostEq(w, "cont$ours"):
		S.contour = false
	case almostEq(w, "colorb$ox"):
		S.colorbox = false
	case almostEq(w, "pm3d"):
		S.pm3d = false
	case almostEq(w, "minus$sign"):
		S.minussign = false
	case almostEq(w, "auto$scale"):
		ex.skipRest()
	case almostEq(w, "da$tafile"):
		S.datafileSep = ""
		S.datafileMissing = ""
		ex.skipRest()
	case almostEq(w, "form$at"):
		for _, a := range S.axes {
			a.format = "% h"
		}
		ex.skipRest()
	default:
		ex.skipRest()
	}
}

// ---------------- show ------------------

func showRange(ax *Axis) string {
	f := func(v float64, auto bool) string {
		if auto {
			return "*"
		}
		if ax.isTime {
			return "\"" + gpStrftime(S.timefmt, v) + "\""
		}
		return fmt.Sprintf("%g", v)
	}
	_ = f
	var sb strings.Builder
	lo, hi := "*", "*"
	if !ax.autoMin {
		lo = fmtFloatC(fspec{conv: 'f', prec: 5, flags: "", width: 0}, ax.min)
		lo = cfmtg(ax.min)
	}
	if !ax.autoMax {
		hi = cfmtg(ax.max)
	}
	rev := "noreverse"
	if ax.reverse {
		rev = "reverse"
	}
	wb := "nowriteback"
	if ax.writeback {
		wb = "writeback"
	}
	sb.WriteString(fmt.Sprintf("\tset %srange [ %s : %s ] %s %s", ax.name, lo, hi, rev, wb))
	if ax.autoMin || ax.autoMax {
		cmin, cmax := ax.min, ax.max
		sb.WriteString(fmt.Sprintf("  # (currently [%s:%s] )", cfmtg(cmin), cfmtg(cmax)))
	}
	sb.WriteString("\n")
	return sb.String()
}

func cfmtg(v float64) string {
	return fmtFloatC(fspec{conv: 'g', prec: -1}, v)
}

func (ex *Exec) cmdShow() {
	t := ex.peek()
	if t.Kind != TNAME {
		gpErr(t.Pos, "unrecognized option - see 'help show'.")
	}
	ex.p++
	w := t.Text
	out := stderr
	for _, a := range []string{"x2", "y2", "x", "y", "z", "cb", "r", "t", "u", "v"} {
		if w == a+"range" {
			out.WriteString("\n" + showRangeFmt(S.axes[a]) + "\n")
			return
		}
		if w == a+"label" {
			ax := S.axes[a]
			out.WriteString(fmt.Sprintf("\n\t%slabel is \"%s\", offset at (character %s, %s, 0)center justified  textcolor lt -1\n\n", a, ax.label, cfmtg(ax.labelOffset[0]), cfmtg(ax.labelOffset[1])))
			return
		}
	}
	switch {
	case almostEq(w, "sa$mples"):
		out.WriteString(fmt.Sprintf("\n\tsampling rate is %d, %d\n\n", S.samples1, S.samples2))
	case almostEq(w, "isosam$ples"):
		out.WriteString(fmt.Sprintf("\n\tiso sampling rate is %d, %d\n\n", S.iso1, S.iso2))
	case almostEq(w, "tit$le"):
		font := ""
		if S.titleFont != "" {
			font = ", using font \"" + S.titleFont + "\""
		}
		out.WriteString(fmt.Sprintf("\n\ttitle is \"%s\", offset at (character %s, %s, 0)center justified %s textcolor lt -1\n\n", S.title, cfmtg(S.titleOffset[0]), cfmtg(S.titleOffset[1]), font))
	case almostEq(w, "an$gles"):
		if S.angleDeg {
			out.WriteString("\n\tAngles are in degrees\n\n")
		} else {
			out.WriteString("\n\tAngles are in radians\n\n")
		}
	case almostEq(w, "o$utput"):
		if S.output == "" {
			out.WriteString("\n\toutput is sent to STDOUT\n\n")
		} else {
			out.WriteString("\n\toutput is sent to '" + S.output + "'\n\n")
		}
	case almostEq(w, "print"):
		out.WriteString("\n\tprint output is sent to '" + printName + "'\n\n")
	case almostEq(w, "t$erminal"):
		switch S.termName {
		case "dumb":
			feed := "feed"
			if !S.termFeed {
				feed = "nofeed"
			}
			out.WriteString(fmt.Sprintf("\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", feed, S.termW, S.termH))
		default:
			out.WriteString("\n   terminal type is " + S.termName + " " + "\n\n")
		}
	case almostEq(w, "z$ero"):
		out.WriteString(fmt.Sprintf("\n\tzero is %s\n\n", cfmtg(S.zero)))
	case almostEq(w, "du$mmy"):
		out.WriteString(fmt.Sprintf("\n\tdummy variables are %s %s \n\n", S.dummy1, S.dummy2))
	case almostEq(w, "par$ametric"):
		if S.parametric {
			out.WriteString("\n\tparametric is ON\n\n")
		} else {
			out.WriteString("\n\tparametric is OFF\n\n")
		}
	case almostEq(w, "pol$ar"):
		if S.polar {
			out.WriteString("\n\tpolar is ON\n\n")
		} else {
			out.WriteString("\n\tpolar is OFF\n\n")
		}
	case almostEq(w, "tab$le"):
		if S.tableOn {
			out.WriteString("\n\ttable mode is on\n\n")
		} else {
			out.WriteString("\n\ttable mode is off\n\n")
		}
	case almostEq(w, "g$rid"):
		if !S.grid {
			out.WriteString("\n\tgrid is OFF\n\n")
		} else {
			out.WriteString("\n\tgrid is ON\n\n")
		}
	case almostEq(w, "timef$mt"):
		out.WriteString("\n\tDefault format for reading time data is \"" + S.timefmt + "\"\n\n")
	case almostEq(w, "form$at"):
		out.WriteString("\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			out.WriteString(fmt.Sprintf("\t  %s-axis: \"%s\"\n", a, S.axes[a].format))
		}
		out.WriteString("\n")
	case almostEq(w, "log$scale"):
		var parts []string
		for _, a := range []string{"x", "y", "z", "x2", "y2", "cb", "r"} {
			ax := S.axes[a]
			if ax.log {
				parts = append(parts, fmt.Sprintf("%s (base %s)", a, cfmtg(ax.logBase)))
			}
		}
		if len(parts) == 0 {
			out.WriteString("\n\tlogscaling on none\n\n")
		} else {
			out.WriteString("\n\tlogscaling on " + strings.Join(parts, ", ") + "\n\n")
		}
	case almostEq(w, "st$yle"):
		if ex.isWord("d$ata") {
			ex.p++
			out.WriteString("\n\tData are plotted with " + S.styleData + "\n\n")
			return
		}
		if ex.isWord("f$unction") {
			ex.p++
			out.WriteString("\n\tFunctions are plotted with " + S.styleFunc + "\n\n")
			return
		}
		ex.skipRest()
		out.WriteString("\tData are plotted with " + S.styleData + "\n\tFunctions are plotted with " + S.styleFunc + "\n")
	case almostEq(w, "v$ariables"):
		all := false
		if ex.isWord("all") {
			ex.p++
			all = true
		}
		showVariables(out, all)
	case almostEq(w, "fu$nctions"):
		out.WriteString("\n\tUser-Defined Functions:\n")
		names := make([]string, 0)
		for k := range udfs {
			names = append(names, k)
		}
		for _, k := range udfOrder {
			if _, ok := udfs[k]; ok {
				out.WriteString("\t" + udfs[k].Text + "\n")
			}
		}
		_ = names
		out.WriteString("\n")
	case almostEq(w, "ver$sion"):
		out.WriteString("\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		ex.skipRest()
	case almostEq(w, "bor$der"):
		if S.border == 0 {
			out.WriteString("\n\tborder is not drawn\n\n")
		} else {
			out.WriteString(fmt.Sprintf("\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.border, S.border))
		}
	case almostEq(w, "k$ey"):
		showKey(out)
	case almostEq(w, "si$ze"):
		out.WriteString(fmt.Sprintf("\n\tsize is scaled by %s,%s\n\tNo attempt to control aspect ratio\n\n", cfmtg(S.sizeX), cfmtg(S.sizeY)))
	case almostEq(w, "or$igin"):
		out.WriteString(fmt.Sprintf("\n\torigin is set to %s,%s\n\n", cfmtg(S.originX), cfmtg(S.originY)))
	case almostEq(w, "da$tafile"):
		var sb strings.Builder
		sb.WriteString("\n")
		if S.datafileMissing == "" {
			sb.WriteString("\tNo missing data string set for datafile\n")
		} else {
			sb.WriteString("\t\"" + S.datafileMissing + "\" in datafile is interpreted as missing value\n")
		}
		if S.datafileSep == "" {
			sb.WriteString("\tdatafile fields separated by whitespace\n")
		} else {
			sb.WriteString("\tdatafile fields separated by \"" + S.datafileSep + "\"\n")
		}
		sb.WriteString("\tComments chars are \"" + S.datafileComments + "\"\n")
		sb.WriteString("\tFirst line is treated as headers only if accessed explicitly\n\n")
		out.WriteString(sb.String())
	case almostEq(w, "xd$ata") || almostEq(w, "yd$ata"):
		a := w[:1]
		if S.axes[a].isTime {
			out.WriteString("\n\t" + a + " is set to time\n\n")
		} else {
			out.WriteString("\n\t" + a + " is set to numerical\n\n")
		}
	case almostEq(w, "box$width"):
		if S.boxwidth < 0 {
			out.WriteString("\n\tboxwidth is auto\n\n")
		} else if S.boxwidthRel {
			out.WriteString(fmt.Sprintf("\n\tboxwidth is %s relative\n\n", cfmtg(S.boxwidth)))
		} else {
			out.WriteString(fmt.Sprintf("\n\tboxwidth is %s absolute\n\n", cfmtg(S.boxwidth)))
		}
	case almostEq(w, "off$sets"):
		out.WriteString(fmt.Sprintf("\n\toffsets are %s, %s, %s, %s\n\n", cfmtg(S.offsets[0]), cfmtg(S.offsets[1]), cfmtg(S.offsets[2]), cfmtg(S.offsets[3])))
	case almostEq(w, "enc$oding"):
		out.WriteString("\n\tnominal character encoding is " + S.encoding + "\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case almostEq(w, "fit"):
		showFit(out)
	case almostEq(w, "lab$el"):
		out.WriteString("\n")
		for _, l := range S.labels {
			out.WriteString(fmt.Sprintf("\tlabel %d \"%s\" at %s %s, %s %s, 0 %s not rotated back lt black norotate\n", l.tag, l.text, "", cfmtg(l.x), "", cfmtg(l.y), l.just))
		}
		out.WriteString("\n")
	default:
		ex.skipRest()
	}
}

var udfOrder []string

func showRangeFmt(ax *Axis) string {
	lo, hi := "*", "*"
	if !ax.autoMin {
		lo = fmtFloatC(fspec{conv: 'g', prec: 6}, ax.min)
		lo = fmt.Sprintf("%.5f", ax.min)
		lo = fmtFloatC(fspec{conv: 'f', prec: 5}, ax.min)
	}
	if !ax.autoMax {
		hi = fmtFloatC(fspec{conv: 'f', prec: 5}, ax.max)
	}
	rev := "noreverse"
	if ax.reverse {
		rev = "reverse"
	}
	wb := "nowriteback"
	if ax.writeback {
		wb = "writeback"
	}
	s := fmt.Sprintf("\tset %srange [ %s : %s ] %s %s", ax.name, lo, hi, rev, wb)
	if ax.autoMin || ax.autoMax {
		s += fmt.Sprintf("  # (currently [%s:%s] )", fmtFloatC(fspec{conv: 'f', prec: 4}, ax.min), fmtFloatC(fspec{conv: 'f', prec: 4}, ax.max))
	}
	return s + "\n"
}

func showKey(out *bufio.Writer) {
	if !S.keyOn {
		out.WriteString("\n\tkey is OFF\n\n")
		return
	}
	pos := S.keyVert + " " + S.keyHoriz
	if S.keyHoriz == "center" && S.keyVert == "center" {
		pos = "center"
	}
	inside := ""
	if S.keyOutside {
		inside = " outside"
	}
	_ = inside
	just := "right"
	if S.keyJustLeft {
		just = "left"
	}
	rev := "not reversed"
	if S.keyReverse {
		rev = "reversed"
	}
	inv := "not inverted"
	if S.keyInvert {
		inv = "inverted"
	}
	box := "not boxed"
	if S.keyBox {
		box = "boxed\n\twith linecolor black linewidth 1.000 dashtype solid"
	}
	orient := "vertical"
	if S.keyHorizontal {
		orient = "horizontal"
	}
	fmt.Fprintf(out, "\n\tkey is ON, position: %s %s fixed  offset: (character 0, 0)\n", pos, orient)
	fmt.Fprintf(out, "\tkey is %s justified, %s, %s, enhanced and %s\n", just, rev, inv, box)
	fmt.Fprintf(out, "\tsample length is %s characters\n", cfmtg(S.keySampLen))
	fmt.Fprintf(out, "\tvertical spacing is %s characters\n", cfmtg(S.keySpacing))
	fmt.Fprintf(out, "\twidth adjustment is %s characters\n", cfmtg(S.keyWidth))
	fmt.Fprintf(out, "\theight adjustment is %s characters\n", cfmtg(S.keyHeight))
	if S.keyNoAuto {
		fmt.Fprintf(out, "\tcurves are not automatically titled\n")
	} else {
		fmt.Fprintf(out, "\tcurves are automatically titled with filename\n")
	}
	fmt.Fprintf(out, "\tmaximum number of columns is calculated automatically\n")
	fmt.Fprintf(out, "\tmaximum number of rows is calculated automatically\n")
	fmt.Fprintf(out, "\n\tkey title is \"%s\" center justified \n\n", S.keyTitle)
}

func showFit(out *bufio.Writer) {
	mode := "brief results to console and log-file"
	if S.fitQuiet {
		mode = "no results to console and log-file"
	}
	if S.fitVerbose {
		mode = "verbose results to console and log-file"
	}
	fmt.Fprintf(out, "\n\tfit will output %s.\n", mode)
	fmt.Fprintf(out, "\tfit can handle up to 12 independent variables\n")
	if S.fitPrescale {
		fmt.Fprintf(out, "\tfit will prescale parameters by their initial values\n")
	} else {
		fmt.Fprintf(out, "\tfit will not prescale parameters by their initial values\n")
	}
	if S.fitErrVars {
		fmt.Fprintf(out, "\tfit will place parameter errors in variables\n")
	} else {
		fmt.Fprintf(out, "\tfit will not place parameter errors in variables\n")
	}
	if S.fitCovVars {
		fmt.Fprintf(out, "\tfit will place covariances in variables\n")
	} else {
		fmt.Fprintf(out, "\tfit will not place covariances in variables\n")
	}
	fmt.Fprintf(out, "\tfit will scale parameter errors with the reduced chi square\n")
	if S.fitNoLog {
		fmt.Fprintf(out, "\tfit will not create a log file\n")
	} else if S.fitLog != "" {
		fmt.Fprintf(out, "\tlog-file for fits was set by the user to \n\t'%s'\n", S.fitLog)
	} else {
		fmt.Fprintf(out, "\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
	}
	fmt.Fprintf(out, "\tfits will be considered to have converged if  delta chisq < chisq * %s\n", cfmtg(S.fitLimit))
	if S.fitMaxIter > 0 {
		fmt.Fprintf(out, "\tfit will stop after a maximum of %d iterations\n", S.fitMaxIter)
	} else {
		fmt.Fprintf(out, "\tfit has no limit in the number of iterations\n")
	}
	fmt.Fprintf(out, "\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n")
	fmt.Fprintf(out, "\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
}

var varOrder []string

func showVariables(out *bufio.Writer, all bool) {
	out.WriteString("\n\tUser and default variables:\n")
	keys := make([]string, 0, len(vars))
	for k := range vars {
		keys = append(keys, k)
	}
	// order: by insertion (approximate: builtin first)
	order := orderedVarNames()
	for _, k := range order {
		v, ok := vars[k]
		if !ok {
			continue
		}
		if !all && (strings.HasPrefix(k, "GPVAL_") || k == "GNUTERM" || strings.HasPrefix(k, "MOUSE_")) {
			continue
		}
		if v.T == VUNDEF {
			continue
		}
		if v.T == VARR {
			out.WriteString(fmt.Sprintf("\t%s = <%d element array>\n", k, len(*v.A)))
		} else if v.T == VSTR {
			out.WriteString(fmt.Sprintf("\t%-*s = \"%s\"\n", 0, k, v.S))
		} else {
			out.WriteString(fmt.Sprintf("\t%s = %s\n", k, valueString(v)))
		}
	}
	_ = keys
	out.WriteString("\n")
}

var varSeen = map[string]bool{}

func orderedVarNames() []string {
	for k := range vars {
		if !varSeen[k] {
			varSeen[k] = true
			varOrder = append(varOrder, k)
		}
	}
	return varOrder
}

func init() {
	varOrder = []string{"pi", "I", "NaN", "VoxelDistance", "GNUTERM"}
	for _, k := range varOrder {
		varSeen[k] = true
	}
	_ = strconv.Itoa
}
