package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strconv"
	"strings"
)

var stdout = bufio.NewWriterSize(os.Stdout, 65536)
var stderr = bufio.NewWriterSize(os.Stderr, 65536)

type exitReq struct{ code int }

// source context for error messages
type Source struct {
	name    string // "" for -e or stdin
	kind    int    // 0 file, 1 -e, 2 stdin
	lines   []string
	idx     int
	lineno  int
	curLine string
	args    []string // for call
}

var srcStack []*Source
var heredocRe = regexp.MustCompile(`^\s*(\$[A-Za-z_][A-Za-z0-9_]*)\s*<<\s*([A-Za-z_][A-Za-z0-9_]*)\s*$`)
var anyError bool

func curSrc() *Source {
	if len(srcStack) == 0 {
		return &Source{kind: 1}
	}
	return srcStack[len(srcStack)-1]
}

func flushAll() {
	stdout.Flush()
	stderr.Flush()
	if printFile != nil {
		printFile.Flush()
	}
}

func main() {
	defer flushAll()
	args := os.Args[1:]
	code := run(args)
	closeOutput()
	flushAll()
	os.Exit(code)
}

func usage() {
	fmt.Fprint(stdout, "Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\n")
}

func run(args []string) (code int) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*exitReq); ok {
				code = e.code
				return
			}
			panic(r)
		}
	}()
	initSettings()
	ranSomething := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			fmt.Fprint(stdout, "gnuplot 5.4 patchlevel 9\n")
			return 0
		case a == "-h" || a == "--help":
			usage()
			fmt.Fprint(stdout, "gnuplot 5.4 patchlevel 9\n")
			return 0
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings":
		case a == "-e":
			if i+1 >= len(args) {
				return 0
			}
			i++
			ranSomething = true
			if !runString(args[i]) {
				return 1
			}
		case a == "-c":
			if i+1 >= len(args) {
				return 0
			}
			ranSomething = true
			file := args[i+1]
			cargs := args[i+2:]
			if !runFileTop(file, cargs) {
				return 1
			}
			return 0
		case a == "-":
			ranSomething = true
			runStdin()
		case strings.HasPrefix(a, "-"):
			fmt.Fprintf(stderr, "unrecognized option %s\n", a)
			return 0
		default:
			ranSomething = true
			if !runFileTop(a, nil) {
				return 1
			}
		}
	}
	if !ranSomething {
		runStdin()
	}
	if anyError {
		return 1
	}
	return 0
}

func runString(s string) bool {
	src := &Source{kind: 1, lines: []string{s}}
	return runSource(src)
}

func runFileTop(name string, cargs []string) bool {
	data, err := os.ReadFile(name)
	if err != nil {
		fmt.Fprintf(stderr, "line 0: Cannot load input from '%s'\n\n", name)
		return false
	}
	src := &Source{kind: 0, name: name, lines: splitLines(string(data)), args: cargs}
	if cargs == nil {
		cargs = []string{}
	}
	setCallArgs(name, cargs)
	return runSource(src)
}

func splitLines(s string) []string {
	l := strings.Split(s, "\n")
	if len(l) > 0 && l[len(l)-1] == "" {
		l = l[:len(l)-1]
	}
	return l
}

func runStdin() {
	data, _ := io.ReadAll(os.Stdin)
	src := &Source{kind: 2, lines: splitLines(string(data))}
	runSource(src)
}

// read next logical line from src; returns false at EOF
func (src *Source) readLogical() (string, bool) {
	if src.idx >= len(src.lines) {
		return "", false
	}
	line := src.lines[src.idx]
	src.idx++
	src.lineno = src.idx
	line = strings.TrimSuffix(line, "\r")
	for strings.HasSuffix(line, "\\") && src.idx < len(src.lines) {
		line = line[:len(line)-1] + strings.TrimSuffix(src.lines[src.idx], "\r")
		src.idx++
		src.lineno = src.idx
	}
	// brace balancing
	for braceDepth(line) > 0 && src.idx < len(src.lines) {
		line = line + "\n" + strings.TrimSuffix(src.lines[src.idx], "\r")
		src.idx++
		src.lineno = src.idx
	}
	return line, true
}

func braceDepth(s string) int {
	d := 0
	var q byte
	for i := 0; i < len(s); i++ {
		c := s[i]
		if q != 0 {
			if c == '\\' && q == '"' {
				i++
				continue
			}
			if c == q {
				q = 0
			}
			continue
		}
		switch c {
		case '"', '\'':
			q = c
		case '#':
			for i < len(s) && s[i] != '\n' {
				i++
			}
		case '{':
			d++
		case '}':
			d--
		}
	}
	return d
}

// returns false if an error terminated the source (non-interactive)
func runSource(src *Source) (ok bool) {
	srcStack = append(srcStack, src)
	defer func() { srcStack = srcStack[:len(srcStack)-1] }()
	for {
		line, more := src.readLogical()
		if !more {
			return true
		}
		if m := heredocRe.FindStringSubmatch(line); m != nil {
			var dl []string
			for src.idx < len(src.lines) {
				l := strings.TrimSuffix(src.lines[src.idx], "\r")
				src.idx++
				src.lineno = src.idx
				if strings.TrimSpace(l) == m[2] {
					break
				}
				dl = append(dl, l)
			}
			datablocks[m[1]] = dl
			continue
		}
		if !execLineCatch(src, line) {
			anyError = true
			if src.kind != 2 {
				return false
			}
		}
	}
}

type abortSource struct{}

func execLineCatch(src *Source, line string) (ok bool) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok2 := r.(*GpError); ok2 {
				reportError(src, e)
				ok = false
				if len(srcStack) > 1 && src.kind != 2 {
					// propagate to enclosing source
				}
				return
			}
			if _, ok2 := r.(*abortSource); ok2 {
				ok = false
				return
			}
			panic(r)
		}
	}()
	src.curLine = line
	execLine(line)
	return true
}

func reportError(src *Source, e *GpError) {
	stdout.Flush()
	if printFile != nil {
		printFile.Flush()
	}
	// find the source to report: innermost
	s := curSrc()
	line := s.curLine
	var sb strings.Builder
	prefix := ""
	if s.kind == 2 {
		prefix = "         "
	}
	if e.Pos >= 0 {
		if s.kind == 2 {
			sb.WriteString("\ngnuplot> " + line + "\n")
		} else {
			sb.WriteString("\n" + line + "\n")
		}
		// caret
		col := e.Pos
		pre := line
		if col > len(pre) {
			col = len(pre)
		}
		// handle multi-line: only the part after last newline before col
		if k := strings.LastIndexByte(pre[:col], '\n'); k >= 0 {
			col = col - k - 1
		}
		var cb strings.Builder
		cb.WriteString(prefix)
		for i := 0; i < col; i++ {
			if line[i] == '\t' {
				cb.WriteByte('\t')
			} else {
				cb.WriteByte(' ')
			}
		}
		cb.WriteString("^\n")
		sb.WriteString(cb.String())
	}
	sb.WriteString(prefix)
	if s.kind == 0 {
		sb.WriteString("\"" + s.name + "\" line " + strconv.Itoa(s.lineno) + ": ")
	} else {
		sb.WriteString("line 0: ")
	}
	sb.WriteString(e.Msg + "\n\n")
	stderr.WriteString(sb.String())
	if exitAfterError {
		panic(&exitReq{1})
	}
	if s != src {
		// error inside nested source: already reported; mark to unwind
	}
}

// ---------------- execution of token streams ----------------

type Exec struct {
	toks []Token
	p    int
	line string
}

func (ex *Exec) peek() Token { return ex.toks[ex.p] }
func (ex *Exec) at(i int) Token {
	if ex.p+i < len(ex.toks) {
		return ex.toks[ex.p+i]
	}
	return ex.toks[len(ex.toks)-1]
}
func (ex *Exec) next() Token {
	t := ex.toks[ex.p]
	if t.Kind != TEND {
		ex.p++
	}
	return t
}
func (ex *Exec) isOp(s string) bool {
	t := ex.toks[ex.p]
	return t.Kind == TOP && t.Text == s
}
func (ex *Exec) isName(s string) bool {
	t := ex.toks[ex.p]
	return t.Kind == TNAME && t.Text == s
}

// abbreviation matching like gnuplot's almost_equals: pattern "rep$lot"
func almostEq(word, pat string) bool {
	k := strings.IndexByte(pat, '$')
	if k < 0 {
		return word == pat
	}
	full := pat[:k] + pat[k+1:]
	if len(word) < k || len(word) > len(full) {
		return false
	}
	return strings.HasPrefix(full, word)
}
func (ex *Exec) isWord(pat string) bool {
	t := ex.toks[ex.p]
	return t.Kind == TNAME && almostEq(t.Text, pat)
}

func (ex *Exec) endOfCmd() bool {
	t := ex.toks[ex.p]
	return t.Kind == TEND || (t.Kind == TOP && t.Text == ";")
}

func (ex *Exec) parseExpr() *Node {
	if ex.endOfCmd() {
		gpErr(ex.peek().Pos, "constant expression required")
	}
	ps := &Parser{toks: ex.toks, p: ex.p}
	n := ps.parseExpr()
	ex.p = ps.p
	return n
}

func (ex *Exec) evalExpr() Value {
	n := ex.parseExpr()
	return evalTop(n)
}

func (ex *Exec) evalNum() float64 {
	v := ex.evalExpr()
	return v.numify().Real()
}

func (ex *Exec) evalString() string {
	v := ex.evalExpr()
	if v.T != VSTR {
		gpErr(-1, "expecting string")
	}
	return v.S
}

func (ex *Exec) expectEnd() {
	if !ex.endOfCmd() {
		t := ex.peek()
		gpErr(t.Pos, "unexpected or unrecognized token: "+ex.line[t.Pos:t.End])
	}
}

var curLine string

func execLine(line string) {
	line = expandMacros(line)
	curSrc().curLine = line
	toks := tokenize(line)
	ex := &Exec{toks: toks, line: line}
	ex.run()
}

func (ex *Exec) run() {
	for {
		for ex.isOp(";") {
			ex.p++
		}
		if ex.peek().Kind == TEND {
			return
		}
		ex.command()
		if !ex.endOfCmd() {
			t := ex.peek()
			gpErr(t.Pos, "unexpected or unrecognized token: "+ex.line[t.Pos:t.End])
		}
	}
}

func expandMacros(line string) string {
	if !strings.Contains(line, "@") {
		return line
	}
	var sb strings.Builder
	var q byte
	for i := 0; i < len(line); i++ {
		c := line[i]
		if q != 0 {
			if c == '\\' && q == '"' && i+1 < len(line) {
				sb.WriteByte(c)
				sb.WriteByte(line[i+1])
				i++
				continue
			}
			if c == q {
				q = 0
			}
			sb.WriteByte(c)
			continue
		}
		if c == '"' || c == '\'' {
			q = c
			sb.WriteByte(c)
			continue
		}
		if c == '@' && i+1 < len(line) && isAlpha(line[i+1]) {
			j := i + 1
			for j < len(line) && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			name := line[i+1 : j]
			v, ok := lookupVar(name)
			if !ok || v.T != VSTR {
				warn(name + " is not a string variable")
			} else {
				sb.WriteString(v.S)
			}
			i = j - 1
			continue
		}
		sb.WriteByte(c)
	}
	return sb.String()
}

// find matching close brace token index for '{' at index i
func matchBrace(toks []Token, i int) int {
	d := 0
	for j := i; j < len(toks); j++ {
		if toks[j].Kind == TOP {
			if toks[j].Text == "{" {
				d++
			} else if toks[j].Text == "}" {
				d--
				if d == 0 {
					return j
				}
			}
		}
		if toks[j].Kind == TEND {
			break
		}
	}
	return -1
}

func (ex *Exec) subExec(a, b int) *Exec {
	t := make([]Token, 0, b-a+1)
	t = append(t, ex.toks[a:b]...)
	endPos := ex.toks[b].Pos
	t = append(t, Token{Kind: TEND, Pos: endPos, End: endPos})
	return &Exec{toks: t, line: ex.line}
}

type loopCtl struct{ brk bool }
