package main

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

// almostEquals: pattern like "pr$int" — minimum abbrev before $
func almostEquals(word, pat string) bool {
	k := strings.IndexByte(pat, '$')
	if k < 0 {
		return word == pat
	}
	full := pat[:k] + pat[k+1:]
	if len(word) < k || len(word) > len(full) {
		return false
	}
	return strings.HasPrefix(full, word)
}

func (ps *Parser) almost(pat string) bool {
	t := ps.cur()
	return t.K == TNAME && almostEquals(t.Text, pat)
}

type breakSig struct{}
type continueSig struct{}

func execTokens(toks []Token, line string) {
	ps := &Parser{toks: toks, line: line}
	execStatements(ps)
}

func execStatements(ps *Parser) {
	for ps.cur().K != TEOL {
		if ps.isOp(";") {
			ps.next()
			continue
		}
		if curCtx != nil && curCtx.inBlock {
			if s := curSource(); s != nil && s.name != "" {
				s.lineno = curCtx.startLine + strings.Count(ps.line[:ps.cur().Pos], "\n")
			}
		}
		execCommand(ps)
		if ps.cur().K == TEOL {
			break
		}
		if !ps.isOp(";") {
			t := ps.cur()
			gpErr(t.Pos, "unexpected or unrecognized token: "+t.Text)
		}
	}
}

// findMatching returns index of matching close brace for open at index i
func findMatching(toks []Token, i int) int {
	d := 0
	for j := i; j < len(toks); j++ {
		if toks[j].K == TOP {
			if toks[j].Text == "{" {
				d++
			} else if toks[j].Text == "}" {
				d--
				if d == 0 {
					return j
				}
			}
		}
	}
	return -1
}

func runBlock(ps *Parser, open, close int) {
	sub := make([]Token, 0, close-open)
	sub = append(sub, ps.toks[open+1:close]...)
	sub = append(sub, Token{K: TEOL, Pos: ps.toks[close].Pos})
	saved := curCtx
	nc := *curCtx
	nc.inBlock = true
	curCtx = &nc
	sp := &Parser{toks: sub, line: ps.line}
	execStatements(sp)
	curCtx = saved
}

func (ps *Parser) parseBlock() (int, int) {
	if !ps.isOp("{") {
		return -1, -1
	}
	o := ps.p
	c := findMatching(ps.toks, o)
	if c < 0 {
		gpErr(ps.cur().Pos, "Syntax error: missing block terminator }")
	}
	ps.p = c + 1
	return o, c
}

func evalExprAt(ps *Parser) Value {
	start := ps.cur().Pos
	undefinedFlag = false
	n := ps.parseExpr()
	v := evalNode(n)
	if undefinedFlag {
		undefinedFlag = false
		gpErr(start, "undefined value")
	}
	return v
}

func constExpr(ps *Parser) Value {
	if ps.atEnd() {
		gpErr(ps.cur().Pos, "constant expression required")
	}
	return evalExprAt(ps)
}

func realExpr(ps *Parser) float64 {
	v := constExpr(ps)
	return v.Num().Real()
}

func intExpr(ps *Parser) int {
	v := constExpr(ps).Num()
	if v.K == INT {
		return int(v.I)
	}
	return int(v.Real())
}

func stringExpr(ps *Parser) string {
	v := constExpr(ps)
	if v.K != STR {
		return v.String()
	}
	return v.S
}

// isStringStart: true if next token begins a string expression (quoted or string var)
func (ps *Parser) isStringValue() bool {
	t := ps.cur()
	if t.K == TSTR {
		return true
	}
	if t.K == TNAME {
		if v, ok := gvars[t.Text]; ok && v.K == STR {
			return true
		}
		if t.Text == "sprintf" || t.Text == "gprintf" || t.Text == "strftime" || t.Text == "word" || t.Text == "substr" || t.Text == "system" || t.Text == "trim" || t.Text == "columnhead" || t.Text == "strcol" || t.Text == "stringcolumn" {
			return true
		}
	}
	if t.K == TOP && t.Text == "(" {
		return true
	}
	return false
}

func tryString(ps *Parser) (string, bool) {
	if !ps.isStringValue() {
		return "", false
	}
	save := ps.p
	v := constExpr(ps)
	if v.K != STR {
		ps.p = save
		return "", false
	}
	return v.S, true
}

func execCommand(ps *Parser) {
	t := ps.cur()
	if t.K == TOP && t.Text == "!" {
		// shell command: rest of line
		cmd := ps.line[t.End:]
		if k := strings.IndexByte(cmd, '\n'); k >= 0 {
			cmd = cmd[:k]
		}
		flushOut()
		c := exec.Command("/bin/sh", "-c", cmd)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
		for ps.cur().K != TEOL {
			ps.next()
		}
		return
	}
	if t.K == TDOLLAR {
		// datablock definition or assignment
		if ps.peek(1).K == TOP && ps.peek(1).Text == "<<" {
			name := t.Text
			ps.next()
			ps.next()
			eod := ps.cur()
			if eod.K != TNAME {
				gpErr(eod.Pos, "data block name must be a string")
			}
			ps.next()
			readDatablock(name, eod.Text)
			return
		}
		if ps.peek(1).K == TOP && ps.peek(1).Text == "=" {
			// $a = $b copy not common
		}
		gpErr(t.Pos, "invalid command")
	}
	if t.K != TNAME {
		gpErr(t.Pos, "invalid command")
	}
	w := t.Text
	// assignments / function definitions
	nt := ps.peek(1)
	if nt.K == TOP && nt.Text == "=" {
		ps.next()
		op := ps.next().Text
		start := ps.cur().Pos
		undefinedFlag = false
		n := ps.parseExpr()
		if op != "=" {
			n = &Node{Op: "bin" + op[:1], Kids: []*Node{{Op: "var", Name: w}, n}}
		}
		v := evalNode(n)
		if undefinedFlag {
			undefinedFlag = false
			gpErr(start, "undefined value")
		}
		setVar(w, v)
		return
	}
	if nt.K == TOP && nt.Text == "(" {
		// possible function definition: name(a,b)=...
		j := ps.p + 2
		var params []string
		ok := true
		for {
			if ps.toks[j].K != TNAME {
				ok = false
				break
			}
			params = append(params, ps.toks[j].Text)
			j++
			if ps.toks[j].K == TOP && ps.toks[j].Text == "," {
				j++
				continue
			}
			break
		}
		if ok && ps.toks[j].K == TOP && ps.toks[j].Text == ")" && ps.toks[j+1].K == TOP && ps.toks[j+1].Text == "=" {
			ps.p = j + 2
			start := ps.cur().Pos
			body := ps.parseExpr()
			end := ps.cur().Pos
			txt := strings.TrimSpace(ps.line[t.Pos:end])
			_ = start
			if _, ok := gfuncs[w]; !ok { funcOrder = append(funcOrder, w) }
			gfuncs[w] = &UFunc{Name: w, Params: params, Body: body, Text: txt}
			return
		}
	}
	if nt.K == TOP && nt.Text == "[" {
		// array element assignment A[i] = v
		if v, ok := gvars[w]; ok && v.K == ARR {
			ps.next()
			ps.next()
			idx := intExpr(ps)
			ps.expectOp("]")
			if ps.isOp("=") {
				ps.next()
				val := evalExprAt(ps)
				if idx < 1 || idx > len(v.A.V) {
					errNoCaret("array index out of range")
				}
				v.A.V[idx-1] = val
				return
			}
			gpErr(ps.cur().Pos, "invalid command")
		}
	}
	switch {
	case w == "print":
		ps.next()
		cmdPrint(ps, false)
	case w == "printerr":
		ps.next()
		cmdPrint(ps, true)
	case almostEquals(w, "pr$int"):
		ps.next()
		cmdPrint(ps, false)
	case w == "if":
		ps.next()
		cmdIf(ps)
	case w == "else":
		gpErr(t.Pos, "else without if")
	case w == "do":
		ps.next()
		cmdDo(ps)
	case w == "while":
		ps.next()
		cmdWhile(ps)
	case w == "break":
		ps.next()
		panic(breakSig{})
	case w == "continue":
		ps.next()
		panic(continueSig{})
	case almostEquals(w, "eval$uate"):
		ps.next()
		s := stringExpr(ps)
		execLineNested(s)
	case almostEquals(w, "l$oad"):
		ps.next()
		if ps.cur().K == TDOLLAR {
			name := ps.cur().Text
			ps.next()
			db, ok := datablocks[name]
			if !ok {
				errNoCaret("undefined datablock")
			}
			runSource(&Source{name: name, lines: append([]string{}, db...)})
			return
		}
		f := stringExpr(ps)
		loadFile(f)
	case almostEquals(w, "ca$ll"):
		ps.next()
		f := stringExpr(ps)
		var cargs []string
		for !ps.atEnd() {
			tk := ps.cur()
			if tk.K == TSTR {
				cargs = append(cargs, tk.Str)
				ps.next()
			} else if tk.K == TOP && tk.Text == "(" {
				v := constExpr(ps)
				cargs = append(cargs, v.String())
			} else {
				// raw token text, gather contiguous
				st := tk.Pos
				ps.next()
				end := tk.End
				for !ps.atEnd() && ps.cur().Pos == end && ps.cur().K != TSTR {
					end = ps.cur().End
					ps.next()
				}
				word := ps.line[st:end]
				if tk.K == TNAME {
					if v, ok := gvars[word]; ok {
						word = v.String()
					}
				}
				cargs = append(cargs, word)
			}
		}
		callFile(f, cargs)
	case almostEquals(w, "ex$it") || almostEquals(w, "q$uit"):
		ps.next()
		code := 0
		if ps.isName("status") {
			ps.next()
			code = intExpr(ps)
		} else if ps.isName("gnuplot") {
			ps.next()
		} else if !ps.atEnd() {
			// "exit error 'msg'"
			if ps.isName("error") {
				ps.next()
				msg := stringExpr(ps)
				flushOut()
				fmt.Fprintf(stderr, "%s\n", msg)
				panic(&exitReq{1})
			}
		}
		flushOut()
		panic(&exitReq{code})
	case almostEquals(w, "se$t"):
		ps.next()
		cmdSet(ps)
	case almostEquals(w, "uns$et"):
		ps.next()
		cmdUnset(ps)
	case almostEquals(w, "sh$ow"):
		ps.next()
		cmdShow(ps)
	case almostEquals(w, "p$lot"):
		ps.next()
		cmdPlot(ps, false)
	case almostEquals(w, "sp$lot"):
		ps.next()
		cmdPlot(ps, true)
	case almostEquals(w, "rep$lot"):
		ps.next()
		cmdReplot(ps)
	case almostEquals(w, "stat$s"):
		ps.next()
		cmdStats(ps)
	case almostEquals(w, "f$it"):
		ps.next()
		cmdFit(ps)
	case almostEquals(w, "re$set"):
		ps.next()
		if ps.isName("session") || ps.isName("errors") || ps.isName("bind") {
			ps.next()
		}
		resetSettings()
	case almostEquals(w, "cl$ear"):
		ps.next()
		cmdClear()
	case almostEquals(w, "pa$use"):
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	case w == "array":
		ps.next()
		cmdArray(ps)
	case almostEquals(w, "undef$ine"):
		ps.next()
		for !ps.atEnd() {
			n := ps.cur().Text
			ps.next()
			if strings.HasSuffix(n, "*") {
				continue
			}
			if ps.isOp("*") {
				ps.next()
				for k := range gvars {
					if strings.HasPrefix(k, n) {
						delete(gvars, k)
					}
				}
				continue
			}
			if strings.HasPrefix(n, "$") {
				delete(datablocks, n)
			} else {
				delete(gvars, n)
			}
		}
	case almostEquals(w, "sy$stem"):
		ps.next()
		s := stringExpr(ps)
		flushOut()
		c := exec.Command("/bin/sh", "-c", s)
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		c.Run()
	case w == "cd":
		ps.next()
		d := stringExpr(ps)
		if err := os.Chdir(d); err != nil {
			errNoCaret("Can't change to this directory")
		}
	case w == "pwd":
		ps.next()
		fmt.Fprintln(stdout, getwd())
	case almostEquals(w, "hi$story"):
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "up$date"):
		ps.next()
		cmdUpdate(ps)
	case almostEquals(w, "sa$ve"):
		ps.next()
		cmdSave(ps)
	case w == "test":
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "h$elp") || w == "?":
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	case w == "local":
		ps.next()
		execCommand(ps)
	case w == "toggle", w == "bind", w == "vclear", w == "refresh", w == "raise", w == "lower":
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	default:
		gpErr(t.Pos, "invalid command")
	}
}

func execLineNested(s string) {
	saved := curCtx
	curCtx = &execCtx{line: s, startLine: 0}
	if saved != nil {
		curCtx.startLine = saved.startLine
	}
	s2 := expandMacros(s)
	curCtx.line = s2
	toks := tokenize(s2)
	execTokens(toks, s2)
	curCtx = saved
}

func readDatablock(name, eod string) {
	s := curSource()
	var lines []string
	if s != nil {
		for {
			l, ok := s.readRaw()
			if !ok {
				break
			}
			if strings.HasPrefix(l, eod) && strings.TrimSpace(l) == eod {
				break
			}
			if strings.TrimRight(l, "\r") == eod {
				break
			}
			lines = append(lines, l)
		}
	}
	datablocks[name] = lines
}

var printFile *os.File
var printToBlock string
var printAppend bool
var printName string

func printWriter() func(string) {
	if printToBlock != "" {
		return func(s string) {
			db := datablocks[printToBlock]
			parts := strings.Split(s, "\n")
			if len(parts) > 0 && parts[len(parts)-1] == "" {
				parts = parts[:len(parts)-1]
			}
			datablocks[printToBlock] = append(db, parts...)
		}
	}
	if printFile != nil {
		return func(s string) { printFile.WriteString(s) }
	}
	if printName == "-" {
		return func(s string) { stdout.WriteString(s) }
	}
	return func(s string) { stderr.WriteString(s) }
}

func cmdPrint(ps *Parser, toErr bool) {
	var out strings.Builder
	w := printWriter()
	if toErr {
		w = func(s string) { stderr.WriteString(s) }
	}
	first := true
	for {
		if ps.atEnd() && first {
			gpErr(ps.cur().Pos, "constant expression required")
		}
		if ps.cur().K == TDOLLAR && !(ps.peek(1).K == TOP && ps.peek(1).Text == "[") {
			name := ps.cur().Text
			if db, ok := datablocks[name]; ok {
				ps.next()
				if !first {
					out.WriteString(" ")
				}
				for _, l := range db {
					out.WriteString(l + "\n")
				}
				first = false
				if ps.isOp(",") {
					ps.next()
					continue
				}
				break
			}
		}
		if !first {
			out.WriteString(" ")
		}
		if ps.atEnd() {
			w(out.String())
			out.Reset()
			gpErr(ps.cur().Pos, "constant expression required")
		}
		var v Value
		func() {
			defer func() {
				if r := recover(); r != nil {
					w(out.String())
					panic(r)
				}
			}()
			v = evalExprAt(ps)
		}()
		first = false
		if v.K == ARR {
			out.WriteString(v.String() + "\n")
		} else {
			out.WriteString(v.String())
		}
		if ps.isOp(",") {
			ps.next()
			continue
		}
		break
	}
	s := out.String()
	if !strings.HasSuffix(s, "\n") || true {
		s += "\n"
	}
	w(s)
}

func cmdIf(ps *Parser) {
	ps.expectOp("(")
	c := evalExprAt(ps)
	ps.expectOp(")")
	cond := c.Num().Truth()
	if !ps.isOp("{") {
		// old-style if: rest of line
		if cond {
			execStatements(ps)
		} else {
			// skip to else or end
			for ps.cur().K != TEOL {
				if ps.isName("else") {
					ps.next()
					execStatements(ps)
					return
				}
				ps.next()
			}
		}
		return
	}
	o, cl := ps.parseBlock()
	done := false
	if cond {
		runBlock(ps, o, cl)
		done = true
	}
	for ps.isName("else") {
		ps.next()
		if ps.isName("if") && false {
			ps.next()
			ps.expectOp("(")
			var c2 bool
			if !done {
				c2 = evalExprAt(ps).Num().Truth()
			} else {
				ps.parseExpr()
			}
			ps.expectOp(")")
			o2, cl2 := ps.parseBlock()
			if o2 < 0 {
				gpErr(ps.cur().Pos, "expected {")
			}
			if !done && c2 {
				runBlock(ps, o2, cl2)
				done = true
			}
			continue
		}
		o2, cl2 := ps.parseBlock()
		if o2 < 0 {
			gpErr(ps.cur().Pos, "expected {else-clause}")
		}
		if !done {
			runBlock(ps, o2, cl2)
			done = true
		}
		break
	}
}

// iteration spec
type IterSpec struct {
	Var      string
	Start    int64
	End      int64
	Step     int64
	Words    []string
	IsWords  bool
	Unbounded bool
}

func parseIter(ps *Parser) *IterSpec {
	ps.expectOp("[")
	vt := ps.cur()
	if vt.K != TNAME {
		gpErr(vt.Pos, "Expecting iterator \tfor [<var> = <start> : <end> {: <incr>}]\n\tor\tfor [<var> in \"string of words\"]")
	}
	ps.next()
	it := &IterSpec{Var: vt.Text, Step: 1}
	if ps.isName("in") {
		ps.next()
		s := stringExpr(ps)
		it.Words = splitWords(s)
		it.IsWords = true
		ps.expectOp("]")
		return it
	}
	ps.expectOp("=")
	it.Start = int64(intExpr(ps))
	ps.expectOp(":")
	if ps.isOp("*") {
		ps.next()
		it.Unbounded = true
	} else {
		it.End = int64(intExpr(ps))
	}
	if ps.isOp(":") {
		ps.next()
		it.Step = int64(intExpr(ps))
	}
	ps.expectOp("]")
	return it
}

func (it *IterSpec) each(f func()) {
	if it.IsWords {
		for _, w := range it.Words {
			gset(it.Var, StrV(w))
			if iterBody(f) {
				break
			}
		}
		return
	}
	if it.Step == 0 {
		errNoCaret("iteration step cannot be 0")
	}
	for i := it.Start; it.Unbounded || (it.Step > 0 && i <= it.End) || (it.Step < 0 && i >= it.End); i += it.Step {
		gset(it.Var, IntV(i))
		if iterBody(f) {
			break
		}
	}
}

func iterBody(f func()) (brk bool) {
	savedCtx := curCtx
	defer func() {
		if r := recover(); r != nil {
			curCtx = savedCtx
			switch r.(type) {
			case breakSig:
				brk = true
			case continueSig:
				brk = false
			default:
				panic(r)
			}
		}
	}()
	f()
	return false
}

func cmdDo(ps *Parser) {
	if !ps.isName("for") {
		gpErr(ps.cur().Pos, "invalid command")
	}
	ps.next()
	var iters []*IterSpec
	type itTok struct{ p int }
	iters = append(iters, parseIter(ps))
	for ps.isName("for") {
		ps.next()
		iters = append(iters, parseIter(ps))
	}
	o, cl := ps.parseBlock()
	if o < 0 {
		gpErr(ps.cur().Pos, "expecting {")
	}
	var rec func(k int)
	rec = func(k int) {
		if k == len(iters) {
			runBlock(ps, o, cl)
			return
		}
		iters[k].each(func() { rec(k + 1) })
	}
	rec(0)
}

func cmdWhile(ps *Parser) {
	ps.expectOp("(")
	cstart := ps.p
	ps.parseExpr()
	ps.expectOp(")")
	o, cl := ps.parseBlock()
	for {
		cp := &Parser{toks: ps.toks, p: cstart, line: ps.line}
		c := evalExprAt(cp)
		if !c.Num().Truth() {
			break
		}
		if iterBody(func() { runBlock(ps, o, cl) }) {
			break
		}
	}
}

func cmdArray(ps *Parser) {
	nt := ps.cur()
	if nt.K != TNAME {
		gpErr(nt.Pos, "illegal array name")
	}
	ps.next()
	if ps.isOp("[") {
		ps.next()
		n := intExpr(ps)
		ps.expectOp("]")
		arr := &Array{V: make([]Value, n)}
		if ps.isOp("=") {
			ps.next()
			if ps.isOp("[") {
				ps.next()
				i := 0
				for !ps.isOp("]") {
					v := evalExprAt(ps)
					if i < n {
						arr.V[i] = v
					}
					i++
					if ps.isOp(",") {
						ps.next()
					} else {
						break
					}
				}
				ps.expectOp("]")
			} else {
				v := evalExprAt(ps)
				for i := range arr.V {
					arr.V[i] = v
				}
			}
		}
		gset(nt.Text, Value{K: ARR, A: arr})
		return
	}
	if ps.isOp("=") {
		ps.next()
		ps.expectOp("[")
		arr := &Array{}
		for !ps.isOp("]") {
			v := evalExprAt(ps)
			arr.V = append(arr.V, v)
			if ps.isOp(",") {
				ps.next()
			} else {
				break
			}
		}
		ps.expectOp("]")
		gset(nt.Text, Value{K: ARR, A: arr})
		return
	}
	gpErr(ps.cur().Pos, "expecting array[size] or array = [...]")
}
