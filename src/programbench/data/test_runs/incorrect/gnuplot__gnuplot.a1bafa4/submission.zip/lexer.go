package main

import (
	"strconv"
	"strings"
)

type TokKind int

const (
	TNUM TokKind = iota
	TSTR
	TNAME
	TOP
	TDOLLAR
	TEOL
)

type Token struct {
	K    TokKind
	Text string
	Pos  int
	End  int
	Num  Value
	Str  string
	Sq   bool // single quoted
}

func isAlpha(c byte) bool {
	return c == '_' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }

var ops3 = []string{"<<<"}
var ops2 = []string{"**", "==", "!=", "<=", ">=", "<<", ">>", "&&", "||", "+=", "-=", "*=", "/="}

func tokenize(line string) []Token {
	var toks []Token
	i := 0
	n := len(line)
	for i < n {
		c := line[i]
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '\n' {
			toks = append(toks, Token{K: TOP, Text: ";", Pos: i, End: i + 1})
			i++
			continue
		}
		if c == '#' {
			// comment to end of line
			for i < n && line[i] != '\n' {
				i++
			}
			continue
		}
		st := i
		if isDigit(c) || (c == '.' && i+1 < n && isDigit(line[i+1])) {
			// number
			if c == '0' && i+1 < n && (line[i+1] == 'x' || line[i+1] == 'X') {
				j := i + 2
				for j < n && strings.IndexByte("0123456789abcdefABCDEF", line[j]) >= 0 {
					j++
				}
				v, _ := strconv.ParseUint(line[i+2:j], 16, 64)
				toks = append(toks, Token{K: TNUM, Text: line[i:j], Pos: st, End: j, Num: IntV(int64(v))})
				i = j
				continue
			}
			j := i
			isf := false
			for j < n && isDigit(line[j]) {
				j++
			}
			if j < n && line[j] == '.' {
				isf = true
				j++
				for j < n && isDigit(line[j]) {
					j++
				}
			}
			if j < n && (line[j] == 'e' || line[j] == 'E') {
				k := j + 1
				if k < n && (line[k] == '+' || line[k] == '-') {
					k++
				}
				if k < n && isDigit(line[k]) {
					for k < n && isDigit(line[k]) {
						k++
					}
					j = k
					isf = true
				}
			}
			txt := line[i:j]
			var v Value
			if !isf {
				if len(txt) > 1 && txt[0] == '0' {
					if iv, err := strconv.ParseInt(txt, 8, 64); err == nil {
						v = IntV(iv)
					} else {
						iv, _ := strconv.ParseInt(txt, 10, 64)
						v = IntV(iv)
					}
				} else if iv, err := strconv.ParseInt(txt, 10, 64); err == nil {
					v = IntV(iv)
				} else {
					f, _ := strconv.ParseFloat(txt, 64)
					v = FltV(f)
				}
			} else {
				f, _ := strconv.ParseFloat(txt, 64)
				v = FltV(f)
			}
			toks = append(toks, Token{K: TNUM, Text: txt, Pos: st, End: j, Num: v})
			i = j
			continue
		}
		if isAlpha(c) {
			j := i
			for j < n && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			toks = append(toks, Token{K: TNAME, Text: line[i:j], Pos: st, End: j})
			i = j
			continue
		}
		if c == '$' {
			j := i + 1
			for j < n && (isAlpha(line[j]) || isDigit(line[j])) {
				j++
			}
			toks = append(toks, Token{K: TDOLLAR, Text: line[i:j], Pos: st, End: j})
			i = j
			continue
		}
		if c == '"' {
			var b strings.Builder
			j := i + 1
			for j < n && line[j] != '"' {
				if line[j] == '\\' && j+1 < n {
					j++
					switch line[j] {
					case 'n':
						b.WriteByte('\n')
					case 't':
						b.WriteByte('\t')
					case 'r':
						b.WriteByte('\r')
					case 'a':
						b.WriteByte('\a')
					case 'b':
						b.WriteByte('\b')
					case 'f':
						b.WriteByte('\f')
					case 'v':
						b.WriteByte('\v')
					case '"':
						b.WriteByte('"')
					case '\\':
						b.WriteByte('\\')
					case '\n':
					default:
						if line[j] >= '0' && line[j] <= '7' {
							v := 0
							k := 0
							for k < 3 && j < n && line[j] >= '0' && line[j] <= '7' {
								v = v*8 + int(line[j]-'0')
								j++
								k++
							}
							j--
							b.WriteByte(byte(v))
						} else {
							b.WriteByte(line[j])
						}
					}
					j++
					continue
				}
				b.WriteByte(line[j])
				j++
			}
			end := j
			if j < n {
				end = j + 1
			}
			toks = append(toks, Token{K: TSTR, Text: line[i:end], Pos: st, End: end, Str: b.String()})
			i = end
			continue
		}
		if c == '\'' {
			var b strings.Builder
			j := i + 1
			for j < n {
				if line[j] == '\'' {
					if j+1 < n && line[j+1] == '\'' {
						b.WriteByte('\'')
						j += 2
						continue
					}
					break
				}
				b.WriteByte(line[j])
				j++
			}
			end := j
			if j < n {
				end = j + 1
			}
			toks = append(toks, Token{K: TSTR, Text: line[i:end], Pos: st, End: end, Str: b.String(), Sq: true})
			i = end
			continue
		}
		matched := false
		for _, o := range ops2 {
			if strings.HasPrefix(line[i:], o) {
				toks = append(toks, Token{K: TOP, Text: o, Pos: st, End: i + 2})
				i += 2
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		toks = append(toks, Token{K: TOP, Text: string(c), Pos: st, End: i + 1})
		i++
	}
	toks = append(toks, Token{K: TEOL, Text: "", Pos: n, End: n})
	return toks
}
