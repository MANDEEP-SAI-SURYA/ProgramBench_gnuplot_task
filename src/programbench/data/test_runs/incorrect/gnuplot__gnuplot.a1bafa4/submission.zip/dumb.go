package main

import (
	"fmt"
	"math"
	"strings"
)

type Canvas struct {
	W, H int
	c    [][]byte
	cx   int
	cy   int
}

func newCanvas(w, h int) *Canvas {
	cv := &Canvas{W: w, H: h}
	cv.c = make([][]byte, h)
	for i := range cv.c {
		cv.c[i] = []byte(strings.Repeat(" ", w))
	}
	return cv
}

func (cv *Canvas) set(x, y int, ch byte) {
	if x < 0 || y < 0 || x >= cv.W || y >= cv.H {
		return
	}
	cv.c[y][x] = ch
}

func (cv *Canvas) text(x, y int, s string, just int) {
	n := len([]rune(s))
	switch just {
	case 1: // center
		x -= n / 2
	case 2: // right
		x -= n - 1
	}
	for i, r := range []rune(s) {
		if r < 128 {
			cv.set(x+i, y, byte(r))
		} else {
			cv.set(x+i, y, '?')
		}
	}
}

func (cv *Canvas) move(x, y int) { cv.cx, cv.cy = x, y }

func sgn(a int) int {
	if a < 0 {
		return -1
	}
	if a > 0 {
		return 1
	}
	return 0
}

func iabs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}

// vector draws like the dumb terminal; black=true uses border pens
func (cv *Canvas) vector(x, y int, pen byte, black bool) {
	x1, y1 := cv.cx, cv.cy
	dx, dy := x-x1, y-y1
	end := pen
	hp, vp := pen, pen
	if black {
		end = '+'
		hp, vp = '-', '|'
	}
	if iabs(dy) > iabs(dx) {
		cv.set(x1, y1, end)
		for d := 1; d < iabs(dy); d++ {
			cv.set(x1+int(math.Floor(float64(dx)*float64(d)/float64(iabs(dy))+0.5)), y1+d*sgn(dy), vp)
		}
		cv.set(x, y, end)
	} else if iabs(dx) > 0 {
		cv.set(x1, y1, end)
		for d := 1; d < iabs(dx); d++ {
			cv.set(x1+d*sgn(dx), y1+int(math.Floor(float64(dy)*float64(d)/float64(iabs(dx))+0.5)), hp)
		}
		cv.set(x, y, end)
	} else {
		cv.set(x1, y1, end)
	}
	cv.cx, cv.cy = x, y
}

var ltChars = "*#$%@&=*"

func ltChar(lt int) byte {
	if lt < 1 {
		return '*'
	}
	return ltChars[(lt-1)%8]
}

func ptChar(pt int) byte {
	if pt <= 0 {
		return '.'
	}
	return byte('A' + (pt-1)%26)
}

type plotGeom struct {
	xl, xr, yb, yt int
	xmin, xmax     float64
	ymin, ymax     float64
	xlog, ylog     bool
	xbase, ybase   float64
}

func (g *plotGeom) mapX(x float64) float64 {
	if g.xlog {
		x = math.Log(x)
		return float64(g.xl) + (x-math.Log(g.xmin))/(math.Log(g.xmax)-math.Log(g.xmin))*float64(g.xr-g.xl)
	}
	return float64(g.xl) + (x-g.xmin)/(g.xmax-g.xmin)*float64(g.xr-g.xl)
}
func (g *plotGeom) mapY(y float64) float64 {
	if g.ylog {
		y = math.Log(y)
		return float64(g.yb) + (y-math.Log(g.ymin))/(math.Log(g.ymax)-math.Log(g.ymin))*float64(g.yt-g.yb)
	}
	return float64(g.yb) + (y-g.ymin)/(g.ymax-g.ymin)*float64(g.yt-g.yb)
}

func rnd(v float64) int { return int(math.Floor(v + 0.5)) }

// tic generation
func genTics(a *Axis, lo, hi float64) []TicItem {
	if !a.Tics {
		return nil
	}
	var out []TicItem
	if a.TicStep < 0 || (a.TicList != nil && !a.TicAdd) {
		for _, t := range a.TicList {
			if t.Pos >= math.Min(lo, hi)-1e-9*math.Abs(hi-lo) && t.Pos <= math.Max(lo, hi)+1e-9*math.Abs(hi-lo) {
				if !t.HasL {
					t.Label = gprintf(a.Format, t.Pos)
				}
				out = append(out, t)
			}
		}
		return out
	}
	mn, mx := math.Min(lo, hi), math.Max(lo, hi)
	if a.Log {
		base := a.LogBase
		lmn := math.Log(mn) / math.Log(base)
		lmx := math.Log(mx) / math.Log(base)
		step := 1.0
		if a.TicStep > 0 {
			step = math.Log(a.TicStep) / math.Log(base)
		} else {
			r := lmx - lmn
			if r > 20 {
				step = quantizeTics(r, 20)
				if step < 1 {
					step = 1
				}
			}
		}
		for e := math.Ceil(lmn/step-1e-9) * step; e <= lmx+1e-9; e += step {
			v := math.Pow(base, e)
			out = append(out, TicItem{Pos: v, Label: gprintf(a.Format, v)})
		}
		for _, t := range a.TicList {
			out = append(out, t)
		}
		return out
	}
	step := a.TicStep
	if step <= 0 {
		step = quantizeTics(mx-mn, 20)
		if a.autoStep > 0 {
			step = a.autoStep
		}
	}
	start := math.Ceil(mn/step-1e-9) * step
	end := mx
	if a.TicStartSet {
		start = a.TicStart
		for start < mn-1e-9*step {
			start += step
		}
	}
	if a.TicEndSet && a.TicEnd < end {
		end = a.TicEnd
	}
	for i := 0; i < 1000; i++ {
		v := start + float64(i)*step
		if v > end+1e-9*step {
			break
		}
		if math.Abs(v) < 1e-10*step {
			v = 0
		}
		out = append(out, TicItem{Pos: v, Label: gprintf(a.Format, v)})
	}
	for _, t := range a.TicList {
		if !t.HasL {
			t.Label = gprintf(a.Format, t.Pos)
		}
		out = append(out, t)
	}
	return out
}

func curveRange(curves []*Curve) (float64, float64, float64, float64, bool) {
	xlo, xhi, ylo, yhi := math.Inf(1), math.Inf(-1), math.Inf(1), math.Inf(-1)
	any := false
	for _, c := range curves {
		pts := applySmooth(c)
		for _, p := range pts {
			if p.Brk || p.Typ == 'u' {
				continue
			}
			xs := []float64{p.X}
			ys := []float64{p.Y}
			switch c.Style {
			case "yerrorbars", "yerrorlines":
				ex := tableExtra(c.Style, p)
				ys = append(ys, ex...)
			case "xerrorbars", "xerrorlines":
				xs = append(xs, tableExtra(c.Style, p)...)
			case "xyerrorbars", "xyerrorlines":
				ex := tableExtra(c.Style, p)
				if len(ex) == 4 {
					xs = append(xs, ex[0], ex[1])
					ys = append(ys, ex[2], ex[3])
				}
			case "boxes", "impulses":
				ys = append(ys, 0)
			}
			for _, x := range xs {
				xlo = math.Min(xlo, x)
				xhi = math.Max(xhi, x)
			}
			for _, y := range ys {
				if math.IsNaN(y) || math.IsInf(y, 0) {
					continue
				}
				ylo = math.Min(ylo, y)
				yhi = math.Max(yhi, y)
				any = true
			}
		}
	}
	return xlo, xhi, ylo, yhi, any
}

func renderPlot(curves []*Curve, is3D bool) {
	switch S.Term {
	case "svg":
		renderSVG(curves, is3D)
		return
	case "canvas":
		renderSVG(curves, is3D)
		return
	case "dumb":
	default:
		return
	}
	if is3D {
		render3D(curves)
		return
	}
	W, H := S.TermW, S.TermH
	xa, ya := S.Axes["x"], S.Axes["y"]
	xa.autoStep, ya.autoStep = 0, 0
	g := &plotGeom{xlog: xa.Log, ylog: ya.Log}
	// x range
	xlo, xhi, ylo, yhi, any := curveRange(curves)
	g.xmin, g.xmax = xa.Min, xa.Max
	if xa.AutoMin || xa.AutoMax {
		if !math.IsInf(xlo, 1) {
			if xa.AutoMin {
				g.xmin = xlo
			}
			if xa.AutoMax {
				g.xmax = xhi
			}
			g.xmin, g.xmax = extendRangeLog(xa, g.xmin, g.xmax, xa.AutoMin, xa.AutoMax)
		}
	}
	g.ymin, g.ymax = ya.Min, ya.Max
	if ya.AutoMin || ya.AutoMax {
		if any {
			if ya.AutoMin {
				g.ymin = ylo
			}
			if ya.AutoMax {
				g.ymax = yhi
			}
			if g.ymin == g.ymax {
				lo, hi := g.ymin, g.ymax
				if lo == 0 {
					g.ymin, g.ymax = -1, 1
				} else {
					d := math.Abs(lo) * 0.01
					g.ymin, g.ymax = lo-d, hi+d
				}
				flushOut()
				fmt.Fprintf(stderr, "Warning: empty y range [%s:%s], adjusting to [%s:%s]\n", cfmtG(lo, 6, false, ""), cfmtG(hi, 6, false, ""), cfmtG(g.ymin, 6, false, ""), cfmtG(g.ymax, 6, false, ""))
			}
			g.ymin, g.ymax = extendRangeLog(ya, g.ymin, g.ymax, ya.AutoMin, ya.AutoMax)
		} else if !any {
			// all undefined
			errNoCaret("all points y value undefined!")
		}
	}
	if ya.Reverse && ya.AutoMin && ya.AutoMax {
		g.ymin, g.ymax = g.ymax, g.ymin
	}
	if xa.Reverse && xa.AutoMin && xa.AutoMax {
		g.xmin, g.xmax = g.xmax, g.xmin
	}
	xa.curMin, xa.curMax, xa.curSet = g.xmin, g.xmax, true
	ya.curMin, ya.curMax, ya.curSet = g.ymin, g.ymax, true
	xtics := genTics(xa, g.xmin, g.xmax)
	ytics := genTics(ya, g.ymin, g.ymax)
	// margins
	maxw := 0
	for _, t := range ytics {
		if l := len([]rune(t.Label)); l > maxw {
			maxw = l
		}
	}
	g.xl = maxw + 2
	if len(ytics) == 0 {
		g.xl = 2
	}
	if ya.Label != "" {
		g.xl += len([]rune(ya.Label)) + 1
	}
	if S.Lmargin >= 0 {
		g.xl = int(S.Lmargin)
	}
	g.xr = W - 4
	if S.Rmargin >= 0 {
		g.xr = W - 1 - int(S.Rmargin)
	}
	g.yt = H - 2
	if S.Title != "" {
		g.yt -= 2
	}
	if S.Tmargin >= 0 {
		g.yt = H - 1 - int(S.Tmargin)
	}
	g.yb = 2
	if len(xtics) == 0 {
		g.yb = 1
	}
	if xa.Label != "" {
		g.yb++
	}
	if S.Bmargin >= 0 {
		g.yb = int(S.Bmargin)
	}
	cv := newCanvas(W, H)
	// grid
	if S.Grid {
		if ya.Grid {
			for _, t := range ytics {
				y := rnd(g.mapY(t.Pos))
				if y <= g.yb || y >= g.yt {
					continue
				}
				cv.move(g.xl, y)
				cv.vector(g.xr, y, '.', false)
			}
		}
		if xa.Grid {
			for _, t := range xtics {
				x := rnd(g.mapX(t.Pos))
				if x <= g.xl || x >= g.xr {
					continue
				}
				cv.move(x, g.yb)
				cv.vector(x, g.yt, ':', false)
			}
		}
	}
	// tics
	for _, t := range xtics {
		x := rnd(g.mapX(t.Pos))
		if x < g.xl || x > g.xr {
			continue
		}
		cv.move(x, g.yb)
		cv.vector(x, g.yb+1, '+', true)
		if xa.Mirror && S.Border&4 != 0 {
			cv.move(x, g.yt)
			cv.vector(x, g.yt-1, '+', true)
		}
		cv.text(x, g.yb-1, t.Label, 1)
	}
	if ya.Log && ya.Tics && !(ya.MinorSet && ya.MinorTics == 0) {
		b := ya.LogBase
		for e := math.Floor(math.Log(math.Min(g.ymin, g.ymax))/math.Log(b)) - 1; e <= math.Log(math.Max(g.ymin, g.ymax))/math.Log(b)+1; e++ {
			for k := 2.0; k < b; k++ {
				v := k * math.Pow(b, e)
				if v < math.Min(g.ymin, g.ymax) || v > math.Max(g.ymin, g.ymax) {
					continue
				}
				y := rnd(g.mapY(v))
				cv.move(g.xl, y)
				cv.vector(g.xl+1, y, '+', true)
				if ya.Mirror {
					cv.move(g.xr, y)
					cv.vector(g.xr-1, y, '+', true)
				}
			}
		}
	}
	if xa.Log && xa.Tics && !(xa.MinorSet && xa.MinorTics == 0) {
		b := xa.LogBase
		for e := math.Floor(math.Log(math.Min(g.xmin, g.xmax))/math.Log(b)) - 1; e <= math.Log(math.Max(g.xmin, g.xmax))/math.Log(b)+1; e++ {
			for k := 2.0; k < b; k++ {
				v := k * math.Pow(b, e)
				if v < math.Min(g.xmin, g.xmax) || v > math.Max(g.xmin, g.xmax) {
					continue
				}
				x := rnd(g.mapX(v))
				cv.move(x, g.yb)
				cv.vector(x, g.yb+1, '+', true)
				if xa.Mirror {
					cv.move(x, g.yt)
					cv.vector(x, g.yt-1, '+', true)
				}
			}
		}
	}
	for _, t := range ytics {
		y := rnd(g.mapY(t.Pos))
		if y < g.yb || y > g.yt {
			continue
		}
		cv.move(g.xl, y)
		cv.vector(g.xl+2, y, '+', true)
		if ya.Mirror && S.Border&8 != 0 {
			cv.move(g.xr, y)
			cv.vector(g.xr-2, y, '+', true)
		}
		cv.text(g.xl-2, y, t.Label, 2)
	}
	// key layout
	var keyed []*Curve
	maxt := 0
	for _, c := range curves {
		if c.NoTitle || c.Title == "" {
			continue
		}
		keyed = append(keyed, c)
		if l := len([]rune(c.Title)); l > maxt {
			maxt = l
		}
	}
	keyIdx := map[*Curve]int{}
	for i, c := range keyed {
		keyIdx[c] = i
	}
	var keyTextX, keySL, keySR, keyY0 int
	keyTextJust := 2
	if S.KeyOn && len(keyed) > 0 {
		if S.KeyHoriz == "left" {
			keyTextX = g.xl + 1 + maxt - 1
			keySL = keyTextX + 2
		} else {
			keySL = g.xr - 8
			keyTextX = keySL - 2
		}
		if S.KeyReverse {
			if S.KeyHoriz == "left" {
				keySL = g.xl + 1
				keyTextX = keySL + 8
			} else {
				keySL = g.xr - 1 - maxt - 8
				keyTextX = keySL + 8
			}
			keyTextJust = 0
		}
		keySR = keySL + 6
		if S.KeyReverse && S.KeyHoriz == "left" {
			keySL = g.xl + 2
			keySR = keySL + 6
			keyTextX = keySR + 1
		}
		if S.KeyVert == "bottom" {
			keyY0 = g.yb + len(keyed)
			if S.KeyBox {
				keyY0++
			}
		} else if S.KeyVert == "center" {
			keyY0 = (g.yb+g.yt)/2 + len(keyed)/2
		} else {
			keyY0 = g.yt - 2
		}
	}
	if S.KeyOn && S.KeyBox && len(keyed) > 0 {
		bl := keyTextX - maxt + 1
		br := keySR + 1
		if keyTextJust == 0 {
			bl = keySL - 1
			br = keyTextX + maxt
		}
		bt := keyY0 + 1
		bb := keyY0 - len(keyed) + 1
		cv.move(bl, bb)
		cv.vector(br, bb, '+', true)
		cv.vector(br, bt, '+', true)
		cv.vector(bl, bt, '+', true)
		cv.vector(bl, bb, '+', true)
	}
	// draw curves
	for ci, c := range curves {
		lt := ci + 1
		if c.LT > 0 {
			lt = c.LT
		}
		pt := ci + 1
		if c.PT >= 0 {
			pt = c.PT
		}
		pen := ltChar(lt)
		pch := ptChar(pt)
		if k, ok := keyIdx[c]; ok && S.KeyOn {
			y := keyY0 - k
			cv.text(keyTextX, y, c.Title, keyTextJust)
			switch c.Style {
			case "points":
				cv.set((keySL+keySR)/2, y, pch)
			case "linespoints":
				cv.move(keySL, y)
				cv.vector(keySR, y, pen, false)
				cv.set((keySL+keySR)/2, y, pch)
			case "dots":
				cv.set((keySL+keySR)/2, y, '.')
			default:
				cv.move(keySL, y)
				cv.vector(keySR, y, pen, false)
			}
		}
		pts := applySmooth(c)
		drawCurve(cv, g, c, pts, pen, pch)
	}
	// border
	if S.Border != 0 {
		b := S.Border
		if b&1 != 0 {
			cv.move(g.xl, g.yb)
			cv.vector(g.xr, g.yb, '+', true)
		}
		if b&2 != 0 {
			cv.move(g.xl, g.yb)
			cv.vector(g.xl, g.yt, '+', true)
		}
		if b&4 != 0 {
			cv.move(g.xl, g.yt)
			cv.vector(g.xr, g.yt, '+', true)
		}
		if b&8 != 0 {
			cv.move(g.xr, g.yb)
			cv.vector(g.xr, g.yt, '+', true)
		}
	}
	// labels
	for _, l := range S.Labels {
		var x, y int
		switch l.Coord {
		case "graph":
			x = rnd(float64(g.xl) + l.X*float64(g.xr-g.xl))
			y = rnd(float64(g.yb) + l.Y*float64(g.yt-g.yb))
		case "screen":
			x = rnd(l.X * float64(W-1))
			y = rnd(l.Y * float64(H-1))
		default:
			x = rnd(g.mapX(l.X))
			y = rnd(g.mapY(l.Y))
		}
		j := 0
		if l.Just == "center" || l.Just == "centre" {
			j = 1
		} else if l.Just == "right" {
			j = 2
		}
		cv.text(x, y, l.Text, j)
	}
	if S.Title != "" {
		cv.text((g.xl+g.xr)/2, H-3, S.Title, 1)
	}
	if xa.Label != "" {
		cv.text((g.xl+g.xr)/2, g.yb-2, xa.Label, 1)
	}
	if ya.Label != "" {
		cv.text(1, (g.yb+g.yt)/2, ya.Label, 0)
	}
	emitCanvas(cv)
}

func extendRangeLog(a *Axis, lo, hi float64, amin, amax bool) (float64, float64) {
	if a.Log {
		if lo <= 0 {
			lo = hi / 1000
		}
		b := a.LogBase
		if amin {
			lo = math.Pow(b, math.Floor(math.Log(lo)/math.Log(b)+1e-9))
		}
		if amax {
			hi = math.Pow(b, math.Ceil(math.Log(hi)/math.Log(b)-1e-9))
		}
		return lo, hi
	}
	return extendRange(a, lo, hi, amin, amax)
}

func clipSeg(x1, y1, x2, y2 float64, g *plotGeom) (float64, float64, float64, float64, bool) {
	xmin, xmax := float64(g.xl), float64(g.xr)
	ymin, ymax := float64(g.yb), float64(g.yt)
	t0, t1 := 0.0, 1.0
	dx, dy := x2-x1, y2-y1
	p := []float64{-dx, dx, -dy, dy}
	q := []float64{x1 - xmin, xmax - x1, y1 - ymin, ymax - y1}
	for i := 0; i < 4; i++ {
		if p[i] == 0 {
			if q[i] < 0 {
				return 0, 0, 0, 0, false
			}
			continue
		}
		r := q[i] / p[i]
		if p[i] < 0 {
			if r > t1 {
				return 0, 0, 0, 0, false
			}
			if r > t0 {
				t0 = r
			}
		} else {
			if r < t0 {
				return 0, 0, 0, 0, false
			}
			if r < t1 {
				t1 = r
			}
		}
	}
	return x1 + t0*dx, y1 + t0*dy, x1 + t1*dx, y1 + t1*dy, true
}

func inside(g *plotGeom, x, y float64) bool {
	return x >= float64(g.xl)-1e-9 && x <= float64(g.xr)+1e-9 && y >= float64(g.yb)-1e-9 && y <= float64(g.yt)+1e-9
}

func drawCurve(cv *Canvas, g *plotGeom, c *Curve, pts []Pt, pen, pch byte) {
	style := c.Style
	lines := style == "lines" || style == "linespoints" || style == "yerrorlines" || style == "xerrorlines" || style == "xyerrorlines" || style == "fsteps" || style == "steps" || style == "histeps" || style == "filledcurves" || style == "fillsteps"
	points := style == "points" || style == "linespoints" || style == "yerrorbars" || style == "xerrorbars" || style == "xyerrorbars" || style == "yerrorlines" || style == "xerrorlines" || style == "xyerrorlines"
	var prev *Pt
	var px, py float64
	segment := func(x1, y1, x2, y2 float64) {
		a, b, c2, d, ok := clipSeg(x1, y1, x2, y2, g)
		if !ok {
			return
		}
		cv.move(rnd(a), rnd(b))
		cv.vector(rnd(c2), rnd(d), pen, false)
	}
	for i := range pts {
		p := &pts[i]
		if p.Brk || p.Typ == 'u' {
			prev = nil
			continue
		}
		if g.xlog && p.X <= 0 || g.ylog && p.Y <= 0 {
			prev = nil
			continue
		}
		x, y := g.mapX(p.X), g.mapY(p.Y)
		switch style {
		case "impulses":
			y0 := g.mapY(0)
			if g.ylog {
				y0 = float64(g.yb)
			}
			if y0 < float64(g.yb) {
				y0 = float64(g.yb)
			}
			if y0 > float64(g.yt) {
				y0 = float64(g.yt)
			}
			segment(x, y0, x, y)
		case "boxes":
			// handled below
		case "dots":
			if inside(g, x, y) {
				cv.set(rnd(x), rnd(y), '.')
			}
		}
		if lines && prev != nil {
			switch style {
			case "steps":
				segment(px, py, x, py)
				segment(x, py, x, y)
			case "fsteps":
				segment(px, py, px, y)
				segment(px, y, x, y)
			default:
				segment(px, py, x, y)
			}
		}
		if style == "yerrorbars" || style == "yerrorlines" {
			ex := tableExtra("yerrorbars", *p)
			if len(ex) == 2 {
				segment(x, g.mapY(ex[0]), x, g.mapY(ex[1]))
			}
		}
		prev = p
		px, py = x, y
	}
	if style == "boxes" {
		drawBoxes(cv, g, c, pts, pen, segment)
	}
	if points {
		for i := range pts {
			p := &pts[i]
			if p.Brk || p.Typ == 'u' {
				continue
			}
			x, y := g.mapX(p.X), g.mapY(p.Y)
			if inside(g, x, y) {
				cv.set(rnd(x), rnd(y), pch)
			}
		}
	}
}

func drawBoxes(cv *Canvas, g *plotGeom, c *Curve, pts []Pt, pen byte, segment func(x1, y1, x2, y2 float64)) {
	var v []Pt
	for _, p := range pts {
		if !p.Brk && p.Typ != 'u' {
			v = append(v, p)
		}
	}
	for i, p := range v {
		w := S.BoxWidth
		var xlo, xhi float64
		if w <= 0 || S.BoxWidthRel {
			var dl, dr float64
			if len(v) > 1 {
				if i > 0 {
					dl = (p.X - v[i-1].X) / 2
				}
				if i < len(v)-1 {
					dr = (v[i+1].X - p.X) / 2
				}
				if i == 0 {
					dl = dr
				}
				if i == len(v)-1 {
					dr = dl
				}
			} else {
				dl, dr = 0.5, 0.5
			}
			if S.BoxWidthRel && S.BoxWidth > 0 {
				dl *= S.BoxWidth
				dr *= S.BoxWidth
			}
			xlo, xhi = p.X-dl, p.X+dr
		} else {
			xlo, xhi = p.X-w/2, p.X+w/2
		}
		if len(p.Ex) >= 3 && c.Bins {
			xlo, xhi = p.Ex[0], p.Ex[1]
		}
		x1, x2 := g.mapX(xlo), g.mapX(xhi)
		y0 := g.mapY(0)
		if g.ylog {
			y0 = float64(g.yb)
		}
		y := g.mapY(p.Y)
		segment(x1, y0, x1, y)
		segment(x1, y, x2, y)
		segment(x2, y, x2, y0)
	}
}

func emitCanvas(cv *Canvas) {
	var b strings.Builder
	if S.TermFeed {
		b.WriteString("\f")
	}
	for r := cv.H - 1; r >= 0; r-- {
		b.Write(cv.c[r])
		if r > 0 || S.TermFeed {
			b.WriteString("\n")
		}
	}
	outWrite(b.String())
}

func render3D(curves []*Curve) {
	// minimal: blank canvas with border-less output
	cv := newCanvas(S.TermW, S.TermH)
	emitCanvas(cv)
}
