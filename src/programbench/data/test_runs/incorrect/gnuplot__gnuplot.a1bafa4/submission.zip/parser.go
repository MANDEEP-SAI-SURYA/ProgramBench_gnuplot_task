package main

type Node struct {
	Op   string
	Val  Value
	Name string
	Kids []*Node
	Pos  int
}

type Parser struct {
	toks []Token
	p    int
	line string
}

func (ps *Parser) cur() *Token  { return &ps.toks[ps.p] }
func (ps *Parser) peek(k int) *Token {
	if ps.p+k < len(ps.toks) {
		return &ps.toks[ps.p+k]
	}
	return &ps.toks[len(ps.toks)-1]
}
func (ps *Parser) isOp(s string) bool {
	t := ps.cur()
	return t.K == TOP && t.Text == s
}
func (ps *Parser) atEnd() bool {
	t := ps.cur()
	return t.K == TEOL || (t.K == TOP && t.Text == ";")
}
func (ps *Parser) isName(s string) bool {
	t := ps.cur()
	return t.K == TNAME && t.Text == s
}
func (ps *Parser) next() *Token {
	t := &ps.toks[ps.p]
	if ps.p < len(ps.toks)-1 {
		ps.p++
	}
	return t
}
func (ps *Parser) expectOp(s string) {
	if !ps.isOp(s) {
		gpErr(ps.cur().Pos, "invalid expression ")
	}
	ps.next()
}

// parseExpr parses a full expression (including assignment), not comma
func (ps *Parser) parseExpr() *Node {
	t := ps.cur()
	if t.K == TNAME && ps.peek(1).K == TOP && ps.peek(1).Text == "=" {
		ps.next()
		ps.next()
		rhs := ps.parseExpr()
		return &Node{Op: "=", Name: t.Text, Kids: []*Node{rhs}, Pos: t.Pos}
	}
	if false {
		op := ps.peek(1).Text[:1]
		ps.next()
		ps.next()
		rhs := ps.parseExpr()
		return &Node{Op: "=", Name: t.Text, Kids: []*Node{{Op: "bin" + op, Kids: []*Node{{Op: "var", Name: t.Text, Pos: t.Pos}, rhs}, Pos: t.Pos}}, Pos: t.Pos}
	}
	return ps.parseTernary()
}

func (ps *Parser) parseTernary() *Node {
	c := ps.parseBin(0)
	if ps.isOp("?") {
		pos := ps.cur().Pos
		ps.next()
		a := ps.parseTernary()
		ps.expectOp(":")
		b := ps.parseTernary()
		return &Node{Op: "?", Kids: []*Node{c, a, b}, Pos: pos}
	}
	return c
}

var binLevels = [][]string{
	{"||"}, {"&&"}, {"|"}, {"^"}, {"&"}, {"==", "!=", "eq", "ne"}, {"<", ">", "<=", ">="}, {"<<", ">>"}, {"+", "-", "."}, {"*", "/", "%"},
}

func (ps *Parser) matchLevel(lv int) string {
	t := ps.cur()
	for _, o := range binLevels[lv] {
		if (t.K == TOP || (t.K == TNAME && (o == "eq" || o == "ne"))) && t.Text == o {
			return o
		}
	}
	return ""
}

func (ps *Parser) parseBin(lv int) *Node {
	if lv >= len(binLevels) {
		return ps.parseUnary()
	}
	l := ps.parseBin(lv + 1)
	for {
		o := ps.matchLevel(lv)
		if o == "" {
			return l
		}
		pos := ps.cur().Pos
		ps.next()
		r := ps.parseBin(lv + 1)
		if o == "&&" || o == "||" {
			l = &Node{Op: o, Kids: []*Node{l, r}, Pos: pos}
		} else {
			l = &Node{Op: "bin" + o, Kids: []*Node{l, r}, Pos: pos}
		}
	}
}

func (ps *Parser) parseUnary() *Node {
	t := ps.cur()
	if t.K == TOP && (t.Text == "-" || t.Text == "+" || t.Text == "!" || t.Text == "~") {
		ps.next()
		x := ps.parseUnary()
		return &Node{Op: "u" + t.Text, Kids: []*Node{x}, Pos: t.Pos}
	}
	return ps.parsePower()
}

func (ps *Parser) parsePower() *Node {
	b := ps.parsePostfix()
	if ps.isOp("**") {
		pos := ps.cur().Pos
		ps.next()
		e := ps.parseUnary()
		return &Node{Op: "bin**", Kids: []*Node{b, e}, Pos: pos}
	}
	return b
}

func (ps *Parser) parsePostfix() *Node {
	x := ps.parsePrimary()
	for {
		if ps.isOp("!") && !(ps.peek(1).K == TOP && ps.peek(1).Text == "=") {
			pos := ps.cur().Pos
			ps.next()
			x = &Node{Op: "fact", Kids: []*Node{x}, Pos: pos}
			continue
		}
		if ps.isOp("[") {
			pos := ps.cur().Pos
			ps.next()
			var a, b *Node
			if ps.isOp(":") {
				ps.next()
				a = &Node{Op: "const", Val: IntV(1)}
				if ps.isOp("]") {
					b = &Node{Op: "const", Val: IntV(1 << 40)}
				} else {
					b = ps.parseExpr()
				}
				ps.expectOp("]")
				x = &Node{Op: "substr", Kids: []*Node{x, a, b}, Pos: pos}
				continue
			}
			a = ps.parseExpr()
			if ps.isOp(":") {
				ps.next()
				if ps.isOp("]") || ps.isOp("*") {
					if ps.isOp("*") {
						ps.next()
					}
					b = &Node{Op: "const", Val: IntV(1 << 40)}
				} else {
					b = ps.parseExpr()
				}
				ps.expectOp("]")
				x = &Node{Op: "substr", Kids: []*Node{x, a, b}, Pos: pos}
				continue
			}
			ps.expectOp("]")
			x = &Node{Op: "index", Kids: []*Node{x, a}, Pos: pos}
			continue
		}
		return x
	}
}

func (ps *Parser) parsePrimary() *Node {
	t := ps.cur()
	switch t.K {
	case TNUM:
		ps.next()
		return &Node{Op: "const", Val: t.Num, Pos: t.Pos}
	case TSTR:
		ps.next()
		return &Node{Op: "const", Val: StrV(t.Str), Pos: t.Pos}
	case TDOLLAR:
		ps.next()
		name := t.Text[1:]
		if name == "" {
			gpErr(t.Pos, "invalid expression ")
		}
		if isDigit(name[0]) {
			return &Node{Op: "column", Kids: []*Node{{Op: "const", Val: IntV(atoiSafe(name))}}, Pos: t.Pos + 1}
		}
		// datablock reference used as value
		return &Node{Op: "dblock", Name: t.Text, Pos: t.Pos}
	case TNAME:
		if t.Text == "sum" && ps.peek(1).K == TOP && ps.peek(1).Text == "[" {
			ps.next()
			ps.next()
			v := ps.cur()
			if v.K != TNAME {
				gpErr(v.Pos, "Expecting name of iteration variable")
			}
			ps.next()
			ps.expectOp("=")
			lo := ps.parseExpr()
			ps.expectOp(":")
			hi := ps.parseExpr()
			ps.expectOp("]")
			body := ps.parseTernaryNoAssign()
			return &Node{Op: "sum", Name: v.Text, Kids: []*Node{lo, hi, body}, Pos: t.Pos}
		}
		ps.next()
		if ps.isOp("(") {
			ps.next()
			var args []*Node
			if ps.isOp(")") {
				gpErr(ps.cur().Pos, "invalid expression ")
			}
			if !ps.isOp(")") {
				for {
					args = append(args, ps.parseExpr())
					if ps.isOp(",") {
						ps.next()
						continue
					}
					break
				}
			}
			cp := ps.cur().Pos
			ps.expectOp(")")
			return &Node{Op: "call", Name: t.Text, Kids: args, Pos: t.Pos, Val: IntV(int64(cp))}
		}
		return &Node{Op: "var", Name: t.Text, Pos: t.Pos}
	case TOP:
		switch t.Text {
		case "(":
			ps.next()
			e := ps.parseExpr()
			for ps.isOp(",") {
				ps.next()
				e2 := ps.parseExpr()
				e = &Node{Op: ",", Kids: []*Node{e, e2}, Pos: t.Pos}
			}
			ps.expectOp(")")
			return e
		case "{":
			ps.next()
			re := ps.parseExpr()
			ps.expectOp(",")
			im := ps.parseExpr()
			ps.expectOp("}")
			return &Node{Op: "cplx", Kids: []*Node{re, im}, Pos: t.Pos}
		case "|":
			ps.next()
			n := ps.cur()
			if n.K != TNAME && n.K != TDOLLAR {
				gpErr(n.Pos, "not an array")
			}
			ps.next()
			ps.expectOp("|")
			return &Node{Op: "card", Name: n.Text, Pos: n.Pos}
		}
	}
	gpErr(t.Pos, "invalid expression ")
	return nil
}

func (ps *Parser) parseTernaryNoAssign() *Node { return ps.parseTernary() }

func atoiSafe(s string) int64 {
	var v int64
	for i := 0; i < len(s); i++ {
		if !isDigit(s[i]) {
			break
		}
		v = v*10 + int64(s[i]-'0')
	}
	return v
}
