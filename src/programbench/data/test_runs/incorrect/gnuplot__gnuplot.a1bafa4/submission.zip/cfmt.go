package main

import (
	"math"
	"strconv"
	"strings"
)

// Spec is a parsed printf conversion spec
type Spec struct {
	Minus, Plus, Space, Hash, Zero bool
	Width                          int
	Prec                           int // -1 if none
	Conv                           byte
	Len                            string
}

// parseSpec parses at s[i]=='%'; returns spec and index after conversion char
func parseSpec(s string, i int) (Spec, int, bool) {
	sp := Spec{Prec: -1}
	i++
	for i < len(s) {
		switch s[i] {
		case '-':
			sp.Minus = true
		case '+':
			sp.Plus = true
		case ' ':
			sp.Space = true
		case '#':
			sp.Hash = true
		case '0':
			sp.Zero = true
		default:
			goto width
		}
		i++
	}
width:
	for i < len(s) && s[i] >= '0' && s[i] <= '9' {
		sp.Width = sp.Width*10 + int(s[i]-'0')
		i++
	}
	if i < len(s) && s[i] == '.' {
		i++
		sp.Prec = 0
		for i < len(s) && s[i] >= '0' && s[i] <= '9' {
			sp.Prec = sp.Prec*10 + int(s[i]-'0')
			i++
		}
	}
	for i+1 < len(s) && strings.IndexByte("hlLqjz", s[i]) >= 0 && strings.IndexByte("diouxXeEfgGcshlL", s[i+1]) >= 0 {
		sp.Len += string(s[i])
		i++
	}
	if i >= len(s) {
		return sp, i, false
	}
	sp.Conv = s[i]
	return sp, i + 1, true
}

func pad(sp Spec, body string, sign string, numeric bool) string {
	n := len(sign) + len(body)
	if n >= sp.Width {
		return sign + body
	}
	fill := sp.Width - n
	if sp.Minus {
		return sign + body + strings.Repeat(" ", fill)
	}
	if sp.Zero && numeric {
		return sign + strings.Repeat("0", fill) + body
	}
	return strings.Repeat(" ", fill) + sign + body
}

func signOf(sp Spec, neg bool) string {
	if neg {
		return "-"
	}
	if sp.Plus {
		return "+"
	}
	if sp.Space {
		return " "
	}
	return ""
}

func fmtInt(sp Spec, v int64) string {
	neg := false
	var body string
	switch sp.Conv {
	case 'd', 'i':
		u := uint64(v)
		if v < 0 {
			neg = true
			u = uint64(-v)
		}
		body = strconv.FormatUint(u, 10)
	case 'u':
		body = strconv.FormatUint(uint64(v), 10)
	case 'x':
		body = strconv.FormatUint(uint64(v), 16)
	case 'X':
		body = strings.ToUpper(strconv.FormatUint(uint64(v), 16))
	case 'o':
		body = strconv.FormatUint(uint64(v), 8)
	case 'c':
		return pad(sp, string(rune(byte(v))), "", false)
	}
	if sp.Prec >= 0 {
		if sp.Prec == 0 && v == 0 {
			body = ""
		}
		for len(body) < sp.Prec {
			body = "0" + body
		}
		sp.Zero = false
	}
	if sp.Hash {
		if sp.Conv == 'o' && !strings.HasPrefix(body, "0") {
			body = "0" + body
		} else if (sp.Conv == 'x') && v != 0 {
			return pad(sp, body, "0x", true)
		} else if sp.Conv == 'X' && v != 0 {
			return pad(sp, body, "0X", true)
		}
	}
	var sign string
	if sp.Conv == 'd' || sp.Conv == 'i' {
		sign = signOf(sp, neg)
	}
	return pad(sp, body, sign, true)
}

func fmtFloat(sp Spec, f float64) string {
	neg := math.Signbit(f)
	if neg {
		f = -f
	}
	sign := signOf(sp, neg)
	if math.IsInf(f, 0) || math.IsNaN(f) {
		b := "inf"
		if math.IsNaN(f) {
			b = "nan"
			if neg {
				sign = "-"
			}
		}
		if sp.Conv >= 'A' && sp.Conv <= 'Z' {
			b = strings.ToUpper(b)
		}
		sp.Zero = false
		return pad(sp, b, sign, false)
	}
	prec := sp.Prec
	if prec < 0 {
		prec = 6
	}
	var body string
	switch sp.Conv {
	case 'f', 'F':
		body = strconv.FormatFloat(f, 'f', prec, 64)
		if sp.Hash && prec == 0 {
			body += "."
		}
	case 'e', 'E':
		body = fmtE(f, prec, sp.Hash)
		if sp.Conv == 'E' {
			body = strings.ToUpper(body)
		}
	case 'g', 'G':
		body = cfmtG(f, prec, sp.Hash, "g")
		if sp.Conv == 'G' {
			body = strings.ToUpper(body)
		}
	}
	return pad(sp, body, sign, true)
}

func fmtE(f float64, prec int, hash bool) string {
	s := strconv.FormatFloat(f, 'e', prec, 64)
	// Go gives e+00 style already with at least 2 digits
	if hash && prec == 0 {
		k := strings.IndexByte(s, 'e')
		s = s[:k] + "." + s[k:]
	}
	return s
}

// cfmtG implements C's %g for non-negative or negative finite f
func cfmtG(f float64, prec int, hash bool, _ string) string {
	if math.IsInf(f, 1) {
		return "inf"
	}
	if math.IsInf(f, -1) {
		return "-inf"
	}
	if math.IsNaN(f) {
		return "nan"
	}
	if prec == 0 {
		prec = 1
	}
	if f == 0 {
		x := "0"
		if math.Signbit(f) {
			x = "-0"
		}
		if hash {
			x += "." + strings.Repeat("0", prec-1)
		}
		return x
	}
	es := strconv.FormatFloat(f, 'e', prec-1, 64)
	k := strings.IndexByte(es, 'e')
	exp, _ := strconv.Atoi(es[k+1:])
	var s string
	if exp < -4 || exp >= prec {
		mant := es[:k]
		if !hash && strings.Contains(mant, ".") {
			mant = strings.TrimRight(mant, "0")
			mant = strings.TrimSuffix(mant, ".")
		}
		s = mant + es[k:]
	} else {
		s = strconv.FormatFloat(f, 'f', prec-1-exp, 64)
		if !hash && strings.Contains(s, ".") {
			s = strings.TrimRight(s, "0")
			s = strings.TrimSuffix(s, ".")
		}
	}
	return s
}

// cprintf1 formats a single numeric value using a C-like spec string like "%g"
func cfmtNum(spec string, f float64) string {
	sp, _, ok := parseSpec(spec, 0)
	if !ok {
		return spec
	}
	return fmtSpecVal(sp, FltV(f))
}

func fmtSpecVal(sp Spec, v Value) string {
	switch sp.Conv {
	case 'd', 'i', 'x', 'X', 'o', 'u', 'c':
		var i int64
		if v.K == INT {
			i = v.I
		} else {
			r := v.Real()
			i = int64(r)
		}
		return fmtInt(sp, i)
	case 'f', 'F', 'e', 'E', 'g', 'G':
		return fmtFloat(sp, v.Real())
	case 's':
		s := v.S
		if sp.Prec >= 0 && sp.Prec < len(s) {
			s = s[:sp.Prec]
		}
		return pad(sp, s, "", false)
	}
	return ""
}
