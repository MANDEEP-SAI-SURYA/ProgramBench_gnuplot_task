package main

import "math"

func besI(n int, x float64) float64 {
	// series
	sum := 0.0
	term := math.Pow(x/2, float64(n))
	for k := 1; k <= n; k++ {
		term /= float64(k)
	}
	for k := 0; k < 500; k++ {
		sum += term
		term *= (x * x / 4) / (float64(k+1) * float64(k+1+n))
		if math.Abs(term) < 1e-17*math.Abs(sum) {
			break
		}
	}
	return sum
}

func igamma(a, x float64) float64 {
	if x <= 0 || a <= 0 {
		return 0
	}
	lg, _ := math.Lgamma(a)
	if x < a+1 {
		ap := a
		sum := 1.0 / a
		del := sum
		for n := 0; n < 1000; n++ {
			ap++
			del *= x / ap
			sum += del
			if math.Abs(del) < math.Abs(sum)*1e-16 {
				break
			}
		}
		return sum * math.Exp(-x+a*math.Log(x)-lg)
	}
	b := x + 1 - a
	c := 1.0 / 1e-300
	d := 1.0 / b
	h := d
	for i := 1; i < 1000; i++ {
		an := -float64(i) * (float64(i) - a)
		b += 2
		d = an*d + b
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = b + an/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return 1 - math.Exp(-x+a*math.Log(x)-lg)*h
}

func betacf(a, b, x float64) float64 {
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < 1e-300 {
		d = 1e-300
	}
	d = 1 / d
	h := d
	for m := 1; m <= 1000; m++ {
		fm := float64(m)
		m2 := 2 * fm
		aa := fm * (b - fm) * x / ((qam + m2) * (a + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		h *= d * c
		aa = -(a + fm) * (qab + fm) * x / ((a + m2) * (qap + m2))
		d = 1 + aa*d
		if math.Abs(d) < 1e-300 {
			d = 1e-300
		}
		c = 1 + aa/c
		if math.Abs(c) < 1e-300 {
			c = 1e-300
		}
		d = 1 / d
		del := d * c
		h *= del
		if math.Abs(del-1) < 1e-16 {
			break
		}
	}
	return h
}

func ibeta(a, b, x float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	la, _ := math.Lgamma(a)
	lb, _ := math.Lgamma(b)
	lab, _ := math.Lgamma(a + b)
	bt := math.Exp(lab - la - lb + a*math.Log(x) + b*math.Log(1-x))
	if x < (a+1)/(a+b+2) {
		return bt * betacf(a, b, x) / a
	}
	return 1 - bt*betacf(b, a, 1-x)/b
}

func lambertw(x float64) float64 {
	if x < -1/math.E {
		return math.NaN()
	}
	w := 0.0
	if x > 1 {
		w = math.Log(x) - math.Log(math.Log(x)+1e-300)
		if w < 0 {
			w = 0.5
		}
	}
	for i := 0; i < 100; i++ {
		ew := math.Exp(w)
		f := w*ew - x
		wn := w - f/(ew*(w+1)-(w+2)*f/(2*w+2))
		if math.Abs(wn-w) < 1e-15*(1+math.Abs(wn)) {
			w = wn
			break
		}
		w = wn
	}
	return w
}

func voigt(x, y float64) float64 {
	// numerical integration of Voigt profile (Humlicek approx would be better)
	// K(x,y) = y/pi * int exp(-t^2)/((x-t)^2+y^2) dt
	n := 4000
	lim := 10.0 + math.Abs(x)
	h := 2 * lim / float64(n)
	s := 0.0
	for i := 0; i <= n; i++ {
		t := -lim + float64(i)*h
		w := 1.0
		if i == 0 || i == n {
			w = 0.5
		}
		s += w * math.Exp(-t*t) / ((x-t)*(x-t) + y*y)
	}
	return s * h * y / math.Pi / math.Sqrt(math.Pi)
}

func expint(n int, x float64) float64 {
	if n == 0 {
		return math.Exp(-x) / x
	}
	if x > 1 {
		b := x + float64(n)
		c := 1 / 1e-300
		d := 1 / b
		h := d
		for i := 1; i < 1000; i++ {
			an := -float64(i) * float64(n-1+i)
			b += 2
			d = 1 / (an*d + b)
			c = b + an/c
			del := c * d
			h *= del
			if math.Abs(del-1) < 1e-16 {
				break
			}
		}
		return h * math.Exp(-x)
	}
	nm1 := n - 1
	var ans float64
	if nm1 != 0 {
		ans = 1 / float64(nm1)
	} else {
		ans = -math.Log(x) - 0.5772156649015329
	}
	fact := 1.0
	for i := 1; i < 1000; i++ {
		fact *= -x / float64(i)
		var del float64
		if i != nm1 {
			del = -fact / float64(i-nm1)
		} else {
			psi := -0.5772156649015329
			for ii := 1; ii <= nm1; ii++ {
				psi += 1 / float64(ii)
			}
			del = fact * (-math.Log(x) + psi)
		}
		ans += del
		if math.Abs(del) < math.Abs(ans)*1e-16 {
			break
		}
	}
	return ans
}

func airyAi(x float64) float64 {
	// power series for moderate x
	c1 := 0.355028053887817239
	c2 := 0.258819403792806798
	f, g := 1.0, x
	tf, tg := 1.0, x
	for k := 1; k < 200; k++ {
		fk := float64(k)
		tf *= x * x * x / ((3*fk - 1) * (3 * fk))
		tg *= x * x * x / ((3 * fk) * (3*fk + 1))
		f += tf
		g += tg
		if math.Abs(tf)+math.Abs(tg) < 1e-18 {
			break
		}
	}
	return c1*f - c2*g
}

func ellipK(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	for i := 0; i < 60; i++ {
		a, b = (a+b)/2, math.Sqrt(a*b)
	}
	return math.Pi / (2 * a)
}

func ellipE(k float64) float64 {
	a, b := 1.0, math.Sqrt(1-k*k)
	c := k
	sum := c * c / 2
	p := 1.0
	for i := 0; i < 60; i++ {
		c = (a - b) / 2
		a, b = (a+b)/2, math.Sqrt(a*b)
		p *= 2
		sum += p * c * c / 2
	}
	return math.Pi / (2 * a) * (1 - sum)
}
