package main

import (
	"bufio"
	"fmt"
	"io"
	"math"
	"os"
	"strings"
)

var gvars = map[string]Value{}
var gfuncs = map[string]*UFunc{}
var datablocks = map[string][]string{}

var stdout = bufio.NewWriterSize(os.Stdout, 65536)
var stderr = bufio.NewWriterSize(os.Stderr, 65536)

func flushOut() {
	stdout.Flush()
	stderr.Flush()
}

type Source struct {
	name     string // "" for -e / stdin
	lines    []string
	idx      int // next line index
	lineno   int // current line number (1-based) of last read line
	stdin    bool
	reader   *bufio.Reader
	isCmdArg bool
}

func (s *Source) readRaw() (string, bool) {
	if s.reader != nil {
		l, err := s.reader.ReadString('\n')
		if err != nil && l == "" {
			return "", false
		}
		s.lineno++
		return strings.TrimRight(l, "\n"), true
	}
	if s.idx >= len(s.lines) {
		return "", false
	}
	l := s.lines[s.idx]
	s.idx++
	s.lineno++
	return l, true
}

var srcStack []*Source

func curSource() *Source {
	if len(srcStack) == 0 {
		return nil
	}
	return srcStack[len(srcStack)-1]
}

type exitReq struct{ code int }

// current execution context for error messages
type execCtx struct {
	line      string
	startLine int
	inBlock   bool
}

var curCtx *execCtx

func errLocation() string {
	s := curSource()
	if s == nil || s.name == "" {
		if s != nil && s.stdin {
			return "         line 0: "
		}
		return "line 0: "
	}
	return fmt.Sprintf("\"%s\" line %d: ", s.name, s.lineno)
}

func reportError(e *GPError) {
	flushOut()
	s := curSource()
	loc := errLocation()
	if e.Pos >= 0 && curCtx != nil && !curCtx.inBlock {
		line := curCtx.line
		prefix := ""
		if s != nil && s.stdin {
			prefix = "gnuplot> "
		}
		fmt.Fprintf(stderr, "\n%s%s\n%s^\n", prefix, line, strings.Repeat(" ", len(prefix)+e.Pos))
	}
	fmt.Fprintf(stderr, "%s%s\n\n", loc, e.Msg)
	flushOut()
}

// readLogical reads a full logical line: continuation lines and brace balancing
func readLogical(s *Source) (string, bool) {
	l, ok := s.readRaw()
	if !ok {
		return "", false
	}
	for strings.HasSuffix(l, "\\") {
		n, ok2 := s.readRaw()
		if !ok2 {
			l = l[:len(l)-1]
			break
		}
		l = l[:len(l)-1] + n
	}
	for braceDepth(l) > 0 {
		n, ok2 := s.readRaw()
		if !ok2 {
			break
		}
		for strings.HasSuffix(n, "\\") {
			m, ok3 := s.readRaw()
			if !ok3 {
				break
			}
			n = n[:len(n)-1] + m
		}
		l = l + "\n" + n
	}
	return l, true
}

func braceDepth(l string) int {
	d := 0
	inS, inD := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		switch {
		case inD:
			if c == '\\' {
				i++
			} else if c == '"' {
				inD = false
			}
		case inS:
			if c == '\'' {
				inS = false
			}
		case c == '"':
			inD = true
		case c == '\'':
			inS = true
		case c == '#':
			for i < len(l) && l[i] != '\n' {
				i++
			}
		case c == '{':
			d++
		case c == '}':
			d--
		}
	}
	return d
}

func expandMacros(l string) string {
	if !strings.Contains(l, "@") {
		return l
	}
	var b strings.Builder
	inS, inD := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		if inD {
			if c == '\\' && i+1 < len(l) {
				b.WriteByte(c)
				i++
				b.WriteByte(l[i])
				continue
			}
			if c == '"' {
				inD = false
			}
			b.WriteByte(c)
			continue
		}
		if inS {
			if c == '\'' {
				inS = false
			}
			b.WriteByte(c)
			continue
		}
		if c == '"' {
			inD = true
		} else if c == '\'' {
			inS = true
		} else if c == '#' {
			b.WriteString(l[i:])
			break
		} else if c == '@' && i+1 < len(l) && isAlpha(l[i+1]) {
			j := i + 1
			for j < len(l) && (isAlpha(l[j]) || isDigit(l[j])) {
				j++
			}
			name := l[i+1 : j]
			v, ok := gvars[name]
			if ok && v.K == STR {
				b.WriteString(v.S)
				i = j - 1
				continue
			}
			if !ok {
				errNoCaret("undefined variable: " + name)
			}
			errNoCaret("macro must be a string")
		}
		b.WriteByte(c)
	}
	return b.String()
}

// runSource executes all lines of s. Returns false if aborted by error (non-interactive).
func runSource(s *Source) {
	srcStack = append(srcStack, s)
	savedCtx := curCtx
	defer func() { srcStack = srcStack[:len(srcStack)-1]; curCtx = savedCtx }()
	for {
		l, ok := readLogical(s)
		if !ok {
			break
		}
		if s.stdin {
			func() {
				defer func() {
					if r := recover(); r != nil {
						if e, ok := r.(*GPError); ok {
							reportError(e)
							return
						}
						if _, ok := r.(*exitReq); ok {
							panic(r)
						}
						reportError(&GPError{Msg: "internal error", Pos: -1})
					}
				}()
				execLine(l, s.lineno)
			}()
		} else {
			func() {
				defer func() {
					if r := recover(); r != nil {
						if e, ok := r.(*GPError); ok {
							reportError(e)
							panic(&exitReq{1})
						}
						if _, ok := r.(*exitReq); ok {
							panic(r)
						}
						switch r.(type) {
						case breakSig, continueSig:
							panic(r)
						}
						reportError(&GPError{Msg: "internal error", Pos: -1})
						panic(&exitReq{1})
					}
				}()
				execLine(l, s.lineno)
			}()
		}
	}
}

func execLine(l string, lineno int) {
	saved := curCtx
	curCtx = &execCtx{line: l, startLine: lineno - strings.Count(l, "\n")}
	l2 := expandMacros(l)
	curCtx.line = l2
	toks := tokenize(l2)
	execTokens(toks, l2)
	curCtx = saved
}

func main() {
	initVars()
	args := os.Args[1:]
	code := run(args)
	flushOut()
	closeOutputs()
	os.Exit(code)
}

func run(args []string) (code int) {
	defer func() {
		if r := recover(); r != nil {
			if e, ok := r.(*GPError); ok {
				reportError(e)
				code = 1
				return
			}
			if x, ok := r.(*exitReq); ok {
				code = x.code
				return
			}
			flushOut()
			code = 1
		}
	}()
	didFile := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-V" || a == "--version":
			fmt.Fprintln(stdout, "gnuplot 5.4 patchlevel 9")
			return 0
		case a == "-h" || a == "--help":
			fmt.Fprint(stdout, "Usage: gnuplot [OPTION] ... [FILE]\n  -V, --version\n  -h, --help\n  -p  --persist\n  -s  --slow\n  -d  --default-settings\n  -c  scriptfile ARG1 ARG2 ... \n  -e  \"command1; command2; ...\"\n")
			fmt.Fprintln(stdout, "gnuplot 5.4 patchlevel 9")
			return 0
		case a == "-p" || a == "--persist" || a == "-s" || a == "--slow" || a == "-d" || a == "--default-settings":
		case a == "-e":
			if i+1 < len(args) {
				i++
				s := &Source{lines: []string{args[i]}, isCmdArg: true}
				runSource(s)
				didFile = true
			}
		case a == "-c":
			if i+1 < len(args) {
				fname := args[i+1]
				callFile(fname, args[i+2:])
				return 0
			}
		case a == "-":
			runStdin()
			didFile = true
		case strings.HasPrefix(a, "-") && len(a) > 1:
			fmt.Fprintf(stderr, "unrecognized option %s\n", a)
		default:
			callFile(a, nil)
			didFile = true
		}
	}
	if !didFile {
		runStdin()
	}
	return 0
}

func runStdin() {
	s := &Source{stdin: true, reader: bufio.NewReader(os.Stdin)}
	runSource(s)
}

func loadFile(name string) {
	data, err := os.ReadFile(name)
	if err != nil {
		errNoCaret(fmt.Sprintf("Cannot load input from '%s'", name))
	}
	txt := string(data)
	txt = strings.TrimSuffix(txt, "\n")
	lines := strings.Split(txt, "\n")
	if len(data) == 0 {
		lines = nil
	}
	s := &Source{name: name, lines: lines}
	runSource(s)
}

func callFile(name string, cargs []string) {
	// save ARGs
	saved := map[string]Value{}
	names := []string{"ARGC", "ARGV", "ARG0", "ARG1", "ARG2", "ARG3", "ARG4", "ARG5", "ARG6", "ARG7", "ARG8", "ARG9"}
	for _, n := range names {
		if v, ok := gvars[n]; ok {
			saved[n] = v
		}
	}
	gset("ARGC", IntV(int64(len(cargs))))
	gset("ARG0", StrV(name))
	arr := &Array{}
	gset("ARGV", Value{K: ARR, A: arr})
	for i := 1; i <= 9; i++ {
		if i <= len(cargs) {
			gset(fmt.Sprintf("ARG%d", i), StrV(cargs[i-1]))
		} else {
			gset(fmt.Sprintf("ARG%d", i), StrV(""))
		}
	}
	for _, c := range cargs {
		if v, ok := strToNum(c); ok && scanNumberPrefix(strings.TrimSpace(c)) == len(strings.TrimSpace(c)) {
			arr.V = append(arr.V, FltV(v.Real()))
		} else {
			arr.V = append(arr.V, StrV(c))
		}
	}
	gset("ARGV", Value{K: ARR, A: arr})
	defer func() {
		for _, n := range names {
			if v, ok := saved[n]; ok {
				gvars[n] = v
			} else {
				delete(gvars, n)
			}
		}
	}()
	loadFile(name)
}

func initVars() {
	gset("pi", FltV(math.Pi))
	gset("I", CplxV(0, 1))
	gset("NaN", FltV(math.NaN()))
	gset("VoxelDistance", FltV(0))
	gset("GPVAL_VERSION", FltV(5.4))
	gset("GPVAL_PATCHLEVEL", StrV("9"))
	gset("GPVAL_COMPILE_OPTIONS", StrV("+READLINE  +LIBREADLINE  +HISTORY  -BACKWARDS_COMPATIBILITY  +BINARY_DATA  +GD_PNG  +GD_JPEG  +GD_TTF  +GD_GIF  +ANIMATION  -USE_CWDRC  +HIDDEN3D_QUADTREE  +DATASTRINGS  +HISTOGRAMS  +OBJECTS  +STRINGVARS  +MACROS  +THIN_SPLINES  +IMAGE  +USER_LIMITS  +STATS +EXTERNAL_FUNCTIONS "))
	gset("GPVAL_TERM", StrV("unknown"))
	gset("GPVAL_TERMOPTIONS", StrV(""))
	gset("GPVAL_OUTPUT", StrV(""))
	gset("GPVAL_ERRNO", IntV(0))
	gset("GPVAL_ERRMSG", StrV(""))
	gset("GPVAL_PWD", StrV(getwd()))
	gset("GPVAL_SYSNAME", StrV("Linux"))
	gset("GPVAL_MACHINE", StrV("x86_64"))
	gset("GPVAL_ENCODING", StrV("default"))
	gset("GPVAL_MINUS_SIGN", StrV("-"))
	gset("GPVAL_MICRO", StrV("u"))
	gset("GPVAL_DEGREE_SIGN", StrV("°"))
	gset("GPVAL_LAST_PLOT", StrV(""))
	gset("GPVAL_TERMINALS", StrV("canvas cgm context dumb dxf emf epslatex fig gif hpgl jpeg latex lua mf mp pcl5 pict2e png postscript pslatex pstex pstricks qms sixelgd svg tek40xx tek410x texdraw tikz tkcanvas unknown vttek xterm"))
	gset("GPVAL_DATA_NAME", StrV(""))
	resetSettings()
}

func getwd() string {
	d, _ := os.Getwd()
	return d
}

var _ = io.EOF
