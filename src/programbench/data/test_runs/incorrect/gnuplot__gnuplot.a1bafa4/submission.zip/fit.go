package main

import (
	"fmt"
	"math"
	"strings"
)

func cmdFit(ps *Parser) {
	// optional ranges
	var xr *[2]float64
	for ps.isOp("[") {
		ps.next()
		if ps.cur().K == TNAME && ps.peek(1).K == TOP && ps.peek(1).Text == "=" {
			ps.next()
			ps.next()
		}
		var lo, hi = math.Inf(-1), math.Inf(1)
		if !ps.isOp(":") && !ps.isOp("*") {
			lo = realExpr(ps)
		} else if ps.isOp("*") {
			ps.next()
		}
		ps.expectOp(":")
		if !ps.isOp("]") && !ps.isOp("*") {
			hi = realExpr(ps)
		} else if ps.isOp("*") {
			ps.next()
		}
		ps.expectOp("]")
		if xr == nil {
			xr = &[2]float64{lo, hi}
		}
	}
	funcStart := ps.cur().Pos
	fn := ps.parseExpr()
	funcText := strings.TrimSpace(ps.line[funcStart:ps.cur().Pos])
	_ = funcText
	it := &PlotItem{lt: -1, pt: -1}
	st := ps.cur()
	if st.K == TDOLLAR {
		it.file = st.Text
		ps.next()
	} else {
		v := constExpr(ps)
		it.file = v.S
	}
	var params []string
	errorsGiven := false
	for !ps.atEnd() {
		switch {
		case ps.almost("u$sing"):
			ps.next()
			it.using = parseUsing(ps)
			it.hasUsing = true
		case ps.almost("i$ndex"):
			ps.next()
			a := intExpr(ps)
			it.index = [3]int{a, a, 1}
			it.hasIndex = true
		case ps.almost("ev$ery"):
			ps.next()
			it.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if ps.isOp(":") {
					ps.next()
					continue
				}
				if ps.atEnd() || ps.cur().K == TNAME {
					break
				}
				it.every[k] = intExpr(ps)
				if ps.isOp(":") {
					ps.next()
				} else {
					break
				}
			}
			it.hasEvery = true
		case ps.isName("via"):
			ps.next()
			if ps.cur().K == TSTR {
				errNoCaret("fit: parameter files not supported")
			}
			for {
				if ps.cur().K != TNAME {
					gpErr(ps.cur().Pos, "no parameter specified")
				}
				params = append(params, ps.cur().Text)
				ps.next()
				if ps.isOp(",") {
					ps.next()
					continue
				}
				break
			}
		case ps.isName("yerror") || ps.isName("yerrors") || ps.isName("errors") || ps.isName("zerror") || ps.isName("xyerror"):
			errorsGiven = true
			ps.next()
			for ps.isOp(",") || ps.cur().K == TNAME && len(ps.cur().Text) == 1 {
				ps.next()
			}
		case ps.isName("unitweights"):
			ps.next()
		default:
			gpErr(ps.cur().Pos, "unexpected or unrecognized token: "+ps.cur().Text)
		}
	}
	if len(params) == 0 {
		gpErr(ps.cur().Pos, "Need via and either parameter list or file")
	}
	lines, ok := readDataLines(it.file)
	if !ok {
		errNoCaret(fmt.Sprintf("Cannot find or open file \"%s\"", it.file))
	}
	df := parseData(lines)
	var X, Y, W []float64
	ncol := len(it.using)
	if ncol >= 3 && !errorsGiven {
		errorsGiven = true
		flushOut()
		fmt.Fprintf(stderr, "%swarning: \n\t> Implied independent variable y not found in fit function.\n\t> Assuming version 4 syntax with zerror in column 3 but no zerror keyword.\n\n", errLocation())
	}
	for si, set := range df.sets {
		if it.hasIndex && si != it.index[0] {
			continue
		}
		dsPoint := -1
		for bi, blk := range set.blocks {
			for pi, row := range blk {
				dsPoint++
				if it.hasEvery {
					e := it.every
					if pi < e[2] || (e[4] >= 0 && pi > e[4]) || (pi-e[2])%e[0] != 0 {
						continue
					}
					if bi < e[3] || (e[5] >= 0 && bi > e[5]) {
						continue
					}
				}
				curRow = &rowCtx{fields: row.fields, pointNo: dsPoint, blockNo: bi, setNo: si}
				var vals []float64
				skip := false
				if it.hasUsing {
					v, typ, sk, _ := evalUsing(it.using, row.fields, 3, true, "")
					skip = sk || typ == 'u'
					vals = v
				} else {
					for k := 0; k < len(row.fields) && k < 2; k++ {
						f, ok := fieldNum(row.fields[k])
						if !ok {
							skip = true
						}
						vals = append(vals, f)
					}
					if len(vals) == 1 {
						vals = []float64{float64(dsPoint), vals[0]}
					}
				}
				curRow = nil
				if skip || len(vals) < 2 {
					continue
				}
				if xr != nil && (vals[0] < xr[0] || vals[0] > xr[1]) {
					continue
				}
				X = append(X, vals[0])
				Y = append(Y, vals[1])
				w := 1.0
				if len(vals) >= 3 && errorsGiven {
					w = vals[2]
				}
				W = append(W, w)
			}
		}
	}
	n := len(X)
	np := len(params)
	if n == 0 {
		errNoCaret("No data to fit")
	}
	// initial values
	p0 := make([]float64, np)
	for i, p := range params {
		v, ok := gvars[p]
		if !ok || v.K == UNDEF {
			gset(p, FltV(1))
			p0[i] = 1
		} else {
			p0[i] = v.Num().Real()
		}
	}
	scale := make([]float64, np)
	for i := range p0 {
		scale[i] = p0[i]
		if scale[i] == 0 || !S.FitPrescale {
			scale[i] = 1
		}
	}
	dummy := S.Dummy1
	oldX, hadX := gvars[dummy]
	evalModel := func(p []float64, x float64) float64 {
		for i, name := range params {
			gvars[name] = FltV(p[i])
		}
		gvars[dummy] = FltV(x)
		undefinedFlag = false
		v := evalNode(fn)
		if undefinedFlag {
			undefinedFlag = false
			return math.NaN()
		}
		return v.Num().Real()
	}
	chisqOf := func(p []float64) (float64, []float64) {
		r := make([]float64, n)
		s := 0.0
		for i := 0; i < n; i++ {
			r[i] = (Y[i] - evalModel(p, X[i])) / W[i]
			s += r[i] * r[i]
		}
		return s, r
	}
	jacobian := func(p []float64) [][]float64 {
		J := make([][]float64, n)
		for i := range J {
			J[i] = make([]float64, np)
		}
		base := make([]float64, n)
		for i := 0; i < n; i++ {
			base[i] = evalModel(p, X[i])
		}
		for k := 0; k < np; k++ {
			ak := p[k] / scale[k]
			h := math.Abs(ak) * 1e-3
			if h == 0 {
				h = 1e-3
			}
			pp := append([]float64{}, p...)
			pp[k] = (ak + h) * scale[k]
			for i := 0; i < n; i++ {
				d := (evalModel(pp, X[i]) - base[i]) / h
				J[i][k] = d / W[i]
			}
		}
		return J
	}
	p := append([]float64{}, p0...)
	chisq, r := chisqOf(p)
	J := jacobian(p)
	lambda := 0.0
	if S.FitStartLambda > 0 {
		lambda = S.FitStartLambda
	} else {
		tr := 0.0
		for i := 0; i < n; i++ {
			for k := 0; k < np; k++ {
				tr += J[i][k] * J[i][k]
			}
		}
		lambda = math.Sqrt(tr / float64(np*n))
	}
	factor := S.FitLambdaFactor
	if factor <= 0 {
		factor = 10
	}
	limit := S.FitLimit
	if limit <= 0 {
		limit = 1e-5
	}
	verbose := S.FitQuiet == "" || S.FitQuiet == "verbose" || S.FitQuiet == "brief"
	var out strings.Builder
	hdr := "iter      chisq       delta/lim  lambda  "
	var hp []string
	for _, pn := range params {
		hp = append(hp, fmt.Sprintf("%-13s", pn))
	}
	hdr += " " + strings.Join(hp, " ")
	rowLine := func(iter int, chisq, delta, lambda float64, p []float64) string {
		s := fmt.Sprintf("%4d %-17.10e%10.2e %9.2e ", iter, chisq, delta, lambda)
		for _, v := range p {
			s += fmt.Sprintf(" %14.6e", v)
		}
		return s
	}
	if verbose {
		out.WriteString(hdr + "\n")
		out.WriteString(rowLine(0, chisq, 0, lambda, p) + "\n")
	}
	iter := 0
	lastDelta := 0.0
	converged := false
	maxiter := S.FitMaxIter
	for {
		// build normal equations
		A := make([][]float64, np)
		g := make([]float64, np)
		for k := 0; k < np; k++ {
			A[k] = make([]float64, np)
		}
		for i := 0; i < n; i++ {
			for k := 0; k < np; k++ {
				g[k] += J[i][k] * r[i]
				for l := 0; l < np; l++ {
					A[k][l] += J[i][k] * J[i][l]
				}
			}
		}
		improved := false
		for tries := 0; tries < 30; tries++ {
			d, ok := givensSolve(J, r, lambda, np)
			if !ok {
				lambda *= factor
				continue
			}
			pn := make([]float64, np)
			for k := range pn {
				pn[k] = (p[k]/scale[k] + d[k]) * scale[k]
			}
			cn, rn := chisqOf(pn)
			if !math.IsNaN(cn) && cn <= chisq {
				delta := (cn - chisq) / cn
				if cn == 0 {
					delta = 0
				}
				lastDelta = delta
				p, r, chisq = pn, rn, cn
				lambda /= factor
				iter++
				improved = true
				if verbose {
					out.WriteString(rowLine(iter, chisq, delta/limit, lambda, p) + "\n")
				}
				if math.Abs(delta) < limit {
					converged = true
				}
				break
			}
			lambda *= factor
			if verbose {
				dl := (cn - chisq) / cn
				s := fmt.Sprintf("%4s %-17.10e%10.2e %9.2e ", "*", cn, dl/limit, lambda)
				for _, v := range pn {
					s += fmt.Sprintf(" %14.6e", v)
				}
				out.WriteString(s + "\n")
			}
		}
		if !improved {
			converged = true
			break
		}
		if converged {
			break
		}
		if maxiter > 0 && iter >= maxiter {
			break
		}
		J = jacobian(p)
	}
	for i, name := range params {
		gset(name, FltV(p[i]))
	}
	if hadX {
		gvars[dummy] = oldX
	} else {
		delete(gvars, dummy)
	}
	// errors
	ndf := n - np
	Jf := jacobian(p)
	for i, name := range params {
		gvars[name] = FltV(p[i])
	}
	if hadX {
		gvars[dummy] = oldX
	} else {
		delete(gvars, dummy)
	}
	A := make([][]float64, np)
	for k := range A {
		A[k] = make([]float64, np)
	}
	for i := 0; i < n; i++ {
		for k := 0; k < np; k++ {
			for l := 0; l < np; l++ {
				A[k][l] += Jf[i][k] * Jf[i][l] / (scale[k] * scale[l])
			}
		}
	}
	cov := invert(A)
	rchi := 1.0
	if ndf > 0 {
		rchi = chisq / float64(ndf)
	}
	errs := make([]float64, np)
	for k := 0; k < np; k++ {
		v := cov[k][k]
		if S.FitErrScaling || !errorsGiven {
			v *= rchi
		}
		errs[k] = math.Sqrt(math.Abs(v))
	}
	stdfit := math.Sqrt(rchi)
	pval := 0.0
	if ndf > 0 {
		pval = 1 - igamma(float64(ndf)/2, chisq/2)
	}
	gset("FIT_CONVERGED", IntV(1))
	gset("FIT_NDF", IntV(int64(ndf)))
	gset("FIT_STDFIT", FltV(stdfit))
	gset("FIT_WSSR", FltV(chisq))
	gset("FIT_P", FltV(pval))
	gset("FIT_NITER", IntV(int64(iter)))
	if S.FitErrVars {
		for k, name := range params {
			gset(name+"_err", FltV(errs[k]))
		}
	}
	if S.FitQuiet == "quiet" {
		return
	}
	if verbose {
		out.WriteString(hdr + "\n")
	}
	g := func(x float64) string { return cfmtG(x, 6, false, "") }
	if converged || true {
		fmt.Fprintf(&out, "\nAfter %d iterations the fit converged.\n", iter)
	}
	fmt.Fprintf(&out, "final sum of squares of residuals : %s\n", g(chisq))
	fmt.Fprintf(&out, "rel. change during last iteration : %s\n\n", g(lastDelta))
	fmt.Fprintf(&out, "degrees of freedom    (FIT_NDF)                        : %d\n", ndf)
	fmt.Fprintf(&out, "rms of residuals      (FIT_STDFIT) = sqrt(WSSR/ndf)    : %s\n", g(stdfit))
	fmt.Fprintf(&out, "variance of residuals (reduced chisquare) = WSSR/ndf   : %s\n", g(rchi))
	if errorsGiven {
		fmt.Fprintf(&out, "p-value of the Chisq distribution (FIT_P)              : %s\n", g(pval))
	}
	out.WriteString("\nFinal set of parameters            Asymptotic Standard Error\n")
	out.WriteString("=======================            ==========================\n")
	for k, name := range params {
		pct := 0.0
		if p[k] != 0 {
			pct = math.Abs(errs[k] / p[k] * 100)
		}
		fmt.Fprintf(&out, "%-15s = %-15s  +/- %-12s (%s%%)\n", name, g(p[k]), cfmtG(errs[k], 4, false, ""), cfmtG(pct, 4, false, ""))
	}
	if np > 1 {
		out.WriteString("\ncorrelation matrix of the fit parameters:\n")
		out.WriteString("                ")
		for _, name := range params {
			fmt.Fprintf(&out, "%-6.6s ", name)
		}
		out.WriteString("\n")
		for k, name := range params {
			fmt.Fprintf(&out, "%-15.15s", name)
			for l := 0; l <= k; l++ {
				c := cov[k][l] / math.Sqrt(cov[k][k]*cov[l][l])
				fmt.Fprintf(&out, "%6.3f ", c)
			}
			out.WriteString("\n")
		}
	}
	pw := printWriter()
	_ = pw
	stderr.WriteString(out.String())
}

// givensSolve solves min ||[J; lambda I] d - [r; 0]|| via Givens QR
func givensSolve(J [][]float64, r []float64, lambda float64, np int) ([]float64, bool) {
	m := len(J) + np
	C := make([][]float64, m)
	d := make([]float64, m)
	for i := range J {
		C[i] = append([]float64{}, J[i]...)
		d[i] = r[i]
	}
	for k := 0; k < np; k++ {
		C[len(J)+k] = make([]float64, np)
		C[len(J)+k][k] = lambda
	}
	for j := 0; j < np; j++ {
		for i := j + 1; i < m; i++ {
			if C[i][j] == 0 {
				continue
			}
			var c, s float64
			if math.Abs(C[j][j]) < 1e-300 {
				c, s = 0, 1
			} else {
				rr := math.Hypot(C[j][j], C[i][j])
				if C[j][j] < 0 {
					rr = -rr
				}
				c = C[j][j] / rr
				s = C[i][j] / rr
			}
			for k := j; k < np; k++ {
				a, b := C[j][k], C[i][k]
				C[j][k] = c*a + s*b
				C[i][k] = -s*a + c*b
			}
			a, b := d[j], d[i]
			d[j] = c*a + s*b
			d[i] = -s*a + c*b
		}
	}
	x := make([]float64, np)
	for j := np - 1; j >= 0; j-- {
		s := d[j]
		for k := j + 1; k < np; k++ {
			s -= C[j][k] * x[k]
		}
		if C[j][j] == 0 {
			return nil, false
		}
		x[j] = s / C[j][j]
	}
	return x, true
}

func solveLin(A [][]float64, b []float64) ([]float64, bool) {
	n := len(b)
	M := make([][]float64, n)
	for i := range M {
		M[i] = append(append([]float64{}, A[i]...), b[i])
	}
	for c := 0; c < n; c++ {
		piv := c
		for r := c + 1; r < n; r++ {
			if math.Abs(M[r][c]) > math.Abs(M[piv][c]) {
				piv = r
			}
		}
		if M[piv][c] == 0 {
			return nil, false
		}
		M[c], M[piv] = M[piv], M[c]
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := M[r][c] / M[c][c]
			for k := c; k <= n; k++ {
				M[r][k] -= f * M[c][k]
			}
		}
	}
	x := make([]float64, n)
	for i := range x {
		x[i] = M[i][n] / M[i][i]
	}
	return x, true
}

func invert(A [][]float64) [][]float64 {
	n := len(A)
	out := make([][]float64, n)
	for j := 0; j < n; j++ {
		e := make([]float64, n)
		e[j] = 1
		x, ok := solveLin(A, e)
		if !ok {
			x = make([]float64, n)
		}
		for i := 0; i < n; i++ {
			if out[i] == nil {
				out[i] = make([]float64, n)
			}
			out[i][j] = x[i]
		}
	}
	return out
}
