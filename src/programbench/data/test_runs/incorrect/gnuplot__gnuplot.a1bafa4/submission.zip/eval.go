package main

import (
	"math"
	"math/cmplx"
	"strings"
)

type UFunc struct {
	Name   string
	Params []string
	Body   *Node
	Text   string
}

type DataCtx struct {
	cols    []string // raw fields
	vals    []Value
	valid   []bool
	line    int
	heads   []string
	colhead bool
}

var undefinedFlag bool

func setUndef() Value {
	undefinedFlag = true
	return FltV(math.NaN())
}

func lookupVar(name string, pos int) Value {
	if v, ok := gvars[name]; ok {
		if v.K == UNDEF {
			errNoCaret("undefined variable: " + name)
		}
		return v
	}
	errNoCaret("undefined variable: " + name)
	return Value{}
}

func evalNode(n *Node) Value {
	switch n.Op {
	case "const":
		return n.Val
	case "var":
		return lookupVar(n.Name, n.Pos)
	case "=":
		v := evalNode(n.Kids[0])
		if v.K == ARR {
			errNoCaret("cannot assign array")
		}
		setVar(n.Name, v)
		return v
	case ",":
		evalNode(n.Kids[0])
		return evalNode(n.Kids[1])
	case "?":
		c := evalNode(n.Kids[0])
		if c.Num().Truth() {
			return evalNode(n.Kids[1])
		}
		return evalNode(n.Kids[2])
	case "&&":
		a := evalNode(n.Kids[0])
		if !a.Num().Truth() {
			return IntV(0)
		}
		return BoolV(evalNode(n.Kids[1]).Num().Truth())
	case "||":
		a := evalNode(n.Kids[0])
		if a.Num().Truth() {
			return IntV(1)
		}
		return BoolV(evalNode(n.Kids[1]).Num().Truth())
	case "u-":
		v := evalNode(n.Kids[0]).Num()
		if v.K == INT {
			return IntV(-v.I)
		}
		return CplxV(-v.R, -v.Im)
	case "u+":
		return evalNode(n.Kids[0]).Num()
	case "u!":
		v := evalNode(n.Kids[0]).Num()
		return BoolV(!v.Truth())
	case "u~":
		v := evalNode(n.Kids[0]).Num()
		if v.K != INT {
			errNoCaret("~ operator requires integer operand")
		}
		return IntV(^v.I)
	case "fact":
		v := evalNode(n.Kids[0]).Num()
		if v.K != INT {
			errNoCaret("factorial (!) argument must be an integer")
		}
		r := 1.0
		for i := int64(2); i <= v.I; i++ {
			r *= float64(i)
		}
		if r < 9.2e18 {
			return IntV(int64(r))
		}
		return FltV(r)
	case "cplx":
		a := evalNode(n.Kids[0]).Num()
		b := evalNode(n.Kids[1]).Num()
		return CplxV(a.Real(), b.Real())
	case "index":
		x := evalNode(n.Kids[0])
		i := evalNode(n.Kids[1])
		if x.K == ARR {
			idx := int(i.Num().Real())
			if i.K == INT {
				idx = int(i.I)
			}
			if idx < 1 || idx > len(x.A.V) {
				errNoCaret("array index out of range")
			}
			e := x.A.V[idx-1]
			if e.K == UNDEF {
				return e
			}
			return e
		}
		if x.K != ARR {
			errNoCaret("internal error: attempt to index a scalar variable")
		}
		gpErr(n.Pos, "invalid expression ")
	case "substr":
		x := evalNode(n.Kids[0])
		a := evalNode(n.Kids[1]).Num()
		b := evalNode(n.Kids[2]).Num()
		if x.K != STR {
			errNoCaret("substring operation requires string variable")
		}
		return StrV(substrGP(x.S, int(a.Real()), int(math.Min(b.Real(), 1<<40))))
	case "card":
		v, ok := gvars[n.Name]
		if !ok || v.K != ARR {
			if strings.HasPrefix(n.Name, "$") {
				if db, ok := datablocks[n.Name]; ok {
					return IntV(int64(len(db)))
				}
			}
			gpErr(n.Pos, "not an array")
		}
		return IntV(int64(len(v.A.V)))
	case "column":
		return colValue(evalNode(n.Kids[0]), n.Pos)
	case "dblock":
		errNoCaret("invalid use of datablock")
	case "sum":
		lo := evalNode(n.Kids[0]).Num()
		hi := evalNode(n.Kids[1]).Num()
		l := int64(lo.Real())
		h := int64(hi.Real())
		old, had := gvars[n.Name]
		var acc Value = IntV(0)
		for i := l; i <= h; i++ {
			gset(n.Name, IntV(i))
			acc = arith("+", acc, evalNode(n.Kids[2]).Num())
		}
		if had {
			gvars[n.Name] = old
		} else {
			delete(gvars, n.Name)
		}
		return acc
	case "call":
		return callFunc(n)
	}
	if strings.HasPrefix(n.Op, "bin") {
		op := n.Op[3:]
		a := evalNode(n.Kids[0])
		b := evalNode(n.Kids[1])
		return binop(op, a, b)
	}
	panic("bad node " + n.Op)
}

func substrGP(s string, a, b int) string {
	rs := []rune(s)
	if a < 1 {
		a = 1
	}
	if b > len(rs) {
		b = len(rs)
	}
	if a > b {
		return ""
	}
	return string(rs[a-1 : b])
}

func binop(op string, a, b Value) Value {
	switch op {
	case ".":
		if a.K == ARR || b.K == ARR {
			errNoCaret("internal error : STRING operator applied to non-STRING type")
		}
		return StrV(a.String() + b.String())
	case "eq":
		if a.K != STR || b.K != STR {
			errNoCaret("internal error : STRING operator applied to non-STRING type")
		}
		return BoolV(a.S == b.S)
	case "ne":
		if a.K != STR || b.K != STR {
			errNoCaret("internal error : STRING operator applied to non-STRING type")
		}
		return BoolV(a.S != b.S)
	case "==", "!=":
		var eq bool
		{
			x, y := a.Num(), b.Num()
			if x.K == INT && y.K == INT {
				eq = x.I == y.I
			} else {
				eq = x.Real() == y.Real() && x.Imag() == y.Imag()
			}
		}
		if op == "!=" {
			eq = !eq
		}
		return BoolV(eq)
	case "<", ">", "<=", ">=":
		x, y := a.Num(), b.Num()
		var c int
		if x.K == INT && y.K == INT {
			if x.I < y.I {
				c = -1
			} else if x.I > y.I {
				c = 1
			}
		} else {
			xr, yr := x.Real(), y.Real()
			if xr < yr {
				c = -1
			} else if xr > yr {
				c = 1
			} else if xr != yr {
				return IntV(0)
			}
		}
		switch op {
		case "<":
			return BoolV(c < 0)
		case ">":
			return BoolV(c > 0)
		case "<=":
			return BoolV(c <= 0)
		}
		return BoolV(c >= 0)
	case "&", "|", "^", "<<", ">>":
		x, y := a.Num(), b.Num()
		if x.K != INT || y.K != INT {
			errNoCaret("bitwise operation requires integer operands")
		}
		switch op {
		case "&":
			return IntV(x.I & y.I)
		case "|":
			return IntV(x.I | y.I)
		case "^":
			return IntV(x.I ^ y.I)
		case "<<":
			return IntV(x.I << uint64(y.I&63))
		case ">>":
			return IntV(int64(uint64(x.I) >> uint64(y.I&63)))
		}
	}
	return arith(op, a.Num(), b.Num())
}

func arith(op string, a, b Value) Value {
	if a.K == INT && b.K == INT {
		x, y := a.I, b.I
		switch op {
		case "+":
			r := x + y
			if (x >= 0) == (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) + float64(y))
			}
			return IntV(r)
		case "-":
			r := x - y
			if (x >= 0) != (y >= 0) && (r >= 0) != (x >= 0) {
				return FltV(float64(x) - float64(y))
			}
			return IntV(r)
		case "*":
			r := x * y
			if x != 0 && (r/x != y || (x == -1 && y == math.MinInt64)) {
				return FltV(float64(x) * float64(y))
			}
			return IntV(r)
		case "/":
			if y == 0 {
				return setUndef()
			}
			return IntV(x / y)
		case "%":
			if y == 0 {
				return setUndef()
			}
			return IntV(x % y)
		case "**":
			if y < 0 {
				if x == 1 {
					return IntV(1)
				}
				if x == -1 {
					if y%2 == 0 {
						return IntV(1)
					}
					return IntV(-1)
				}
				if x == 0 {
					return setUndef()
				}
				return FltV(math.Pow(float64(x), float64(y)))
			}
			r := int64(1)
			ov := false
			for i := int64(0); i < y; i++ {
				nr := r * x
				if x != 0 && nr/x != r {
					ov = true
					break
				}
				r = nr
			}
			if ov {
				return FltV(math.Pow(float64(x), float64(y)))
			}
			return IntV(r)
		}
	}
	if op == "%" {
		errNoCaret("non-integer operand for %")
	}
	if a.Imag() == 0 && b.Imag() == 0 {
		x, y := a.Real(), b.Real()
		switch op {
		case "+":
			return FltV(x + y)
		case "-":
			return FltV(x - y)
		case "*":
			return FltV(x * y)
		case "/":
			if y == 0 {
				return setUndef()
			}
			return FltV(x / y)
		case "**":
			if x == 0 && y < 0 {
				return setUndef()
			}
			if x < 0 && y != math.Trunc(y) {
				mag := math.Pow(-x, y)
				th := math.Pi * y
				return CplxV(mag*math.Cos(th), mag*math.Sin(th))
			}
			if b.K == INT {
				return FltV(math.Pow(x, y))
			}
			return FltV(math.Pow(x, y))
		}
	}
	x := complex(a.Real(), a.Imag())
	y := complex(b.Real(), b.Imag())
	var r complex128
	switch op {
	case "+":
		r = x + y
	case "-":
		r = x - y
	case "*":
		r = x * y
	case "/":
		if y == 0 {
			return setUndef()
		}
		r = x / y
	case "**":
		if x == 0 {
			if real(y) == 0 && imag(y) == 0 {
				return FltV(1)
			}
			return FltV(0)
		}
		if imag(y) == 0 {
			mag := math.Pow(cmplx.Abs(x), real(y))
			th := cmplx.Phase(x) * real(y)
			r = complex(mag*math.Cos(th), mag*math.Sin(th))
		} else {
			r = cmplx.Exp(y * cmplx.Log(x))
		}
	}
	return CplxV(real(r), imag(r))
}

func setVar(name string, v Value) {
	if name == "pi" || name == "NaN" {
		// gnuplot allows? keep simple
	}
	gset(name, v)
}
