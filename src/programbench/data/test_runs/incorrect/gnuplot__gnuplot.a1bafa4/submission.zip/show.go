package main

import (
	"fmt"
	"sort"
	"strings"
)

var varOrder []string
var varSeen = map[string]bool{}

func gset(name string, v Value) {
	if !varSeen[name] {
		varSeen[name] = true
		varOrder = append(varOrder, name)
	}
	gvars[name] = v
}

func showVarValue(v Value) string {
	if v.K == STR {
		return "\"" + v.S + "\""
	}
	if v.K == ARR {
		return fmt.Sprintf("<%d element array>", len(v.A.V))
	}
	return v.String()
}

func cmdShow(ps *Parser) {
	out := func(f string, a ...interface{}) { fmt.Fprintf(stderr, f, a...) }
	t := ps.cur()
	if ps.atEnd() {
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
	w := t.Text
	ps.next()
	if a, ok := axisFromPrefix(w, "range"); ok {
		out("\n")
		showRange(a)
		out("\n")
		return
	}
	if a, ok := axisFromPrefix(w, "label"); ok && a != "" {
		out("\n\t%slabel is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", a, S.Axes[a].Label)
		return
	}
	switch {
	case almostEquals(w, "sa$mples"):
		out("\n\tsampling rate is %d, %d\n\n", S.Samples1, S.Samples2)
	case almostEquals(w, "iso$samples"):
		out("\n\tiso sampling rate is %d, %d\n\n", S.Iso1, S.Iso2)
	case almostEquals(w, "log$scale"):
		var parts []string
		var bases []string
		for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
			ax := S.Axes[a]
			if ax.Log {
				parts = append(parts, a)
				if ax.LogBase != 10 {
					bases = append(bases, fmt.Sprintf("%s (base %s)", a, fmtShowNum(ax.LogBase)))
				}
			}
		}
		if len(parts) == 0 {
			out("\n\tlogscaling on none\n\n")
		} else {
			s := "\n\tlogscaling on "
			for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
				ax := S.Axes[a]
				if ax.Log {
					if ax.LogBase != 10 {
						s += fmt.Sprintf(" %s (base %s)", a, fmtShowNum(ax.LogBase))
					} else {
						s += " " + a
					}
				}
			}
			out("%s\n\n", s)
		}
	case almostEquals(w, "tit$le"):
		out("\n\ttitle is \"%s\", offset at (character 0, 0, 0)center justified  textcolor lt -1\n\n", S.Title)
	case almostEquals(w, "k$ey"):
		showKey()
	case almostEquals(w, "fo$rmat"):
		out("\n\ttic format is:\n")
		for _, a := range []string{"x", "y", "x2", "y2", "z", "cb", "r"} {
			out("\t  %s-axis: \"%s\"\n", a, S.Axes[a].Format)
		}
		out("\n")
	case almostEquals(w, "st$yle"):
		if ps.almost("d$ata") {
			ps.next()
			out("\n\tData are plotted with %s\n\n", S.StyleData)
		} else if ps.almost("f$unction") {
			ps.next()
			out("\n\tFunctions are plotted with %s\n\n", S.StyleFunc)
		} else if ps.almost("fi$ll") {
			ps.next()
			showFill()
		} else {
			for !ps.atEnd() {
				ps.next()
			}
			out("\n\tData are plotted with %s\n\n", S.StyleData)
		}
	case almostEquals(w, "t$erminal"):
		switch S.Term {
		case "dumb":
			f := "feed"
			if !S.TermFeed {
				f = "nofeed"
			}
			out("\n   terminal type is dumb %s  size %d, %d aspect 2, 1 mono\n\n", f, S.TermW, S.TermH)
		default:
			out("\n   terminal type is %s \n\n", S.Term)
		}
	case almostEquals(w, "o$utput"):
		if S.Output == "" {
			out("\n\toutput is sent to STDOUT\n\n")
		} else {
			out("\n\toutput is sent to '%s'\n\n", S.Output)
		}
	case almostEquals(w, "an$gles"):
		out("\n\tAngles are in %s\n\n", S.Angles)
	case almostEquals(w, "du$mmy"):
		out("\n\tdummy variables are %s %s \n\n", S.Dummy1, S.Dummy2)
	case almostEquals(w, "pa$rametric"):
		out("\n\tparametric is %s\n\n", onoff(S.Parametric))
	case almostEquals(w, "pol$ar"):
		out("\n\tpolar is %s\n\n", onoff(S.Polar))
	case almostEquals(w, "bor$der"):
		if S.Border == 0 {
			out("\n\tborder is not drawn\n\n")
		} else {
			out("\n\tborder %d (0x%X) is drawn in front layer with\n\t  lt black linewidth 1.000 dashtype solid\n\n", S.Border, S.Border)
		}
	case almostEquals(w, "g$rid"):
		if !S.Grid {
			out("\n\tgrid is OFF\n\n")
		} else {
			var at []string
			for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
				if S.Axes[a].Grid {
					at = append(at, a)
				}
			}
			for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
				if S.Axes[a].MGrid {
					at = append(at, "m"+a)
				}
			}
			out("\n\tRectangular grid drawn at %s tics\n\tMajor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tMinor grid drawn with lt 0 linecolor 0 linewidth 0.500\n\tGrid drawn at default layer\n\n", strings.Join(at, " "))
		}
	case almostEquals(w, "dataf$ile"):
		out("\n")
		if S.DFMissing == "" {
			out("\tNo missing data string set for datafile\n")
		} else {
			out("\t\"%s\" in datafile is interpreted as missing value\n", S.DFMissing)
		}
		if S.DFSep == "" {
			out("\tdatafile fields separated by whitespace\n")
		} else {
			out("\tdatafile fields separated by any of %d characters \"%s\"\n", len(S.DFSep), S.DFSep)
		}
		out("\tComments chars are \"%s\"\n", S.DFComments)
		if S.DFColumnHeaders {
			out("\tFirst line is treated as headers\n")
		} else {
			out("\tFirst line is treated as headers only if accessed explicitly\n")
		}
		out("\n")
	case almostEquals(w, "fit"):
		showFit()
	case almostEquals(w, "pr$int"):
		name := "<stderr>"
		if printName == "-" {
			name = "<stdout>"
		} else if printName != "" {
			name = printName
		} else if printToBlock != "" {
			name = printToBlock
		}
		out("\n\tprint output is sent to '%s'\n\n", name)
	case almostEquals(w, "off$sets"):
		out("\n\toffsets are %s, %s, %s, %s\n\n", fmtShowNum(S.Offsets[0]), fmtShowNum(S.Offsets[1]), fmtShowNum(S.Offsets[2]), fmtShowNum(S.Offsets[3]))
	case almostEquals(w, "mar$gins"):
		out("\n")
		for _, m := range []struct {
			n string
			v float64
		}{{"l", S.Lmargin}, {"r", S.Rmargin}, {"b", S.Bmargin}, {"t", S.Tmargin}} {
			if m.v < 0 {
				out("\t%smargin is computed automatically\n", m.n)
			} else {
				out("\t%smargin is set to %s\n", m.n, fmtShowNum(m.v))
			}
		}
		out("\n")
	case almostEquals(w, "si$ze"):
		out("\n\tsize is scaled by %s,%s\n\tNo attempt to control aspect ratio\n\n", fmtShowNum(S.SizeX), fmtShowNum(S.SizeY))
	case almostEquals(w, "or$igin"):
		out("\n\torigin is set to %s,%s\n\n", fmtShowNum(S.OriginX), fmtShowNum(S.OriginY))
	case almostEquals(w, "timef$mt"):
		out("\n\tDefault format for reading time data is \"%s\"\n\n", S.Timefmt)
	case almostEquals(w, "poi$ntsize"):
		out("\n\tpointsize is %s\n\n", fmtShowNum(S.PointSize))
	case almostEquals(w, "box$width"):
		if S.BoxWidth < 0 {
			out("\n\tboxwidth is auto\n\tboxdepth is 0\n\n")
		} else if S.BoxWidthRel {
			out("\n\tboxwidth is %s relative\n\tboxdepth is 0\n\n", fmtShowNum(S.BoxWidth))
		} else {
			out("\n\tboxwidth is %s absolute\n\tboxdepth is 0\n\n", fmtShowNum(S.BoxWidth))
		}
	case almostEquals(w, "enc$oding"):
		out("\n\tnominal character encoding is utf8\n\thowever LC_CTYPE in current locale is C.UTF-8\n\n")
	case almostEquals(w, "ve$rsion"):
		out("\n\tG N U P L O T\n\tVersion 5.4 patchlevel 9    last modified 2023-09-01\n\n\tCopyright (C) 1986-1993, 1998, 2004, 2007-2023\n\tThomas Williams, Colin Kelley and many others\n\n\tgnuplot home:     http://www.gnuplot.info\n\tfaq, bugs, etc:   type \"help FAQ\"\n\timmediate help:   type \"help\"  (plot window: hit 'h')\n\n")
		if ps.almost("l$ong") {
			ps.next()
		}
	case almostEquals(w, "var$iables"):
		all := false
		prefix := ""
		if ps.isName("all") {
			all = true
			ps.next()
		} else if !ps.atEnd() && ps.cur().K == TNAME {
			prefix = ps.cur().Text
			ps.next()
		}
		if all {
			out("\n\tAll available variables:\n")
		} else if prefix != "" {
			out("\n\tVariables beginning with %s:\n", prefix)
		} else {
			out("\n\tUser and default variables:\n")
		}
		for _, n := range varOrder {
			v, ok := gvars[n]
			if !ok {
				continue
			}
			if !all && strings.HasPrefix(n, "GPVAL_") {
				continue
			}
			if prefix != "" && !strings.HasPrefix(n, prefix) {
				continue
			}
			if v.K == UNDEF {
				continue
			}
			out("\t%s = %s\n", n, showVarValue(v))
		}
		out("\n")
	case almostEquals(w, "fu$nctions"):
		out("\n\tUser-Defined Functions:\n")
		names := make([]string, 0)
		for _, n := range funcOrder {
			if _, ok := gfuncs[n]; ok {
				names = append(names, n)
			}
		}
		for _, n := range names {
			out("\t%s\n", gfuncs[n].Text)
		}
		out("\n")
	case almostEquals(w, "ta$ble"):
		if S.Table {
			if S.TableBlock != "" {
				out("\n\ttable mode is on, output to datablock %s\n\n", S.TableBlock)
			} else if S.TableFile != "" {
				out("\n\ttable mode is on, output to file \"%s\"\n\n", S.TableFile)
			} else {
				out("\n\ttable mode is on\n\n")
			}
		} else {
			out("\n\ttable mode is off\n\n")
		}
	case almostEquals(w, "vi$ew"):
		out("\n\tview is %s rot_x, %s rot_z, %s scale, %s scale_z\n\t\t axes are independently scaled\n\t\t azimuth 0\n\n", fmtShowNum(S.View[0]), fmtShowNum(S.View[1]), fmtShowNum(S.View[2]), fmtShowNum(S.View[3]))
	case almostEquals(w, "zero$axis"):
		for _, a := range []string{"x", "x2", "y", "y2", "z"} {
			if S.Axes[a].ZeroAxis {
				out("\n\t%szeroaxis is drawn with\t lt 0 linecolor 0 linewidth 1.000\n\n", a)
			} else {
				out("\n\t%szeroaxis is OFF\n\n", a)
			}
		}
	case almostEquals(w, "cl$ip"):
		out("\n\tpoint clip is OFF\n\tclipping lines with one end out of range (clip one)\n\tnot drawing lines with both ends out of range (clip two)\n\tnot clipping lines on polar plot at maximum radius\n\n")
	case almostEquals(w, "cont$ours"):
		out("\n\tcontour for surfaces are not drawn\n\n")
	case almostEquals(w, "lab$el"):
		out("\n")
		for _, l := range S.Labels {
			showOneLabel(l)
		}
		out("\n")
	case almostEquals(w, "arr$ow"), almostEquals(w, "obj$ect"):
		out("\n\n")
	case almostEquals(w, "auto$scale"):
		out("\n\tautoscaling is \tx: %s, \ty: %s, \n\t               \tx2: %s, \ty2: %s, \n\t               \tz: %s, \tcb: %s, \n", autoStr("x"), autoStr("y"), autoStr("x2"), autoStr("y2"), autoStr("z"), autoStr("cb"))
	case almostEquals(w, "dec$imalsign"):
		out("\n\tdecimalsign for input is  . \n\tdecimalsign for output has default value (normally '.')\n\tdegree sign for output is \xc2\xb0 \n\n")
	case len(w) > 5 && w[0] == 'm' && strings.HasSuffix(w, "tics"):
		a := w[1 : len(w)-4]
		if ax, ok := S.Axes[a]; ok {
			if ax.MinorSet && ax.MinorTics > 0 {
				out("\tminor %stics are drawn with %d subintervals between major tic marks\n\n", a, ax.MinorTics)
			} else if ax.MinorSet && ax.MinorTics == 0 {
				out("\tminor %stics are off\n\n", a)
			} else {
				out("\tminor %stics are off for linear scales\n\tminor %stics are computed automatically for log scales\n\n", a, a)
			}
		}
	case almostEquals(w, "tics"):
		showTics([]string{"x", "x2", "y", "y2", "z", "cb"})
	case w == "xtics" || w == "ytics" || w == "ztics" || w == "x2tics" || w == "y2tics" || w == "cbtics":
		a := strings.TrimSuffix(w, "tics")
		if a == "x" {
			showTics([]string{"x", "x2"})
		} else if a == "y" {
			showTics([]string{"y", "y2"})
		} else {
			showTics([]string{a})
		}
	case len(w) >= 5 && strings.HasSuffix(w, "data"):
		a := strings.TrimSuffix(w, "data")
		if ax, ok := S.Axes[a]; ok {
			if ax.Time {
				out("\n\t%s is set to time\n\n", a)
			} else {
				out("\n\t%s is set to numerical\n\n", a)
			}
		}
	default:
		gpErr(t.Pos, "Unrecognized option. See 'help show'.")
	}
	_ = sort.Strings
}

var funcOrder []string

func autoStr(a string) string {
	ax := S.Axes[a]
	if ax.AutoMin && ax.AutoMax {
		return "ON"
	}
	if ax.AutoMin {
		return "MIN"
	}
	if ax.AutoMax {
		return "MAX"
	}
	return "OFF"
}

func onoff(b bool) string {
	if b {
		return "ON"
	}
	return "OFF"
}

func showOneLabel(l *Label) {
	fmt.Fprintf(stderr, "\tlabel %d \"%s\" at %s %s, %s %s, %s 0 %s not rotated back lt black norotate\n", l.Tag, l.Text, l.Coord, fmtShowNum(l.X), l.Coord, fmtShowNum(l.Y), l.Coord, l.Just)
}

func showRange(a string) {
	ax := S.Axes[a]
	lo := "*"
	hi := "*"
	if !ax.AutoMin {
		lo = fmt.Sprintf("%.5f", ax.Min)
		lo = cfmtNum("%#g", ax.Min)
	}
	if !ax.AutoMax {
		hi = cfmtNum("%#g", ax.Max)
	}
	rev := "noreverse"
	if ax.Reverse {
		rev = "reverse"
	}
	wb := "nowriteback"
	if ax.Writeback {
		wb = "writeback"
	}
	s := fmt.Sprintf("\tset %srange [ %s : %s ] %s %s", a, lo, hi, rev, wb)
	if ax.AutoMin || ax.AutoMax {
		cmin, cmax := ax.curMin, ax.curMax
		if !ax.curSet {
			d := newAxis(a)
			cmin, cmax = d.Min, d.Max
		}
		s += fmt.Sprintf("  # (currently [%s:%s] )", cfmtNum("%#g", cmin), cfmtNum("%#g", cmax))
	}
	fmt.Fprintf(stderr, "%s\n", s)
}

func showKey() {
	out := func(f string, a ...interface{}) { fmt.Fprintf(stderr, f, a...) }
	if !S.KeyOn {
		out("\n\tkey is OFF\n")
		return
	}
	pos := S.KeyVert + " " + S.KeyHoriz
	if S.KeyHoriz == "center" && S.KeyVert == "center" {
		pos = "center"
	}
	if S.KeyOutside {
		pos = "outside " + pos
	}
	dir := "vertical"
	if S.KeyHorizontal {
		dir = "horizontal"
	}
	out("\n\tkey is ON, position: %s %s fixed  offset: (character 0, 0)\n", pos, dir)
	just := "right"
	if S.KeyJust == "Left" {
		just = "left"
	}
	rev := "not reversed"
	if S.KeyReverse {
		rev = "reversed"
	}
	inv := "not inverted"
	if S.KeyInvert {
		inv = "inverted"
	}
	box := "not boxed"
	if S.KeyBox {
		box = "boxed"
	}
	out("\tkey is %s justified, %s, %s, enhanced and %s\n", just, rev, inv, box)
	if S.KeyBox {
		out("\twith  lt black linewidth 1.000 dashtype solid\n")
	}
	out("\tsample length is %s characters\n", fmtShowNum(S.KeySamplen))
	out("\tvertical spacing is %s characters\n", fmtShowNum(S.KeySpacing))
	out("\twidth adjustment is 0 characters\n\theight adjustment is 0 characters\n\tcurves are automatically titled with filename\n\tmaximum number of columns is calculated automatically\n\tmaximum number of rows is calculated automatically\n\n")
	out("\tkey title is \"%s\" center justified \n\n", S.KeyTitle)
}

func showFill() {
	switch S.FillStyle {
	case "solid":
		fmt.Fprintf(stderr, "\n\tFill style uses  solid colour with density %.3f with border \n\n", S.FillDensity)
	default:
		fmt.Fprintf(stderr, "\n\tFill style is empty with border \n\n")
	}
}

func showFit() {
	out := func(f string, a ...interface{}) { fmt.Fprintf(stderr, f, a...) }
	mode := "brief"
	switch S.FitQuiet {
	case "quiet":
		mode = "no"
	case "results":
		mode = "final"
	case "verbose":
		mode = "verbose"
	}
	_ = mode
	out("\n")
	switch S.FitQuiet {
	case "quiet":
		out("\tfit will not output results to console")
	case "results":
		out("\tfit will only print final results to console")
	case "verbose":
		out("\tfit will output verbose results to console")
	default:
		out("\tfit will output brief results to console")
	}
	if S.FitLog {
		out(" and log-file.\n")
	} else {
		out(".\n")
	}
	out("\tfit can handle up to 12 independent variables\n")
	if S.FitPrescale {
		out("\tfit will prescale parameters by their initial values\n")
	} else {
		out("\tfit will not prescale parameters by their initial values\n")
	}
	if S.FitErrVars {
		out("\tfit will place parameter errors in variables\n")
	} else {
		out("\tfit will not place parameter errors in variables\n")
	}
	if S.FitCovVars {
		out("\tfit will place covariances in variables\n")
	} else {
		out("\tfit will not place covariances in variables\n")
	}
	if S.FitErrScaling {
		out("\tfit will scale parameter errors with the reduced chi square\n")
	} else {
		out("\tfit will not scale parameter errors with the reduced chi square\n")
	}
	if S.FitLog {
		if S.FitLogFile == "" {
			out("\tlog-file for fits is unchanged from the environment default of\n\t\t'fit.log'\n")
		} else {
			out("\tlog-file for fits was set by the user to \n\t\t'%s'\n", S.FitLogFile)
		}
	}
	out("\tfits will be considered to have converged if  delta chisq < chisq * %s\n", fmtShowNum(S.FitLimit))
	if S.FitMaxIter > 0 {
		out("\tfit will stop after a maximum of %d iterations\n", S.FitMaxIter)
	} else {
		out("\tfit has no limit in the number of iterations\n")
	}
	out("\tfit will default to `unitweights` if no `error`keyword is given on the command line.\n")
	out("\tfit can run the following command when interrupted:\n\t\t'replot'\n\n")
}

func showTics(axes []string) {
	out := func(f string, a ...interface{}) { fmt.Fprintf(stderr, f, a...) }
	out("\n\ttics are in back of plot\n")
	for _, a := range axes {
		ax := S.Axes[a]
		io := "IN"
		if ax.TicOut {
			io = "OUT"
		}
		out("\t%s-axis tics are %s, \tmajor ticscale is %s and minor ticscale is %s\n", a, io, fmtShowNum(S.TicScaleMaj), fmtShowNum(S.TicScaleMin))
		if !ax.Tics {
			out("\t%s-axis tics:\tOFF\n", a)
			continue
		}
		if ax.Mirror {
			out("\t%s-axis tics:\ton border and mirrored on opposite border\n", a)
		} else {
			out("\t%s-axis tics:\ton border\n", a)
		}
		out("\t  labels are justified automatically, format \"%s\" and are not rotated,\n\t    offset (character 0, 0, 0)\n", ax.Format)
		if ax.TicStep > 0 {
			if !ax.TicStartSet {
				out("\t  series by %s\n", fmtShowNum(ax.TicStep))
			} else if ax.TicStartSet {
				if ax.TicEndSet {
					out("\t  series from %s by %s until %s\n", fmtShowNum(ax.TicStart), fmtShowNum(ax.TicStep), fmtShowNum(ax.TicEnd))
				} else {
					out("\t  series from %s by %s\n", fmtShowNum(ax.TicStart), fmtShowNum(ax.TicStep))
				}
			} else {
				out("\t  series from 0 by %s\n", fmtShowNum(ax.TicStep))
			}
		} else if ax.TicStep < 0 {
			out("\t  no auto-generated tics\n\t  explicit list (")
			for i, it := range ax.TicList {
				if i > 0 {
					out(", ")
				}
				if it.HasL {
					out("\"%s\" ", it.Label)
				}
				out("%s", cfmtNum("%#g", it.Pos))
			}
			out(")\n")
		} else {
			out("\t  intervals computed automatically\n")
		}
	}
	out("\tScales for user tic levels 2-4 are:  1, 1, 1\n\n")
}
