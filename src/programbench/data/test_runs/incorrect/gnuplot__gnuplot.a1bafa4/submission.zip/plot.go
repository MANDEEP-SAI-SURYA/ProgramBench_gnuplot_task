package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type Pt struct {
	X, Y, Z float64
	Ex     []float64
	Typ    byte // 'i','o','u'
	Brk    bool
	Label  string
}

type Curve struct {
	Title     string
	NoTitle   bool
	Style     string
	Pts       []Pt
	IsFunc    bool
	Smooth    string
	Bins      bool
	BinsN     int
	LT        int
	PT        int
	Is3D      bool
	Iso       [][]Pt // for splot surfaces
	ColHeadTitle bool
	Axes      string
	PtsExplicit bool
	Missing bool
}

type PlotItem struct {
	isFunc    bool
	expr      *Node
	exprText  string
	file      string
	using     []UsingEntry
	hasUsing  bool
	usingText string
	index     [3]int
	hasIndex  bool
	every     [6]int
	hasEvery  bool
	title     string
	hasTitle  bool
	notitle   bool
	colhead   bool
	colheadN  int
	style     string
	smooth    string
	bins      bool
	binsN     int
	lt        int
	pt        int
	defText   string
	sampleRange *[2]float64
	iterVars map[string]Value
	sampleVar  string
}

type UsingEntry struct {
	col  int
	name string
	expr *Node
	isExpr bool
}

var lastPlotLine string
var lastPlotToks []Token
var lastPlotIs3D bool

func parseUsing(ps *Parser) []UsingEntry {
	var out []UsingEntry
	for {
		var e UsingEntry
		if ps.isOp("(") {
			e.expr = ps.parsePrimary()
			e.isExpr = true
		} else if ps.cur().K == TNUM {
			e.col = int(ps.cur().Num.Real())
			ps.next()
		} else if ps.isOp("-") && ps.peek(1).K == TNUM {
			ps.next()
			e.col = -int(ps.cur().Num.Real())
			ps.next()
		} else if ps.cur().K == TSTR {
			e.name = ps.cur().Str
			e.col = -99
			ps.next()
		} else if ps.cur().K == TNAME || ps.cur().K == TDOLLAR {
			e.expr = ps.parsePostfix()
			e.isExpr = true
		} else {
			break
		}
		out = append(out, e)
		if ps.isOp(":") {
			ps.next()
			continue
		}
		break
	}
	return out
}

func parseStyleOpts(ps *Parser, it *PlotItem) {
	for !ps.atEnd() && !ps.isOp(",") {
		switch {
		case ps.isName("lt") || ps.almost("linet$ype") || ps.isName("ls") || ps.almost("lines$tyle"):
			isLT := ps.isName("lt") || ps.almost("linet$ype")
			ps.next()
			v := intExpr(ps)
			if isLT {
				it.lt = v
			}
		case ps.isName("lw") || ps.almost("linew$idth") || ps.isName("ps") || ps.almost("points$ize") || ps.isName("dt") || ps.almost("dasht$ype") || ps.isName("pi") || ps.isName("pn") || ps.almost("pointi$nterval") || ps.almost("pointn$umber"):
			ps.next()
			if ps.isName("variable") || ps.isName("solid") {
				ps.next()
			} else {
				constExpr(ps)
			}
		case ps.isName("pt") || ps.almost("pointt$ype"):
			ps.next()
			if ps.cur().K == TSTR {
				ps.next()
			} else {
				it.pt = intExpr(ps)
			}
		case ps.isName("lc") || ps.almost("linec$olor") || ps.isName("tc") || ps.almost("textc$olor") || ps.isName("fc") || ps.almost("fillc$olor"):
			ps.next()
			skipColorSpec(ps)
		case ps.isName("fs") || ps.almost("fill$style"):
			ps.next()
			for ps.isName("solid") || ps.isName("empty") || ps.isName("pattern") || ps.isName("border") || ps.isName("noborder") || ps.isName("transparent") || ps.cur().K == TNUM {
				if ps.cur().K == TNUM {
					constExpr(ps)
					continue
				}
				if ps.isName("border") {
					ps.next()
					if ps.isName("lt") || ps.isName("lc") {
						ps.next()
						skipColorSpec(ps)
					}
					continue
				}
				ps.next()
			}
		case ps.almost("nohidden3d"), ps.almost("nocontours"), ps.almost("nosurface"), ps.almost("palette"), ps.isName("nopoint"), ps.isName("point"), ps.isName("center"), ps.isName("left"), ps.isName("right"), ps.isName("front"), ps.isName("back"), ps.isName("above"), ps.isName("below"), ps.isName("closed"), ps.isName("x1"), ps.isName("x2"), ps.isName("y1"), ps.isName("y2"), ps.isName("rotate"), ps.isName("norotate"), ps.isName("boxed"), ps.isName("hypertext"):
			if ps.isName("above") || ps.isName("below") {
				ps.next()
				if ps.isName("y") || ps.isName("x") {
					ps.next()
					ps.expectOp("=")
					constExpr(ps)
				}
				continue
			}
			ps.next()
		case ps.isName("offset"):
			ps.next()
			skipPosition(ps)
		case ps.isName("font"):
			ps.next()
			ps.next()
		default:
			return
		}
	}
}

func cmdPlot(ps *Parser, is3D bool) {
	startTok := ps.p
	_ = startTok
	lastPlotLine = ps.line
	lastPlotToks = ps.toks[ps.p:]
	lastPlotIs3D = is3D
	S2 := saveRanges()
	defer restoreRanges(S2)
	// ranges
	axesOrder := []string{"x", "y"}
	if is3D {
		axesOrder = []string{"x", "y", "z"}
	}
	if S.Parametric {
		if is3D {
			axesOrder = []string{"u", "v", "x", "y", "z"}
		} else {
			axesOrder = []string{"t", "x", "y"}
		}
	}
	dummyVar := S.Dummy1
	if S.Parametric && !is3D {
		dummyVar = "t"
	}
	ri := 0
	for ps.isOp("[") {
		ax := "x"
		if ri < len(axesOrder) {
			ax = axesOrder[ri]
		}
		// dummy var form [t=..]
		if ps.peek(1).K == TNAME && ps.peek(2).K == TOP && ps.peek(2).Text == "=" {
			if ri == 0 {
				dummyVar = ps.peek(1).Text
			}
			ps.next()
			ps.next()
			ps.toks[ps.p-1].Text = "["
			ps.p--
			// emulate "[" at current
			ps.toks[ps.p] = Token{K: TOP, Text: "[", Pos: ps.toks[ps.p].Pos}
		}
		parseRange(ps, S.Axes[ax])
		ri++
	}
	var items []*PlotItem
	for {
		if ps.atEnd() {
			if len(items) == 0 {
				gpErr(ps.cur().Pos, "function to plot expected")
			}
			break
		}
		// iteration
		var iter *IterSpec
		if ps.isName("for") {
			ps.next()
			iter = parseIter(ps)
		}
		itemStart := ps.p
		parseOne := func() *PlotItem {
			ps.p = itemStart
			pi := parsePlotItem(ps, dummyVar, is3D)
			if iter != nil {
				pi.iterVars = map[string]Value{iter.Var: gvars[iter.Var]}
			}
			return pi
		}
		if iter != nil {
			iter.each(func() {
				items = append(items, parseOne())
			})
			if len(iter.Words) == 0 && !iter.IsWords && ((iter.Step > 0 && iter.Start > iter.End) || (iter.Step < 0 && iter.Start < iter.End)) {
				// skip tokens
				parseOne()
				items = items[:len(items)]
			}
		} else {
			items = append(items, parseOne())
		}
		if ps.isOp(",") {
			ps.next()
			continue
		}
		if !ps.atEnd() {
			gpErr(ps.cur().Pos, "unexpected or unrecognized token: "+ps.cur().Text)
		}
		break
	}
	curves := buildCurves(items, dummyVar, is3D)
	allMissing := true
	for _, c := range curves {
		if !c.Missing {
			allMissing = false
		}
	}
	if allMissing {
		errNoCaret("No data in plot")
	}
	if S.Table {
		writeTable(curves, is3D)
		return
	}
	renderPlot(curves, is3D)
}

var saved3 []Axis

func saveRanges() map[string]Axis {
	m := map[string]Axis{}
	for k, v := range S.Axes {
		m[k] = *v
	}
	return m
}

func restoreRanges(m map[string]Axis) {
	for k, v := range m {
		a := S.Axes[k]
		a.Min, a.Max, a.AutoMin, a.AutoMax = v.Min, v.Max, v.AutoMin, v.AutoMax
	}
}

func parsePlotItem(ps *Parser, dummyVar string, is3D bool) *PlotItem {
	it := &PlotItem{lt: -1, pt: -1}
	st := ps.cur()
	startPos := st.Pos
	// sampling range for this item
	if ps.isOp("[") && !(st.K == TOP && false) {
		// per-item sampling range [a:b] or [t=a:b]
		ps.next()
		if ps.cur().K == TNAME && ps.peek(1).K == TOP && ps.peek(1).Text == "=" {
			it.sampleVar = ps.cur().Text
			ps.next()
			ps.next()
		}
		a := realExpr(ps)
		ps.expectOp(":")
		b := realExpr(ps)
		ps.expectOp("]")
		it.sampleRange = &[2]float64{a, b}
		st = ps.cur()
		startPos = st.Pos
	}
	isData := false
	if st.K == TSTR {
		isData = true
	} else if st.K == TDOLLAR && !(ps.peek(1).K == TOP && ps.peek(1).Text == "[") {
		if _, err := strconvAtoi(st.Text[1:]); err != nil {
			isData = true
		}
	}
	if !isData && st.K != TSTR {
		// could be a string-valued expression naming a file
		if st.K == TNAME {
			if v, ok := gvars[st.Text]; ok && v.K == STR {
				save := ps.p
				ps.next()
				if ps.atEnd() || ps.isOp(",") || ps.isName("u") || ps.almost("us$ing") || ps.almost("w$ith") || ps.almost("t$itle") || ps.almost("notit$le") || ps.almost("i$ndex") || ps.almost("ev$ery") {
					isData = true
				}
				ps.p = save
			}
		}
	}
	endDef := 0
	if isData {
		if st.K == TDOLLAR {
			it.file = st.Text
			ps.next()
		} else {
			v := constExpr(ps)
			it.file = v.S
		}
		if it.file == "" {
			it.file = lastDataFile
		}
		lastDataFile = it.file
		endDef = ps.toks[ps.p-1].End
		for {
			switch {
			case ps.almost("u$sing"):
				ps.next()
				it.using = parseUsing(ps)
				it.hasUsing = true
				endDef = ps.toks[ps.p-1].End
				continue
			case ps.almost("i$ndex"):
				ps.next()
				if ps.cur().K == TSTR {
					ps.next()
				} else {
					a := intExpr(ps)
					it.index = [3]int{a, a, 1}
					if ps.isOp(":") {
						ps.next()
						it.index[1] = intExpr(ps)
						if ps.isOp(":") {
							ps.next()
							it.index[2] = intExpr(ps)
						}
					}
				}
				it.hasIndex = true
				endDef = ps.toks[ps.p-1].End
				continue
			case ps.almost("ev$ery"):
				ps.next()
				it.every = [6]int{1, 1, 0, 0, -1, -1}
				for k := 0; k < 6; k++ {
					if ps.isOp(":") {
						ps.next()
						continue
					}
					if ps.atEnd() || ps.isOp(",") || ps.cur().K == TNAME {
						break
					}
					it.every[k] = intExpr(ps)
					if ps.isOp(":") {
						ps.next()
					} else {
						break
					}
				}
				it.hasEvery = true
				endDef = ps.toks[ps.p-1].End
				continue
			case ps.almost("s$mooth"):
				ps.next()
				if ps.cur().K == TNAME {
					it.smooth = ps.cur().Text
					ps.next()
				}
				continue
			case ps.isName("bins"):
				ps.next()
				it.bins = true
				it.binsN = S.Samples1
				if ps.isOp("=") {
					ps.next()
					it.binsN = intExpr(ps)
				}
				for ps.isName("binrange") || ps.isName("binwidth") || ps.isName("binvalue") {
					ps.next()
					if ps.isOp("[") {
						for !ps.isOp("]") {
							ps.next()
						}
						ps.next()
					} else {
						ps.expectOp("=")
						if ps.cur().K == TNAME {
							ps.next()
						} else {
							constExpr(ps)
						}
					}
				}
				continue
			}
			break
		}
		it.defText = ps.line[startPos:endDef]
	} else {
		it.isFunc = true
		save := ps.p
		it.expr = ps.parseExpr()
		_ = save
		endDef = ps.toks[ps.p-1].End
		it.exprText = ps.line[startPos:endDef]
		it.defText = it.exprText
	}
	// remaining options
	for !ps.atEnd() && !ps.isOp(",") {
		switch {
		case ps.almost("t$itle"):
			ps.next()
			if ps.almost("col$umnheader") {
				ps.next()
				it.colhead = true
				it.colheadN = -1
				if ps.isOp("(") {
					ps.next()
					it.colheadN = intExpr(ps)
					ps.expectOp(")")
				}
			} else {
				it.title = stringExpr(ps)
				it.hasTitle = true
			}
			for ps.isName("at") || ps.almost("enh$anced") || ps.almost("noenh$anced") {
				if ps.isName("at") {
					ps.next()
					ps.next()
					continue
				}
				ps.next()
			}
		case ps.almost("notit$le"):
			ps.next()
			it.notitle = true
			if ps.cur().K == TSTR {
				ps.next()
			}
		case ps.almost("w$ith"):
			ps.next()
			s := matchStyle(ps.cur().Text)
			if s == "" {
				gpErr(ps.peek(1).Pos, "unrecognized plot type")
			}
			ps.next()
			it.style = s
			parseStyleOpts(ps, it)
		case ps.isName("axes") || ps.isName("axis"):
			ps.next()
			ps.next()
		case ps.isName("lt") || ps.almost("linet$ype") || ps.isName("ls") || ps.isName("lw") || ps.isName("lc") || ps.isName("pt") || ps.isName("ps") || ps.isName("dt") || ps.isName("fs") || ps.almost("linec$olor") || ps.almost("linew$idth") || ps.almost("pointt$ype") || ps.almost("points$ize"):
			parseStyleOpts(ps, it)
		case ps.almost("s$mooth"):
			ps.next()
			if ps.cur().K == TNAME {
				it.smooth = ps.cur().Text
				ps.next()
			}
		default:
			gpErr(ps.cur().Pos, "unexpected or unrecognized token: "+ps.cur().Text)
		}
	}
	if it.style == "" {
		if it.isFunc {
			it.style = S.StyleFunc
		} else {
			it.style = S.StyleData
		}
	}
	return it
}

var lastDataFile string

func strconvAtoi(s string) (int, error) {
	var v int
	if s == "" {
		return 0, fmt.Errorf("empty")
	}
	for i := 0; i < len(s); i++ {
		if !isDigit(s[i]) {
			return 0, fmt.Errorf("nd")
		}
		v = v*10 + int(s[i]-'0')
	}
	return v, nil
}

func smoothName(s string) string {
	for _, n := range []string{"unique", "frequency", "fnormal", "cumulative", "cnormal", "csplines", "acsplines", "mcsplines", "bezier", "sbezier", "kdensity", "unwrap", "path", "zsort"} {
		if strings.HasPrefix(n, s) && len(s) >= 1 {
			return n
		}
	}
	return s
}

func buildCurves(items []*PlotItem, dummy string, is3D bool) []*Curve {
	var curves []*Curve
	xa := S.Axes["x"]
	// first pass: data curves
	for _, it := range items {
		if it.isFunc {
			continue
		}
		for k, v := range it.iterVars {
			gvars[k] = v
		}
		c := readDataCurve(it, is3D)
		curves = append(curves, c)
		_ = c
	}
	// determine x range for functions
	xmin, xmax := xa.Min, xa.Max
	if xa.AutoMin || xa.AutoMax {
		lo, hi := math.Inf(1), math.Inf(-1)
		for _, c := range curves {
			for _, p := range c.Pts {
				if p.Brk || p.Typ == 'u' {
					continue
				}
				lo = math.Min(lo, p.X)
				hi = math.Max(hi, p.X)
			}
		}
		if !math.IsInf(lo, 1) {
			if xa.AutoMin {
				xmin = lo
			}
			if xa.AutoMax {
				xmax = hi
			}
			if !S.Table && !is3D {
				xmin, xmax = extendRange(xa, xmin, xmax, xa.AutoMin, xa.AutoMax)
			}
		}
	}
	// assemble in original order
	var out []*Curve
	di := 0
	for _, it := range items {
		if !it.isFunc {
			out = append(out, curves[di])
			di++
			continue
		}
		if is3D {
			out = append(out, sampleSurface(it))
			continue
		}
		for k, v := range it.iterVars {
			gvars[k] = v
		}
		out = append(out, sampleFunc(it, dummy, xmin, xmax))
	}
	return out
}

func sampleFunc(it *PlotItem, dummy string, xmin, xmax float64) *Curve {
	c := &Curve{Title: it.exprText, Style: it.style, IsFunc: true, LT: it.lt, PT: it.pt}
	if it.hasTitle {
		c.Title = it.title
	}
	c.NoTitle = it.notitle
	n := S.Samples1
	if it.sampleRange != nil {
		xmin, xmax = it.sampleRange[0], it.sampleRange[1]
	}
	if it.sampleVar != "" {
		dummy = it.sampleVar
	}
	xa := S.Axes["x"]
	ya := S.Axes["y"]
	old, had := gvars[dummy]
	for i := 0; i < n; i++ {
		var x float64
		if xa.Log {
			lmin, lmax := math.Log(xmin), math.Log(xmax)
			x = math.Exp(lmin + float64(i)*(lmax-lmin)/float64(n-1))
		} else {
			x = xmin + float64(i)*(xmax-xmin)/float64(n-1)
		}
		gvars[dummy] = FltV(x)
		undefinedFlag = false
		var v Value
		func() {
			defer func() {
				if r := recover(); r != nil {
					if _, ok := r.(*GPError); ok {
						panic(r)
					}
					panic(r)
				}
			}()
			v = evalNode(it.expr)
		}()
		p := Pt{X: x}
		if undefinedFlag || v.K == STR {
			p.Typ = 'u'
			p.X, p.Y = 0, 0
		} else {
			v = v.Num()
			if v.Imag() != 0 && math.Abs(v.Imag()) > 1e-8*math.Abs(v.Real()) || math.IsNaN(v.Real()) {
				p.Typ = 'u'
				p.X, p.Y = 0, 0
			} else {
				p.Y = v.Real()
				p.Typ = 'i'
				if (!ya.AutoMin && p.Y < math.Min(ya.Min, ya.Max)) || (!ya.AutoMax && p.Y > math.Max(ya.Min, ya.Max)) {
					p.Typ = 'o'
				}
				if math.IsInf(p.Y, 0) {
					p.Typ = 'u'
				}
				if ya.Log && p.Y <= 0 {
					p.Typ = 'u'
				}
			}
		}
		c.Pts = append(c.Pts, p)
	}
	undefinedFlag = false
	if had {
		gvars[dummy] = old
	} else {
		delete(gvars, dummy)
	}
	return c
}

func sampleSurface(it *PlotItem) *Curve {
	c := &Curve{Title: it.exprText, Style: it.style, IsFunc: true, Is3D: true, LT: it.lt}
	if it.hasTitle {
		c.Title = it.title
	}
	c.NoTitle = it.notitle
	xa, ya := S.Axes["x"], S.Axes["y"]
	xmin, xmax := xa.Min, xa.Max
	ymin, ymax := ya.Min, ya.Max
	nx := S.Samples1
	ny := S.Iso1
	// isolines along x for each y (iso2 count of y lines) and along y for each x
	nyIso := S.Iso2
	_ = ny
	ox, hx := gvars[S.Dummy1]
	oy, hy := gvars[S.Dummy2]
	evalAt := func(x, y float64) Pt {
		gvars[S.Dummy1] = FltV(x)
		gvars[S.Dummy2] = FltV(y)
		undefinedFlag = false
		v := evalNode(it.expr)
		p := Pt{X: x, Y: y, Typ: 'i'}
		if undefinedFlag || v.K == STR {
			p.Typ = 'u'
		} else {
			p.Z = v.Num().Real()
		}
		return p
	}
	for j := 0; j < nyIso; j++ {
		y := ymin + float64(j)*(ymax-ymin)/float64(nyIso-1)
		var row []Pt
		for i := 0; i < nx; i++ {
			x := xmin + float64(i)*(xmax-xmin)/float64(nx-1)
			row = append(row, evalAt(x, y))
		}
		c.Iso = append(c.Iso, row)
	}
	// cross isolines
	nxIso := 0
	ns := S.Samples2
	var cross [][]Pt
	for i := 0; i < nxIso; i++ {
		x := xmin + float64(i)*(xmax-xmin)/float64(nxIso-1)
		var row []Pt
		for j := 0; j < ns; j++ {
			y := ymin + float64(j)*(ymax-ymin)/float64(ns-1)
			row = append(row, evalAt(x, y))
		}
		cross = append(cross, row)
	}
	c.Iso = append(c.Iso, cross...)
	c.Pts = nil
	undefinedFlag = false
	if hx {
		gvars[S.Dummy1] = ox
	} else {
		delete(gvars, S.Dummy1)
	}
	if hy {
		gvars[S.Dummy2] = oy
	} else {
		delete(gvars, S.Dummy2)
	}
	return c
}

func styleCols(style string, is3D bool) int {
	switch style {
	case "yerrorbars", "xerrorbars", "yerrorlines", "xerrorlines":
		return 3
	case "xyerrorbars", "xyerrorlines", "boxxyerror":
		return 4
	case "boxerrorbars":
		return 3
	case "labels":
		return 3
	case "vectors":
		return 4
	case "candlesticks", "financebars":
		return 5
	}
	if is3D {
		return 3
	}
	return 2
}

func readDataCurve(it *PlotItem, is3D bool) *Curve {
	c := &Curve{Style: it.style, LT: it.lt, PT: it.pt, Smooth: smoothName(it.smooth), Bins: it.bins, BinsN: it.binsN}
	c.Title = it.defText
	if it.hasTitle {
		c.Title = it.title
	}
	c.NoTitle = it.notitle
	lines, ok := readDataLines(it.file)
	if !ok {
		if strings.HasPrefix(it.file, "$") {
			errNoCaret("undefined datablock " + it.file)
		}
		flushOut()
		fmt.Fprintf(stderr, "%swarning: Cannot find or open file \"%s\"\n", errLocation(), it.file)
		c.Missing = true
		return c
	}
	df := parseData(lines)
	var heads []string
	needHead := it.colhead || S.DFColumnHeaders
	for _, u := range it.using {
		if u.col == -99 {
			needHead = true
		}
		if u.isExpr && nodeUses(u.expr, "columnhead") {
			needHead = true
		}
	}
	if needHead && len(df.sets) > 0 && len(df.sets[0].blocks) > 0 && len(df.sets[0].blocks[0]) > 0 {
		heads = df.sets[0].blocks[0][0].fields
		for i := range heads {
			heads[i] = strings.Trim(heads[i], "\"")
		}
		df.sets[0].blocks[0] = df.sets[0].blocks[0][1:]
		if it.colhead {
			k := 2
			if len(it.using) >= 2 {
				if it.using[1].col > 0 {
					k = it.using[1].col
				}
			} else if len(it.using) == 1 && it.using[0].col > 0 {
				k = it.using[0].col
			}
			if it.colheadN > 0 {
				k = it.colheadN
			}
			if k-1 < len(heads) {
				c.Title = heads[k-1]
			}
		}
	}
	ncols := styleCols(it.style, is3D)
	using := it.using
	xa, ya := S.Axes["x"], S.Axes["y"]
	first := true
	for si, set := range df.sets {
		dsPoint := -1
		if it.hasIndex {
			if si < it.index[0] || si > it.index[1] || (si-it.index[0])%it.index[2] != 0 {
				continue
			}
		}
		for bi, blk := range set.blocks {
			if it.hasEvery {
				e := it.every
				if bi < e[3] || (e[5] >= 0 && bi > e[5]) || (bi-e[3])%e[1] != 0 {
					continue
				}
			}
			if !first {
				c.Pts = append(c.Pts, Pt{Brk: true})
			}
			first = false
			for pi, row := range blk {
				dsPoint++
				if it.hasEvery {
					e := it.every
					if pi < e[2] || (e[4] >= 0 && pi > e[4]) || (pi-e[2])%e[0] != 0 {
						continue
					}
				}
				curRow = &rowCtx{fields: row.fields, pointNo: dsPoint, blockNo: bi, setNo: si, heads: heads}
				vals, typ, skip, label := evalUsing(using, row.fields, ncols, it.hasUsing, it.style)
				curRow = nil
				if skip {
					continue
				}
				p := Pt{Typ: typ, Label: label}
				if len(vals) > 0 {
					p.X = vals[0]
				}
				if len(vals) > 1 {
					p.Y = vals[1]
				}
				if is3D && len(vals) > 2 {
					p.Z = vals[2]
					p.Ex = vals[3:]
				} else if len(vals) > 2 {
					p.Ex = vals[2:]
				}
				if p.Typ == 'u' && ((!xa.AutoMin && p.X < math.Min(xa.Min, xa.Max)) || (!xa.AutoMax && p.X > math.Max(xa.Min, xa.Max))) {
					continue
				}
				if p.Typ == 'i' {
					if (!xa.AutoMin && p.X < math.Min(xa.Min, xa.Max)) || (!xa.AutoMax && p.X > math.Max(xa.Min, xa.Max)) {
						p.Typ = 'o'
					}
					if (!ya.AutoMin && p.Y < math.Min(ya.Min, ya.Max)) || (!ya.AutoMax && p.Y > math.Max(ya.Min, ya.Max)) {
						p.Typ = 'o'
					}
				}
				c.Pts = append(c.Pts, p)
			}
		}
	}
	return c
}

func nodeUses(n *Node, fn string) bool {
	if n == nil {
		return false
	}
	if n.Op == "call" && n.Name == fn {
		return true
	}
	for _, k := range n.Kids {
		if nodeUses(k, fn) {
			return true
		}
	}
	return false
}

// evalUsing returns values, point type, skip flag
func evalUsing(using []UsingEntry, fields []string, ncols int, hasUsing bool, style string) ([]float64, byte, bool, string) {
	if !hasUsing {
		// default columns
		for _, f := range fields {
			if _, ok := fieldNum(f); !ok {
				return nil, 0, true, ""
			}
		}
		if len(fields) == 0 {
			return nil, 0, true, ""
		}
		var vals []float64
		if len(fields) == 1 {
			v, _ := fieldNum(fields[0])
			vals = []float64{float64(curRow.pointNo), v}
		} else {
			for i := 0; i < len(fields) && i < ncols; i++ {
				v, _ := fieldNum(fields[i])
				vals = append(vals, v)
			}
		}
		return vals, 'i', false, ""
	}
	var vals []float64
	typ := byte('i')
	label := ""
	for k, u := range using {
		if style == "labels" && k == len(using)-1 && k >= 2 {
			// label column: string
			if u.isExpr {
				undefinedFlag = false
				v := evalNode(u.expr)
				label = v.String()
				undefinedFlag = false
			} else if u.col >= 1 && u.col <= len(fields) {
				label = strings.Trim(fields[u.col-1], "\"")
			}
			continue
		}
		if u.isExpr {
			undefinedFlag = false
			v := evalNode(u.expr)
			if undefinedFlag || v.K == STR {
				if curRow.missing {
					return nil, 0, true, ""
				}
				vals = append(vals, math.NaN())
				typ = 'u'
				undefinedFlag = false
				continue
			}
			vals = append(vals, v.Num().Real())
			continue
		}
		col := u.col
		if u.col == -99 {
			col = colIndexFromValue(StrV(u.name))
		}
		switch {
		case col == 0:
			vals = append(vals, float64(curRow.pointNo))
		case col == -1:
			vals = append(vals, float64(curRow.blockNo))
		case col == -2:
			vals = append(vals, float64(curRow.setNo))
		case col >= 1 && col <= len(fields):
			f, ok := fieldNum(fields[col-1])
			if !ok {
				return nil, 0, true, ""
			}
			vals = append(vals, f)
		default:
			return nil, 0, true, ""
		}
	}
	if len(using) == 1 {
		vals = []float64{float64(curRow.pointNo), vals[0]}
	}
	return vals, typ, false, label
}

func extendRange(a *Axis, lo, hi float64, amin, amax bool) (float64, float64) {
	if lo == hi {
		if lo == 0 {
			lo, hi = -1, 1
		} else {
			d := math.Abs(lo) * 0.01
			lo, hi = lo-d, hi+d
		}
	}
	if a.Log {
		return lo, hi
	}
	step := ticStep(lo, hi, a)
	a.autoStep = step
	if amin {
		lo = math.Floor(lo/step+1e-9) * step
	}
	if amax {
		hi = math.Ceil(hi/step-1e-9) * step
	}
	return lo, hi
}

// gnuplot's quantize_normal_tics
func quantizeTics(arg float64, guide float64) float64 {
	power := math.Pow(10, math.Floor(math.Log10(arg)))
	xnorm := arg / power
	posns := guide / xnorm
	var tics float64
	if posns > 40 {
		tics = 0.05
	} else if posns > 20 {
		tics = 0.1
	} else if posns > 10 {
		tics = 0.2
	} else if posns > 4 {
		tics = 0.5
	} else if posns > 2 {
		tics = 1
	} else if posns > 0.5 {
		tics = 2
	} else {
		tics = math.Ceil(xnorm)
	}
	return tics * power
}

func ticStep(lo, hi float64, a *Axis) float64 {
	if a.TicStep > 0 {
		return a.TicStep
	}
	return quantizeTics(math.Abs(hi-lo), 20)
}

func fmtTableNum(f float64) string {
	if math.IsNaN(f) {
		return " NaN"
	}
	return cfmtNum("% g", f)
}

func tableWriter() func(string) {
	if S.TableBlock != "" {
		return func(s string) {
			parts := strings.Split(s, "\n")
			if len(parts) > 0 && parts[len(parts)-1] == "" {
				parts = parts[:len(parts)-1]
			}
			datablocks[S.TableBlock] = append(datablocks[S.TableBlock], parts...)
		}
	}
	if S.TableFile != "" {
		return func(s string) {
			appendFile(S.TableFile, s)
		}
	}
	return func(s string) { outWrite(s) }
}

func writeTable(curves []*Curve, is3D bool) {
	w := tableWriter()
	var b strings.Builder
	if is3D {
		writeTable3D(&b, curves)
		w(b.String())
		return
	}
	for ci, c := range curves {
		pts := applySmooth(c)
		hdr := "x y"
		switch c.Style {
		case "yerrorbars", "yerrorlines":
			hdr = "x y ylow yhigh"
		case "xerrorbars", "xerrorlines":
			hdr = "x y xlow xhigh"
		case "xyerrorbars", "xyerrorlines":
			hdr = "x y xlow xhigh ylow yhigh"
		case "labels":
			hdr = "x y label"
		case "boxes":
			hdr = "x y"
		}
		if c.Bins {
			hdr = "x y  N"
			if c.Style == "boxes" {
				hdr = "x y xlow xhigh  N"
			}
		}
		fmt.Fprintf(&b, "\n# Curve %d of %d, %d points\n# Curve title: \"%s\"\n# %s type\n", ci, len(curves), len(pts), c.Title, hdr)
		for _, p := range pts {
			if p.Brk && c.Style != "labels" {
				b.WriteString("\n")
				continue
			}
			if c.Bins {
				b.WriteString(fmtTableNum(p.X) + " " + fmtTableNum(p.Y))
				if c.Style == "boxes" {
					b.WriteString(" " + fmtTableNum(p.Ex[0]) + " " + fmtTableNum(p.Ex[1]))
				}
				fmt.Fprintf(&b, " %5d %c\n", int(p.Ex[2]), p.Typ)
				continue
			}
			if c.Style == "labels" {
				if p.Brk {
					continue
				}
				fmt.Fprintf(&b, "%s %s \"%s\"\n", fmtTableNum(p.X), fmtTableNum(p.Y), p.Label)
				continue
			}
			b.WriteString(fmtTableNum(p.X))
			b.WriteString(" ")
			b.WriteString(fmtTableNum(p.Y))
			ex := tableExtra(c.Style, p)
			for _, e := range ex {
				b.WriteString(" ")
				b.WriteString(fmtTableNum(e))
			}
			b.WriteString("  ")
			b.WriteByte(p.Typ)
			b.WriteString("\n")
		}
		b.WriteString("\n")
	}
	w(b.String())
}

func tableExtra(style string, p Pt) []float64 {
	switch style {
	case "yerrorbars", "yerrorlines":
		if len(p.Ex) == 1 {
			return []float64{p.Y - p.Ex[0], p.Y + p.Ex[0]}
		}
		if len(p.Ex) >= 2 {
			return p.Ex[:2]
		}
	case "xerrorbars", "xerrorlines":
		if len(p.Ex) == 1 {
			return []float64{p.X - p.Ex[0], p.X + p.Ex[0]}
		}
		if len(p.Ex) >= 2 {
			return p.Ex[:2]
		}
	case "xyerrorbars", "xyerrorlines":
		if len(p.Ex) == 2 {
			return []float64{p.X - p.Ex[0], p.X + p.Ex[0], p.Y - p.Ex[1], p.Y + p.Ex[1]}
		}
		if len(p.Ex) >= 4 {
			return p.Ex[:4]
		}
	}
	return nil
}

func writeTable3D(b *strings.Builder, curves []*Curve) {
	for ci, c := range curves {
		fmt.Fprintf(b, "\n# Surface %d of %d surfaces\n", ci, len(curves))
		if c.IsFunc {
			fmt.Fprintf(b, "\n# Curve title: \"%s\"\n", c.Title)
			for k, row := range c.Iso {
				fmt.Fprintf(b, "\n# IsoCurve %d, %d points\n# x y z type\n", k, len(row))
				for _, p := range row {
					fmt.Fprintf(b, "%s %s %s %c\n", fmtTableNum(p.X), fmtTableNum(p.Y), fmtTableNum(p.Z), p.Typ)
				}
			}
			b.WriteString("\n")
			continue
		}
		fmt.Fprintf(b, "\n# Curve title: \"%s\"\n", c.Title)
		blocks := [][]Pt{{}}
		for _, p := range c.Pts {
			if p.Brk {
				blocks = append(blocks, []Pt{})
				continue
			}
			blocks[len(blocks)-1] = append(blocks[len(blocks)-1], p)
		}
		for k, row := range blocks {
			fmt.Fprintf(b, "\n# IsoCurve %d, %d points\n# x y z type\n", k, len(row))
			for _, p := range row {
				fmt.Fprintf(b, "%s %s %s %c\n", fmtTableNum(p.X), fmtTableNum(p.Y), fmtTableNum(p.Z), p.Typ)
			}
		}
		b.WriteString("\n")
	}
}

var _ = sort.Float64s
