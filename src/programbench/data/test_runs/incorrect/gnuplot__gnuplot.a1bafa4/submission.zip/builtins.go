package main

import (
	"fmt"
	"math"
	"math/cmplx"
	"os/exec"
	"strings"
	"time"
)

var builtinArgc = map[string]int{
	"abs": 1, "acos": 1, "acosh": 1, "airy": 1, "arg": 1, "asin": 1, "asinh": 1, "atan": 1, "atan2": 2, "atanh": 1,
	"besj0": 1, "besj1": 1, "besy0": 1, "besy1": 1, "besjn": 2, "besyn": 2, "besi0": 1, "besi1": 1,
	"ceil": 1, "cos": 1, "cosh": 1, "erf": 1, "erfc": 1, "exp": 1, "expint": 2, "floor": 1, "gamma": 1,
	"ibeta": 3, "inverf": 1, "igamma": 2, "imag": 1, "invnorm": 1, "int": 1, "lambertw": 1, "lgamma": 1,
	"log": 1, "log10": 1, "norm": 1, "rand": 1, "real": 1, "sgn": 1, "sin": 1, "sinh": 1, "sqrt": 1,
	"tan": 1, "tanh": 1, "voigt": 2, "conj": 1,
	"strlen": 1, "strstrt": 2, "substr": 3, "strftime": 2, "strptime": 2, "system": 1, "word": 2, "words": 1,
	"trim": 1, "value": 1, "exists": 1, "valid": 1, "column": 1, "columnhead": 1, "stringcolumn": 1, "strcol": 1,
	"timecolumn": -1, "time": 1, "tm_hour": 1, "tm_mday": 1, "tm_min": 1, "tm_mon": 1, "tm_sec": 1, "tm_wday": 1,
	"tm_yday": 1, "tm_year": 1, "hsv2rgb": 3, "rgbcolor": 1, "sprintf": -1, "gprintf": 2, "EllipticK": 1, "EllipticE": 1,
	"EllipticPi": 2, "weekdate_iso": 3, "weekdate_cdc": 3, "invigamma": 2, "invibeta": 3, "zeta": 1, "cerf": 1,
}

func argErr(name string) {
	errNoCaret("wrong number of arguments")
}

func callFunc(n *Node) Value {
	name := n.Name
	if uf, ok := gfuncs[name]; ok {
		if len(n.Kids) != len(uf.Params) {
			if len(uf.Params) == 1 {
				errNoCaret(fmt.Sprintf("function %s requires %d variable", name, len(uf.Params)))
			}
			errNoCaret(fmt.Sprintf("function %s requires %d variables", name, len(uf.Params)))
		}
		args := make([]Value, len(n.Kids))
		for i, k := range n.Kids {
			args[i] = evalNode(k)
		}
		saved := make([]Value, len(uf.Params))
		had := make([]bool, len(uf.Params))
		for i, p := range uf.Params {
			saved[i], had[i] = gvars[p]
			gvars[p] = args[i]
		}
		defer func() {
			for i, p := range uf.Params {
				if had[i] {
					gvars[p] = saved[i]
				} else {
					delete(gvars, p)
				}
			}
		}()
		return evalNode(uf.Body)
	}
	argc, ok := builtinArgc[name]
	if !ok {
		errNoCaret("undefined function: " + name)
	}
	if argc >= 0 && len(n.Kids) != argc {
		if len(n.Kids) < argc {
			gpErr(n.Pos, "not enough arguments")
		}
	}
	args := make([]Value, len(n.Kids))
	for i, k := range n.Kids {
		args[i] = evalNode(k)
	}
	return callBuiltin(name, args, n)
}

func num1(args []Value) Value { return args[0].Num() }
func f1(args []Value) float64 { return args[0].Num().Real() }

func cfun(v Value, f func(float64) float64, cf func(complex128) complex128) Value {
	v = v.Num()
	if v.Imag() != 0 && cf != nil {
		r := cf(complex(v.R, v.Im))
		return CplxV(real(r), imag(r))
	}
	return FltV(f(v.Real()))
}

func checkRange(v Value) Value {
	if v.K == CMPLX && (math.IsInf(v.R, 0) || math.IsNaN(v.R)) {
		return setUndef()
	}
	return v
}

func callBuiltin(name string, args []Value, n *Node) Value {
	switch name {
	case "abs":
		v := num1(args)
		if v.K == INT {
			if v.I < 0 {
				return IntV(-v.I)
			}
			return v
		}
		return FltV(cmplx.Abs(complex(v.R, v.Im)))
	case "sgn":
		v := num1(args)
		r := v.Real()
		if r > 0 {
			return IntV(1)
		} else if r < 0 {
			return IntV(-1)
		}
		return IntV(0)
	case "real":
		return FltV(num1(args).Real())
	case "imag":
		return FltV(num1(args).Imag())
	case "conj":
		v := num1(args)
		return CplxV(v.Real(), -v.Imag())
	case "arg":
		v := num1(args)
		return FltV(math.Atan2(v.Imag(), v.Real()))
	case "sin":
		return cfun(args[0], math.Sin, cmplx.Sin)
	case "cos":
		return cfun(args[0], math.Cos, cmplx.Cos)
	case "tan":
		return cfun(args[0], math.Tan, cmplx.Tan)
	case "sinh":
		return checkRange(cfun(args[0], math.Sinh, cmplx.Sinh))
	case "cosh":
		return checkRange(cfun(args[0], math.Cosh, cmplx.Cosh))
	case "tanh":
		return cfun(args[0], math.Tanh, cmplx.Tanh)
	case "asin":
		v := num1(args)
		if v.Imag() == 0 && math.Abs(v.Real()) <= 1 {
			return FltV(math.Asin(v.Real()))
		}
		r := cmplx.Asin(complex(v.Real(), v.Imag()))
		return CplxV(real(r), imag(r))
	case "acos":
		v := num1(args)
		if v.Imag() == 0 && math.Abs(v.Real()) <= 1 {
			return FltV(math.Acos(v.Real()))
		}
		r := cmplx.Acos(complex(v.Real(), v.Imag()))
		return CplxV(real(r), imag(r))
	case "atan":
		return cfun(args[0], math.Atan, cmplx.Atan)
	case "atan2":
		return FltV(math.Atan2(args[0].Num().Real(), args[1].Num().Real()))
	case "asinh":
		return cfun(args[0], math.Asinh, cmplx.Asinh)
	case "acosh":
		v := num1(args)
		if v.Imag() == 0 && v.Real() >= 1 {
			return FltV(math.Acosh(v.Real()))
		}
		r := cmplx.Acosh(complex(v.Real(), v.Imag()))
		return CplxV(real(r), imag(r))
	case "atanh":
		v := num1(args)
		if v.Imag() == 0 && math.Abs(v.Real()) < 1 {
			return FltV(math.Atanh(v.Real()))
		}
		r := cmplx.Atanh(complex(v.Real(), v.Imag()))
		return CplxV(real(r), imag(r))
	case "exp":
		v := num1(args)
		if v.Imag() != 0 {
			r := cmplx.Exp(complex(v.R, v.Im))
			return CplxV(real(r), imag(r))
		}
		r := math.Exp(v.Real())
		if math.IsInf(r, 0) {
			return setUndef()
		}
		return FltV(r)
	case "log", "log10":
		v := num1(args)
		if v.Imag() == 0 && v.Real() > 0 {
			if name == "log" {
				return FltV(math.Log(v.Real()))
			}
			return FltV(math.Log10(v.Real()))
		}
		if v.Imag() == 0 && v.Real() == 0 {
			return setUndef()
		}
		r := cmplx.Log(complex(v.Real(), v.Imag()))
		if name == "log10" {
			r = r / complex(math.Ln10, 0)
		}
		return CplxV(real(r), imag(r))
	case "sqrt":
		v := num1(args)
		if v.Imag() == 0 && v.Real() >= 0 {
			return FltV(math.Sqrt(v.Real()))
		}
		r := cmplx.Sqrt(complex(v.Real(), v.Imag()))
		return CplxV(real(r), imag(r))
	case "floor", "ceil", "int", "round":
		v := num1(args)
		if v.K == INT {
			return v
		}
		r := v.Real()
		switch name {
		case "floor":
			r = math.Floor(r)
		case "ceil":
			r = math.Ceil(r)
		case "int":
			r = math.Trunc(r)
		case "round":
			r = math.Round(r)
		}
		if math.IsNaN(r) || math.Abs(r) > 9.2e18 {
			if name == "int" {
				return setUndef()
			}
			return FltV(r)
		}
		return IntV(int64(r))
	case "gamma":
		x := f1(args)
		r := math.Gamma(x)
		if math.IsInf(r, 0) || math.IsNaN(r) {
			return setUndef()
		}
		return FltV(r)
	case "lgamma":
		r, _ := math.Lgamma(f1(args))
		return FltV(r)
	case "erf":
		return FltV(math.Erf(f1(args)))
	case "erfc":
		return FltV(math.Erfc(f1(args)))
	case "inverf":
		return FltV(math.Erfinv(f1(args)))
	case "norm":
		return FltV(0.5 * math.Erfc(-f1(args)/math.Sqrt2))
	case "invnorm":
		x := f1(args)
		if x <= 0 || x >= 1 {
			return setUndef()
		}
		return FltV(-math.Sqrt2 * math.Erfcinv(2*x))
	case "besj0":
		return FltV(math.J0(f1(args)))
	case "besj1":
		return FltV(math.J1(f1(args)))
	case "besy0":
		x := f1(args)
		if x <= 0 {
			return setUndef()
		}
		return FltV(math.Y0(x))
	case "besy1":
		x := f1(args)
		if x <= 0 {
			return setUndef()
		}
		return FltV(math.Y1(x))
	case "besjn":
		return FltV(math.Jn(int(args[0].Num().Real()), args[1].Num().Real()))
	case "besyn":
		return FltV(math.Yn(int(args[0].Num().Real()), args[1].Num().Real()))
	case "besi0":
		return FltV(besI(0, f1(args)))
	case "besi1":
		return FltV(besI(1, f1(args)))
	case "igamma":
		return FltV(igamma(args[0].Num().Real(), args[1].Num().Real()))
	case "ibeta":
		return FltV(ibeta(args[0].Num().Real(), args[1].Num().Real(), args[2].Num().Real()))
	case "lambertw":
		return FltV(lambertw(f1(args)))
	case "voigt":
		return FltV(voigt(args[0].Num().Real(), args[1].Num().Real()))
	case "expint":
		return FltV(expint(int(args[0].Num().Real()), args[1].Num().Real()))
	case "airy":
		return FltV(airyAi(f1(args)))
	case "EllipticK":
		k := f1(args)
		return FltV(ellipK(k))
	case "EllipticE":
		return FltV(ellipE(f1(args)))
	case "rand":
		return FltV(gpRand(args[0].Num()))
	case "strlen":
		if args[0].K != STR {
			errNoCaret("internal error : strlen of non-STRING argument")
		}
		return IntV(int64(len([]rune(args[0].S))))
	case "strstrt":
		if args[0].K != STR || args[1].K != STR {
			errNoCaret("strstrt() arguments must be strings")
		}
		i := strings.Index(args[0].S, args[1].S)
		return IntV(int64(i + 1))
	case "substr":
		if args[0].K != STR {
			errNoCaret("substr() first argument must be a string")
		}
		return StrV(substrGP(args[0].S, int(args[1].Num().Real()), int(args[2].Num().Real())))
	case "trim":
		return StrV(strings.Trim(args[0].S, " \t\n\r"))
	case "word", "words":
		if args[0].K != STR {
			errNoCaret(name + "() argument must be a string")
		}
		ws := splitWords(args[0].S)
		if name == "words" {
			return IntV(int64(len(ws)))
		}
		k := int(args[1].Num().Real())
		if k < 1 || k > len(ws) {
			return StrV("")
		}
		return StrV(ws[k-1])
	case "system":
		if args[0].K != STR {
			errNoCaret("non-string argument to system()")
		}
		flushOut()
		out, _ := exec.Command("/bin/sh", "-c", args[0].S).Output()
		s := string(out)
		s = strings.TrimSuffix(s, "\n")
		return StrV(s)
	case "value":
		if args[0].K != STR {
			return args[0]
		}
		v, ok := gvars[args[0].S]
		if !ok {
			return setUndef()
		}
		return v
	case "exists":
		if args[0].K != STR {
			errNoCaret("exists() argument must be a string")
		}
		v, ok := gvars[args[0].S]
		return BoolV(ok && v.K != UNDEF)
	case "sprintf":
		if len(args) < 1 || args[0].K != STR {
			errNoCaret("First parameter to sprintf must be a format string")
		}
		return StrV(gpSprintf(args[0].S, args[1:]))
	case "gprintf":
		if args[0].K != STR {
			errNoCaret("First parameter to gprintf must be a format string")
		}
		return StrV(gprintf(args[0].S, args[1].Num().Real()))
	case "strftime":
		if args[0].K != STR {
			errNoCaret("First parameter to strftime must be a format string")
		}
		return StrV(gpStrftime(args[0].S, args[1].Num().Real()))
	case "strptime":
		if args[0].K != STR || args[1].K != STR {
			errNoCaret("Both parameters to strptime must be strings")
		}
		t, ok := gpStrptime(args[0].S, args[1].S)
		if !ok {
			return setUndef()
		}
		return FltV(t)
	case "time":
		now := float64(time.Now().UnixNano()) / 1e9
		if args[0].K == STR {
			return StrV(gpStrftime(args[0].S, now))
		}
		if args[0].K == INT {
			return IntV(int64(now))
		}
		return FltV(now)
	case "tm_sec", "tm_min", "tm_hour", "tm_mday", "tm_mon", "tm_year", "tm_wday", "tm_yday":
		t := args[0].Num().Real()
		tt := time.Unix(int64(math.Floor(t)), 0).UTC()
		switch name {
		case "tm_sec":
			return FltV(float64(tt.Second()) + t - math.Floor(t))
		case "tm_min":
			return FltV(float64(tt.Minute()))
		case "tm_hour":
			return FltV(float64(tt.Hour()))
		case "tm_mday":
			return FltV(float64(tt.Day()))
		case "tm_mon":
			return FltV(float64(tt.Month()) - 1)
		case "tm_year":
			return FltV(float64(tt.Year()))
		case "tm_wday":
			return FltV(float64(tt.Weekday()))
		case "tm_yday":
			return FltV(float64(tt.YearDay() - 1))
		}
	case "hsv2rgb":
		h, s, v := args[0].Num().Real(), args[1].Num().Real(), args[2].Num().Real()
		r, g, b := hsv2rgb(h, s, v)
		return IntV(int64(r)<<16 | int64(g)<<8 | int64(b))
	case "rgbcolor":
		if args[0].K != STR {
			errNoCaret("rgbcolor() requires string")
		}
		c, ok := parseColorName(args[0].S)
		if !ok {
			return IntV(0)
		}
		return IntV(int64(c))
	case "column", "stringcolumn", "strcol", "columnhead", "valid", "timecolumn":
		return dataFunc(name, args, n)
	}
	errNoCaret("undefined function: " + name)
	return Value{}
}

func splitWords(s string) []string {
	// gnuplot word(): whitespace separated; quoted strings count as one word
	var out []string
	i := 0
	for i < len(s) {
		for i < len(s) && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]
			j := i + 1
			for j < len(s) && s[j] != q {
				j++
			}
			out = append(out, s[i+1:j])
			i = j + 1
			continue
		}
		j := i
		for j < len(s) && !(s[j] == ' ' || s[j] == '\t' || s[j] == '\n') {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

func hsv2rgb(h, s, v float64) (int, int, int) {
	var r, g, b float64
	if s == 0 {
		r, g, b = v, v, v
	} else {
		h = h - math.Floor(h)
		h *= 6
		i := math.Floor(h)
		f := h - i
		p := v * (1 - s)
		q := v * (1 - s*f)
		t := v * (1 - s*(1-f))
		switch int(i) {
		case 0:
			r, g, b = v, t, p
		case 1:
			r, g, b = q, v, p
		case 2:
			r, g, b = p, v, t
		case 3:
			r, g, b = p, q, v
		case 4:
			r, g, b = t, p, v
		default:
			r, g, b = v, p, q
		}
	}
	return int(r*255 + 0.5), int(g*255 + 0.5), int(b*255 + 0.5)
}

// random generator (L'Ecuyer)
var rseed1, rseed2 int64 = 12345, 67890

func gpRand(arg Value) float64 {
	a := arg.Real()
	if a < 0 {
		rseed1, rseed2 = 12345, 67890
		return 0
	}
	if a > 0 && arg.K == INT {
		rseed1 = int64(a)
		rseed2 = int64(a)
		return 0
	}
	if a > 0 {
		rseed1 = int64(a)
		rseed2 = int64(a)
		return 0
	}
	k := rseed1 / 53668
	rseed1 = 40014*(rseed1-k*53668) - k*12211
	if rseed1 < 0 {
		rseed1 += 2147483563
	}
	k = rseed2 / 52774
	rseed2 = 40692*(rseed2-k*52774) - k*3791
	if rseed2 < 0 {
		rseed2 += 2147483399
	}
	z := rseed1 - rseed2
	if z < 1 {
		z += 2147483562
	}
	return float64(z) * 4.656613057e-10
}
