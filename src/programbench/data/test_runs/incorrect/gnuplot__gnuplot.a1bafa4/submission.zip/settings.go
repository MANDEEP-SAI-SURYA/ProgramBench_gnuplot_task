package main

import (
	"fmt"
	"math"
	"os"
	"strings"
)

type Axis struct {
	Name             string
	Min, Max         float64
	AutoMin, AutoMax bool
	Reverse          bool
	Writeback        bool
	Log              bool
	LogBase          float64
	Label            string
	Format           string
	FormatSet        bool
	Tics             bool
	Mirror           bool
	TicStep          float64 // 0 = auto
	TicStart         float64
	TicEnd           float64
	TicStartSet      bool
	TicEndSet        bool
	TicList          []TicItem
	TicAdd           bool
	MinorTics        int // 0 = off/default; >0 explicit
	MinorSet         bool
	Time             bool
	ZeroAxis         bool
	TicOut           bool
	Rotate           bool
	Grid, MGrid      bool
	autoStep float64
	curMin, curMax float64
	curSet bool
	// computed ranges for plotting
	dmin, dmax float64
}

type TicItem struct {
	Pos   float64
	Label string
	HasL  bool
	Minor bool
}

type Label struct {
	Tag   int
	Text  string
	X, Y  float64
	Coord string
	Just  string
	Point bool
}

type Settings struct {
	Samples1, Samples2 int
	Iso1, Iso2         int
	Axes               map[string]*Axis
	Title              string
	KeyOn              bool
	KeyPos             string // "top right" etc
	KeyHoriz           string // left/right/center
	KeyVert            string // top/bottom/center
	KeyOutside         bool
	KeyBox             bool
	KeyReverse         bool
	KeyJust            string // Right/Left
	KeyTitle           string
	KeySamplen         float64
	KeySpacing         float64
	KeyInvert          bool
	KeyHorizontal      bool
	KeyColumns         int
	KeyAtSet           bool
	StyleData          string
	StyleFunc          string
	Table              bool
	TableFile          string
	TableBlock         string
	TableAppend        bool
	TableSep           string
	Term               string
	TermW, TermH       int
	TermFeed           bool
	TermEnhanced       bool
	SvgW, SvgH         int
	Output             string
	Angles             string
	Dummy1, Dummy2     string
	Parametric         bool
	Polar              bool
	Border             int
	DFSep              string
	DFMissing          string
	DFComments         string
	DFColumnHeaders    bool
	Timefmt            string
	FitLog             bool
	FitLogFile         string
	FitQuiet           string // "", "quiet", "results", "brief", "verbose"
	FitErrVars         bool
	FitCovVars         bool
	FitPrescale        bool
	FitLimit           float64
	FitMaxIter         int
	FitErrScaling      bool
	FitStartLambda     float64
	FitLambdaFactor    float64
	Clip               bool
	PointSize          float64
	BoxWidth           float64
	BoxWidthRel        bool
	FillStyle          string
	FillDensity        float64
	Labels             []*Label
	Offsets            [4]float64
	Grid               bool
	Bars               float64
	Zero               float64
	DecimalSign        string
	Multiplot          bool
	MinusSign          bool
	Encoding           string
	View               [4]float64
	Hidden3d           bool
	Surface            bool
	Contour            string
	Smooth             string
	XYPlane            float64
	XYPlaneRel         bool
	TicScaleMaj        float64
	TicScaleMin        float64
	Histogram          string
	Lmargin, Rmargin, Tmargin, Bmargin float64
	OriginX, OriginY   float64
	SizeX, SizeY       float64
	Mapping            string
	Locale             string
	Datafile           string
}

var S *Settings

func newAxis(name string) *Axis {
	a := &Axis{Name: name, AutoMin: true, AutoMax: true, Min: -10, Max: 10, LogBase: 10, Format: "% h", Tics: true, Mirror: true}
	if name == "x2" || name == "y2" {
		a.Tics = false
	}
	if name == "z" {
		a.Mirror = false
	}
	if name == "cb" {
		a.Min, a.Max = 0, 10
	}
	return a
}

func resetSettings() {
	s := &Settings{}
	s.Samples1, s.Samples2 = 100, 100
	s.Iso1, s.Iso2 = 10, 10
	s.Axes = map[string]*Axis{}
	for _, n := range []string{"x", "y", "z", "x2", "y2", "cb", "r", "t", "u", "v"} {
		s.Axes[n] = newAxis(n)
	}
	s.Axes["t"].Min, s.Axes["t"].Max = -5, 5
	s.Axes["u"].Min, s.Axes["u"].Max = -5, 5
	s.Axes["v"].Min, s.Axes["v"].Max = -5, 5
	s.Axes["r"].Min, s.Axes["r"].Max = 0, 10
	s.KeyOn = true
	s.KeyHoriz = "right"
	s.KeyVert = "top"
	s.KeyJust = "Right"
	s.KeySamplen = 4
	s.KeySpacing = 1
	s.StyleData = "points"
	s.StyleFunc = "lines"
	if S != nil {
		s.Term = S.Term
		s.TermW, s.TermH = S.TermW, S.TermH
		s.TermFeed = S.TermFeed
		s.Output = S.Output
		s.SvgW, s.SvgH = S.SvgW, S.SvgH
		s.TermEnhanced = S.TermEnhanced
	} else {
		s.Term = "unknown"
		s.TermW, s.TermH = 79, 24
		s.TermFeed = true
		s.SvgW, s.SvgH = 600, 480
	}
	s.Angles = "radians"
	s.Dummy1, s.Dummy2 = "x", "y"
	s.Border = 31
	s.DFComments = "#"
	s.Timefmt = "%d/%m/%y,%H:%M"
	s.FitLogFile = ""
	s.FitLog = true
	s.FitErrVars = true
	s.FitPrescale = true
	s.FitLimit = 1e-5
	s.FitErrScaling = true
	s.FitLambdaFactor = 10
	s.PointSize = 1
	s.BoxWidth = -1
	s.FillStyle = "empty"
	s.Bars = 1
	s.Zero = 1e-8
	s.View = [4]float64{60, 30, 1, 1}
	s.Surface = true
	s.XYPlane = 0.5
	s.XYPlaneRel = true
	s.TicScaleMaj, s.TicScaleMin = 1, 0.5
	s.Lmargin, s.Rmargin, s.Tmargin, s.Bmargin = -1, -1, -1, -1
	s.SizeX, s.SizeY = 1, 1
	S = s
}

func axisFromPrefix(w string, suffix string) (string, bool) {
	for _, a := range []string{"x2", "y2", "cb", "x", "y", "z", "r", "t", "u", "v"} {
		if w == a+suffix {
			return a, true
		}
	}
	return "", false
}

func parseRange(ps *Parser, ax *Axis) {
	ps.expectOp("[")
	// [min:max]
	if ps.isOp(":") {
		ps.next()
	} else if ps.isOp("*") {
		ps.next()
		ax.AutoMin = true
		ps.expectOp(":")
	} else if ps.isOp("]") {
		ps.next()
		goto rest
	} else {
		v := rangeVal(ps, ax)
		ax.Min = v
		ax.AutoMin = false
		if !ps.isOp(":") {
			if ps.atEnd() {
				gpErr(ps.cur().Pos, "constant expression required")
			}
			gpErr(ps.cur().Pos, "':' expected")
		}
		ps.next()
	}
	if ps.isOp("]") {
		ps.next()
		goto rest
	}
	if ps.isOp("*") {
		ps.next()
		ax.AutoMax = true
	} else {
		v := rangeVal(ps, ax)
		ax.Max = v
		ax.AutoMax = false
	}
	if !ps.isOp("]") {
		gpErr(ps.cur().Pos, "']' expected")
	}
	ps.next()
rest:
	for !ps.atEnd() {
		switch {
		case ps.almost("rev$erse"):
			ax.Reverse = true
		case ps.almost("norev$erse"):
			ax.Reverse = false
		case ps.almost("wr$iteback"):
			ax.Writeback = true
		case ps.almost("nowr$iteback"):
			ax.Writeback = false
		case ps.almost("ext$end"), ps.almost("noext$end"):
		default:
			return
		}
		ps.next()
	}
}

func rangeVal(ps *Parser, ax *Axis) float64 {
	if ps.atEnd() {
		gpErr(ps.cur().Pos, "constant expression required")
	}
	v := constExpr(ps)
	if v.K == STR && ax.Time {
		t, ok := gpStrptime(S.Timefmt, v.S)
		if ok {
			return t
		}
	}
	return v.Num().Real()
}

func parseLabelText(ps *Parser) string {
	if ps.atEnd() {
		return ""
	}
	s, ok := tryString(ps)
	if ok {
		return s
	}
	return ""
}

func skipTextOptions(ps *Parser) {
	for !ps.atEnd() {
		switch {
		case ps.almost("off$set"):
			ps.next()
			skipPosition(ps)
			continue
		case ps.almost("font"), ps.almost("tc"), ps.almost("textc$olor"):
			ps.next()
			skipColorSpec(ps)
			continue
		case ps.almost("rot$ate"):
			ps.next()
			if ps.isName("by") {
				ps.next()
				constExpr(ps)
			} else if ps.almost("para$llel") {
				ps.next()
			}
			continue
		case ps.almost("norot$ate"), ps.isName("left"), ps.isName("right"), ps.isName("center"), ps.almost("enh$anced"), ps.almost("noenh$anced"), ps.isName("front"), ps.isName("back"):
			ps.next()
			continue
		}
		return
	}
}

func skipPosition(ps *Parser) {
	for k := 0; k < 3; k++ {
		for ps.isName("first") || ps.isName("second") || ps.isName("graph") || ps.isName("screen") || ps.almost("char$acter") {
			ps.next()
		}
		constExpr(ps)
		if !ps.isOp(",") {
			return
		}
		ps.next()
	}
}

func skipColorSpec(ps *Parser) {
	// after font/tc: consume a string or lt N / rgb "x" / palette ...
	if ps.cur().K == TSTR {
		ps.next()
		return
	}
	if ps.almost("rgb$color") {
		ps.next()
		if ps.isName("variable") {
			ps.next()
		} else {
			constExpr(ps)
		}
		return
	}
	if ps.isName("lt") || ps.almost("linet$ype") || ps.isName("ls") || ps.almost("lines$tyle") {
		ps.next()
		constExpr(ps)
		return
	}
	if ps.isName("palette") {
		ps.next()
		if ps.isName("frac") || ps.isName("cb") || ps.isName("z") {
			ps.next()
			if !ps.atEnd() && !ps.isName("z") {
				constExpr(ps)
			}
		}
		return
	}
	if ps.isName("variable") || ps.isName("default") || ps.isName("bgnd") || ps.isName("black") {
		ps.next()
		return
	}
	if !ps.atEnd() {
		constExpr(ps)
	}
}

func cmdSet(ps *Parser) {
	t := ps.cur()
	if t.K != TNAME {
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
	w := t.Text
	if a, ok := axisFromPrefix(w, "range"); ok || almostEquals(w, "xr$ange") || almostEquals(w, "yr$ange") || almostEquals(w, "zr$ange") {
		if !ok {
			a = w[:1]
		}
		ps.next()
		parseRange(ps, S.Axes[a])
		return
	}
	if a, ok := axisFromPrefix(w, "label"); ok || almostEquals(w, "xl$abel") || almostEquals(w, "yl$abel") || almostEquals(w, "zl$abel") {
		if !ok {
			a = w[:1]
		}
		ps.next()
		S.Axes[a].Label = parseLabelText(ps)
		skipTextOptions(ps)
		return
	}
	if a, ok := axisFromPrefix(w, "tics"); ok || almostEquals(w, "xt$ics") || almostEquals(w, "yt$ics") || almostEquals(w, "zt$ics") {
		if !ok {
			a = w[:1]
		}
		ps.next()
		setTics(ps, S.Axes[a])
		return
	}
	if a, ok := axisFromPrefix(w, "data"); ok && a != "" && w != "data" {
		ps.next()
		if ps.isName("time") {
			ps.next()
			S.Axes[a].Time = true
		} else {
			S.Axes[a].Time = false
		}
		return
	}
	if a, ok := axisFromPrefix(w, "zeroaxis"); ok {
		ps.next()
		S.Axes[a].ZeroAxis = true
		skipLineStyle(ps)
		return
	}
	if strings.HasPrefix(w, "m") {
		if a, ok := axisFromPrefix(w[1:], "tics"); ok {
			ps.next()
			S.Axes[a].MinorSet = true
			S.Axes[a].MinorTics = -1
			if !ps.atEnd() {
				S.Axes[a].MinorTics = intExpr(ps)
			}
			return
		}
	}
	if a, ok := axisFromPrefix(w, ""); ok && false {
		_ = a
	}
	if strings.HasPrefix(w, "format") || w == "fo" || w == "for" || w == "form" || w == "forma" {
		ps.next()
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		if ps.cur().K == TNAME {
			n := ps.cur().Text
			switch n {
			case "x", "y", "z", "x2", "y2", "cb", "r":
				axes = []string{n}
				ps.next()
			case "xy":
				axes = []string{"x", "y"}
				ps.next()
			}
		}
		f := "% h"
		if !ps.atEnd() {
			f = stringExpr(ps)
		}
		for _, a := range axes {
			S.Axes[a].Format = f
			S.Axes[a].FormatSet = true
		}
		for !ps.atEnd() {
			ps.next()
		}
		return
	}
	ps.next()
	switch {
	case almostEquals(w, "sa$mples"):
		S.Samples1 = intExpr(ps)
		S.Samples2 = S.Samples1
		if ps.isOp(",") {
			ps.next()
			S.Samples2 = intExpr(ps)
		}
		if S.Samples1 < 2 || S.Samples2 < 2 {
			errNoCaret("sampling rate must be > 1; sampling unchanged")
		}
	case almostEquals(w, "iso$samples"):
		S.Iso1 = intExpr(ps)
		S.Iso2 = S.Iso1
		if ps.isOp(",") {
			ps.next()
			S.Iso2 = intExpr(ps)
		}
	case almostEquals(w, "log$scale"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		base := 10.0
		if !ps.atEnd() && ps.cur().K == TNAME {
			axes = splitAxes(ps.cur().Text)
			ps.next()
		}
		if !ps.atEnd() {
			base = realExpr(ps)
		}
		for _, a := range axes {
			if ax, ok := S.Axes[a]; ok {
				ax.Log = true
				ax.LogBase = base
			}
		}
	case almostEquals(w, "tit$le"):
		S.Title = parseLabelText(ps)
		skipTextOptions(ps)
	case almostEquals(w, "k$ey"):
		setKey(ps)
	case almostEquals(w, "st$yle"):
		setStyle(ps)
	case almostEquals(w, "ta$ble"):
		S.Table = true
		S.TableFile = ""
		S.TableBlock = ""
		if ps.cur().K == TDOLLAR {
			S.TableBlock = ps.cur().Text
			ps.next()
			datablocks[S.TableBlock] = nil
		} else if !ps.atEnd() && !ps.isName("append") && !ps.almost("sep$arator") {
			S.TableFile = stringExpr(ps)
		}
		S.TableAppend = false
		for !ps.atEnd() {
			if ps.isName("append") {
				S.TableAppend = true
			}
			ps.next()
		}
		if S.TableFile != "" && !S.TableAppend {
			os.WriteFile(S.TableFile, nil, 0644)
		}
	case almostEquals(w, "t$erminal"):
		setTerminal(ps)
	case almostEquals(w, "o$utput"):
		closeOutputs()
		if ps.atEnd() {
			S.Output = ""
		} else {
			S.Output = stringExpr(ps)
			os.WriteFile(S.Output, nil, 0644)
		}
	case almostEquals(w, "pr$int"):
		if printFile != nil {
			printFile.Close()
			printFile = nil
		}
		printToBlock = ""
		printName = ""
		if ps.atEnd() {
			return
		}
		if ps.cur().K == TDOLLAR {
			printToBlock = ps.cur().Text
			ps.next()
			app := false
			if ps.isName("append") {
				app = true
				ps.next()
			}
			if !app {
				datablocks[printToBlock] = nil
			} else if _, ok := datablocks[printToBlock]; !ok {
				datablocks[printToBlock] = nil
			}
			return
		}
		name := stringExpr(ps)
		app := false
		if ps.isName("append") {
			app = true
			ps.next()
		}
		printName = name
		if name == "-" {
			return
		}
		if name == "<stderr>" || name == "" {
			printName = ""
			return
		}
		flag := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if app {
			flag = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		f, err := os.OpenFile(name, flag, 0644)
		if err == nil {
			printFile = f
		}
	case almostEquals(w, "an$gles"):
		if ps.almost("d$egrees") {
			S.Angles = "degrees"
		} else {
			S.Angles = "radians"
		}
		ps.next()
	case almostEquals(w, "du$mmy"):
		if ps.cur().K == TNAME {
			S.Dummy1 = ps.cur().Text
			ps.next()
		}
		if ps.isOp(",") {
			ps.next()
			S.Dummy2 = ps.cur().Text
			ps.next()
		}
	case almostEquals(w, "pa$rametric"):
		S.Parametric = true
	case almostEquals(w, "pol$ar"):
		S.Polar = true
	case almostEquals(w, "bor$der"):
		S.Border = 31
		if !ps.atEnd() && ps.cur().K != TNAME {
			S.Border = intExpr(ps)
		}
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "g$rid"):
		S.Grid = true
		any := false
		for !ps.atEnd() {
			n := ps.cur().Text
			for _, a := range []string{"x", "y", "z", "x2", "y2", "cb"} {
				if n == a+"tics" {
					S.Axes[a].Grid = true
					any = true
				} else if n == "m"+a+"tics" {
					S.Axes[a].MGrid = true
					any = true
				} else if n == "no"+a+"tics" {
					S.Axes[a].Grid = false
					any = true
				}
			}
			ps.next()
		}
		if !any {
			S.Axes["x"].Grid = true
			S.Axes["y"].Grid = true
		}
	case almostEquals(w, "dataf$ile"):
		setDatafile(ps)
	case almostEquals(w, "timef$mt"):
		S.Timefmt = stringExpr(ps)
	case almostEquals(w, "fit"):
		setFit(ps)
	case almostEquals(w, "cl$ip"):
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "poi$ntsize"):
		S.PointSize = realExpr(ps)
	case almostEquals(w, "box$width"):
		S.BoxWidth = -1
		S.BoxWidthRel = false
		if !ps.atEnd() && !ps.isName("absolute") && !ps.isName("relative") {
			S.BoxWidth = realExpr(ps)
		}
		if ps.isName("relative") {
			S.BoxWidthRel = true
			ps.next()
		} else if ps.isName("absolute") {
			ps.next()
		}
	case almostEquals(w, "lab$el"):
		setLabel(ps)
	case almostEquals(w, "off$sets"):
		for i := 0; i < 4 && !ps.atEnd(); i++ {
			for ps.isName("graph") || ps.isName("first") {
				ps.next()
			}
			S.Offsets[i] = realExpr(ps)
			if ps.isOp(",") {
				ps.next()
			}
		}
	case almostEquals(w, "bar$s"):
		S.Bars = 1
		for !ps.atEnd() {
			if ps.cur().K == TNUM {
				S.Bars = realExpr(ps)
				continue
			}
			if ps.isName("small") {
				S.Bars = 0
			}
			if ps.isName("large") {
				S.Bars = -1
			}
			ps.next()
		}
	case almostEquals(w, "ze$ro"):
		S.Zero = realExpr(ps)
	case almostEquals(w, "dec$imalsign"):
		if !ps.atEnd() {
			S.DecimalSign = stringExpr(ps)
		}
	case almostEquals(w, "mu$ltiplot"):
		startMultiplot(ps)
	case almostEquals(w, "auto$scale"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		if !ps.atEnd() {
			n := ps.cur().Text
			ps.next()
			n = strings.TrimSuffix(n, "fixmin")
			n = strings.TrimSuffix(n, "fixmax")
			n = strings.TrimSuffix(n, "fix")
			n = strings.TrimSuffix(n, "min")
			n = strings.TrimSuffix(n, "max")
			axes = splitAxes(n)
		}
		for _, a := range axes {
			if ax, ok := S.Axes[a]; ok {
				ax.AutoMin, ax.AutoMax = true, true
			}
		}
	case almostEquals(w, "vi$ew"):
		if ps.isName("map") {
			S.View = [4]float64{0, 0, 1, 1}
			ps.next()
			return
		}
		for i := 0; i < 4 && !ps.atEnd(); i++ {
			if ps.isOp(",") {
				ps.next()
				continue
			}
			S.View[i] = realExpr(ps)
			if ps.isOp(",") {
				ps.next()
			}
		}
	case almostEquals(w, "hid$den3d"):
		S.Hidden3d = true
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "sur$face"):
		S.Surface = true
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "cont$ours"):
		S.Contour = "base"
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "tics"):
		for !ps.atEnd() {
			if ps.isName("out") || ps.isName("in") {
				out := ps.isName("out")
				for _, a := range S.Axes {
					a.TicOut = out
				}
			}
			if ps.almost("sc$ale") {
				ps.next()
				S.TicScaleMaj = realExpr(ps)
				if ps.isOp(",") {
					ps.next()
					S.TicScaleMin = realExpr(ps)
				}
				continue
			}
			ps.next()
		}
	case almostEquals(w, "xyp$lane"):
		if ps.isName("at") {
			ps.next()
			S.XYPlane = realExpr(ps)
			S.XYPlaneRel = false
		} else if ps.isName("relative") {
			ps.next()
			S.XYPlane = realExpr(ps)
			S.XYPlaneRel = true
		} else if !ps.atEnd() {
			S.XYPlane = realExpr(ps)
			S.XYPlaneRel = true
		}
	case almostEquals(w, "ticsl$evel"):
		S.XYPlane = realExpr(ps)
		S.XYPlaneRel = true
	case almostEquals(w, "lm$argin"), almostEquals(w, "rm$argin"), almostEquals(w, "tm$argin"), almostEquals(w, "bm$argin"):
		v := -1.0
		if ps.isName("at") {
			ps.next()
			ps.next()
		}
		if !ps.atEnd() {
			v = realExpr(ps)
		}
		switch w[0] {
		case 'l':
			S.Lmargin = v
		case 'r':
			S.Rmargin = v
		case 't':
			S.Tmargin = v
		case 'b':
			S.Bmargin = v
		}
	case almostEquals(w, "mar$gins"):
		vals := []*float64{&S.Lmargin, &S.Rmargin, &S.Bmargin, &S.Tmargin}
		for i := 0; i < 4 && !ps.atEnd(); i++ {
			*vals[i] = realExpr(ps)
			if ps.isOp(",") {
				ps.next()
			}
		}
	case almostEquals(w, "si$ze"):
		for !ps.atEnd() {
			if ps.cur().K == TNUM {
				S.SizeX = realExpr(ps)
				if ps.isOp(",") {
					ps.next()
					S.SizeY = realExpr(ps)
				}
				continue
			}
			ps.next()
		}
	case almostEquals(w, "or$igin"):
		S.OriginX = realExpr(ps)
		if ps.isOp(",") {
			ps.next()
			S.OriginY = realExpr(ps)
		}
	case almostEquals(w, "enc$oding"), almostEquals(w, "loc$ale"), almostEquals(w, "mou$se"), almostEquals(w, "hi$story"), almostEquals(w, "obj$ect"), almostEquals(w, "arr$ow"), almostEquals(w, "pal$ette"), almostEquals(w, "colorb$ox"), almostEquals(w, "pm3d"), almostEquals(w, "lines$tyle"), almostEquals(w, "linet$ype"), almostEquals(w, "termopt$ion"), almostEquals(w, "fontp$ath"), almostEquals(w, "loadp$ath"), almostEquals(w, "psdir"), almostEquals(w, "colors$equence"), almostEquals(w, "map$ping"), almostEquals(w, "cntrp$aram"), almostEquals(w, "cntrl$abel"), almostEquals(w, "dg$rid3d"), almostEquals(w, "jitter"), almostEquals(w, "rgbmax"), almostEquals(w, "theta"), almostEquals(w, "rr$ange"), almostEquals(w, "trange"), almostEquals(w, "wall"), almostEquals(w, "micro"), almostEquals(w, "minus$sign"), almostEquals(w, "overflow"), almostEquals(w, "walls"), almostEquals(w, "pixmap"), almostEquals(w, "isosurface"), almostEquals(w, "co$lor"), almostEquals(w, "monochrome"), almostEquals(w, "rtics"), almostEquals(w, "ttics"), almostEquals(w, "raxis"), almostEquals(w, "paxis"), almostEquals(w, "spider$plot"), almostEquals(w, "vxr$ange"), almostEquals(w, "vyr$ange"), almostEquals(w, "vzr$ange"), almostEquals(w, "x2zeroaxis"), almostEquals(w, "isotropic"), almostEquals(w, "nonlinear"), almostEquals(w, "ve$rbose"), almostEquals(w, "ti$mestamp"), almostEquals(w, "debug"):
		for !ps.atEnd() {
			ps.next()
		}
	case almostEquals(w, "zero$axis"):
		S.Axes["x"].ZeroAxis = true
		S.Axes["y"].ZeroAxis = true
		skipLineStyle(ps)
	default:
		gpErr(t.Pos, "unrecognized option - see 'help set'.")
	}
}

func skipLineStyle(ps *Parser) {
	for !ps.atEnd() {
		ps.next()
	}
}

func splitAxes(n string) []string {
	var out []string
	for i := 0; i < len(n); i++ {
		if i+1 < len(n) && n[i:i+2] == "cb" {
			out = append(out, "cb")
			i++
			continue
		}
		if i+1 < len(n) && n[i+1] == '2' {
			out = append(out, n[i:i+2])
			i++
			continue
		}
		out = append(out, n[i:i+1])
	}
	return out
}

func setTics(ps *Parser, ax *Axis) {
	ax.Tics = true
	for !ps.atEnd() {
		switch {
		case ps.almost("ax$is"), ps.almost("bo$rder"), ps.isName("in"), ps.isName("out"), ps.almost("rangel$imited"), ps.isName("front"), ps.isName("back"), ps.almost("norot$ate"), ps.almost("enh$anced"), ps.almost("noenh$anced"), ps.isName("left"), ps.isName("right"), ps.isName("center"), ps.almost("autoj$ustify"):
			if ps.isName("out") {
				ax.TicOut = true
			}
			if ps.isName("in") {
				ax.TicOut = false
			}
			ps.next()
		case ps.almost("mi$rror"):
			ax.Mirror = true
			ps.next()
		case ps.almost("nomi$rror"):
			ax.Mirror = false
			ps.next()
		case ps.almost("rot$ate"):
			ps.next()
			if ps.isName("by") {
				ps.next()
				constExpr(ps)
			}
		case ps.almost("off$set"):
			ps.next()
			skipPosition(ps)
		case ps.almost("nooff$set"):
			ps.next()
		case ps.almost("sc$ale"):
			ps.next()
			if ps.isName("default") {
				ps.next()
			} else {
				constExpr(ps)
				if ps.isOp(",") {
					ps.next()
					constExpr(ps)
				}
			}
		case ps.isName("font"), ps.isName("tc"), ps.almost("textc$olor"):
			ps.next()
			skipColorSpec(ps)
		case ps.almost("f$ormat"):
			ps.next()
			ax.Format = stringExpr(ps)
		case ps.almost("autofreq"):
			ps.next()
			ax.TicStep = 0
			ax.TicList = nil
		case ps.isName("add"):
			ps.next()
			ax.TicAdd = true
		case ps.isOp("("):
			ps.next()
			if !ax.TicAdd {
				ax.TicList = nil
			}
			ax.TicStep = 0
			for !ps.isOp(")") {
				var item TicItem
				if ps.isStringValue() && ps.cur().K == TSTR {
					item.Label = ps.cur().Str
					item.HasL = true
					ps.next()
				}
				item.Pos = realExpr(ps)
				if !ps.isOp(",") && !ps.isOp(")") {
					m := intExpr(ps)
					item.Minor = m == 1
				}
				ax.TicList = append(ax.TicList, item)
				if ps.isOp(",") {
					ps.next()
				}
			}
			ps.next()
			ax.TicStep = -1 // explicit list only
			if ax.TicAdd {
				ax.TicStep = 0
			}
		default:
			if ps.cur().K == TNUM || ps.isOp("-") || ps.isOp("+") || ps.cur().K == TNAME {
				v1 := realExpr(ps)
				if ps.isOp(",") {
					ps.next()
					v2 := realExpr(ps)
					if ps.isOp(",") {
						ps.next()
						v3 := realExpr(ps)
						ax.TicStart, ax.TicStep, ax.TicEnd = v1, v2, v3
						ax.TicStartSet, ax.TicEndSet = true, true
					} else {
						ax.TicStart, ax.TicStep = v1, v2
						ax.TicStartSet, ax.TicEndSet = true, false
					}
				} else {
					ax.TicStep = v1
					ax.TicStartSet, ax.TicEndSet = false, false
				}
				ax.TicList = nil
				continue
			}
			gpErr(ps.cur().Pos, "unrecognized option - see 'help set'.")
		}
	}
}

func setKey(ps *Parser) {
	S.KeyOn = true
	for !ps.atEnd() {
		switch {
		case ps.almost("on"):
			S.KeyOn = true
		case ps.almost("off"):
			S.KeyOn = false
		case ps.isName("left"):
			S.KeyHoriz = "left"
		case ps.isName("right"):
			S.KeyHoriz = "right"
		case ps.almost("cent$er"):
			S.KeyHoriz = "center"
			S.KeyVert = "center"
		case ps.isName("top"):
			S.KeyVert = "top"
		case ps.almost("bot$tom"):
			S.KeyVert = "bottom"
		case ps.almost("out$side"):
			S.KeyOutside = true
		case ps.almost("ins$ide"):
			S.KeyOutside = false
		case ps.almost("b$ox"):
			S.KeyBox = true
			ps.next()
			for ps.isName("lt") || ps.isName("lw") || ps.isName("lc") || ps.isName("ls") || ps.almost("linew$idth") || ps.almost("linet$ype") {
				ps.next()
				constExpr(ps)
			}
			continue
		case ps.almost("nob$ox"):
			S.KeyBox = false
		case ps.almost("rev$erse"):
			S.KeyReverse = true
		case ps.almost("norev$erse"):
			S.KeyReverse = false
		case ps.almost("inv$ert"):
			S.KeyInvert = true
		case ps.almost("noinv$ert"):
			S.KeyInvert = false
		case ps.almost("Left"):
			S.KeyJust = "Left"
		case ps.almost("Right"):
			S.KeyJust = "Right"
		case ps.almost("hor$izontal"):
			S.KeyHorizontal = true
		case ps.almost("ver$tical"):
			S.KeyHorizontal = false
		case ps.almost("sa$mplen"):
			ps.next()
			S.KeySamplen = realExpr(ps)
			continue
		case ps.almost("sp$acing"):
			ps.next()
			S.KeySpacing = realExpr(ps)
			continue
		case ps.almost("tit$le"):
			ps.next()
			S.KeyTitle = parseLabelText(ps)
			continue
		case ps.almost("noenh$anced"), ps.almost("enh$anced"), ps.isName("opaque"), ps.isName("noopaque"), ps.isName("fixed"), ps.isName("autotitle"), ps.isName("noautotitle"), ps.isName("default"):
			if ps.isName("default") {
				S.KeyHoriz, S.KeyVert, S.KeyOutside, S.KeyBox = "right", "top", false, false
			}
		case ps.almost("col$umns"), ps.isName("maxcols"), ps.isName("maxrows"), ps.almost("wid$th"), ps.almost("hei$ght"):
			ps.next()
			if ps.isName("auto") {
				ps.next()
			} else {
				constExpr(ps)
			}
			continue
		case ps.isName("at"):
			ps.next()
			skipPosition(ps)
			S.KeyAtSet = true
			continue
		case ps.isName("font"), ps.isName("tc"), ps.almost("textc$olor"):
			ps.next()
			skipColorSpec(ps)
			continue
		default:
			gpErr(ps.cur().Pos, "unrecognized option - see 'help set'.")
		}
		ps.next()
	}
}

var styleNames = []string{"l$ines", "p$oints", "linesp$oints", "lp", "d$ots", "i$mpulses", "s$teps", "fs$teps", "his$teps", "e$rrorbars", "yerrorb$ars", "xerrorb$ars", "xye$rrorbars", "errorl$ines", "yerrorl$ines", "xerrorl$ines", "xyerrorl$ines", "b$oxes", "boxer$rorbars", "boxxy$errorbars", "fillst$eps", "filledc$urves", "labels", "vec$tors", "financebars", "candlesticks", "histograms", "image", "rgbimage", "pm3d", "boxplot", "circles", "ellipses", "surface", "parallelaxes", "table", "zerrorfill", "arrows", "sp$iderplot", "rgba$lpha", "polygons", "isosurface"}

func matchStyle(w string) string {
	for _, p := range styleNames {
		if almostEquals(w, p) {
			full := strings.Replace(p, "$", "", 1)
			if full == "lp" {
				return "linespoints"
			}
			if full == "errorbars" {
				return "yerrorbars"
			}
			if full == "errorlines" {
				return "yerrorlines"
			}
			return full
		}
	}
	return ""
}

func setStyle(ps *Parser) {
	switch {
	case ps.almost("d$ata"):
		ps.next()
		st := matchStyle(ps.cur().Text)
		if st == "" {
			gpErr(ps.peek(1).Pos, "unrecognized plot type")
		}
		ps.next()
		S.StyleData = st
	case ps.almost("f$unction"):
		ps.next()
		st := matchStyle(ps.cur().Text)
		if st == "" {
			gpErr(ps.peek(1).Pos, "unrecognized plot type")
		}
		ps.next()
		S.StyleFunc = st
	case ps.almost("fi$ll"):
		ps.next()
		for !ps.atEnd() {
			if ps.almost("s$olid") {
				S.FillStyle = "solid"
				ps.next()
				if ps.cur().K == TNUM {
					S.FillDensity = realExpr(ps)
				}
				continue
			}
			if ps.almost("e$mpty") {
				S.FillStyle = "empty"
			}
			if ps.almost("p$attern") {
				S.FillStyle = "pattern"
			}
			ps.next()
		}
	case ps.almost("hist$ogram"):
		ps.next()
		for !ps.atEnd() {
			ps.next()
		}
	default:
		for !ps.atEnd() {
			ps.next()
		}
	}
}

func setDatafile(ps *Parser) {
	switch {
	case ps.almost("miss$ing"):
		ps.next()
		if ps.atEnd() {
			S.DFMissing = ""
		} else {
			S.DFMissing = stringExpr(ps)
		}
	case ps.almost("sep$arators"):
		ps.next()
		if ps.atEnd() || ps.almost("white$space") {
			S.DFSep = ""
			if !ps.atEnd() {
				ps.next()
			}
		} else if ps.isName("tab") {
			S.DFSep = "\t"
			ps.next()
		} else if ps.isName("comma") {
			S.DFSep = ","
			ps.next()
		} else {
			S.DFSep = stringExpr(ps)
		}
	case ps.almost("com$mentschars"):
		ps.next()
		if ps.atEnd() {
			S.DFComments = "#"
		} else {
			S.DFComments = stringExpr(ps)
		}
	case ps.almost("columnhead$ers"):
		ps.next()
		S.DFColumnHeaders = true
	case ps.almost("nocolumnhead$ers"):
		ps.next()
		S.DFColumnHeaders = false
	default:
		for !ps.atEnd() {
			ps.next()
		}
	}
}

func setFit(ps *Parser) {
	for !ps.atEnd() {
		switch {
		case ps.almost("log$file"):
			ps.next()
			S.FitLog = true
			if !ps.atEnd() && ps.isStringValue() {
				S.FitLogFile = stringExpr(ps)
			}
			continue
		case ps.almost("nolog$file"):
			S.FitLog = false
		case ps.isName("quiet"):
			S.FitQuiet = "quiet"
		case ps.isName("results"):
			S.FitQuiet = "results"
		case ps.isName("brief"):
			S.FitQuiet = "brief"
		case ps.isName("verbose"):
			S.FitQuiet = "verbose"
		case ps.isName("noquiet"):
			S.FitQuiet = ""
		case ps.almost("err$orvariables"):
			S.FitErrVars = true
		case ps.almost("noerr$orvariables"):
			S.FitErrVars = false
		case ps.almost("cov$ariancevariables"):
			S.FitCovVars = true
		case ps.almost("nocov$ariancevariables"):
			S.FitCovVars = false
		case ps.almost("errors$caling"):
			S.FitErrScaling = true
		case ps.almost("noerrors$caling"):
			S.FitErrScaling = false
		case ps.isName("prescale"):
			S.FitPrescale = true
		case ps.isName("noprescale"):
			S.FitPrescale = false
		case ps.isName("limit"):
			ps.next()
			S.FitLimit = realExpr(ps)
			continue
		case ps.isName("maxiter"):
			ps.next()
			if ps.isName("default") {
				ps.next()
				S.FitMaxIter = 0
			} else {
				S.FitMaxIter = intExpr(ps)
			}
			continue
		case ps.isName("start_lambda") || ps.isName("lambda_factor"):
			isStart := ps.isName("start_lambda")
			ps.next()
			v := realExpr(ps)
			if isStart {
				S.FitStartLambda = v
			} else {
				S.FitLambdaFactor = v
			}
			continue
		case ps.isName("script"), ps.isName("v4"), ps.isName("v5"):
		default:
			ps.next()
			continue
		}
		ps.next()
	}
}

func setLabel(ps *Parser) {
	l := &Label{Just: "left"}
	if ps.cur().K == TNUM {
		l.Tag = intExpr(ps)
	} else {
		maxt := 0
		for _, x := range S.Labels {
			if x.Tag > maxt {
				maxt = x.Tag
			}
		}
		l.Tag = maxt + 1
	}
	if s, ok := tryString(ps); ok {
		l.Text = s
	}
	for !ps.atEnd() {
		switch {
		case ps.isName("at"):
			ps.next()
			l.Coord = "first"
			for ps.isName("first") || ps.isName("graph") || ps.isName("screen") || ps.almost("char$acter") {
				l.Coord = ps.cur().Text
				ps.next()
			}
			l.X = realExpr(ps)
			ps.expectOp(",")
			for ps.isName("first") || ps.isName("graph") || ps.isName("screen") || ps.almost("char$acter") {
				ps.next()
			}
			l.Y = realExpr(ps)
			if ps.isOp(",") {
				ps.next()
				realExpr(ps)
			}
		case ps.isName("left"), ps.isName("right"), ps.isName("center"), ps.almost("cent$re"):
			l.Just = ps.cur().Text
			ps.next()
		case ps.almost("po$int"):
			l.Point = true
			ps.next()
		default:
			if s, ok := tryString(ps); ok {
				l.Text = s
				continue
			}
			skipTextOptions(ps)
			if !ps.atEnd() {
				ps.next()
			}
		}
	}
	// replace existing tag
	for i, x := range S.Labels {
		if x.Tag == l.Tag {
			S.Labels[i] = l
			return
		}
	}
	S.Labels = append(S.Labels, l)
}

func setTerminal(ps *Parser) {
	if ps.atEnd() {
		return
	}
	n := ps.cur().Text
	ps.next()
	switch {
	case almostEquals(n, "dumb"):
		S.Term = "dumb"
		for !ps.atEnd() {
			if ps.isName("size") {
				ps.next()
				S.TermW = intExpr(ps)
				ps.expectOp(",")
				S.TermH = intExpr(ps)
				continue
			}
			if ps.isName("feed") {
				S.TermFeed = true
			} else if ps.isName("nofeed") {
				S.TermFeed = false
			} else if ps.cur().K == TNUM {
				S.TermW = intExpr(ps)
				if ps.isOp(",") {
					ps.next()
				}
				S.TermH = intExpr(ps)
				continue
			}
			ps.next()
		}
	case n == "svg":
		S.Term = "svg"
		S.SvgW, S.SvgH = 600, 480
		for !ps.atEnd() {
			if ps.isName("size") {
				ps.next()
				S.SvgW = intExpr(ps)
				ps.expectOp(",")
				S.SvgH = intExpr(ps)
				continue
			}
			ps.next()
		}
	case n == "canvas":
		S.Term = "canvas"
		S.SvgW, S.SvgH = 600, 400
		for !ps.atEnd() {
			if ps.isName("size") {
				ps.next()
				S.SvgW = intExpr(ps)
				ps.expectOp(",")
				S.SvgH = intExpr(ps)
				continue
			}
			ps.next()
		}
	case n == "push", n == "pop":
	case almostEquals(n, "un$known"):
		S.Term = "unknown"
	case n == "table":
		S.Term = "table"
	default:
		S.Term = n
		for !ps.atEnd() {
			ps.next()
		}
	}
	gvars["GPVAL_TERM"] = StrV(S.Term)
}

var outFile *os.File

func closeOutputs() {
	if outFile != nil {
		outFile.Close()
		outFile = nil
	}
}

func outWrite(s string) {
	if S.Output != "" {
		f, err := os.OpenFile(S.Output, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
		if err == nil {
			f.WriteString(s)
			f.Close()
		}
		return
	}
	stdout.WriteString(s)
}

func cmdUnset(ps *Parser) {
	t := ps.cur()
	w := t.Text
	ps.next()
	if a, ok := axisFromPrefix(w, "tics"); ok {
		S.Axes[a].Tics = false
		return
	}
	if a, ok := axisFromPrefix(w, "label"); ok {
		S.Axes[a].Label = ""
		return
	}
	if a, ok := axisFromPrefix(w, "range"); ok {
		S.Axes[a].AutoMin, S.Axes[a].AutoMax = true, true
		return
	}
	if strings.HasPrefix(w, "m") {
		if a, ok := axisFromPrefix(w[1:], "tics"); ok {
			S.Axes[a].MinorSet = true
			S.Axes[a].MinorTics = 0
			return
		}
	}
	if a, ok := axisFromPrefix(w, "zeroaxis"); ok {
		S.Axes[a].ZeroAxis = false
		return
	}
	if a, ok := axisFromPrefix(w, "data"); ok {
		S.Axes[a].Time = false
		return
	}
	switch {
	case almostEquals(w, "k$ey"):
		S.KeyOn = false
	case almostEquals(w, "tit$le"):
		S.Title = ""
	case almostEquals(w, "log$scale"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		if !ps.atEnd() {
			axes = splitAxes(ps.cur().Text)
			ps.next()
		}
		for _, a := range axes {
			if ax, ok := S.Axes[a]; ok {
				ax.Log = false
			}
		}
	case almostEquals(w, "ta$ble"):
		S.Table = false
		S.TableBlock = ""
		S.TableFile = ""
	case almostEquals(w, "pa$rametric"):
		S.Parametric = false
	case almostEquals(w, "pol$ar"):
		S.Polar = false
	case almostEquals(w, "bor$der"):
		S.Border = 0
	case almostEquals(w, "g$rid"):
		S.Grid = false
		for _, a := range S.Axes {
			a.Grid, a.MGrid = false, false
		}
	case almostEquals(w, "lab$el"):
		if ps.atEnd() {
			S.Labels = nil
		} else {
			tag := intExpr(ps)
			for i, x := range S.Labels {
				if x.Tag == tag {
					S.Labels = append(S.Labels[:i], S.Labels[i+1:]...)
					break
				}
			}
		}
	case almostEquals(w, "pr$int"):
		if printFile != nil {
			printFile.Close()
			printFile = nil
		}
		printToBlock = ""
		printName = ""
	case almostEquals(w, "o$utput"):
		S.Output = ""
	case almostEquals(w, "mu$ltiplot"):
		endMultiplot()
	case almostEquals(w, "tics"):
		for _, a := range S.Axes {
			a.Tics = false
		}
	case almostEquals(w, "sur$face"):
		S.Surface = false
	case almostEquals(w, "hid$den3d"):
		S.Hidden3d = false
	case almostEquals(w, "cont$ours"):
		S.Contour = ""
	case almostEquals(w, "zero$axis"):
		for _, a := range S.Axes {
			a.ZeroAxis = false
		}
	case almostEquals(w, "auto$scale"):
		axes := []string{"x", "y", "z", "x2", "y2", "cb"}
		if !ps.atEnd() {
			axes = splitAxes(ps.cur().Text)
			ps.next()
		}
		for _, a := range axes {
			if ax, ok := S.Axes[a]; ok {
				ax.AutoMin, ax.AutoMax = false, false
			}
		}
	case almostEquals(w, "dataf$ile"):
		resetDF := func() { S.DFSep = ""; S.DFMissing = ""; S.DFComments = "#" }
		if ps.atEnd() {
			resetDF()
		} else {
			if ps.almost("miss$ing") {
				S.DFMissing = ""
			} else if ps.almost("sep$arators") {
				S.DFSep = ""
			} else if ps.almost("com$mentschars") {
				S.DFComments = ""
			}
			ps.next()
		}
	default:
		for !ps.atEnd() {
			ps.next()
		}
	}
}

func fmtShowNum(f float64) string {
	return cfmtG(f, 6, false, "g")
}

var _ = math.Pi
var _ = fmt.Sprint
