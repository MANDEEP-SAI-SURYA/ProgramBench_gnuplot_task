package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

type colStats struct {
	n                                       int
	mean, sd, ssd, skew, kurt, adev, sum, sumsq float64
	meanErr, sdErr, skewErr, kurtErr        float64
	min, max                                float64
	imin, imax                              int
	median, q1, q3                          float64
}

func computeStats(v []float64) colStats {
	var s colStats
	n := len(v)
	s.n = n
	if n == 0 {
		return s
	}
	s.min, s.max = v[0], v[0]
	for i, x := range v {
		s.sum += x
		s.sumsq += x * x
		if x < s.min {
			s.min = x
			s.imin = i
		}
		if x > s.max {
			s.max = x
			s.imax = i
		}
	}
	fn := float64(n)
	s.mean = s.sum / fn
	var m2, m3, m4, ad float64
	for _, x := range v {
		d := x - s.mean
		m2 += d * d
		m3 += d * d * d
		m4 += d * d * d * d
		ad += math.Abs(d)
	}
	s.sd = math.Sqrt(m2 / fn)
	if n > 1 {
		s.ssd = math.Sqrt(m2 / (fn - 1))
	}
	s.adev = ad / fn
	if s.sd > 0 {
		s.skew = (m3 / fn) / (s.sd * s.sd * s.sd)
		s.kurt = (m4 / fn) / (s.sd * s.sd * s.sd * s.sd)
	}
	s.meanErr = s.sd / math.Sqrt(fn)
	s.sdErr = s.sd / math.Sqrt(2*fn)
	s.skewErr = math.Sqrt(6 / fn)
	s.kurtErr = math.Sqrt(24 / fn)
	sv := append([]float64{}, v...)
	sort.Float64s(sv)
	if n%2 == 0 {
		s.median = (sv[n/2-1] + sv[n/2]) / 2
	} else {
		s.median = sv[(n-1)/2]
	}
	if n%4 == 0 {
		s.q1 = (sv[n/4-1] + sv[n/4]) / 2
		s.q3 = (sv[3*n/4-1] + sv[3*n/4]) / 2
	} else {
		s.q1 = sv[n/4]
		s.q3 = sv[3*n/4]
	}
	return s
}

func cmdStats(ps *Parser) {
	it := &PlotItem{lt: -1, pt: -1}
	// file
	st := ps.cur()
	if st.K == TDOLLAR {
		it.file = st.Text
		ps.next()
	} else {
		v := constExpr(ps)
		if v.K != STR {
			errNoCaret("stats: expecting filename")
		}
		it.file = v.S
	}
	prefix := "STATS"
	output := true
	for !ps.atEnd() {
		switch {
		case ps.almost("u$sing"):
			ps.next()
			it.using = parseUsing(ps)
			it.hasUsing = true
		case ps.almost("i$ndex"):
			ps.next()
			a := intExpr(ps)
			it.index = [3]int{a, a, 1}
			if ps.isOp(":") {
				ps.next()
				it.index[1] = intExpr(ps)
			}
			it.hasIndex = true
		case ps.almost("ev$ery"):
			ps.next()
			it.every = [6]int{1, 1, 0, 0, -1, -1}
			for k := 0; k < 6; k++ {
				if ps.isOp(":") {
					ps.next()
					continue
				}
				if ps.atEnd() || ps.cur().K == TNAME {
					break
				}
				it.every[k] = intExpr(ps)
				if ps.isOp(":") {
					ps.next()
				} else {
					break
				}
			}
			it.hasEvery = true
		case ps.isName("name"):
			ps.next()
			prefix = stringExpr(ps)
		case ps.almost("nooutput"):
			ps.next()
			output = false
		case ps.almost("output"):
			ps.next()
			output = true
		case ps.isName("prefix"):
			ps.next()
			prefix = stringExpr(ps)
		default:
			gpErr(ps.cur().Pos, "Unrecognized option")
		}
	}
	lines, ok := readDataLines(it.file)
	if !ok {
		errNoCaret(fmt.Sprintf("Cannot find or open file \"%s\"", it.file))
	}
	// count blank lines
	blank := 0
	for _, l := range lines {
		if isBlank(l) {
			blank++
		}
	}
	df := parseData(lines)
	ncols := 0
	if it.hasUsing {
		ncols = len(it.using)
	}
	var xs, ys []float64
	records := 0
	fileCols := 0
	for si, set := range df.sets {
		if it.hasIndex && (si < it.index[0] || si > it.index[1]) {
			continue
		}
		dsPoint := -1
		for bi, blk := range set.blocks {
			if it.hasEvery {
				e := it.every
				if bi < e[3] || (e[5] >= 0 && bi > e[5]) || (bi-e[3])%e[1] != 0 {
					continue
				}
			}
			for pi, row := range blk {
				dsPoint++
				if it.hasEvery {
					e := it.every
					if pi < e[2] || (e[4] >= 0 && pi > e[4]) || (pi-e[2])%e[0] != 0 {
						continue
					}
				}
				curRow = &rowCtx{fields: row.fields, pointNo: dsPoint, blockNo: bi, setNo: si}
				var vals []float64
				skip := false
				if fileCols == 0 {
					fileCols = len(row.fields)
				}
				if !it.hasUsing {
					for k, f := range row.fields {
						if k >= 2 {
							break
						}
						if _, ok := fieldNum(f); !ok {
							skip = true
						}
					}
					if !skip {
						for k := 0; k < len(row.fields) && k < 2; k++ {
							f, _ := fieldNum(row.fields[k])
							vals = append(vals, f)
						}
					}
				} else {
					v, typ, sk, _ := evalUsing(it.using, row.fields, 2, true, "")
					skip = sk || typ == 'u'
					if len(it.using) == 1 && len(v) == 2 {
						v = v[1:]
					}
					vals = v
				}
				curRow = nil
				if skip || len(vals) == 0 {
					continue
				}
				if ncols == 0 {
					ncols = len(vals)
					if ncols > 2 {
						ncols = 2
					}
				}
				records++
				xs = append(xs, vals[0])
				if ncols >= 2 && len(vals) >= 2 {
					ys = append(ys, vals[1])
				}
			}
		}
	}
	nblocks := len(df.sets)
	if ncols > 2 {
		ncols = 2
	}
	if records == 0 {
		errNoCaret("All points out of range")
	}
	sx := computeStats(xs)
	var sy colStats
	two := ncols == 2 && len(ys) == len(xs)
	if two {
		sy = computeStats(ys)
	}
	// set variables
	set := func(n string, v Value) { gset(prefix+"_"+n, v) }
	set("records", IntV(int64(records)))
	set("invalid", IntV(0))
	set("headers", IntV(0))
	set("blank", IntV(int64(blank)))
	set("blocks", IntV(int64(nblocks)))
	set("outofrange", IntV(0))
	set("columns", IntV(int64(fileCols)))
	setCol := func(s colStats, suf string) {
		set("mean"+suf, FltV(s.mean))
		set("stddev"+suf, FltV(s.sd))
		set("ssd"+suf, FltV(s.ssd))
		set("skewness"+suf, FltV(s.skew))
		set("kurtosis"+suf, FltV(s.kurt))
		set("adev"+suf, FltV(s.adev))
		set("mean_err"+suf, FltV(s.meanErr))
		set("stddev_err"+suf, FltV(s.sdErr))
		set("skewness_err"+suf, FltV(s.skewErr))
		set("kurtosis_err"+suf, FltV(s.kurtErr))
		set("sum"+suf, FltV(s.sum))
		set("sumsq"+suf, FltV(s.sumsq))
		set("min"+suf, FltV(s.min))
		set("max"+suf, FltV(s.max))
		set("median"+suf, FltV(s.median))
		set("lo_quartile"+suf, FltV(s.q1))
		set("up_quartile"+suf, FltV(s.q3))
		set("index_min"+suf, IntV(int64(s.imin)))
		set("index_max"+suf, IntV(int64(s.imax)))
	}
	var slope, icpt, slopeErr, icptErr, corr, sumxy float64
	if two {
		setCol(sx, "_x")
		setCol(sy, "_y")
		n := float64(records)
		var sxx, syy, sxy float64
		for i := range xs {
			dx := xs[i] - sx.mean
			dy := ys[i] - sy.mean
			sxx += dx * dx
			syy += dy * dy
			sxy += dx * dy
			sumxy += xs[i] * ys[i]
		}
		slope = sxy / sxx
		icpt = sy.mean - slope*sx.mean
		var rss float64
		for i := range xs {
			r := ys[i] - (icpt + slope*xs[i])
			rss += r * r
		}
		s2 := rss / (n - 2)
		slopeErr = math.Sqrt(s2 / sxx)
		icptErr = math.Sqrt(s2 * (1/n + sx.mean*sx.mean/sxx))
		corr = sxy / math.Sqrt(sxx*syy)
		set("slope", FltV(slope))
		set("intercept", FltV(icpt))
		set("slope_err", FltV(slopeErr))
		set("intercept_err", FltV(icptErr))
		set("correlation", FltV(corr))
		set("sumxy", FltV(sumxy))
		set("pos_min_y", FltV(xs[sy.imin]))
		set("pos_max_y", FltV(xs[sy.imax]))
	} else {
		setCol(sx, "")
	}
	if !output {
		return
	}
	var b strings.Builder
	ln := func(label string, w int, val string) string {
		pad := w - len(label) - len(val)
		if pad < 1 {
			pad = 1
		}
		return label + strings.Repeat(" ", pad) + val
	}
	b.WriteString("\n* FILE: \n")
	b.WriteString(ln("  Records:", 22, fmt.Sprint(records)) + "\n")
	b.WriteString(ln("  Out of range:", 22, "0") + "\n")
	b.WriteString(ln("  Invalid:", 22, "0") + "\n")
	b.WriteString(ln("  Header records:", 22, "0") + "\n")
	b.WriteString(ln("  Blank:", 22, fmt.Sprint(blank)) + "\n")
	b.WriteString(ln("  Data Blocks:", 22, fmt.Sprint(nblocks)) + "\n")
	f4 := func(x float64) string { return fmt.Sprintf("%.4f", x) }
	row := func(label string, a, c float64) {
		s := ln(label, 28, f4(a))
		if two {
			s += fmt.Sprintf("%18s", f4(c))
		} else {
			s += ""
		}
		b.WriteString(s + "\n")
	}
	if two {
		b.WriteString("\n* COLUMNS:\n")
	} else {
		b.WriteString("\n* COLUMN: \n")
	}
	row("  Mean:", sx.mean, sy.mean)
	row("  Std Dev:", sx.sd, sy.sd)
	row("  Sample StdDev:", sx.ssd, sy.ssd)
	row("  Skewness:", sx.skew, sy.skew)
	row("  Kurtosis:", sx.kurt, sy.kurt)
	row("  Avg Dev:", sx.adev, sy.adev)
	row("  Sum:", sx.sum, sy.sum)
	row("  Sum Sq.:", sx.sumsq, sy.sumsq)
	b.WriteString("\n")
	row("  Mean Err.:", sx.meanErr, sy.meanErr)
	row("  Std Dev Err.:", sx.sdErr, sy.sdErr)
	row("  Skewness Err.:", sx.skewErr, sy.skewErr)
	row("  Kurtosis Err.:", sx.kurtErr, sy.kurtErr)
	b.WriteString("\n")
	mm := func(label string, a float64, ia int, c float64, ic int) {
		s := ln(label, 28, f4(a)) + fmt.Sprintf(" [%d]", ia)
		if two {
			s += fmt.Sprintf("%14s [%d]", f4(c), ic)
		}
		b.WriteString(s + "\n")
	}
	mm("  Minimum:", sx.min, sx.imin, sy.min, sy.imin)
	mm("  Maximum:", sx.max, sx.imax, sy.max, sy.imax)
	q := func(label string, a, c float64) {
		s := ln(label, 28, f4(a))
		if two {
			s += fmt.Sprintf("%18s", f4(c))
		} else {
			s += " "
		}
		b.WriteString(s + "\n")
	}
	q("  Quartile:", sx.q1, sy.q1)
	q("  Median:", sx.median, sy.median)
	q("  Quartile:", sx.q3, sy.q3)
	b.WriteString("\n")
	if two {
		sign := "+"
		ic := icpt
		if ic < 0 {
			sign = "-"
			ic = -ic
		}
		g4 := func(x float64) string { return cfmtG(x, 4, false, "") }
		b.WriteString(fmt.Sprintf("  Linear Model:       y = %s x %s %s\n", g4(slope), sign, g4(ic)))
		b.WriteString(fmt.Sprintf("  Slope:              %s +- %s\n", g4(slope), g4(slopeErr)))
		b.WriteString(fmt.Sprintf("  Intercept:          %s +- %s\n", g4(icpt), g4(icptErr)))
		b.WriteString(fmt.Sprintf("  Correlation:        r = %.4f\n", corr))
		b.WriteString(fmt.Sprintf("  Sum xy:             %s\n", g4(sumxy)))
		b.WriteString("\n")
	}
	pw := printWriter()
	pw(b.String())
}
