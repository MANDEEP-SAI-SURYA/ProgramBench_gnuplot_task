package main

import (
	"math"
	"strconv"
	"strings"
)

type Kind int

const (
	UNDEF Kind = iota
	INT
	CMPLX
	STR
	ARR
)

type Array struct {
	V []Value
}

type Value struct {
	K  Kind
	I  int64
	R  float64
	Im float64
	S  string
	A  *Array
}

func IntV(i int64) Value            { return Value{K: INT, I: i} }
func FltV(f float64) Value          { return Value{K: CMPLX, R: f} }
func CplxV(r, i float64) Value      { return Value{K: CMPLX, R: r, Im: i} }
func StrV(s string) Value           { return Value{K: STR, S: s} }
func BoolV(b bool) Value            { if b { return IntV(1) }; return IntV(0) }

// GPError is a gnuplot error raised via panic.
type GPError struct {
	Msg   string
	Pos   int // caret column, -1 = no caret
	Quiet bool
}

func gpErr(pos int, format string) {
	panic(&GPError{Msg: format, Pos: pos})
}

func errNoCaret(msg string) { panic(&GPError{Msg: msg, Pos: -1}) }

func (v Value) Real() float64 {
	switch v.K {
	case INT:
		return float64(v.I)
	case CMPLX:
		return v.R
	case STR:
		f, ok := strToNum(v.S)
		if !ok {
			errNoCaret("Non-numeric string found where a numeric expression was expected")
		}
		return f.Real()
	}
	errNoCaret("internal error: undefined value")
	return 0
}

func (v Value) Imag() float64 {
	if v.K == CMPLX {
		return v.Im
	}
	return 0
}

// numeric coerce: strings to numbers
func (v Value) Num() Value {
	if v.K == STR {
		f, ok := strToNum(v.S)
		if !ok {
			errNoCaret("Non-numeric string found where a numeric expression was expected")
		}
		return f
	}
	if v.K == ARR {
		errNoCaret("non-scalar argument")
	}
	return v
}

func strToNum(s string) (Value, bool) {
	t := strings.TrimSpace(s)
	if t == "" {
		return Value{}, false
	}
	// gnuplot uses strtod-like parse of a prefix
	end := scanNumberPrefix(t)
	if end == 0 {
		return Value{}, false
	}
	p := t[:end]
	if !strings.ContainsAny(p, ".eE") || strings.HasPrefix(strings.ToLower(p), "0x") {
		if i, err := strconv.ParseInt(p, 0, 64); err == nil {
			return IntV(i), true
		}
	}
	f, err := strconv.ParseFloat(p, 64)
	if err != nil {
		if ne, ok := err.(*strconv.NumError); ok && ne.Err == strconv.ErrRange {
			return FltV(f), true
		}
		return Value{}, false
	}
	return FltV(f), true
}

func scanNumberPrefix(t string) int {
	i := 0
	if i < len(t) && (t[i] == '+' || t[i] == '-') {
		i++
	}
	st := i
	for i < len(t) && t[i] >= '0' && t[i] <= '9' {
		i++
	}
	if i < len(t) && t[i] == '.' {
		i++
		for i < len(t) && t[i] >= '0' && t[i] <= '9' {
			i++
		}
	}
	if i == st || (i == st+1 && t[st] == '.') {
		return 0
	}
	if i < len(t) && (t[i] == 'e' || t[i] == 'E') {
		j := i + 1
		if j < len(t) && (t[j] == '+' || t[j] == '-') {
			j++
		}
		k := j
		for k < len(t) && t[k] >= '0' && t[k] <= '9' {
			k++
		}
		if k > j {
			i = k
		}
	}
	return i
}

// formatting a number the way 'print' does
func fmtReal(f float64) string {
	if math.IsNaN(f) {
		return "NaN"
	}
	s := cfmtG(f, 15, false, "g")
	if !strings.ContainsAny(s, ".e") {
		s += ".0"
	}
	return s
}

func (v Value) String() string {
	switch v.K {
	case INT:
		return strconv.FormatInt(v.I, 10)
	case CMPLX:
		if v.Im != 0 {
			return "{" + fmtReal(v.R) + ", " + fmtReal(v.Im) + "}"
		}
		return fmtReal(v.R)
	case STR:
		return v.S
	case ARR:
		var b strings.Builder
		b.WriteString("[")
		for i, e := range v.A.V {
			if i > 0 {
				b.WriteString(",")
			}
			if e.K == STR {
				b.WriteString("\"" + e.S + "\"")
			} else if e.K != UNDEF {
				b.WriteString(e.String())
			}
		}
		b.WriteString("]")
		return b.String()
	}
	return ""
}

func (v Value) Truth() bool {
	switch v.K {
	case INT:
		return v.I != 0
	case CMPLX:
		return v.R != 0 || v.Im != 0
	case STR:
		n := v.Num()
		return n.Truth()
	}
	return false
}
