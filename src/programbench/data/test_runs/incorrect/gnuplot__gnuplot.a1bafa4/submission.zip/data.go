package main

import (
	"math"
	"os"
	"strconv"
	"strings"
)

// a parsed data row
type DRow struct {
	fields []string
	line   int
}

// a dataset: list of blocks; each block list of rows
type DSet struct {
	blocks [][]DRow
}

type DFile struct {
	sets    []DSet
	headers []string
}

func readDataLines(name string) ([]string, bool) {
	if strings.HasPrefix(name, "$") {
		db, ok := datablocks[name]
		if !ok {
			return nil, false
		}
		return db, true
	}
	data, err := os.ReadFile(name)
	if err != nil {
		return nil, false
	}
	s := string(data)
	s = strings.TrimSuffix(s, "\n")
	if s == "" {
		return nil, true
	}
	return strings.Split(s, "\n"), true
}

func splitFields(l string) []string {
	if S.DFSep != "" && S.DFSep != " " {
		var out []string
		cur := ""
		inq := false
		for i := 0; i < len(l); i++ {
			c := l[i]
			if c == '"' {
				inq = !inq
				cur += string(c)
				continue
			}
			if !inq && strings.IndexByte(S.DFSep, c) >= 0 {
				out = append(out, strings.TrimSpace(cur))
				cur = ""
				continue
			}
			cur += string(c)
		}
		out = append(out, strings.TrimSpace(cur))
		return out
	}
	var out []string
	i := 0
	for i < len(l) {
		for i < len(l) && (l[i] == ' ' || l[i] == '\t' || l[i] == '\r') {
			i++
		}
		if i >= len(l) {
			break
		}
		if l[i] == '"' {
			j := i + 1
			for j < len(l) && l[j] != '"' {
				j++
			}
			if j < len(l) {
				j++
			}
			out = append(out, l[i:j])
			i = j
			continue
		}
		j := i
		for j < len(l) && !(l[j] == ' ' || l[j] == '\t' || l[j] == '\r') {
			j++
		}
		out = append(out, l[i:j])
		i = j
	}
	return out
}

func isCommentLine(l string) bool {
	t := strings.TrimLeft(l, " \t")
	if t == "" {
		return false
	}
	return strings.IndexByte(S.DFComments, t[0]) >= 0
}

func isBlank(l string) bool {
	return strings.TrimSpace(l) == ""
}

// parseData splits lines into datasets (index) and blocks
func parseData(lines []string) *DFile {
	df := &DFile{}
	cur := DSet{}
	blk := []DRow{}
	blanks := 0
	started := false
	for ln, l := range lines {
		l = strings.TrimRight(l, "\r")
		if isCommentLine(l) {
			continue
		}
		if isBlank(l) {
			blanks++
			continue
		}
		if blanks > 0 && started {
			if blanks >= 2 {
				cur.blocks = append(cur.blocks, blk)
				df.sets = append(df.sets, cur)
				cur = DSet{}
				blk = nil
			} else {
				cur.blocks = append(cur.blocks, blk)
				blk = nil
			}
		}
		blanks = 0
		started = true
		// strip trailing comments
		f := splitFields(l)
		for k, x := range f {
			if len(x) > 0 && strings.IndexByte(S.DFComments, x[0]) >= 0 && S.DFSep == "" {
				f = f[:k]
				break
			}
		}
		blk = append(blk, DRow{fields: f, line: ln})
	}
	if started {
		cur.blocks = append(cur.blocks, blk)
		df.sets = append(df.sets, cur)
	}
	return df
}

func fieldNum(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	if S.DFMissing != "" && s == S.DFMissing {
		return math.NaN(), false
	}
	if s[0] == '"' {
		s = strings.Trim(s, "\"")
	}
	end := scanNumberPrefix(s)
	if end == 0 {
		return 0, false
	}
	// gnuplot accepts Fortran D exponents and trailing garbage
	f, err := strconv.ParseFloat(s[:end], 64)
	if err != nil {
		return 0, false
	}
	return f, true
}

// current data row for column() evaluation
type rowCtx struct {
	fields  []string
	pointNo int
	blockNo int
	setNo   int
	heads   []string
	missing bool // set when a missing value was referenced
	invalid bool
}

var curRow *rowCtx

func colIndexFromValue(v Value) int {
	if v.K == STR {
		if curRow != nil {
			for i, h := range curRow.heads {
				if h == v.S {
					return i + 1
				}
			}
		}
		return -99
	}
	return int(v.Num().Real())
}

func colValue(v Value, pos int) Value {
	if curRow == nil {
		gpErr(pos, "column() called from invalid context")
	}
	c := colIndexFromValue(v)
	return colNumeric(c)
}

func colNumeric(c int) Value {
	r := curRow
	switch c {
	case 0:
		return FltV(float64(r.pointNo))
	case -1:
		return FltV(float64(r.blockNo))
	case -2:
		return FltV(float64(r.setNo))
	}
	if c < 1 || c > len(r.fields) {
		r.invalid = true
		return setUndef()
	}
	s := r.fields[c-1]
	if S.DFMissing != "" && strings.TrimSpace(s) == S.DFMissing {
		r.missing = true
		return setUndef()
	}
	f, ok := fieldNum(s)
	if !ok {
		return setUndef()
	}
	return FltV(f)
}

func dataFunc(name string, args []Value, n *Node) Value {
	if curRow == nil {
		gpErr(int(n.Val.I), name+"() called from invalid context")
	}
	switch name {
	case "column":
		return colValue(args[0], n.Pos)
	case "stringcolumn", "strcol":
		c := colIndexFromValue(args[0])
		if c < 1 || c > len(curRow.fields) {
			return setUndef()
		}
		return StrV(strings.Trim(curRow.fields[c-1], "\""))
	case "columnhead":
		c := int(args[0].Num().Real())
		if c >= 1 && c <= len(curRow.heads) {
			return StrV(curRow.heads[c-1])
		}
		return StrV("")
	case "valid":
		c := colIndexFromValue(args[0])
		if c < 1 || c > len(curRow.fields) {
			return IntV(0)
		}
		_, ok := fieldNum(curRow.fields[c-1])
		return BoolV(ok)
	case "timecolumn":
		c := colIndexFromValue(args[0])
		f := S.Timefmt
		if len(args) > 1 {
			f = args[1].S
		}
		if c < 1 || c > len(curRow.fields) {
			return setUndef()
		}
		t, ok := gpStrptime(f, strings.Join(curRow.fields[c-1:], " "))
		if !ok {
			return setUndef()
		}
		return FltV(t)
	}
	return Value{}
}
