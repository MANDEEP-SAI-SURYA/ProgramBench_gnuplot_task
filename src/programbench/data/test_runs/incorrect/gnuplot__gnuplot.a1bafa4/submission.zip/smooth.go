package main

import (
	"math"
	"os"
	"sort"
)

func appendFile(name, s string) {
	f, err := os.OpenFile(name, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return
	}
	f.WriteString(s)
	f.Close()
}

func validPts(pts []Pt) []Pt {
	var out []Pt
	for _, p := range pts {
		if p.Brk || p.Typ == 'u' {
			continue
		}
		out = append(out, p)
	}
	return out
}

// applySmooth returns points to output; for some modes it pads with blank breaks to keep count
func applySmooth(c *Curve) []Pt {
	if c.Bins {
		return doBins(c)
	}
	if c.Smooth == "" {
		return c.Pts
	}
	v := validPts(c.Pts)
	n := len(c.Pts)
	switch c.Smooth {
	case "unique", "frequency", "cumulative", "cnormal":
		sort.SliceStable(v, func(i, j int) bool { return v[i].X < v[j].X })
		var out []Pt
		for i := 0; i < len(v); {
			j := i
			sum := 0.0
			for j < len(v) && v[j].X == v[i].X {
				sum += v[j].Y
				j++
			}
			y := sum
			if c.Smooth == "unique" {
				y = sum / float64(j-i)
			}
			out = append(out, Pt{X: v[i].X, Y: y, Typ: 'i'})
			i = j
		}
		if c.Smooth == "cumulative" || c.Smooth == "cnormal" {
			acc := 0.0
			for i := range out {
				acc += out[i].Y
				out[i].Y = acc
			}
			if c.Smooth == "cnormal" && acc != 0 {
				for i := range out {
					out[i].Y /= acc
				}
			}
		}
		for len(out) < n {
			out = append(out, Pt{Brk: true})
		}
		return out
	case "csplines", "acsplines", "mcsplines":
		sort.SliceStable(v, func(i, j int) bool { return v[i].X < v[j].X })
		// merge duplicate x by averaging
		var u []Pt
		for i := 0; i < len(v); {
			j := i
			sum := 0.0
			for j < len(v) && v[j].X == v[i].X {
				sum += v[j].Y
				j++
			}
			u = append(u, Pt{X: v[i].X, Y: sum / float64(j-i)})
			i = j
		}
		return splineSample(u, c.Smooth == "mcsplines")
	case "bezier", "sbezier":
		return bezierSample(v)
	case "kdensity":
		return kdensity(v)
	}
	return c.Pts
}

func splineSample(u []Pt, mono bool) []Pt {
	n := len(u)
	ns := S.Samples1
	if n < 2 {
		return u
	}
	xs := make([]float64, n)
	ys := make([]float64, n)
	for i, p := range u {
		xs[i], ys[i] = p.X, p.Y
	}
	var eval func(x float64) float64
	if mono {
		// Fritsch-Carlson
		d := make([]float64, n-1)
		for i := 0; i < n-1; i++ {
			d[i] = (ys[i+1] - ys[i]) / (xs[i+1] - xs[i])
		}
		m := make([]float64, n)
		m[0] = d[0]
		m[n-1] = d[n-2]
		for i := 1; i < n-1; i++ {
			if d[i-1]*d[i] <= 0 {
				m[i] = 0
			} else {
				m[i] = (d[i-1] + d[i]) / 2
			}
		}
		for i := 0; i < n-1; i++ {
			if d[i] == 0 {
				m[i], m[i+1] = 0, 0
				continue
			}
			a, b := m[i]/d[i], m[i+1]/d[i]
			s := a*a + b*b
			if s > 9 {
				t := 3 / math.Sqrt(s)
				m[i] = t * a * d[i]
				m[i+1] = t * b * d[i]
			}
		}
		eval = func(x float64) float64 {
			i := sort.SearchFloat64s(xs, x) - 1
			if i < 0 {
				i = 0
			}
			if i > n-2 {
				i = n - 2
			}
			h := xs[i+1] - xs[i]
			t := (x - xs[i]) / h
			h00 := 2*t*t*t - 3*t*t + 1
			h10 := t*t*t - 2*t*t + t
			h01 := -2*t*t*t + 3*t*t
			h11 := t*t*t - t*t
			return h00*ys[i] + h10*h*m[i] + h01*ys[i+1] + h11*h*m[i+1]
		}
	} else {
		// natural cubic spline
		m := make([]float64, n)
		if n > 2 {
			a := make([]float64, n)
			b := make([]float64, n)
			cc := make([]float64, n)
			r := make([]float64, n)
			for i := 1; i < n-1; i++ {
				h0 := xs[i] - xs[i-1]
				h1 := xs[i+1] - xs[i]
				a[i] = h0
				b[i] = 2 * (h0 + h1)
				cc[i] = h1
				r[i] = 6 * ((ys[i+1]-ys[i])/h1 - (ys[i]-ys[i-1])/h0)
			}
			for i := 2; i < n-1; i++ {
				w := a[i] / b[i-1]
				b[i] -= w * cc[i-1]
				r[i] -= w * r[i-1]
			}
			for i := n - 2; i >= 1; i-- {
				m[i] = (r[i] - cc[i]*m[i+1]) / b[i]
			}
		}
		eval = func(x float64) float64 {
			i := sort.SearchFloat64s(xs, x) - 1
			if i < 0 {
				i = 0
			}
			if i > n-2 {
				i = n - 2
			}
			h := xs[i+1] - xs[i]
			A := (xs[i+1] - x) / h
			B := (x - xs[i]) / h
			return A*ys[i] + B*ys[i+1] + ((A*A*A-A)*m[i]+(B*B*B-B)*m[i+1])*h*h/6
		}
	}
	var out []Pt
	x0, x1 := xs[0], xs[n-1]
	for i := 0; i < ns; i++ {
		x := x0 + float64(i)*(x1-x0)/float64(ns-1)
		out = append(out, Pt{X: x, Y: eval(x), Typ: 'i'})
	}
	return out
}

func bezierSample(v []Pt) []Pt {
	n := len(v)
	ns := S.Samples1
	if n < 2 {
		return v
	}
	var out []Pt
	for k := 0; k < ns; k++ {
		t := float64(k) / float64(ns-1)
		// de Casteljau via binomial
		x, y := 0.0, 0.0
		for i := 0; i < n; i++ {
			b := binom(n-1, i) * math.Pow(t, float64(i)) * math.Pow(1-t, float64(n-1-i))
			x += b * v[i].X
			y += b * v[i].Y
		}
		out = append(out, Pt{X: x, Y: y, Typ: 'i'})
	}
	return out
}

func binom(n, k int) float64 {
	r := 1.0
	for i := 1; i <= k; i++ {
		r = r * float64(n-k+i) / float64(i)
	}
	return r
}

func kdensity(v []Pt) []Pt {
	n := len(v)
	if n == 0 {
		return nil
	}
	sum, sw := 0.0, 0.0
	for _, p := range v {
		sum += p.X
		sw += 1
	}
	mean := sum / sw
	vs := 0.0
	for _, p := range v {
		vs += (p.X - mean) * (p.X - mean)
	}
	sigma := math.Sqrt(vs / sw)
	h := 1.06 * sigma * math.Pow(float64(n), -0.2)
	if h == 0 {
		h = 1
	}
	xmin, xmax := v[0].X, v[0].X
	for _, p := range v {
		xmin = math.Min(xmin, p.X)
		xmax = math.Max(xmax, p.X)
	}
	ns := S.Samples1
	var out []Pt
	for k := 0; k < ns; k++ {
		x := xmin + float64(k)*(xmax-xmin)/float64(ns-1)
		y := 0.0
		for _, p := range v {
			z := (x - p.X) / h
			y += p.Y * math.Exp(-z*z/2) / math.Sqrt(2*math.Pi) / h
		}
		out = append(out, Pt{X: x, Y: y, Typ: 'i'})
	}
	return out
}

func doBins(c *Curve) []Pt {
	v := validPts(c.Pts)
	if len(v) == 0 {
		return nil
	}
	nb := c.BinsN
	xmin, xmax := v[0].X, v[0].X
	for _, p := range v {
		xmin = math.Min(xmin, p.X)
		xmax = math.Max(xmax, p.X)
	}
	w := (xmax - xmin) / float64(nb-1)
	ys := make([]float64, nb)
	ns := make([]int, nb)
	for _, p := range v {
		i := int(math.Floor((p.X-xmin)/w + 0.5))
		if i < 0 || i >= nb {
			continue
		}
		ys[i] += p.Y
		ns[i]++
	}
	var out []Pt
	for i := 0; i < nb; i++ {
		x := xmin + float64(i)*w
		out = append(out, Pt{X: x, Y: ys[i], Typ: 'i', Ex: []float64{x - w/2, x + w/2, float64(ns[i])}})
	}
	return out
}
