package main

func cmdUpdate(ps *Parser) {
	for !ps.atEnd() {
		ps.next()
	}
}
func cmdSave(ps *Parser) {
	for !ps.atEnd() {
		ps.next()
	}
}


func cmdReplot(ps *Parser) {
	for !ps.atEnd() {
		ps.next()
	}
	if lastPlotToks == nil {
		errNoCaret("no previous plot")
	}
	toks := append([]Token{}, lastPlotToks...)
	p := &Parser{toks: toks, line: lastPlotLine}
	cmdPlot(p, lastPlotIs3D)
}
func cmdClear() {}
func startMultiplot(ps *Parser) { for !ps.atEnd() { ps.next() } }
func endMultiplot() {}
func parseColorName(s string) (int, bool) { return 0, false }
func renderSVG(curves []*Curve, is3D bool) {}
