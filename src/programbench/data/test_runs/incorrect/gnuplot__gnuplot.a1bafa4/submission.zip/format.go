package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

func gpSprintf(f string, args []Value) string {
	var b strings.Builder
	ai := 0
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' {
			b.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			b.WriteByte('%')
			i += 2
			continue
		}
		sp, ni, ok := parseSpec(f, i)
		if !ok {
			b.WriteString(f[i:])
			break
		}
		// star width not supported
		if ai >= len(args) {
			b.WriteString(f[i:])
			break
		}
		a := args[ai]
		ai++
		switch sp.Conv {
		case 's':
			if a.K != STR {
				errNoCaret("f_sprintf: attempt to print numeric value with string format")
			}
			b.WriteString(fmtSpecVal(sp, a))
		case 'd', 'i', 'x', 'X', 'o', 'u', 'c', 'f', 'F', 'e', 'E', 'g', 'G':
			if a.K == STR {
				errNoCaret("f_sprintf: attempt to print string value with numeric format")
			}
			b.WriteString(fmtSpecVal(sp, a.Num()))
		default:
			errNoCaret("bad format character")
		}
		i = ni
	}
	return b.String()
}

var sciPrefix = map[int]string{-24: "y", -21: "z", -18: "a", -15: "f", -12: "p", -9: "n", -6: "u", -3: "m", 0: "", 3: "k", 6: "M", 9: "G", 12: "T", 15: "P", 18: "E", 21: "Z", 24: "Y"}

// gprintf implements gnuplot's tic-label style format
func gprintf(f string, x float64) string {
	var b strings.Builder
	logbase := 10.0
	if lb, ok := gvars["__logbase"]; ok {
		logbase = lb.R
	}
	i := 0
	// precompute mantissa/exponent pairs lazily
	for i < len(f) {
		c := f[i]
		if c != '%' {
			b.WriteByte(c)
			i++
			continue
		}
		if i+1 < len(f) && f[i+1] == '%' {
			b.WriteByte('%')
			i += 2
			continue
		}
		sp, ni, ok := parseSpec(f, i)
		if !ok {
			b.WriteString(f[i:])
			break
		}
		i = ni
		switch sp.Conv {
		case 'f', 'F', 'e', 'E', 'g', 'G':
			b.WriteString(fmtFloat(sp, x))
		case 'x', 'X', 'o', 'd', 'i':
			b.WriteString(fmtInt(sp, int64(x)))
		case 't', 'T':
			m, e := mantExp(x, 10)
			if sp.Conv == 't' {
				sp.Conv = 'f'
				b.WriteString(fmtFloat(sp, m))
			} else {
				sp.Conv = 'd'
				b.WriteString(fmtInt(sp, int64(e)))
			}
		case 'l', 'L':
			m, e := x, 0
			if logbase != 10 || true {
				_ = logbase
			}
			if sp.Conv == 'l' {
				sp.Conv = 'f'
				b.WriteString(fmtFloat(sp, m))
			} else {
				sp.Conv = 'd'
				b.WriteString(fmtInt(sp, int64(e)))
			}
		case 's', 'S', 'c':
			m, e := mantExp(x, 10)
			// engineering: power multiple of 3
			e3 := int(math.Floor(float64(e) / 3))
			e3 *= 3
			m = x / math.Pow(10, float64(e3))
			if x == 0 {
				m, e3 = 0, 0
			}
			_ = m
			switch sp.Conv {
			case 's':
				sp.Conv = 'f'
				b.WriteString(fmtFloat(sp, m))
			case 'S':
				sp.Conv = 'd'
				b.WriteString(fmtInt(sp, int64(e3)))
			case 'c':
				p, ok := sciPrefix[e3]
				if !ok {
					p = fmt.Sprintf("e%d", e3)
				}
				b.WriteString(p)
			}
		case 'P':
			sp.Conv = 'g'
			b.WriteString(fmtFloat(sp, x/math.Pi))
		case 'h', 'H':
			sp.Conv = 'g'
			s := fmtFloat(sp, x)
			b.WriteString(s)
		default:
			errNoCaret("Bad format character")
		}
	}
	return b.String()
}

func mantExp(x, base float64) (float64, int) {
	if x == 0 {
		return 0, 0
	}
	l := math.Log(math.Abs(x)) / math.Log(base)
	e := int(math.Floor(l + 1e-12))
	m := x / math.Pow(base, float64(e))
	return m, e
}

var monNames = []string{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
var dayNames = []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}

func gpStrftime(f string, t float64) string {
	if math.IsNaN(t) || math.IsInf(t, 0) {
		return ""
	}
	sec := math.Floor(t)
	frac := t - sec
	tt := time.Unix(int64(sec), 0).UTC()
	var b strings.Builder
	i := 0
	for i < len(f) {
		c := f[i]
		if c != '%' || i+1 >= len(f) {
			b.WriteByte(c)
			i++
			continue
		}
		i++
		// optional width/precision e.g. %.3S
		prec := -1
		if f[i] == '.' {
			i++
			prec = 0
			for i < len(f) && isDigit(f[i]) {
				prec = prec*10 + int(f[i]-'0')
				i++
			}
		}
		if i >= len(f) {
			break
		}
		d := f[i]
		i++
		switch d {
		case 'a':
			b.WriteString(dayNames[tt.Weekday()][:3])
		case 'A':
			b.WriteString(dayNames[tt.Weekday()])
		case 'b', 'h':
			b.WriteString(monNames[tt.Month()-1][:3])
		case 'B':
			b.WriteString(monNames[tt.Month()-1])
		case 'd':
			fmt.Fprintf(&b, "%02d", tt.Day())
		case 'e':
			fmt.Fprintf(&b, "%2d", tt.Day())
		case 'D':
			fmt.Fprintf(&b, "%02d/%02d/%02d", tt.Month(), tt.Day(), tt.Year()%100)
		case 'F':
			fmt.Fprintf(&b, "%04d-%02d-%02d", tt.Year(), tt.Month(), tt.Day())
		case 'H':
			fmt.Fprintf(&b, "%02d", tt.Hour())
		case 'k':
			fmt.Fprintf(&b, "%2d", tt.Hour())
		case 'I':
			h := tt.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%02d", h)
		case 'l':
			h := tt.Hour() % 12
			if h == 0 {
				h = 12
			}
			fmt.Fprintf(&b, "%2d", h)
		case 'j':
			fmt.Fprintf(&b, "%03d", tt.YearDay())
		case 'm':
			fmt.Fprintf(&b, "%02d", tt.Month())
		case 'M':
			fmt.Fprintf(&b, "%02d", tt.Minute())
		case 'p':
			if tt.Hour() < 12 {
				b.WriteString("am")
			} else {
				b.WriteString("pm")
			}
		case 'r':
			h := tt.Hour() % 12
			if h == 0 {
				h = 12
			}
			ap := "AM"
			if tt.Hour() >= 12 {
				ap = "PM"
			}
			fmt.Fprintf(&b, "%02d:%02d:%02d %s", h, tt.Minute(), tt.Second(), ap)
		case 'R':
			fmt.Fprintf(&b, "%02d:%02d", tt.Hour(), tt.Minute())
		case 'S':
			if prec > 0 {
				s := float64(tt.Second()) + frac
				w := prec + 3
				b.WriteString(fmt.Sprintf("%0*.*f", w, prec, s))
			} else {
				fmt.Fprintf(&b, "%02d", tt.Second())
			}
		case 's':
			b.WriteString(strconv.FormatInt(int64(sec), 10))
		case 'T':
			fmt.Fprintf(&b, "%02d:%02d:%02d", tt.Hour(), tt.Minute(), tt.Second())
		case 'y':
			fmt.Fprintf(&b, "%02d", tt.Year()%100)
		case 'Y':
			fmt.Fprintf(&b, "%d", tt.Year())
		case 'w':
			fmt.Fprintf(&b, "%d", tt.Weekday())
		case 'U':
			fmt.Fprintf(&b, "%02d", (tt.YearDay()+6-int(tt.Weekday()))/7)
		case 'W':
			fmt.Fprintf(&b, "%02d", (tt.YearDay()+6-(int(tt.Weekday())+6)%7)/7)
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case '%':
			b.WriteByte('%')
		case 'z':
			b.WriteString("+0000")
		case 'Z':
			b.WriteString("UTC")
		default:
			b.WriteByte('%')
			b.WriteByte(d)
		}
	}
	return b.String()
}

func gpStrptime(f, s string) (float64, bool) {
	year, mon, day, hour, min := 1970, 1, 1, 0, 0
	secf := 0.0
	yday := -1
	pm := -1
	epoch := math.NaN()
	i, j := 0, 0
	readInt := func(maxd int) (int, bool) {
		for j < len(s) && s[j] == ' ' {
			j++
		}
		neg := false
		if j < len(s) && (s[j] == '-' || s[j] == '+') {
			neg = s[j] == '-'
			j++
		}
		st := j
		for j < len(s) && isDigit(s[j]) && j-st < maxd {
			j++
		}
		if j == st {
			return 0, false
		}
		v, _ := strconv.Atoi(s[st:j])
		if neg {
			v = -v
		}
		return v, true
	}
	for i < len(f) {
		c := f[i]
		if c != '%' {
			if c == ' ' {
				for j < len(s) && s[j] == ' ' {
					j++
				}
				i++
				continue
			}
			if j < len(s) && s[j] == c {
				j++
			} else {
				return 0, false
			}
			i++
			continue
		}
		i++
		if i >= len(f) {
			break
		}
		d := f[i]
		i++
		var ok bool
		switch d {
		case 'Y':
			year, ok = readInt(4)
		case 'y':
			var y int
			y, ok = readInt(2)
			if y < 69 {
				year = 2000 + y
			} else {
				year = 1900 + y
			}
		case 'm':
			mon, ok = readInt(2)
		case 'd', 'e':
			day, ok = readInt(2)
		case 'H', 'k':
			hour, ok = readInt(2)
		case 'I', 'l':
			hour, ok = readInt(2)
		case 'M':
			min, ok = readInt(2)
		case 'j':
			yday, ok = readInt(3)
		case 'S':
			for j < len(s) && s[j] == ' ' {
				j++
			}
			st := j
			for j < len(s) && (isDigit(s[j]) || s[j] == '.') {
				j++
			}
			ok = j > st
			secf, _ = strconv.ParseFloat(s[st:j], 64)
		case 's':
			st := j
			for j < len(s) && (isDigit(s[j]) || s[j] == '.' || s[j] == '-') {
				j++
			}
			ok = j > st
			epoch, _ = strconv.ParseFloat(s[st:j], 64)
		case 'b', 'h', 'B':
			ok = false
			for k, m := range monNames {
				if len(s)-j >= 3 && strings.EqualFold(s[j:j+3], m[:3]) {
					mon = k + 1
					if d == 'B' && strings.HasPrefix(strings.ToLower(s[j:]), strings.ToLower(m)) {
						j += len(m)
					} else {
						j += 3
					}
					ok = true
					break
				}
			}
		case 'a', 'A':
			ok = false
			for _, m := range dayNames {
				if len(s)-j >= 3 && strings.EqualFold(s[j:j+3], m[:3]) {
					if d == 'A' && strings.HasPrefix(strings.ToLower(s[j:]), strings.ToLower(m)) {
						j += len(m)
					} else {
						j += 3
					}
					ok = true
					break
				}
			}
		case 'p':
			if j+2 <= len(s) {
				u := strings.ToUpper(s[j : j+2])
				if u == "PM" {
					pm = 1
				} else if u == "AM" {
					pm = 0
				}
				j += 2
				ok = true
			}
		case 'T':
			hour, ok = readInt(2)
			if ok && j < len(s) && s[j] == ':' {
				j++
				min, ok = readInt(2)
				if ok && j < len(s) && s[j] == ':' {
					j++
					var sv int
					sv, ok = readInt(2)
					secf = float64(sv)
				}
			}
		case '%':
			if j < len(s) && s[j] == '%' {
				j++
				ok = true
			}
		default:
			ok = true
		}
		if !ok {
			return 0, false
		}
	}
	if !math.IsNaN(epoch) {
		return epoch, true
	}
	if pm == 1 && hour < 12 {
		hour += 12
	} else if pm == 0 && hour == 12 {
		hour = 0
	}
	var t time.Time
	if yday > 0 {
		t = time.Date(year, 1, 1, hour, min, 0, 0, time.UTC).AddDate(0, 0, yday-1)
	} else {
		t = time.Date(year, time.Month(mon), day, hour, min, 0, 0, time.UTC)
	}
	return float64(t.Unix()) + secf, true
}
