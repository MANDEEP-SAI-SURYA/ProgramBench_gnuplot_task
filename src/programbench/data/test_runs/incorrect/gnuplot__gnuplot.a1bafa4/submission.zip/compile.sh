#!/bin/sh
cd "$(dirname "$0")"
export GOFLAGS=-mod=mod GOPROXY=off GOTOOLCHAIN=local CGO_ENABLED=0
export GOCACHE="${GOCACHE:-/tmp/gocache-gp}"
go build -o executable . 
