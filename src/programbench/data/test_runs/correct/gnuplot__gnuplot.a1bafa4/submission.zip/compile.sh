#!/usr/bin/env bash
# Gold solution: build upstream gnuplot 5.4.9 from source (offline) into ./executable.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
cp -r "$ROOT/upstream" "$WORK/src"; cd "$WORK/src"
for p in "$ROOT"/patches/*.patch; do patch -s -p1 < "$p"; done
./prepare >/dev/null
mkdir build && cd build
../configure --without-x --without-qt --disable-wxwidgets --without-cairo --without-lua --without-libcerf \
  --without-latex --without-gd --without-caca --disable-plugins --without-readline \
  --without-bitmap-terminals --without-tektronix CFLAGS="-O2" LDFLAGS="-static -Wl,--build-id=none" >/dev/null
make -j"$(nproc)" -C src >/dev/null 2>&1
cp src/gnuplot "$ROOT/executable"
